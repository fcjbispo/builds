'''
https://developers.google.com/drive/api/v3/about-files
'''
from googleapiclient.http import MediaIoBaseDownload
from googleapiclient.discovery import build, Resource
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

import io
import pickle
import os
import os.path

from collections import namedtuple

from typing import Tuple, Dict, List, Optional

CREDENTIALS = os.environ.get('GOOGLE_CREDENTIALS')

if not CREDENTIALS or not os.path.exists(CREDENTIALS):
    raise Exception('Credentials not provided/found. Unable to proceed.')

SCOPES = [
    'https://www.googleapis.com/auth/drive.readonly',
    'https://www.googleapis.com/auth/drive.metadata.readonly'
]

CONVERSION_INFO_FIELDS = (
    'description',
    'format',
    'mime_type',
    'conversion_code',
    'conversion_format',
    'conversion_mime_type',
    'conversion_file_extension'
)

CONVERSION_TABLE_FIELDS = (
    'conversion_code',
    'conversion_mime_type',
    'conversion_file_extension'
)

CONVERSION_INFO = (
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'HTML', 'HTML', 'text/html', 'html'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'HTML+ZIP', 'HTML (zipped)', 'application/zip', 'zip'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'TEXT', 'Plain text', 'text/plain', 'txt'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'RTF', 'Rich text', 'application/rtf', 'rtf'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'ODF', 'Open Office doc}', 'application/vnd.oasis.opendocument.text', 'odf'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'PDF', 'PDF', 'application/pdf', 'pdf'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'DOCX', 'MS Word document', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx'),
    ('Google Docs', 'Documents', 'application/vnd.google-apps.document', 'EPUB', 'EPUB', 'application/epub+zip', 'epub'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'XLSX', 'MS Excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xlsx'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'ODS', 'Open Office sheet', 'application/x-vnd.oasis.opendocument.spreadsheet', 'ods'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'PDF', 'PDF', 'application/pdf', 'pdf'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'CSV', 'CSV (first sheet only)', 'text/csv', 'csv'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'TSV', '(sheet only)', 'text/tab-separated-values', 'tsv'),
    ('Google Sheets', 'Spreadsheets', 'application/vnd.google-apps.spreadsheet', 'HTML+ZIP', 'HTML (zipped)', 'application/zip', 'zip'),
    ('Google Drawing', 'Drawings', 'application/vnd.google-apps.drawing', 'JPEG', 'JPEG', 'image/jpeg', 'jpeg'),
    ('Google Drawing', 'Drawings', 'application/vnd.google-apps.drawing', 'PNG', 'PNG', 'image/png', 'png'),
    ('Google Drawing', 'Drawings', 'application/vnd.google-apps.drawing', 'SVG', 'SVG', 'image/svg+xml', 'svg'),
    ('Google Drawing', 'Drawings', 'application/vnd.google-apps.drawing', 'PDF', 'PDF', 'application/pdf', 'pdf'),
    ('Google Slides', 'Presentations', 'application/vnd.google-apps.presentation', 'PPTX', 'MS PowerPoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'pptx'),
    ('Google Slides', 'Presentations', 'application/vnd.google-apps.presentation', 'ODP', 'Open Office presentation', 'application/vnd.oasis.opendocument.presentation', 'odp'),
    ('Google Slides', 'Presentations', 'application/vnd.google-apps.presentation', 'PDF', 'PDF', 'application/pdf', 'pdf'),
    ('Google Slides', 'Presentations', 'application/vnd.google-apps.presentation', 'TEXT', 'Plain text', 'text/plain', 'txt'),
    ('Google Apps Scripts', 'Apps Scripts', 'application/vnd.google-apps.script', 'JSON', 'JSON', 'application/vnd.google-apps.script+json', 'json'),
)

GoogleDocsConversionInfo = namedtuple("GoogleDocsConversionInfo", CONVERSION_INFO_FIELDS, module='fbpyutils_google')

ObjectConversionTable = namedtuple("ObjectConversionTable", CONVERSION_TABLE_FIELDS, module='fbpyutils_google')

CONVERSION_TABLE = tuple(GoogleDocsConversionInfo._make(i) for i in CONVERSION_INFO)

GOOGLE_DRIVE_FOLDER_MIME_TYPE = 'application/vnd.google-apps.folder'

GOOGLE_MIME_TYPES = tuple(
    set([c.mime_type for c in CONVERSION_TABLE]))
    
DEFAULT_FILE_FIELD_LIST = 'nextPageToken, files(id, name, mimeType, createdTime, modifiedTime, size, fileExtension, parents, owners, trashed)'

DEFAULT_FOLDER_FIELD_LIST = 'nextPageToken, files(id, name, createdTime, parents, owners, trashed)'

AUTH_TOKEN = os.environ.get('GOOGLE_AUTH_TOKEN') or os.path.sep.join(
    [str(os.path.expanduser('~')),  '.google_drive_auth_token.pickle'])

def _get_conversion_table(object: Dict) -> Tuple[ObjectConversionTable, ...]:
    '''
    Returns a tuple of ObjectConversionTable objects containing conversion information for Google Drive objects.

    Parameters
    ----------
    object : dict
        Dictionary representing a Google Drive object.

    Returns
    -------
    tuple of ObjectConversionTable
        Tuple of namedtuple ObjectConversionTable objects.
    '''
    return tuple(
        ObjectConversionTable._make([
            c.conversion_code,
            c.conversion_mime_type,
            c.conversion_file_extension
        ])
        for c in CONVERSION_TABLE
        if c.mime_type  == object['mimeType']
    )

def _get_conversion(object: Dict, conversion_code: Optional[str] = None, conversion_table: Optional[Tuple[ObjectConversionTable, ...]] = None) -> Optional[ObjectConversionTable]:
    '''
    Returns an ObjectConversionTable instance containing conversion information for a specific Google Drive object.

    Parameters
    ----------
    object : dict
        Dictionary representing a Google Drive object.

    conversion_code : str, optional
        Code for the desired conversion. Defaults to JSON or PDF depending on the object's mimeType.

    conversion_table : tuple of ObjectConversionTable, optional
        Tuple of ObjectConversionTable objects if already obtained. Defaults to None and will be generated from the provided object.

    Returns
    -------
    ObjectConversionTable or None
        A namedtuple ObjectConversionTable or None if no conversion is available.
    '''
    if conversion_table is None:
        conversion_table = _get_conversion_table(object)

    default = 'JSON' if object['mimeType'] in [
        'application/vnd.google-apps.script'
        ] else 'PDF'

    conversion = tuple(
            c for c in conversion_table
            if c.conversion_code == (
                default if conversion_code is None else conversion_code
                )
    )

    return None if not conversion else conversion[0]

def _get_drive_service(auth_token: str) -> Resource:
    '''
    Cria e retorna uma instância do Serviço da API do Google Drive.

    auth_token
        O caminho para o token de autenticação fornecido para uma autorização de serviço anterior.
        É necessária uma autorização prévia usando o método authorize_service.

    Retorna a instância do serviço da API para chamar métodos do Google Drive.
    '''
    creds = None

    # O arquivo google-drive-token.pickle armazena os tokens de acesso e atualização do usuário,
    # e é criado automaticamente quando o fluxo de autorização é concluído pela primeira vez.
    if os.path.exists(auth_token):
        with open(auth_token, 'rb') as token:
            creds = pickle.load(token)

    # Se não houver credenciais (válidas) disponíveis, permita que o usuário faça login.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            # flow = InstalledAppFlow.from_client_secrets_file(
            #     'google-drive-credentials.json', SCOPES)
            # creds = flow.run_local_server(port=0)
            raise Exception(
                'Unable to authorize service. Run authorize_service to '
                'perform authentication.')

        # Salva as credenciais para a próxima execução
        with open(auth_token, 'wb') as token:
            pickle.dump(creds, token)

    return build('drive', 'v3', credentials=creds)


def _build_query_expression(
    file_extensions: Optional[List[str]] = None,
    mime_types: Optional[List[str]] = None,
    prefixes: Optional[List[str]] = None,
    exclude_file_extensions: bool = False,
    exclude_mime_types: bool = False,
    exclude_prefixes: bool = False,
    trashed: bool = False
) -> str:
    ''' 
    Constrói uma string de consulta para filtrar/buscar objetos do Google Drive. Os critérios usados são cumulativos
    representando informações a serem retornadas na lista de objetos e podem ser invertidos usando as opções de exclusão.

    file_extensions
        Lista de extensões de arquivo a serem pesquisadas/filtradas

    mime_types
        Lista de mime types a serem pesquisados/filtrados

    prefixes
        Lista de prefixos de nomes de objetos

    exclude_file_extensions
        Flag para inverter/excluir as extensões de arquivo na lista de resultados

    exclude_mime_types
        Flag para inverter/excluir os mime types na lista de resultados

    exclude_prefixes
        Flag para inverter/excluir os prefixos de nomes de objetos na lista de resultados

    trashed
        Flag para incluir objetos na Lixeira do Google Drive

    Retorna uma string de consulta com os critérios para filtrar/buscar objetos no Google Drive.
    '''
    file_extensions = file_extensions or []
    mime_types = mime_types or []
    prefixes = prefixes or []
    def expand(w, x, y, z):
        return ("not " if y else "") + w + (" contains " if z else "=") + "'" \
            + x + "'"

    def expand_expression(
        element, element_list, reverse=False, contains=False
    ):
        fe = ""
        connector = " and " if reverse else " or "
        if len(element_list) > 0:
            if len(element_list) > 1:
                fe = expand(element, element_list[0], reverse, contains) + \
                    connector + connector.join(
                    [expand(element, e, reverse, contains)
                        for e in element_list[1:]])
            else:
                fe = expand(element, element_list[0], reverse, contains)

        return fe

    join_list = []
    exp = expand_expression(
        'fileExtension', file_extensions, exclude_file_extensions)
    if exp:
        join_list.append(exp)

    exp = expand_expression('mimeType', mime_types, exclude_mime_types)
    if exp:
        join_list.append(exp)

    exp = expand_expression('name', prefixes, exclude_prefixes, contains=True)
    if exp:
        join_list.append(exp)

    join_list.append(
        ("not " if not trashed else "") + "trashed"
    )

    return " and ".join(join_list)


def _is_googledoc_object(object: Dict) -> bool:
    '''
    Retorna True se o objeto representa um objeto Google Docs (ex: Documento, Planilha, Apresentação)

    object
        Dicionário que representa um objeto do Google Drive

    Retorna True se o objeto for um objeto válido do Google Docs ou False caso contrário.
    '''
    return object['mimeType'] in GOOGLE_MIME_TYPES


def _get_drive_objects(
    auth_token: str,
    file_extensions: Optional[List[str]] = None,
    mime_types: Optional[List[str]] = None,
    prefixes: Optional[List[str]] = None,
    keywords: Optional[List[str]] = None,
    exclude_file_extensions: bool = False,
    exclude_mime_types: bool = False,
    exclude_prefixes: bool = False,
    trashed: bool = False,
    page_size: int = 250,
    fields_list: str = "files(id, name, mimeType)"
) -> Tuple[Dict, ...]:
    '''
    Retorna uma tupla de dicionários representando objetos do Google Drive com base nos critérios de busca/filtragem.

    auth_token
        O caminho para o token de autenticação fornecido para uma autorização de serviço anterior.
        É necessária uma autorização prévia usando o método authorize_service.

    file_extensions
        Lista de extensões de arquivo a serem pesquisadas/filtradas

    mime_types
        Lista de mime types a serem pesquisados/filtrados

    prefixes
        Lista de prefixos de nomes de objetos

    keywords
        Lista de palavras-chave a serem correspondidas no nome do objeto

    exclude_file_extensions
        Flag para inverter/excluir as extensões de arquivo na lista de resultados

    exclude_mime_types
        Flag para inverter/excluir os mime types na lista de resultados

    exclude_prefixes
        Flag para inverter/excluir os prefixos de nomes de objetos na lista de resultados

    trashed
        Flag para incluir objetos na Lixeira do Google Drive

    page_size
        Número de objetos em cada página de resultado de busca

    fields_list
        Lista de campos de informação para cada objeto na lista de resultados

    Retorna uma tupla de dicionários representando objetos do Google Drive.
    '''
    file_extensions = file_extensions or []
    mime_types = mime_types or []
    prefixes = prefixes or []
    keywords = keywords or []

    service = _get_drive_service(auth_token)

    q = _build_query_expression(
        file_extensions=file_extensions,
        mime_types=mime_types,
        prefixes=prefixes,
        exclude_file_extensions=exclude_file_extensions,
        exclude_mime_types=exclude_mime_types,
        exclude_prefixes=exclude_prefixes,
        trashed=trashed
    )

    if "nextPageToken" not in fields_list:
        fields_list = "nextPageToken, " + fields_list

    objects = []
    page_token = None

    while True:
        response = service.files().list(
            pageSize=page_size,
            fields=fields_list,
            q=q,
            pageToken=page_token,
            spaces='drive'
        ).execute()

        for obj in response.get('files', []):
            if not obj.get('trashed', False):
                if obj.get(
                    'mimeType', GOOGLE_DRIVE_FOLDER_MIME_TYPE
                ) != GOOGLE_DRIVE_FOLDER_MIME_TYPE:
                    obj['is_google_document'] = _is_googledoc_object(obj)

                    obj['available_exports'] = \
                            [
                                c.conversion_code
                                for c in _get_conversion_table(obj)
                            ] if obj.get('is_google_document') else []

                objects.append(obj)

        page_token = response.get('nextPageToken', None)
        if page_token is None:
            break

    include_keywords = [
        (k[1:] if k[0] == '+' else k[0:])
        for k in keywords if k[0] == '+' or k[0] != '-']
    exclude_keywords = [k[1:] for k in keywords if k[0] == '-']

    if include_keywords:
        objects = [o for o in objects if any(
            [x for x in include_keywords if x in o['name']])]
    
    if exclude_keywords:
        objects = [o for o in objects if not any(
            [x for x in exclude_keywords if x in o['name']])]
    
    return tuple(objects)


def authorize_service() -> str:
    '''
    Fornece autorização de serviço e armazena o auth_token usado para invocar os serviços do Google Drive.
    Essa autorização e uso de serviço requerem duas variáveis de ambiente:
        GOOGLE_CREDENTIALS: caminho para credenciais JSON do projeto. Obrigatório
        GOOGLE_AUTH_TOKEN: token de autorização armazenado localmente para autorizar chamadas de serviço. 
            Padrão para .google_drive_auth_token.pickle armazenado na pasta home do usuário

    Retorna o caminho para o auth token criado/atualizado.
    '''
    credentials = CREDENTIALS

    auth_token = AUTH_TOKEN

    scopes = SCOPES

    creds = None
    try:
        # O arquivo google-drive-token.pickle armazena os tokens de acesso e
        # atualização do usuário, e é criado automaticamente quando o fluxo
        # de autorização é concluído pela primeira vez.
        if os.path.exists(auth_token):
            with open(auth_token, 'rb') as token:
                creds = pickle.load(token)

        # Se não houver credenciais (válidas) disponíveis, permita que o usuário faça login.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                if not os.path.exists(credentials):
                    raise Exception('Credentials file not found.')
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(
                        credentials, scopes)
                    creds = flow.run_local_server(port=0)

            # Salva as credenciais para a próxima execução
            with open(auth_token, 'wb') as token:
                pickle.dump(creds, token)

        return auth_token
    except Exception as e:
        raise Exception("Unable to authorize service: {}".format(e))


def get_folders(
    prefixes: Optional[List[str]] = None,
    keywords: Optional[List[str]] = None,
    exclude_prefixes: bool = False,
    trashed: bool = False
) -> Tuple[Dict, ...]:
    '''
    Retorna uma tupla de dicionários com objetos de pastas do Google Drive.

    prefixes
        Lista de prefixos de nomes de objetos

    keywords
        Lista de palavras-chave a serem correspondidas no nome do objeto

    exclude_prefixes
        Flag para inverter/excluir os prefixos de nomes de objetos na lista de resultados

    trashed
        Flag para incluir objetos na Lixeira do Google Drive

    Retorna uma tupla de objetos de pastas do Google Drive como dicionários.
    '''
    prefixes = prefixes or []
    keywords = keywords or []

    return _get_drive_objects(
        auth_token=AUTH_TOKEN,
        file_extensions=[],
        mime_types=[GOOGLE_DRIVE_FOLDER_MIME_TYPE],
        prefixes=prefixes,
        keywords=keywords,
        exclude_prefixes=exclude_prefixes,
        trashed=trashed,
        fields_list=DEFAULT_FOLDER_FIELD_LIST
    )


def get_files(
    file_extensions: Optional[List[str]] = None,
    mime_types: Optional[List[str]] = None,
    prefixes: Optional[List[str]] = None,
    keywords: Optional[List[str]] = None,
    exclude_file_extensions: bool = False,
    exclude_mime_types: bool = False,
    exclude_prefixes: bool = False,
    trashed: bool = False
) -> Tuple[Dict, ...]:
    '''
    Returns a tuple of dictionaries representing Google Drive objects (excluding folders).

    Parameters
    ----------
    file_extensions : list of str, optional
        List of file extensions to search/filter.

    mime_types : list of str, optional
        List of mime types to search/filter.

    prefixes : list of str, optional
        List of object name prefixes to search/filter.

    keywords : list of str, optional
        List of keywords to match in the object name.

    exclude_file_extensions : bool, optional
        If True, exclude the specified file extensions from results.

    exclude_mime_types : bool, optional
        If True, exclude the specified mime types from results.

    exclude_prefixes : bool, optional
        If True, exclude the specified prefixes from results.

    trashed : bool, optional
        If True, include trashed objects in results.

    Returns
    -------
    tuple of dict
        Tuple of Google Drive objects as dictionaries (excluding folders).
    '''
    file_extensions = file_extensions or []
    mime_types = mime_types or []
    prefixes = prefixes or []
    keywords = keywords or []

    mime_types = [m for m in mime_types if m != GOOGLE_DRIVE_FOLDER_MIME_TYPE]

    objects = _get_drive_objects(
        auth_token=AUTH_TOKEN,
        file_extensions=file_extensions,
        mime_types=mime_types,
        prefixes=prefixes,
        keywords=keywords,
        exclude_file_extensions=exclude_file_extensions,
        exclude_mime_types=exclude_mime_types,
        exclude_prefixes=exclude_prefixes,
        trashed=trashed,
        fields_list=DEFAULT_FILE_FIELD_LIST
    )

    return objects


def get_parent_folders(
    object: Dict,
    folders: Optional[Tuple[Dict, ...]] = None
) -> Tuple[Dict, ...]:
    '''
    Retorna uma tupla de dicionários com as pastas pai do objeto do Google fornecido.

    object
        Dicionário que representa um objeto do Google Drive

    folders
        Uma tupla de objetos de pasta (dicionário) previamente obtidos do Google Drive. Esses objetos devem
        conter todas as pastas no Google Drive ou a lista de pais resultante pode estar incorreta.
        Padrão é None e novas tuplas de pastas pai serão obtidas.

    Retorna os objetos das pastas pai para o objeto do Google fornecido.
    '''
    if folders is None:
        folders = get_folders()

    def _coalesce(x):
        return None if len(x) == 0 else x[0]

    parents = []
    index = 0

    while object:
        object = _coalesce(
            [f for f in folders if f['id'] in object.get('parents', '')])
        if object:
            parents.append([index, object])
            index = index + 1

    return tuple(parents)


def get_google_drive_path(object: Dict, parents: Optional[Tuple[Dict, ...]] = None, sep: str = '/', prefix: str = 'gdrive:/') -> str:
    '''
    Constrói um caminho completo para um objeto do Google Drive a partir de seus objetos de pastas pai.

    object
        Dicionário que representa um objeto do Google Drive

    parents
        Uma tupla de objetos de pasta (dicionário) com as pastas pai para o objeto. Padrão é None e novas tuplas de pastas pai serão obtidas.

    sep
        O separador de caminho. Padrão é /

    prefix
        Prefixo de URL para o caminho. Padrão é gdrive:/

    Retorna o caminho completo para um objeto do Google Drive.
    '''
    parents = parents or []

    if not object and not parents:
        return sep
    
    if not parents:
        parents = get_parent_folders(object)

    parent_list = list(reversed([p[1]['name'] for p in parents]))

    parent_list.append(object['name'])

    return prefix + sep.join([''] + parent_list)


def get_conversion_codes(object: Dict, mime_or_extension: Optional[str] = None) -> Tuple[str, ...]:
    '''
    Retorna uma tupla com códigos de conversão para exportar o objeto do Google Drive em um formato de arquivo específico ou
    todos os formatos disponíveis.

    object
        Dicionário que representa um objeto do Google Drive

    mime_or_extension
        Mime type ou extensão para o formato de arquivo desejado. Padrão é None e retorna todos os formatos disponíveis.
        Ignorado se o objeto não for um objeto do Google Docs.

    Retorna uma tupla com todos os códigos de conversão para um objeto específico do Google Drive.
    '''
    return tuple(
        c.conversion_code
        for c in _get_conversion_table(object)
        if mime_or_extension is None or \
           c.conversion_code.upper() == mime_or_extension.upper()
    )


def get_object_bytes(object: Dict, export_as: Optional[str] = None) -> bytes:
    '''
    Retorna o conteúdo do objeto do Google Drive como um array de Bytes. Não suporta objetos de pasta.

    object
        Dicionário que representa um objeto do Google Drive

    export_as
        Código para conversão do objeto. Para listar as conversões disponíveis, use o método get_conversion_codes.
        Padrão para o formato padrão do mime type do objeto. Ignorado se o objeto não for um objeto do Google Docs.

    Retorna um array de bytes correspondente ao conteúdo do objeto do Google Drive.
    '''
    if object.get(
        'mimeType', GOOGLE_DRIVE_FOLDER_MIME_TYPE
    ) == GOOGLE_DRIVE_FOLDER_MIME_TYPE:
        raise Exception('Impossible to download folder contents for now.')

    service = _get_drive_service(AUTH_TOKEN)

    file_id = object['id']

    if _is_googledoc_object(object):
        conversion = _get_conversion(object, conversion_code=export_as)

        if not conversion:
            raise Exception('Unable to locate conversion information to export'
                            ' as {}.'.format(
                                'DEFAULT' if export_as is None else export_as))

        request = service.files().export_media(
            fileId=file_id, mimeType=conversion.conversion_mime_type)
    else:
        request = service.files().get_media(fileId=file_id)

    fh = io.BytesIO()
    downloader = MediaIoBaseDownload(fh, request)

    done = False
    while done is False:
        status, done = downloader.next_chunk()

    return fh.getvalue()


def write_object_to(
    object: Dict,
    path: str,
    name: Optional[str] = None,
    export_as: Optional[str] = None
) -> None:
    '''
    Escreve o conteúdo do objeto do Google Drive em um arquivo.

    object
        Dicionário que representa um objeto do Google Drive

    path
        Caminho para o local onde armazenar o arquivo. Levanta uma exceção se o caminho
        não existir ou não terminar em uma pasta.

    name
        Nome a ser usado no arquivo local. Padrão é o nome original do objeto do Google Drive

    export_as
        Código para conversão do objeto. Para listar as conversões disponíveis, use o método get_conversion_codes. 
        Padrão para o formato padrão do mime type do objeto. Ignorado se o objeto não for um objeto do Google Docs.

    Escreve o conteúdo do arquivo do objeto do Google Drive e retorna o caminho completo do arquivo armazenado localmente.
    '''
    if not os.path.exists(path) or not os.path.isdir(path):
        raise Exception('Path doesn\'t exists or is not a folder.')

    if _is_googledoc_object(object):
        conversion = _get_conversion(object, conversion_code=export_as)
        name = name or object['name']
        fileExtension = conversion.conversion_file_extension \
            if conversion else 'FILE'
    else:
        name = ''.join(object['name'].split('.')[0:-1]) if '.' in object['name'] else object['name']
        fileExtension = object['name'].split('.')[-1] if '.' in object['name'] else object.get('fileExtension','FILE')

    file_path = os.path.sep.join([path, '.'.join([name, fileExtension])])

    data = get_object_bytes(object=object, export_as=export_as)

    with open(file_path, 'wb') as f:
        f.write(data)
        f.close()

    return file_path
