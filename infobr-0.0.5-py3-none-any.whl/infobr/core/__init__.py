'''
Core Package
Provides core modules, functions and classes for entire system.
'''
import os, sys
import traceback

from dotenv import load_dotenv

import connexion
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

# loading config parameters
load_dotenv()

# debug resources
def debug_info(x: Exception):
    '''
    Return extra exception/execution info for debug.
    '''
    try:
        info = traceback.format_exc()
    except Exception as e:
        info = "Unable to get debug info: {}".format(e)

    return info if settings['debug_info'] else x.__str__()

def debug(x):
    '''
    Decorator function to be used to debug execution of system functions.
    Prints all arguments used and the result value of the debugged functions.

    Use:

    @debug
    def myFunc(x, y, z)?
        pass

        x
            The function to be decorated

        Return function decorator
    '''

    def _debug(*args, **kwargs):
        result = x(*args, **kwargs)
        print(
            f"{x.__name__}(args: {args}, kwargs: {kwargs}) -> {result}"
        )
        return result

    return _debug

def debug_print(x):
    '''
    Prints x on standard out if DEBUG is turned ON.

    Use:
    '''
    if settings['debug_info']:
        print(x, file=sys.stdout)


# define global core settings
settings = {}

settings['environment'] = os.environ.get('FLASK_ENV', 'development') #or production
settings['debug_info'] = os.environ.get('INFOBR_DEBUG', 'FALSE') == 'TRUE'
settings['host_listen_address'] = os.environ.get('INFOBR_HOST_LISTEN_ADDRESS', '0.0.0.0')
settings['host_listen_port'] = os.environ.get('INFOBR_HOST_LISTEN_PORT', 5000)

settings['db_oracle_home'] = os.environ.get('INFOBR_ORACLE_HOME', None)
settings['db_oracle_tns_admin'] = os.environ.get('INFOBR_ORACLE_TNS_ADMIN', None)
settings['db_oracle_service_name'] = os.environ.get('INFOBR_ORACLE_SERVICE_NAME', None)
settings['db_oracle_user_name'] = os.environ.get('INFOBR_ORACLE_USER_NAME', None)
settings['db_oracle_user_password'] = os.environ.get('INFOBR_ORACLE_USER_PASSWORD', None)

# build global core objects
application = {
    "application": {
        "name": "InfoBR - Informações Financeiras do Mercado Brasileiro",
        "initials": "INFOBR",
        "version": "0.0.5",
        "copyright": {
            "year": 2021,
            "owner": "Ackertime Serviços em Informática"
        }
    }
}

# build core app object

connex_app = connexion.App(__name__)

app = connex_app.app

# build SQLAlchemy support

os.environ['ORACLE_HOME'] = settings['db_oracle_home']
os.environ['TNS_ADMIN'] = settings['db_oracle_tns_admin']

# Configure the SqlAlchemy part of the app instance
app.config["SQLALCHEMY_ECHO"] = settings['debug_info'] or False
app.config["SQLALCHEMY_DATABASE_URI"] = 'oracle://{user}:{password}@{service}'.format(
        user=settings['db_oracle_user_name'],
        password=settings['db_oracle_user_password'],
        service=settings['db_oracle_service_name'])
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    'max_identifier_length': 30
}

# Create the SqlAlchemy db instance
db = SQLAlchemy(app)

# Initialize Marshmallow
ma = Marshmallow(app)