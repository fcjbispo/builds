"""API dependency helpers."""

