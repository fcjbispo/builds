"""WEB-040: integration tests for auth/password endpoints."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin, require_user
from infobr.api.main import app
from infobr.api.routers import auth


def test_login_endpoint_handles_invalid_and_locked(monkeypatch):
    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class FakeCredRepo:
        def __init__(self, _session):
            pass

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

    monkeypatch.setattr(auth, "session_scope", fake_session_scope)
    monkeypatch.setattr(auth, "AppCredentialRepository", FakeCredRepo)
    monkeypatch.setattr(auth, "TokenRepository", FakeTokenRepo)

    client = TestClient(app)

    monkeypatch.setattr(
        auth.PasswordService,
        "login",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("Invalid credentials")),
    )
    invalid_resp = client.post(
        "/api/v1/auth/login",
        json={"email": "user@example.com", "password": "wrong"},
    )
    assert invalid_resp.status_code == 401
    assert "Invalid credentials" in invalid_resp.json()["details"]

    monkeypatch.setattr(
        auth.PasswordService,
        "login",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(PermissionError("locked")),
    )
    locked_resp = client.post(
        "/api/v1/auth/login",
        json={"email": "user@example.com", "password": "wrong"},
    )
    assert locked_resp.status_code == 403
    assert "locked" in locked_resp.json()["details"]


def test_password_endpoints_return_standard_errors(monkeypatch):
    app.dependency_overrides[require_admin] = lambda: SimpleNamespace(
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="admintok",
        id="admin-token-id",
    )
    app.dependency_overrides[require_user] = lambda: SimpleNamespace(
        email="user@example.com",
        profile="USER",
        token_prefix="usertok",
        id="user-token-id",
    )

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class FakeCredRepo:
        def __init__(self, _session):
            pass

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

        def revoke(self, _token_id):
            return True

    cred = SimpleNamespace(
        id="cred1",
        email="user@example.com",
        profile="USER",
        is_active=True,
        expires_at=datetime.now(timezone.utc),
    )

    monkeypatch.setattr(auth, "session_scope", fake_session_scope)
    monkeypatch.setattr(auth, "AppCredentialRepository", FakeCredRepo)
    monkeypatch.setattr(auth, "TokenRepository", FakeTokenRepo)
    monkeypatch.setattr(auth.PasswordService, "set_password", lambda *_args, **_kwargs: cred)
    monkeypatch.setattr(
        auth.PasswordService,
        "change_password",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("bad current password")),
    )
    monkeypatch.setattr(
        auth.PasswordService,
        "reset_password",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("credential not found")),
    )

    client = TestClient(app)

    set_resp = client.post(
        "/api/v1/auth/password/set",
        json={"email": "user@example.com", "profile": "USER", "password": "User1234"},
    )
    assert set_resp.status_code == 200

    change_resp = client.post(
        "/api/v1/auth/password/change",
        json={"current_password": "bad", "new_password": "New12345"},
    )
    assert change_resp.status_code == 422
    assert "bad current password" in change_resp.json()["details"]

    reset_resp = client.post(
        "/api/v1/auth/password/reset",
        json={"email": "user@example.com", "new_password": "Reset1234"},
    )
    assert reset_resp.status_code == 422
    assert "credential not found" in reset_resp.json()["details"]

    app.dependency_overrides.clear()

