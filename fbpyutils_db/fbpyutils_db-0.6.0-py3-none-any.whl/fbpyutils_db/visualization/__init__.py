"""Data visualization utilities for console output.

This module provides functions for creating and displaying ASCII tables
from data structures. These utilities are useful for debugging, logging,
and displaying tabular data in terminal environments.

Functions
---------
ascii_table
    Create an ASCII table representation from data.
print_ascii_table
    Print an ASCII table directly to console.
print_ascii_table_from_dataframe
    Convert and print a pandas DataFrame as an ASCII table.
print_columns
    Print formatted column names with optional normalization.

Examples
--------
Create an ASCII table:

>>> from fbpyutils_db.visualization.ascii_table import ascii_table
>>> data = [['John', 25, 'USA'], ['Alice', 30, 'Canada']]
>>> columns = ['Name', 'Age', 'Country']
>>> table = ascii_table(data, columns=columns, alignment='center')
>>> for line in table:
...     print(line)
+-------+-----+---------+
|  Name | Age | Country |
+-------+-----+---------+
|  John |  25 |   USA   |
| Alice |  30 |  Canada |
+-------+-----+---------+

Print DataFrame as ASCII table:

>>> from fbpyutils_db.visualization.display import print_ascii_table_from_dataframe
>>> import pandas as pd
>>> df = pd.DataFrame({'Name': ['John', 'Alice'], 'Age': [25, 30]})
>>> print_ascii_table_from_dataframe(df, alignment='left')
+------+-----+
| Name | Age |
+------+-----+
| John |  25 |
| Alice|  30 |
+------+-----+

Print formatted columns:

>>> from fbpyutils_db.visualization.display import print_columns
>>> cols = ['Name', 'Age', 'Address']
>>> print_columns(cols, normalize=True, length=10, quotes=True)
'name     ', 'age      ', 'address  '

Notes
-----
- ASCII tables support left, right, and center alignment
- Column widths are automatically calculated based on content
- Empty data returns None for ascii_table function
- DataFrame conversion handles index inclusion optionally

See Also
--------
tabulate : Third-party library for table formatting
pandas.DataFrame : Primary data structure for tabular data
"""