import pandas as pd
from typing import List

from fbpyutils_db import logger


def _check_columns(df: pd.DataFrame, columns: List[str]) -> bool:
    """Check if all specified columns exist in the DataFrame.

    This function validates that all column names in the provided list are
    present in the DataFrame's columns. It logs a warning if any columns
    are missing.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to check column existence in.
    columns : list of str
        A list of column names to check for existence.

    Returns
    -------
    bool
        True if all columns exist, False otherwise.

    Examples
    --------
    Check existing columns:

    >>> import pandas as pd
    >>> from fbpyutils_db.utils.validators import _check_columns
    >>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
    >>> _check_columns(df, ['A', 'B'])
    True

    Check with missing columns:

    >>> _check_columns(df, ['A', 'C'])
    False

    Check single column:

    >>> _check_columns(df, ['A'])
    True

    Notes
    -----
    - This function logs debug information about the validation process
    - A warning is logged if any columns are not found
    - The function is case-sensitive for column names
    - Empty column list returns True

    See Also
    --------
    pandas.DataFrame.columns : DataFrame column labels
    """
    logger.debug(
        "Checking column existence in DataFrame",
        extra={
            "operation": "column_validation",
            "requested_columns": columns,
            "available_columns": list(df.columns),
        },
    )

    result = all(c in df.columns for c in columns)

    if not result:
        missing_columns = [c for c in columns if c not in df.columns]
        logger.warning(
            "Column validation failed: some columns not found in DataFrame",
            extra={
                "operation": "column_validation",
                "missing_columns": missing_columns,
                "available_columns": list(df.columns),
            },
        )

    return result
