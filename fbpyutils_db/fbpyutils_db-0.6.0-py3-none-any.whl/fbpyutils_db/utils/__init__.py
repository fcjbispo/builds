"""Utility functions for data validation and NaN handling.

This module provides internal utility functions used across the fbpyutils_db
package for data validation, NaN value handling, and column checking.

Functions
---------
_deal_with_nans
    Handle NaN, None, and empty string values in data processing.
_check_columns
    Validate that specified columns exist in a DataFrame.

Examples
--------
Handle NaN values:

>>> from fbpyutils_db.utils.nan_handler import _deal_with_nans
>>> import pandas as pd
>>> import numpy as np
>>>
>>> result = _deal_with_nans(np.nan)
>>> print(result)
None
>>> result = _deal_with_nans("valid value")
>>> print(result)
valid value

Check column existence:

>>> from fbpyutils_db.utils.validators import _check_columns
>>> import pandas as pd
>>>
>>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
>>> _check_columns(df, ['A', 'B'])
True
>>> _check_columns(df, ['A', 'C'])
False

Notes
-----
- These are internal utility functions (prefixed with underscore)
- NaN handling supports pandas, numpy, and Python native types
- Column validation is case-sensitive

See Also
--------
pandas.isna : Check for missing values in pandas
numpy.isnan : Check for NaN values in numpy arrays
"""