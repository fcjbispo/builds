import pandas as pd
import numpy as np
from datetime import datetime, date
from typing import Any, Optional

from fbpyutils_db import logger


def _deal_with_nans(x: Any, debug: Optional[bool] = False) -> Any:
    """Handle null values and special data types.

    This function checks if the input is a NaN value, None, an empty string,
    or a datetime/date with a NaT (Not a Time) value, and returns None for
    these cases. For numeric types like float, it checks if the value is NaN.
    For datetime/date types, it checks if the value is NaT. For all other
    types, the input is returned unchanged.

    Parameters
    ----------
    x : any
        The input variable that may contain null values or special cases
        that need to be handled.
    debug : bool, optional
        Enable debug logging for NaN detection. Default is False to avoid
        performance impact in hot paths.

    Returns
    -------
    any
        Returns `None` if the input is NaN, None, an empty string,
        a datetime with NaT, or a date with NaT. Otherwise, returns the
        original input value.

    Examples
    --------
    Handle various null-like values:

    >>> from fbpyutils_db.utils.nan_handler import _deal_with_nans
    >>> import pandas as pd
    >>> import numpy as np
    >>> _deal_with_nans(None)
    >>> _deal_with_nans('')
    >>> _deal_with_nans(np.nan)
    >>> _deal_with_nans(pd.NaT)

    Handle valid values:

    >>> _deal_with_nans('hello')
    'hello'
    >>> _deal_with_nans(42)
    42
    >>> _deal_with_nans(3.14)
    3.14

    Notes
    -----
    - Uses pandas `isna()` for general NaN detection
    - Uses numpy `isnan()` for float-specific NaN detection
    - Empty strings are treated as null values
    - NaT (Not a Time) values for datetime/date are converted to None
    - Debug logging is disabled by default for performance

    See Also
    --------
    pandas.isna : Check for missing values
    numpy.isnan : Check for NaN in numeric arrays
    """
    if pd.isna(x) or x is None or (isinstance(x, str) and not x):
        if debug:
            logger.debug(
                "NaN detected: general null value",
                extra={
                    "operation": "nan_handling",
                    "value_type": type(x).__name__,
                    "detection": "pd.isna or None or empty_string",
                },
            )
        return None
    elif isinstance(x, (float, np.float64)) and np.isnan(x):
        if debug:
            logger.debug(
                "NaN detected: float NaN",
                extra={
                    "operation": "nan_handling",
                    "value_type": type(x).__name__,
                    "detection": "np.isnan",
                },
            )
        return None
    elif isinstance(x, (datetime, pd.Timestamp)) and pd.isna(x):
        if debug:
            logger.debug(
                "NaN detected: datetime NaT",
                extra={
                    "operation": "nan_handling",
                    "value_type": type(x).__name__,
                    "detection": "pd.isna for datetime",
                },
            )
        return None
    elif isinstance(x, date) and pd.isna(pd.Timestamp(x)):
        if debug:
            logger.debug(
                "NaN detected: date NaT",
                extra={
                    "operation": "nan_handling",
                    "value_type": type(x).__name__,
                    "detection": "pd.isna for date",
                },
            )
        return None
    return x
