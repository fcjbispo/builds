"""Hashing utilities for data processing.

This module provides functions for generating hash values from DataFrame columns
and creating hash-based indices. Hashing is useful for creating unique identifiers,
deduplication, and data integrity verification.

The module uses MD5 hashing algorithm to generate fixed-length hash strings
from column values or combinations of columns.

Functions
---------
add_hash_column
    Add a hash column to a DataFrame based on specified columns.
add_hash_index
    Replace DataFrame index with a hash string generated from row values.

Examples
--------
Add a hash column to a DataFrame:

>>> import pandas as pd
>>> from fbpyutils_db.hashing import add_hash_column
>>>
>>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30]})
>>> df_hashed = add_hash_column(df, 'hash_id', length=12)
>>> print(df_hashed)
    hash_id   name  age
0  8b9c45e2  Alice   25
1  3d4c4f4f    Bob   30

Create a hash-based index:

>>> from fbpyutils_db.hashing import add_hash_index
>>> df_indexed = add_hash_index(df, 'id', length=12)
>>> print(df_indexed)
            name  age
id
8b9c45e2  Alice   25
3d4c4f4f    Bob   30

Notes
-----
- Hash values are generated using MD5 algorithm
- NaN values are treated as empty strings during hash generation
- Hash length can be customized (default is 12 characters)
- For DataFrames, multiple columns can be combined for hash generation

See Also
--------
fbpyutils_db.database.index : Database index creation utilities
hashlib : Python's built-in hashlib module for cryptographic hashing
"""