from sqlalchemy import Index, Selectable
from typing import List

from fbpyutils_db import logger


def create_index(
    name: str, table: Selectable, keys: List[str], unique: bool = True
) -> Index:
    """Create an index on the specified keys for a given table.

    This function creates a SQLAlchemy Index object for the specified table
    and columns. The index can be configured as unique or non-unique.

    Parameters
    ----------
    name : str
        The name of the index to be created.
    table : sqlalchemy.sql.expression.Selectable
        The table on which to create the index.
    keys : list of str
        A list of column names that should be part of the index.
    unique : bool, optional
        Whether the index should enforce uniqueness. Default is True.

    Returns
    -------
    sqlalchemy.Index
        The created Index object.

    Raises
    ------
    ValueError
        If no matching columns are found for the specified keys.

    Examples
    --------
    Create a unique index:

    >>> from sqlalchemy import Table, Column, Integer, String, MetaData
    >>> from fbpyutils_db.database.index import create_index
    >>> metadata = MetaData()
    >>> table = Table('users', metadata,
    ...               Column('id', Integer),
    ...               Column('email', String))
    >>> idx = create_index('idx_users_email', table, ['email'], unique=True)
    >>> idx.name
    'idx_users_email'

    Create a non-unique index:

    >>> idx = create_index('idx_users_name', table, ['name'], unique=False)

    Notes
    -----
    - The function searches for columns in the table that match the keys
    - If no matching columns are found, a ValueError is raised
    - The index is not created in the database until the table is created
    - Use this function with `create_table` to add indexes during table creation

    See Also
    --------
    create_table : Create a table with optional indexes
    sqlalchemy.Index : SQLAlchemy Index class
    """
    logger.debug(f"Creating index '{name}' on columns: {keys}, unique: {unique}")

    index_cols = [c for c in table.columns if c.name in keys]
    if not index_cols:
        logger.warning(f"No columns found for index '{name}' with keys: {keys}")
        raise ValueError(f"No matching columns found for keys: {keys}")

    index_obj = Index(name, *index_cols, unique=unique)
    logger.debug(f"Index '{name}' created successfully with {len(index_cols)} columns")

    return index_obj
