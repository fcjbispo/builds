from sqlalchemy.engine import Engine
from typing import Any, Dict

from fbpyutils_db import logger


def get_oracle_dialect_specific_query(query_name: str, **kwargs: Any) -> str:
    """Return Oracle-specific SQL queries based on the query name.

    This function retrieves SQL query templates optimized for Oracle
    database operations. The queries support various operations including
    upsert, append, batch operations, and table management.

    Parameters
    ----------
    query_name : str
        The name of the query to retrieve. Valid values include:
        'upsert', 'append', 'batch_append', 'batch_check', 'drop'.
    **kwargs : Any
        Arbitrary keyword arguments for query formatting. Common keys
        include target_table, columns, values, on_conditions, updates, etc.

    Returns
    -------
    str
        The Oracle-specific SQL query, formatted with provided kwargs.

    Raises
    ------
    KeyError
        If an unknown query name is provided.

    Examples
    --------
    Get an upsert query template:

    >>> from fbpyutils_db.database.dialects.oracle import get_oracle_dialect_specific_query
    >>> query = get_oracle_dialect_specific_query('upsert')
    >>> 'MERGE INTO' in query
    True

    Get a formatted query:

    >>> query = get_oracle_dialect_specific_query(
    ...     'append',
    ...     target_table='users',
    ...     columns='name, age',
    ...     values="'Alice', 25"
    ... )
    >>> 'users' in query
    True

    Notes
    -----
    - Oracle uses MERGE statement for upsert operations
    - FULL OUTER JOIN is used for batch check operations
    - The function returns unformatted templates when no kwargs are provided
    - All queries are optimized for Oracle syntax and features

    See Also
    --------
    is_oracle : Check if engine is Oracle
    get_postgresql_dialect_specific_query : PostgreSQL-specific queries
    get_sqlite_dialect_specific_query : SQLite-specific queries
    """
    logger.debug(
        f"Getting Oracle dialect specific query for '{query_name}' with kwargs: {kwargs}"
    )
    queries = {
        "upsert": """
            MERGE INTO {target_table} target
            USING (SELECT {values_select} FROM DUAL) source
            ON ({on_conditions})
            WHEN MATCHED THEN UPDATE SET {updates}
            WHEN NOT MATCHED THEN INSERT ({columns}) VALUES ({values})
        """,
        "append": "INSERT INTO {target_table} ({columns}) VALUES ({values})",
        "batch_append": """INSERT INTO {target_table} ({table_columns})
            SELECT {table_columns} FROM {session_table} s
            WHERE NOT EXISTS (SELECT 1 FROM {target_table} t WHERE {matching_conditions})""",
        "batch_check": """SELECT 
            COUNT(CASE WHEN s.id IS NOT NULL AND t.id IS NULL THEN 1 END) as {column_1},
            COUNT(CASE WHEN s.id IS NOT NULL AND t.id IS NOT NULL THEN 1 END) as {column_2},
            COUNT(CASE WHEN s.id IS NULL AND t.id IS NOT NULL THEN 1 END) as {column_3}
            FROM {session_table} s
            FULL OUTER JOIN {target_table} t ON {keys}""",
        "drop": "DROP TABLE {target_table}",
    }
    query = queries.get(query_name)
    if not query:
        logger.error(f"Unknown Oracle query name: {query_name}")
        raise KeyError(f"Unknown query name: {query_name}")
    logger.debug(f"Returning Oracle query for '{query_name}'")

    # Only format if kwargs are provided
    if kwargs:
        return query.format(**kwargs)
    else:
        return query.strip()


def is_oracle(engine: Engine) -> bool:
    """Check if the given SQLAlchemy engine is for Oracle.

    This function determines whether the provided SQLAlchemy engine
    is connected to an Oracle database by checking the engine's
    dialect name.

    Parameters
    ----------
    engine : sqlalchemy.engine.Engine
        The SQLAlchemy engine to check.

    Returns
    -------
    bool
        True if the engine is for Oracle, False otherwise.

    Examples
    --------
    Check if engine is Oracle:

    >>> from sqlalchemy import create_engine
    >>> from fbpyutils_db.database.dialects.oracle import is_oracle
    >>> engine = create_engine('oracle+oracledb://user:pass@localhost/db')
    >>> is_oracle(engine)
    True

    Check with SQLite engine:

    >>> engine = create_engine('sqlite:///:memory:')
    >>> is_oracle(engine)
    False

    Notes
    -----
    - This function checks the `engine.name` attribute
    - It is a simple string comparison, not a connection test
    - Use this for conditional logic based on database type

    See Also
    --------
    is_postgresql : Check if engine is PostgreSQL
    is_sqlite : Check if engine is SQLite
    """
    return engine.name == "oracle"
