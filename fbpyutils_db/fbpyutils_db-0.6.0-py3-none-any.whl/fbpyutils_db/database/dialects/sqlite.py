from sqlalchemy.engine import Engine
from typing import Any, Dict

from fbpyutils_db import logger


def get_sqlite_dialect_specific_query(query_name: str, **kwargs: Any) -> str:
    """Return SQLite-specific SQL queries based on the query name.

    This function retrieves SQL query templates optimized for SQLite
    database operations. The queries support various operations including
    upsert, append, batch operations, and table management.

    Parameters
    ----------
    query_name : str
        The name of the query to retrieve. Valid values include:
        'upsert', 'append', 'batch_append', 'batch_check', 'drop'.
    **kwargs : Any
        Arbitrary keyword arguments for query formatting. Common keys
        include table_name, columns, values, keys, updates, etc.

    Returns
    -------
    str
        The SQLite-specific SQL query, formatted with provided kwargs.

    Raises
    ------
    KeyError
        If an unknown query name is provided.

    Examples
    --------
    Get an upsert query template:

    >>> from fbpyutils_db.database.dialects.sqlite import get_sqlite_dialect_specific_query
    >>> query = get_sqlite_dialect_specific_query('upsert')
    >>> 'INSERT INTO' in query
    True

    Get a formatted query:

    >>> query = get_sqlite_dialect_specific_query(
    ...     'append',
    ...     table_name='users',
    ...     columns='name, age',
    ...     values="'Alice', 25"
    ... )
    >>> 'users' in query
    True

    Notes
    -----
    - SQLite uses ON CONFLICT for upsert operations (UPSERT support added in 3.24.0)
    - Simple INSERT SELECT is used for batch append operations
    - The function returns unformatted templates when no kwargs are provided
    - All queries are optimized for SQLite syntax and features

    See Also
    --------
    is_sqlite : Check if engine is SQLite
    get_postgresql_dialect_specific_query : PostgreSQL-specific queries
    get_oracle_dialect_specific_query : Oracle-specific queries
    """
    logger.debug(
        f"Getting SQLite dialect specific query for '{query_name}' with kwargs: {kwargs}"
    )
    queries = {
        "upsert": """
            INSERT INTO {table_name} ({columns})
            VALUES ({values})
            ON CONFLICT({keys}) DO UPDATE SET {updates}
        """,
        "append": "INSERT INTO {table_name} ({columns}) VALUES ({values})",
        "batch_append": "INSERT INTO {target_table} ({table_columns}) SELECT {table_columns} FROM {session_table}",
        "batch_check": "SELECT COUNT(*) FROM {session_table} s WHERE NOT EXISTS (SELECT 1 FROM {table_name} t WHERE {matching_conditions})",
        "drop": "DROP TABLE IF EXISTS {table_name}",
    }
    query = queries.get(query_name)
    if not query:
        logger.error(f"Unknown SQLite query name: {query_name}")
        raise KeyError(f"Unknown query name: {query_name}")
    logger.debug(f"Returning SQLite query for '{query_name}'")

    # Only format if kwargs are provided
    if kwargs:
        return query.format(**kwargs)
    else:
        return query.strip()


def is_sqlite(engine: Engine) -> bool:
    """Check if the given SQLAlchemy engine is for SQLite.

    This function determines whether the provided SQLAlchemy engine
    is connected to a SQLite database by checking the engine's
    dialect name.

    Parameters
    ----------
    engine : sqlalchemy.engine.Engine
        The SQLAlchemy engine to check.

    Returns
    -------
    bool
        True if the engine is for SQLite, False otherwise.

    Examples
    --------
    Check if engine is SQLite:

    >>> from sqlalchemy import create_engine
    >>> from fbpyutils_db.database.dialects.sqlite import is_sqlite
    >>> engine = create_engine('sqlite:///:memory:')
    >>> is_sqlite(engine)
    True

    Check with PostgreSQL engine:

    >>> engine = create_engine('postgresql://user:pass@localhost/db')
    >>> is_sqlite(engine)
    False

    Notes
    -----
    - This function checks the `engine.name` attribute
    - It is a simple string comparison, not a connection test
    - Use this for conditional logic based on database type

    See Also
    --------
    is_postgresql : Check if engine is PostgreSQL
    is_oracle : Check if engine is Oracle
    """
    return engine.name == "sqlite"
