import pandas as pd
import polars as pl
from sqlalchemy import Engine, MetaData, Table, text, inspect
from sqlalchemy.sql import exists
from typing import Any, Dict, List, Tuple
from pandas.core.frame import DataFrame

from fbpyutils.uuid import uuid
from fbpyutils_db import logger

# Importa funções de outros módulos
from fbpyutils_db.utils.nan_handler import _deal_with_nans
from fbpyutils_db.database.table import create_table
from fbpyutils_db.database.dialects import get_dialect_specific_query


def table_operation(
    operation: str,
    dataframe: pd.DataFrame,
    engine: Engine,
    table_name: str,
    schema: str = None,
    keys: list[str] = None,
    index: str = None,
    commit_at: int = 50,
) -> Dict[str, Any]:
    """
    Perform upsert or replace operation on a table based on the provided dataframe.

    Args:
        operation (str, optional): The operation to be performed ('append', 'upsert' or 'replace').
        dataframe (pd.DataFrame): The pandas DataFrame containing the data to be inserted or updated.
        engine (sqlalchemy.engine.Engine): The SQLAlchemy engine engine.
        table_name (str): The name of the table to operate on.
        schema (str, optional): the schena name to preffix the table objects.
        keys (list of str, required for operation=upsert): List of column names to use as keys for upsert operation.
        index (str, optional): Whether to create an index and what kind using the keys. Default is None (not create index).
            If an index must be created, index be in 'standard' or 'unique'.
        commit_at (int, optional): Number of rows to commit in the database at once. Defaults to 50.
            Must be > 1 and < total rows of the dataframe.

    Returns:
        dict: A dictionary containing information about the performed operation.

    """
    logger.info(
        "Starting table operation",
        extra={
            "operation": "table_operation",
            "table_name": table_name,
            "schema": schema,
            "operation_type": operation,
            "total_rows": len(dataframe),
            "keys": keys,
            "index": index,
            "commit_at": commit_at,
        },
    )

    # Check parameters - Validate dataframe type first
    if not type(dataframe) == pd.DataFrame:
        logger.error(
            "Table operation failed: invalid DataFrame type",
            extra={
                "operation": "table_operation",
                "error_type": "invalid_dataframe",
                "provided_type": type(dataframe).__name__,
            },
        )
        raise ValueError("Dataframe must be a Pandas DataFrame.")

    # Check operation type
    if operation not in ("append", "upsert", "replace"):
        logger.error(
            "Table operation failed: invalid operation type",
            extra={
                "operation": "table_operation",
                "error_type": "invalid_operation",
                "provided_operation": operation,
            },
        )
        raise ValueError("Invalid operation. Valid values: append|upsert|replace.")

    # Check upsert requirements
    if operation == "upsert" and not keys:
        logger.error(
            "Table operation failed: missing keys parameter for upsert",
            extra={"operation": "table_operation", "error_type": "missing_keys"},
        )
        raise ValueError("keys parameter is mandatory")

    # Check keys type
    if keys and not type(keys) == list:
        logger.error(
            "Table operation failed: invalid keys type",
            extra={
                "operation": "table_operation",
                "error_type": "invalid_keys_type",
                "provided_type": type(keys).__name__,
            },
        )
        raise ValueError("keys must be a list")

    if (keys and index) and index not in ("standard", "unique", "primary"):
        logger.error(
            "Table operation failed: invalid index type",
            extra={
                "operation": "table_operation",
                "error_type": "invalid_index_type",
                "provided_index": index,
            },
        )
        raise ValueError(
            "If an index will be created, it must be any of standard|unique|primary."
        )

    # Validate commit_at parameter before any database operations
    # First check if commit_at is a valid integer and > 1
    if commit_at is not None and (not type(commit_at) == int or commit_at <= 1):
        logger.error(
            "Table operation failed: invalid commit_at parameter",
            extra={
                "operation": "table_operation",
                "error_type": "invalid_commit_at",
                "provided_value": commit_at,
            },
        )
        raise ValueError("Commit At must be > 1")

    # Set default value if None
    commit_at = commit_at or 50
    
    # Adjust commit_at if it's larger than dataframe length
    if commit_at > len(dataframe):
        commit_at = len(dataframe)
        logger.info(
            "Adjusted commit_at to match dataframe length",
            extra={
                "operation": "table_operation",
                "adjusted_commit_at": commit_at,
                "dataframe_length": len(dataframe),
            },
        )

    # Check if the table exists in the database, if not create it
    table_exists = inspect(engine).has_table(table_name, schema=schema)

    if not table_exists:
        logger.info(
            "Creating table as it doesn't exist",
            extra={
                "operation": "table_operation",
                "table_name": table_name,
                "schema": schema,
            },
        )
        create_table(dataframe, engine, table_name, schema, keys, index)

    # Get the table object
    metadata = MetaData(schema)
    table = Table(table_name, metadata, autoload_with=engine)

    # Initialize reports for insertions, updates, and failures
    inserts = 0
    updates = 0
    skips = 0
    failures = []

    try:
        with engine.connect() as conn:
            step = "drop table"
            if operation == "replace":
                logger.info(
                    "Performing replace operation - clearing table",
                    extra={
                        "operation": "table_operation",
                        "table_name": table_name,
                        "schema": schema,
                    },
                )
                conn.execute(table.delete())
                conn.commit()

            rows = 0
            processed_rows = 0

            for i, row in dataframe.iterrows():
                try:
                    values = {
                        col: _deal_with_nans(row[col]) for col in dataframe.columns
                    }

                    row_exists = False
                    step = "check existence"
                    if keys:
                        # Check if row exists in the table based on keys
                        exists_query = (
                            table.select()
                            .where(
                                exists(
                                    table.select().where(
                                        text(
                                            " AND ".join(
                                                [f"{col} = :{col}" for col in keys]
                                            )
                                        )
                                    )
                                )
                            )
                            .params(**values)
                        )
                        if conn.execute(exists_query).fetchone():
                            row_exists = True

                    if row_exists:
                        if operation == "upsert":
                            # Perform update
                            step = "replace with update"
                            update_values = {
                                k: values[k] for k in values.keys() if k not in keys
                            }

                            update_stmt = (
                                table.update()
                                .where(
                                    text(
                                        " AND ".join([f"{col}=:{col}" for col in keys])
                                    )
                                )
                                .values(**update_values)
                            )

                            update_stmt = text(str(update_stmt))
                            conn.execute(update_stmt, values)
                            updates += 1
                        else:
                            skips += 1
                    else:
                        # Perform insert
                        step = "perform insert"
                        insert_stmt = table.insert().values(**values)
                        conn.execute(insert_stmt)
                        inserts += 1

                    rows += 1
                    processed_rows += 1

                    if rows >= commit_at:
                        conn.commit()
                        rows = 0

                    if processed_rows % 100 == 0:
                        logger.info(
                            "Processing progress",
                            extra={
                                "operation": "table_operation",
                                "table_name": table_name,
                                "processed": processed_rows,
                                "total": len(dataframe),
                                "progress_percent": round((processed_rows / len(dataframe)) * 100, 1),
                            },
                        )

                except Exception as e:
                    logger.error(
                        "Error processing row",
                        extra={
                            "operation": "table_operation",
                            "table_name": table_name,
                            "row_index": i,
                            "step": step,
                            "error": str(e),
                            "error_type": type(e).__name__,
                        },
                    )
                    failures.append(
                        {
                            "step": step,
                            "row": (
                                i,
                                ", ".join(
                                    [f"{k}='{str(v)}'" for k, v in values.items()]
                                ),
                            ),
                            "error": str(e),
                        }
                    )
                    conn.rollback()
                    continue
            conn.commit()
    except Exception as e:
        logger.error(
            "Critical error in table operation",
            extra={
                "operation": "table_operation",
                "table_name": table_name,
                "schema": schema,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        conn.rollback()
        failures.append({"step": step, "row": None, "error": str(e)})

    result = {
        "operation": operation,
        "table_name": f"{schema}.{table_name}" if schema else table_name,
        "insertions": inserts,
        "updates": updates,
        "skips": skips,
        "failures": failures,
    }

    logger.info(
        "Table operation completed",
        extra={
            "operation": "table_operation",
            "table_name": table_name,
            "schema": schema,
            "operation_type": operation,
            "total_processed": processed_rows,
            "insertions": inserts,
            "updates": updates,
            "skips": skips,
            "failures": len(failures),
        },
    )

    if failures:
        logger.warning(
            "Operation completed with failures",
            extra={
                "operation": "table_operation",
                "table_name": table_name,
                "failure_count": len(failures),
            },
        )
        for failure in failures[:5]:  # Log first 5 failures
            logger.warning(
                "Row processing failure",
                extra={
                    "operation": "table_operation",
                    "failure_details": failure,
                },
            )

    return result


def get_batch_query(operation: str, engine_name: str) -> str:
    """Get a batch query for a specific operation and database engine.

    This function retrieves dialect-specific SQL queries for batch operations
    on different database engines. It supports PostgreSQL, Oracle, and SQLite.

    Parameters
    ----------
    operation : str
        The operation type to retrieve the query for.
        Valid values: 'append', 'upsert', 'check', 'drop'.
    engine_name : str
        The database engine name.
        Valid values: 'postgresql', 'oracle', 'sqlite'.

    Returns
    -------
    str
        The formatted SQL query string for the specified operation and engine.

    Raises
    ------
    KeyError
        If the engine_name is not supported or the operation is unknown.

    Examples
    --------
    Get batch append query for PostgreSQL:

    >>> query = get_batch_query('append', 'postgresql')
    >>> print(query[:50])
    INSERT INTO {table_name} ({columns}) VALUES ({values})

    Get batch upsert query for SQLite:

    >>> query = get_batch_query('upsert', 'sqlite')
    >>> print(query[:50])
    INSERT INTO {table_name} ({columns}) VALUES ({values})

    Notes
    -----
    - This function uses a mock engine object to query dialect-specific templates
    - The returned query contains placeholders that need to be replaced with actual values
    - Supported operations: append, upsert, check, drop
    - Supported engines: postgresql, oracle, sqlite

    See Also
    --------
    batch_table_operation : Perform batch operations using these queries
    get_dialect_specific_query : Get dialect-specific query templates
    """

    # Create a mock engine object based on the engine name
    class MockEngine:
        def __init__(self, name):
            self.name = name

    mock_engine = MockEngine(engine_name)

    # Define the queries structure
    query_map = {
        "postgresql": {
            "append": lambda: get_dialect_specific_query(mock_engine, "batch_append"),
            "upsert": lambda: get_dialect_specific_query(mock_engine, "upsert"),
            "check": lambda: get_dialect_specific_query(mock_engine, "batch_check"),
            "drop": lambda: get_dialect_specific_query(mock_engine, "drop"),
        },
        "oracle": {
            "append": lambda: get_dialect_specific_query(mock_engine, "batch_append"),
            "upsert": lambda: get_dialect_specific_query(mock_engine, "upsert"),
            "check": lambda: get_dialect_specific_query(mock_engine, "batch_check"),
            "drop": lambda: get_dialect_specific_query(mock_engine, "drop"),
        },
        "sqlite": {
            "append": lambda: get_dialect_specific_query(mock_engine, "batch_append"),
            "upsert": lambda: get_dialect_specific_query(mock_engine, "upsert"),
            "check": lambda: get_dialect_specific_query(mock_engine, "batch_check"),
            "drop": lambda: get_dialect_specific_query(mock_engine, "drop"),
        },
    }

    if engine_name not in query_map:
        raise KeyError(f"Unknown engine name: {engine_name}")

    if operation not in query_map[engine_name]:
        raise KeyError(f"Unknown operation: {operation}")

    return query_map[engine_name][operation]()


def batch_table_operation(
    operation: str,
    dataframe: DataFrame,
    engine: Engine,
    schema: str,
    table_name: str,
    table_schema: Tuple[Tuple[str, str, str, str, bool], ...],
    table_keys: List[str],
    commit_at: int = 50,
) -> Dict[str, Any]:
    """Perform batch database operations using temporary tables.

    This function executes batch operations (append, upsert) by creating a
    temporary session table, loading data into it, and then performing
    the operation using SQL queries. This approach is more efficient for
    large datasets than row-by-row operations.

    Parameters
    ----------
    operation : str
        The operation type to perform. Valid values: 'append', 'upsert'.
    dataframe : pandas.DataFrame
        The DataFrame containing the data to be processed.
    engine : sqlalchemy.engine.Engine
        The SQLAlchemy engine for database connection.
    schema : str
        The schema name for the target table.
    table_name : str
        The name of the target table.
    table_schema : tuple of tuple
        Schema definition tuples for the table. Each tuple contains:
        (schema_name, table_name, field_name, field_type, is_key).
    table_keys : list of str
        List of column names to use as keys for matching/updating.
    commit_at : int, optional
        Number of rows to commit at once during batch insert. By default 50.

    Returns
    -------
    dict
        A dictionary containing operation results with keys:
        - 'operation': The operation type performed
        - 'table_name': The fully qualified table name
        - 'insertions': Number of rows inserted
        - 'updates': Number of rows updated
        - 'skips': Number of rows skipped
        - 'failures': List of failure details

    Examples
    --------
    Perform batch upsert operation:

    >>> from fbpyutils_db.database.operations import batch_table_operation
    >>> import pandas as pd
    >>> from sqlalchemy import create_engine
    >>>
    >>> engine = create_engine("postgresql://user:pass@localhost/db")
    >>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
    >>> table_schema = (('schema', 'users', 'id', 'int64', True),
    ...                ('schema', 'users', 'name', 'object', False))
    >>> result = batch_table_operation(
    ...     'upsert', df, engine, 'public', 'users',
    ...     table_schema, ['id']
    ... )
    >>> print(result['insertions'])
    2

    Notes
    -----
    - Creates a temporary session table with a unique name
    - Uses polars for efficient database reading of check queries
    - Automatically drops the temporary table after operation
    - Progress is logged at various stages of the operation
    - Failed rows are logged but do not stop the entire operation

    Performance Considerations
    --------------------------
    - Batch operations are significantly faster than row-by-row operations
    - The commit_at parameter controls batch size for initial data load
    - Temporary tables are automatically cleaned up in the finally block

    See Also
    --------
    table_operation : Row-by-row table operations
    get_batch_query : Get batch query templates
    """
    failures = []
    pre_checks = {}
    pos_checks = {}

    op_result = {
        "operation": operation,
        "table_name": f"{schema}.{table_name}" if schema else table_name,
        "insertions": 0,
        "updates": 0,
        "skips": 0,
        "failures": failures,
    }

    try:
        table_keys = table_keys or [c[2] for c in table_schema if c[4]]

        batch_id = uuid()
        batch_table = f"batch_{table_name}_{batch_id}".replace("-", "_")

        logger.info(
            f"Starting session table operation '{operation}' on table '{table_name}' with session table '{batch_table}'"
        )
        _ = dataframe.to_sql(
            schema=schema,
            name=batch_table,
            con=engine,
            if_exists="replace",
            index=False,
            method="multi",
            chunksize=commit_at,
        )
        logger.info(
            f"Inserted {len(dataframe)} rows into session table '{batch_table}'"
        )

        try:
            query = get_batch_query(operation, engine.name)
            query = (
                query.replace(
                    "{table_name}", f"{schema}.{table_name}" if schema else table_name
                )
                .replace(
                    "{session_table}",
                    f"{schema}.{batch_table}" if schema else batch_table,
                )
                .replace("{columns}", ", ".join(dataframe.columns))
                .replace(
                    "{matching_conditions}",
                    " AND ".join([f"t.{k}=s.{k}" for k in table_keys]),
                )
                .replace(
                    "{updates}",
                    ", ".join(
                        [
                            f"t.{col}=s.{col}"
                            for col in dataframe.columns
                            if col not in table_keys
                        ]
                    ),
                )
                .replace(
                    "{values}",
                    ", ".join([f"s.{col}" for col in dataframe.columns]),
                )
                .replace("{key_columns}", ", ".join([f"{k}" for k in table_keys]))
            )
            logger.info(f"Prepared {operation} query for table '{table_name}': {query}")

            if operation == "append":
                C1 = "inserts"
                C2 = "skips"
                C3 = "updates"
            elif operation == "upsert":
                C1 = "inserts"
                C2 = "updates"
                C3 = "skips"
            else:
                C1 = "inserts"
                C2 = "updates"
                C3 = "skips"

            check_sql = (
                get_batch_query("check", engine.name)
                .replace(
                    "{table_name}", f"{schema}.{table_name}" if schema else table_name
                )
                .replace(
                    "{session_table}",
                    f"{schema}.{batch_table}" if schema else batch_table,
                )
                .replace("{keys}", ", ".join(table_keys))
                .replace("{column_1}", C1)
                .replace("{column_2}", C2)
                .replace("{column_3}", C3)
            )
            logger.info(
                f"Prepared pre/post check query for table '{table_name}': {check_sql}"
            )

            pre_checks = (
                pl.read_database(check_sql, connection=engine)
                .to_pandas()
                .to_dict(orient="records")[0]
            )
            logger.info(f"Pre-operation checks: {pre_checks}")

            with engine.begin() as conn:
                result = conn.execute(text(query))
                check_result = (
                    pl.read_database(check_sql, connection=conn)
                    .to_pandas()
                    .to_dict(orient="records")
                )
                pos_checks = check_result[0] if check_result else {}
                logger.info(f"Post-operation checks: {pos_checks}")
                logger.info(
                    f"Operation {operation} completed successfully. Result: {result}"
                )
        except Exception as e:
            failures.append({"step": operation, "row": query, "error": str(e)})
            logger.error(f"Operation {operation} failed. Error: {e}")
            logger.info(f"SQL: {query}")
        finally:
            drop_sql = get_batch_query("drop", engine.name).replace(
                "{session_table}",
                f"{schema}.{batch_table}" if schema else batch_table,
            )
            logger.info(f"Dropping session table with query: {drop_sql}")
            with engine.connect() as conn:
                conn.execute(text(drop_sql))
                conn.commit()
            logger.info(
                f"Dropped session table {batch_table} skipped (for debugging purposes)."
            )
    except Exception as e:
        failures.append({"step": "batch_setup", "row": None, "error": str(e)})
        logger.critical(f"Batch table operation setup failed. Error: {e}")

    op_result = {
        "operation": operation,
        "table_name": f"{schema}.{table_name}" if schema else table_name,
        "insertions": max([pos_checks.get("inserts", 0), pre_checks.get("inserts", 0)]),
        "updates": max([pos_checks.get("updates", 0), pre_checks.get("updates", 0)]),
        "skips": max([pos_checks.get("skips", 0), pre_checks.get("skips", 0)]),
        "failures": failures,
    }

    return op_result
