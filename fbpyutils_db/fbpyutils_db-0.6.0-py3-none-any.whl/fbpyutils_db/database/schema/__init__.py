"""
Database Schema Management Module.

This module provides functions to handle schemas for pandas DataFrames, enabling
schema validation, transformation, and application across database operations.

Schemas are defined in JSON files in the same directory as this module.
Each JSON file contains a dictionary where keys are table names and values are
lists of column definitions. Each column definition is a dictionary containing:
- field_name: The column name
- field_type: The data type (e.g., 'string', 'int64', 'float64', 'datetime64[ns]')
- is_key: Boolean indicating if column is a primary key

This module provides functions to:
- Load schemas from JSON configuration files
- Build schemas from DataFrame structures
- Apply schemas to DataFrames with type conversion
- List available schemas and tables
- Print schema definitions for debugging

Examples
--------
Load and apply a schema to a DataFrame:

>>> from fbpyutils_db.database.schema import get_schema, apply_schema
>>> import pandas as pd
>>>
>>> # Create sample data
>>> df = pd.DataFrame({'id': ['1', '2'], 'name': ['Alice', 'Bob']})
>>>
>>> # Get schema for a table
>>> schema = get_schema('sample', 'test')
>>>
>>> # Apply schema with type conversion
>>> df_typed = apply_schema(df, schema)

Build a schema from existing DataFrame:

>>> from fbpyutils_db.database.schema import build_schema
>>> import pandas as pd
>>>
>>> df = pd.DataFrame({'id': [1, 2], 'value': [10.5, 20.3]})
>>> schema_df = build_schema('custom', 'my_table', df)

See Also
--------
- pandas.DataFrame: Data structure for tabular data
- fbpyutils_db.database.operations: Database operations using schemas

Notes
-----
- Column names are automatically converted to uppercase when applying schemas
- Type conversion uses pandas' built-in converters with error coercion
- Missing columns in the DataFrame are skipped during schema application
- All timestamps are treated as UTC when converting datetime columns
"""

import json
import inspect
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
import pandas as pd
from fbpyutils.file import find
from fbpyutils_db import logger


def get_schemas(
    folder: Optional[str] = None,
) -> Tuple[Tuple[str, str, str, str, bool], ...]:
    """Load database schemas from JSON configuration files.

    This function scans the specified directory (or the module directory if None)
    for JSON files containing schema definitions and loads them into a structured
    tuple format for efficient processing.

    Parameters
    ----------
    folder : str, optional
        Path to directory containing JSON schema files.
        If None, uses the directory where this module is located.

    Returns
    -------
    tuple of tuple
        A tuple where each element is a schema definition tuple containing:
        (schema_name, table_name, field_name, field_type, is_key)

        - schema_name (str): Name of the schema file (without extension)
        - table_name (str): Name of the table within the schema
        - field_name (str): Name of the column/field
        - field_type (str): Data type (e.g., 'string', 'int64', 'datetime64[ns]')
        - is_key (bool): True if field is a primary key, False otherwise

    Raises
    ------
    FileNotFoundError
        If no JSON schema files are found in the specified directory.
    JSONDecodeError
        If a JSON file contains invalid JSON format.
    KeyError
        If a schema file is missing required fields (field_name, field_type, is_key).

    Examples
    --------
    Load schemas from module directory:

    >>> schemas = get_schemas()
    >>> print(f"Found {len(schemas)} schema definitions")

    Load schemas from custom directory:

    >>> schemas = get_schemas("/path/to/schema/files")
    >>> for schema in schemas:
    ...     print(f"Schema: {schema[0]}, Table: {schema[1]}, Field: {schema[2]}")

    Notes
    -----
    - JSON files should follow the naming convention: schema_name.json
    - Each schema file should contain a dictionary where keys are table names
      and values are lists of column definitions
    - Column definitions must be dictionaries with keys: field_name, field_type, is_key
    - The function logs loading progress and any errors encountered

    See Also
    --------
    get_schema : Get schema for a specific table
    list_schemas : List all available schema names
    """
    start_time = pd.Timestamp.now()

    # Determine directory to scan
    if folder is None:
        current_dir = Path(inspect.getfile(inspect.currentframe())).parent
        logger.info(
            "Schema initialization started: scanning module directory",
            extra={"operation": "schema_load", "directory": str(current_dir)},
        )
    else:
        current_dir = Path(folder)
        logger.info(
            "Schema initialization started: scanning custom directory",
            extra={"operation": "schema_load", "directory": folder},
        )

    # Find all JSON files in the directory
    json_files = find(str(current_dir), "*.json")

    if not json_files:
        error_msg = f"No JSON schema files found in directory: {current_dir}"
        logger.error(
            error_msg, extra={"operation": "schema_load", "directory": str(current_dir)}
        )
        raise FileNotFoundError(error_msg)

    schema_tuples = []
    files_processed = 0
    tables_found = 0
    fields_found = 0

    try:
        for json_file in json_files:
            schema_name = Path(json_file).stem
            files_processed += 1

            logger.info(
                "Loading schema file",
                extra={
                    "operation": "schema_load",
                    "file_path": json_file,
                    "schema_name": schema_name,
                    "file_number": files_processed,
                    "total_files": len(json_files),
                },
            )

            try:
                with open(json_file, "r", encoding="utf-8") as f:
                    schema_data = json.load(f)

                for table_name, columns in schema_data.items():
                    tables_found += 1

                    if not isinstance(columns, list):
                        logger.warning(
                            f"Invalid columns format in table {table_name}: expected list",
                            extra={
                                "operation": "schema_validation",
                                "table": table_name,
                            },
                        )
                        continue

                    for column in columns:
                        if not isinstance(column, dict):
                            logger.warning(
                                f"Invalid column format in table {table_name}: expected dict",
                                extra={
                                    "operation": "schema_validation",
                                    "table": table_name,
                                },
                            )
                            continue

                        # Validate required fields
                        required_fields = ["field_name", "field_type", "is_key"]
                        if not all(field in column for field in required_fields):
                            missing_fields = [
                                f for f in required_fields if f not in column
                            ]
                            error_msg = f"Missing required fields in column definition: {missing_fields}"
                            logger.error(
                                error_msg,
                                extra={
                                    "operation": "schema_validation",
                                    "table": table_name,
                                    "column": column,
                                },
                            )
                            raise KeyError(error_msg)

                        schema_tuples.append(
                            (
                                schema_name,
                                table_name,
                                column["field_name"],
                                column["field_type"],
                                column["is_key"],
                            )
                        )
                        fields_found += 1

            except json.JSONDecodeError as e:
                logger.error(
                    f"Invalid JSON format in schema file",
                    extra={
                        "operation": "schema_load",
                        "file_path": json_file,
                        "error": str(e),
                        "line": e.lineno,
                        "column": e.colno,
                    },
                )
                raise

            except Exception as e:
                logger.error(
                    f"Error processing schema file",
                    extra={
                        "operation": "schema_load",
                        "file_path": json_file,
                        "error": str(e),
                    },
                )
                raise

    except Exception as e:
        logger.error(
            f"Critical error during schema loading",
            extra={"operation": "schema_load", "error": str(e)},
        )
        raise

    # Log completion summary
    duration = (pd.Timestamp.now() - start_time).total_seconds()
    logger.info(
        "Schema loading completed",
        extra={
            "operation": "schema_load",
            "duration_seconds": duration,
            "files_processed": files_processed,
            "tables_found": tables_found,
            "fields_loaded": fields_found,
            "total_schema_definitions": len(schema_tuples),
        },
    )

    return tuple(schema_tuples)


def build_schema(schema_name: str, table_name: str, data: pd.DataFrame) -> pd.DataFrame:
    """Generate a database schema definition from an existing DataFrame.

    This function analyzes a pandas DataFrame and creates a schema definition
    that can be used for database operations. The generated schema captures
    the current structure and data types of the DataFrame.

    Parameters
    ----------
    schema_name : str
        Name to assign to the generated schema.
        This will be used to identify the schema in configuration.
    table_name : str
        Name of the table within the schema.
        This represents the logical table grouping for the schema.
    data : pd.DataFrame
        Source DataFrame to analyze for schema generation.
        The DataFrame should contain the data structure to be replicated
        in the database schema.

    Returns
    -------
    pd.DataFrame
        DataFrame containing the generated schema with columns:
        - schema_name: Name of the generated schema
        - schema: Table name (same as input table_name)
        - coluna: Column name from source DataFrame
        - datatype: Data type as string (e.g., 'int64', 'object')

    Raises
    ------
    ValueError
        If the input data is not a pandas DataFrame.
    TypeError
        If schema_name or table_name are not strings.

    Examples
    --------
    Generate schema from a DataFrame:

    >>> import pandas as pd
    >>> from fbpyutils_db.database.schema import build_schema
    >>>
    >>> # Create sample DataFrame
    >>> df = pd.DataFrame({
    ...     'id': [1, 2, 3],
    ...     'name': ['Alice', 'Bob', 'Charlie'],
    ...     'salary': [50000.0, 60000.0, 75000.0],
    ...     'hire_date': pd.to_datetime(['2020-01-01', '2021-06-15', '2019-03-20'])
    ... })
    >>>
    >>> # Generate schema
    >>> schema_df = build_schema('hr', 'employees', df)
    >>> print(schema_df)
      schema_name schema    coluna    datatype
    0         hr  employees       id      int64
    1         hr  employees     name     object
    2         hr  employees   salary    float64
    3         hr  employees hire_date  datetime64[ns]

    Notes
    -----
    - The generated schema uses pandas' native data type representations
    - String columns are represented as 'object' type
    - This function is useful for creating initial schemas from existing data
    - The returned schema can be used as input for apply_schema() functions

    See Also
    --------
    apply_schema : Apply a schema to transform DataFrame types
    get_schema : Load a predefined schema from JSON files
    """
    start_time = pd.Timestamp.now()

    # Input validation
    if not isinstance(data, pd.DataFrame):
        error_msg = "Invalid argument: data must be a pandas DataFrame"
        logger.error(
            "Schema generation failed: invalid input type",
            extra={
                "operation": "schema_generation",
                "schema_name": schema_name,
                "table_name": table_name,
                "error_type": "invalid_dataframe",
                "data_type": type(data).__name__,
            },
        )
        raise ValueError(error_msg)

    if not isinstance(schema_name, str):
        raise TypeError(
            f"schema_name must be a string, got {type(schema_name).__name__}"
        )

    if not isinstance(table_name, str):
        raise TypeError(f"table_name must be a string, got {type(table_name).__name__}")

    logger.info(
        "Starting schema generation",
        extra={
            "operation": "schema_generation",
            "schema_name": schema_name,
            "table_name": table_name,
            "source_rows": len(data),
            "source_columns": len(data.columns),
            "column_names": list(data.columns),
        },
    )

    try:
        schema_data = [(None, None, None)]  # Header row with nulls
        columns_processed = 0

        for column_name in data.columns:
            columns_processed += 1
            column_type = str(data[column_name].dtype)

            schema_data.append((schema_name, table_name, column_name, column_type))

            logger.debug(
                "Processed column for schema",
                extra={
                    "operation": "schema_generation",
                    "column_name": column_name,
                    "column_type": column_type,
                    "column_index": columns_processed,
                    "schema_name": schema_name,
                },
            )

        # Create result DataFrame
        result_df = pd.DataFrame(
            [row for row in schema_data if any(row)],  # Filter out rows with all None
            columns=["schema_name", "schema", "coluna", "datatype"],
        )

        # Log completion
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.info(
            "Schema generation completed",
            extra={
                "operation": "schema_generation",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "table_name": table_name,
                "columns_processed": columns_processed,
                "output_rows": len(result_df),
            },
        )

        return result_df

    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Schema generation failed",
            extra={
                "operation": "schema_generation",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "table_name": table_name,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise


def print_schema(schema_name: str, table_name: str, data: pd.DataFrame) -> None:
    """Print a formatted schema definition for debugging purposes.

    This function generates and prints a schema in a readable format that shows
    the relationship between schema name, table name, column names, and data types.
    The output is suitable for debugging schema issues or documenting table structures.

    Parameters
    ----------
    schema_name : str
        Name of the schema to print.
    table_name : str
        Name of the table within the schema.
    data : pd.DataFrame
        DataFrame to analyze for schema generation.
        Used to extract column names and data types.

    Raises
    ------
    ValueError
        If data is not a pandas DataFrame.
    Exception
        If schema generation or printing fails.

    Examples
    --------
    Print schema for debugging:

    >>> import pandas as pd
    >>> from fbpyutils_db.database.schema import print_schema
    >>>
    >>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
    >>> print_schema('example', 'users', df)
    (None, None, None, None, None) ,
    ('example', 'users', 'id', 'int64', True) ,
    ('example', 'users', 'name', 'object', True) ,

    Notes
    -----
    - Output format is a tuple representation of schema elements
    - Each line represents one column definition
    - The function includes a header row with None values
    - This is primarily used for debugging and development

    See Also
    --------
    build_schema : Generate schema DataFrame
    get_schema : Get predefined schema from JSON
    """
    start_time = pd.Timestamp.now()

    logger.info(
        "Starting schema printing",
        extra={
            "operation": "schema_print",
            "schema_name": schema_name,
            "table_name": table_name,
            "source_rows": len(data),
            "source_columns": len(data.columns),
        },
    )

    try:
        # Generate the schema
        schema_df = build_schema(schema_name, table_name, data)

        columns_printed = 0
        for schema_record in schema_df.to_records(index=False):
            s, t, c, y = schema_record

            # Format and print the tuple representation
            formatted_tuple = (s, t, c, y, True)  # is_key set to True for all columns
            print(formatted_tuple, ",")
            columns_printed += 1

            logger.debug(
                "Printed schema column",
                extra={
                    "operation": "schema_print",
                    "schema_name": s,
                    "table_name": t,
                    "column_name": c,
                    "data_type": y,
                    "column_index": columns_printed,
                },
            )

        # Log completion
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.info(
            "Schema printing completed",
            extra={
                "operation": "schema_print",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "table_name": table_name,
                "columns_printed": columns_printed,
            },
        )

    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Schema printing failed",
            extra={
                "operation": "schema_print",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "table_name": table_name,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise


def get_schema(
    schema_name: str,
    table_name: str,
    schemas: Tuple[Tuple[str, str, str, str, bool], ...] = None,
) -> List[Tuple[str, str, str, str, bool]]:
    """Retrieve schema definition for a specific table.

    This function loads and filters the available schemas to return the schema
    definition for a specific table within a named schema. The schema contains
    column definitions with data types and key information.

    Parameters
    ----------
    schema_name : str
        Name of the schema to retrieve.
        This should match the filename (without .json extension) of the schema file.
    table_name : str
        Name of the table within the schema.
        This should match one of the keys in the schema JSON file.
    schemas : tuple of tuple, optional
        Preloaded schema definitions to use for filtering.
        If None, the function will load schemas using get_schemas().

    Returns
    -------
    list of tuple
        List of schema definition tuples, where each tuple contains:
        (schema_name, table_name, field_name, field_type, is_key)

        - schema_name (str): The requested schema name
        - table_name (str): The requested table name
        - field_name (str): Name of the column/field
        - field_type (str): Data type specification
        - is_key (bool): True if field is a primary key

    Raises
    ------
    FileNotFoundError
        If no schema files are found or the specified schema doesn't exist.
    KeyError
        If the specified table_name doesn't exist in the schema.
    Exception
        If there's an error loading or processing the schema.

    Examples
    --------
    Get schema for a specific table:

    >>> from fbpyutils_db.database.schema import get_schema
    >>> schema = get_schema('sample', 'test')
    >>> for field in schema:
    ...     print(f"Field: {field[2]}, Type: {field[3]}, Key: {field[4]}")
    Field: ID, Type: int64, Key: True
    Field: NAME, Type: object, Key: False

    Use schema for DataFrame processing:

    >>> import pandas as pd
    >>> from fbpyutils_db.database.schema import get_schema, apply_schema
    >>>
    >>> df = pd.DataFrame({'id': ['1', '2'], 'name': ['Alice', 'Bob']})
    >>> schema = get_schema('financial', 'accounts')
    >>> df_typed = apply_schema(df, schema)

    Notes
    -----
    - This function uses the internal get_schemas() to load all schemas
    - Column names are case-sensitive in the JSON files
    - The returned schema can be used with apply_schema() for type conversion
    - Missing tables return an empty list (not an error)

    See Also
    --------
    get_schemas : Internal function that loads all schemas
    apply_schema : Apply schema to transform DataFrame types
    list_schemas : List all available schema names
    """
    start_time = pd.Timestamp.now()

    # Input validation
    if not isinstance(schema_name, str):
        raise TypeError(
            f"schema_name must be a string, got {type(schema_name).__name__}"
        )

    if not isinstance(table_name, str):
        raise TypeError(f"table_name must be a string, got {type(table_name).__name__}")

    if not schema_name.strip():
        raise ValueError("schema_name cannot be empty or whitespace")

    if not table_name.strip():
        raise ValueError("table_name cannot be empty or whitespace")

    logger.info(
        "Retrieving schema definition",
        extra={
            "operation": "schema_retrieval",
            "schema_name": schema_name,
            "table_name": table_name,
        },
    )

    try:
        # Use all schemas if provided, otherwise load them
        all_schemas = schemas or get_schemas(None)

        if not all_schemas:
            error_msg = "No schemas found in the schema directory"
            logger.error(
                "Schema retrieval failed: no schemas available",
                extra={"operation": "schema_retrieval"},
            )
            raise FileNotFoundError(error_msg)

        # Filter schemas for the requested table
        matching_schemas = [
            schema
            for schema in all_schemas
            if schema[0] == schema_name and schema[1] == table_name
        ]

        if not matching_schemas:
            # Check if schema_name exists but table doesn't
            available_schemas = list(set(schema[0] for schema in all_schemas))
            if schema_name not in available_schemas:
                error_msg = f"Schema '{schema_name}' not found. Available schemas: {available_schemas}"
                logger.error(
                    "Schema retrieval failed: schema not found",
                    extra={
                        "operation": "schema_retrieval",
                        "requested_schema": schema_name,
                        "available_schemas": available_schemas,
                    },
                )
                raise KeyError(error_msg)
            else:
                # Schema exists but table doesn't
                available_tables = list(
                    set(schema[1] for schema in all_schemas if schema[0] == schema_name)
                )
                error_msg = f"Table '{table_name}' not found in schema '{schema_name}'. Available tables: {available_tables}"
                logger.error(
                    "Schema retrieval failed: table not found",
                    extra={
                        "operation": "schema_retrieval",
                        "schema_name": schema_name,
                        "requested_table": table_name,
                        "available_tables": available_tables,
                    },
                )
                raise KeyError(error_msg)

        # Log successful retrieval
        fields_found = len(matching_schemas)
        logger.info(
            "Schema retrieval completed",
            extra={
                "operation": "schema_retrieval",
                "schema_name": schema_name,
                "table_name": table_name,
                "fields_found": fields_found,
                "duration_seconds": (pd.Timestamp.now() - start_time).total_seconds(),
            },
        )

        return matching_schemas

    except (FileNotFoundError, KeyError):
        # Re-raise known exceptions
        raise
    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Schema retrieval failed with unexpected error",
            extra={
                "operation": "schema_retrieval",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "table_name": table_name,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise


def apply_schema(
    dataframe: pd.DataFrame, table_schema: List[Tuple[str, str, str, str, bool]]
) -> pd.DataFrame:
    """Apply a database schema to transform DataFrame column types.

    This function applies a database schema definition to a pandas DataFrame,
    performing type conversions and data validation according to the schema
    specifications. Column names are automatically converted to uppercase,
    and missing columns in the DataFrame are gracefully skipped.

    Parameters
    ----------
    dataframe : pd.DataFrame
        Source DataFrame to apply the schema to.
        Column names will be converted to uppercase during processing.
    table_schema : list of tuple
        Schema definition containing column specifications.
        Each tuple should contain: (schema_name, table_name, field_name, field_type, is_key)

        - schema_name (str): Name of the schema (informational)
        - table_name (str): Name of the table (informational)
        - field_name (str): Name of the column to apply type to
        - field_type (str): Target data type (e.g., 'int64', 'float64', 'datetime64[ns]')
        - is_key (bool): Whether field is a primary key (informational for this function)

    Returns
    -------
    pd.DataFrame
        DataFrame with applied schema types.
        Returns the same DataFrame object with modified column types.

    Raises
    ------
    ValueError
        If dataframe is not a pandas DataFrame or schema is invalid.
    TypeError
        If table_schema is not a list or contains invalid tuple structures.
    Exception
        If type conversion fails for any column.

    Examples
    --------
    Apply a schema to convert DataFrame types:

    >>> import pandas as pd
    >>> from fbpyutils_db.database.schema import get_schema, apply_schema
    >>>
    >>> # Create sample data with string types
    >>> df = pd.DataFrame({
    ...     'id': ['1', '2', '3'],
    ...     'name': ['Alice', 'Bob', 'Charlie'],
    ...     'salary': ['50000.0', '60000.0', '75000.0'],
    ...     'hire_date': ['2020-01-01', '2021-06-15', '2019-03-20']
    ... })
    >>>
    >>> # Get and apply schema
    >>> schema = get_schema('hr', 'employees')
    >>> df_typed = apply_schema(df, schema)
    >>>
    >>> # Check converted types
    >>> print(df_typed.dtypes)
    id           int64
    name        object
    salary      float64
    hire_date    datetime64[ns]
    dtype: object

    Handle missing columns gracefully:

    >>> df_incomplete = pd.DataFrame({'id': ['1', '2'], 'name': ['Alice', 'Bob']})
    >>> df_partial = apply_schema(df_incomplete, schema)  # Only applies to existing columns
    >>> print(df_partial.dtypes)
    id      int64
    name    object
    dtype: object

    Notes
    -----
    - Column names are converted to uppercase before processing
    - Missing columns in the DataFrame are skipped with DEBUG level logging
    - Type conversion uses pandas' converters with error coercion (invalid values become NA)
    - Datetime conversion attempts dayfirst=True first, then falls back to inference
    - Boolean conversion handles nullable boolean types appropriately
    - String columns are converted to 'object' type (pandas default for strings)

    Performance Considerations
    --------------------------
    - Large DataFrames may take time for type conversion
    - Datetime conversion is the most expensive operation
    - Consider preprocessing data before applying schema for large datasets

    See Also
    --------
    get_schema : Retrieve schema definition for a table
    build_schema : Generate schema from existing DataFrame
    pandas.DataFrame.astype : Direct type conversion method
    """
    start_time = pd.Timestamp.now()

    # Input validation
    if not isinstance(dataframe, pd.DataFrame):
        error_msg = "Invalid argument: dataframe must be a pandas DataFrame"
        logger.error(
            "Schema application failed: invalid input type",
            extra={
                "operation": "schema_application",
                "error_type": "invalid_dataframe",
                "data_type": type(dataframe).__name__,
            },
        )
        raise ValueError(error_msg)

    if not isinstance(table_schema, list):
        error_msg = "Invalid argument: table_schema must be a list"
        logger.error(
            "Schema application failed: invalid schema type",
            extra={
                "operation": "schema_application",
                "error_type": "invalid_schema_list",
                "schema_type": type(table_schema).__name__,
            },
        )
        raise ValueError(error_msg)

    if not table_schema:
        logger.warning(
            "Schema application attempted with empty schema",
            extra={"operation": "schema_application"},
        )
        return dataframe

    logger.info(
        "Starting schema application",
        extra={
            "operation": "schema_application",
            "source_rows": len(dataframe),
            "source_columns": len(dataframe.columns),
            "schema_fields": len(table_schema),
            "source_column_names": list(dataframe.columns),
        },
    )

    try:
        # Step 1: Normalize DataFrame column names to uppercase
        logger.info(
            "Normalizing DataFrame column names to uppercase",
            extra={
                "operation": "schema_application",
                "step": "column_normalization",
                "original_columns": list(dataframe.columns),
                "normalized_columns": [str(col).upper() for col in dataframe.columns],
            },
        )

        original_columns = list(dataframe.columns)
        dataframe.columns = [str(col).upper() for col in dataframe.columns]
        normalized_columns = set(dataframe.columns)

        # Step 2: Get available columns after normalization
        available_columns = set(dataframe.columns)

        logger.debug(
            "Column normalization completed",
            extra={
                "operation": "schema_application",
                "step": "column_normalization",
                "available_columns": list(available_columns),
            },
        )

        # Step 3: Apply schema field by field
        fields_processed = 0
        fields_applied = 0
        fields_skipped = 0
        conversion_errors = 0

        # Extract field definitions from schema tuples
        field_definitions = [
            (schema[2], schema[3]) for schema in table_schema
        ]  # (field_name, field_type)

        for field_name, field_type in field_definitions:
            fields_processed += 1

            try:
                # Normalize field name and type
                normalized_field_name = str(field_name).upper()
                normalized_field_type = str(field_type).lower()

                # Check if field exists in DataFrame
                if normalized_field_name not in available_columns:
                    fields_skipped += 1
                    logger.debug(
                        "Skipping schema field: column not found in DataFrame",
                        extra={
                            "operation": "schema_application",
                            "step": "field_processing",
                            "field_name": field_name,
                            "normalized_field_name": normalized_field_name,
                            "field_type": field_type,
                            "available_columns": list(available_columns),
                            "fields_processed": fields_processed,
                        },
                    )
                    continue

                logger.debug(
                    "Processing schema field",
                    extra={
                        "operation": "schema_application",
                        "step": "field_processing",
                        "field_name": field_name,
                        "normalized_field_name": normalized_field_name,
                        "field_type": field_type,
                        "normalized_field_type": normalized_field_type,
                        "fields_processed": fields_processed,
                    },
                )

                # Replace None values with pandas NA for consistent handling
                dataframe[normalized_field_name] = dataframe[
                    normalized_field_name
                ].replace([None], pd.NA)

                # Apply type conversion based on target type
                conversion_success = False

                if normalized_field_type == "datetime64[ns]":
                    try:
                        # First attempt: dayfirst=True for European-style dates
                        logger.debug(
                            "Attempting datetime conversion with dayfirst=True",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                            },
                        )
                        dataframe[normalized_field_name] = pd.to_datetime(
                            dataframe[normalized_field_name],
                            dayfirst=True,
                            errors="coerce",
                        ).astype(normalized_field_type)
                        conversion_success = True
                    except Exception as e:
                        logger.debug(
                            "Dayfirst datetime conversion failed, trying inference",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                                "error": str(e),
                            },
                        )
                        try:
                            # Fallback: let pandas infer datetime format
                            dataframe[normalized_field_name] = pd.to_datetime(
                                dataframe[normalized_field_name], errors="coerce"
                            ).astype(normalized_field_type)
                            conversion_success = True
                        except Exception as e2:
                            logger.warning(
                                "Datetime conversion failed completely",
                                extra={
                                    "operation": "schema_application",
                                    "field": normalized_field_name,
                                    "dayfirst_error": str(e),
                                    "inference_error": str(e2),
                                },
                            )

                elif normalized_field_type == "float64":
                    try:
                        dataframe[normalized_field_name] = pd.to_numeric(
                            dataframe[normalized_field_name], errors="coerce"
                        ).astype("float64")
                        conversion_success = True
                    except Exception as e:
                        logger.warning(
                            "Float conversion failed",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                                "error": str(e),
                            },
                        )

                elif normalized_field_type == "int64":
                    try:
                        dataframe[normalized_field_name] = pd.to_numeric(
                            dataframe[normalized_field_name], errors="coerce"
                        ).astype("int64")
                        conversion_success = True
                    except Exception as e:
                        logger.warning(
                            "Integer conversion failed",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                                "error": str(e),
                            },
                        )

                elif normalized_field_type in ["boolean", "bool"]:
                    try:
                        # Handle nullable boolean conversion
                        if dataframe[normalized_field_name].isna().any():
                            # Create mask for non-null values
                            non_null_mask = dataframe[normalized_field_name].notna()

                            # Initialize result with nullable boolean dtype
                            result = pd.Series(
                                pd.NA, index=dataframe.index, dtype=pd.BooleanDtype()
                            )

                            # Convert non-null values
                            if non_null_mask.any():
                                result[non_null_mask] = pd.to_numeric(
                                    dataframe[normalized_field_name][non_null_mask],
                                    errors="coerce",
                                ).astype("boolean")

                            dataframe[normalized_field_name] = result
                        else:
                            # No nulls, use simple conversion
                            dataframe[normalized_field_name] = pd.to_numeric(
                                dataframe[normalized_field_name], errors="coerce"
                            ).astype("bool")

                        conversion_success = True
                    except Exception as e:
                        logger.warning(
                            "Boolean conversion failed",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                                "error": str(e),
                            },
                        )

                else:
                    # Default: convert to object type (strings, etc.)
                    try:
                        dataframe[normalized_field_name] = dataframe[
                            normalized_field_name
                        ].astype("object")
                        conversion_success = True
                    except Exception as e:
                        logger.warning(
                            "Object conversion failed",
                            extra={
                                "operation": "schema_application",
                                "field": normalized_field_name,
                                "error": str(e),
                            },
                        )

                # Track conversion results
                if conversion_success:
                    fields_applied += 1
                    logger.debug(
                        "Field type conversion successful",
                        extra={
                            "operation": "schema_application",
                            "field": normalized_field_name,
                            "target_type": normalized_field_type,
                            "fields_applied": fields_applied,
                        },
                    )
                else:
                    conversion_errors += 1
                    logger.warning(
                        "Field type conversion failed",
                        extra={
                            "operation": "schema_application",
                            "field": normalized_field_name,
                            "target_type": normalized_field_type,
                            "conversion_errors": conversion_errors,
                        },
                    )

            except Exception as e:
                conversion_errors += 1
                error_msg = f"Error converting column {normalized_field_name} to type {normalized_field_type}: {str(e)}"
                logger.error(
                    "Critical field conversion error",
                    extra={
                        "operation": "schema_application",
                        "field": normalized_field_name,
                        "target_type": normalized_field_type,
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                )
                raise ValueError(error_msg)

        # Log completion summary
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.info(
            "Schema application completed",
            extra={
                "operation": "schema_application",
                "duration_seconds": duration,
                "fields_processed": fields_processed,
                "fields_applied": fields_applied,
                "fields_skipped": fields_skipped,
                "conversion_errors": conversion_errors,
                "final_columns": list(dataframe.columns),
                "success_rate": f"{(fields_applied / fields_processed) * 100:.1f}%"
                if fields_processed > 0
                else "N/A",
            },
        )

        return dataframe

    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Schema application failed with critical error",
            extra={
                "operation": "schema_application",
                "duration_seconds": duration,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise


def list_schemas(
    schemas: Tuple[Tuple[str, str, str, str, bool], ...] = None,
) -> List[str]:
    """List all available schema names in the schema directory.

    This function scans the schema directory and returns a list of unique
    schema names based on the JSON files found. Each JSON file represents
    a schema, and the schema name is derived from the filename (without extension).

    Parameters
    ----------
    schemas : tuple of tuple, optional
        Preloaded schema definitions to use for discovery.
        If None, the function will load schemas using get_schemas().

    Returns
    -------
    list of str
        Sorted list of unique schema names available in the schema directory.
        Returns empty list if no schemas are found.

    Raises
    ------
    FileNotFoundError
        If the schema directory doesn't exist or contains no JSON files.
    Exception
        If there's an error scanning or processing the schema directory.

    Examples
    --------
    List all available schemas:

    >>> from fbpyutils_db.database.schema import list_schemas
    >>> schemas = list_schemas()
    >>> print(schemas)
    ['financial', 'hr', 'inventory']

    Check if a specific schema exists:

    >>> from fbpyutils_db.database.schema import list_schemas
    >>> available = list_schemas()
    >>> if 'financial' in available:
    ...     print("Financial schema is available")

    Notes
    -----
    - Schema names are extracted from JSON filenames (filename.json -> 'filename')
    - The list is sorted alphabetically for consistent output
    - This function uses the internal get_schemas() to load and process schemas
    - Empty or invalid JSON files are skipped during processing

    See Also
    --------
    list_tables : List tables within a specific schema
    get_schema : Get detailed schema definition for a specific table
    get_schemas : Internal function that loads all schema data
    """
    start_time = pd.Timestamp.now()

    logger.info("Starting schema discovery", extra={"operation": "schema_discovery"})

    try:
        # Use provided schemas or load all to discover available schema names
        all_schemas = schemas or get_schemas(None)

        if not all_schemas:
            logger.warning(
                "No schemas discovered during directory scan",
                extra={"operation": "schema_discovery"},
            )
            return []

        # Extract unique schema names
        schema_names = list(set(schema[0] for schema in all_schemas))
        schema_names.sort()  # Sort for consistent output

        # Log discovery results
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.info(
            "Schema discovery completed",
            extra={
                "operation": "schema_discovery",
                "duration_seconds": duration,
                "schemas_found": len(schema_names),
                "schema_names": schema_names,
                "total_schema_definitions": len(all_schemas),
            },
        )

        return schema_names

    except FileNotFoundError:
        # Re-raise file not found errors
        logger.error(
            "Schema discovery failed: schema directory not found",
            extra={"operation": "schema_discovery"},
        )
        raise
    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Schema discovery failed with unexpected error",
            extra={
                "operation": "schema_discovery",
                "duration_seconds": duration,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise


def list_tables(
    schema_name: str, schemas: Tuple[Tuple[str, str, str, str, bool], ...] = None
) -> List[str]:
    """List all table names within a specific schema.

    This function retrieves all table definitions associated with a given schema
    name and returns a unique list of table names. This is useful for discovering
    available tables before loading schema definitions.

    Parameters
    ----------
    schema_name : str
        Name of the schema to list tables for.
        This should match a schema name returned by list_schemas().
    schemas : tuple of tuple, optional
        Preloaded schema definitions to use for filtering.
        If None, the function will load schemas using get_schemas().

    Returns
    -------
    list of str
        Sorted list of unique table names in the specified schema.
        Returns empty list if no tables are found for the schema.

    Raises
    ------
    TypeError
        If schema_name is not a string.
    ValueError
        If schema_name is empty or contains only whitespace.
    FileNotFoundError
        If the specified schema doesn't exist.
    Exception
        If there's an error loading or processing the schema data.

    Examples
    --------
    List tables in a schema:

    >>> from fbpyutils_db.database.schema import list_tables
    >>> tables = list_tables('financial')
    >>> print(tables)
    ['accounts', 'transactions', 'budgets']

    Check available tables before loading schema:

    >>> from fbpyutils_db.database.schema import list_schemas, list_tables
    >>> for schema in list_schemas():
    ...     tables = list_tables(schema)
    ...     print(f"{schema}: {len(tables)} tables")

    Use with schema operations:

    >>> from fbpyutils_db.database.schema import list_tables, get_schema
    >>> schema_name = 'hr'
    >>> for table in list_tables(schema_name):
    ...     schema_def = get_schema(schema_name, table)
    ...     print(f"Table {table} has {len(schema_def)} fields")

    Notes
    -----
    - Table names are returned in sorted order for consistent output
    - This function uses the internal get_schemas() to load schema data
    - Invalid or corrupted schema files are skipped during processing
    - The function validates that the schema exists before attempting to list tables

    See Also
    --------
    list_schemas : List all available schema names
    get_schema : Get detailed schema definition for a specific table
    get_schemas : Internal function that loads all schema data
    """
    start_time = pd.Timestamp.now()

    # Input validation
    if not isinstance(schema_name, str):
        error_msg = f"schema_name must be a string, got {type(schema_name).__name__}"
        logger.error(
            "Table listing failed: invalid schema name type",
            extra={
                "operation": "table_listing",
                "error_type": "invalid_schema_name_type",
                "provided_type": type(schema_name).__name__,
            },
        )
        raise TypeError(error_msg)

    if not schema_name.strip():
        error_msg = "schema_name cannot be empty or whitespace"
        logger.error(
            "Table listing failed: empty schema name",
            extra={"operation": "table_listing"},
        )
        raise ValueError(error_msg)

    logger.info(
        "Starting table discovery for schema",
        extra={"operation": "table_listing", "schema_name": schema_name},
    )

    try:
        # Use provided schemas or load all schemas
        all_schemas = schemas or get_schemas(None)

        if not all_schemas:
            error_msg = "No schemas found in the schema directory"
            logger.error(
                "Table listing failed: no schemas available",
                extra={"operation": "table_listing"},
            )
            raise FileNotFoundError(error_msg)

        # Filter tables for the specified schema
        matching_schemas = [
            schema for schema in all_schemas if schema[0] == schema_name
        ]

        if not matching_schemas:
            # Check available schemas to provide helpful error message
            available_schemas = list(set(schema[0] for schema in all_schemas))
            error_msg = (
                f"Schema '{schema_name}' not found. "
                f"Available schemas: {available_schemas}"
            )
            logger.error(
                "Table listing failed: schema not found",
                extra={
                    "operation": "table_listing",
                    "requested_schema": schema_name,
                    "available_schemas": available_schemas,
                },
            )
            raise KeyError(error_msg)

        # Extract unique table names
        table_names = list(set(schema[1] for schema in matching_schemas))
        table_names.sort()  # Sort for consistent output

        # Log discovery results
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.info(
            "Table discovery completed",
            extra={
                "operation": "table_listing",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "tables_found": len(table_names),
                "table_names": table_names,
                "total_schema_definitions": len(matching_schemas),
            },
        )

        return table_names

    except (FileNotFoundError, KeyError):
        # Re-raise known exceptions
        raise
    except Exception as e:
        duration = (pd.Timestamp.now() - start_time).total_seconds()
        logger.error(
            "Table listing failed with unexpected error",
            extra={
                "operation": "table_listing",
                "duration_seconds": duration,
                "schema_name": schema_name,
                "error": str(e),
                "error_type": type(e).__name__,
            },
        )
        raise
