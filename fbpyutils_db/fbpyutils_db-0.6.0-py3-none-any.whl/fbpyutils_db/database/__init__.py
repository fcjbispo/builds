"""Database operations and utilities.

This module provides comprehensive database operations including table creation,
data insertion, upsert, and batch operations. It supports multiple database
backends through SQLAlchemy and provides dialect-specific query generation.

Modules
-------
dialects
    Database-specific query templates and dialect detection.
schema
    Schema management and validation utilities.
types
    Type mapping between pandas and SQLAlchemy.
table
    Table creation utilities.
index
    Index creation utilities.

Functions
---------
table_operation
    Perform append, upsert, or replace operations on database tables.
batch_table_operation
    Perform batch operations using temporary tables for performance.
get_batch_query
    Get dialect-specific batch queries.

Classes
-------
No classes defined in this module.

Examples
--------
Basic table operation (append):

>>> from fbpyutils_db.database.operations import table_operation
>>> import pandas as pd
>>> from sqlalchemy import create_engine
>>>
>>> engine = create_engine("sqlite:///test.db")
>>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
>>> result = table_operation('append', df, engine, 'users')
>>> print(result)
{'operation': 'append', 'table_name': 'users', 'insertions': 2, ...}

Upsert operation with keys:

>>> result = table_operation(
...     'upsert', df, engine, 'users',
...     keys=['id'], index='unique'
... )

Batch operation for large datasets:

>>> from fbpyutils_db.database.operations import batch_table_operation
>>> result = batch_table_operation(
...     'upsert', df, engine, 'public', 'users',
...     table_schema=(...), table_keys=['id']
... )

Notes
-----
- Supports PostgreSQL, Oracle, and SQLite databases
- Automatic table creation if table doesn't exist
- Batch operations use temporary tables for better performance
- NaN values are handled automatically during database operations
- Supports schema-qualified table names

See Also
--------
sqlalchemy : Python SQL toolkit and ORM
pandas.DataFrame.to_sql : Pandas method for writing to SQL databases
fbpyutils_db.database.schema : Schema management utilities
"""