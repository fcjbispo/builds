import re
import pandas as pd
from typing import List, Literal

from fbpyutils_db import logger


def normalize_columns(cols: List[str]) -> List[str]:
    """Normalize column names by removing special characters and converting to lowercase.

    This function validates that column names contain only alphanumeric characters
    and underscores, then converts them to lowercase. Special characters are not
    allowed and will raise an error.

    Parameters
    ----------
    cols : list of str
        A list of column names to normalize.

    Returns
    -------
    list of str
        A list of normalized column names in lowercase.

    Raises
    ------
    AttributeError
        If any column name contains special characters that cannot be normalized.

    Examples
    --------
    Normalize valid column names:

    >>> from fbpyutils_db.data.normalize import normalize_columns
    >>> cols = ['Name', 'Age', 'Address']
    >>> normalize_columns(cols)
    ['name', 'age', 'address']

    Handle column names with underscores and numbers:

    >>> cols = ['User_ID', 'Age_2024', 'First_Name']
    >>> normalize_columns(cols)
    ['user_id', 'age_2024', 'first_name']

    Error on special characters:

    >>> cols = ['Name!', 'Age@', '#Address']
    >>> normalize_columns(cols)
    Traceback (most recent call last):
        ...
    AttributeError: Column names contain special characters that cannot be normalized.

    Notes
    -----
    - Only alphanumeric characters and underscores are allowed
    - The function is strict and will raise an error for any special characters
    - Use this function before creating DataFrames to ensure valid column names
    - Empty list returns an empty list

    See Also
    --------
    capitalize : Capitalize DataFrame column names
    pandas.DataFrame.columns : DataFrame column labels
    """
    logger.debug(f"Normalizing {len(cols)} column names")
    # test if the column names contain special characters
    if any([re.search("[^0-9a-zA-Z_]+", x) for x in cols]):
        logger.warning(f"Column names contain special characters: {cols}")
        raise AttributeError(
            "Column names contain special characters that cannot be normalized."
        )
    normalized = [re.sub("[^0-9a-zA-Z_]+", "", x).lower() for x in cols]
    logger.debug(f"Successfully normalized columns: {normalized}")
    return normalized


def capitalize(
    df: pd.DataFrame, mode: Literal["upper", "lower", "asis"] = "asis"
) -> pd.DataFrame:
    """Capitalize DataFrame column names based on the specified mode.

    This function creates a new DataFrame with column names converted to
    uppercase, lowercase, or left unchanged. The original DataFrame is not
    modified.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    mode : {'upper', 'lower', 'asis'}, optional
        Capitalization mode:
        - 'upper': Convert all column names to uppercase
        - 'lower': Convert all column names to lowercase
        - 'asis': Keep original column names (default)

    Returns
    -------
    pd.DataFrame
        New DataFrame with capitalized column names in the same order as
        the original DataFrame.

    Raises
    ------
    ValueError
        If `mode` is not one of 'upper', 'lower', or 'asis'.

    Examples
    --------
    Convert column names to uppercase:

    >>> import pandas as pd
    >>> from fbpyutils_db.data.normalize import capitalize
    >>> df = pd.DataFrame({'Name': [1, 2], 'Age': [3, 4]})
    >>> capitalize(df, 'upper')
       NAME  AGE
    0     1    3
    1     2    4

    Convert column names to lowercase:

    >>> capitalize(df, 'lower')
       name  age
    0     1    3
    1     2    4

    Keep original column names:

    >>> capitalize(df, 'asis')
       Name  Age
    0     1    3
    1     2    4

    Notes
    -----
    - The original DataFrame is not modified; a copy is returned
    - Column order is preserved
    - Data values are not affected, only column names
    - Use 'asis' mode when you want to ensure a copy is returned without
      modifying column names

    See Also
    --------
    normalize_columns : Normalize column names by removing special characters
    pandas.DataFrame.rename : Alter axes labels
    """
    if mode == "asis":
        return df.copy()

    if mode == "upper":
        new_columns = [col.upper() for col in df.columns]
    elif mode == "lower":
        new_columns = [col.lower() for col in df.columns]
    else:
        raise ValueError(
            f"Invalid mode '{mode}'. Must be one of: 'upper', 'lower', 'asis'"
        )

    # Create a copy of the DataFrame with new column names
    result_df = df.copy()
    result_df.columns = new_columns
    return result_df
