"""Data type conversion utilities.

This module provides functions for converting values to various data types
with proper handling of NaN, None, and empty string values. These converters
are designed to work seamlessly with pandas DataFrames and database operations.

Functions
---------
is_nan_or_empty
    Check if a value is NaN, None, or empty.
as_boolean
    Convert value to boolean type.
as_datetime
    Convert value to datetime type.
as_date
    Convert value to date type.
as_float
    Convert value to float type.
as_integer
    Convert value to integer type.
as_string
    Convert value to string type.
as_string_id
    Convert value to string ID (removing special characters).
as_dict
    Convert JSON string to dictionary.

Examples
--------
Convert values to different types:

>>> from fbpyutils_db.data.converters import as_integer, as_float, as_boolean
>>> as_integer("42")
42
>>> as_float("3.14")
3.14
>>> as_boolean("Y")
True
>>> as_boolean("N")
False

Handle NaN values:

>>> import pandas as pd
>>> from fbpyutils_db.data.converters import as_string, as_integer
>>> as_string(pd.NA)
None
>>> as_integer(None)
<NA>

Convert JSON to dictionary:

>>> from fbpyutils_db.data.converters import as_dict
>>> as_dict('{"name": "Alice", "age": 30}')
{'name': 'Alice', 'age': 30}

Notes
-----
- All converter functions handle NaN, None, and empty strings gracefully
- Boolean conversion recognizes 'S', 'Y', '1' as True values
- String ID conversion removes '/', '-', and '.' characters
- Failed conversions raise exceptions with detailed logging

See Also
--------
pandas.to_datetime : Pandas datetime conversion
pandas.to_numeric : Pandas numeric conversion
json.loads : JSON parsing from Python standard library
"""

import json
import pandas as pd
import numpy as np
from datetime import datetime

from fbpyutils_db import logger


def is_nan_or_empty(x):
    """Check if a value is NaN, None, or empty.

    This function determines whether a given value represents a missing or
    empty value, including pandas NaN values, Python None, and empty strings.

    Parameters
    ----------
    x : any
        The value to check for NaN or empty status.

    Returns
    -------
    bool
        True if the value is None, NaN, or an empty string, False otherwise.

    Examples
    --------
    Check various values:

    >>> import pandas as pd
    >>> import numpy as np
    >>> is_nan_or_empty(None)
    True
    >>> is_nan_or_empty(pd.NA)
    True
    >>> is_nan_or_empty(np.nan)
    True
    >>> is_nan_or_empty("")
    True
    >>> is_nan_or_empty("valid")
    False
    >>> is_nan_or_empty(42)
    False

    See Also
    --------
    pandas.isna : Check for missing values in pandas
    numpy.isnan : Check for NaN values in numpy
    """
    return x is None or pd.isna(x)


def as_boolean(x):
    """Convert a value to boolean type.

    This function converts a value to boolean, recognizing specific string
    values as True indicators. NaN, None, and empty strings return False.

    Parameters
    ----------
    x : any
        The value to convert to boolean.

    Returns
    -------
    bool
        True if the value is 'S', 'Y', or '1' (case-insensitive),
        False otherwise (including NaN, None, and empty strings).

    Examples
    --------
    Convert various values to boolean:

    >>> as_boolean("Y")
    True
    >>> as_boolean("S")
    True
    >>> as_boolean("1")
    True
    >>> as_boolean("N")
    False
    >>> as_boolean("0")
    False
    >>> as_boolean(None)
    False
    >>> as_boolean("")
    False

    Notes
    -----
    - The function is case-insensitive when checking for True values
    - Only 'S', 'Y', and '1' are recognized as True indicators
    - All other values (including other truthy values) return False

    See Also
    --------
    bool : Python built-in boolean conversion
    pandas.Series.astype : Convert pandas Series to boolean
    """
    if is_nan_or_empty(x):
        return False
    else:
        return str(x).upper() in ("S", "Y", "1")


def as_datetime(x):
    """Convert a value to datetime type.

    This function converts a value to pandas datetime using ISO format parsing.
    NaN, None, and empty strings return NaT (Not a Time).

    Parameters
    ----------
    x : any
        The value to convert to datetime. Should be an ISO format string
        or a value that can be converted to one.

    Returns
    -------
    pandas.Timestamp
        The converted datetime value, or NaT for NaN/None/empty inputs.

    Raises
    ------
    Exception
        If the value cannot be parsed as a valid datetime.

    Examples
    --------
    Convert ISO format strings to datetime:

    >>> as_datetime("2023-01-01")
    Timestamp('2023-01-01 00:00:00')
    >>> as_datetime("2023-01-01T12:30:45")
    Timestamp('2023-01-01 12:30:45')

    Handle NaN values:

    >>> import pandas as pd
    >>> as_datetime(pd.NA)
    <NaT>
    >>> as_datetime(None)
    <NaT>

    Notes
    -----
    - Uses datetime.fromisoformat for parsing
    - Requires ISO 8601 format strings
    - Failed conversions are logged with detailed error information

    See Also
    --------
    pandas.to_datetime : Pandas datetime conversion
    datetime.fromisoformat : Python datetime ISO parsing
    as_date : Convert to date (time component removed)
    """
    if is_nan_or_empty(x):
        return pd.to_datetime(np.nan)
    else:
        try:
            return pd.to_datetime(datetime.fromisoformat(x))
        except Exception as e:
            logger.error(
                "Datetime conversion failed",
                extra={
                    "operation": "datetime_conversion",
                    "input_value": str(x)[:100] if x else None,
                    "input_type": type(x).__name__,
                    "error": str(e),
                },
            )
            raise


def as_date(x):
    """Convert a value to date type (datetime without time component).

    This function converts a value to pandas datetime with only the date
    component. NaN, None, and empty strings return NaT (Not a Time).

    Parameters
    ----------
    x : any
        The value to convert to date. Should be an ISO format string
        or a value that can be converted to one.

    Returns
    -------
    pandas.Timestamp
        The converted date value (time component set to 00:00:00),
        or NaT for NaN/None/empty inputs.

    Raises
    ------
    Exception
        If the value cannot be parsed as a valid datetime.

    Examples
    --------
    Convert ISO format strings to date:

    >>> as_date("2023-01-01")
    Timestamp('2023-01-01 00:00:00')
    >>> as_date("2023-01-01T12:30:45")
    Timestamp('2023-01-01 00:00:00')

    Handle NaN values:

    >>> import pandas as pd
    >>> as_date(pd.NA)
    <NaT>
    >>> as_date(None)
    <NaT>

    Notes
    -----
    - Uses datetime.fromisoformat for parsing
    - Time component is discarded, only date is preserved
    - Failed conversions are logged with detailed error information

    See Also
    --------
    pandas.to_datetime : Pandas datetime conversion
    datetime.fromisoformat : Python datetime ISO parsing
    as_datetime : Convert to datetime (preserves time component)
    """
    try:
        if is_nan_or_empty(x):
            return pd.to_datetime(np.nan)
        else:
            return pd.to_datetime(datetime.fromisoformat(x).date())
    except Exception as e:
        logger.error(
            "Date conversion failed",
            extra={
                "operation": "date_conversion",
                "input_value": str(x)[:100] if x else None,
                "input_type": type(x).__name__,
                "error": str(e),
            },
        )
        raise


def as_float(x):
    """Convert a value to float type.

    This function converts a value to float. NaN, None, and empty strings
    return NaN. Invalid values also return NaN (no exception raised).

    Parameters
    ----------
    x : any
        The value to convert to float.

    Returns
    -------
    float or pandas.NA
        The converted float value, or NaN for invalid/empty inputs.

    Examples
    --------
    Convert various values to float:

    >>> as_float("3.14")
    3.14
    >>> as_float("42")
    42.0
    >>> as_float(100)
    100.0

    Handle invalid and NaN values:

    >>> import pandas as pd
    >>> as_float(pd.NA)
    <NA>
    >>> as_float(None)
    <NA>
    >>> as_float("invalid")
    <NA>

    Notes
    -----
    - Invalid values return NaN instead of raising exceptions
    - String values are converted using float(str(x))
    - This is a forgiving conversion suitable for data cleaning

    See Also
    --------
    pandas.to_numeric : Pandas numeric conversion
    as_integer : Convert to integer type
    float : Python built-in float conversion
    """
    if is_nan_or_empty(x):
        return pd.to_numeric(np.nan)
    else:
        try:
            return float(str(x))
        except ValueError:
            return pd.to_numeric(np.nan)


def as_integer(x):
    """Convert a value to integer type.

    This function converts a value to integer. NaN, None, and empty strings
    return NaN. Invalid values also return NaN (no exception raised).

    Parameters
    ----------
    x : any
        The value to convert to integer.

    Returns
    -------
    int or pandas.NA
        The converted integer value, or NaN for invalid/empty inputs.

    Examples
    --------
    Convert various values to integer:

    >>> as_integer("42")
    42
    >>> as_integer("3.14")
    3
    >>> as_integer(100)
    100

    Handle invalid and NaN values:

    >>> import pandas as pd
    >>> as_integer(pd.NA)
    <NA>
    >>> as_integer(None)
    <NA>
    >>> as_integer("invalid")
    <NA>

    Notes
    -----
    - Invalid values return NaN instead of raising exceptions
    - Float values are truncated (not rounded) to integer
    - This is a forgiving conversion suitable for data cleaning

    See Also
    --------
    pandas.to_numeric : Pandas numeric conversion
    as_float : Convert to float type
    int : Python built-in integer conversion
    """
    if is_nan_or_empty(x):
        return pd.to_numeric(np.nan)
    else:
        try:
            return int(float(x))
        except (ValueError, TypeError):
            return pd.to_numeric(np.nan)


def as_string(x):
    """Convert a value to string type.

    This function converts a value to string. NaN, None, and empty strings
    return None (not an empty string).

    Parameters
    ----------
    x : any
        The value to convert to string.

    Returns
    -------
    str or None
        The string representation of the value, or None for NaN/None/empty inputs.

    Examples
    --------
    Convert various values to string:

    >>> as_string(42)
    '42'
    >>> as_string(3.14)
    '3.14'
    >>> as_string(True)
    'True'

    Handle NaN values:

    >>> import pandas as pd
    >>> as_string(pd.NA)
    None
    >>> as_string(None)
    None
    >>> as_string("")
    None

    Notes
    -----
    - Empty strings return None, not an empty string
    - Uses Python's built-in str() function for conversion
    - This is useful for distinguishing between missing and empty values

    See Also
    --------
    str : Python built-in string conversion
    pandas.Series.astype : Convert pandas Series to string
    as_string_id : Convert to string ID with special character removal
    """
    if is_nan_or_empty(x):
        return None
    else:
        return str(x)


def as_string_id(x):
    """Convert a value to string ID with special characters removed.

    This function converts a value to string and removes common special
    characters ('/', '-', '.') to create a clean ID string. NaN, None,
    and empty strings return None.

    Parameters
    ----------
    x : any
        The value to convert to string ID.

    Returns
    -------
    str or None
        The string ID with special characters removed, or None for
        NaN/None/empty inputs.

    Examples
    --------
    Convert values to string IDs:

    >>> as_string_id("123-456-789")
    '123456789'
    >>> as_string_id("user/123")
    'user123'
    >>> as_string_id("file.name.txt")
    'filenametxt'

    Handle NaN values:

    >>> import pandas as pd
    >>> as_string_id(pd.NA)
    None
    >>> as_string_id(None)
    None

    Notes
    -----
    - Removes '/', '-', and '.' characters from the string
    - Useful for creating database-friendly identifiers
    - Does not remove other special characters

    See Also
    --------
    as_string : Convert to string without special character removal
    str.replace : Python string replacement method
    """
    if is_nan_or_empty(x):
        return None
    else:
        return str(x).replace("/", "").replace("-", "").replace(".", "")


def as_dict(x):
    """Convert a JSON string to dictionary.

    This function parses a JSON string and returns a Python dictionary.
    NaN, None, and empty strings return an empty dictionary.

    Parameters
    ----------
    x : any
        The JSON string to parse.

    Returns
    -------
    dict
        The parsed dictionary, or an empty dict for NaN/None/empty inputs.

    Raises
    ------
    json.JSONDecodeError
        If the input is not valid JSON.

    Examples
    --------
    Parse JSON strings:

    >>> as_dict('{"name": "Alice", "age": 30}')
    {'name': 'Alice', 'age': 30}
    >>> as_dict('["a", "b", "c"]')
    ['a', 'b', 'c']

    Handle NaN values:

    >>> import pandas as pd
    >>> as_dict(pd.NA)
    {}
    >>> as_dict(None)
    {}
    >>> as_dict("")
    {}

    Notes
    -----
    - Uses Python's built-in json module for parsing
    - Failed JSON parsing raises json.JSONDecodeError
    - Failed conversions are logged with detailed error information

    See Also
    --------
    json.loads : Python JSON parsing
    json.dumps : Python JSON serialization
    """
    if is_nan_or_empty(x):
        return {}
    else:
        try:
            return json.loads(x)
        except json.JSONDecodeError as e:
            logger.error(
                "JSON parsing failed",
                extra={
                    "operation": "json_conversion",
                    "input_value": str(x)[:200] if x else None,
                    "input_type": type(x).__name__,
                    "error": str(e),
                },
            )
            raise