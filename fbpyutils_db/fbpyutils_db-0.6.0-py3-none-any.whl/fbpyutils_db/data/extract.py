import pandas as pd
from typing import Any, List, Tuple

from fbpyutils_db import logger


def get_data_from_pandas(
    df: pd.DataFrame, include_index: bool = False
) -> Tuple[List[List[Any]], List[str]]:
    """Extract data and column names from a pandas DataFrame.

    This function converts a pandas DataFrame into a list of lists containing
    the data values, along with a list of column names. Optionally includes
    the DataFrame index as the first column in the extracted data.

    Parameters
    ----------
    df : pandas.DataFrame
        The input pandas DataFrame to extract data from.
    include_index : bool, optional
        If True, includes the index column in the extracted data.
        Default is False.

    Returns
    -------
    tuple of (list of list, list of str)
        A tuple containing:
        - The extracted data as a list of lists, where each inner list
          represents a row.
        - The column names as a list of strings.

    Raises
    ------
    TypeError
        If the input is not a pandas DataFrame.

    Examples
    --------
    Extract data without index:

    >>> import pandas as pd
    >>> from fbpyutils_db.data.extract import get_data_from_pandas
    >>> df = pd.DataFrame({'Name': ['John', 'Alice', 'Bob'], 'Age': [25, 30, 40]})
    >>> data, columns = get_data_from_pandas(df)
    >>> data
    [['John', 25], ['Alice', 30], ['Bob', 40]]
    >>> columns
    ['Name', 'Age']

    Extract data with index:

    >>> df = pd.DataFrame({'Name': ['John', 'Alice'], 'Age': [25, 30]})
    >>> df.index = [100, 200]
    >>> data, columns = get_data_from_pandas(df, include_index=True)
    >>> data
    [[100, 'John', 25], [200, 'Alice', 30]]
    >>> columns
    ['Index', 'Name', 'Age']

    Notes
    -----
    - The data is extracted using `to_records()` method
    - When `include_index` is True, 'Index' is prepended to the column names
    - The original DataFrame is not modified
    - All data types are preserved as returned by `to_records()`

    See Also
    --------
    pandas.DataFrame.to_records : Convert DataFrame to NumPy record array
    pandas.DataFrame.values : DataFrame values as NumPy array
    """
    if not isinstance(df, pd.DataFrame):
        logger.error("Invalid input type provided, expected pandas DataFrame")
        raise TypeError("Input must be a pandas DataFrame")

    logger.debug(f"Extracting data from DataFrame with include_index={include_index}")
    logger.debug(f"Input DataFrame shape: {df.shape}")

    data = [list(d) for d in df.to_records(index=include_index)]
    columns = list(c for c in df.columns)

    if include_index:
        columns.insert(0, "Index")

    logger.info(f"Successfully extracted {len(data)} rows and {len(columns)} columns")
    logger.debug(f"Extracted columns: {columns}")

    return data, columns
