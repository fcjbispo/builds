import pandas as pd
from typing import List, Union, Dict, Any
from sqlalchemy import Engine
import json
import warnings

# Configurar imports com fallback
FBPYUTILS_AVAILABLE = True
try:
    from fbpyutils.uuid import hash_string, hash_json, Snowflake, uuid as generate_uuid
except ImportError:
    import hashlib

    FBPYUTILS_AVAILABLE = False
    warnings.warn(
        "fbpyutils v1.8.0+ não disponível. Usando hashlib.md5 como fallback. "
        "Para performance e recursos completos, instale fbpyutils==1.8.0+",
        DeprecationWarning,
        stacklevel=2,
    )

from fbpyutils_db.utils.validators import check_columns


def _safe_hash_value(value, length: int = 12) -> str:
    """
    Internal function to safely hash a value with specified length.

    Args:
        value: Value to hash (string, number, dict, etc.)
        length: Hash length in characters

    Returns:
        Hash string truncated to specified length
    """
    if pd.isna(value):
        value = ""

    value_str = str(value)

    # Use fbpyutils se disponível, senão fallback
    if FBPYUTILS_AVAILABLE:
        return hash_string(value_str)[:length]
    else:
        import hashlib

        return hashlib.md5(value_str.encode()).hexdigest()[:length]
    """
    Internal function to safely hash a value with specified length.

    Args:
        value: Value to hash (string, number, dict, etc.)
        length: Hash length in characters

    Returns:
        Hash string truncated to specified length

    Details:
        - Dictionaries are hashed using hash_json if fbpyutils available
        - Other values use hash_string or hashlib.md5 fallback
    """
    # Para dicionários, usar hash_json se disponível
    if isinstance(value, dict):
        if FBPYUTILS_AVAILABLE:
            return hash_json(value)[:length]
        else:
            import json

            value_str = json.dumps(value, sort_keys=True)
            return hashlib.md5(value_str.encode()).hexdigest()[:length]

    # Para outros valores, usar a lógica anterior
    if pd.isna(value):
        value = ""

    value_str = str(value)

    # Use fbpyutils se disponível, senão fallback para hashlib
    if FBPYUTILS_AVAILABLE:
        return hash_string(value_str)[:length]
    else:
        return hashlib.md5(value_str.encode()).hexdigest()[:length]


def create_hash_column(x: Union[str, pd.Series], y: int = 12) -> pd.Series:
    """
    Generate hash for input values or series, truncated to specified length.

    Handles NaN by treating as empty string. For DataFrame input, hashes concatenated row values.

    Args:
        x: Input string, Series, or DataFrame to hash.
        y: Hash length. Defaults to 12.

    Returns:
        pd.Series: Series of hex hashes.

    Example:
        >>> import pandas as pd
        >>> s = pd.Series(['value1', 'value2'])
        >>> hashes = create_hash_column(s, 8)
        >>> hashes.iloc[0]
        'c51ce410'
        # Hashes 'value1' to 'c51ce410c7f896aa' truncated to 8 chars.
    """
    if isinstance(x, pd.DataFrame):
        # Para DataFrames, concatenar valores de cada linha
        def hash_row(row):
            # Tratar valores NaN/None
            values = [str(v) if pd.notna(v) else "" for v in row.values]
            combined = "|".join(values)

            # Use fbpyutils se disponível, senão fallback
            if FBPYUTILS_AVAILABLE:
                return hash_string(combined)[:y]
            else:
                return hashlib.md5(combined.encode()).hexdigest()[:y]

        return x.apply(hash_row, axis=1)
    else:
        # Para Series únicas
        return pd.Series([_safe_hash_value(val, y) for val in x])


def add_hash_column(
    df: pd.DataFrame, column_name: str, length: int = 12, columns: List[str] = []
) -> pd.DataFrame:
    """
    Add a hash column to DataFrame using specified or all columns.

    Hashes concatenated column values per row using MD5, adds as new first column.

    Args:
        df: Input DataFrame.
        column_name: Name for the new hash column.
        length: Hash string length. Defaults to 12.
        columns: Specific columns to hash. Defaults to all.

    Returns:
        pd.DataFrame: Copy with hash column added first.

    Raises:
        TypeError: For invalid df, column_name, or length types.
        ValueError: For invalid length or missing columns.

    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'a': [1, 2], 'b': ['x', 'y']})
        >>> result = add_hash_column(df, 'hash_id', 8, columns=['a', 'b'])
        >>> result['hash_id'].iloc[0]
        '90015098'
        # Hashes '1|x' to '900150983cd24fb0d6963f7d28e17f72' truncated to 8: '90015098'.
    """
    # Parameter checks
    if not isinstance(df, pd.DataFrame):
        raise TypeError("The 'df' parameter should be of type pandas.DataFrame.")
    if not isinstance(column_name, str):
        raise TypeError("The 'index_name' parameter should be a string.")
    if not isinstance(length, int):
        raise TypeError("The 'length' parameter should be an integer.")
    if length <= 0:
        raise ValueError("The 'length' parameter should be greater than 0.")
    if columns and type(columns) != list:
        raise ValueError("When given, columns must be a list of column names")
    if columns and not check_columns(df, columns):
        raise ValueError("When given, all column names should exist in the dataframe.")

    # Creates the hash column
    if columns:
        xdf = df[columns].copy()
    else:
        xdf = df.copy()

    df[column_name] = create_hash_column(xdf, length)
    xcolumns = [column_name, *[c for c in df.columns if c != column_name]]

    return df[xcolumns].copy()
