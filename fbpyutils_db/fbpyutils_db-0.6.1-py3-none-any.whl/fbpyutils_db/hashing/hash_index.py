import pandas as pd
from typing import List

from fbpyutils_db import logger
from fbpyutils_db.hashing.hash_column import _create_hash_column
from fbpyutils_db.utils.validators import _check_columns


def add_hash_index(
    df: pd.DataFrame, index_name: str = "id", length: int = 12, columns: List[str] = []
) -> pd.DataFrame:
    """Replace DataFrame index with hash values.

    This function replaces the DataFrame's index with MD5 hash values derived
    from specified columns. The new index is named according to the provided
    `index_name` parameter.

    Parameters
    ----------
    df : pd.DataFrame
        The input DataFrame whose index will be replaced.
    index_name : str, optional
        The name to be given to the new index. Default is 'id'.
    length : int, optional
        The length of the hash string to generate. Default is 12.
    columns : list of str, optional
        The column names to be used for hash generation. If empty or None
        (default), all columns will be used.

    Returns
    -------
    pd.DataFrame
        A DataFrame with the hash values as the new index.

    Raises
    ------
    TypeError
        If `df` is not a pandas DataFrame, `index_name` is not a string,
        or `length` is not an integer.
    ValueError
        If `length` is less than or equal to 0, `columns` is not a list,
        or specified columns are not found in the DataFrame.

    Examples
    --------
    Replace index with hash from all columns:

    >>> import pandas as pd
    >>> from fbpyutils_db.hashing.hash_index import add_hash_index
    >>> df = pd.DataFrame({'col1': [1, 2, 3], 'col2': ['a', 'b', 'c']})
    >>> result = add_hash_index(df, 'new_index')
    >>> result.index.name
    'new_index'

    Replace index with hash from specific columns:

    >>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30], 'city': ['NY', 'LA']})
    >>> result = add_hash_index(df, 'person_id', columns=['name', 'age'])
    >>> result.index.name
    'person_id'

    Customize hash length:

    >>> result = add_hash_index(df, 'id', length=8)
    >>> len(result.index[0])
    8

    Notes
    -----
    - The original DataFrame index is completely replaced
    - MD5 hashing is used for fast computation
    - Row values are concatenated with '|' separator when multiple columns are used
    - NaN values are treated as empty strings during hash generation
    - The DataFrame is modified in place and returned

    See Also
    --------
    add_hash_column : Add a hash column to a DataFrame
    _create_hash_column : Internal function for hash generation
    """
    # Parameter checks
    if not isinstance(df, pd.DataFrame):
        logger.error(
            "Hash index creation failed: invalid DataFrame type",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "invalid_dataframe",
                "provided_type": type(df).__name__,
            },
        )
        raise TypeError("The 'df' parameter should be of type pandas.DataFrame.")

    logger.info(
        "Starting hash index creation",
        extra={
            "operation": "hash_index_creation",
            "index_name": index_name,
            "hash_length": length,
            "source_columns": columns if columns else "all",
            "input_rows": len(df),
            "input_columns": len(df.columns),
        },
    )
    if not isinstance(index_name, str):
        logger.error(
            "Hash index creation failed: invalid index_name type",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "invalid_index_name_type",
                "provided_type": type(index_name).__name__,
            },
        )
        raise TypeError("The 'index_name' parameter should be a string.")
    if not isinstance(length, int):
        logger.error(
            "Hash index creation failed: invalid length type",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "invalid_length_type",
                "provided_type": type(length).__name__,
            },
        )
        raise TypeError("The 'length' parameter should be an integer.")
    if length <= 0:
        logger.error(
            "Hash index creation failed: invalid length value",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "invalid_length_value",
                "provided_value": length,
            },
        )
        raise ValueError("The 'length' parameter should be greater than 0.")
    if columns and type(columns) != list:
        logger.error(
            "Hash index creation failed: invalid columns type",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "invalid_columns_type",
                "provided_type": type(columns).__name__,
            },
        )
        raise ValueError("When given, columns must be a list of column names")
    if columns and not _check_columns(df, columns):
        logger.error(
            "Hash index creation failed: specified columns not found in DataFrame",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "error_type": "columns_not_found",
                "requested_columns": columns,
                "available_columns": list(df.columns),
            },
        )
        raise ValueError("When given, all column names should exist in the dataframe.")

    logger.debug(
        "Creating hash index",
        extra={
            "operation": "hash_index_creation",
            "index_name": index_name,
            "hash_length": length,
            "using_columns": columns if columns else "all",
        },
    )

    # Creates the hash column
    if columns:
        xdf = df[columns].copy()
        logger.debug(
            "Using subset of columns for hash generation",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
                "selected_columns": columns,
            },
        )
    else:
        xdf = df.copy()
        logger.debug(
            "Using all columns for hash generation",
            extra={
                "operation": "hash_index_creation",
                "index_name": index_name,
            },
        )

    hash_df = _create_hash_column(xdf, length)
    logger.debug(
        "Generated hash values for index",
        extra={
            "operation": "hash_index_creation",
            "index_name": index_name,
            "hash_count": len(hash_df),
        },
    )

    # Set the hash string as the new index
    df.index = hash_df
    # Rename the index
    df.index.name = index_name

    logger.info(
        "Hash index created successfully",
        extra={
            "operation": "hash_index_creation",
            "index_name": index_name,
            "output_rows": len(df),
        },
    )

    return df
