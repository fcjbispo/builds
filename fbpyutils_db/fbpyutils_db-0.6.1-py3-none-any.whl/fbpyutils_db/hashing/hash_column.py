import pandas as pd
import hashlib
from typing import List, Union

from fbpyutils_db import logger
from fbpyutils_db.utils.validators import _check_columns


def _create_hash_column(x: Union[str, pd.Series], y: int = 12) -> pd.Series:
    """Create a hash column from DataFrame or Series values.

    This function generates MD5 hashes for each value in the input and returns
    a Series of truncated hash strings. For DataFrames, values from each row
    are concatenated with pipe separators before hashing. NaN values are
    treated as empty strings.

    Parameters
    ----------
    x : str or pd.Series or pd.DataFrame
        The column from the DataFrame whose values will be hashed, or a
        DataFrame where each row's values will be concatenated and hashed.
    y : int, optional
        The length of the hash string to return. Default is 12.

    Returns
    -------
    pd.Series
        A new pandas Series containing the MD5 hash of the input column values,
        truncated to the specified length.

    Examples
    --------
    Hash a single column:

    >>> import pandas as pd
    >>> from fbpyutils_db.hashing.hash_column import _create_hash_column
    >>> df = pd.DataFrame({'SomeColumn': ['value1', 'value2']})
    >>> _create_hash_column(df['SomeColumn'])
    0    f96b61d7a3f8
    1    f96b61d7a3f9
    dtype: object

    Hash multiple columns by concatenating row values:

    >>> df = pd.DataFrame({'col1': ['a', 'b'], 'col2': [1, 2]})
    >>> _create_hash_column(df)
    0    8b9c45e2a9f6
    1    3d4c4f4f4d1f
    dtype: object

    Handle NaN values:

    >>> df = pd.DataFrame({'col': ['value', None, pd.NA]})
    >>> _create_hash_column(df['col'])
    0    f96b61d7a3f8
    1    d41d8cd98f00
    2    d41d8cd98f00
    dtype: object

    Notes
    -----
    - MD5 is used for hashing, which is fast but not cryptographically secure
    - For DataFrames, row values are joined with '|' separator before hashing
    - NaN/None values are converted to empty strings before hashing
    - The hash is always returned as a string, not bytes

    See Also
    --------
    add_hash_column : Add a hash column to a DataFrame
    add_hash_index : Replace DataFrame index with hash values
    """
    if isinstance(x, pd.DataFrame):
        # Para DataFrames, concatenar valores de cada linha
        def hash_row(row):
            # Tratar valores NaN/None
            values = [str(v) if pd.notna(v) else "" for v in row.values]
            combined = "|".join(values)
            return hashlib.md5(combined.encode()).hexdigest()[:y]

        return x.apply(hash_row, axis=1)
    else:
        # Para Series únicas
        def safe_hash(value):
            if pd.isna(value):
                value = ""
            return hashlib.md5(str(value).encode()).hexdigest()[:y]

        return x.apply(safe_hash)


def add_hash_column(
    df: pd.DataFrame, column_name: str, length: int = 12, columns: List[str] = []
) -> pd.DataFrame:
    """Add a hash column to a DataFrame.

    This function creates a new column containing MD5 hash values derived from
    specified columns in the DataFrame. The hash column is positioned as the
    first column in the returned DataFrame.

    Parameters
    ----------
    df : pandas.DataFrame
        The input DataFrame to which the hash column will be added.
    column_name : str
        The name of the hash column to be created.
    length : int, optional
        The length of the hash string to generate. Default is 12.
    columns : list of str, optional
        The column names to be used for hash generation. If empty or None
        (default), all columns will be used.

    Returns
    -------
    pandas.DataFrame
        A new DataFrame with the hash column added as the first column.
        The order of other columns remains unchanged.

    Raises
    ------
    TypeError
        If `df` is not a pandas DataFrame, `column_name` is not a string,
        or `length` is not an integer.
    ValueError
        If `length` is less than or equal to 0, `columns` is not a list,
        or specified columns are not found in the DataFrame.

    Examples
    --------
    Add hash column using all DataFrame columns:

    >>> import pandas as pd
    >>> from fbpyutils_db.hashing.hash_column import add_hash_column
    >>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30]})
    >>> result = add_hash_column(df, 'hash_id')
    >>> result.columns.tolist()
    ['hash_id', 'name', 'age']

    Add hash column using specific columns:

    >>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30], 'city': ['NY', 'LA']})
    >>> result = add_hash_column(df, 'hash_id', columns=['name', 'age'])
    >>> result['hash_id'].iloc[0]  # Hash of 'Alice|25'
    '8b9c45e2a9f6'

    Customize hash length:

    >>> result = add_hash_column(df, 'hash_id', length=8)
    >>> len(result['hash_id'].iloc[0])
    8

    Notes
    -----
    - The hash column is always placed as the first column
    - MD5 hashing is used for fast computation
    - Row values are concatenated with '|' separator when multiple columns are used
    - NaN values are treated as empty strings during hash generation
    - The original DataFrame is not modified; a copy is returned

    See Also
    --------
    add_hash_index : Replace DataFrame index with hash values
    _create_hash_column : Internal function for hash generation
    """
    # Parameter checks
    if not isinstance(df, pd.DataFrame):
        logger.error(
            "Hash column creation failed: invalid DataFrame type",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "error_type": "invalid_dataframe",
                "provided_type": type(df).__name__,
            },
        )
        raise TypeError("The 'df' parameter should be of type pandas.DataFrame.")

    logger.info(
        "Starting hash column creation",
        extra={
            "operation": "hash_column_creation",
            "column_name": column_name,
            "hash_length": length,
            "source_columns": columns if columns else "all",
            "input_rows": len(df),
            "input_columns": len(df.columns),
        },
    )
    if not isinstance(column_name, str):
        logger.error(
            "Hash column creation failed: invalid column_name type",
            extra={
                "operation": "hash_column_creation",
                "error_type": "invalid_column_name_type",
                "provided_type": type(column_name).__name__,
            },
        )
        raise TypeError("The 'column_name' parameter should be a string.")
    if not isinstance(length, int):
        logger.error(
            "Hash column creation failed: invalid length type",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "error_type": "invalid_length_type",
                "provided_type": type(length).__name__,
            },
        )
        raise TypeError("The 'length' parameter should be an integer.")
    if length <= 0:
        logger.error(
            "Hash column creation failed: invalid length value",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "error_type": "invalid_length_value",
                "provided_value": length,
            },
        )
        raise ValueError("The 'length' parameter should be greater than 0.")
    if columns and type(columns) != list:
        logger.error(
            "Hash column creation failed: invalid columns type",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "error_type": "invalid_columns_type",
                "provided_type": type(columns).__name__,
            },
        )
        raise ValueError("When given, columns must be a list of column names")
    if columns and not _check_columns(df, columns):
        logger.error(
            "Hash column creation failed: specified columns not found in DataFrame",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "error_type": "columns_not_found",
                "requested_columns": columns,
                "available_columns": list(df.columns),
            },
        )
        raise ValueError("When given, all column names should exist in the dataframe.")

    logger.debug(
        "Creating hash column",
        extra={
            "operation": "hash_column_creation",
            "column_name": column_name,
            "hash_length": length,
            "using_columns": columns if columns else "all",
        },
    )

    # Creates the hash column
    if columns:
        xdf = df[columns].copy()
        logger.debug(
            "Using subset of columns for hash generation",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
                "selected_columns": columns,
            },
        )
    else:
        xdf = df.copy()
        logger.debug(
            "Using all columns for hash generation",
            extra={
                "operation": "hash_column_creation",
                "column_name": column_name,
            },
        )

    df[column_name] = _create_hash_column(xdf, length)
    xcolumns = [column_name, *[c for c in df.columns if c != column_name]]

    logger.info(
        "Hash column created successfully",
        extra={
            "operation": "hash_column_creation",
            "column_name": column_name,
            "output_rows": len(df),
            "output_columns": len(df.columns),
        },
    )

    return df[xcolumns].copy()
