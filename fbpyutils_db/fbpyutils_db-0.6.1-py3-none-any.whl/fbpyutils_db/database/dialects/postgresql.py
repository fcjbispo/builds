from sqlalchemy.engine import Engine
from typing import Any, Dict

from fbpyutils_db import logger


def get_postgresql_dialect_specific_query(query_name: str, **kwargs: Any) -> str:
    """Return PostgreSQL-specific SQL queries based on the query name.

    This function retrieves SQL query templates optimized for PostgreSQL
    database operations. The queries support various operations including
    upsert, append, batch operations, and table management.

    Parameters
    ----------
    query_name : str
        The name of the query to retrieve. Valid values include:
        'upsert', 'append', 'batch_append', 'batch_upsert',
        'batch_check', 'drop'.
    **kwargs : Any
        Arbitrary keyword arguments for query formatting. Common keys
        include table_name, columns, values, keys, updates, etc.

    Returns
    -------
    str
        The PostgreSQL-specific SQL query, formatted with provided kwargs.

    Raises
    ------
    KeyError
        If an unknown query name is provided.

    Examples
    --------
    Get an upsert query template:

    >>> from fbpyutils_db.database.dialects.postgresql import get_postgresql_dialect_specific_query
    >>> query = get_postgresql_dialect_specific_query('upsert')
    >>> 'INSERT INTO' in query
    True

    Get a formatted query:

    >>> query = get_postgresql_dialect_specific_query(
    ...     'append',
    ...     table_name='users',
    ...     columns='name, age',
    ...     values="'Alice', 25"
    ... )
    >>> 'users' in query
    True

    Notes
    -----
    - PostgreSQL uses ON CONFLICT for upsert operations
    - MERGE is used for batch upsert operations
    - The function returns unformatted templates when no kwargs are provided
    - All queries are optimized for PostgreSQL syntax and features

    See Also
    --------
    is_postgresql : Check if engine is PostgreSQL
    get_oracle_dialect_specific_query : Oracle-specific queries
    get_sqlite_dialect_specific_query : SQLite-specific queries
    """
    logger.debug(
        f"Getting PostgreSQL dialect specific query for '{query_name}' with kwargs: {kwargs}"
    )
    queries = {
        "upsert": """
            INSERT INTO {table_name} ({columns})
            VALUES ({values})
            ON CONFLICT ({keys}) DO UPDATE SET {updates}
        """,
        "append": "INSERT INTO {table_name} ({columns}) VALUES ({values})",
        "batch_append": """INSERT INTO {table_name}
            ({columns})
            SELECT
                {columns}
            FROM (
            SELECT
                {columns},
                ROW_NUMBER() OVER (PARTITION BY {key_columns} ORDER BY {key_columns}) AS RN
            FROM {session_table} s
            WHERE NOT EXISTS (
            SELECT 1 FROM {table_name} t
            WHERE ({matching_conditions})
            )) AS DD WHERE DD.RN = 1;""",
        "batch_upsert": """MERGE INTO {table_name} t
            USING {session_table} s
            ON ({matching_conditions})
            WHEN MATCHED THEN
            UPDATE SET {updates}
            WHEN NOT MATCHED THEN
            INSERT ({columns})
            VALUES ({values})
        """,
        "batch_check": """with t as (
            select case when s.id is not null then true else false end as s_id,
                case when t.id is not null then true else false end as t_id
            from {session_table} s
            left join {table_name} t on {keys}
            )
            select
                sum(case when s_id and not t_id then 1 else 0 end) {column_1},
                sum(case when s_id and t_id then 1 else 0 end)     {column_2},
                sum(case when not s_id and t_id then 1 else 0 end) {column_3}
            from t
        """,
        "drop": """DROP TABLE IF EXISTS {table_name};""",
    }
    query = queries.get(query_name)
    if not query:
        logger.error(f"Unknown PostgreSQL query name: {query_name}")
        raise KeyError(f"Unknown query name: {query_name}")
    logger.debug(f"Returning PostgreSQL query for '{query_name}'")

    # Only format if kwargs are provided
    if kwargs:
        return query.format(**kwargs)
    else:
        return query.strip()


def is_postgresql(engine: Engine) -> bool:
    """Check if the given SQLAlchemy engine is for PostgreSQL.

    This function determines whether the provided SQLAlchemy engine
    is connected to a PostgreSQL database by checking the engine's
    dialect name.

    Parameters
    ----------
    engine : sqlalchemy.engine.Engine
        The SQLAlchemy engine to check.

    Returns
    -------
    bool
        True if the engine is for PostgreSQL, False otherwise.

    Examples
    --------
    Check if engine is PostgreSQL:

    >>> from sqlalchemy import create_engine
    >>> from fbpyutils_db.database.dialects.postgresql import is_postgresql
    >>> engine = create_engine('postgresql://user:pass@localhost/db')
    >>> is_postgresql(engine)
    True

    Check with SQLite engine:

    >>> engine = create_engine('sqlite:///:memory:')
    >>> is_postgresql(engine)
    False

    Notes
    -----
    - This function checks the `engine.name` attribute
    - It is a simple string comparison, not a connection test
    - Use this for conditional logic based on database type

    See Also
    --------
    is_oracle : Check if engine is Oracle
    is_sqlite : Check if engine is SQLite
    """
    return engine.name == "postgresql"
