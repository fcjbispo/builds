import pandas as pd
import re
from typing import Any, List

from fbpyutils_db import logger

# Importa funções de outros módulos de visualização e dados
from fbpyutils_db.visualization.ascii_table import print_ascii_table
from fbpyutils_db.data.extract import get_data_from_pandas
from fbpyutils_db.data.normalize import normalize_columns


def print_ascii_table_from_dataframe(df: pd.DataFrame, alignment: str = "left") -> None:
    """Print the ASCII table representation of a pandas DataFrame.

    This function extracts data and column names from a pandas DataFrame
    and prints a formatted ASCII table to the console. It handles data
    extraction and formatting automatically.

    Parameters
    ----------
    df : pandas.DataFrame
        The pandas DataFrame to display as an ASCII table.
    alignment : {'left', 'right', 'center'}, optional
        The alignment of the table cells. Valid values are 'left', 'right',
        or 'center'. Default is 'left'.

    Returns
    -------
    None
        The table is printed directly to the console.

    Raises
    ------
    ValueError
        If the DataFrame is invalid or data extraction fails.

    Examples
    --------
    Print a DataFrame as an ASCII table:

    >>> import pandas as pd
    >>> from fbpyutils_db.visualization.display import print_ascii_table_from_dataframe
    >>> df = pd.DataFrame({'Name': ['John', 'Alice', 'Bob'], 'Age': [25, 30, 40], 'Country': ['USA', 'Canada', 'UK']})
    >>> print_ascii_table_from_dataframe(df, alignment='center')
    +-------+-----+---------+
    |  Name | Age | Country |
    +-------+-----+---------+
    |  John |  25 |   USA   |
    | Alice |  30 |  Canada |
    |  Bob  |  40 |    UK   |
    +-------+-----+---------+

    Notes
    -----
    - Uses `get_data_from_pandas` for data extraction
    - Uses `print_ascii_table` for table rendering
    - The DataFrame index is not included in the output
    - Empty DataFrames produce an empty table

    See Also
    --------
    ascii_table : Create ASCII table from list of lists
    print_ascii_table : Print ASCII table directly
    get_data_from_pandas : Extract data from DataFrame
    """
    data, columns = None, None
    try:
        logger.info(
            f"Converting DataFrame to ASCII table with {len(df)} rows and {len(df.columns)} columns"
        )
        data, columns = get_data_from_pandas(df)
        logger.debug(
            f"Successfully extracted data from DataFrame: {len(data)} rows, {len(columns)} columns"
        )
    except Exception as e:
        logger.error(f"Failed to extract data from DataFrame: {e}")
        raise ValueError(f"Invalid pandas dataframe: {e}.")

    if all([data, columns]):
        logger.info("Data and columns extracted successfully, printing ASCII table")
        print_ascii_table(data, columns, alignment)
    else:
        logger.warning("No data or columns to display in ASCII table")


def print_columns(
    cols: List[str], normalize: bool = False, length: int = None, quotes: bool = False
) -> None:
    """Print a formatted string representation of a list of columns.

    This function formats and prints column names with optional normalization,
    padding, and quoting. Useful for generating SQL column lists or debugging
    column names.

    Parameters
    ----------
    cols : list of str
        A list of column names to format and print.
    normalize : bool, optional
        If True, normalizes column names by removing special characters
        and converting to lowercase. Default is False.
    length : int, optional
        The desired length for each column. Columns are left-padded with
        spaces to this length. If not provided, the length is determined
        automatically based on the longest column name. Default is None.
    quotes : bool, optional
        If True, adds single quotes around each column name. Default is False.

    Returns
    -------
    None
        The formatted columns are printed directly to the console.

    Examples
    --------
    Print columns with default formatting:

    >>> from fbpyutils_db.visualization.display import print_columns
    >>> cols = ['Name', 'Age', 'Address']
    >>> print_columns(cols)
    Name, Age, Address

    Print normalized columns with quotes:

    >>> print_columns(cols, normalize=True, quotes=True)
    'name', 'age', 'address'

    Print columns with fixed length:

    >>> print_columns(cols, length=10)
    Name      , Age       , Address

    Notes
    -----
    - Columns are separated by commas and spaces
    - Uses `normalize_columns` for normalization when enabled
    - Padding is applied to the right of each column name
    - The output is suitable for use in SQL queries

    See Also
    --------
    normalize_columns : Normalize column names
    print_ascii_table_from_dataframe : Print DataFrame as ASCII table
    """
    logger.debug(
        f"Printing {len(cols)} columns with options: normalize={normalize}, length={length}, quotes={quotes}"
    )

    if normalize:
        logger.debug("Normalizing column names")
        cols = normalize_columns(cols)

    if quotes:
        logger.debug("Adding quotes to column names")
        cols = [f"'{c}'" for c in cols]

    length = length or max([len(c) for c in cols])
    logger.debug(f"Using column length: {length}")

    colstrings = ", ".join([c.ljust(length, " ") for c in cols])

    logger.info(f"Columns: {colstrings}")
    print(colstrings)
