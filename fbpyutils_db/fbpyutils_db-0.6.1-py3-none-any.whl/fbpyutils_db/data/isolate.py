import pandas as pd
from typing import List

from fbpyutils_db import logger


def isolate(df: pd.DataFrame, group_columns: List[str]):
    """Filter DataFrame to rows with maximum 'Unique' value per group.

    This function groups the DataFrame by the specified columns and selects
    the row with the maximum value in the 'Unique' column for each group.
    This is useful for deduplicating data while keeping the most recent
    or highest-priority record.

    Parameters
    ----------
    df : pd.DataFrame
        The input pandas DataFrame.
    group_columns : list of str
        A list of column names used for grouping the DataFrame.

    Returns
    -------
    pd.DataFrame
        A DataFrame containing only the rows with maximum 'Unique' values
        for each unique combination of values in `group_columns`.

    Examples
    --------
    Isolate rows with maximum 'Unique' value per group:

    >>> import pandas as pd
    >>> from fbpyutils_db.data.isolate import isolate
    >>> df = pd.DataFrame({'Group': ['A', 'A', 'B', 'B'],
    ...                    'Value': [1, 2, 3, 4],
    ...                    'Unique': [5, 6, 7, 8]})
    >>> isolate(df, ['Group'])
      Group  Value  Unique
    1     A      2       6
    3     B      4       8

    Handle empty DataFrame:

    >>> df = pd.DataFrame()
    >>> isolate(df, ['Group'])
    Empty DataFrame
    Columns: []
    Index: []

    Notes
    -----
    - The function requires a 'Unique' column in the DataFrame
    - Uses `groupby()` and `idxmax()` to find the row with maximum value
    - The index of the result DataFrame is reset
    - Empty DataFrames are returned unchanged

    See Also
    --------
    pandas.DataFrame.groupby : Group DataFrame using a mapper
    pandas.DataFrame.idxmax : Return index of first occurrence of maximum
    """
    logger.debug(f"Starting isolate operation with group_columns: {group_columns}")
    logger.debug(f"Input DataFrame shape: {df.shape}")

    # Handle empty DataFrame case
    if df.empty:
        logger.debug("Input DataFrame is empty, returning empty DataFrame")
        return df.copy()

    # Find the index of the row with the maximum 'Unique' value for each group
    idx = df.groupby(group_columns)["Unique"].idxmax()

    result = df.loc[idx].reset_index(drop=True)
    logger.info(f"Isolate operation completed. Result DataFrame shape: {result.shape}")

    return result
