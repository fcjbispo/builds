"""Data processing and conversion utilities.

This module provides functions for data type conversion, extraction, normalization,
and isolation operations on pandas DataFrames. These utilities are essential for
preparing data for database operations and ensuring data consistency.

Modules
-------
converters
    Type conversion functions for various data types.
extract
    Data extraction utilities from DataFrames.
isolate
    Data isolation and filtering functions.
normalize
    Column name normalization and capitalization.

Functions
---------
is_nan_or_empty
    Check if a value is NaN, None, or empty.
as_boolean
    Convert value to boolean type.
as_datetime
    Convert value to datetime type.
as_date
    Convert value to date type.
as_float
    Convert value to float type.
as_integer
    Convert value to integer type.
as_string
    Convert value to string type.
as_string_id
    Convert value to string ID (removing special characters).
as_dict
    Convert JSON string to dictionary.
get_data_from_pandas
    Extract data and columns from DataFrame.
isolate
    Filter DataFrame to isolate rows with maximum values.
normalize_columns
    Normalize column names by removing special characters.
capitalize
    Capitalize DataFrame column names.

Examples
--------
Type conversion:

>>> from fbpyutils_db.data.converters import as_integer, as_float, as_datetime
>>> as_integer("42")
42
>>> as_float("3.14")
3.14
>>> as_datetime("2023-01-01")
Timestamp('2023-01-01 00:00:00')

Data extraction:

>>> from fbpyutils_db.data.extract import get_data_from_pandas
>>> import pandas as pd
>>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
>>> data, columns = get_data_from_pandas(df)
>>> print(data)
[[1, 3], [2, 4]]
>>> print(columns)
['A', 'B']

Column normalization:

>>> from fbpyutils_db.data.normalize import normalize_columns, capitalize
>>> normalize_columns(['Name!', 'Age@', '#Address'])
['name', 'age', 'address']
>>> df = pd.DataFrame({'Name': [1], 'Age': [2]})
>>> capitalize(df, 'upper')
   NAME  AGE
0     1    2

Notes
-----
- Type conversion functions handle NaN values gracefully
- Column normalization removes special characters and converts to lowercase
- Data extraction supports optional index inclusion
- All functions are designed to work with pandas DataFrames

See Also
--------
pandas.DataFrame : Primary data structure for tabular data
pandas.to_datetime : Pandas datetime conversion
pandas.to_numeric : Pandas numeric conversion
"""