"""FBPyUtils-DB: Database utilities for data manipulation.

This package provides comprehensive utilities for database operations, data
processing, hashing, and visualization. It is designed to simplify common
tasks when working with pandas DataFrames and SQL databases.

The package supports multiple database backends (PostgreSQL, Oracle, SQLite)
through SQLAlchemy and provides utilities for:
- Database table operations (append, upsert, replace)
- Data type conversion and validation
- Hash-based column and index generation
- Schema management and validation
- ASCII table visualization

Modules
-------
database
    Database operations including table creation, upsert, and batch operations.
    Supports PostgreSQL, Oracle, and SQLite through SQLAlchemy.
data
    Data processing utilities including type conversion, extraction, normalization,
    and isolation operations.
hashing
    Hash generation utilities for creating hash columns and indices from DataFrame values.
utils
    Internal utility functions for NaN handling and column validation.
visualization
    ASCII table generation and display utilities for console output.

Examples
--------
Database operations:

>>> from fbpyutils_db.database.operations import table_operation
>>> import pandas as pd
>>> from sqlalchemy import create_engine
>>>
>>> engine = create_engine("sqlite:///test.db")
>>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
>>> result = table_operation('append', df, engine, 'users')

Hash generation:

>>> from fbpyutils_db.hashing import add_hash_column
>>> df_hashed = add_hash_column(df, 'hash_id', length=12)

Data conversion:

>>> from fbpyutils_db.data.converters import as_integer, as_datetime
>>> as_integer("42")
42
>>> as_datetime("2023-01-01")
Timestamp('2023-01-01 00:00:00')

Visualization:

>>> from fbpyutils_db.visualization.display import print_ascii_table_from_dataframe
>>> print_ascii_table_from_dataframe(df, alignment='center')

Notes
-----
- Requires Python >=3.11,<4.0
- Uses SQLAlchemy for database abstraction
- Supports pandas and polars DataFrames
- Automatic NaN handling in database operations
- Structured logging with context fields for observability

Environment Variables
---------------------
DB_SQLITE_URL : SQLite connection string
DB_PG_URL : PostgreSQL connection string
DB_ORA_URL : Oracle connection string

See Also
--------
sqlalchemy : Python SQL toolkit and ORM
pandas : Data manipulation library
polars : High-performance DataFrame library
"""

import os
import fbpyutils

from dotenv import load_dotenv

_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

fbpyutils.setup(os.path.sep.join([_ROOT_DIR, "app.json"]))

env = fbpyutils.get_env()
logger = fbpyutils.get_logger()
