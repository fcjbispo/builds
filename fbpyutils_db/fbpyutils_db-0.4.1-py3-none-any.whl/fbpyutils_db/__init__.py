"""fbpyutils_db: Package providing utilities for database operations, data extraction, normalization, hashing, and visualization.

This package provides comprehensive utilities for database operations including:
- Database operations (create tables, indexes, manage data)
- Data extraction and isolation from various sources
- Data normalization and validation
- Hashing capabilities for columns and indexes
- Visualization tools for displaying data

The package includes support for multiple database dialects (PostgreSQL, Oracle, Firebird, SQLite)
and provides flexible key generation options (Snowflake, UUID, hash-based keys).

Dependencies:
    - pandas: Data manipulation and analysis
    - sqlalchemy: Database toolkit and ORM
    - psycopg2-binary: PostgreSQL adapter
    - oracledb: Oracle database adapter
    - firebird-driver: Firebird database adapter
    - fdb: Alternative Firebird adapter
    - pyperclip: Clipboard utilities

Main Modules:
    database: Database operations and dialect management
    data: Data extraction, isolation, and normalization
    hashing: Column and index hashing utilities
    visualization: Data visualization tools
    utils: Utility functions for data handling

Example usage:
    import fbpyutils_db
    
    # Setup logger and environment
    env = fbpyutils_db.env
    logger = fbpyutils_db.logger
    
    # Use database operations
    from fbpyutils_db.database import create_table, create_index
    
    # Use data utilities
    from fbpyutils_db.data import extract_data, normalize_columns
    
    # Use hashing utilities
    from fbpyutils_db.hashing import add_hash_column, add_hash_index
    
    # Use visualization utilities
    from fbpyutils_db.visualization import print_ascii_table_from_dataframe

Note:
    This package requires Python 3.11 or higher.
    Some database adapters may require additional system dependencies.
    See individual module documentation for specific requirements.

See Also:
    fbpyutils: Core utilities package
    sqlalchemy: Database toolkit
    pandas: Data analysis library
"""
import os

import fbpyutils

# Setup logger and environment first
try:
    fbpyutils.setup(os.path.join(os.path.dirname(__file__), "app.json"))
    env = fbpyutils.get_env()
    logger = fbpyutils.get_logger()
    
    logger.info("fbpyutils_db package initialized successfully")
    logger.debug(f"Environment: {env.get('environment', 'unknown')}")
    logger.debug(f"Log level: {env.get('log_level', 'unknown')}")
    
except Exception as e:
    # Fallback logger if setup fails
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    logger.error(f"Failed to initialize fbpyutils: {e}")
    logger.warning("Using fallback logging configuration")
    env = {}
