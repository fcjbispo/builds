import pandas as pd
from sqlalchemy import Engine, MetaData, Table, text, inspect, JSON
from sqlalchemy.sql import exists
from typing import Any, Dict, List, Optional

from fbpyutils_db import logger

# Importa funções de outros módulos
from fbpyutils_db.utils.nan_handler import deal_with_nans
from fbpyutils_db.database.table import create_table
import json
import hashlib
import uuid


def table_operation(
    operation: str,
    dataframe: pd.DataFrame,
    engine: Engine,
    table_name: str,
    schema: Optional[str] = None,
    keys: list[str] = [],
    index: str = "",
    commit_at: int = 50,
    parallel: bool = False,
    max_workers: Optional[int] = None,
    key_type: Optional[str] = None,
) -> Dict[str, Any]:
    logger.info(f"Starting table operation: {operation}")
    logger.debug(f"Table: {table_name}, Schema: {schema}")

    schema_norm = schema or None
    logger.debug(f"Keys: {keys}, Index: {index}, Commit at: {commit_at}")

    if operation not in ("append", "upsert", "replace"):
        logger.error(f"Invalid operation: {operation}")
        raise ValueError("Invalid operation. Valid values: append|upsert|replace.")

    if not isinstance(dataframe, pd.DataFrame):
        logger.error("Invalid DataFrame type provided")
        raise ValueError("Dataframe must be a Pandas DataFrame.")

    logger.debug(f"DataFrame shape: {dataframe.shape}")

    if operation == "upsert" and not keys:
        logger.error("Missing keys parameter for upsert operation")
        raise ValueError("For upsert operation 'keys' parameter is mandatory.")

    if keys and not isinstance(keys, list):
        logger.error("Invalid keys type provided")
        raise ValueError("Parameters 'keys' must be a list of str.")

    if keys and index and index not in ("standard", "unique", "primary"):
        logger.error(f"Invalid index type: {index}")
        raise ValueError(
            "If an index will be created, it must be any of standard|unique|primary."
        )

    if not isinstance(commit_at, int) or commit_at < 1:
        logger.error(f"Invalid commit_at value: {commit_at}")
        raise ValueError("Commit At must be a positive integer.")

    if not isinstance(parallel, bool):
        logger.error(f"Invalid parallel type: {parallel}")
        raise ValueError("Parallel must be a boolean value.")

    if key_type is not None and key_type not in ("hash", "snowflake", "uuid"):
        logger.error(f"Invalid key_type: {key_type}")
        raise ValueError("Parameter 'key_type' must be any of hash|snowflake|uuid.")

    table_exists = inspect(engine).has_table(table_name, schema=schema_norm)
    logger.debug(f"Table '{table_name}' exists: {table_exists}")

    if not table_exists:
        logger.info(f"Creating table '{table_name}' as it doesn't exist")
        create_table(
            dataframe, engine, table_name, schema_norm, keys, index, key_type=key_type
        )

    metadata = MetaData(schema_norm)
    table = Table(table_name, metadata, autoload_with=engine)

    inserts = 0
    updates = 0
    skips = 0
    processed_rows = 0
    failures = []

    logger.info(f"Starting {operation} operation on {len(dataframe)} rows")

    total_rows = len(dataframe)

    try:
        with engine.connect() as conn:
            step = "drop table"
            if operation == "replace":
                logger.info("Performing replace operation - clearing table")
                conn.execute(table.delete())
                conn.commit()
                logger.debug("Table cleared successfully")

            if parallel:
                if max_workers is None:
                    import os

                    max_workers = min(32, (os.cpu_count() or 1) + 4)

                logger.info(
                    f"Processing {total_rows} rows in parallel with {max_workers} workers"
                )
                from concurrent.futures import ThreadPoolExecutor

                def process_row(
                    row_data,
                    row_idx,
                    table,
                    keys,
                    operation,
                    engine,
                    dataframe,
                    key_type,
                ):
                    import json
                    import hashlib
                    import uuid
                    from sqlalchemy import JSON
                    values = {}
                    try:
                        values = {
                            col: deal_with_nans(row_data[col])
                            for col in dataframe.columns
                        }
                        
                        # Handle JSON serialization based on column type
                        for col in dataframe.columns:
                            if col in table.columns:
                                col_obj = table.c[col]
                                col_type = col_obj.type
                                value = values[col]
                                if isinstance(value, (dict, list)):
                                    if isinstance(col_type, JSON):
                                        # Let SQLAlchemy handle serialization for native JSON
                                        pass
                                    else:
                                        # Manual serialization to string for TEXT columns
                                        values[col] = json.dumps(value, ensure_ascii=False)
                                else:
                                    values[col] = value
                            else:
                                # Fallback for columns not in table (should not happen)
                                value = values[col]
                                if isinstance(value, (dict, list)):
                                    values[col] = json.dumps(value, ensure_ascii=False)

                        # Parallel key generation support
                        if key_type:
                            key_name = {"snowflake": "snowflake_id", "uuid": "uuid_key", "hash": "hash_key"}[key_type]
                            if key_name not in values:
                                if key_type == "snowflake":
                                    try:
                                        from fbpyutils.uuid import Snowflake
                                        key_value = str(Snowflake(0, 0).next_id())
                                    except ImportError:
                                        key_value = f"{row_idx}1000000000000000"
                                elif key_type == "uuid":
                                    try:
                                        from fbpyutils.uuid import uuid as gen_uuid
                                        key_value = str(gen_uuid())
                                    except ImportError:
                                        key_value = str(uuid.uuid4())
                                else:  # hash
                                    row_content = json.dumps(row_data.to_dict(), sort_keys=True)
                                    key_value = hashlib.md5(row_content.encode()).hexdigest()[:12]
                                values[key_name] = key_value

                        # Generate key if key_type specified
                        if key_type is not None and key_type in (
                            "hash",
                            "snowflake",
                            "uuid",
                        ):
                            key_name = {
                                "snowflake": "snowflake_id",
                                "uuid": "uuid_key",
                                "hash": "hash_key",
                            }[key_type]
                            if key_name not in values:
                                logger.debug(
                                    f"Generating {key_type} key for row {row_idx}"
                                )
                                if key_type == "snowflake":
                                    try:
                                        from fbpyutils.uuid import Snowflake

                                        sf = Snowflake(worker_id=0, datacenter_id=0)
                                        key_value = str(sf.next_id())
                                    except ImportError:
                                        key_value = f"{row_idx}1000000000000000"
                                elif key_type == "uuid":
                                    try:
                                        from fbpyutils.uuid import uuid as generate_uuid

                                        key_value = str(generate_uuid())
                                    except ImportError:
                                        key_value = str(uuid.uuid4())
                                else:
                                    row_content = json.dumps(
                                        row_data.to_dict(), sort_keys=True
                                    )
                                    key_value = hashlib.md5(
                                        row_content.encode()
                                    ).hexdigest()[:12]
                                values[key_name] = key_value

                        row_exists = False
                        if keys:
                            exists_query = (
                                table.select()
                                .where(
                                    text(
                                        " AND ".join(
                                            [f"{col} = :{col}" for col in keys]
                                        )
                                    )
                                )
                                .params(**{k: values.get(k) for k in keys})
                            )
                            # Fix: properly close connection after check to avoid leaks
                            with engine.connect() as check_conn:
                                row_exists = check_conn.execute(exists_query).fetchone() is not None

                        if row_exists:
                            if operation == "upsert":
                                update_values = {
                                    k: values[k] for k in values if k not in keys
                                }
                                # Create parameter names that don't conflict with column names
                                param_names = {k: f"param_{k}" for k in keys}
                                where_clause = " AND ".join([f"{col}=:{param}" for col, param in param_names.items()])
                                
                                update_stmt = (
                                    table.update()
                                    .where(text(where_clause))
                                    .values(**update_values)
                                )
                                # Map values to non-conflicting parameter names
                                param_values = {param_names[k]: values[k] for k in keys}
                                param_values.update(update_values)
                                with engine.connect() as worker_conn:
                                    worker_conn.execute(update_stmt, param_values)
                                    worker_conn.commit()  # Fix: explicit commit for Oracle compatibility
                                return ("update", row_idx)
                            return ("skip", row_idx)
                        else:
                            insert_stmt = table.insert().values(**values)
                            with engine.connect() as worker_conn:
                                worker_conn.execute(insert_stmt)
                                worker_conn.commit()  # Fix: explicit commit for Oracle compatibility
                            return ("insert", row_idx)
                    except Exception as e:
                        return ("error", row_idx, str(e))

                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [
                        executor.submit(
                            process_row,
                            row,
                            i,
                            table,
                            keys,
                            operation,
                            engine,
                            dataframe,
                            key_type,
                        )
                        for i, row in dataframe.iterrows()
                    ]
                    for future in futures:
                        result = future.result()
                        if result[0] == "insert":
                            inserts += 1
                        elif result[0] == "update":
                            updates += 1
                        elif result[0] == "skip":
                            skips += 1
                        else:
                            # Handle error result: ('error', row_idx, error_message)
                            failures.append({
                                "step": "parallel_processing",
                                "row": result[1] if len(result) > 1 else None,
                                "error": result[2] if len(result) > 2 else "Unknown error"
                            })

            else:
                rows = 0
                step = "prepare"
                for i, row in dataframe.iterrows():
                    values = {}
                    try:
                        values = {
                            col: deal_with_nans(row[col]) for col in dataframe.columns
                        }
                        
                        # Convert dict values to JSON strings for database storage
                        for col, value in values.items():
                            if isinstance(value, dict):
                                values[col] = json.dumps(value, ensure_ascii=False)
                            elif isinstance(value, list):
                                values[col] = json.dumps(value, ensure_ascii=False)

                        logger.debug(f"Processing row {i}/{total_rows}: {values}")

                        if operation == "append" and key_type is not None:
                            auto_key_names = {
                                "snowflake": "snowflake_id",
                                "uuid": "uuid_key",
                                "hash": "hash_key",
                            }
                            expected_auto_key = auto_key_names.get(key_type)
                            check_keys = [k for k in keys if k != expected_auto_key]
                        else:
                            check_keys = keys

                        if key_type is not None and key_type in (
                            "hash",
                            "snowflake",
                            "uuid",
                        ):
                            key_name = {
                                "snowflake": "snowflake_id",
                                "uuid": "uuid_key",
                                "hash": "hash_key",
                            }[key_type]
                            if key_name not in values:
                                logger.debug(f"Generating {key_type} key for row {i}")
                                if key_type == "snowflake":
                                    try:
                                        from fbpyutils.uuid import Snowflake

                                        sf = Snowflake(worker_id=0, datacenter_id=0)
                                        key_value = str(sf.next_id())
                                    except ImportError:
                                        key_value = f"{i}1000000000000000"
                                elif key_type == "uuid":
                                    try:
                                        from fbpyutils.uuid import uuid as generate_uuid

                                        key_value = str(generate_uuid())
                                    except ImportError:
                                        key_value = str(uuid.uuid4())
                                else:
                                    row_content = json.dumps(
                                        row.to_dict(), sort_keys=True
                                    )
                                    key_value = hashlib.md5(
                                        row_content.encode()
                                    ).hexdigest()[:12]
                                values[key_name] = key_value

                        step = "check existence"
                        row_exists = False
                        values = values or {}  # Ensure values for mypy
                        if check_keys:
                            exists_query = (
                                table.select()
                                .where(
                                    text(
                                        " AND ".join(
                                            [f"{col} = :{col}" for col in check_keys]
                                        )
                                    )
                                )
                                .params(**{k: values.get(k) for k in check_keys})
                            )
                            row_exists = (
                                conn.execute(exists_query).fetchone() is not None
                            )

                        if row_exists:
                            if operation == "upsert":
                                step = "update"
                                update_values = {
                                    k: values[k] for k in values if k not in keys
                                }
                                # Create parameter names that don't conflict with column names
                                param_names = {k: f"param_{k}" for k in keys}
                                where_clause = " AND ".join([f"{col}=:{param}" for col, param in param_names.items()])
                                
                                update_stmt = (
                                    table.update()
                                    .where(text(where_clause))
                                    .values(**update_values)
                                )
                                # Map values to non-conflicting parameter names
                                param_values = {param_names[k]: values[k] for k in keys}
                                param_values.update(update_values)
                                conn.execute(update_stmt, param_values)
                                updates += 1
                            else:
                                skips += 1
                        else:
                            step = "insert"
                            insert_stmt = table.insert().values(**values)
                            conn.execute(insert_stmt)
                            inserts += 1

                        rows += 1
                        processed_rows += 1

                        if rows >= commit_at:
                            conn.commit()
                            rows = 0

                        if processed_rows % 100 == 0:
                            logger.info(f"Processed {processed_rows}/{total_rows} rows")

                    except Exception as e:
                        logger.error(f"Error processing row {i}/{total_rows}: {str(e)}")
                        failures.append({"step": step, "row": i, "error": str(e)})
                        conn.rollback()
                        continue

                conn.commit()

            logger.info(f"Operation completed. Total processed: {processed_rows}")

    except Exception as e:
        logger.error(f"Critical error in table operation: {str(e)}")
        failures.append({"step": "critical", "row": None, "error": str(e)})

    result = {
        "operation": operation,
        "table_name": f"{schema_norm}.{table_name}" if schema_norm else table_name,
        "insertions": inserts,
        "updates": updates,
        "skips": skips,
        "failures": failures,
    }

    logger.info(
        f"Operation summary: {inserts} inserts, {updates} updates, {skips} skips, {len(failures)} failures"
    )

    if failures:
        logger.warning(f"Operation completed with {len(failures)} failures")
        for failure in failures[:5]:
            logger.warning(f"Failure: {failure}")

    return result
