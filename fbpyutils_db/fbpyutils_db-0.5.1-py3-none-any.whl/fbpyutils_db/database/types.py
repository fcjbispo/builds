import pandas as pd
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON
from sqlalchemy.dialects.oracle import CLOB
from sqlalchemy.sql.sqltypes import TypeEngine
from typing import List, Optional

from fbpyutils_db.database.dialects import get_dialect
from fbpyutils_db import logger


def detect_json_columns(dataframe: pd.DataFrame, max_samples: int = 10) -> List[str]:
    """
    Detect columns that contain dictionary values (JSON data).

    Args:
        dataframe: Input DataFrame to scan.
        max_samples: Maximum number of rows to sample for detection.

    Returns:
        List[str]: Names of columns containing dictionaries.

    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({'a': [1, 2], 'json_col': [{"key": "val1"}, {"key": "val2"}]})
        >>> detect_json_columns(df)
        ['json_col']
    """
    logger.debug(f"Detecting JSON columns in DataFrame with {len(dataframe)} rows")

    json_columns = []

    if dataframe.empty:
        return json_columns

    # Sample rows for efficiency with large DataFrames
    sample_df = (
        dataframe.head(max_samples)
        if len(dataframe) <= max_samples
        else dataframe.sample(max_samples)
    )

    for col in dataframe.columns:
        if dataframe.dtypes[col] == "object":
            # Check if any value in this column is a dict
            try:
                # Use a more robust approach to check for dictionaries
                has_dicts = False
                for val in sample_df[col]:
                    if isinstance(val, dict) and val is not None:
                        has_dicts = True
                        break
                if has_dicts:
                    json_columns.append(col)
                    logger.debug(f"Column '{col}' identified as JSON column")
            except Exception as e:
                logger.warning(f"Error checking column '{col}' for dicts: {e}")
                continue

    logger.info(f"Detected {len(json_columns)} JSON columns: {json_columns}")
    return json_columns


def get_columns_types(
    dataframe: pd.DataFrame, primary_keys: List[str] = [], engine=None
) -> List[Column]:
    """
    Generate SQLAlchemy Column objects from a DataFrame's columns, marking primary keys.

    Infers SQLAlchemy types based on Pandas dtypes, including JSON for dictionary columns,
    and applies primary key constraints..

    Args:
        dataframe: Input DataFrame to derive column definitions from.
        primary_keys: List of column names to set as primary keys. Defaults to empty list.
        engine: SQLAlchemy engine to detect dialect-specific limitations.

    Returns:
        List[Column]: List of SQLAlchemy Column objects for table creation.

    Details:
        Automatically detects columns containing dictionaries and maps them to JSON type
        for dialects that support native JSON (PostgreSQL, Oracle). Falls back to TEXT
        for SQLite and Firebird.

    Example:
        >>> import pandas as pd
        >>> from sqlalchemy import Column, Integer, String, JSON
        >>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob'], 'config': [{"key": "val1"}, {"key": "val2"}]})
        >>> columns = get_columns_types(df, primary_keys=['id'])
        >>> isinstance(columns[0], Column) and columns[0].primary_key
        True
        >>> isinstance(columns[2].type, JSON) or isinstance(columns[2].type, String)
        True
        # Creates columns with 'id' as primary key, 'name' as String, 'config' as JSON/String.
    """
    logger.debug(
        f"Getting column types for DataFrame with {len(dataframe.columns)} columns"
    )
    logger.debug(f"Primary keys: {primary_keys}")

    # Detect JSON columns before processing
    json_columns = detect_json_columns(dataframe)
    logger.debug(f"JSON columns detected: {json_columns}")

    columns = []
    for col in dataframe.columns:
        col_type = get_column_type(dataframe.dtypes[col], col, json_columns, primary_keys, engine)
        is_primary = col in primary_keys
        logger.debug(f"Column '{col}': type={col_type}, primary_key={is_primary}")
        columns.append(
            Column(
                col,
                col_type,
                primary_key=is_primary,
            )
        )

    logger.info(f"Generated {len(columns)} column definitions")
    return columns


def get_column_type(
    dtype: str, column_name: str = "", json_columns: List[str] = [],
    primary_keys: List[str] = [], engine=None
) -> TypeEngine:
    """
    Convert Pandas dtype to corresponding SQLAlchemy TypeEngine, with JSON detection for dictionaries.

    Maps common Pandas types to SQLAlchemy equivalents. Detects columns containing dictionaries
    and maps to JSON type. Defaults to String(4000) for unknowns. For Firebird, applies size
    limitations for columns that will be used as keys.

    Args:
        dtype: Pandas dtype string (e.g., 'int64', 'object').
        column_name: Name of the column (used for JSON detection).
        json_columns: List of columns identified as containing JSON data.
        primary_keys: List of column names that will be primary keys.
        engine: SQLAlchemy engine to detect dialect-specific limitations.

    Returns:
        TypeEngine: SQLAlchemy type instance.

    Details:
        - Automatically maps dictionary columns to JSON for supported dialects
        - Falls back to String for dialects without native JSON support
        - String type includes length hint for better database performance
        - For Firebird, limits String size to 252 bytes for columns used as keys

    Example:
        >>> from sqlalchemy.sql.sqltypes import Integer, String, JSON
        >>> get_column_type('int64')
        Integer()
        >>> get_column_type('object', 'config', json_columns=['config'])
        JSON()
        >>> get_column_type('object', 'name', json_columns=[])
        String(4000)
        # Maps integer to Integer(), dict to JSON, and other object to String.
    """
    logger.debug(f"Mapping pandas dtype '{dtype}' to SQLAlchemy type")
    logger.debug(f"Column name: {column_name}, JSON columns: {json_columns}")
    logger.debug(f"Primary keys: {primary_keys}")

    # Check if this column contains JSON data
    is_json_column = column_name in json_columns
    logger.debug(f"Column '{column_name}' identified as JSON: {is_json_column}")
    
    # Check if this column will be a key (primary key only)
    is_key_column = column_name in primary_keys
    logger.debug(f"Column '{column_name}' is key column: {is_key_column}")
    
    # Check if we're using Firebird dialect
    is_firebird = False
    supports_native_json = True
    dialect_name = None  # Initialize dialect_name
    if engine:
        try:
            dialect_name = engine.dialect.name
            is_firebird = dialect_name == "firebird"
            # Determine JSON support based on dialect
            if dialect_name in ["sqlite", "firebird"]:
                supports_native_json = False
            elif dialect_name in ["postgresql", "oracle"]:
                supports_native_json = True
            else:
                supports_native_json = False
                logger.warning(f"Unknown dialect: {dialect_name}, defaulting to no JSON support")
            logger.debug(f"Detected dialect: {dialect_name}, supports JSON: {supports_native_json}")
        except Exception as e:
            logger.warning(f"Could not detect dialect: {e}")
            supports_native_json = True

    if dtype in ("int64", "int32", "int"):
        sql_type = Integer()
    elif dtype in ("float64", "float32", "float"):
        sql_type = Float()
    elif dtype == "bool":
        sql_type = Boolean()
    elif dtype == "object":
        if is_json_column:
            if supports_native_json:
                # For Oracle, use CLOB with IS JSON constraint for reliable JSON support
                if dialect_name == "oracle":
                    sql_type = CLOB()
                    logger.debug(f"Mapped '{column_name}' to CLOB type (Oracle JSON with IS JSON constraint)")
                else:
                    sql_type = JSON()
                    logger.debug(f"Mapped '{column_name}' to JSON type (native support)")
            else:
                sql_type = String(4000)
                logger.debug(f"Mapped '{column_name}' to String(4000) (no native JSON)")
        else:
            # For Firebird, limit string size for key columns to avoid index size restrictions
            if is_firebird and is_key_column:
                sql_type = String(250)  # 250 chars to stay under 252 byte limit with UTF-8
                logger.debug(f"Firebird: Limited '{column_name}' to String(250) for key column")
            else:
                sql_type = String(4000)
    elif dtype == "datetime64[ns]":
        sql_type = DateTime()
    else:
        logger.warning(f"Unknown pandas dtype '{dtype}', defaulting to String(4000)")
        # If it's an unknown dtype but column was detected as JSON, use appropriate type
        if is_json_column:
            if supports_native_json:
                # For Oracle, use CLOB with IS JSON constraint for reliable JSON support
                if dialect_name == "oracle":
                    sql_type = CLOB()
                else:
                    sql_type = JSON()
            else:
                sql_type = String(4000)
        else:
            # For Firebird, limit string size for key columns to avoid index size restrictions
            if is_firebird and is_key_column:
                sql_type = String(250)
                logger.debug(f"Firebird: Limited '{column_name}' to String(250) for key column")
            else:
                sql_type = String(4000)

    logger.debug(f"Mapped '{column_name}' to {type(sql_type).__name__}")
    return sql_type
