import pandas as pd
from sqlalchemy import (
    Engine,
    MetaData,
    Table,
    ForeignKeyConstraint,
    UniqueConstraint,
    CheckConstraint,
    Index,
)
import json
from typing import List, Optional

from fbpyutils_db import logger

# Importa funções de outros módulos
from fbpyutils_db.database.dialects import get_dialect
from fbpyutils_db.database.types import get_columns_types


def generate_sample_key(key_type: str) -> str:
    """Generate sample key for schema inference"""
    if key_type == "snowflake":
        try:
            from fbpyutils.uuid import Snowflake

            return str(Snowflake(worker_id=0, datacenter_id=0).next_id())
        except ImportError:
            return "1234567890123456789"
    elif key_type == "uuid":
        try:
            from fbpyutils.uuid import uuid as generate_uuid

            return str(generate_uuid())
        except ImportError:
            return "12345678-1234-1234-1234-123456789abc"
    else:
        return "cc6c0100dfad4851"


def get_key_column_name_and_type(key_type: str) -> tuple[str, str]:
    """Get column name and type for generated key"""
    if key_type == "snowflake":
        return ("snowflake_id", "Integer")
    elif key_type == "uuid":
        return ("uuid_key", "String(40)")
    else:
        return ("hash_key", "String(16)")


def create_table(
    dataframe: pd.DataFrame,
    engine: Engine,
    table_name: str,
    schema: Optional[str] = None,
    keys: Optional[List[str]] = None,
    index: Optional[str] = None,
    foreign_keys: Optional[List[dict]] = None,
    constraints: Optional[List[dict]] = None,
    metadata: Optional[MetaData] = None,
    key_type: Optional[str] = None,
) -> None:
    """
    Create a database table from a DataFrame schema, optionally with indexes, foreign keys, constraints
    and flexible key generation (Snowflake, UUID, or Hash).

    Infers column types from the DataFrame and creates the table structure. Supports primary keys,
    standard/unique indexes, and dialect-specific constraints. Also supports flexible key generation
    including Snowflake IDs, UUIDs, and hash-based keys.

    Args:
        dataframe: Pandas DataFrame defining the table schema.
        engine: SQLAlchemy database engine.
        table_name: Name of the table to create.
        schema: Optional schema name.
        keys: List of primary key column names.
        key_type: Key generation type ('hash', 'snowflake', 'uuid'). If not specified, uses values from keys columns. Defaults to None.
        index: Index type on keys ('standard', 'unique', or 'primary'). Defaults to None.
        foreign_keys: List of foreign key definitions as dicts.
        constraints: List of constraint definitions as dicts.
        metadata: Optional SQLAlchemy MetaData object.

    Returns:
        None

    Raises:
        ValueError: For invalid DataFrame, keys, or index type.

    Example:
        >>> import pandas as pd
        >>> from sqlalchemy import create_engine
        >>> df = pd.DataFrame({'id': [1], 'name': ['Test']})
        >>> engine = create_engine('sqlite:///:memory:')
        >>> create_table(df, engine, 'test_table', keys=['id'], index='primary')
        # Creates 'test_table' with 'id' as primary key.
    """
    logger.info(f"Creating table '{table_name}' in schema '{schema}'")

    # Initialize optional parameters
    if keys is None:
        keys = []
    if foreign_keys is None:
        foreign_keys = []
    if constraints is None:
        constraints = []

    # Configure Oracle JSON support if needed
    try:
        if engine.dialect.name == "oracle":
            # Configure JSON serializers for Oracle to handle JSON compilation issues
            if not hasattr(engine.dialect, '_json_serializer'):
                engine.dialect._json_serializer = lambda obj: json.dumps(obj, ensure_ascii=False)
            if not hasattr(engine.dialect, '_json_deserializer'):
                engine.dialect._json_deserializer = lambda obj: json.loads(obj)
            logger.debug("Configured Oracle JSON serializers")
    except Exception as e:
        logger.warning(f"Could not configure Oracle JSON support: {e}")

    # Get dialect instance
    dialect = get_dialect(engine)

    # Check parameters
    if not isinstance(dataframe, pd.DataFrame):
        logger.error("Invalid dataframe type provided")
        raise ValueError("Dataframe must be a Pandas DataFrame.")
    
    # Work with a copy to avoid modifying the original DataFrame
    dataframe_copy = dataframe.copy()
    

    if keys and not isinstance(keys, list):
        logger.error("Invalid keys type provided")
        raise ValueError("Parameters 'keys' must be a list of str.")

    if keys and index and index not in ("standard", "unique", "primary"):
        logger.error(f"Invalid index type: {index}")
        raise ValueError(
            "If an index will be created, it must be any of standard|unique|primary."
        )

    logger.debug(f"Creating table with keys: {keys}, index type: {index}")

    # Handle flexible key generation if key_type specified (Fase 4.3.1)
    if key_type is not None:
        if key_type not in ("hash", "snowflake", "uuid"):
            logger.error(f"Invalid key_type: {key_type}")
            raise ValueError("Parameter 'key_type' must be any of hash|snowflake|uuid.")

        logger.info(f"Using key_type='{key_type}' for automatic key generation")

        # Debug: Show current DataFrame state
        logger.debug(
            f"DataFrame columns before key type handling: {list(dataframe_copy.columns)}"
        )

        # Generate sample data for a key column based on key_type
        example_key_value = generate_sample_key(key_type)

        # Determine appropriate key column name and type
        key_name, key_type_sql = get_key_column_name_and_type(key_type)

        # Add generated key column to DataFrame with sample value
        # Only add if the column doesn't already exist in the DataFrame
        if key_name not in dataframe_copy.columns:
            dataframe_copy[key_name] = example_key_value
            logger.debug(f"Added {key_name} column to DataFrame")
        else:
            logger.warning(
                f"Column {key_name} already exists in DataFrame, skipping duplicate column creation"
            )

        logger.info(
            f"DataFrame columns after key type handling: {list(dataframe_copy.columns)}"
        )

        # Add key to keys list for table schema (only if no keys are provided)
        if not keys:
            keys = [key_name]
            logger.info(f"Added auto-generated key column '{key_name}' as primary key")
        else:
            logger.info(
                f"Using existing keys {keys}. Auto-generated key column '{key_name}' will be added as a regular column."
            )

        logger.debug(
            f"DataFrame updated with key column '{key_name}': {example_key_value[:8]}..."
        )

    # Use provided metadata or create a new one
    if metadata is None:
        metadata = MetaData(schema=schema)
    elif schema is not None:
        logger.warning("Schema parameter ignored when metadata is provided")

    # Get column definitions
    if keys and index == "primary":
        columns = get_columns_types(dataframe_copy, primary_keys=keys, engine=engine)
    else:
        columns = get_columns_types(dataframe_copy, primary_keys=[], engine=engine)

    # Create table
    table = Table(table_name, metadata, *columns)

    # Add foreign keys
    if foreign_keys:
        for fk in foreign_keys:
            # Handle different foreign key formats
            if "referred_table" in fk:
                # Format: {'columns': ['col1'], 'referred_table': 'table2', 'referred_columns': ['col2']}
                fk_name = fk.get("name", f"fk_{table_name}_{fk['referred_table']}")
                constrained_columns = fk["columns"]
                referred_table = fk["referred_table"]
                referred_columns = fk["referred_columns"]

                fk_constraint = ForeignKeyConstraint(
                    constrained_columns,
                    [f"{referred_table}.{col}" for col in referred_columns],
                    name=fk_name,
                )
                table.append_constraint(fk_constraint)
            elif "refcolumns" in fk:
                # Format: {'columns': ['col1'], 'refcolumns': ['table2.col2']}
                fk_name = fk.get(
                    "name", f"fk_{table_name}_{fk['refcolumns'][0].split('.')[0]}"
                )
                constrained_columns = fk["columns"]
                refcolumns = fk["refcolumns"]

                fk_constraint = ForeignKeyConstraint(
                    constrained_columns, refcolumns, name=fk_name
                )
                table.append_constraint(fk_constraint)

    # Add constraints
    if constraints:
        for constraint in constraints:
            constraint_name = constraint.get("name", f"constraint_{table_name}")
            constraint_type = constraint.get("type")

            if constraint_type == "unique":
                unique_constraint = UniqueConstraint(
                    *constraint["columns"], name=constraint_name
                )
                table.append_constraint(unique_constraint)
            elif constraint_type == "check":
                # Support both 'condition' and 'sqltext' for check constraints
                check_sql = constraint.get("condition") or constraint.get("sqltext")
                if check_sql is None:
                    raise ValueError("Check constraint must have either 'condition' or 'sqltext' key")
                check_constraint = CheckConstraint(check_sql, name=constraint_name)
                table.append_constraint(check_constraint)

    logger.info(f"Creating table structure in database")
    metadata.create_all(engine)
    logger.info(f"Table '{table_name}' created successfully")

    # Create the index if required (after table creation to ensure columns exist)
    if keys and index in ("standard", "unique"):
        unique = index == "unique"
        index_name = f"idx_{table_name}_{'_'.join(keys)}"
        logger.debug(f"Creating {index} index '{index_name}' on columns: {keys}")

        # Create and persist the index
        index_obj = Index(index_name, *[table.c[col] for col in keys], unique=unique)
        index_obj.create(bind=engine)
        logger.debug(f"Index '{index_name}' created successfully")
