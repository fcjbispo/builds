from sqlalchemy import Index, Table
from typing import List

from fbpyutils_db import logger


def create_index(
    name: str,
    table: Table,
    keys: List[str],
    unique: bool = False,
    engine=None,
) -> Index:
    """
    Create an index on the specified keys for a given table.

    Args:
        name: The name of the index to be created.
        table: The table on which to create the index.
        keys: Column names that should be part of the index.
        unique: Whether the index should enforce uniqueness. Defaults to False.
        engine: SQLAlchemy database engine. Required for persistence.

    Returns:
        The created index object.

    Raises:
        ValueError: If no matching columns are found for the keys.

    Example:
        from sqlalchemy import Table, Column, Integer, String, MetaData
        from fbpyutils_db.database.index import create_index

        metadata = MetaData()
        table = Table('users', metadata, Column('id', Integer), Column('name', String))
        index = create_index('idx_users_name', table, ['name'], unique=False)
        # Returns: Index('idx_users_name', users.c.name)
    """
    logger.info(f"Creating index '{name}' on columns: {keys}, unique: {unique}")

    # Validate index size for Firebird
    if engine is not None:
        try:
            # Check if engine is Firebird by checking the URL
            is_firebird = "firebird" in str(engine.url).lower()
            if is_firebird:
                logger.debug("Detected Firebird dialect, validating index sizes")
                # Check each column for size limitations
                for key in keys:
                    column = next((col for col in table.columns if col.name == key), None)
                    if column and hasattr(column.type, 'length') and column.type.length:
                        # Firebird has a 252-byte limit for index keys
                        max_key_size = 252
                        col_size = column.type.length
                        if col_size > max_key_size:
                            raise ValueError(
                                f"Firebird index size limitation: Column '{key}' has size {col_size} bytes, "
                                f"but Firebird limits index keys to {max_key_size} bytes. "
                                f"Use a smaller column size or a different column for the index."
                            )
                logger.debug("Firebird index size validation passed")
        except Exception as e:
            logger.warning(f"Could not validate Firebird index size: {e}")

    # Find columns that match the keys
    index_cols = [col for col in table.columns if col.name in keys]

    if not index_cols:
        logger.warning(f"No columns found for index '{name}' with keys: {keys}")
        raise ValueError(f"No matching columns found for keys: {keys}")

    index_obj = Index(name, *index_cols, unique=unique)
    logger.info(f"Index '{name}' created successfully with {len(index_cols)} columns")

    # Persist the index to the database
    if engine is not None:
        logger.info(f"Persisting index '{name}' to database")
        try:
            index_obj.create(bind=engine)
            logger.info(f"Index '{name}' persisted to database successfully")
        except Exception as e:
            if "already exists" in str(e).lower():
                logger.warning(f"Index '{name}' already exists, skipping creation: {e}")
            else:
                logger.error(f"Failed to create index '{name}': {e}")
                raise
    else:
        logger.warning(
            f"Index '{name}' created but not persisted - no engine provided\n"
            f"Call index_obj.create(bind=engine) to persist it"
        )

    return index_obj
