"""
Embedding management module for vector databases and LLM services.

This module provides implementations for various vector databases (ChromaDB, PostgreSQL with pgvector, Pinecone)
and an embedding manager class that integrates LLM services with vector databases for document storage and retrieval.

Key Features:
- Multiple vector database backends (ChromaDB, PostgreSQL/pgvector, Pinecone)
- Consistent interface across different database implementations
- Support for both L2 (Euclidean) and cosine distance functions
- Batch processing for efficient document embedding
- Automatic ID generation from text content
- Metadata support for enriched document storage

Example:
    >>> from fbpyutils_ai.embedding import ChromaDB, EmbeddingManager
    >>> from fbpyutils_ai.llm import OpenAIService
    >>>
    >>> # Initialize vector database
    >>> vector_db = ChromaDB(
    ...     distance_function="cosine",
    ...     persist_directory="./my_chroma_db",
    ...     collection_name="documents"
    ... )
    >>>
    >>> # Initialize LLM service for embeddings
    >>> llm_service = OpenAIService(model_id="text-embedding-ada-002")
    >>>
    >>> # Create embedding manager
    >>> embedding_manager = EmbeddingManager(llm_service, vector_db)
    >>>
    >>> # Add documents
    >>> embedding_manager.add_document(
    ...     text="Machine learning is a subset of artificial intelligence.",
    ...     meta={"category": "tech", "source": "wikipedia"}
    ... )
"""

# Standard library imports
import json
import os
import hashlib
from typing import List, Dict, Any, Tuple, Optional

# Third-party imports
import chromadb
import psycopg
from pgvector.psycopg import register_vector
from pinecone import Pinecone, ServerlessSpec

from fbpyutils_ai import logger
from fbpyutils_ai.base import LLMService, VectorDatabase

from fbpyutils.process import Process


# Implementation for ChromaDB
class ChromaDB(VectorDatabase):
    """
    ChromaDB implementation of the VectorDatabase interface.

    This class provides a ChromaDB-based vector database with support for both
    persistent local storage and HTTP client connections to remote servers.

    Args:
        distance_function: Distance function for similarity search ('l2' or 'cosine')
        persist_directory: Directory for local database persistence
        collection_name: Name of the collection to use
        host: Host address for HTTP client (optional)
        port: Port number for HTTP client (optional)

    Example:
        >>> # Local persistent database
        >>> local_db = ChromaDB(
        ...     distance_function="cosine",
        ...     persist_directory="./my_chroma_db",
        ...     collection_name="documents"
        ... )
        >>>
        >>> # Remote HTTP client
        >>> remote_db = ChromaDB(
        ...     distance_function="l2",
        ...     host="localhost",
        ...     port=8000,
        ...     collection_name="remote_docs"
        ... )
    """

    def __init__(
        self,
        distance_function: str = "l2",
        persist_directory: str = "./chroma_db",
        collection_name: str = "default",
        host: str = None,
        port: int = None,
    ):
        """
        Initializes the ChromaDB with the given persist directory and collection name.

        Args:
            distance_function (str, optional): The distance function to use for similarity search.
                Valid values are 'l2' (Euclidean distance) or 'cosine' (Cosine similarity). Defaults to 'l2'.
            persist_directory (str, optional): The directory to persist the database. Defaults to "./chroma_db".
            collection_name (str, optional): The name of the collection. Defaults to "default".
            host (str, optional): The host address of the ChromaDB server. Defaults to None.
            port (int, optional): The port number of the ChromaDB server. Defaults to None.

        Example:
            >>> db = ChromaDB(
            ...     distance_function="cosine",
            ...     persist_directory="./chroma_data",
            ...     collection_name="tech_docs"
            ... )
            >>> print(f"Collection: {db.collection.name}")
            Collection: tech_docs
        """
        logger.info(
            f"ChromaDB.__init__ called with distance_function={distance_function}, persist_directory={persist_directory}, collection_name={collection_name}, host={host}, port={port}"
        )

        super().__init__(distance_function=distance_function)

        if host and port:
            self.client = chromadb.HttpClient(host=host, port=port)
        else:
            self.client = chromadb.PersistentClient(path=persist_directory)

        logger.debug(f"ChromaDB client created: {type(self.client).__name__}")

        try:
            self.collection = self.client.create_collection(
                name=collection_name,
                metadata={
                    "hnsw:space": (
                        "cosine" if self.distance_function == "cosine" else "l2"
                    )
                },
            )
            logger.info(f"ChromaDB collection created: {collection_name}")
        except Exception:
            logger.debug(
                f"Collection '{collection_name}' already exists, getting or creating"
            )
            self.collection = self.client.get_or_create_collection(
                name=collection_name,
                metadata={
                    "hnsw:space": (
                        "cosine" if self.distance_function == "cosine" else "l2"
                    )
                },
            )
            logger.info(f"ChromaDB collection retrieved: {collection_name}")

        logger.info(
            f"ChromaDB.__init__ completed: client={type(self.client).__name__}, collection={self.collection.name}, distance_function={self.distance_function}"
        )

    def add_embeddings(
        self,
        ids: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ):
        """
        Adds embeddings to the ChromaDB collection.

        Args:
            ids: List of unique IDs for the embeddings
            embeddings: List of embedding vectors (each as a list of floats)
            metadatas: List of metadata dictionaries for each embedding

        Example:
            >>> embeddings = [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]
            >>> ids = ["doc1", "doc2"]
            >>> metadatas = [
            ...     {"title": "Document 1", "category": "tech"},
            ...     {"title": "Document 2", "category": "science"}
            ... ]
            >>> db.add_embeddings(ids, embeddings, metadatas)
            >>> print("Embeddings added successfully")
            Embeddings added successfully
        """
        logger.info(f"ChromaDB.add_embeddings called with {len(ids)} embeddings")

        enhanced_metadatas = []
        for id, metadata in zip(ids, metadatas):
            enhanced_metadata = metadata.copy()
            enhanced_metadata["id"] = id
            enhanced_metadatas.append(enhanced_metadata)

        logger.debug(f"Processing {len(enhanced_metadatas)} enhanced metadata entries")

        self.collection.upsert(
            ids=ids, embeddings=embeddings, metadatas=enhanced_metadatas
        )

        logger.info(
            f"ChromaDB.add_embeddings completed: upserted {len(ids)} embeddings"
        )

    def search_embeddings(
        self, embedding: List[float], n_results: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Searches for similar embeddings in the ChromaDB collection.

        Args:
            embedding: Query embedding vector to search for
            n_results: Maximum number of similar embeddings to return (default: 10)

        Returns:
            List of tuples containing (document_id, distance) for similar embeddings

        Example:
            >>> query_embedding = [0.1, 0.2, 0.3, 0.4]
            >>> results = db.search_embeddings(query_embedding, n_results=3)
            >>> for doc_id, distance in results:
            ...     print(f"Found similar document {doc_id} with distance {distance:.4f}")
            Found similar document doc1 with distance 0.1234
            Found similar document doc3 with distance 0.2345
            Found similar document doc7 with distance 0.3456
        """
        logger.info(
            f"ChromaDB.search_embeddings called with embedding dim={len(embedding)}, n_results={n_results}"
        )

        results = self.collection.query(
            query_embeddings=[embedding],
            n_results=n_results,
            include=["metadatas", "distances"],
        )
        doc_ids = [meta.get("id") for meta in results["metadatas"][0]]
        result_tuples = list(zip(doc_ids, results["distances"][0]))

        logger.info(
            f"ChromaDB.search_embeddings completed: found {len(result_tuples)} results"
        )
        return result_tuples

    def count(self, where: Optional[Dict[str, Any]] = None) -> int:
        """
        Counts the number of embeddings in the ChromaDB collection.

        Args:
            where: Optional filter criteria as a dictionary (default: None)

        Returns:
            Integer count of embeddings matching the criteria

        Example:
            >>> # Count all embeddings
            >>> total = db.count()
            >>> print(f"Total embeddings: {total}")
            Total embeddings: 150

            >>> # Count with filter
            >>> tech_count = db.count(where={"category": "technology"})
            >>> print(f"Technology documents: {tech_count}")
            Technology documents: 45
        """
        if where:
            # Use get() with where filter and count the results
            results = self.collection.get(
                where=where,
                include=["documents"],  # Minimal include to optimize performance
            )
            return len(results["ids"])
        else:
            # For total count, use count() method
            return self.collection.count()

    def get_version(self) -> str:
        """
        Gets the version of the ChromaDB server.

        Returns:
            Version string of the ChromaDB server, or "unknown" if an error occurred
            or if using a persistent client that doesn't expose version information.

        Example:
            >>> version = db.get_version()
            >>> print(f"ChromaDB version: {version}")
            ChromaDB version: 0.4.15
        """
        try:
            return self.client.get_version()
        except AttributeError:
            logger.error(
                "Error: 'get_version' method not found. Please ensure you are using chromadb version 0.4.15 or higher."
            )
            return "unknown"
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")
            return "unknown"

    def list_collections(self) -> List[str]:
        """
        Lists all collections in the ChromaDB.

        Returns:
            List of collection names as strings

        Example:
            >>> collections = db.list_collections()
            >>> print(f"Available collections: {collections}")
            Available collections: ['documents', 'images', 'videos', 'default']
        """
        return self.client.list_collections()

    def reset_collection(self):
        """
        Resets the current collection by erasing all documents.

        Warning:
            This operation is irreversible and will delete all embeddings and metadata
            from the current collection.

        Example:
            >>> # Count documents before reset
            >>> before = db.count()
            >>> print(f"Documents before reset: {before}")
            Documents before reset: 150

            >>> # Reset the collection
            >>> db.reset_collection()
            >>> print("Collection reset completed")
            Collection reset completed

            >>> # Count documents after reset
            >>> after = db.count()
            >>> print(f"Documents after reset: {after}")
            Documents after reset: 0
        """
        # Retrieve all document IDs
        doc_ids = self.collection.get()["ids"]

        # Check if there are any documents to delete
        if doc_ids:
            # Delete all documents by their IDs
            self.collection.delete(ids=doc_ids)
            logger.info(
                f"Deleted {len(doc_ids)} documents from the collection '{self.collection}'."
            )
        else:
            logger.info("No documents found in the collection.")


# Implementation for PgVectorDB
class PgVectorDB(VectorDatabase):
    """
    PostgreSQL with pgvector extension implementation of the VectorDatabase interface.

    This class provides a PostgreSQL-based vector database using the pgvector extension.
    It supports both L2 (Euclidean) and cosine distance functions with HNSW indexing for
    efficient similarity search.

    Args:
        distance_function: Distance function ('l2' or 'cosine') for search and indexing
        collection_name: Name of the table to store embeddings
        host: Database server host address
        port: Database server port
        db_name: Database name
        user: Database username
        password: Database password
        conn_str: Full PostgreSQL connection string (overrides individual parameters)

    Example:
        >>> # Using individual parameters
        >>> pg_db = PgVectorDB(
        ...     distance_function="cosine",
        ...     collection_name="documents",
        ...     host="localhost",
        ...     port=5432,
        ...     db_name="vector_db",
        ...     user="postgres",
        ...     password="secret"
        ... )
        >>>
        >>> # Using connection string
        >>> conn_str = "postgresql://user:pass@localhost:5432/vector_db"
        >>> pg_db = PgVectorDB(conn_str=conn_str, collection_name="docs")
    """

    def __init__(
        self,
        distance_function: str = "l2",
        collection_name: str = "global",
        host: str = None,
        port: int = None,
        db_name: str = None,
        user: str = None,
        password: str = None,
        conn_str: str = None,
    ):
        """
        Initializes the PgVectorDB with the given connection parameters and sets up the database table and index.

        Args:
            distance_function (str, optional): The distance function ('l2' or 'cosine') for index creation and search. Defaults to 'l2'.
            collection_name (str): The name of the table to store embeddings. Defaults to 'default'.
            host (str, optional): Database server host address. Defaults to None (uses conn_str or environment variables if available).
            port (int, optional): Database server port. Defaults to None.
            db_name (str, optional): Database name. Defaults to None.
            user (str, optional): Database username. Defaults to None.
            password (str, optional): Database password. Defaults to None.
            conn_str (str, optional): Full PostgreSQL connection string. If provided, overrides individual host, port, etc. Defaults to None.

        Raises:
            psycopg.Error: If connection to the database fails or table/extension creation fails.

        Example:
            >>> # Using environment variables for credentials
            >>> import os
            >>> os.environ['PGPASSWORD'] = 'secret'
            >>> db = PgVectorDB(
            ...     collection_name="my_embeddings",
            ...     host="localhost",
            ...     db_name="vector_store"
            ... )
            >>> print(f"Connected to PostgreSQL version: {db.get_version()}")
            Connected to PostgreSQL version: 150001
        """
        super().__init__(distance_function=distance_function)

        if conn_str is not None:
            self.conn_str = conn_str
        else:
            db_url = (
                f"{host}:{port}" if host and port else "localhost:5432"
            )  # Default to localhost:5432 if not provided
            self.conn_str = f"postgresql://{user}:{password}@{db_url}/{db_name}"

        self.collection_name = collection_name
        try:
            self.conn = psycopg.connect(self.conn_str, autocommit=True)
            self.conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
            register_vector(self.conn)
            # Create table if it doesn't exist
            self.conn.execute(
                f"""CREATE TABLE IF NOT EXISTS {self.collection_name} (
                        id TEXT PRIMARY KEY,
                        embedding vector(1536), -- Assuming embedding dimension is 1536
                        metadata JSONB
                    )"""
            )
            # Create the appropriate vector index if it doesn't exist
            index_name = f"{self.collection_name}_embedding_idx"
            if self.distance_function == "cosine":
                op_class = "vector_cosine_ops"
            else:  # Default to l2
                op_class = "vector_l2_ops"
            self.conn.execute(
                f"""CREATE INDEX IF NOT EXISTS {index_name}
                    ON {self.collection_name}
                    USING hnsw (embedding {op_class})"""  # Using HNSW index for efficiency
            )
        except psycopg.Error as e:
            logger.error(f"Error connecting to PostgreSQL or creating table: {e}")
            raise

    def add_embeddings(
        self,
        ids: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ):
        """
        Adds or updates embeddings in the PgVectorDB table using an upsert operation.

        Args:
            ids: List of unique IDs for each embedding
            embeddings: List of embedding vectors (each as a list of floats)
            metadatas: List of metadata dictionaries corresponding to each embedding

        Raises:
            psycopg.Error: If the batch insertion fails

        Example:
            >>> embeddings = [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]
            >>> ids = ["doc1", "doc2"]
            >>> metadatas = [
            ...     {"title": "Document 1", "category": "tech"},
            ...     {"title": "Document 2", "category": "science"}
            ... ]
            >>> pg_db.add_embeddings(ids, embeddings, metadatas)
            >>> print("Embeddings upserted successfully")
            Embeddings upserted successfully
        """
        # Prepare data for batch insertion
        data_to_insert = [
            (id, embedding, json.dumps(metadata))
            for id, embedding, metadata in zip(ids, embeddings, metadatas)
        ]

        if not data_to_insert:
            return  # Do nothing if there is no data

        try:
            with self.conn.cursor() as cur:
                # Use executemany for batch insert/update (upsert)
                cur.executemany(
                    f"""INSERT INTO {self.collection_name} (id, embedding, metadata) VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO UPDATE SET embedding = EXCLUDED.embedding, metadata = EXCLUDED.metadata""",
                    data_to_insert,
                )
        except psycopg.Error as e:
            logger.error(f"Error adding embeddings in batch to PostgreSQL: {e}")
            raise

    def search_embeddings(
        self, embedding: List[float], n_results: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Searches for the most similar embeddings in the PgVectorDB table using the configured distance function.

        Args:
            embedding: The query embedding vector
            n_results: Maximum number of similar embeddings to return (default: 10)

        Returns:
            List of tuples containing (document_id, distance) ordered by distance.
            Returns an empty list on error.

        Raises:
            ValueError: If the configured distance_function is invalid

        Example:
            >>> query_embedding = [0.1, 0.2, 0.3, 0.4]
            >>> results = pg_db.search_embeddings(query_embedding, n_results=5)
            >>> for doc_id, distance in results:
            ...     print(f"Document {doc_id}: distance = {distance:.4f}")
            Document doc3: distance = 0.0876
            Document doc7: distance = 0.1234
            Document doc1: distance = 0.2345
        """
        if self.distance_function == "cosine":
            operator = "<=>"
        elif self.distance_function == "l2":
            operator = "<->"
        else:
            raise ValueError(f"Invalid distance function: {self.distance_function}.")

        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    f"SELECT id, embedding {operator} %s::vector AS distance FROM {self.collection_name} ORDER BY distance LIMIT %s",
                    (embedding, n_results),
                )
                results = cur.fetchall()
                return [(result[0], result[1]) for result in results]
        except psycopg.Error as e:
            logger.error(f"Error searching embeddings in PostgreSQL: {e}")
            return []

    def count(self, where: Optional[Dict[str, Any]] = None) -> int:
        """
        Counts the number of embeddings in the PgVectorDB table, optionally applying a metadata filter.

        Args:
            where: Optional filter criteria based on metadata fields
                   (e.g., `{'source': 'web', 'category': 'tech'}`). Defaults to None (counts all).

        Returns:
            Number of embeddings matching the criteria. Returns 0 on error.

        Example:
            >>> # Count all embeddings
            >>> total = pg_db.count()
            >>> print(f"Total embeddings: {total}")
            Total embeddings: 1000

            >>> # Count with metadata filter
            >>> tech_count = pg_db.count(where={"category": "technology"})
            >>> print(f"Technology documents: {tech_count}")
            Technology documents: 250
        """
        try:
            with self.conn.cursor() as cur:
                query = f"SELECT COUNT(*) FROM {self.collection_name}"
                if where:
                    conditions = []
                    params = []
                    for key, value in where.items():
                        conditions.append(f"metadata->>'{key}' = %s")
                        params.append(str(value))
                    query += f" WHERE {' AND '.join(conditions)}"
                    cur.execute(query, params)
                else:
                    cur.execute(query)
                result = cur.fetchone()
                return result[0]
        except psycopg.Error as e:
            logger.error(f"Error counting embeddings in PostgreSQL: {e}")
            return 0

    def get_version(self) -> str:
        """
        Gets the version of the connected PostgreSQL database server.

        Returns:
            Server version string, or empty string on error.

        Example:
            >>> version = pg_db.get_version()
            >>> print(f"PostgreSQL version: {version}")
            PostgreSQL version: 150001
        """
        try:
            return str(self.conn.info.server_version)
        except psycopg.Error as e:
            logger.error(f"Error getting PostgreSQL version: {e}")
            return ""

    def list_collections(self) -> List[str]:
        """
        Lists all tables in the 'public' schema of the connected database.

        Returns:
            List of table names. Returns an empty list on error.

        Example:
            >>> tables = pg_db.list_collections()
            >>> print(f"Available tables: {tables}")
            Available tables: ['documents', 'images', 'users', 'products']
        """
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    "SELECT tablename FROM pg_tables WHERE schemaname = 'public'"
                )
                results = cur.fetchall()
                return [result[0] for result in results]
        except psycopg.Error as e:
            logger.error(f"Error listing collections in PostgreSQL: {e}")
            return []

    def reset_collection(self):
        """
        Resets the current collection (table) by removing all rows using TRUNCATE.

        Warning:
            This operation is irreversible and will delete all data from the table.

        Example:
            >>> # Count before reset
            >>> before = pg_db.count()
            >>> print(f"Rows before reset: {before}")
            Rows before reset: 500

            >>> # Reset the collection
            >>> pg_db.reset_collection()
            >>> print("Collection reset completed")
            Collection reset completed

            >>> # Count after reset
            >>> after = pg_db.count()
            >>> print(f"Rows after reset: {after}")
            Rows after reset: 0
        """
        try:
            with self.conn.cursor() as cur:
                # Use TRUNCATE for fast cleanup, assuming table and index already exist
                cur.execute(f"TRUNCATE TABLE {self.collection_name}")
                logger.info(f"Truncated table '{self.collection_name}'.")
        except psycopg.Error as e:
            logger.error(f"Error truncating collection in PostgreSQL: {e}")
            # Consider re-raising the exception depending on criticality
            # raise # Uncomment if truncate failure should stop execution


class PineconeDB(VectorDatabase):
    """
    Pinecone vector database implementation of the VectorDatabase interface.

    This class provides a Pinecone-based vector database with support for serverless
    indexes on AWS. It automatically creates indexes if they don't exist and supports
    both L2 (Euclidean) and cosine similarity metrics.

    Args:
        api_key: Pinecone API key (or None to use PINECONE_API_KEY env var)
        distance_function: Distance function ('l2' or 'cosine')
        collection_name: Name of the index/collection
        region: AWS region for serverless index
        vector_dimension: Dimension of vectors (must be > 0)

    Example:
        >>> # Using environment variable for API key
        >>> import os
        >>> os.environ['PINECONE_API_KEY'] = 'your-api-key'
        >>> pinecone_db = PineconeDB(
        ...     distance_function="cosine",
        ...     collection_name="documents",
        ...     region="us-west-2",
        ...     vector_dimension=1536
        ... )
        >>>
        >>> # Direct API key
        >>> pinecone_db = PineconeDB(
        ...     api_key="your-api-key",
        ...     collection_name="embeddings",
        ...     vector_dimension=768
        ... )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        distance_function: str = "l2",
        collection_name: str = "default",
        region: str = "us-east-1",
        vector_dimension: int = 1536,
    ):
        """
        Initializes a PineconeDB instance.

        Args:
            api_key: Pinecone API key. If not provided, it will be obtained from the PINECONE_API_KEY environment variable.
            distance_function: Distance function to use ('l2' or 'cosine'). Default: 'l2'.
            collection_name: Name of the collection/index to use. Default: "default".
            region: AWS region where the index will be created. Default: 'us-east-1'.
            vector_dimension: Dimension of the vectors to be stored. Must be greater than 0. Default: 1536.

        Raises:
            ValueError: If the API key is not provided and the PINECONE_API_KEY environment variable is not set.
            ValueError: If vector_dimension is less than or equal to 0.

        Example:
            >>> # Initialize with environment variable
            >>> import os
            >>> os.environ['PINECONE_API_KEY'] = 'pc_...'
            >>> db = PineconeDB(
            ...     collection_name="my_index",
            ...     vector_dimension=1536
            ... )
            >>> print(f"Index: {db.collection_name}")
            Index: my_index
        """
        super().__init__(distance_function)
        self.api_key = api_key or os.environ.get("PINECONE_API_KEY")
        self.collection_name = collection_name or "default"
        self.region = region or "us-east-1"

        if not self.api_key or not self.collection_name:
            raise ValueError(
                "API key não fornecida e variável de ambiente PINECONE_API_KEY não configurada."
            )

        if vector_dimension <= 0:
            raise ValueError("vector_dimension deve ser maior que 0")
        self.vector_dimension = vector_dimension
        self.namespace = collection_name

        self.client = Pinecone(api_key=self.api_key)

        # Verifica se o índice já existe
        existing_indexes = self.client.list_indexes()
        index_names = [index["name"] for index in existing_indexes]

        if self.collection_name not in index_names:
            # Cria o índice com a função de distância especificada
            metric = "euclidean" if distance_function == "l2" else "cosine"
            try:
                self.client.create_index(
                    name=self.collection_name,
                    dimension=self.vector_dimension,
                    metric=metric,
                    deletion_protection="disabled",
                    spec=ServerlessSpec(region=self.region, cloud="aws"),
                )
            except Exception as e:
                if "already exists" not in str(e):
                    raise

        self.index = self.client.Index(self.collection_name)

    def add_embeddings(
        self,
        ids: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ):
        """
        Adds embeddings to the database.

        Args:
            ids: List of unique IDs for each embedding
            embeddings: List of embedding vectors (each as a list of floats)
            metadatas: List of dictionaries containing metadata associated with each embedding

        Example:
            >>> embeddings = [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]
            >>> ids = ["doc1", "doc2"]
            >>> metadatas = [
            ...     {"title": "Document 1", "category": "tech"},
            ...     {"title": "Document 2", "category": "science"}
            ... ]
            >>> pinecone_db.add_embeddings(ids, embeddings, metadatas)
            >>> print("Embeddings upserted to Pinecone")
            Embeddings upserted to Pinecone
        """
        vectors = [
            {"id": id, "values": embedding, "metadata": metadata}
            for id, embedding, metadata in zip(ids, embeddings, metadatas)
        ]

        self.index.upsert(vectors=vectors, namespace=self.namespace)

    def search_embeddings(
        self, embedding: List[float], n_results: int = 10, similarity_by: str = None
    ) -> List[Tuple[str, float]]:
        """
        Searches for embeddings similar to the provided vector.

        Args:
            embedding: Embedding vector for similarity search
            n_results: Maximum number of results to return (default: 10)
            similarity_by: Distance function (ignored by Pinecone, kept for interface consistency)

        Returns:
            List of tuples containing (embedding_id, similarity_score) ordered by descending similarity

        Example:
            >>> query_embedding = [0.1, 0.2, 0.3, 0.4]
            >>> results = pinecone_db.search_embeddings(query_embedding, n_results=3)
            >>> for doc_id, score in results:
            ...     print(f"Document {doc_id}: similarity score = {score:.4f}")
            Document doc5: similarity score = 0.8765
            Document doc2: similarity score = 0.7654
            Document doc8: similarity score = 0.6543
        """
        try:
            query_response = self.index.query(
                vector=embedding,
                top_k=n_results,
                namespace=self.namespace,
                include_metadata=True,
            )
            return [(match.id, match.score) for match in query_response.matches]
        except Exception as e:
            if "Namespace not found" in str(e):
                return []
            raise

    def get_version(self) -> str:
        """
        Gets the version of the index in Pinecone.

        Note:
            Pinecone itself doesn't have a simple 'version' concept like a traditional database server.
            This method returns version information from the index description if available,
            otherwise returns 'unknown'.

        Returns:
            Version string if available from index description, otherwise 'unknown'.

        Example:
            >>> version = pinecone_db.get_version()
            >>> print(f"Pinecone index version: {version}")
            Pinecone index version: unknown
        """
        index_description = self.client.describe_index(self.collection_name)
        return index_description.get("version", "unknown")

    def count(self, where: Optional[Dict[str, Any]] = None) -> int:
        """
        Counts the number of vectors in the namespace.

        Note:
            Pinecone's `describe_index_stats` provides total counts per namespace,
            but does not support counting with metadata filters (`where` clause).
            The `where` parameter is ignored in this implementation.

        Args:
            where: Metadata filter (ignored in current implementation)

        Returns:
            Total number of vectors in the specified namespace.

        Example:
            >>> count = pinecone_db.count()
            >>> print(f"Total vectors in namespace: {count}")
            Total vectors in namespace: 1250
        """
        # Obtém estatísticas do índice (pode ser eventualmente consistente)
        stats = self.index.describe_index_stats()
        # Retorna a contagem de vetores para o namespace específico
        if self.namespace in stats.namespaces:
            return stats.namespaces[self.namespace].vector_count
        return 0  # Retorna 0 se o namespace não existir nas estatísticas

    def list_collections(self) -> List[str]:
        """
        Lists all available indexes in Pinecone (equivalent to collections).

        Returns:
            List of index names.

        Example:
            >>> indexes = pinecone_db.list_collections()
            >>> print(f"Available Pinecone indexes: {indexes}")
            Available Pinecone indexes: ['documents', 'images', 'videos']
        """
        # No Pinecone, collections são chamadas de indexes.
        indexes = self.client.list_indexes()
        return [index["name"] for index in indexes]

    def reset_collection(self):
        """
        Removes all vectors from the current namespace.

        Warning:
            This operation is irreversible and will delete all vectors from the namespace.

        Example:
            >>> # Count before reset
            >>> before = pinecone_db.count()
            >>> print(f"Vectors before reset: {before}")
            Vectors before reset: 800

            >>> # Reset the collection
            >>> pinecone_db.reset_collection()
            >>> print("Namespace reset completed")
            Namespace reset completed

            >>> # Count after reset
            >>> after = pinecone_db.count()
            >>> print(f"Vectors after reset: {after}")
            Vectors after reset: 0
        """
        try:
            # First check if namespace exists
            stats = self.index.describe_index_stats()
            if self.namespace in stats.namespaces:
                self.index.delete(delete_all=True, namespace=self.namespace)
        except Exception as e:
            if "not found" not in str(e).lower():
                raise


# Main class to manage embeddings
class EmbeddingManager:
    """
    Main class for managing document embeddings with LLM services and vector databases.

    This class provides a high-level interface for adding documents, generating embeddings,
    and searching for similar content. It supports batch processing and automatic ID generation.

    Args:
        llm_service: LLM service for generating embeddings
        vector_database: Vector database for storing and searching embeddings

    Example:
        >>> from fbpyutils_ai.llm import OpenAIService
        >>> from fbpyutils_ai.embedding import ChromaDB, EmbeddingManager
        >>>
        >>> # Initialize components
        >>> llm = OpenAIService(model_id="text-embedding-ada-002")
        >>> vector_db = ChromaDB(collection_name="documents")
        >>> manager = EmbeddingManager(llm, vector_db)
        >>>
        >>> # Add a document
        >>> manager.add_document(
        ...     text="Python is a versatile programming language.",
        ...     meta={"category": "programming", "language": "python"}
        ... )
    """

    def __init__(self, llm_service: LLMService, vector_database: VectorDatabase):
        """
        Initializes the EmbeddingManager with the given LLM service and vector database.

        Args:
            llm_service: The LLM service to use for generating embeddings.
            vector_database: The vector database to use for storing embeddings.

        Example:
            >>> manager = EmbeddingManager(llm_service, vector_db)
            >>> print(f"Manager initialized with {type(vector_db).__name__}")
            Manager initialized with ChromaDB
        """
        self.llm_service = llm_service
        self.vector_database = vector_database

    def add_document(
        self, text: str, id: str = None, meta: Optional[Dict[str, Any]] = None
    ):
        """
        Adds a single document to the database.

        Args:
            text: The text content of the document
            id: Optional ID for the document. If None, generated from text hash
            meta: Optional metadata dictionary for the document

        Example:
            >>> # Add document with auto-generated ID
            >>> manager.add_document(
            ...     text="Machine learning is a subset of AI.",
            ...     meta={"category": "technology", "source": "wikipedia"}
            ... )
            >>> print("Document added with auto-generated ID")
            Document added with auto-generated ID

            >>> # Add document with custom ID
            >>> manager.add_document(
            ...     text="Deep learning uses neural networks.",
            ...     id="doc_123",
            ...     meta={"category": "technology", "difficulty": "advanced"}
            ... )
            >>> print("Document added with custom ID")
            Document added with custom ID
        """
        document_id = id if id is not None else self.generate_id_from_text(text)
        embedding = self.llm_service.generate_embeddings(text)
        if embedding:
            self.vector_database.add_embeddings(
                [document_id], [embedding], [meta or {}]
            )
            return document_id
        else:
            logger.error("Failed to generate embedding for the document.")
            return None

    def add_documents(
        self,
        documents: List[Tuple[str, str, Optional[Dict[str, Any]]]],
        parallel: bool = True,
    ):
        """
        Adds multiple documents to the database with optional parallel processing.

        Args:
            documents: List of tuples, where each tuple contains:
                - text: The text of the document
                - id: Optional ID of the document (None for auto-generation)
                - meta: Optional metadata for the document
            parallel: Whether to process documents in parallel (default: True)

        Example:
            >>> documents = [
            ...     ("Python is great", None, {"category": "programming"}),
            ...     ("Java is popular", "java_doc", {"category": "programming"}),
            ...     ("Rust is safe", None, {"category": "programming", "type": "systems"})
            ... ]
            >>> manager.add_documents(documents, parallel=True)
            >>> print(f"Added {len(documents)} documents")
            Added 3 documents
        """
        params = [(text, id, meta) for text, id, meta in documents]
        processor = Process(process=self._process_document, parallelize=parallel)
        results = processor.run(params=params)

        ids = [result[0] for result in results if result]
        embeddings = [result[1] for result in results if result]
        metadatas = [result[2] for result in results if result]

        if ids and embeddings and metadatas:
            self.vector_database.add_embeddings(ids, embeddings, metadatas)
            return ids
        else:
            logger.error("No valid embeddings were generated for the documents.")
            return []

    def _process_document(
        self, text: str, id: str = None, meta: Optional[Dict[str, Any]] = None
    ) -> Optional[Tuple[str, List[float], Dict[str, Any]]]:
        """
        Processes a single document, generating embedding and preparing data for database insertion.

        Args:
            text: The text of the document
            id: Optional ID of the document (None for auto-generation)
            meta: Optional metadata for the document

        Returns:
            Tuple containing (document_id, embedding, metadata) if successful,
            None if embedding generation failed

        Example:
            >>> result = manager._process_document(
            ...     "Test document content",
            ...     meta={"test": True}
            ... )
            >>> if result:
            ...     doc_id, embedding, metadata = result
            ...     print(f"Processed: {doc_id}, embedding length: {len(embedding)}")
            Processed: a1b2c3d4..., embedding length: 1536
        """
        document_id = id if id is not None else self.generate_id_from_text(text)
        embedding = self.llm_service.generate_embeddings(text)
        if embedding:
            return document_id, embedding, meta or {}
        else:
            return None

    def generate_id_from_text(self, text: str) -> str:
        """
        Generates a unique ID based on the SHA-256 hash of the text.

        Args:
            text: The text to generate the ID from

        Returns:
            Hexadecimal string representation of the SHA-256 hash

        Example:
            >>> text = "This is a test document"
            >>> doc_id = manager.generate_id_from_text(text)
            >>> print(f"Generated ID: {doc_id}")
            Generated ID: 7d865e959b246691e91c631961b8b8f8...
            >>>
            >>> # Same text generates same ID
            >>> same_id = manager.generate_id_from_text(text)
            >>> print(f"Same ID: {doc_id == same_id}")
            Same ID: True
        """
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def search_documents(
        self, text: str, n_results: int = 10, similarity_by: str = "cosine"
    ) -> List[Tuple[str, float]]:
        """
        Searches for similar documents in the database based on the given text.

        Args:
            text: The text to search for similar documents
            n_results: Maximum number of results to return (default: 10)
            similarity_by: Similarity metric to use (default: 'cosine')

        Returns:
            List of tuples containing (document_id, similarity_score) for similar documents

        Example:
            >>> query_text = "machine learning algorithms"
            >>> results = manager.search_documents(query_text, n_results=3)
            >>> for doc_id, score in results:
            ...     print(f"Similar document {doc_id}: score = {score:.4f}")
            Similar document a1b2c3d4...: score = 0.8765
            Similar document e5f6g7h8...: score = 0.7654
            Similar document i9j0k1l2...: score = 0.6543
        """
        embedding = self.llm_service.generate_embeddings(text)
        if embedding:
            return self.vector_database.search_embeddings(
                embedding, n_results, similarity_by
            )
        return []
