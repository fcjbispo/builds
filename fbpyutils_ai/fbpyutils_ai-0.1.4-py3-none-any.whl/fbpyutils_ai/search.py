"""
Search tools for web search using SearXNG metasearch engine.

This module provides utilities for searching the web using SearXNG, a privacy-respecting
metasearch engine. It includes both synchronous and asynchronous search capabilities,
result processing utilities, and DataFrame conversion functions.

Features:
- Synchronous and asynchronous search methods
- Multiple search categories (general, images, videos, news, etc.)
- Language and region targeting
- Safe search filtering
- Time-based search filtering
- Result simplification and DataFrame conversion
- Comprehensive error handling

Example:
    >>> from fbpyutils_ai.search import SearXNGTool, SearXNGUtils
    >>>
    >>> # Initialize search tool
    >>> search_tool = SearXNGTool()
    >>>
    >>> # Perform search
    >>> results = search_tool.search("python programming")
    >>> print(f"Found {len(results)} results")
    Found 10 results
    >>>
    >>> # Convert to DataFrame
    >>> df = SearXNGUtils.convert_to_dataframe(results)
    >>> print(df[['title', 'url']].head())
                                                    title                                                url
    0                    Python Programming Language  https://www.python.org/
    1  Learn Python Programming - Python for Beginners  https://www.learnpython.org/
"""

import os
from typing import Any, Dict, Optional, Union, List

import httpx
from fbpyutils_ai import logger
from fbpyutils.http import HTTPClient  # Importando HTTPClient
import pandas as pd


class SearXNGUtils:
    """
    Utilities for processing and converting SearXNG search results.

    Provides helper methods to simplify raw SearXNG results and convert them
    to pandas DataFrames for easier analysis and processing.
    """

    @staticmethod
    def simplify_results(
        results: List[Dict[str, Union[str, int, float, bool, None]]],
    ) -> List[Dict[str, Union[str, int, float, bool, None]]]:
        """
        Simplifies SearXNG results by extracting key fields and organizing metadata.

        Extracts main fields (url, title, content, score, publishedDate) and groups
        all other fields into an 'other_info' dictionary for each result.

        Args:
            results: List of raw SearXNG result dictionaries

        Returns:
            Simplified list with standardized field structure

        Example:
            >>> raw_results = [
            ...     {
            ...         "url": "https://example.com",
            ...         "title": "Example Site",
            ...         "content": "This is example content",
            ...         "score": 0.95,
            ...         "publishedDate": "2024-01-15",
            ...         "engine": "google",
            ...         "category": "general"
            ...     }
            ... ]
            >>> simplified = SearXNGUtils.simplify_results(raw_results)
            >>> print(simplified[0].keys())
            dict_keys(['url', 'title', 'content', 'score', 'publishedDate', 'other_info'])
            >>> print(simplified[0]['other_info'])
            {'engine': 'google', 'category': 'general'}
        """
        logger.debug("Entering simplify_results")
        simplified_results = []
        if results:
            key_columns = ["url", "title", "content", "score", "publishedDate"]
            for result in results:
                result_record = {}
                for key in key_columns:
                    result_record[key] = result.get(key)
                other_keys = [k for k in result.keys() if k not in key_columns]
                result_record["other_info"] = {k: result[k] for k in other_keys}
                simplified_results.append(result_record)
        logger.debug("Exiting simplify_results")
        return simplified_results

    @staticmethod
    def convert_to_dataframe(
        results: List[Dict[str, Union[str, int, float, bool, None]]],
    ) -> pd.DataFrame:
        """
        Converts SearXNG results to a pandas DataFrame for analysis.

        First simplifies the results using simplify_results(), then creates a DataFrame
        with standardized columns for easy manipulation and analysis.

        Args:
            results: List of SearXNG result dictionaries

        Returns:
            pandas DataFrame with columns: url, title, content, score, publishedDate, other_info

        Example:
            >>> results = [
            ...     {
            ...         "url": "https://python.org",
            ...         "title": "Python Programming Language",
            ...         "content": "Official Python website",
            ...         "score": 0.98,
            ...         "publishedDate": None
            ...     }
            ... ]
            >>> df = SearXNGUtils.convert_to_dataframe(results)
            >>> print(df.shape)
            (1, 6)
            >>> print(df.columns.tolist())
            ['url', 'title', 'content', 'score', 'publishedDate', 'other_info']
            >>> print(df['title'].iloc[0])
            Python Programming Language
        """
        logger.debug("Entering convert_to_dataframe")
        df = pd.DataFrame(
            columns=["url", "title", "content", "score", "publishedDate", "other_info"]
        )
        if results:
            results_list = SearXNGUtils.simplify_results(results)
            df = pd.DataFrame.from_dict(results_list, orient="columns")
        logger.debug("Exiting convert_to_dataframe")
        return df


class SearXNGTool:
    """
    SearXNG metasearch engine client for privacy-respecting web searches.

    This tool provides an interface to the SearXNG API for performing web searches
    across multiple search engines while maintaining user privacy. It supports both
    synchronous and asynchronous search operations with comprehensive filtering options.

    Features:
    - Multiple search categories (general, images, videos, news, etc.)
    - Language and region targeting
    - Safe search filtering (none, moderate, strict)
    - Time-based search filtering
    - Result pagination support
    - SSL verification options

    Constants:
        SAFESEARCH_NONE: No safe search filtering (0)
        SAFESEARCH_MODERATE: Moderate safe search filtering (1)
        SAFESEARCH_STRICT: Strict safe search filtering (2)

    Example:
        >>> # Initialize tool
        >>> search_tool = SearXNGTool()
        >>>
        >>> # Basic search
        >>> results = search_tool.search("python programming")
        >>> print(f"Found {len(results)} results")
        Found 10 results
        >>>
        >>> # Advanced search
        >>> results = search_tool.search(
        ...     query="machine learning",
        ...     categories=["science", "general"],
        ...     language="en",
        ...     safesearch=SearXNGTool.SAFESEARCH_MODERATE,
        ...     time_range="week"
        ... )
    """

    SAFESEARCH_NONE = 0
    SAFESEARCH_MODERATE = 1
    SAFESEARCH_STRICT = 2

    CATEGORIES = (
        "general",
        "images",
        "videos",
        "news",
        "map",
        "music",
        "it",
        "science",
        "files",
        "social media",
    )

    LANGUAGES = (
        "auto",
        "en",
        "pt",
        "es",
        "fr",
        "de",
        "it",
        "ru",
        "nl",
        "pd",
        "vi",
        "id",
        "ar",
        "th",
        "zh-cn",
        "ja",
        "ko",
        "tr",
        "cs",
        "da",
        "fi",
        "hu",
        "no",
        "sv",
        "uk",
    )

    def __init__(
        self, base_url: str = None, api_key: str = None, verify_ssl: bool = False
    ):
        """
        Initializes the SearXNGTool with API configuration.

        Sets up the HTTP client and authentication for SearXNG API requests.
        Supports both environment variable and direct parameter configuration.

        Args:
            base_url: Base URL of the SearXNG API instance
            api_key: API key for SearXNG authentication (optional)
            verify_ssl: Whether to verify SSL certificates (default: False)

        Example:
            >>> # Using default public instance
            >>> tool = SearXNGTool()
            >>> print(f"Using instance: {tool.base_url}")
            Using instance: https://searxng.site

            >>> # Custom instance with authentication
            >>> tool = SearXNGTool(
            ...     base_url="https://private.searxng.instance",
            ...     api_key="your-secret-key",
            ...     verify_ssl=True
            ... )
            >>> print(f"SSL verification: {tool.verify_ssl}")
            SSL verification: True
            >>> print("Authorization" in tool.http_client.headers)
            True
        """
        logger.info("Initializing SearXNGTool")
        self.base_url = base_url or os.getenv(
            "FBPY_SEARXNG_BASE_URL", "https://searxng.site"
        )
        self.api_key = api_key or os.getenv("FBPY_SEARXNG_API_KEY", None)
        self.verify_ssl = verify_ssl or "https://" in self.base_url
        self.http_client = HTTPClient(
            base_url=self.base_url,
            headers=self._build_headers(),
            verify_ssl=self.verify_ssl,
        )  # Inicializa HTTPClient com headers
        logger.info(
            f"SearXNGTool initialized with base_url={self.base_url}, api_key={'PROVIDED' if self.api_key else 'NOT PROVIDED'} and verify_ssl={self.verify_ssl}"
        )

    def _build_headers(self) -> Dict[str, str]:
        """
        Builds default HTTP headers for SearXNG requests.

        Creates a standard User-Agent and sets up authentication if API key is provided.

        Returns:
            Dictionary of HTTP headers

        Example:
            >>> tool = SearXNGTool(api_key="test-key")
            >>> headers = tool._build_headers()
            >>> print(headers.keys())
            dict_keys(['User-Agent', 'Content-Type', 'Authorization'])
            >>> print(headers['Authorization'])
            Bearer test-key
        """
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Content-Type": "application/json",  # Default to application/json for GET
        }

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _validate_search_parameters(self, language: str, safesearch: int) -> None:
        """
        Validates search parameters before making the request.

        Checks that the language code is valid and that the safe search level
        is one of the supported values.

        Args:
            language: Language code to validate
            safesearch: Safe search level to validate

        Raises:
            ValueError: If language or safesearch parameters are invalid

        Example:
            >>> tool = SearXNGTool()
            >>> # Valid parameters
            >>> tool._validate_search_parameters("en", SearXNGTool.SAFESEARCH_MODERATE)
            >>>
            >>> # Invalid language
            >>> try:
            ...     tool._validate_search_parameters("invalid", 0)
            ... except ValueError as e:
            ...     print(f"Error: {e}")
            Error: Invalid language: invalid. Use 'auto' or a valid ISO 639-1 code.
        """
        if language not in self.LANGUAGES and language != "auto":
            logger.error(f"Invalid language: {language}")
            raise ValueError(
                f"Invalid language: {language}. Use 'auto' or a valid ISO 639-1 code."
            )
        if safesearch not in (
            self.SAFESEARCH_NONE,
            self.SAFESEARCH_MODERATE,
            self.SAFESEARCH_STRICT,
        ):
            logger.error(f"Invalid safe search level: {safesearch}")
            raise ValueError(
                f"Invalid safe search level: {safesearch}. Use SAFESEARCH_NONE(0), SAFESEARCH_MODERATE(1), or SAFESEARCH_STRICT(2)."
            )

    def _prepare_search_params(
        self,
        query: str,
        categories: Optional[Union[str, List[str]]],
        language: str,
        time_range: str,
        safesearch: int,
    ) -> Dict[str, Any]:
        """
        Prepares search request parameters for the SearXNG API.

        Constructs the parameter dictionary with query, formatting, filtering,
        and category specifications.

        Args:
            query: Search query string
            categories: Search categories (string or list)
            language: Language code
            time_range: Time range filter
            safesearch: Safe search level

        Returns:
            Dictionary of request parameters

        Example:
            >>> tool = SearXNGTool()
            >>> params = tool._prepare_search_params(
            ...     "python tutorial",
            ...     ["general", "videos"],
            ...     "en",
            ...     "week",
            ...     SearXNGTool.SAFESEARCH_MODERATE
            ... )
            >>> print(params['q'])
            python tutorial
            >>> print(params['category_general'])
            1
            >>> print(params['category_videos'])
            1
        """
        params = {
            "q": query,
            "format": "json",
            "language": language,
            "safesearch": safesearch,
            "time_range": time_range,
            "pageno": 1,  # Initial results page
        }
        if not categories:
            categories = ["general"]
        for category in categories:
            if category.lower() in self.CATEGORIES:
                params[f"category_{category.lower()}"] = 1
        logger.debug(f"Request parameters set: {params}")
        return params

    def _handle_http_error(self, e: Exception) -> List[Dict[str, Any]]:
        """
        Handles HTTP errors by logging and returning empty results.

        Args:
            e: The exception that occurred during the HTTP request

        Returns:
            Empty list to indicate no results due to error

        Example:
            >>> tool = SearXNGTool()
            >>> results = tool._handle_http_error(httpx.TimeoutException("Timeout"))
            >>> Error during SearXNG request: Timeout
            >>> print(results)
            []
        """
        logger.error(f"Error during SearXNG request: {e}")
        return []

    def search(
        self,
        query: str,
        categories: Optional[Union[str, List[str]]] = ["general"],
        language: str = "auto",
        time_range: str = None,
        safesearch: int = SAFESEARCH_NONE,
    ) -> List[Dict[str, Any]]:
        """
        Performs a synchronous search on SearXNG using the GET method.

        Executes a search query and returns results from multiple search engines
        aggregated by SearXNG. Supports various search categories, languages,
        time ranges, and safe search filtering.

        Args:
            query: Search term or phrase
            categories: Search categories (e.g., 'general', 'images', 'news').
                       Can be string or list of strings. Default: ['general']
            language: Search language (ISO 639-1 code, e.g., 'en', 'pt', 'es').
                      Default: 'auto' (automatic detection)
            time_range: Time range filter ('day', 'week', 'month', 'year').
                        Default: None (no time filter)
            safesearch: Safe search level using class constants.
                        Default: SAFESEARCH_NONE (no filtering)

        Returns:
            List of search result dictionaries. Returns empty list on error.

        Raises:
            ValueError: If language or safesearch parameters are invalid
            httpx.HTTPError: If HTTP request fails

        Example:
            >>> # Basic search
            >>> results = search_tool.search("python programming")
            >>> print(f"Found {len(results)} results")
            Found 15 results
            >>> print(results[0].keys())
            dict_keys(['url', 'title', 'content', 'score', 'publishedDate', 'other_info'])

            >>> # Advanced search
            >>> results = search_tool.search(
            ...     query="machine learning",
            ...     categories=["science", "news"],
            ...     language="en",
            ...     time_range="week",
            ...     safesearch=SearXNGTool.SAFESEARCH_MODERATE
            ... )
            >>> for result in results[:3]:
            ...     print(f"- {result['title'][:50]}...")
            - Machine Learning: A Complete Beginner's Guide...
            - Introduction to Machine Learning with Python...
            - Deep Learning vs Machine Learning: What's the...
        """
        logger.info(
            f"Starting synchronous SearXNG search with query: '{query}' using method: 'GET'"
        )
        self._validate_search_parameters(language, safesearch)
        params = self._prepare_search_params(
            query, categories, language, time_range, safesearch
        )

        try:
            response = self.http_client.sync_request(
                method="GET", endpoint="search", params=params
            )

            response_json = response.json()
            results = response_json.get("results", [])
            logger.info(
                f"Synchronous SearXNG search for query: '{query}' completed successfully. Results found: {len(results)}"
            )
            return results
        except httpx.HTTPError as e:
            return self._handle_http_error(e)
        finally:
            logger.debug(f"Finishing synchronous SearXNG search for query: '{query}'")

    async def async_search(
        self,
        query: str,
        categories: Optional[Union[str, List[str]]] = ["general"],
        language: str = "auto",
        time_range: str = None,
        safesearch: int = SAFESEARCH_NONE,
    ) -> List[Dict[str, Any]]:
        """
        Performs an asynchronous search on SearXNG using the GET method.

        Same functionality as search() but using async/await for non-blocking
        operation. Ideal for concurrent searches or async applications.

        Args:
            query: Search term or phrase
            categories: Search categories (e.g., 'general', 'images', 'news').
                       Can be string or list of strings. Default: ['general']
            language: Search language (ISO 639-1 code, e.g., 'en', 'pt', 'es').
                      Default: 'auto' (automatic detection)
            time_range: Time range filter ('day', 'week', 'month', 'year').
                        Default: None (no time filter)
            safesearch: Safe search level using class constants.
                        Default: SAFESEARCH_NONE (no filtering)

        Returns:
            List of search result dictionaries. Returns empty list on error.

        Raises:
            ValueError: If language or safesearch parameters are invalid
            httpx.HTTPError: If HTTP request fails

        Example:
            >>> import asyncio
            >>> async def concurrent_searches():
            ...     tool = SearXNGTool()
            ...     # Perform multiple searches concurrently
            ...     search1 = tool.async_search("python tutorials")
            ...     search2 = tool.async_search("javascript guides")
            ...     results1, results2 = await asyncio.gather(search1, search2)
            ...     print(f"Python: {len(results1)} results, JS: {len(results2)} results")
            ...     return results1, results2
            >>>
            >>> results = asyncio.run(concurrent_searches())
            Python: 12 results, JS: 10 results
        """
        logger.info(
            f"Starting asynchronous SearXNG search with query: '{query}' using method: 'GET'"
        )
        self._validate_search_parameters(language, safesearch)
        params = self._prepare_search_params(
            query, categories, language, time_range, safesearch
        )

        try:
            response = await self.http_client.async_request(
                method="GET", endpoint="search", params=params
            )

            response_json = response.json()
            results = response_json.get("results", [])
            logger.info(
                f"Asynchronous SearXNG search for query: '{query}' completed successfully. Results found: {len(results)}"
            )
            return results
        except httpx.HTTPError as e:
            return self._handle_http_error(e)
        finally:
            logger.debug(f"Finishing asynchronous SearXNG search for query: '{query}'")
