import click
import os
from ..search import SearXNGTool
from .output_utils import (
    format_results_txt,
    format_results_json,
    format_results_markdown,
)


@click.command()
@click.argument("query", type=str)
@click.option(
    "--num-results",
    "-n",
    type=int,
    default=10,
    show_default=True,
    help="Número de resultados (1-30)",
)
@click.option(
    "--categories", "-c", type=str, default=None, help='Categorias (ex: "general,news")'
)
@click.option(
    "--lang", "-l", type=str, default="pt", show_default=True, help="Idioma da busca"
)
@click.option(
    "--safesearch",
    "-s",
    type=int,
    default=0,
    show_default=True,
    help="Filtro de segurança (0=off, 1=moderate, 2=strict)",
)
@click.option("--base-url", type=str, help="URL base do SearXNG (sobrescreve config)")
@click.option(
    "--output",
    "-o",
    type=click.Choice(["txt", "json", "markdown"]),
    default="markdown",
    show_default=True,
    help="Formato de saída",
)
@click.option("--verbose", "-v", is_flag=True, help="Modo verbose")
@click.pass_context
def websearch(
    ctx, query, num_results, categories, lang, safesearch, base_url, output, verbose
):
    """Realiza busca na web via SearXNG e exibe resultados."""
    if verbose:
        click.echo(click.style("Iniciando busca...", fg="green"))

    # Carregar config (reutilizável)
    base_url = base_url or os.getenv(
        "FBPY_SEARXNG_BASE_URL", "http://192.168.15.100:3003"
    )

    # Instanciar tool
    tool = SearXNGTool(base_url=base_url)

    try:
        # Preparar params
        cat_list = [c.strip() for c in categories.split(",")] if categories else None
        if num_results < 1 or num_results > 30:
            raise ValueError("num_results deve ser entre 1 e 30")

        # Executar busca (sync)
        all_results = tool.search(
            query=query,
            categories=cat_list,
            language=lang,
            safesearch=safesearch,
        )
        results = all_results[:num_results] if all_results else []

        if not results:
            click.echo(click.style("Nenhum resultado encontrado.", fg="yellow"))
            return

        # Formatar saída (reutilizável)
        if output == "json":
            formatted = format_results_json(results)
        elif output == "txt":
            formatted = format_results_txt(results, query)
        else:  # markdown
            formatted = format_results_markdown(results)

        click.echo(formatted)

        if verbose:
            click.echo(
                click.style(
                    f"Busca concluída: {len(results)} resultados para '{query}'.",
                    fg="green",
                )
            )

    except ValueError as ve:
        click.echo(click.style(f"Erro de parâmetro: {str(ve)}", fg="red"), err=True)
        ctx.exit(1)
    except Exception as e:
        click.echo(click.style(f"Erro na busca: {str(e)}", fg="red"), err=True)
        ctx.exit(1)
