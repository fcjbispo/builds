import json
from typing import List, Dict, Any


def format_results_txt(results: List[Dict[str, Any]], query: str) -> str:
    """Formata resultados em texto simples."""
    output = f"Resultados para '{query}':\n\n"
    for i, res in enumerate(results, 1):
        snippet = (
            res.get("content", "N/A")[:200] + "..."
            if len(res.get("content", "")) > 200
            else res.get("content", "N/A")
        )
        output += f"{i}. {res.get('title', 'N/A')}\n"
        output += f"   URL: {res.get('url', 'N/A')}\n"
        output += f"   Snippet: {snippet}\n\n"
    return output


def format_results_json(results: List[Dict[str, Any]]) -> str:
    """Formata resultados em JSON indentado."""
    return json.dumps(results, indent=2, ensure_ascii=False)


def format_results_markdown(results: List[Dict[str, Any]]) -> str:
    """Formata resultados em tabela Markdown."""
    md = "| # | Title | URL | Snippet | Score |\n| --- | --- | --- | --- | --- |\n"
    for i, res in enumerate(results, 1):
        snippet = (
            res.get("content", "N/A")[:100] + "..."
            if len(res.get("content", "")) > 100
            else res.get("content", "N/A")
        )
        url = res.get("url", "N/A")
        md += f"| {i} | {res.get('title', 'N/A')} | [{url}]({url}) | {snippet} | {res.get('score', 'N/A')} |\n"
    return md
