import click
import os
from ..scrape import FireCrawlTool
import json


@click.command()
@click.argument("url", type=str)
@click.option(
    "--formats",
    "-f",
    type=str,
    default="markdown",
    show_default=True,
    help="Output formats (comma-separated: markdown,html). Default: markdown"
)
@click.option(
    "--only-main-content",
    "-m",
    is_flag=True,
    default=True,
    show_default=True,
    help="Extract only main content, exclude navigation/ads"
)
@click.option(
    "--remove-base64-images",
    "-b",
    is_flag=True,
    default=True,
    show_default=True,
    help="Remove base64 encoded images from output"
)
@click.option(
    "--timeout",
    "-t",
    type=int,
    default=12000,
    show_default=True,
    help="Request timeout in milliseconds"
)
@click.option(
    "--base-url",
    type=str,
    help="FireCrawl base URL (overrides config)"
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["txt", "json", "markdown"]),
    default="markdown",
    show_default=True,
    help="Output format"
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose mode")
@click.pass_context
def webscrape(ctx, url, formats, only_main_content, remove_base64_images, timeout, base_url, output, verbose):
    """Scrapes a webpage using FireCrawl and displays the content."""
    if verbose:
        click.echo(click.style("Starting scrape...", fg="green"))

    # Load config
    base_url = base_url or os.getenv(
        "FBPY_FIRECRAWL_BASE_URL", "http://192.168.15.100:3005/v1"
    )

    # Instantiate tool
    tool = FireCrawlTool(base_url=base_url)

    try:
        # Prepare formats list
        formats_list = [f.strip() for f in formats.split(",")] if formats else ["markdown"]

        # Execute scrape
        result = tool.scrape(
            url=url,
            formats=formats_list,
            onlyMainContent=only_main_content,
            removeBase64Images=remove_base64_images,
            timeout=timeout,
        )

        if not result.get("success", False):
            click.echo(click.style("Scrape failed.", fg="red"))
            ctx.exit(1)

        data = result["data"]
        metadata = data.get("metadata", {})

        if verbose:
            click.echo(click.style(f"Scrape completed for {url}", fg="green"))

        # Format output
        title = metadata.get("title", "No title")
        description = metadata.get("description", "No description")[:200] + "..." if metadata.get("description") else "No description"

        if output == "json":
            click.echo(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            # For txt and markdown, show title, description, and preview of markdown content
            content_preview = data.get("markdown", "No content")[:500] + "..." if len(data.get("markdown", "")) > 500 else data.get("markdown", "No content")

            if output == "txt":
                formatted = f"Title: {title}\n\nDescription: {description}\n\nContent Preview:\n{content_preview}"
            else:  # markdown
                formatted = f"# {title}\n\n**Description:** {description}\n\n## Content Preview\n\n{content_preview}"

            click.echo(formatted)

    except Exception as e:
        click.echo(click.style(f"Scrape error: {str(e)}", fg="red"), err=True)
        ctx.exit(1)