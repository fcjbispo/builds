import click
import os
from pathlib import Path
import json
from typing import Dict, Any

from .websearch import websearch
from .webscrape import webscrape
from .extractmd import extractmd

# Note: app.json is loaded directly; no app.py module yet


# Load app configuration from app.json
def load_app_config() -> Dict[str, Any]:
    """Load configuration from app.json and override with environment variables."""
    config_path = Path(__file__).parent.parent / "app.json"
    if not config_path.exists():
        click.echo("Warning: app.json not found", err=True)
        return {}

    with open(config_path, "r") as f:
        config = json.load(f)

    # Override with environment variables if present
    env_vars = {
        "log_level": "FBPY_LOG_LEVEL",
        "semaphores": "FBPY_SEMAPHORES",
        # Add more as needed
    }

    for key, env_key in env_vars.items():
        if env_key in os.environ:
            if "logging" in config and key in config["logging"]:
                config["logging"][key] = os.environ[env_key]
            elif (
                "config" in config
                and "llm" in config["config"]
                and key in config["config"]["llm"]
            ):
                config["config"]["llm"][key] = os.environ[env_key]

    return config


@click.version_option(version="0.1.4", prog_name="fbpyutils-ai")
@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """FBPyUtils AI - Command Line Interface for AI Utilities."""
    if ctx.invoked_subcommand is None:
        click.echo("FBPyUtils AI CLI - Use --help for commands.")
        ctx.exit(0)

    # Load config on CLI invocation
    config = load_app_config()
    click.echo(
        f"Loaded config: {config.get('app', {}).get('name', 'Unknown')} v{config.get('app', {}).get('version', 'Unknown')}"
    )


cli.add_command(websearch)
cli.add_command(webscrape)
cli.add_command(extractmd)


if __name__ == "__main__":
    cli()
