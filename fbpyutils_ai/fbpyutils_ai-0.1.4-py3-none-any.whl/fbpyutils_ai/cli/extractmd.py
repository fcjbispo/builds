import click
import os
from pathlib import Path
from ..document import DoclingConverter


@click.command("extractmd")
@click.argument("source", type=str)
@click.option(
    "--ocr",
    "-o",
    is_flag=True,
    default=True,
    show_default=True,
    help="Enable OCR for scanned documents"
)
@click.option(
    "--force-image",
    "-f",
    is_flag=True,
    default=False,
    show_default=True,
    help="Convert PDF to images first for better OCR"
)
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, writable=True),
    help="Path to save extracted markdown file (if not provided, prints to console)"
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose mode")
@click.pass_context
def extractmd(ctx, source, ocr, force_image, output, verbose):
    """Extracts markdown from documents using DoclingConverter."""
    if verbose:
        click.echo(click.style("Starting document extraction...", fg="green"))

    # Validate source file exists
    if not os.path.exists(source):
        click.echo(click.style(f"Source file not found: {source}", fg="red"), err=True)
        ctx.exit(1)

    # Instantiate converter
    converter = DoclingConverter()

    try:
        # Execute conversion to markdown
        content = converter.convert(
            source=source,
            output_format="md",
            ocr=ocr,
            force_image=force_image,
        )

        if output:
            # Write to file
            output_path = Path(output)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)
            if verbose:
                click.echo(click.style(f"Extracted content saved to: {output}", fg="green"))
        else:
            # Print to console (formatted as markdown)
            click.echo(content)

        if verbose:
            click.echo(click.style("Extraction completed successfully.", fg="green"))

    except Exception as e:
        click.echo(click.style(f"Extraction error: {str(e)}", fg="red"), err=True)
        ctx.exit(1)