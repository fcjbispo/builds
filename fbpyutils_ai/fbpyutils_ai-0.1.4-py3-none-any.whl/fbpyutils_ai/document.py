"""
Document conversion module using Docling CLI tool.

This module provides a utility class for converting documents between various formats
using the Docling command-line interface. It supports multiple input and output formats
with flexible configuration options including OCR, PDF parsing, and image handling.

Key Features:
- Automatic input format detection from file extensions
- Support for PDF, DOCX, PPTX, HTML, images, AsciiDoc, and Markdown
- OCR (Optical Character Recognition) for scanned documents
- PDF parsing with multiple backend options
- Image export modes (placeholder, embedded, referenced)
- Temporary file handling for safe conversions
- Multi-threading support for performance
- Device selection (CPU, CUDA, MPS, auto)

Example:
    >>> from fbpyutils_ai.document import DoclingConverter
    >>> converter = DoclingConverter()
    >>>
    >>> # Convert PDF to Markdown with OCR
    >>> content = converter.convert(
    ...     source="document.pdf",
    ...     output_format="md",
    ...     ocr=True,
    ...     table_mode="accurate"
    ... )
    >>> print(f"Converted content length: {len(content)} characters")
    Converted content length: 15420 characters
"""

import os
import subprocess
import tempfile
import uuid
from typing import Optional, List, Dict
from pathlib import Path
from pdf2image import convert_from_path

from fbpyutils_ai import logger


class DoclingConverter:
    """
    A utility class for converting documents using the Docling CLI tool.

    This class provides methods to convert documents between various formats,
    with support for OCR, PDF parsing, and flexible configuration options.

    The converter automatically detects input formats, handles temporary files
    safely, and provides detailed error reporting for troubleshooting.

    Attributes:
        SUPPORTED_INPUT_FORMATS (List[str]): Supported input document formats
        SUPPORTED_IMAGE_EXPORT_MODES (List[str]): Supported image export modes
        SUPPORTED_OUTPUT_FORMATS (List[str]): Supported output document formats
        SUPPORTED_DEVICES (List[str]): Supported processing devices (cpu, cuda, mps, auto)
        SUPPORTED_TABLE_MODES (List[str]): Supported table extraction modes (fast, accurate)

    Example:
        >>> converter = DoclingConverter()
        >>> print("Supported formats:", converter.SUPPORTED_INPUT_FORMATS)
        Supported formats: ['pdf', 'docx', 'pptx', 'html', 'image', 'asciidoc', 'md']

        >>> # Check docling version
        >>> version_info = converter.version()
        >>> print(f"Docling version: {version_info.get('docling_version', 'Unknown')}")
        Docling version: 2.1.2
    """

    SUPPORTED_INPUT_FORMATS: List[str] = [
        "pdf",
        "docx",
        "pptx",
        "html",
        "image",
        "asciidoc",
        "md",
    ]
    SUPPORTED_IMAGE_EXPORT_MODES: List[str] = ["placeholder", "embedded", "referenced"]
    SUPPORTED_OUTPUT_FORMATS: List[str] = ["md", "json", "text", "doctags", "html"]
    SUPPORTED_DEVICES: List[str] = ["cpu", "cuda", "mps", "auto"]
    SUPPORTED_TABLE_MODES: List[str] = ["fast", "accurate"]

    @staticmethod
    def _validate_source(source: str) -> bool:
        """
        Validate if the source file exists and is accessible.

        Args:
            source (str): Path to the source file

        Returns:
            bool: True if file exists, otherwise raises FileNotFoundError

        Raises:
            FileNotFoundError: If source file does not exist

        Example:
            >>> # Valid file path
            >>> result = DoclingConverter._validate_source("existing_file.pdf")
            >>> print(result)
            True

            >>> # Invalid file path
            >>> try:
            ...     DoclingConverter._validate_source("nonexistent_file.pdf")
            ... except FileNotFoundError as e:
            ...     print(f"Error: {e}")
            Error: Source file not found: nonexistent_file.pdf
        """
        if not os.path.exists(source):
            logger.error(f"Source file not found: {source}")
            raise FileNotFoundError(f"Source file not found: {source}")
        return True

    @staticmethod
    def _detect_input_format(source: str) -> Optional[str]:
        """
        Automatically detect input format from file extension.

        Args:
            source (str): Path to the source file

        Returns:
            Optional[str]: Detected input format or None if not recognized

        Example:
            >>> # Detect PDF format
            >>> format = DoclingConverter._detect_input_format("document.pdf")
            >>> print(format)
            pdf

            >>> # Detect Markdown format
            >>> format = DoclingConverter._detect_input_format("README.md")
            >>> print(format)
            md

            >>> # Unsupported format
            >>> format = DoclingConverter._detect_input_format("file.xyz")
            >>> print(format)
            None
        """
        ext = Path(source).suffix.lower().replace(".", "")

        # Map common image extensions to "image"
        image_extensions = {"jpg", "jpeg", "png", "gif", "bmp", "tiff", "tif", "webp"}
        if ext in image_extensions:
            detected_format = "image"
        else:
            detected_format = (
                ext if ext in DoclingConverter.SUPPORTED_INPUT_FORMATS else None
            )

        if detected_format:
            logger.info(f"Detected input format: {detected_format}")
        else:
            logger.error(f"Could not detect format for file: {source}")

        return detected_format

    @staticmethod
    def _generate_image_based_pdf(source_pdf: str) -> str:
        """
        Converts a PDF into a new PDF where each page is an image.

        This method converts each page of a PDF into a high-resolution image (300 DPI PNG)
        and then creates a new PDF from these images. This process improves OCR accuracy
        for documents with complex layouts or scanned content.

        Args:
            source_pdf (str): Path to the original PDF file

        Returns:
            str: Path to the newly generated image-based PDF file

        Note:
            The method creates temporary files that are automatically cleaned up,
            but returns a persistent PDF file that must be managed by the caller.

        Example:
            >>> original_pdf = "scanned_document.pdf"
            >>> image_pdf = DoclingConverter._generate_image_based_pdf(original_pdf)
            >>> print(f"Created image-based PDF: {image_pdf}")
            Created image-based PDF: /tmp/docling_persistent_abc123.pdf
            >>> # Clean up the persistent file when done
            >>> import os
            >>> os.remove(image_pdf)
        """
        logger.info(f"Converting PDF to images for better OCR: {source_pdf}")

        pdf_tmpdir = tempfile.TemporaryDirectory(
            prefix=f"docling_pdf_{uuid.uuid4().hex}_"
        )
        try:
            # Generate unique prefix for image files
            image_prefix = f"page_{uuid.uuid4().hex}"

            # Convert PDF to high-quality images with unique names
            logger.debug("Converting PDF pages to images...")
            images = convert_from_path(
                source_pdf,
                dpi=300,  # High DPI for better OCR
                output_folder=pdf_tmpdir.name,
                fmt="png",  # PNG format for better quality
                output_file=image_prefix,  # Prefix for image files
            )

            # Create temporary PDF with unique name
            with tempfile.NamedTemporaryFile(
                prefix=f"docling_converted_{uuid.uuid4().hex}_",
                suffix=".pdf",
                dir=pdf_tmpdir.name,
                delete=False,
            ) as temp_pdf:
                logger.debug(f"Creating temporary PDF from images: {temp_pdf.name}")

                # Convert first image to PDF and append the rest
                images[0].save(
                    temp_pdf.name,
                    "PDF",
                    resolution=300.0,
                    save_all=True,
                    append_images=images[1:],
                )

                # Create a copy of the temporary PDF to prevent deletion
                with tempfile.NamedTemporaryFile(
                    prefix=f"docling_persistent_{uuid.uuid4().hex}_",
                    suffix=".pdf",
                    delete=False,
                ) as persistent_pdf:
                    with open(temp_pdf.name, "rb") as src_file:
                        persistent_pdf.write(src_file.read())

                    # Update source to use the persistent PDF
                    source = persistent_pdf.name
                    logger.info(
                        f"Successfully created persistent image-based PDF, path: {source}"
                    )
                    logger.debug(
                        f"Persistent PDF file exists: {os.path.exists(source)}"
                    )
                    return source
        finally:
            # Ensure the temporary directory is cleaned up
            pdf_tmpdir.cleanup()

    def convert(
        self,
        source: str,
        input_format: Optional[str] = None,
        output_format: str = "md",
        ocr: bool = True,
        ocr_engine: str = "easyocr",
        pdf_backend: str = "dlparse_v1",
        table_mode: str = "accurate",
        image_export_mode: str = "placeholder",
        artifacts_path: Optional[str] = None,
        abort_on_error: bool = False,
        num_threads: int = 4,
        device: str = "auto",
        force_image: bool = False,
    ) -> str:
        """
        Convert document using docling with flexible parameters.

        Args:
            source (str): Path to source file
            input_format (Optional[str]): Input file format (auto-detected if None)
            output_format (str): Desired output format: "md", "json", "text", "doctags", "html"
            ocr (bool): Enable/disable OCR for scanned documents
            ocr_engine (str): OCR engine: "easyocr", "tesseract", "paddleocr"
            pdf_backend (str): PDF parsing backend: "dlparse_v1", "dlparse_v2", "pypdfium2"
            table_mode (str): Table extraction mode: "fast", "accurate"
            image_export_mode (str): Image handling: "placeholder", "embedded", "referenced"
            artifacts_path (Optional[str]): Path to model artifacts for offline processing
            abort_on_error (bool): Stop processing on first error (default: False)
            num_threads (int): Number of threads for processing (1 to CPU count)
            device (str): Processing device: "cpu", "cuda", "mps", "auto"
            force_image (bool): Convert PDF to images first for better OCR (default: False)

        Returns:
            str: Converted document content as string

        Raises:
            FileNotFoundError: If source file does not exist
            ValueError: If input/output format or parameters are unsupported
            subprocess.CalledProcessError: If docling conversion fails

        Example:
            >>> converter = DoclingConverter()
            >>>
            >>> # Simple PDF to Markdown conversion
            >>> md_content = converter.convert("document.pdf", output_format="md")
            >>> print(f"Converted {len(md_content)} characters to Markdown")
            Converted 8420 characters to Markdown
            >>>
            >>> # Advanced conversion with OCR and table extraction
            >>> content = converter.convert(
            ...     source="scanned_report.pdf",
            ...     output_format="json",
            ...     ocr=True,
            ...     table_mode="accurate",
            ...     force_image=True,
            ...     num_threads=8
            ... )
            >>> import json
            >>> data = json.loads(content)
            >>> print(f"Document has {len(data.get('paragraphs', []))} paragraphs")
            Document has 42 paragraphs
        """
        try:
            # Validate inputs
            self._validate_source(source)

            if input_format is None:
                input_format = self._detect_input_format(source)

            if input_format not in self.SUPPORTED_INPUT_FORMATS:
                logger.error(f"Unsupported input format: {input_format}")
                raise ValueError(f"Unsupported input format: {input_format}")

            # Automatically enable OCR for PDF with force_image
            if force_image and (
                input_format == "pdf" or Path(source).suffix.lower() == ".pdf"
            ):
                logger.info("Enabling OCR for PDF due to force_image=True")
                ocr = True

            if output_format not in self.SUPPORTED_OUTPUT_FORMATS:
                logger.error(f"Unsupported output format: {output_format}")
                raise ValueError(f"Unsupported output format: {output_format}")
            if image_export_mode not in self.SUPPORTED_IMAGE_EXPORT_MODES:
                logger.error(f"Unsupported image export mode: {image_export_mode}")
                raise ValueError(f"Unsupported image export mode: {image_export_mode}")

            if table_mode not in self.SUPPORTED_TABLE_MODES:
                logger.error(f"Unsupported table mode: {table_mode}")
                raise ValueError(f"Unsupported table mode: {table_mode}")

            # Handle force_image for PDF inputs
            if force_image and (
                input_format == "pdf" or Path(source).suffix.lower() == ".pdf"
            ):
                if output_format == "image":
                    logger.warning(
                        "force_image=True with output_format='image' is redundant"
                    )
                source = self._generate_image_based_pdf(source)

            # Create temporary output directory
            with tempfile.TemporaryDirectory() as tmpdir:
                # Derive output filename based on source filename
                source_filename = Path(source).stem  # Get filename without extension
                output_filename = f"{source_filename}.{output_format}"
                output_path = os.path.join(tmpdir, output_filename)

                # Construct docling command
                cmd = [
                    "docling",
                    "--from",
                    input_format,
                    "--to",
                    output_format,
                    "--output",
                    tmpdir,  # Specify output directory
                    "--pdf-backend",
                    pdf_backend,
                    "--table-mode",
                    table_mode,
                    "--image-export-mode",
                    image_export_mode,
                ]

                if ocr:
                    cmd.extend(["--ocr", f"--ocr-engine={ocr_engine}"])

                if artifacts_path:
                    cmd.extend(["--artifacts-path", artifacts_path])

                if abort_on_error:
                    cmd.append("--abort-on-error")

                if num_threads:
                    if num_threads < 1 or num_threads > os.cpu_count():
                        logger.info("Invalid number of threads, using default value")
                        num_threads = 4
                    cmd.extend(["--num-threads", str(num_threads)])

                if device:
                    if device not in self.SUPPORTED_DEVICES:
                        logger.info("Invalid device specified, using default value")
                        device = "auto"
                    cmd.extend(["--device", device])

                # Debug: Check if source file exists before running docling
                logger.debug(f"Source file path before docling: {source}")
                logger.debug(
                    f"Source file exists before docling: {os.path.exists(source)}"
                )

                cmd.append(source)

                try:
                    # Run docling command with explicit UTF-8 encoding
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        check=True,
                        encoding="utf-8",
                        errors="replace",
                    )

                    # List files in temporary directory to debug
                    output_files = os.listdir(tmpdir)
                    logger.info(f"Files in temp directory: {output_files}")

                    # Find the output file in the temporary directory
                    output_file = next(
                        (f for f in output_files if f.endswith(f".{output_format}")),
                        None,
                    )

                    if not output_file:
                        raise FileNotFoundError(
                            f"No {output_format} file found in temporary directory"
                        )

                    full_output_path = os.path.join(tmpdir, output_file)

                    # Read converted file
                    with open(full_output_path, "r", encoding="utf-8") as f:
                        content = f.read()

                    logger.info(f"Docling conversion successful: {source}")
                    return content

                except (subprocess.CalledProcessError, FileNotFoundError) as e:
                    # Log detailed error information
                    logger.error(f"Docling conversion failed: {e}")

                    # If it's a CalledProcessError, log stdout and stderr
                    if isinstance(e, subprocess.CalledProcessError):
                        logger.error(f"Docling Command: {' '.join(e.cmd)}")
                        logger.error(f"Docling STDOUT: {e.stdout}")
                        logger.error(f"Docling STDERR: {e.stderr}")

                    raise

        except Exception as e:
            # Debug: Log temporary directory details
            logger.error(f"Conversion error in {__file__}: {str(e)}")
            logger.error(f"Temporary source file path: {source}")
            logger.error(
                f"Temporary source file exists: {os.path.exists(source) if 'source' in locals() else 'Not set'}"
            )

            raise

    @staticmethod
    def version() -> Dict[str, str]:
        """
        Get the version of the docling tool and related software components.

        Returns:
            Dict[str, str]: Dictionary containing version information with keys:
                - docling_version: Main docling version
                - docling_core_version: Core library version
                - docling_ibm_models_version: IBM models version (if available)
                - docling_parse_version: Parse library version (if available)

        Raises:
            subprocess.CalledProcessError: If docling version check fails

        Example:
            >>> version_info = DoclingConverter.version()
            >>> print(f"Docling version: {version_info.get('docling_version', 'Unknown')}")
            Docling version: 2.1.2
            >>>
            >>> # Check all available version information
            >>> for component, version in version_info.items():
            ...     print(f"{component}: {version}")
            docling_version: 2.1.2
            docling_core_version: 1.3.0
            docling_ibm_models_version: 1.0.0
            docling_parse_version: 1.2.1
        """
        try:
            cmd = ["docling", "--version"]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            output = result.stdout

            version_info = {}
            for line in output.splitlines():
                if "Docling version:" in line:
                    version_info["docling_version"] = line.split(": ")[1].strip()
                elif "Docling Core version:" in line:
                    version_info["docling_core_version"] = line.split(": ")[1].strip()
                elif "Docling IBM Models version:" in line:
                    version_info["docling_ibm_models_version"] = line.split(": ")[
                        1
                    ].strip()
                elif "Docling Parse version:" in line:
                    version_info["docling_parse_version"] = line.split(": ")[1].strip()

            logger.info(f"Docling version info: {version_info}")

            return version_info

        except subprocess.CalledProcessError as e:
            logger.error(f"Error getting docling version: {e}")
            raise
        except Exception as e:
            logger.error(f"Error getting docling version in {__file__}: {str(e)}")
            raise
