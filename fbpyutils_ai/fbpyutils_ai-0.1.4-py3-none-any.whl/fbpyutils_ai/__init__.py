"""
Initialization module for the fbpyutils_ai package.

This module sets up the fbpyutils_ai package by configuring logging and environment variables.
It loads environment variables using python-dotenv and configures the fbpyutils logging system
with settings from the app.json configuration file.

The module automatically:
- Loads environment variables from .env file
- Sets up logging configuration using RotatingFileHandler and QueueListener
- Configures LLM semaphore settings from environment or config file
- Initializes the global logger instance

Example:
    The module is automatically imported when the package is used:

    >>> import fbpyutils_ai
    >>> # Logging is now configured and ready to use
    >>> from fbpyutils import get_logger
    >>> logger = get_logger()
    >>> logger.info("Application started")

    Environment variables can override default settings:
    >>> import os
    >>> os.environ['FBPY_LOG_LEVEL'] = 'DEBUG'
    >>> os.environ['FBPY_SEMAPHORES'] = '10'
    >>> import fbpyutils_ai  # Re-import to apply new settings

Environment Variables:
    FBPY_LOG_LEVEL: Sets the logging level (default: INFO)
    FBPY_SEMAPHORES: Sets the number of LLM semaphores (default: 6)
"""

import os
import fbpyutils

from dotenv import load_dotenv

_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "INFO")
env.CONFIG = {
    "llm": {
        "semaphores": os.environ.get(
            "FBPY_SEMAPHORES",
            env.CONFIG.get("llm", {}).get("semaphores", 6),
        ),
    },
}

logger = fbpyutils.get_logger()
logger.configure_from_env(env)
