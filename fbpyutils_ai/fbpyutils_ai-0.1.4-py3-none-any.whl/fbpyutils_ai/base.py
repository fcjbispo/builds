"""
Core interfaces and base classes for AI tools in the fbpyutils_ai package.

This module provides abstract base classes and data models for vector databases and LLM services.
It defines the standard interfaces that concrete implementations must follow, ensuring consistency
across different AI service providers and vector database implementations.

Classes:
    VectorDatabase: Abstract base class for vector database implementations
    LLMServiceModel: Data model for LLM service configuration
    LLMService: Abstract base class for LLM service implementations

Example:
    >>> from fbpyutils_ai.base import VectorDatabase, LLMServiceModel, LLMService
    >>> # Create a vector database instance
    >>> class MyVectorDB(VectorDatabase):
    ...     def add_embeddings(self, ids, embeddings, metadatas):
    ...         # Implementation here
    ...         pass
    >>> db = MyVectorDB(distance_function="cosine")
    >>> db.distance_function
    'cosine'
"""

import os
from abc import ABC, abstractmethod
from pydantic import BaseModel
from typing import Any, Optional, Dict, List, Tuple

from fbpyutils_ai import logger


# Interface for the vector database
class VectorDatabase(ABC):
    """
    Abstract base class for vector database implementations.

    This class defines the standard interface that all vector database implementations
    must follow. It supports both cosine and L2 distance functions for similarity search.

    Args:
        distance_function: The distance function to use for similarity search.
                          Valid values are "cosine" or "l2" (default: "l2").

    Raises:
        ValueError: If an invalid distance function is provided.

    Example:
        >>> class MyVectorDB(VectorDatabase):
        ...     def add_embeddings(self, ids, embeddings, metadatas):
        ...         # Implementation here
        ...         pass
        ...     # Implement other required methods...
        >>> db = MyVectorDB(distance_function="cosine")
        >>> db.distance_function
        'cosine'
    """

    def __init__(self, distance_function: str = "l2"):
        logger.info(
            f"VectorDatabase.__init__ called with distance_function={distance_function}"
        )

        distance_function = distance_function or "l2"
        original_function = distance_function

        if distance_function not in ("cosine", "l2"):
            logger.error(
                f"VectorDatabase.__init__ invalid distance function: {distance_function}"
            )
            raise ValueError(
                f"Invalid distance function {distance_function}. Valid values are: cosine|l2."
            )

        self.distance_function = distance_function
        logger.info(
            f"VectorDatabase.__init__ completed: distance_function={original_function} -> {self.distance_function}"
        )

    @abstractmethod
    def add_embeddings(
        self,
        ids: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ):
        """
        Adds embeddings to the database.

        Args:
            ids: List of unique identifiers for the embeddings
            embeddings: List of embedding vectors (each as a list of floats)
            metadatas: List of metadata dictionaries associated with each embedding

        Example:
            >>> db.add_embeddings(
            ...     ids=["doc1", "doc2"],
            ...     embeddings=[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]],
            ...     metadatas=[{"title": "Document 1"}, {"title": "Document 2"}]
            ... )
        """
        logger.info(f"VectorDatabase.add_embeddings called with {len(ids)} embeddings")
        pass

    @abstractmethod
    def search_embeddings(
        self, embedding: List[float], n_results: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Searches for similar embeddings in the database.

        Args:
            embedding: The query embedding vector to search for
            n_results: Maximum number of similar embeddings to return (default: 10)

        Returns:
            List of tuples containing (id, similarity_score) for similar embeddings

        Example:
            >>> results = db.search_embeddings([0.1, 0.2, 0.3], n_results=5)
            >>> for doc_id, score in results:
            ...     print(f"Found similar document {doc_id} with score {score}")
        """
        logger.info(
            f"VectorDatabase.search_embeddings called with embedding dim={len(embedding)}, n_results={n_results}"
        )
        pass

    @abstractmethod
    def get_version(self) -> str:
        """
        Gets the version of the database server.

        Returns:
            String containing the version information of the database server

        Example:
            >>> version = db.get_version()
            >>> print(f"Database version: {version}")
            Database version: 1.2.3
        """
        logger.info("VectorDatabase.get_version called")
        pass

    @abstractmethod
    def count(self, where: Optional[Dict[str, Any]] = None) -> int:
        """
        Counts the number of embeddings in the collection.

        Args:
            where: Optional filter criteria as a dictionary (default: None)

        Returns:
            Integer count of embeddings matching the criteria

        Example:
            >>> total_count = db.count()
            >>> print(f"Total embeddings: {total_count}")
            Total embeddings: 1000

            >>> filtered_count = db.count(where={"category": "tech"})
            >>> print(f"Tech embeddings: {filtered_count}")
            Tech embeddings: 250
        """
        logger.info(f"VectorDatabase.count called with where={where}")
        pass

    @abstractmethod
    def list_collections(self) -> List[str]:
        """
        Lists all collections in the database.

        Returns:
            List of collection names as strings

        Example:
            >>> collections = db.list_collections()
            >>> print(f"Available collections: {collections}")
            Available collections: ['documents', 'images', 'videos']
        """
        logger.info("VectorDatabase.list_collections called")
        pass

    @abstractmethod
    def reset_collection(self):
        """
        Resets the current collection by erasing all documents.

        Warning:
            This operation is irreversible and will delete all data in the current collection.

        Example:
            >>> # Use with caution - this deletes all data!
            >>> db.reset_collection()
            >>> print("Collection has been reset")
            Collection has been reset
        """
        logger.warning(
            "VectorDatabase.reset_collection called - irreversible operation!"
        )
        pass


class LLMServiceModel(BaseModel):
    """
    Data model for LLM service configuration.

    This model represents the configuration for an LLM service provider, including
    API credentials, base URL, and model identification. The API key is automatically
    protected in string representations.

    Attributes:
        provider: Name of the LLM provider (e.g., "openai", "anthropic")
        api_base_url: Base URL for the provider's API
        api_key: API key for authentication (protected in __str__)
        is_local: Whether this is a local/self-hosted model (default: False)
        model_id: Specific model identifier (e.g., "gpt-4", "claude-3-sonnet")

    Example:
        >>> model = LLMServiceModel(
        ...     provider="openai",
        ...     api_base_url="https://api.openai.com/v1",
        ...     api_key="sk-...",
        ...     model_id="gpt-4"
        ... )
        >>> print(model.provider)
        openai
        >>> print(model)  # API key is hashed for security
        LLMServiceModel(provider=openai, api_base_url=https://api.openai.com/v1, api_key=HASHED, model_id=gpt-4)
    """

    provider: str
    api_base_url: str
    api_key: str
    is_local: bool = False
    model_id: str

    @staticmethod
    def get_llm_service_model(
        model_id: str, provider: Dict[str, Any]
    ) -> "LLMServiceModel":
        """
        Creates an LLMServiceModel instance from provider configuration.

        Args:
            model_id: The model identifier to use
            provider: Dictionary containing provider configuration with keys:
                     - provider: Provider name
                     - base_url: API base URL
                     - env_api_key: Environment variable name for API key
                     - is_local: Optional flag for local models (default: False)

        Returns:
            LLMServiceModel instance configured with the provided settings

        Example:
            >>> provider_config = {
            ...     "provider": "openai",
            ...     "base_url": "https://api.openai.com/v1",
            ...     "env_api_key": "OPENAI_API_KEY"
            ... }
            >>> # Assuming OPENAI_API_KEY is set in environment
            >>> model = LLMServiceModel.get_llm_service_model("gpt-4", provider_config)
            >>> print(model.model_id)
            gpt-4
        """
        logger.info(
            f"LLMServiceModel.get_llm_service_model called with model_id={model_id}, provider={provider.get('provider', 'unknown')}"
        )

        model = LLMServiceModel(
            provider=provider["provider"].lower(),
            api_base_url=provider["base_url"],
            api_key=os.environ.get(provider["env_api_key"]),
            is_local=provider.get("is_local", False),
            model_id=model_id,
        )

        logger.info(
            f"LLMServiceModel.get_llm_service_model completed: created model for {model.provider}"
        )
        return model

    def __str__(self) -> str:
        """
        Returns a string representation with API key hashed for security.

        Returns:
            String representation of the model with sensitive data protected

        Example:
            >>> model = LLMServiceModel(
            ...     provider="anthropic",
            ...     api_base_url="https://api.anthropic.com",
            ...     api_key="sk-ant-...",
            ...     model_id="claude-3-sonnet"
            ... )
            >>> print(model)
            LLMServiceModel(provider=anthropic, api_base_url=https://api.anthropic.com, api_key=HASHED, model_id=claude-3-sonnet)
        """
        return f"LLMServiceModel(provider={self.provider}, api_base_url={self.api_base_url}, api_key=HASHED, model_id={self.model_id})"


# Interface for the LLM service
class LLMService(ABC):
    """
    Abstract base class for LLM service implementations.

    This class defines the standard interface that all LLM service implementations
    must follow. It supports multiple model types (base, embed, vision) and
    provides configuration for timeouts and retry attempts.

    Args:
        base_model: Primary LLM model configuration
        embed_model: Optional embedding model configuration (defaults to base_model)
        vision_model: Optional vision model configuration (defaults to base_model)
        timeout: Request timeout in seconds (default: 300)
        session_retries: Number of retry attempts for failed requests (default: 3)

    Example:
        >>> base_model = LLMServiceModel(
        ...     provider="openai",
        ...     api_base_url="https://api.openai.com/v1",
        ...     api_key="sk-...",
        ...     model_id="gpt-4"
        ... )
        >>> service = MyLLMService(base_model, timeout=600)
        >>> service.timeout
        600
        >>> service.model_map["base"].model_id
        gpt-4
    """

    def __init__(
        self,
        base_model: LLMServiceModel,
        embed_model: Optional[LLMServiceModel] = None,
        vision_model: Optional[LLMServiceModel] = None,
        timeout: int = 300,
        session_retries: int = 3,
    ):
        logger.info(
            f"LLMService.__init__ called with base_model={base_model.model_id}, timeout={timeout}, retries={session_retries}"
        )

        self.model_map = {
            "base": base_model,
            "embed": embed_model or base_model,
            "vision": vision_model or base_model,
        }
        self.timeout = timeout or 300
        self.retries = session_retries or 3

        logger.info(
            f"LLMService.__init__ completed: model_map={list(self.model_map.keys())}, timeout={self.timeout}, retries={self.retries}"
        )

    def get_base_model(self):
        logger.debug("LLMService.get_base_model called")
        return self.model_map["base"]

    def get_embed_model(self):
        logger.debug("LLMService.get_embed_model called")
        return self.model_map["embed"]

    def get_vision_model(self):
        logger.debug("LLMService.get_vision_model called")
        return self.model_map["vision"]

    @abstractmethod
    def generate_embeddings(self, input: List[str]) -> Optional[List[float]]:
        """
        Generates an embedding for the given list of text.

        Args:
            input: List of text strings to generate embeddings for

        Returns:
            List of embedding vectors as floats, or None if generation fails

        Example:
            >>> texts = ["Hello world", "Machine learning"]
            >>> embeddings = service.generate_embeddings(texts)
            >>> if embeddings:
            ...     print(f"Generated {len(embeddings)} embeddings")
            ...     print(f"First embedding dimension: {len(embeddings[0])}")
            Generated 2 embeddings
            First embedding dimension: 1536
        """
        logger.info(f"LLMService.generate_embeddings called with {len(input)} texts")
        pass

    @abstractmethod
    def generate_text(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generates text from a prompt.

        Args:
            prompt: The input text prompt
            **kwargs: Additional parameters for text generation (e.g., temperature, max_tokens)

        Returns:
            Generated text response as a string

        Example:
            >>> prompt = "Write a haiku about programming"
            >>> response = service.generate_text(prompt, temperature=0.7)
            >>> print(response)
            Code flows like water
            Logic branches endlessly
            Bugs hide in the depths
        """
        logger.info(f"LLMService.generate_text called with prompt length={len(prompt)}")
        pass

    @abstractmethod
    def generate_completions(
        self, messages: List[Dict[str, str]], **kwargs
    ) -> Dict[str, Any]:
        """
        Generates text from a chat completion.

        Args:
            messages: List of message dictionaries with role and content
            **kwargs: Additional parameters for completion generation

        Returns:
            Generated completion text as a string

        Example:
            >>> messages = [
            ...     {"role": "system", "content": "You are a helpful assistant"},
            ...     {"role": "user", "content": "What is the capital of France?"}
            ... ]
            >>> response = service.generate_completions(messages)
            >>> print(response)
            The capital of France is Paris.
        """
        logger.info(
            f"LLMService.generate_completions called with {len(messages)} messages"
        )
        pass

    @abstractmethod
    def generate_tokens(self, text: str, **kwargs) -> List[int]:
        """
        Generates tokens from a text.

        Args:
            text: Input text to tokenize
            **kwargs: Additional parameters for tokenization

        Returns:
            List of token IDs as integers

        Example:
            >>> text = "Hello, world!"
            >>> tokens = service.generate_tokens(text)
            >>> print(f"Text: '{text}' -> Tokens: {tokens}")
            Text: 'Hello, world!' -> Tokens: [9906, 11, 4435, 0]
        """
        logger.info(f"LLMService.generate_tokens called with text length={len(text)}")
        pass

    @abstractmethod
    def describe_image(self, image: str, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Describes an image.

        Args:
            image: Image data (base64 encoded)
            prompt: Instructions for how to describe the image
            **kwargs: Additional parameters for image analysis

        Returns:
            Text description of the image

        Example:
            >>> image_data = "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
            >>> prompt = "Describe what you see in this image"
            >>> description = service.describe_image(image_data, prompt)
            >>> print(description)
            The image shows a serene landscape with mountains in the background...
        """
        logger.info(
            f"LLMService.describe_image called with image length={len(image)}, prompt length={len(prompt)}"
        )
        pass

    @abstractmethod
    def get_model_details(
        self, model_type: str = "base", introspection: bool = False, **kwargs
    ) -> Dict[str, Any]:
        """
        Gets the details of a model.

        Args:
            model_type: Type of model to get details for ("base", "embed", or "vision")
            introspection: Whether to perform detailed introspection of the model
            **kwargs: Additional parameters for model details retrieval

        Returns:
            Dictionary containing model details such as name, version, capabilities, etc.

        Example:
            >>> details = service.get_model_details("base", introspection=True)
            >>> print(f"Model: {details.get('name', 'Unknown')}")
            >>> print(f"Max tokens: {details.get('max_tokens', 'Unknown')}")
            Model: gpt-4
            Max tokens: 8192
        """
        logger.info(
            f"LLMService.get_model_details called with model_type={model_type}, introspection={introspection}"
        )
        pass

    @abstractmethod
    def list_models(model_type: str = "base", **kwargs) -> List[Dict[str, Any]]:
        """
        Lists the available models.

        Args:
            model_type: The model type to select which model to use: base, embed or vision. Default: base
            **kwargs: Additional parameters for model listing (e.g., provider, capabilities)

        Returns:
            List of dictionaries containing model information

        Example:
            >>> models = LLMService.list_models(provider="openai")
            >>> for model in models:
            ...     print(f"Model: {model['id']}")
            ...     print(f"Type: {model.get('type', 'unknown')}")
            Model: gpt-4
            Type: chat
        """
        logger.info(f"LLMService.list_models called with model_type={model_type}")
        pass
