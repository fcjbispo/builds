"""
Initialization module for the fbpyutils_ai package.

This module sets up the fbpyutils_ai package by configuring logging and environment variables.
It provides the entry point for the package and automatically initializes core components
including logging infrastructure, environment configuration, and LLM service settings.

The module is automatically imported when the package is used and handles all initialization
tasks transparently, ensuring that logging and configuration are ready before any other
package functionality is used.

Modules
-------
base
    Abstract interfaces and base classes for vector databases and LLM services.
embedding
    Vector database implementations (ChromaDB, PostgreSQL+pgvector, Pinecone).
llm
    LLM service implementations and utilities.
document
    Document conversion utilities using Docling.
scrape
    Web scraping tools using FireCrawl API.
search
    Web search tools using SearXNG metasearch engine.
cli
    Command-line interface tools.

Classes
-------
None (module-level initialization only)

Functions
---------
None (automatic initialization only)

Environment Variables
---------------------
The following environment variables can be set to customize package behavior:

FBPY_LOG_LEVEL : str, optional
    Logging level for the application. Valid values are: DEBUG, INFO, WARNING, ERROR, CRITICAL.
    Default is "INFO".
FBPY_SEMAPHORES : str, optional
    Number of semaphores for controlling LLM service concurrency. Default is "6".
FBPY_SEARXNG_BASE_URL : str, optional
    Base URL for SearXNG instance (default: http://192.168.15.100:3003).
FBPY_FIRECRAWL_BASE_URL : str, optional
    Base URL for FireCrawl service (default: http://192.168.15.100:3005/v1).
FBPY_FIRECRAWL_API_KEY : str, optional
    API key for FireCrawl service authentication.
OPENAI_API_KEY : str, optional
    API key for OpenAI service authentication.
ANTHROPIC_API_KEY : str, optional
    API key for Anthropic service authentication.

Examples
--------
Basic package import and usage:

>>> import fbpyutils_ai
>>> # Logging is now configured and ready to use
>>> from fbpyutils import get_logger
>>> logger = get_logger()
>>> logger.info("Application started")
Application started

Override default configuration:

>>> import os
>>> os.environ['FBPY_LOG_LEVEL'] = 'DEBUG'
>>> os.environ['FBPY_SEMAPHORES'] = '10'
>>> import fbpyutils_ai  # Re-import to apply new settings

Use vector database functionality:

>>> from fbpyutils_ai.embedding import ChromaDB
>>> from fbpyutils_ai.llm import OpenAILLMService
>>> # Initialize components
>>> vector_db = ChromaDB(collection_name="documents")
>>> # Use the database...

Use CLI tools:

>>> from fbpyutils_ai.cli import cli
>>> # Access CLI: python -m fbpyutils_ai.cli --help

Notes
-----
This module automatically:

1. Loads environment variables from .env file using python-dotenv
2. Sets up logging configuration using fbpyutils with app.json settings
3. Configures LLM semaphore settings from environment or config file
4. Initializes the global logger instance

The module must be imported before using any other fbpyutils_ai functionality
to ensure proper initialization of logging and configuration systems.

Dependencies:
- fbpyutils: Core utilities and logging framework
- python-dotenv: Environment variable loading
- pydantic: Data validation and configuration management

See Also
--------
fbpyutils_ai.base : Core interfaces and abstract classes
fbpyutils_ai.embedding : Vector database implementations
fbpyutils_ai.llm : LLM service implementations
fbpyutils_ai.cli : Command-line interface tools
fbpyutils_ai.app : Application configuration settings
"""

import os
import fbpyutils

from dotenv import load_dotenv

_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "INFO")
env.CONFIG = {
    "llm": {
        "semaphores": os.environ.get(
            "FBPY_SEMAPHORES",
            env.CONFIG.get("llm", {}).get("semaphores", 6),
        ),
    },
}

logger = fbpyutils.get_logger()
logger.configure_from_env(env)
