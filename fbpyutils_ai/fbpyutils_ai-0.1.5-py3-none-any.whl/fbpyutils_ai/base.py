"""
Core interfaces and base classes for AI tools in the fbpyutils_ai package.

This module provides abstract base classes and data models for vector databases and LLM services.
It defines the standard interfaces that concrete implementations must follow, ensuring consistency
across different AI service providers and vector database implementations.

The module is designed to support multiple vector database backends (ChromaDB, PostgreSQL+pgvector, Pinecone)
and LLM providers (OpenAI, Anthropic, etc.) through a unified interface.

Classes
-------
VectorDatabase
    Abstract base class for vector database implementations supporting cosine and L2 distance functions.
LLMServiceModel
    Data model for LLM service configuration with provider-specific settings.
LLMService
    Abstract base class for LLM service implementations supporting text, embeddings, and vision models.

Examples
--------
Create a custom vector database implementation:

>>> from fbpyutils_ai.base import VectorDatabase
>>> class MyVectorDB(VectorDatabase):
...     def add_embeddings(self, ids, embeddings, metadatas):
...         # Implementation here
...         pass
...     # Implement other required methods...
>>> db = MyVectorDB(distance_function="cosine")
>>> db.distance_function
'cosine'

Configure an LLM service:

>>> from fbpyutils_ai.base import LLMServiceModel
>>> model = LLMServiceModel(
...     provider="openai",
...     api_base_url="https://api.openai.com/v1",
...     api_key="sk-...",
...     model_id="gpt-4"
... )
>>> print(f"Model configured: {model.provider}/{model.model_id}")
Model configured: openai/gpt-4

Notes
-----
All concrete implementations must inherit from these abstract base classes and implement
all abstract methods. The interfaces ensure consistent behavior across different providers
and facilitate testing and development.

See Also
--------
fbpyutils_ai.embedding : Concrete vector database implementations
fbpyutils_ai.llm.openai : OpenAI service implementation
fbpyutils_ai.llm.utils : LLM utility functions
"""

import os
from abc import ABC, abstractmethod
from pydantic import BaseModel
from typing import Any, Optional, Dict, List, Tuple

from fbpyutils_ai import logger


# Interface for the vector database
class VectorDatabase(ABC):
    """
    Abstract base class for vector database implementations.

    This class defines the standard interface that all vector database implementations
    must follow. It provides a unified API for vector operations including adding
    embeddings, similarity search, and collection management.

    The class supports both cosine and L2 (Euclidean) distance functions for
    similarity search, allowing implementations to choose the most appropriate
    metric for their use case.

    Parameters
    ----------
    distance_function : str, optional
        The distance function to use for similarity search. Valid values are
        "cosine" for cosine similarity or "l2" for Euclidean distance.
        Default is "l2".

    Attributes
    ----------
    distance_function : str
        The configured distance function for similarity search operations.

    Raises
    ------
    ValueError
        If an invalid distance function is provided.

    Examples
    --------
    Create a custom vector database implementation:

    >>> from fbpyutils_ai.base import VectorDatabase
    >>> class CustomVectorDB(VectorDatabase):
    ...     def add_embeddings(self, ids, embeddings, metadatas):
    ...         # Store embeddings in your database
    ...         pass
    ...     def search_embeddings(self, embedding, n_results=10):
    ...         # Perform similarity search
    ...         pass
    ...     # Implement other abstract methods...
    >>> db = CustomVectorDB(distance_function="cosine")
    >>> db.distance_function
    'cosine'

    Notes
    -----
    All concrete implementations must implement the abstract methods defined
    in this class. The interface ensures consistent behavior across different
    vector database backends.

    See Also
    --------
    fbpyutils_ai.embedding.ChromaDB : ChromaDB implementation
    fbpyutils_ai.embedding.PgVectorDB : PostgreSQL+pgvector implementation
    fbpyutils_ai.embedding.PineconeDB : Pinecone implementation
    """

    def __init__(self, distance_function: str = "l2"):
        """
        Initialize the vector database with the specified distance function.

        Parameters
        ----------
        distance_function : str, optional
            The distance function to use for similarity search. Valid values are
            "cosine" for cosine similarity or "l2" for Euclidean distance.
            Default is "l2".

        Raises
        ------
        ValueError
            If an invalid distance function is provided.
        """
        logger.debug(f"VectorDatabase initialized with distance_function={distance_function}")

        distance_function = distance_function or "l2"
        original_function = distance_function

        if distance_function not in ("cosine", "l2"):
            logger.error(
                f"VectorDatabase.__init__ invalid distance function: {distance_function}"
            )
            raise ValueError(
                f"Invalid distance function {distance_function}. Valid values are: cosine|l2."
            )

        self.distance_function = distance_function
        logger.debug(f"VectorDatabase initialized: distance_function={original_function} -> {self.distance_function}")

    @abstractmethod
    def add_embeddings(
        self,
        ids: List[str],
        embeddings: List[List[float]],
        metadatas: List[Dict[str, Any]],
    ):
        """
        Add embeddings to the database.

        This method stores embeddings along with their associated identifiers
        and metadata in the vector database. The operation is typically
        implemented as an upsert (insert or update).

        Parameters
        ----------
        ids : list of str
            List of unique identifiers for the embeddings. Each ID must be
            unique within the collection.
        embeddings : list of list of float
            List of embedding vectors. Each embedding should be a list of
            floating-point numbers with consistent dimensionality.
        metadatas : list of dict
            List of metadata dictionaries associated with each embedding.
            Metadata can include any additional information like document
            titles, sources, timestamps, etc.

        Examples
        --------
        Add embeddings to the database:

        >>> db.add_embeddings(
        ...     ids=["doc1", "doc2"],
        ...     embeddings=[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]],
        ...     metadatas=[{"title": "Document 1"}, {"title": "Document 2"}]
        ... )

        Notes
        -----
        The exact behavior depends on the implementation. Some databases
        may require all embeddings to have the same dimensionality,
        while others may be more flexible.

        See Also
        --------
        search_embeddings : Search for similar embeddings
        count : Count embeddings in the collection
        """
        pass

    @abstractmethod
    def search_embeddings(
        self, embedding: List[float], n_results: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Search for similar embeddings in the database.

        This method performs similarity search using the configured distance
        function (cosine or L2) to find the most similar embeddings to the
        query vector.

        Parameters
        ----------
        embedding : list of float
            The query embedding vector to search for. Should have the same
            dimensionality as stored embeddings.
        n_results : int, optional
            Maximum number of similar embeddings to return. Default is 10.

        Returns
        -------
        list of tuple of (str, float)
            List of tuples containing (id, similarity_score) for similar embeddings.
            The similarity score depends on the distance function:
            - For "cosine": higher values indicate more similarity
            - For "l2": lower values indicate more similarity

        Examples
        --------
        Search for similar embeddings:

        >>> results = db.search_embeddings([0.1, 0.2, 0.3], n_results=5)
        >>> for doc_id, score in results:
        ...     print(f"Found similar document {doc_id} with score {score}")

        Notes
        -----
        The interpretation of similarity scores depends on the distance
        function used. Check the `distance_function` attribute to understand
        how to interpret the scores.

        See Also
        --------
        add_embeddings : Add embeddings to the database
        count : Count embeddings in the collection
        """
        pass

    @abstractmethod
    def get_version(self) -> str:
        """
        Gets the version of the database server.

        Returns:
            String containing the version information of the database server

        Example:
            >>> version = db.get_version()
            >>> print(f"Database version: {version}")
            Database version: 1.2.3
        """
        pass

    @abstractmethod
    def count(self, where: Optional[Dict[str, Any]] = None) -> int:
        """
        Counts the number of embeddings in the collection.

        Args:
            where: Optional filter criteria as a dictionary (default: None)

        Returns:
            Integer count of embeddings matching the criteria

        Example:
            >>> total_count = db.count()
            >>> print(f"Total embeddings: {total_count}")
            Total embeddings: 1000

            >>> filtered_count = db.count(where={"category": "tech"})
            >>> print(f"Tech embeddings: {filtered_count}")
            Tech embeddings: 250
        """
        pass

    @abstractmethod
    def list_collections(self) -> List[str]:
        """
        Lists all collections in the database.

        Returns:
            List of collection names as strings

        Example:
            >>> collections = db.list_collections()
            >>> print(f"Available collections: {collections}")
            Available collections: ['documents', 'images', 'videos']
        """
        pass

    @abstractmethod
    def reset_collection(self):
        """
        Reset the current collection by erasing all documents.

        Warning
        -------
        This operation is irreversible and will delete all embeddings
        and metadata from the current collection.

        Examples
        --------
        Reset the collection (use with caution):

        >>> # This will delete all data!
        >>> db.reset_collection()
        >>> print("Collection has been reset")
        Collection has been reset

        Notes
        -----
        After reset, the collection will be empty. Some implementations
        may require re-initialization or recreation of indexes.

        See Also
        --------
        count : Count embeddings to verify reset
        list_collections : List available collections
        """
        logger.warning(
            "VectorDatabase.reset_collection called - irreversible operation!"
        )
        pass


class LLMServiceModel(BaseModel):
    """
    Data model for LLM service configuration.

    This model represents the configuration for an LLM service provider, including
    API credentials, base URL, and model identification. The API key is automatically
    protected in string representations for security.

    Parameters
    ----------
    provider : str
        Name of the LLM provider (e.g., "openai", "anthropic", "local").
    api_base_url : str
        Base URL for the provider's API endpoint.
    api_key : str
        API key for authentication with the service provider.
    is_local : bool, optional
        Whether this is a local/self-hosted model. Default is False.
    model_id : str
        Specific model identifier (e.g., "gpt-4", "claude-3-sonnet", "llama2").

    Attributes
    ----------
    provider : str
        The LLM provider name.
    api_base_url : str
        The API base URL.
    api_key : str
        The API authentication key (protected in string representations).
    is_local : bool
        Whether this is a local model.
    model_id : str
        The specific model identifier.

    Examples
    --------
    Create an OpenAI model configuration:

    >>> model = LLMServiceModel(
    ...     provider="openai",
    ...     api_base_url="https://api.openai.com/v1",
    ...     api_key="sk-...",
    ...     model_id="gpt-4"
    ... )
    >>> print(model.provider)
    openai
    >>> print(model.model_id)
    gpt-4

    Create a local model configuration:

    >>> local_model = LLMServiceModel(
    ...     provider="local",
    ...     api_base_url="http://localhost:8000/v1",
    ...     api_key="",
    ...     model_id="llama2",
    ...     is_local=True
    ... )
    >>> print(local_model.is_local)
    True

    Notes
    -----
    The API key is automatically hashed in string representations for security.
    Always ensure API keys are stored securely and never logged.

    See Also
    --------
    LLMService : Abstract base class for LLM service implementations
    fbpyutils_ai.llm.utils.get_llm_model : Helper function to create model instances
    """

    provider: str
    api_base_url: str
    api_key: str
    is_local: bool = False
    model_id: str

    @staticmethod
    def get_llm_service_model(
        model_id: str, provider: Dict[str, Any]
    ) -> "LLMServiceModel":
        """
        Create an LLMServiceModel instance from provider configuration.

        This factory method creates a model instance by looking up provider
        configuration and loading API credentials from environment variables.

        Parameters
        ----------
        model_id : str
            The model identifier to use (e.g., "gpt-4", "claude-3-sonnet").
        provider : dict
            Dictionary containing provider configuration with keys:
            - provider : str
                Provider name (e.g., "openai", "anthropic")
            - base_url : str
                API base URL for the provider
            - env_api_key : str
                Environment variable name containing the API key
            - is_local : bool, optional
                Flag for local models. Default is False.

        Returns
        -------
        LLMServiceModel
            Configured LLMServiceModel instance.

        Raises
        ------
        KeyError
            If required provider configuration keys are missing.
        ValueError
            If the API key environment variable is not set.

        Examples
        --------
        Create an OpenAI model configuration:

        >>> provider_config = {
        ...     "provider": "openai",
        ...     "base_url": "https://api.openai.com/v1",
        ...     "env_api_key": "OPENAI_API_KEY"
        ... }
        >>> # Assuming OPENAI_API_KEY is set in environment
        >>> model = LLMServiceModel.get_llm_service_model("gpt-4", provider_config)
        >>> print(model.model_id)
        gpt-4
        >>> print(model.provider)
        openai

        Notes
        -----
        The API key is loaded from the specified environment variable.
        Ensure the environment variable is set before calling this method.

        See Also
        --------
        get_llm_resources : Load provider configurations from files
        """
        logger.info(
            f"LLMServiceModel.get_llm_service_model called with model_id={model_id}, provider={provider.get('provider', 'unknown')}"
        )

        model = LLMServiceModel(
            provider=provider["provider"].lower(),
            api_base_url=provider["base_url"],
            api_key=os.environ.get(provider["env_api_key"]),
            is_local=provider.get("is_local", False),
            model_id=model_id,
        )

        logger.info(
            f"LLMServiceModel.get_llm_service_model completed: created model for {model.provider}"
        )
        return model

    def __str__(self) -> str:
        """
        Return a string representation with API key hashed for security.

        Returns
        -------
        str
            String representation of the model with the API key replaced
            with "HASHED" for security purposes.

        Examples
        --------
        Display model configuration safely:

        >>> model = LLMServiceModel(
        ...     provider="anthropic",
        ...     api_base_url="https://api.anthropic.com",
        ...     api_key="sk-ant-...",
        ...     model_id="claude-3-sonnet"
        ... )
        >>> print(model)
        LLMServiceModel(provider=anthropic, api_base_url=https://api.anthropic.com, api_key=HASHED, model_id=claude-3-sonnet)

        Notes
        -----
        This method is automatically called when the object is converted
        to a string or printed. The API key is always masked for security.

        See Also
        --------
        __repr__ : Alternative string representation method
        """
        return f"LLMServiceModel(provider={self.provider}, api_base_url={self.api_base_url}, api_key=HASHED, model_id={self.model_id})"


# Interface for the LLM service
class LLMService(ABC):
    """
    Abstract base class for LLM service implementations.

    This class defines the standard interface that all LLM service implementations
    must follow. It provides a unified API for various LLM operations including
    text generation, chat completions, embeddings, tokenization, and vision tasks.

    The class supports multiple model types allowing implementations to use
    different models for different tasks (e.g., GPT-4 for chat, text-embedding-ada-002
    for embeddings, GPT-4V for vision).

    Parameters
    ----------
    base_model : LLMServiceModel
        Primary LLM model configuration for text generation and chat completions.
    embed_model : LLMServiceModel, optional
        Optional embedding model configuration. If not provided, defaults to base_model.
    vision_model : LLMServiceModel, optional
        Optional vision model configuration. If not provided, defaults to base_model.
    timeout : int, optional
        Request timeout in seconds. Default is 300 (5 minutes).
    session_retries : int, optional
        Number of retry attempts for failed requests. Default is 3.

    Attributes
    ----------
    model_map : dict
        Dictionary mapping model types to their configurations:
        - "base" : Primary model for text generation and chat
        - "embed" : Model for generating embeddings
        - "vision" : Model for image understanding tasks
    timeout : int
        Request timeout in seconds.
    retries : int
        Number of retry attempts for failed requests.

    Examples
    --------
    Create a custom LLM service implementation:

    >>> from fbpyutils_ai.base import LLMService, LLMServiceModel
    >>> class MyLLMService(LLMService):
    ...     def generate_embeddings(self, input):
    ...         # Implementation here
    ...         pass
    ...     # Implement other abstract methods...
    >>> base_model = LLMServiceModel(
    ...     provider="openai",
    ...     api_base_url="https://api.openai.com/v1",
    ...     api_key="sk-...",
    ...     model_id="gpt-4"
    ... )
    >>> service = MyLLMService(base_model, timeout=600)
    >>> service.timeout
    600
    >>> service.model_map["base"].model_id
    'gpt-4'

    Notes
    -----
    All concrete implementations must implement the abstract methods defined
    in this class. The interface ensures consistent behavior across different
    LLM providers and facilitates testing and development.

    The service automatically handles model selection based on the operation
    type. For example, generate_embeddings() uses the embed model, while
    generate_completions() uses the base model.

    See Also
    --------
    LLMServiceModel : Configuration model for LLM services
    fbpyutils_ai.llm.openai.OpenAILLMService : OpenAI implementation
    fbpyutils_ai.embedding.EmbeddingManager : High-level embedding management
    """

    def __init__(
        self,
        base_model: LLMServiceModel,
        embed_model: Optional[LLMServiceModel] = None,
        vision_model: Optional[LLMServiceModel] = None,
        timeout: int = 300,
        session_retries: int = 3,
    ):
        """
        Initialize the LLM service with model configurations.

        Parameters
        ----------
        base_model : LLMServiceModel
            Primary LLM model configuration for text generation and chat completions.
        embed_model : LLMServiceModel, optional
            Optional embedding model configuration. If not provided, defaults to base_model.
        vision_model : LLMServiceModel, optional
            Optional vision model configuration. If not provided, defaults to base_model.
        timeout : int, optional
            Request timeout in seconds. Default is 300.
        session_retries : int, optional
            Number of retry attempts for failed requests. Default is 3.
        """
        logger.debug(f"LLMService initialized with base_model={base_model.model_id}, timeout={timeout}, retries={session_retries}")

        self.model_map = {
            "base": base_model,
            "embed": embed_model or base_model,
            "vision": vision_model or base_model,
        }
        self.timeout = timeout or 300
        self.retries = session_retries or 3

        logger.debug(
            f"LLMService initialized: model_map={list(self.model_map.keys())}, timeout={self.timeout}, retries={self.retries}"
        )

    def get_base_model(self) -> LLMServiceModel:
        """
        Get the base model configuration.

        Returns
        -------
        LLMServiceModel
            The base model configuration used for text generation and chat completions.

        Examples
        --------
        Access the base model:

        >>> base_model = service.get_base_model()
        >>> print(f"Using model: {base_model.model_id}")
        Using model: gpt-4

        See Also
        --------
        get_embed_model : Get the embedding model configuration
        get_vision_model : Get the vision model configuration
        """
        return self.model_map["base"]

    def get_embed_model(self) -> LLMServiceModel:
        """
        Get the embedding model configuration.

        Returns
        -------
        LLMServiceModel
            The embedding model configuration used for generating text embeddings.

        Examples
        --------
        Access the embedding model:

        >>> embed_model = service.get_embed_model()
        >>> print(f"Embedding model: {embed_model.model_id}")
        Embedding model: text-embedding-ada-002

        See Also
        --------
        get_base_model : Get the base model configuration
        get_vision_model : Get the vision model configuration
        """
        return self.model_map["embed"]

    def get_vision_model(self) -> LLMServiceModel:
        """
        Get the vision model configuration.

        Returns
        -------
        LLMServiceModel
            The vision model configuration used for image understanding tasks.

        Examples
        --------
        Access the vision model:

        >>> vision_model = service.get_vision_model()
        >>> print(f"Vision model: {vision_model.model_id}")
        Vision model: gpt-4-vision-preview

        See Also
        --------
        get_base_model : Get the base model configuration
        get_embed_model : Get the embedding model configuration
        """
        return self.model_map["vision"]

    @abstractmethod
    def generate_embeddings(self, input: List[str]) -> Optional[List[float]]:
        """
        Generates an embedding for the given list of text.

        Args:
            input: List of text strings to generate embeddings for

        Returns:
            List of embedding vectors as floats, or None if generation fails

        Example:
            >>> texts = ["Hello world", "Machine learning"]
            >>> embeddings = service.generate_embeddings(texts)
            >>> if embeddings:
            ...     print(f"Generated {len(embeddings)} embeddings")
            ...     print(f"First embedding dimension: {len(embeddings[0])}")
            Generated 2 embeddings
            First embedding dimension: 1536
        """
        pass

    @abstractmethod
    def generate_text(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generates text from a prompt.

        Args:
            prompt: The input text prompt
            **kwargs: Additional parameters for text generation (e.g., temperature, max_tokens)

        Returns:
            Generated text response as a string

        Example:
            >>> prompt = "Write a haiku about programming"
            >>> response = service.generate_text(prompt, temperature=0.7)
            >>> print(response)
            Code flows like water
            Logic branches endlessly
            Bugs hide in the depths
        """
        pass

    @abstractmethod
    def generate_completions(
        self, messages: List[Dict[str, str]], **kwargs
    ) -> Dict[str, Any]:
        """
        Generates text from a chat completion.

        Args:
            messages: List of message dictionaries with role and content
            **kwargs: Additional parameters for completion generation

        Returns:
            Generated completion text as a string

        Example:
            >>> messages = [
            ...     {"role": "system", "content": "You are a helpful assistant"},
            ...     {"role": "user", "content": "What is the capital of France?"}
            ... ]
            >>> response = service.generate_completions(messages)
            >>> print(response)
            The capital of France is Paris.
        """
        logger.info(
            f"LLMService.generate_completions called with {len(messages)} messages"
        )
        pass

    @abstractmethod
    def generate_tokens(self, text: str, **kwargs) -> List[int]:
        """
        Generates tokens from a text.

        Args:
            text: Input text to tokenize
            **kwargs: Additional parameters for tokenization

        Returns:
            List of token IDs as integers

        Example:
            >>> text = "Hello, world!"
            >>> tokens = service.generate_tokens(text)
            >>> print(f"Text: '{text}' -> Tokens: {tokens}")
            Text: 'Hello, world!' -> Tokens: [9906, 11, 4435, 0]
        """
        pass

    @abstractmethod
    def describe_image(self, image: str, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Describes an image.

        Args:
            image: Image data (base64 encoded)
            prompt: Instructions for how to describe the image
            **kwargs: Additional parameters for image analysis

        Returns:
            Text description of the image

        Example:
            >>> image_data = "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
            >>> prompt = "Describe what you see in this image"
            >>> description = service.describe_image(image_data, prompt)
            >>> print(description)
            The image shows a serene landscape with mountains in the background...
        """
        logger.info(
            f"LLMService.describe_image called with image length={len(image)}, prompt length={len(prompt)}"
        )
        pass

    @abstractmethod
    def get_model_details(
        self, model_type: str = "base", introspection: bool = False, **kwargs
    ) -> Dict[str, Any]:
        """
        Gets the details of a model.

        Args:
            model_type: Type of model to get details for ("base", "embed", or "vision")
            introspection: Whether to perform detailed introspection of the model
            **kwargs: Additional parameters for model details retrieval

        Returns:
            Dictionary containing model details such as name, version, capabilities, etc.

        Example:
            >>> details = service.get_model_details("base", introspection=True)
            >>> print(f"Model: {details.get('name', 'Unknown')}")
            >>> print(f"Max tokens: {details.get('max_tokens', 'Unknown')}")
            Model: gpt-4
            Max tokens: 8192
        """
        logger.info(
            f"LLMService.get_model_details called with model_type={model_type}, introspection={introspection}"
        )
        pass

    @abstractmethod
    def list_models(model_type: str = "base", **kwargs) -> List[Dict[str, Any]]:
        """
        Lists the available models.

        Args:
            model_type: The model type to select which model to use: base, embed or vision. Default: base
            **kwargs: Additional parameters for model listing (e.g., provider, capabilities)

        Returns:
            List of dictionaries containing model information

        Example:
            >>> models = LLMService.list_models(provider="openai")
            >>> for model in models:
            ...     print(f"Model: {model['id']}")
            ...     print(f"Type: {model.get('type', 'unknown')}")
            Model: gpt-4
            Type: chat
        """
        pass
