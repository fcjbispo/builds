import typer
from typing import Optional
from typing_extensions import Annotated
from rich.console import Console
import os
from pathlib import Path

from ..document import DoclingConverter

console = Console()


def extractmd(
    source: Annotated[str, typer.Argument(help="Source document path")],
    ocr: Annotated[
        bool,
        typer.Option("--ocr", "-r", help="Enable OCR for scanned documents"),
    ] = True,
    force_image: Annotated[
        bool,
        typer.Option(
            "--force-image", "-f",
            help="Convert PDF to images first for better OCR"
        ),
    ] = False,
    output: Annotated[
        Optional[str],
        typer.Option(
            "--output", "-o",
            help="Path to save extracted markdown file (if not provided, prints to console)"
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Verbose mode"),
    ] = False,
) -> None:
    """Extract markdown from documents using DoclingConverter."""
    if verbose:
        console.print("[green]Starting document extraction...[/green]")

    if not os.path.exists(source):
        console.print(f"[red]Source file not found: {source}[/red]")
        raise typer.Exit(code=1)

    converter = DoclingConverter()

    try:
        content = converter.convert(
            source=source,
            output_format="md",
            ocr=ocr,
            force_image=force_image,
        )

        if output:
            output_path = Path(output)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)
            if verbose:
                console.print(f"[green]Extracted content saved to: {output}[/green]")
        else:
            console.print(content)

        if verbose:
            console.print("[green]Extraction completed successfully.[/green]")

    except Exception as e:
        console.print(f"[red]Extraction error: {str(e)}[/red]")
        raise typer.Exit(code=1)
