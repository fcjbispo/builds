import typer
from typing import Optional
from typing_extensions import Annotated
from rich.console import Console
import os
import json as json_module

from ..scrape import FireCrawlTool

console = Console()


def webscrape(
    url: Annotated[str, typer.Argument(help="URL to scrape")],
    formats: Annotated[
        str,
        typer.Option(
            "--formats", "-f",
            help="Output formats (comma-separated: markdown,html)"
        ),
    ] = "markdown",
    only_main_content: Annotated[
        bool,
        typer.Option(
            "--only-main-content", "-m",
            help="Extract only main content, exclude navigation/ads"
        ),
    ] = True,
    remove_base64_images: Annotated[
        bool,
        typer.Option(
            "--remove-base64-images", "-b",
            help="Remove base64 encoded images from output"
        ),
    ] = True,
    timeout: Annotated[
        int,
        typer.Option("--timeout", "-t", help="Request timeout in milliseconds"),
    ] = 12000,
    base_url: Annotated[
        Optional[str],
        typer.Option("--base-url", help="FireCrawl base URL (overrides config)"),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output", "-o",
            help="Output format: txt, json, markdown"
        ),
    ] = "markdown",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Verbose mode"),
    ] = False,
) -> None:
    """Scrape a webpage using FireCrawl and display the content."""
    if verbose:
        console.print("[green]Starting scrape...[/green]")

    base_url = base_url or os.getenv(
        "FBPY_FIRECRAWL_BASE_URL", "http://192.168.15.100:3005/v1"
    )

    tool = FireCrawlTool(base_url=base_url)

    try:
        formats_list = [f.strip() for f in formats.split(",")] if formats else ["markdown"]

        result = tool.scrape(
            url=url,
            formats=formats_list,
            onlyMainContent=only_main_content,
            removeBase64Images=remove_base64_images,
            timeout=timeout,
        )

        if not result.get("success", False):
            console.print("[red]Scrape failed.[/red]")
            raise typer.Exit(code=1)

        data = result["data"]
        metadata = data.get("metadata", {})

        if verbose:
            console.print(f"[green]Scrape completed for {url}[/green]")

        title = metadata.get("title", "No title")
        description = metadata.get("description", "No description")
        if description and len(description) > 200:
            description = description[:200] + "..."

        if output == "json":
            console.print(json_module.dumps(result, indent=2, ensure_ascii=False))
        else:
            markdown_content = data.get("markdown", "No content")
            if len(markdown_content) > 500:
                content_preview = markdown_content[:500] + "..."
            else:
                content_preview = markdown_content

            if output == "txt":
                formatted = f"Title: {title}\n\nDescription: {description}\n\nContent Preview:\n{content_preview}"
            else:
                formatted = f"# {title}\n\n**Description:** {description}\n\n## Content Preview\n\n{content_preview}"

            console.print(formatted)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Scrape error: {str(e)}[/red]")
        raise typer.Exit(code=1)
