import typer
from rich.console import Console
from rich import print as rprint
import os
from pathlib import Path
import json
from typing import Dict, Any

from .websearch import websearch
from .webscrape import webscrape
from .extractmd import extractmd

console = Console()

cli = typer.Typer(
    name="fbpyutils-ai",
    help="FBPyUtils AI - Command Line Interface for AI Utilities.",
    add_completion=True,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


def load_app_config() -> Dict[str, Any]:
    """Load configuration from app.json and override with environment variables."""
    config_path = Path(__file__).parent.parent / "app.json"
    if not config_path.exists():
        console.print("[yellow]Warning: app.json not found[/yellow]")
        return {}

    with open(config_path, "r") as f:
        config = json.load(f)

    env_vars = {
        "log_level": "FBPY_LOG_LEVEL",
        "semaphores": "FBPY_SEMAPHORES",
    }

    for key, env_key in env_vars.items():
        if env_key in os.environ:
            if "logging" in config and key in config["logging"]:
                config["logging"][key] = os.environ[env_key]
            elif (
                "config" in config
                and "llm" in config["config"]
                and key in config["config"]["llm"]
            ):
                config["config"]["llm"][key] = os.environ[env_key]

    return config


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        rprint("[bold blue]fbpyutils-ai[/bold blue] version [green]0.1.5[/green]")
        raise typer.Exit()


@cli.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """FBPyUtils AI - Command Line Interface for AI Utilities."""
    pass


cli.command(name="websearch")(websearch)
cli.command(name="webscrape")(webscrape)
cli.command(name="extractmd")(extractmd)


if __name__ == "__main__":
    cli()
