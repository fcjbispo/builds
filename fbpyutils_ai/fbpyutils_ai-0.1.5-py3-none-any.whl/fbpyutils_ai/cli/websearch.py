import typer
from typing import Optional
from typing_extensions import Annotated
from rich.console import Console
from rich.table import Table
import os

from ..search import SearXNGTool
from .output_utils import (
    format_results_txt,
    format_results_json,
    format_results_markdown,
)

console = Console()


def websearch(
    query: Annotated[str, typer.Argument(help="Search query string")],
    num_results: Annotated[
        int,
        typer.Option(
            "--num-results", "-n",
            min=1, max=30,
            help="Number of results (1-30)"
        ),
    ] = 10,
    categories: Annotated[
        Optional[str],
        typer.Option(
            "--categories", "-c",
            help='Categories (e.g., "general,news")'
        ),
    ] = None,
    lang: Annotated[
        str,
        typer.Option("--lang", "-l", help="Search language"),
    ] = "pt",
    safesearch: Annotated[
        int,
        typer.Option(
            "--safesearch", "-s",
            min=0, max=2,
            help="Safe search filter (0=off, 1=moderate, 2=strict)"
        ),
    ] = 0,
    base_url: Annotated[
        Optional[str],
        typer.Option("--base-url", help="SearXNG base URL (overrides config)"),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output", "-o",
            help="Output format: txt, json, markdown"
        ),
    ] = "markdown",
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Verbose mode"),
    ] = False,
) -> None:
    """Perform web search via SearXNG and display results."""
    if verbose:
        console.print("[green]Starting search...[/green]")

    base_url = base_url or os.getenv(
        "FBPY_SEARXNG_BASE_URL", "http://192.168.15.100:3003"
    )

    tool = SearXNGTool(base_url=base_url)

    try:
        cat_list = [c.strip() for c in categories.split(",")] if categories else None

        all_results = tool.search(
            query=query,
            categories=cat_list,
            language=lang,
            safesearch=safesearch,
        )
        results = all_results[:num_results] if all_results else []

        if not results:
            console.print("[yellow]No results found.[/yellow]")
            return

        if output == "json":
            formatted = format_results_json(results)
        elif output == "txt":
            formatted = format_results_txt(results, query)
        else:
            formatted = format_results_markdown(results)

        console.print(formatted)

        if verbose:
            console.print(
                f"[green]Search completed: {len(results)} results for '{query}'.[/green]"
            )

    except ValueError as ve:
        console.print(f"[red]Parameter error: {str(ve)}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Search error: {str(e)}[/red]")
        raise typer.Exit(code=1)
