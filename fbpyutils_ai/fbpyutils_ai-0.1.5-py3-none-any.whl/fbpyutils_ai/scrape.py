"""
Web scraping tools for extracting content from websites using Firecrawl API.

This module provides a FireCrawlTool class that interfaces with the Firecrawl API
for scraping web content and performing web searches. It supports both self-hosted
and cloud-based Firecrawl instances with comprehensive configuration options.

Features:
- Single URL scraping with multiple output formats
- Web search with content extraction
- Custom headers and timeout configuration
- Content filtering with CSS selectors
- Base64 image removal option
- SSL verification control

Example:
    >>> from fbpyutils_ai.scrape import FireCrawlTool
    >>>
    >>> # Initialize tool with self-hosted instance
    >>> tool = FireCrawlTool(
    ...     base_url="http://localhost:3005/v1",
    ...     token="your-api-key"
    ... )
    >>>
    >>> # Scrape a webpage
    >>> result = tool.scrape(
    ...     url="https://example.com",
    ...     formats=["markdown", "html"],
    ...     onlyMainContent=True
    ... )
    >>> print(f"Content length: {len(result['data']['markdown'])}")
    Content length: 1542
"""

import os
from typing import Any, Dict

from fbpyutils_ai import logger


from fbpyutils.http import HTTPClient


class FireCrawlTool:
    """
    Firecrawl API client for web scraping and search operations.

    This class provides an interface to the Firecrawl API for scraping web content
    and performing web searches. It supports both self-hosted instances (default)
    and cloud-based Firecrawl services.

    Args:
        base_url: Base URL of the Firecrawl API (defaults to self-hosted)
        token: Authentication token (optional for self-hosted)
        verify_ssl: Whether to verify SSL certificates (default: True)

    Example:
        >>> # Self-hosted instance
        >>> tool = FireCrawlTool()
        >>> print(f"Using base URL: {tool._base_url}")
        Using base URL: http://localhost:3005/v1

        >>> # Cloud instance with token
        >>> cloud_tool = FireCrawlTool(
        ...     base_url="https://api.firecrawl.dev/v1",
        ...     token="your-api-key"
        ... )
        >>> print("Authorization" in cloud_tool._headers)
        True
    """

    def __init__(
        self, base_url: str = None, token: str = None, verify_ssl: bool = True
    ):
        """
        Initializes the FireCrawlTool with base URL, token, and SSL verification setting.

        Args:
            base_url: The base URL of the Firecrawl API. Defaults to self-hosted URL.
            token: The authentication token. Optional for self-hosted.
            verify_ssl: Whether to verify SSL certificates. Defaults to True.

        Example:
            >>> # Using environment variables
            >>> import os
            >>> os.environ['FBPY_FIRECRAWL_BASE_URL'] = 'http://localhost:3005/v1'
            >>> os.environ['FBPY_FIRECRAWL_API_KEY'] = 'your-key'
            >>> tool = FireCrawlTool()
            >>> print(f"Base URL: {tool._base_url}")
            Base URL: http://localhost:3005/v1

            >>> # Direct parameters
            >>> tool = FireCrawlTool(
            ...     base_url="https://custom.firecrawl.com/v1",
            ...     token="custom-token",
            ...     verify_ssl=False
            ... )
            >>> print(f"SSL verification: {tool.http_client.verify_ssl}")
            SSL verification: False
        """
        self._base_url = base_url or os.environ.get(
            "FBPY_FIRECRAWL_BASE_URL",
            "http://localhost:3005/v1",  # Default to self-hosted v1
        )
        self._headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36",
            "Content-Type": "application/json",
        }
        token = token or os.environ.get("FBPY_FIRECRAWL_API_KEY")
        if token is not None and token != "":
            self._headers["Authorization"] = f"Bearer {token}"

        self.http_client = HTTPClient(
            base_url=self._base_url, headers=self._headers, verify_ssl=verify_ssl
        )
        logger.info("Initialized FireCrawlTool with base URL %s", self._base_url)

    def scrape(
        self,
        url: str,
        formats: list[str] = ["markdown"],
        onlyMainContent: bool = False,
        includeTags: list[str] | None = None,
        excludeTags: list[str] | None = None,
        headers: dict | None = None,
        waitFor: int = 0,
        timeout: int = 30000,
        removeBase64Images: bool = False,
    ) -> Dict[str, Any]:
        """
        Scrapes a single URL using the Firecrawl v1 API (Self-Hosted compatible).

        This method extracts content from a webpage with support for multiple output formats,
        content filtering, and custom request configuration. It's optimized for self-hosted
        Firecrawl instances without fire-engine.

        Args:
            url: The URL to scrape (required)
            formats: List of output formats (e.g., ["markdown", "html"]). Default: ["markdown"]
            onlyMainContent: Return only main content, exclude navigation/ads. Default: False
            includeTags: CSS selectors to include (e.g., ["article", ".content"]). Default: None
            excludeTags: CSS selectors to exclude (e.g., ["nav", ".ads"]). Default: None
            headers: Custom HTTP headers for the scraping request. Default: None
            waitFor: Wait time in milliseconds for dynamic content. Default: 0
            timeout: Request timeout in milliseconds. Default: 30000
            removeBase64Images: Remove base64 encoded images from output. Default: False

        Returns:
            Dictionary containing scrape results with success status and data

        Raises:
            httpx.HTTPStatusError: If the API returns 4xx or 5xx status code
            httpx.RequestError: If network or other request error occurs

        Example:
            >>> # Basic scrape
            >>> result = tool.scrape("https://example.com")
            >>> print(f"Success: {result['success']}")
            Success: True
            >>> print(f"Markdown length: {len(result['data']['markdown'])}")
            Markdown length: 1247

            >>> # Advanced scrape with filtering
            >>> result = tool.scrape(
            ...     url="https://news.site.com/article",
            ...     formats=["markdown", "html"],
            ...     onlyMainContent=True,
            ...     includeTags=["article", "main"],
            ...     excludeTags=["nav", "footer", ".advertisement"],
            ...     waitFor=2000,
            ...     timeout=45000
            ... )
            >>> if result['success']:
            ...     print(f"Title: {result['data']['metadata'].get('title', 'No title')}")
            ...     print(f"Word count: {len(result['data']['markdown'].split())}")
            Title: Breaking News Story
            Word count: 342
        """
        payload = {
            "url": url,
            "formats": formats,
            "onlyMainContent": onlyMainContent,
            "includeTags": includeTags,
            "excludeTags": excludeTags,
            "headers": headers,
            "waitFor": waitFor,
            "timeout": timeout,
            "removeBase64Images": removeBase64Images,
        }

        # Remove None values from payload
        payload = {k: v for k, v in payload.items() if v is not None}

        logger.info("Sending v1 scrape request with payload: %s", payload)
        # Use HTTPClient to make the request
        response = self.http_client.sync_request("POST", "scrape", json=payload)
        response_data = response.json()
        logger.info("Scrape successful for URL %s", url)
        return response_data

    def search(
        self,
        query: str,
        limit: int = 5,
        tbs: str | None = None,
        lang: str = "en",
        country: str = "us",
        timeout: int = 60000,
        **kwargs: Any,  # Accept arbitrary keyword arguments
    ) -> Dict[str, Any]:
        """
        Searches for a keyword using the Firecrawl API with optional content extraction.

        Performs a web search and optionally scrapes content from the search results.
        Supports time-based filtering, language/region targeting, and custom scraping options.

        Args:
            query: The search query (required)
            limit: Maximum number of results to return (default: 5)
            tbs: Time-based search parameter (e.g., "qdr:h" for past hour). Default: None
            lang: Language code for search results (default: "en")
            country: Country code for search results (default: "us")
            timeout: Timeout in milliseconds (default: 60000)
            **kwargs: Additional parameters including scrapeOptions for content extraction

        Returns:
            Dictionary containing search results with success status and data array

        Raises:
            httpx.HTTPStatusError: If the API returns 4xx or 5xx status code
            httpx.RequestError: If network or other request error occurs

        Example:
            >>> # Basic search
            >>> results = tool.search("python programming tutorials")
            >>> print(f"Found {len(results['data'])} results")
            Found 5 results
            >>> for result in results['data']:
            ...     print(f"- {result['title']}: {result['url']}")
            - Python Programming Tutorial: https://example.com/python-tutorial
            - Learn Python Programming: https://example.com/learn-python

            >>> # Search with content extraction
            >>> results = tool.search(
            ...     query="artificial intelligence news",
            ...     limit=3,
            ...     lang="en",
            ...     country="us",
            ...     formats=["markdown"],
            ...     onlyMainContent=True,
            ...     scrapeOptions={
            ...         "waitFor": 1000,
            ...         "timeout": 30000
            ...     }
            ... )
            >>> for i, result in enumerate(results['data']):
            ...     print(f"{i+1}. {result['title']}")
            ...     print(f"   Content preview: {result['markdown'][:100]}...")
            1. Latest AI Breakthrough Announced
               Content preview: Researchers at TechCorp have announced a major breakthrough in artificial intelligence...
        """
        # Construct the base payload with known parameters
        payload: Dict[str, Any] = {
            "query": query,
            "limit": limit,
            "tbs": tbs,
            "lang": lang,
            "country": country,
            "timeout": timeout,
        }

        # Extract scrapeOptions from kwargs if provided
        scrape_options = kwargs.pop("scrapeOptions", {})

        # Add scrapeOptions to the payload if it's not empty
        if scrape_options:
            payload["scrapeOptions"] = scrape_options

        # Add any remaining kwargs directly to the payload
        payload.update(kwargs)

        # Remove None values from payload, including nested dictionaries
        payload = {k: v for k, v in payload.items() if v is not None}
        if "searchOptions" in payload and isinstance(payload["searchOptions"], dict):
            payload["searchOptions"] = {
                k: v for k, v in payload["searchOptions"].items() if v is not None
            }
        if "scrapeOptions" in payload and isinstance(payload["scrapeOptions"], dict):
            payload["scrapeOptions"] = {
                k: v for k, v in payload["scrapeOptions"].items() if v is not None
            }

        logger.info("Sending v1 search request with payload: %s", payload)
        # Use HTTPClient to make the request
        response = self.http_client.sync_request("POST", "search", json=payload)
        response_data = response.json()
        logger.info("Search successful for query: %s", query)
        return response_data
