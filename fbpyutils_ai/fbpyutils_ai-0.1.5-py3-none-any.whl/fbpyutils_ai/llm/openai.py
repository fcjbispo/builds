"""
OpenAI-compatible LLM service implementation.

This module provides OpenAILLMService, a concrete implementation of the LLMService
abstract base class using the official OpenAI Python client library. It supports text generation,
chat completions, embeddings, tokenization, image description, and model management for OpenAI APIs.

The service handles OpenAI-specific endpoints and authentication, with support for base64-encoded
images and document attachments in vision and completion methods where applicable.

Dependencies:
- openai: Official OpenAI client library
- tiktoken: For tokenization (OpenAI-compatible)

Example:
    >>> from fbpyutils_ai.tools import LLMServiceModel
    >>> from .openaicompatible import OpenAILLMService
    >>>
    >>> model = LLMServiceModel(
    ...     provider="openai",
    ...     api_base_url="https://api.openai.com/v1",
    ...     api_key="sk-...",
    ...     model_id="gpt-4o"
    ... )
    >>> service = OpenAILLMService(model)
    >>> response = service.generate_completions([{"role": "user", "content": "Hello!"}])
    >>> print(response)
"""

from typing import Any, Dict, List, Optional

from openai import OpenAI
from tiktoken import get_encoding

from fbpyutils_ai import logger
from fbpyutils_ai.base import LLMService, LLMServiceModel
from fbpyutils_ai.llm.utils import get_llm_introspection, get_llm_resources


_, _, LLM_INTROSPECTION_PROMPT, LLM_INTROSPECTION_VALIDATION_SCHEMA = (
    get_llm_resources()
)


class OpenAILLMService(LLMService):
    """
    Concrete implementation of LLMService using the OpenAI Python client.

    This class integrates with the OpenAI API for text generation, embeddings, chat completions,
    tokenization, and vision tasks. It supports OpenAI-compatible configurations via the
    LLMServiceModel, including custom base URLs for proxies or local servers.

    Supports:
    - Text and chat completions (GPT models)
    - Embeddings (text-embedding models)
    - Vision (GPT-4V or similar for image description)
    - Tokenization via tiktoken
    - Model listing and details retrieval

    For image and document support:
    - Images: Accepted as URLs or base64-encoded data (data:image/...;base64,...)
    - Documents: Text content can be included in prompts; for vision, images only (no direct doc support)

    Args:
        base_model: Primary LLM model configuration (required)
        embed_model: Optional embedding model configuration (defaults to base_model)
        vision_model: Optional vision model configuration (defaults to base_model)
        timeout: Request timeout in seconds (default: 300)
        session_retries: Number of retry attempts (default: 3)

    Raises:
        ValueError: If model configuration is invalid
        openai.APIError: If OpenAI API calls fail

    Example:
        >>> from fbpyutils_ai.tools import LLMServiceModel
        >>> model = LLMServiceModel(
        ...     provider="openai",
        ...     api_base_url="https://api.openai.com/v1",
        ...     api_key="sk-...",
        ...     model_id="gpt-4o-mini"
        ... )
        >>> service = OpenAILLMService(model, timeout=120)
        >>> # Generate completion
        >>> messages = [{"role": "user", "content": "Explain quantum computing."}]
        >>> response = service.generate_completions(messages, max_tokens=100)
        >>> print(response)
        Quantum computing uses qubits...
        >>> # Describe image
        >>> image_b64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD..."
        >>> description = service.describe_image(image_b64, "Describe this photo.")
        >>> print(description)
        The image shows a cat sitting on a windowsill...
    """

    def __init__(
        self,
        base_model: LLMServiceModel,
        embed_model: Optional[LLMServiceModel] = None,
        vision_model: Optional[LLMServiceModel] = None,
        timeout: int = 300,
        retries: int = 3,
    ):
        super().__init__(base_model, embed_model, vision_model, timeout, retries)

    def _client(self, model: LLMServiceModel):
        try:
            logger.info("Return new OpenAICompatible client.")
            return OpenAI(
                api_key=model.api_key,
                base_url=model.api_base_url,
                timeout=self.timeout,
                max_retries=self.retries,
            )
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            raise ValueError(f"Invalid OpenAI configuration: {e}")

    def generate_embeddings(self, input: List[str]) -> Optional[List[List[float]]]:
        """
        Generates embeddings for the given list of text inputs using the embed model.

        Args:
            input: List of text strings to embed

        Returns:
            List of embedding vectors (each a list of floats), or None if failed

        Raises:
            openai.APIError: If embedding generation fails

        Example:
            >>> texts = ["Hello world", "AI is great"]
            >>> embeddings = service.generate_embeddings(texts)
            >>> print(f"Generated {len(embeddings)} embeddings")
            Generated 2 embeddings
            >>> print(f"First embedding length: {len(embeddings[0])}")
            First embedding length: 1536
        """
        if not input:
            logger.warning("Empty input for embeddings")
            return None

        try:
            model = self.model_map["embed"]
            client = self._client(model)
            response = client.embeddings.create(
                model=model.model_id,
                input=input,
            )
            embeddings = [data.embedding for data in response.data]
            logger.debug(
                f"Generated embeddings for {len(input)} texts using {model.model_id}"
            )
            return embeddings
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            return None

    def generate_text(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generates text completion from a prompt using the completions endpoint (legacy).

        Args:
            prompt: The input text prompt
            **kwargs: Additional parameters (e.g., max_tokens=100, temperature=0.7)

        Returns:
            Generated text as string

        Example:
            >>> response = service.generate_text("Write a poem about code.", max_tokens=50)
            >>> print(response)
            In lines of logic, we weave our dreams...
        """
        try:
            model = self.model_map["base"]
            client = self._client(model)
            response = client.completions.create(
                model=model.model_id,
                prompt=prompt,
                **kwargs,
            )
            text = response.choices[0].text.strip()
            logger.debug(f"Generated text completion: {text[:50]}...")
            return response
        except Exception as e:
            logger.error(f"Text generation failed: {e}")
            raise ValueError(f"Text generation error: {e}")

    def generate_completions(
        self, messages: List[Dict[str, str]], **kwargs
    ) -> Dict[str, Any]:
        """
        Generates chat completion from a list of messages.

        Supports document attachment by including text in user messages.
        For images/documents in vision models, use describe_image instead.

        Args:
            messages: List of dicts with 'role' (system/user/assistant) and 'content' (str or list for multimodal)
            **kwargs: Additional parameters (e.g., max_tokens=100, temperature=0.7)

        Returns:
            Generated completion text as string

        Example:
            >>> messages = [
            ...     {"role": "system", "content": "You are a helpful assistant."},
            ...     {"role": "user", "content": "Summarize this document: [document text]"}
            ... ]
            >>> response = service.generate_completions(messages)
            >>> print(response)
            The document discusses...
        """
        try:
            model = self.model_map["base"]
            client = self._client(model)
            response = client.chat.completions.create(
                model=model.model_id,
                messages=messages,
                **kwargs,
            )
            text = response.choices[0].message.content.strip()
            logger.debug(f"Generated chat completion: {text[:50]}...")
            return response
        except Exception as e:
            logger.error(f"Chat completion failed: {e}")
            raise ValueError(f"Chat completion error: {e}")

    def generate_tokens(self, text: str, **kwargs) -> List[int]:
        """
        Tokenizes text using tiktoken (OpenAI-compatible encoding).

        Args:
            text: Input text to tokenize
            **kwargs: Additional parameters (e.g., model="gpt-4" for encoding)

        Returns:
            List of token IDs as integers

        Example:
            >>> tokens = service.generate_tokens("Hello, world!")
            >>> print(tokens)
            [9906, 11, 304, 0]
        """
        try:
            model_name = kwargs.get("model", "cl100k_base")
            encoding = get_encoding(
                model_name.replace("-", "_")
            )  # tiktoken uses underscores
            tokens = encoding.encode(text)
            logger.debug(f"Tokenized '{text}' into {len(tokens)} tokens")
            return tokens
        except Exception as e:
            logger.error(f"Tokenization failed: {e}")
            raise ValueError(f"Tokenization error: {e}")

    def describe_image(
        self, image: str, prompt: str = None, **kwargs
    ) -> Dict[str, Any]:
        """
        Describes an image using a vision model.

        Supports images as base64-encoded data (data:image/...;base64,...).
        Documents: If image is a document screenshot/PDF page, describe accordingly.

        Args:
            image: Image base64 data
            prompt: Instructions for description
            **kwargs: Additional parameters (e.g., max_tokens=200)

        Returns:
            Text description of the image

        Example:
            >>> image_url = "https://example.com/image.jpg"
            >>> description = service.describe_image(image_url, "What is in this image?")
            >>> print(description)
            The image depicts a landscape with mountains...
        """
        try:
            if not image.startswith("data:image/"):
                raise ValueError("Invalid image source.")
            prompt = prompt or "Describe the content of the given image."
            content = [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": image}},
            ]
            model = self.model_map["vision"]
            client = self._client(model)
            messages = [{"role": "user", "content": content}]
            response = client.chat.completions.create(
                model=model.model_id,
                messages=messages,
                **kwargs,
            )
            description = response.choices[0].message.content.strip()
            logger.debug(f"Generated image description: {description[:50]}...")
            return response
        except Exception as e:
            logger.error(f"Image description failed: {e}")
            raise ValueError(f"Image description error: {e}")

    def get_model_details(
        self, model_type: str = "base", introspection: bool = False, **kwargs
    ) -> Dict[str, Any]:
        """
        Retrieves details for a specific model type.

        Args:
            model_type: "base", "embed", or "vision"
            introspection: If True, perform additional API introspection
            **kwargs: Additional parameters

        Returns:
            Dict with model details (id, capabilities, etc.)

        Example:
            >>> details = service.get_model_details("base")
            >>> print(details.get("id"))
            gpt-4o-mini
        """
        try:
            model = self.model_map[model_type]
            client = self._client(model)
            response = client.models.retrieve(model.model_id)
            details = {
                "id": response.id,
                "owned_by": response.owned_by,
                "capabilities": getattr(response, "capabilities", {}),
            }
            if introspection:
                retries = kwargs.get("retries", 3)
                timeout = kwargs.get("timeout", 360)
                details["introspection"] = get_llm_introspection(
                    llm_service=OpenAILLMService,
                    model=self.model_map[model_type],
                    introspection_prompt=LLM_INTROSPECTION_PROMPT,
                    validation_schema=LLM_INTROSPECTION_VALIDATION_SCHEMA,
                    retries=retries,
                    timeout=timeout,
                )
            logger.debug(f"Retrieved details for {model_type} model: {model.model_id}")
            return details
        except Exception as e:
            logger.error(f"Model details retrieval failed: {e}")
            return {"error": str(e)}
        pass

    def list_models(self, model_type: str = "base", **kwargs) -> List[Dict[str, Any]]:
        """
        Lists available models from OpenAI API.

        Args:
            model_type: The model type to select which model to use: base, embed or vision. Default: base
            **kwargs: Filters (e.g., owned_by="openai")

        Returns:
            List of model dicts

        Example:
            >>> models = OpenAILLMService.list_models()
            >>> print([m["id"] for m in models[:3]])
            ['gpt-4o', 'gpt-4o-mini', 'text-embedding-3-small']
        """
        model_type = model_type or "base"
        try:
            model = self.model_map[model_type]
            client = self._client(model)
            response = client.models.list(**kwargs)
            # models = [{"id": model.id, "owned_by": model.owned_by} for model in response.data]
            models = [model for model in response.data]
            logger.info(f"Listed {len(models)} OpenAI models")
            return models
        except Exception as e:
            logger.error(f"Model listing failed: {e}")
            return [{"error": str(e)}]
