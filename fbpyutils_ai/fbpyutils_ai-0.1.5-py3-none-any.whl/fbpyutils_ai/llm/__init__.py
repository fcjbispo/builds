"""
LLM service implementations for various providers (OpenAI, Anthropic, etc.).

This module provides concrete implementations of the LLMService abstract base class
for different LLM providers. It includes support for text generation, chat completions,
embeddings, image description, and model introspection capabilities.

Features:
- Multi-provider support (OpenAI, Anthropic, OpenRouter)
- Thread-safe request handling with semaphores
- Automatic retry logic with exponential backoff
- Streaming response support
- Model introspection and validation
- Token counting with tiktoken
- Image description capabilities

Example:
    >>> from fbpyutils_ai.llm import OpenAICustomLLMService
    >>> from fbpyutils_ai.tools import LLMServiceModel
    >>>
    >>> # Initialize service
    >>> model = LLMServiceModel(
    ...     provider="openai",
    ...     api_base_url="https://api.openai.com/v1",
    ...     api_key="your-api-key",
    ...     model_id="gpt-4"
    ... )
    >>> service = OpenAICustomLLMService(base_model=model)
    >>>
    >>> # Generate text
    >>> response = service.generate_text("What is machine learning?")
    >>> print(response[:100])
    Machine learning is a subset of artificial intelligence that focuses on...
"""

from fbpyutils_ai.llm.utils import get_llm_resources
from .openai import OpenAILLMService

(
    LLM_PROVIDERS,
    LLM_COMMON_PARAMS,
    LLM_INTROSPECTION_PROMPT,
    LLM_INTROSPECTION_VALIDATION_SCHEMA,
) = get_llm_resources()

__all__ = [
    "LLM_PROVIDERS",
    "LLM_COMMON_PARAMS",
    "LLM_INTROSPECTION_PROMPT",
    "LLM_INTROSPECTION_VALIDATION_SCHEMA",
    "OpenAICustomLLMService",
    "OpenAILLMService",
]
