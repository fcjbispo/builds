"""
Utility functions for LLM service operations and resource management.

This module provides helper functions for LLM services including API responses,
model configuration, resource loading, and data sanitization according to JSON schemas.

Features:
- API response handling with provider-specific headers
- LLM model configuration from provider definitions
- Resource loading from configuration files
- Model details sanitization according to JSON schemas
- Markdown table parsing for provider configurations

Example:
@TODO
"""

import os
import json
import requests
from jsonschema import ValidationError, validate

from typing import Any, Dict, List, Tuple
from fbpyutils_ai import logger, _ROOT_DIR
from fbpyutils_ai.base import LLMServiceModel, LLMService
from fbpyutils.file import get_base64_data_from, mime_type


def base64_image_data(image_path: str) -> str:
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Coul'd find the file {image_path}.")

    mime = mime_type(image_path)
    base64_image = get_base64_data_from(image_path)

    return f"data:{mime};base64,{base64_image}"


def get_llm_model(
    provider_id: str, model_id: str, llm_providers: list[dict]
) -> LLMServiceModel:
    """
    Creates an LLMServiceModel instance from provider configuration.

    Looks up provider configuration and creates a model instance with
    appropriate API base URL and authentication settings.

    Args:
        provider_id: Identifier of the LLM provider (e.g., 'openai', 'anthropic')
        model_id: Specific model identifier (e.g., 'gpt-4', 'claude-3-sonnet')
        llm_providers: List of provider configuration dictionaries

    Returns:
        LLMServiceModel instance configured for the specified provider and model

    Example:
        >>> providers = [
        ...     {
        ...         "provider": "openai",
        ...         "api_base_url": "https://api.openai.com/v1",
        ...         "env_api_key": "OPENAI_API_KEY"
        ...     }
        ... ]
        >>> model = get_llm_model("openai", "gpt-4", providers)
        >>> print(f"Model: {model.provider}/{model.model_id}")
        Model: openai/gpt-4
        >>> print(f"Base URL: {model.api_base_url}")
        Base URL: https://api.openai.com/v1
    """
    llm_provider = [p for p in llm_providers if p["provider"] == provider_id]
    if llm_provider:
        llm_model = LLMServiceModel(
            provider=provider_id,
            api_base_url=os.environ.get(
                f"{provider_id.upper()}_API_BASE_URL", llm_provider[0]["api_base_url"]
            ),
            api_key=os.environ.get(llm_provider[0]["env_api_key"]),
            model_id=model_id,
        )
        return llm_model


def get_llm_resources():
    """
    Loads LLM service configuration resources from files.

    Reads and parses configuration files for LLM providers, common parameters,
    introspection prompts, and validation schemas.

    Returns:
        Tuple containing:
        - llm_providers: Dictionary of provider configurations
        - llm_common_params: List of common API parameters
        - llm_introspection_prompt: Prompt template for model introspection
        - llm_introspection_validation_schema: JSON schema for validation

    Example:
        >>> providers, params, prompt, schema = get_llm_resources()
        >>> print(f"Loaded {len(providers)} providers")
        Loaded 5 providers
        >>> print(f"Common parameters: {params}")
        Common parameters: ['temperature', 'max_tokens', 'top_p', 'stream', ...]
        >>> print(f"Prompt length: {len(prompt)} characters")
        Prompt length: 1247 characters
        >>> print(f"Schema properties: {len(schema.get('properties', {}))}")
        Schema properties: 15
    """

    def _strip(x: str) -> str:
        """
        Removes extra whitespace from strings.

        Args:
            x: Input string

        Returns:
            String with extra spaces removed

        Example:
            >>> _strip("  hello    world  ")
            'hello world'
        """
        while "  " in x:
            x = x.replace("  ", "")
        return x.strip()

    prompt_path = os.path.join(
        _ROOT_DIR, "llm", "resources", "llm_introspection_prompt.md"
    )
    schema_path = os.path.join(
        _ROOT_DIR,
        "llm",
        "resources",
        "llm_introspection_validation_schema.json",
    )
    endpoints_path = os.path.join(
        _ROOT_DIR,
        "llm",
        "resources",
        "llm_providers.md",
    )

    with open(prompt_path, "r", encoding="utf-8") as f:
        llm_introspection_prompt = f.read()
    with open(schema_path, "r", encoding="utf-8") as f:
        llm_introspection_validation_schema = json.load(f)
    with open(endpoints_path, "r", encoding="utf-8") as f:
        llm_endpoints_raw = f.read()

    lines = llm_endpoints_raw.strip().split("\n")

    # Find header and separator lines
    header_line = None
    separator_line = None
    data_lines = []

    for i, line in enumerate(lines):
        stripped_line = line.strip()
        if stripped_line.startswith("|") and stripped_line.endswith("|"):
            if separator_line is None and all(
                c in ("-", "|", ":", " ") for c in stripped_line
            ):
                separator_line = stripped_line
            elif header_line is None:
                header_line = stripped_line
            elif separator_line is not None:
                data_lines.append(stripped_line)

    if not header_line or not separator_line:
        logger.error("Could not parse markdown table headers or separator.")
        return {}, [], "", {}  # Return empty or default values if parsing fails

    # Extract and clean headers
    headers = [
        h.strip().lower().replace(" ", "_") for h in header_line.strip("|").split("|")
    ]

    # Extract and clean data rows
    data_rows = []
    for data_line in data_lines:
        # Split by |, strip whitespace, and remove empty strings from leading/trailing pipes
        row_data = [d.strip() for d in data_line.strip("|").split("|")]
        if len(row_data) == len(headers):
            data_rows.append(row_data)
        else:
            logger.warning(f"Skipping malformed row in llm_providers.md: {data_line}")

    # Create list of dictionaries
    providers_list = [dict(zip(headers, row)) for row in data_rows]

    # Filter for selected providers and create the dictionary
    llm_providers = {
        p["provider"]: p
        for p in providers_list
        if p.get("selected", "").lower() == "true"
    }

    llm_common_params = [
        "temperature",
        "max_tokens",
        "top_p",
        "stream",
        "stream_options",
        "tool_choice",
    ]

    return (
        llm_providers,
        llm_common_params,
        llm_introspection_prompt,
        llm_introspection_validation_schema,
    )


def sanitize_model_details(
    model_details: Dict[str, Any],
    schema: Dict[str, Any],
    parent_key: str = "",  # Used for tracking nested changes
) -> Tuple[Dict[str, Any], Dict[str, List[str]]]:
    """
    Sanitizes model details dictionary according to JSON schema specification.

    Normalizes the input dictionary by:
    - Adding missing required properties with None values
    - Removing properties not defined in the schema
    - Recursively processing nested objects and arrays
    - Tracking all changes made during sanitization

    Args:
        model_details: Dictionary containing model information to sanitize
        schema: JSON schema dictionary defining expected structure
        parent_key: Internal parameter for tracking nested key paths

    Returns:
        Tuple containing:
        - Sanitized dictionary conforming to schema
        - Changes dictionary with 'added' and 'removed' key lists

    Example:
        >>> # Example schema and data
        >>> schema = {
        ...     "type": "object",
        ...     "properties": {
        ...         "name": {"type": "string"},
        ...         "version": {"type": "string"},
        ...         "capabilities": {"type": "object"}
        ...     },
        ...     "required": ["name", "version"]
        ... }
        >>>
        >>> # Data with extra and missing fields
        >>> data = {
        ...     "name": "GPT-4",
        ...     "extra_field": "will be removed",
        ...     "capabilities": {"text": True}
        ... }
        >>>
        >>> sanitized, changes = sanitize_model_details(data, schema)
        >>> print(f"Sanitized: {sanitized}")
        Sanitized: {'name': 'GPT-4', 'version': None, 'capabilities': {'text': True}}
        >>> print(f"Changes: {changes}")
        Changes: {'added': ['version'], 'removed': ['extra_field']}
    """
    sanitized_details = {}
    changes = {"added": [], "removed": []}
    schema_properties = schema.get("properties", {})
    required_properties = schema.get("required", [])
    original_keys = set(model_details.keys())
    schema_keys = set(schema_properties.keys())

    current_prefix = f"{parent_key}." if parent_key else ""

    # Add required properties with None if missing
    for prop_name in required_properties:
        if prop_name not in model_details and prop_name in schema_properties:
            sanitized_details[prop_name] = None
            changes["added"].append(f"{current_prefix}{prop_name}")

    # Process existing properties
    for prop_name, prop_value in model_details.items():
        if prop_name in schema_properties:
            prop_schema = schema_properties[prop_name]
            prop_type = prop_schema.get("type")

            if (
                prop_type == "object"
                and "properties" in prop_schema
                and isinstance(prop_value, dict)
            ):
                # Recursively sanitize nested objects
                nested_sanitized, nested_changes = sanitize_model_details(
                    prop_value,
                    prop_schema,
                    parent_key=f"{current_prefix}{prop_name}".strip(
                        "."
                    ),  # Pass down the nested key path
                )
                sanitized_details[prop_name] = nested_sanitized
                changes["added"].extend(nested_changes["added"])
                changes["removed"].extend(nested_changes["removed"])
            elif (
                prop_type == "array"
                and "items" in prop_schema
                and isinstance(prop_value, list)
            ):
                # Handle arrays of objects if needed
                item_schema = prop_schema.get("items", {})
                if item_schema.get("type") == "object" and "properties" in item_schema:
                    sanitized_array = []
                    for index, item in enumerate(prop_value):
                        if isinstance(item, dict):
                            nested_item_key = f"{current_prefix}{prop_name}[{index}]"
                            nested_sanitized_item, nested_item_changes = (
                                sanitize_model_details(
                                    item, item_schema, parent_key=nested_item_key
                                )
                            )
                            sanitized_array.append(nested_sanitized_item)
                            changes["added"].extend(nested_item_changes["added"])
                            changes["removed"].extend(nested_item_changes["removed"])
                        else:
                            sanitized_array.append(item)  # Keep non-dict items as is
                    sanitized_details[prop_name] = sanitized_array
                else:
                    sanitized_details[prop_name] = (
                        prop_value  # Keep array as is if items are not objects or schema is simple
                    )
            else:
                # Copy other valid properties
                sanitized_details[prop_name] = prop_value
        # else: property not in schema, will be marked as removed later

    # Ensure required properties added earlier are not overwritten if they existed in model_details
    # This logic is implicitly handled by processing existing properties first.
    # If a required prop was missing, it's added. If present, it's processed (and kept).

    # Identify removed keys
    # Keys removed are those in the original dict but not in the schema's properties
    removed_keys_current_level = original_keys - schema_keys
    for removed_key in removed_keys_current_level:
        changes["removed"].append(f"{current_prefix}{removed_key}")

    return sanitized_details, changes


def get_llm_introspection(
    llm_service: LLMService,
    model: LLMServiceModel,
    introspection_prompt: str,
    validation_schema: dict,
    retries: int = 3,
    timeout: int = 360,
) -> Dict[str, Any]:
    response_data = {}
    try:

        def _parse_response(
            response, introspection_report: Dict[str, Any]
        ) -> Tuple[Dict[str, Any], str | None, Dict[str, Any]]:
            if isinstance(response, requests.Response):
                contents = (
                    response.get("choices", [{}])[0].get("message", {}).get("content")
                )
            elif isinstance(response, dict):
                contents = json.dumps(response, ensure_ascii=False, default=str)
            else:
                contents = str(response)

            parse_error = None
            model_details = {}
            if contents:
                try:
                    model_details = json.loads(
                        contents.replace("```json", "").replace("```", "")
                    )
                    validate(
                        instance=model_details,
                        schema=validation_schema,
                    )
                    introspection_report["generation_ok"] = True
                except ValidationError as e:
                    parse_error = f"JSON Validation error: {e}. JSON: {model_details}"
                except json.JSONDecodeError as e:
                    parse_error = f"Error decoding JSON: {e}. JSON: {model_details}"
                if parse_error is not None:
                    logger.info(parse_error)
                    introspection_report["decode_error"] = True
            else:
                parse_error = "No content found in the response."
                logger.warning(parse_error)

            return introspection_report, parse_error, model_details

        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": "llm_introspection_validation_schema",
                "strict": True,
                "schema": validation_schema,
                "required": ["llm_introspection_validation_schema"],
            },
        }

        llm = llm_service(model)
        llm_model_details = {}
        introspection_report = {
            "attempts": 1,
            "generation_ok": False,
            "decode_error": False,
            "validation_error": False,
            "sanitized": False,
            "sanitize_changes": {},
        }

        messages = [
            {"role": "system", "content": introspection_prompt},
            {
                "role": "user",
                "content": "Please list me ALL the details about this model.",
            },
        ]

        while (introspection_report["attempts"] <= retries) and (
            not introspection_report["generation_ok"]
        ):
            attempt_no = introspection_report["attempts"]
            logger.info(
                f"Performing model introspection for: {model.model_id}. Attempt #{attempt_no + 1}."
            )

            try:
                response = llm.generate_completions(
                    messages=messages,
                    stream=False,
                    timeout=timeout,
                    top_p=1,
                    temperature=0.0,
                    response_format=response_format,
                )
                (introspection_report, parse_error, llm_model_details) = (
                    _parse_response(response, introspection_report)
                )
            except Exception as e:
                parse_error = f"An error occurred while fetching model details from the LLM: {e.message}."
                response = (
                    f"Attempt #{attempt_no + 1} failed with error: {parse_error}."
                )
                logger.info(parse_error)

            if parse_error is not None:
                introspection_report["attempts"] += 1
                for m in [
                    {
                        "role": "assistant",
                        "content": response,
                    },
                    {
                        "role": "user",
                        "content": f"This is the attempt {attempt_no + 1}/{retries}. The expected JSON format was not returned. Please try again and ensure the output is a valid JSON object an defined on the provided schema. The error was: {parse_error}",
                    },
                ]:
                    messages.append(m)

        if not introspection_report["generation_ok"]:
            sanitized_details, sanitize_changes = sanitize_model_details(
                llm_model_details, validation_schema
            )
            llm_model_details = sanitized_details  # Update with sanitized version
            introspection_report["sanitized"] = True
            introspection_report["sanitize_changes"] = sanitize_changes  # Store changes
            logger.info(f"Sanitization applied. Changes: {sanitize_changes}")

        response_data["introspection"] = llm_model_details
        response_data["introspection"]["report"] = introspection_report

        return response_data
    except Exception as e:
        logger.error(
            f"Failed to retrieve model introspection: {e}. Response data: {response_data}"
        )
        raise
