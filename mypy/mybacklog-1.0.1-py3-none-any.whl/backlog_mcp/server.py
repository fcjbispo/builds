#!/usr/bin/env python3
"""MCP Server for MyBacklogManager API.

This server provides tools to interact with the MyBacklogManager REST API,
enabling LLMs to manage backlog items, view dashboards, and perform
import/export operations.

Usage:
    # stdio transport (default)
    python -m backlog_mcp.server

    # streamable HTTP transport
    python -m backlog_mcp.server --transport streamable-http --port 9000

Environment Variables:
    BACKLOG_API_URL: Base URL for the MyBacklogManager API
                     (default: http://127.0.0.1:8833)
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Optional

import httpx
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

from backlog_api.app.statuses import DEFAULT_STATUS, Status

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_API_URL = "http://127.0.0.1:8833"
API_BASE_URL = os.environ.get("BACKLOG_API_URL", DEFAULT_API_URL)

# ---------------------------------------------------------------------------
# Server Initialization
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "backlog_mcp",
    stateless_http=True,
    json_response=True,
)


# ---------------------------------------------------------------------------
# Pydantic Input Models
# ---------------------------------------------------------------------------

class ResponseFormat(str):
    """Output format for tool responses."""

    MARKDOWN = "markdown"
    JSON = "json"


class ListItemsInput(BaseModel):
    """Input model for listing backlog items."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    projeto: Optional[str] = Field(
        default=None,
        description="Filter by project name (optional)",
    )
    componente: Optional[str] = Field(
        default=None,
        description="Filter by component name (optional)",
    )
    status: Status | None = Field(
        default=None,
        description="Filter by Factory backlog status (optional)",
    )
    response_format: str = Field(
        default="markdown",
        description="Output format: 'markdown' or 'json'",
    )


class GetItemInput(BaseModel):
    """Input model for retrieving a single backlog item."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    item_id: int = Field(
        ...,
        description="Unique ID of the item",
        ge=1,
    )
    response_format: str = Field(
        default="markdown",
        description="Output format: 'markdown' or 'json'",
    )


class CreateItemInput(BaseModel):
    """Input model for creating a new backlog item."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    item: int = Field(
        ...,
        description="Item number within the project",
        ge=1,
    )
    projeto: str = Field(
        ...,
        description="Project name",
        min_length=1,
    )
    componente: str = Field(
        ...,
        description="Component name",
        min_length=1,
    )
    titulo: str = Field(
        ...,
        description="Item title",
        min_length=1,
    )
    detalhamento: Optional[str] = Field(
        default=None,
        description="Detailed description (markdown supported)",
    )
    status: Status = Field(
        default=DEFAULT_STATUS,
        description="Factory backlog status",
    )


class UpdateItemInput(BaseModel):
    """Input model for updating an existing backlog item (full update)."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    item_id: int = Field(
        ...,
        description="Unique ID of the item to update",
        ge=1,
    )
    item: int = Field(
        ...,
        description="Item number within the project",
        ge=1,
    )
    projeto: str = Field(
        ...,
        description="Project name",
        min_length=1,
    )
    componente: str = Field(
        ...,
        description="Component name",
        min_length=1,
    )
    titulo: str = Field(
        ...,
        description="Item title",
        min_length=1,
    )
    detalhamento: Optional[str] = Field(
        default=None,
        description="Detailed description (markdown supported)",
    )
    status: Status = Field(
        default=DEFAULT_STATUS,
        description="Factory backlog status",
    )


class PatchItemInput(BaseModel):
    """Input model for partial update of a backlog item."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    item_id: int = Field(
        ...,
        description="Unique ID of the item to patch",
        ge=1,
    )
    item: Optional[int] = Field(
        default=None,
        description="Item number (optional)",
        ge=1,
    )
    projeto: Optional[str] = Field(
        default=None,
        description="Project name (optional)",
        min_length=1,
    )
    componente: Optional[str] = Field(
        default=None,
        description="Component name (optional)",
        min_length=1,
    )
    titulo: Optional[str] = Field(
        default=None,
        description="Item title (optional)",
        min_length=1,
    )
    detalhamento: Optional[str] = Field(
        default=None,
        description="Detailed description (optional)",
    )
    status: Status | None = Field(
        default=None,
        description="Factory backlog status (optional)",
    )


class DeleteItemInput(BaseModel):
    """Input model for deleting a backlog item."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    item_id: int = Field(
        ...,
        description="Unique ID of the item to delete",
        ge=1,
    )


class ImportCsvInput(BaseModel):
    """Input model for importing items from CSV."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    csv_content: str = Field(
        ...,
        description="Raw CSV content string",
        min_length=1,
    )
    append: bool = Field(
        default=False,
        description="If True, append to existing items instead of replacing",
    )


class ResponseFormatInput(BaseModel):
    """Input model for operations that only need response format."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )

    response_format: str = Field(
        default="markdown",
        description="Output format: 'markdown' or 'json'",
    )


# ---------------------------------------------------------------------------
# Shared Utilities
# ---------------------------------------------------------------------------

def _handle_api_error(e: Exception) -> str:
    """Consistent error formatting across all tools."""
    if isinstance(e, httpx.HTTPStatusError):
        if e.response.status_code == 404:
            return "Error: Resource not found. Please check the ID or parameters are correct."
        elif e.response.status_code == 422:
            detail = ""
            try:
                detail = json.dumps(e.response.json(), indent=2)
            except Exception:
                detail = e.response.text
            return f"Error: Validation error (422):\n{detail}"
        elif e.response.status_code == 429:
            return "Error: Rate limit exceeded. Please wait before making more requests."
        return (
            f"Error: API request failed with status {e.response.status_code}. "
            f"Response: {e.response.text}"
        )
    elif isinstance(e, httpx.TimeoutException):
        return "Error: Request timed out. Please try again."
    elif isinstance(e, httpx.ConnectError):
        return (
            f"Error: Could not connect to Backlog API at {API_BASE_URL}. "
            "Please verify the server is running."
        )
    return f"Error: Unexpected error occurred: {type(e).__name__}: {e}"


async def _make_api_request(
    endpoint: str,
    method: str = "GET",
    params: Optional[dict] = None,
    json_data: Optional[dict] = None,
) -> dict:
    """Reusable async function for all API calls."""
    async with httpx.AsyncClient() as client:
        response = await client.request(
            method,
            f"{API_BASE_URL}{endpoint}",
            params=params,
            json=json_data,
            timeout=30.0,
        )
        response.raise_for_status()
        if response.status_code == 204:
            return {}
        return response.json()


def _format_item_markdown(item: dict) -> list[str]:
    """Format a single backlog item as markdown lines."""
    lines = [
        f"### Item #{item['item']} (ID: {item['id']})",
        "",
        f"- **Project**: {item['projeto']}",
        f"- **Component**: {item['componente']}",
        f"- **Title**: {item['titulo']}",
        f"- **Status**: {item['status']}",
    ]
    if item.get("detalhamento"):
        lines.append(f"- **Details**: {item['detalhamento']}")
    lines.append("")
    return lines


# ---------------------------------------------------------------------------
# Tool Definitions
# ---------------------------------------------------------------------------

@mcp.tool(
    name="backlog_list_items",
    annotations={
        "title": "List Backlog Items",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_list_items(params: ListItemsInput) -> str:
    """List all backlog items with optional filters.

    Retrieves the complete list of backlog items, optionally filtered by
    project, component, or status. Returns paginated results with item details.

    Args:
        params: Validated input parameters containing:
            - projeto: Optional project name filter
            - componente: Optional component name filter
            - status: Optional status filter
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted list of backlog items

    Examples:
        - List all items: no filters
        - Filter by project: projeto="MyProject"
        - Filter by status: status="em-progresso"
        - Combined filter: projeto="MyProject", status="resolvido"
    """
    try:
        query_params = {}
        if params.projeto:
            query_params["projeto"] = params.projeto
        if params.componente:
            query_params["componente"] = params.componente
        if params.status:
            query_params["status"] = params.status

        data = await _make_api_request("/items", params=query_params)
        items = data.get("items", [])
        total = data.get("total", 0)

        if not items:
            return "No backlog items found matching the criteria."

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        lines = [f"# Backlog Items ({total} total)", ""]
        for item in items:
            lines.extend(_format_item_markdown(item))
        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_get_item",
    annotations={
        "title": "Get Backlog Item",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_get_item(params: GetItemInput) -> str:
    """Retrieve a single backlog item by its unique ID.

    Fetches detailed information about a specific backlog item including
    project, component, title, status, and description.

    Args:
        params: Validated input parameters containing:
            - item_id: Unique ID of the item
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted item details

    Examples:
        - Get item details: item_id=42
    """
    try:
        data = await _make_api_request(f"/items/{params.item_id}")

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        return "\n".join(_format_item_markdown(data))

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_create_item",
    annotations={
        "title": "Create Backlog Item",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def backlog_create_item(params: CreateItemInput) -> str:
    """Create a new backlog item.

    Creates a new item in the backlog with the specified project, component,
    title, and optional description and status.

    Args:
        params: Validated input parameters containing:
            - item: Item number within the project (>=1)
            - projeto: Project name
            - componente: Component name
            - titulo: Item title
            - detalhamento: Optional detailed description
            - status: Factory backlog status (default: 'aberto')

    Returns:
        str: Markdown or JSON formatted created item details

    Examples:
        - Create minimal item: item=1, projeto="API", componente="Auth", titulo="Login endpoint"
        - Create with details: include detalhamento and status
    """
    try:
        payload = params.model_dump(exclude_none=True)
        data = await _make_api_request("/items", method="POST", json_data=payload)

        return (
            f"✅ Item created successfully!\n\n"
            f"ID: {data['id']}\n"
            f"Item #: {data['item']}\n"
            f"Project: {data['projeto']}\n"
            f"Component: {data['componente']}\n"
            f"Title: {data['titulo']}\n"
            f"Status: {data['status']}"
        )

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_update_item",
    annotations={
        "title": "Update Backlog Item",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_update_item(params: UpdateItemInput) -> str:
    """Update an existing backlog item (full update).

    Replaces all fields of an existing item. All fields are required
    except detalhamento which is optional.

    Args:
        params: Validated input parameters containing:
            - item_id: Unique ID of the item to update
            - item: New item number
            - projeto: New project name
            - componente: New component name
            - titulo: New title
            - detalhamento: New description (optional)
            - status: New status

    Returns:
        str: Markdown or JSON formatted updated item details

    Examples:
        - Update entire item: provide all fields
    """
    try:
        payload = params.model_dump(exclude={"item_id"}, exclude_none=True)
        data = await _make_api_request(
            f"/items/{params.item_id}",
            method="PUT",
            json_data=payload,
        )

        return (
            f"✅ Item updated successfully!\n\n"
            f"ID: {data['id']}\n"
            f"Item #: {data['item']}\n"
            f"Project: {data['projeto']}\n"
            f"Component: {data['componente']}\n"
            f"Title: {data['titulo']}\n"
            f"Status: {data['status']}"
        )

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_patch_item",
    annotations={
        "title": "Patch Backlog Item",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_patch_item(params: PatchItemInput) -> str:
    """Partially update an existing backlog item.

    Updates only the fields that are provided. Unspecified fields
    retain their current values.

    Args:
        params: Validated input parameters containing:
            - item_id: Unique ID of the item to patch
            - item: Optional new item number
            - projeto: Optional new project name
            - componente: Optional new component name
            - titulo: Optional new title
            - detalhamento: Optional new description
            - status: Optional new status

    Returns:
        str: Markdown or JSON formatted patched item details

    Examples:
        - Change status only: item_id=42, status="resolvido"
        - Change title: item_id=42, titulo="New title"
    """
    try:
        payload = params.model_dump(exclude={"item_id"}, exclude_none=True)
        if not payload:
            return "Error: No fields provided to update. Please specify at least one field."

        data = await _make_api_request(
            f"/items/{params.item_id}",
            method="PATCH",
            json_data=payload,
        )

        return (
            f"✅ Item patched successfully!\n\n"
            f"ID: {data['id']}\n"
            f"Item #: {data['item']}\n"
            f"Project: {data['projeto']}\n"
            f"Component: {data['componente']}\n"
            f"Title: {data['titulo']}\n"
            f"Status: {data['status']}"
        )

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_delete_item",
    annotations={
        "title": "Delete Backlog Item",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_delete_item(params: DeleteItemInput) -> str:
    """Delete a backlog item by its unique ID.

    Permanently removes the item from the backlog. This operation
    cannot be undone.

    Args:
        params: Validated input parameters containing:
            - item_id: Unique ID of the item to delete

    Returns:
        str: Confirmation message or error

    Examples:
        - Delete item: item_id=42
    """
    try:
        await _make_api_request(f"/items/{params.item_id}", method="DELETE")
        return f"✅ Item {params.item_id} deleted successfully."

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_list_projects",
    annotations={
        "title": "List Projects",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_list_projects(params: ResponseFormatInput) -> str:
    """List all unique project names in the backlog.

    Returns a list of distinct project names currently referenced
    by backlog items.

    Args:
        params: Validated input parameters containing:
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted list of projects
    """
    try:
        data = await _make_api_request("/items/meta/projects")

        if not data:
            return "No projects found."

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        lines = ["# Projects", ""]
        for i, proj in enumerate(data, 1):
            lines.append(f"{i}. {proj}")
        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_list_components",
    annotations={
        "title": "List Components",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_list_components(params: ResponseFormatInput) -> str:
    """List all unique component names in the backlog.

    Returns a list of distinct component names currently referenced
    by backlog items.

    Args:
        params: Validated input parameters containing:
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted list of components
    """
    try:
        data = await _make_api_request("/items/meta/components")

        if not data:
            return "No components found."

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        lines = ["# Components", ""]
        for i, comp in enumerate(data, 1):
            lines.append(f"{i}. {comp}")
        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_list_statuses",
    annotations={
        "title": "List Valid Statuses",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_list_statuses(params: ResponseFormatInput) -> str:
    """List all valid backlog item statuses.

    Returns the list of valid status values that can be assigned
    to backlog items.

    Args:
        params: Validated input parameters containing:
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted list of statuses
    """
    try:
        data = await _make_api_request("/items/meta/statuses")

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        lines = ["# Valid Statuses", ""]
        for status in data:
            lines.append(f"- {status}")
        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_get_dashboard",
    annotations={
        "title": "Get Dashboard Statistics",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_get_dashboard(params: ResponseFormatInput) -> str:
    """Get backlog dashboard statistics.

    Retrieves aggregated statistics including total items,
    items in progress, completed items, number of projects,
    and breakdown by status.

    Args:
        params: Validated input parameters containing:
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: Markdown or JSON formatted dashboard statistics
    """
    try:
        data = await _make_api_request("/items/dashboard/stats")

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        lines = [
            "# Dashboard Statistics",
            "",
            f"- **Total Items**: {data['total']}",
            f"- **In Progress**: {data['em_andamento']}",
            f"- **Completed**: {data['concluidos']}",
            f"- **Projects**: {data['projetos']}",
            "",
            "## Status Breakdown",
            "",
        ]
        for sc in data.get("por_status", []):
            lines.append(f"- {sc['status']}: {sc['count']}")
        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_export_csv",
    annotations={
        "title": "Export Backlog to CSV",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_export_csv(params: ResponseFormatInput) -> str:
    """Export all backlog items to CSV format.

    Retrieves the complete backlog as a CSV string with columns:
    Item, Project, Component, Title, Details, Status.

    Args:
        params: Validated input parameters containing:
            - response_format: Output format ('markdown' or 'json')

    Returns:
        str: CSV content string or JSON with metadata
    """
    try:
        data = await _make_api_request("/items/export/csv")

        if params.response_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)

        return (
            f"# CSV Export\n\n"
            f"**Filename**: {data['filename']}\n"
            f"**Content Type**: {data['content_type']}\n\n"
            f"```csv\n{data['content']}\n```"
        )

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_import_csv",
    annotations={
        "title": "Import Backlog from CSV",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def backlog_import_csv(params: ImportCsvInput) -> str:
    """Import backlog items from CSV content.

    Imports items from a CSV string. By default replaces all
    existing items. Set append=True to add to existing items.

    Expected CSV columns: Item, Project, Component, Title, Details, Status

    Args:
        params: Validated input parameters containing:
            - csv_content: Raw CSV content string
            - append: If True, append to existing items

    Returns:
        str: Import result summary
    """
    try:
        data = await _make_api_request(
            "/items/import/csv",
            method="POST",
            json_data={
                "csv_content": params.csv_content,
                "append": params.append,
            },
        )

        imported = data.get("imported", 0)
        errors = data.get("errors", [])
        success = data.get("success", False)

        lines = ["# CSV Import Result", ""]
        if success:
            lines.append(f"✅ Successfully imported **{imported}** items.")
        elif imported > 0:
            lines.append(f"⚠️ Imported **{imported}** items with **{len(errors)}** error(s).")
        else:
            lines.append("❌ Import failed. No items were imported.")

        if errors:
            lines.extend(["", "## Errors:", ""])
            for err in errors:
                lines.append(f"- {err}")

        return "\n".join(lines)

    except Exception as e:
        return _handle_api_error(e)


@mcp.tool(
    name="backlog_clear_all",
    annotations={
        "title": "Clear All Backlog Items",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def backlog_clear_all() -> str:
    """Delete all backlog items (administrative operation).

    WARNING: This permanently removes ALL items from the backlog.
    This operation cannot be undone.

    Returns:
        str: Confirmation message or error
    """
    try:
        await _make_api_request("/items/admin/clear-all", method="DELETE")
        return "✅ All backlog items have been cleared."

    except Exception as e:
        return _handle_api_error(e)


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point for the Backlog MCP server."""
    parser = argparse.ArgumentParser(description="MyBacklogManager MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default="stdio",
        help="Transport mechanism (default: stdio)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=9000,
        help="Port for streamable HTTP transport (default: 9000)",
    )
    parser.add_argument(
        "--api-url",
        default=os.environ.get("BACKLOG_API_URL", DEFAULT_API_URL),
        help="Backlog API base URL (default: http://127.0.0.1:8833)",
    )
    args = parser.parse_args()

    # Override global API URL if provided
    global API_BASE_URL
    if args.api_url:
        API_BASE_URL = args.api_url

    if args.transport == "streamable-http":
        mcp.settings.host = "0.0.0.0"
        mcp.settings.port = args.port
        # The MCP HTTP service is restricted to the private FBNet Docker network.
        mcp.settings.transport_security = None
        mcp.run(transport="streamable-http")
    else:
        mcp.run()


if __name__ == "__main__":
    main()
