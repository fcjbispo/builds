"""Pydantic models para validação e serialização."""

from __future__ import annotations

from pydantic import BaseModel, Field

from backlog_api.app.statuses import DEFAULT_STATUS, Status


class ItemBase(BaseModel):
    """Campos base de um item de backlog."""
    item: int = Field(..., ge=1, description="Número do item no projeto")
    projeto: str = Field(..., min_length=1, description="Nome do projeto")
    componente: str = Field(..., min_length=1, description="Nome do componente")
    titulo: str = Field(..., min_length=1, description="Título do item")
    detalhamento: str | None = Field(None, description="Descrição detalhada em markdown")
    status: Status = Field(default=DEFAULT_STATUS, description="Status do item")


class ItemCreate(ItemBase):
    """Model para criação de item."""
    pass


class ItemUpdate(ItemBase):
    """Model para atualização de item (todos os campos obrigatórios)."""
    pass


class ItemPartialUpdate(BaseModel):
    """Model para atualização parcial (PATCH)."""
    item: int | None = Field(None, ge=1)
    projeto: str | None = Field(None, min_length=1)
    componente: str | None = Field(None, min_length=1)
    titulo: str | None = Field(None, min_length=1)
    detalhamento: str | None = None
    status: Status | None = Field(None, description="Status do item")


class ItemResponse(ItemBase):
    """Model de resposta com ID gerado pelo banco."""
    id: int = Field(..., description="ID único do item")

    class Config:
        from_attributes = True


class ItemListResponse(BaseModel):
    """Resposta paginada de lista de itens."""
    items: list[ItemResponse]
    total: int


class StatusCount(BaseModel):
    """Contagem por status."""
    status: Status
    count: int


class DashboardStats(BaseModel):
    """Estatísticas do dashboard."""
    total: int
    em_andamento: int
    concluidos: int
    projetos: int
    por_status: list[StatusCount]


class CsvExportResponse(BaseModel):
    """Resposta de exportação CSV."""
    content: str
    filename: str
    content_type: str


class CsvImportRequest(BaseModel):
    """Requisição de importação CSV."""
    csv_content: str
    append: bool = False


class CsvImportResponse(BaseModel):
    """Resposta de importação CSV."""
    imported: int
    errors: list[str]
    success: bool
