"""Configuração de banco de dados SQLite com WAL para concorrência."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from backlog_api.app.statuses import DEFAULT_STATUS, STATUS_OPTIONS, migrate_legacy_status

APP_DIR = Path(__file__).resolve().parents[3]
configured_db_path = os.environ.get("FBNET_BACKLOGMANAGER_DB_PATH")
DB_PATH = Path(configured_db_path).expanduser() if configured_db_path else APP_DIR / "backlog.db"


def get_connection() -> sqlite3.Connection:
    """Retorna conexão com SQLite configurado para concorrência."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    
    # WAL mode: permite leitura concorrente com gravação
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    
    return conn


def init_database() -> None:
    """Create the official table and migrate the legacy table once."""
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("BEGIN IMMEDIATE")
        tables = {
            row[0]
            for row in cursor.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }

        if "backlog_items" not in tables:
            cursor.execute(f"""
                CREATE TABLE backlog_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item INTEGER NOT NULL,
                    projeto TEXT NOT NULL,
                    componente TEXT NOT NULL,
                    titulo TEXT NOT NULL,
                    detalhamento TEXT,
                    status TEXT NOT NULL DEFAULT '{DEFAULT_STATUS}'
                        CHECK (status IN ({','.join(repr(status) for status in STATUS_OPTIONS)}))
                )
            """)

            if "backlog" in tables:
                rows = cursor.execute("""
                    SELECT id, item, projeto, componente, titulo, detalhamento, status
                    FROM backlog
                    ORDER BY id
                """).fetchall()
                cursor.executemany("""
                    INSERT INTO backlog_items
                        (id, item, projeto, componente, titulo, detalhamento, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, [
                    (*row[:6], migrate_legacy_status(row[6], row[5]) or "suspenso")
                    for row in rows
                ])

                copied = cursor.execute("SELECT COUNT(*) FROM backlog_items").fetchone()[0]
                if copied != len(rows):
                    raise RuntimeError(f"Status migration copied {copied} of {len(rows)} rows")
                cursor.execute("ALTER TABLE backlog RENAME TO backlog_legacy")

        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
