"""Router para endpoints de itens de backlog."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from backlog_api.app import crud
from backlog_api.app.models import (
    CsvExportResponse,
    CsvImportRequest,
    CsvImportResponse,
    DashboardStats,
    ItemCreate,
    ItemListResponse,
    ItemPartialUpdate,
    ItemResponse,
    ItemUpdate,
)
from backlog_api.app.statuses import STATUS_OPTIONS, Status

router = APIRouter(prefix="/items", tags=["items"])


# ============================================================
# CRUD BÁSICO
# ============================================================

@router.get("", response_model=ItemListResponse)
def list_items(
    projeto: str | None = Query(None, description="Filtrar por projeto"),
    componente: str | None = Query(None, description="Filtrar por componente"),
    status: Status | None = None,
) -> dict:
    """Lista todos os itens com filtros opcionais."""
    items = crud.get_all_items(projeto=projeto, componente=componente, status=status)
    return {
        "items": items,
        "total": len(items),
    }


@router.post("", response_model=ItemResponse, status_code=201)
def create_item(data: ItemCreate) -> dict:
    """Cria novo item no backlog."""
    return crud.create_item(data.model_dump())


@router.get("/{item_id}", response_model=ItemResponse)
def get_item(item_id: int) -> dict:
    """Retorna um item específico pelo ID."""
    item = crud.get_item_by_id(item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Item não encontrado")
    return item


@router.put("/{item_id}", response_model=ItemResponse)
def update_item(item_id: int, data: ItemUpdate) -> dict:
    """Atualiza item existente (todos os campos)."""
    item = crud.update_item(item_id, data.model_dump())
    if item is None:
        raise HTTPException(status_code=404, detail="Item não encontrado")
    return item


@router.patch("/{item_id}", response_model=ItemResponse)
def patch_item(item_id: int, data: ItemPartialUpdate) -> dict:
    """Atualização parcial de item."""
    item = crud.patch_item(item_id, data.model_dump(exclude_unset=True))
    if item is None:
        raise HTTPException(status_code=404, detail="Item não encontrado")
    return item


@router.delete("/{item_id}", status_code=204)
def delete_item(item_id: int) -> None:
    """Remove item pelo ID."""
    deleted = crud.delete_item(item_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Item não encontrado")


# ============================================================
# OPERAÇÕES AGREGADAS
# ============================================================

@router.get("/meta/projects", response_model=list[str])
def list_projects() -> list[str]:
    """Retorna lista de projetos únicos."""
    return crud.get_projects()


@router.get("/meta/components", response_model=list[str])
def list_components() -> list[str]:
    """Retorna lista de componentes únicos."""
    return crud.get_components()


@router.get("/meta/statuses", response_model=list[str])
def list_statuses() -> list[str]:
    """Retorna lista de status válidos."""
    return STATUS_OPTIONS


# ============================================================
# DASHBOARD
# ============================================================

@router.get("/dashboard/stats", response_model=DashboardStats)
def get_dashboard() -> dict:
    """Retorna estatísticas para o dashboard."""
    return crud.get_dashboard_stats()


# ============================================================
# IMPORTAR / EXPORTAR
# ============================================================

@router.get("/export/csv", response_model=CsvExportResponse)
def export_csv() -> dict:
    """Exporta todos os itens como CSV."""
    csv_data = crud.export_to_csv()
    return {
        "content": csv_data,
        "filename": "Backlog.csv",
        "content_type": "text/csv",
    }


@router.post("/import/csv", response_model=CsvImportResponse)
def import_csv(data: CsvImportRequest) -> dict:
    """Importa itens de CSV."""
    imported, errors = crud.import_from_csv(data.csv_content, append=data.append)
    return {
        "imported": imported,
        "errors": errors,
        "success": imported > 0 and len(errors) == 0,
    }


@router.delete("/admin/clear-all", status_code=204)
def clear_all() -> None:
    """Remove todos os itens (uso administrativo)."""
    crud.clear_all_items()
