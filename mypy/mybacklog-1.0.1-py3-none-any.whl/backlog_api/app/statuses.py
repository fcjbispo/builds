"""Canonical backlog status values and legacy-status conversion."""

from __future__ import annotations

from typing import Literal

type Status = Literal[
    "aberto",
    "em-analise",
    "priorizado",
    "em-progresso",
    "resolvido",
    "rejeitado",
    "suspenso",
]

STATUS_OPTIONS: list[str] = [
    "aberto",
    "em-analise",
    "priorizado",
    "em-progresso",
    "resolvido",
    "rejeitado",
    "suspenso",
]
DEFAULT_STATUS: Status = "aberto"


def migrate_legacy_status(status: str | None, detalhamento: str | None) -> Status | None:
    """Map a known legacy status; return None when no direct mapping exists."""
    if status is None:
        return None
    if status == "Backlog":
        return "suspenso" if "suspenso" in (detalhamento or "").casefold() else "aberto"

    legacy_map: dict[str, Status] = {
        "aberto": "aberto",
        "em-analise": "em-analise",
        "priorizado": "priorizado",
        "em-progresso": "em-progresso",
        "resolvido": "resolvido",
        "rejeitado": "rejeitado",
        "suspenso": "suspenso",
        "Aberto": "aberto",
        "A Fazer": "aberto",
        "Em Andamento": "em-progresso",
        "Concluído": "resolvido",
        "Concluido": "resolvido",
        "Feito": "resolvido",
        # Factory has no review state; unresolved legacy states are suspended.
        "Em Revisão": "suspenso",
        "Em Revisao": "suspenso",
    }
    return legacy_map.get(status)
