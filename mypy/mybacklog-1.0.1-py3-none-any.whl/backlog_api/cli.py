"""Local development and database commands for MyBacklogManager."""

from __future__ import annotations

import importlib.metadata
import os
from pathlib import Path

import typer
from typing_extensions import Annotated

from backlog_api.app.database import DB_PATH

APP_NAME = "MyBacklogManager"
API_PORT = 8833

GREEN = typer.colors.GREEN
YELLOW = typer.colors.YELLOW
BLUE = typer.colors.BLUE
RED = typer.colors.RED


def _get_version() -> str:
    try:
        return importlib.metadata.version("mybacklog")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def _info(msg: str) -> None:
    typer.secho(f"[INFO] {msg}", fg=BLUE)


def _ok(msg: str) -> None:
    typer.secho(f"[OK] {msg}", fg=GREEN)


def _warn(msg: str) -> None:
    typer.secho(f"[AVISO] {msg}", fg=YELLOW, err=True)


def _err(msg: str) -> None:
    typer.secho(f"[ERRO] {msg}", fg=RED, err=True)


app = typer.Typer(
    name=APP_NAME,
    help="Run MyBacklogManager local development tools and manage its database.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"{APP_NAME} {_get_version()}")
        raise typer.Exit()


@app.callback()
def _main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    """CLI callback for global options."""


@app.command()
def api(
    port: Annotated[int, typer.Option("--port", "-p", help="API port")] = API_PORT,
    host: Annotated[str, typer.Option("--host", "-h", help="Bind host")] = "127.0.0.1",
) -> None:
    """Run the API locally."""
    _info(f"Starting API at http://{host}:{port}")
    try:
        os.execvp(
            "uv",
            [
                "uv",
                "run",
                "uvicorn",
                "backlog_api.app.main:app",
                "--host",
                host,
                "--port",
                str(port),
                "--reload",
                "--log-level",
                "info",
            ],
        )
    except FileNotFoundError:
        _err("Command 'uv' not found. Install uv.")
        raise typer.Exit(1)


@app.command()
def web(
    port: Annotated[int, typer.Option("--port", "-p", help="Vite dev server port")] = 5173,
    host: Annotated[str, typer.Option("--host", "-h", help="Bind host")] = "0.0.0.0",
    api_url: Annotated[str, typer.Option("--api-url", help="API URL for proxy")] = "http://localhost:8833",
) -> None:
    """Run Vite locally (requires the API to be running)."""
    _warn(f"Make sure the API is running at {api_url}")
    _info(f"Starting Vite dev server at http://{host}:{port}")
    js_dir = Path(__file__).resolve().parents[1] / "backlog_manager_js"
    if not (js_dir / "package.json").exists():
        _err(f"Frontend directory not found: {js_dir}")
        raise typer.Exit(1)

    env = os.environ.copy()
    env["VITE_API_URL"] = api_url
    try:
        os.chdir(js_dir)
        os.execvpe("npx", ["npx", "vite", f"--port={port}", f"--host={host}"], env)
    except FileNotFoundError:
        _err("Command 'npx' not found. Install Node.js.")
        raise typer.Exit(1)


@app.command()
def clean_db(
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Confirm without prompt")] = False,
) -> None:
    """Remove the configured SQLite database file."""
    if not DB_PATH.exists():
        _warn(f"No database found at {DB_PATH}.")
        return

    if not confirm:
        _warn(f"This will permanently delete: {DB_PATH}")
        choice = typer.prompt("Are you sure? [y/N]", default="N")
        if choice.lower() not in ("s", "sim", "y", "yes"):
            _info("Operation cancelled.")
            return

    try:
        DB_PATH.unlink()
        _ok("Database removed.")
    except OSError as e:
        _err(f"Failed to remove database: {e}")
        raise typer.Exit(1)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
