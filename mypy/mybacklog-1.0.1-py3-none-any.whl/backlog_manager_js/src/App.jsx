import { Routes, Route } from 'react-router-dom';
import { Sidebar } from '@/components/sidebar';
import DashboardPage from '@/pages/dashboard';
import ItemsPage from '@/pages/items';

export default function App() {
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/items" element={<ItemsPage />} />
        </Routes>
      </main>
    </div>
  );
}