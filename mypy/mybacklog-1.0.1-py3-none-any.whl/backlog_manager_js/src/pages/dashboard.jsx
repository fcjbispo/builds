import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProjectMetrics } from '@/components/project-metrics';
import { StatsCards } from '@/components/stats-cards';
import { StatusChart } from '@/components/status-chart';
import { api } from '@/lib/api';

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [items, setItems] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [dashboard, itemList, validStatuses] = await Promise.all([
        api.getDashboard(),
        api.getItems(),
        api.getStatuses(),
      ]);
      setStats(dashboard);
      setItems(itemList.items || []);
      setStatuses(validStatuses || []);
    } catch (err) {
      if (!silent) toast.error('Erro ao carregar dashboard: ' + err.message);
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchDashboard();
    const timer = window.setInterval(() => void fetchDashboard(true), 30000);
    return () => window.clearInterval(timer);
  }, [fetchDashboard]);

  return (
    <div className="mx-auto max-w-[1400px] space-y-6 p-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="mt-1 text-sm text-muted-foreground">Visão geral do backlog de projetos</p>
          <p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-primary">
            Atualização automática · 30 s
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => fetchDashboard()} disabled={loading}>
          <RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>
      <StatsCards stats={stats} loading={loading} />
      <ProjectMetrics items={items} statuses={statuses} loading={loading} />
      <StatusChart data={stats?.por_status} loading={loading} />
    </div>
  );
}
