import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { Plus, RefreshCw, Filter, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ItemsTable } from '@/components/items-table';
import { ItemForm } from '@/components/item-form';
import { ItemDetailSheet } from '@/components/item-detail-sheet';
import { ImportExportActions } from '@/components/import-export-actions';
import { api } from '@/lib/api';
export default function ItemsPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState([]);
  const [components, setComponents] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [filterProjeto, setFilterProjeto] = useState(() => new URLSearchParams(window.location.search).get('projeto') || '__all__');
  const [filterComponente, setFilterComponente] = useState('__all__');
  const [filterStatus, setFilterStatus] = useState('__all__');
  const [showFilters, setShowFilters] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [detailItem, setDetailItem] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const fetchMeta = async () => { try { const [p, c, s] = await Promise.all([api.getProjects(), api.getComponents(), api.getStatuses()]); setProjects(p || []); setComponents(c || []); setStatuses(s || []); } catch {} };
  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (filterProjeto !== '__all__') params.projeto = filterProjeto;
      if (filterComponente !== '__all__') params.componente = filterComponente;
      if (filterStatus !== '__all__') params.status = filterStatus;
      const data = await api.getItems(params);
      setItems(data.items || []);
    } catch (err) { toast.error('Erro ao carregar itens: ' + err.message); } finally { setLoading(false); }
  }, [filterProjeto, filterComponente, filterStatus]);
  useEffect(() => { fetchMeta(); }, []);
  useEffect(() => { fetchItems(); }, [fetchItems]);
  const handleCreate = async (data) => { setCreating(true); try { await api.createItem(data); toast.success('Item criado com sucesso'); setCreateOpen(false); fetchItems(); fetchMeta(); } catch (err) { toast.error(err.message); } finally { setCreating(false); } };
  const handleEdit = async (data) => { setCreating(true); try { await api.updateItem(editItem.id, data); toast.success('Item atualizado com sucesso'); setEditOpen(false); setEditItem(null); fetchItems(); } catch (err) { toast.error(err.message); } finally { setCreating(false); } };
  const handleDelete = async (item) => { try { await api.deleteItem(item.id); toast.success('Item excluído com sucesso'); fetchItems(); } catch (err) { toast.error(err.message); } };
  const handleView = (item) => { setDetailItem(item); setDetailOpen(true); };
  const handleEditClick = (item) => { setEditItem(item); setEditOpen(true); };
  const hasActiveFilters = filterProjeto !== '__all__' || filterComponente !== '__all__' || filterStatus !== '__all__';
  const clearFilters = () => { setFilterProjeto('__all__'); setFilterComponente('__all__'); setFilterStatus('__all__'); };
  return (<div className="p-6 space-y-5 max-w-[1400px] mx-auto"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"><div><h2 className="text-2xl font-bold tracking-tight">Backlog de Itens</h2><p className="text-muted-foreground text-sm mt-1">{items.length} {items.length === 1 ? 'item encontrado' : 'itens encontrados'}</p></div><div className="flex items-center gap-2 flex-wrap"><Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className={showFilters ? 'bg-accent' : ''}><Filter className="mr-1.5 h-3.5 w-3.5" />Filtros{hasActiveFilters && (<span className="ml-1.5 h-5 w-5 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold">!</span>)}</Button><Button variant="outline" size="sm" onClick={fetchItems} disabled={loading}><RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /></Button><ImportExportActions onRefresh={fetchItems} /><Button size="sm" onClick={() => setCreateOpen(true)}><Plus className="mr-1.5 h-3.5 w-3.5" />Novo Item</Button></div></div>{showFilters && (<div className="flex flex-wrap items-end gap-3 p-4 rounded-lg border border-border bg-card"><div className="space-y-1.5 min-w-[160px]"><label className="text-xs font-medium text-muted-foreground">Projeto</label><Select value={filterProjeto} onValueChange={setFilterProjeto}><SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Todos" /></SelectTrigger><SelectContent><SelectItem value="__all__">Todos os projetos</SelectItem>{projects.map((p) => (<SelectItem key={p} value={p}>{p}</SelectItem>))}</SelectContent></Select></div><div className="space-y-1.5 min-w-[160px]"><label className="text-xs font-medium text-muted-foreground">Componente</label><Select value={filterComponente} onValueChange={setFilterComponente}><SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Todos" /></SelectTrigger><SelectContent><SelectItem value="__all__">Todos os componentes</SelectItem>{components.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}</SelectContent></Select></div><div className="space-y-1.5 min-w-[160px]"><label className="text-xs font-medium text-muted-foreground">Status</label><Select value={filterStatus} onValueChange={setFilterStatus}><SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Todos" /></SelectTrigger><SelectContent><SelectItem value="__all__">Todos os status</SelectItem>{statuses.map((s) => (<SelectItem key={s} value={s}>{s}</SelectItem>))}</SelectContent></Select></div>{hasActiveFilters && (<Button variant="ghost" size="sm" className="h-8 text-xs" onClick={clearFilters}><X className="mr-1 h-3 w-3" />Limpar filtros</Button>)}</div>)}<ItemsTable items={items} loading={loading} onView={handleView} onEdit={handleEditClick} onDelete={handleDelete} /><Dialog open={createOpen} onOpenChange={setCreateOpen}><DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>Novo Item do Backlog</DialogTitle><DialogDescription>Preencha os campos abaixo para adicionar um novo item.</DialogDescription></DialogHeader><ItemForm statuses={statuses} onSubmit={handleCreate} onCancel={() => setCreateOpen(false)} loading={creating} /></DialogContent></Dialog><Dialog open={editOpen} onOpenChange={(v) => { if (!v) setEditItem(null); setEditOpen(v); }}><DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>Editar Item #{editItem?.item}</DialogTitle><DialogDescription>Altere os campos desejados.</DialogDescription></DialogHeader>{editItem && (<ItemForm item={editItem} statuses={statuses} onSubmit={handleEdit} onCancel={() => { setEditOpen(false); setEditItem(null); }} loading={creating} />)}</DialogContent></Dialog><ItemDetailSheet item={detailItem} open={detailOpen} onOpenChange={setDetailOpen} statuses={statuses} onRefresh={fetchItems} /></div>);
}
