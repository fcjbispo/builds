import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'sonner';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster position="top-right" toastOptions={{ style: { background: 'hsl(222, 47%, 8%)', border: '1px solid hsl(217, 33%, 16%)', color: 'hsl(210, 40%, 96%)', fontFamily: 'Space Grotesk, sans-serif' } }} />
    </BrowserRouter>
  </React.StrictMode>
);