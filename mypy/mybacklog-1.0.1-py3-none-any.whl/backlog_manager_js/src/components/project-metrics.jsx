import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { groupDashboardItems } from '@/lib/dashboard-data';

const STATUS_COLORS = {
  aberto: '#94a3b8',
  'em-analise': '#60a5fa',
  priorizado: '#a78bfa',
  'em-progresso': '#22d3ee',
  resolvido: '#34d399',
  rejeitado: '#f87171',
  suspenso: '#fbbf24',
};

function EmptyState({ children }) {
  return <p className="py-10 text-center text-sm text-muted-foreground">{children}</p>;
}

export function ProjectMetrics({ items, statuses, loading }) {
  const grouped = useMemo(() => groupDashboardItems(items), [items]);
  const countsByProjectAndStatus = useMemo(
    () => new Map(grouped.projectStatuses.map(({ projeto, status, count }) => [`${projeto}\0${status}`, count])),
    [grouped],
  );
  const maxProjectCount = Math.max(1, ...grouped.projects.map(({ count }) => count));

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
      <Card className="stat-card-animate">
        <CardHeader>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">01 / Projetos</p>
          <CardTitle className="text-base">Itens por projeto</CardTitle>
          <CardDescription>Volume de trabalho em cada projeto.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? <div className="h-40 animate-pulse rounded-lg bg-muted" /> : grouped.projects.length === 0 ? (
            <EmptyState>Nenhum item para agrupar.</EmptyState>
          ) : (
            <ul className="space-y-4">
              {grouped.projects.map(({ projeto, count }) => (
                <li key={projeto}>
                  <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                    <span className="truncate font-medium text-foreground">{projeto}</span>
                    <span className="font-mono text-xs tabular-nums text-muted-foreground">{count}</span>
                  </div>
                  <div
                    aria-label={`${projeto}: ${count} itens`}
                    aria-valuemax={maxProjectCount}
                    aria-valuemin={0}
                    aria-valuenow={count}
                    className="h-1.5 overflow-hidden rounded-full bg-muted"
                    role="progressbar"
                  >
                    <div className="h-full rounded-full bg-primary transition-[width] duration-500" style={{ width: `${(count / maxProjectCount) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card className="stat-card-animate" style={{ animationDelay: '0.1s' }}>
        <CardHeader>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">02 / Fluxo</p>
          <CardTitle className="text-base">Projeto × status</CardTitle>
          <CardDescription>Mapa de calor dos status canônicos do Factory.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? <div className="h-40 animate-pulse rounded-lg bg-muted" /> : grouped.projects.length === 0 ? (
            <EmptyState>Nenhum item para agrupar.</EmptyState>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] border-separate border-spacing-1 text-xs">
                <thead>
                  <tr>
                    <th className="min-w-28 px-2 py-2 text-left font-medium text-muted-foreground">Projeto</th>
                    {statuses.map((status) => (
                      <th className="px-1 py-2 text-center font-mono font-medium text-muted-foreground" key={status}>{status}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {grouped.projects.map(({ projeto }) => (
                    <tr key={projeto}>
                      <th className="truncate px-2 py-2 text-left font-medium text-foreground">{projeto}</th>
                      {statuses.map((status) => {
                        const count = countsByProjectAndStatus.get(`${projeto}\0${status}`) || 0;
                        const color = STATUS_COLORS[status] || '#94a3b8';
                        return (
                          <td className="p-0.5 text-center" key={status}>
                            <span
                              aria-label={`${projeto}, ${status}: ${count} itens`}
                              className="block rounded-md px-2 py-2 font-mono tabular-nums"
                              style={{ backgroundColor: `${color}${count ? '30' : '0D'}`, color: count ? color : '#64748b' }}
                            >
                              {count || '·'}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="stat-card-animate xl:col-span-2" style={{ animationDelay: '0.2s' }}>
        <CardHeader>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-primary">03 / Componentes</p>
          <CardTitle className="text-base">Itens por projeto e componente</CardTitle>
          <CardDescription>Distribuição para localizar concentração e gargalos.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? <div className="h-40 animate-pulse rounded-lg bg-muted" /> : grouped.projectComponents.length === 0 ? (
            <EmptyState>Nenhum componente para agrupar.</EmptyState>
          ) : (
            <div className="max-h-80 overflow-auto rounded-lg border border-border">
              <table className="w-full min-w-[440px] text-sm">
                <thead className="sticky top-0 bg-card text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 text-left font-medium">Projeto</th>
                    <th className="px-4 py-3 text-left font-medium">Componente</th>
                    <th className="px-4 py-3 text-right font-medium">Itens</th>
                  </tr>
                </thead>
                <tbody>
                  {grouped.projectComponents.map(({ projeto, componente, count }) => (
                    <tr className="border-t border-border/70" key={`${projeto}\0${componente}`}>
                      <td className="px-4 py-3 font-medium text-foreground">{projeto}</td>
                      <td className="px-4 py-3 text-muted-foreground">{componente}</td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums text-primary">{count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
