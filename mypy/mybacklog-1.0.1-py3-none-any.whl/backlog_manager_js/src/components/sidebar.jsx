import { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, ListTodo, Activity, ChevronLeft, ChevronRight } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { api } from '@/lib/api';
const navItems = [{ to: '/', label: 'Dashboard', icon: LayoutDashboard }, { to: '/items', label: 'Backlog', icon: ListTodo }];
export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [health, setHealth] = useState(null);
  const location = useLocation();
  useEffect(() => { const check = async () => { try { setHealth(await api.health()); } catch { setHealth(null); } }; check(); const i = setInterval(check, 15000); return () => clearInterval(i); }, []);
  return (
    <aside className={cn('sidebar-glow flex flex-col border-r border-border transition-all duration-300 relative', collapsed ? 'w-16' : 'w-60')}>
      <div className="flex items-center gap-3 px-4 h-14 border-b border-border shrink-0">
        <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center shrink-0"><ListTodo className="h-4 w-4 text-primary-foreground" /></div>
        {!collapsed && <div className="overflow-hidden"><h1 className="text-sm font-bold tracking-tight text-foreground truncate">MyBacklogManager</h1></div>}
      </div>
      <nav className="flex-1 py-4 px-2 space-y-1">
        {navItems.map(({ to, label, icon: Icon }) => {
          const isActive = to === '/' ? location.pathname === '/' : location.pathname.startsWith(to);
          return (<NavLink key={to} to={to} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200', isActive ? 'bg-primary/10 text-primary border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-accent')} title={collapsed ? label : undefined}><Icon className="h-4 w-4 shrink-0" />{!collapsed && <span className="truncate">{label}</span>}</NavLink>);
        })}
      </nav>
      <div className="px-2 pb-2"><Separator className="mb-2" /><div className={cn('flex items-center gap-2 px-3 py-1.5 rounded-md text-xs', collapsed && 'justify-center px-0')}><Activity className={cn('h-3.5 w-3.5 shrink-0', health ? 'text-emerald-500' : 'text-destructive')} />{!collapsed && <span className={health ? 'text-emerald-500' : 'text-destructive'}>{health ? 'API Online' : 'API Offline'}</span>}</div></div>
      <button onClick={() => setCollapsed(!collapsed)} className="absolute -right-3 top-16 h-6 w-6 rounded-full border border-border bg-card flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors z-10">{collapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronLeft className="h-3 w-3" />}</button>
    </aside>);
}