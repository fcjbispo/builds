import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'items-spa-navigation',
      configureServer(server) {
        server.middlewares.use((request, _response, next) => {
          const requestUrl = request.url || '/';
          if (
            request.method === 'GET' &&
            requestUrl.split('?')[0] === '/items' &&
            request.headers.accept?.includes('text/html')
          ) {
            const query = requestUrl.indexOf('?');
            request.url = `/index.html${query === -1 ? '' : requestUrl.slice(query)}`;
          }
          next();
        });
      },
    },
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  optimizeDeps: {
    include: ['recharts'],
  },
  build: {
    commonjsOptions: {
      transformMixedEsModules: true,
    },
  },
  server: {
    port: 5173,
    proxy: {
      '/items': {
        target: 'http://localhost:8833',
        changeOrigin: true,
      },
      '/health': {
        target: 'http://localhost:8833',
        changeOrigin: true,
      },
    },
  },
});
