"""
CEI (Clube de Investimento) Data Provider for proventos/calendario de eventos.

This provider reads the xlsx file exported from CEI platform containing
dividends and interest on equity (JCP) data for Brazilian stocks and BDRs.
"""

import os
import json
from datetime import datetime
from typing import Dict, Any, Optional

import pandas as pd

from infobr import logger
from infobr.data import DataProvider
from infobr.data.tools import DataTools


class CeiProventosDataProvider(DataProvider):
    """
    Data provider for proventos (dividends/JCP) information from CEI xlsx file.

    This provider reads an Excel file exported from the CEI (Clube de Investimento)
    platform containing a calendar of corporate events for Brazilian stocks and BDRs.

    The provider transforms the xlsx data into a standard dividend schema with
    additional metadata in extra_info field.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - file_path: Full path to the xlsx file (required)
            - compute_frequency: Whether to compute payout frequency (default: True)
    """

    EXPECTED_PARAMS = {
        "file_path": (str, True, None),
        "compute_frequency": (bool, False, True),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve proventos data from the CEI xlsx file.

        Returns:
            DataFrame containing structured dividend data:
            {
                "Ticker": str,
                "Payout_Frequency": str,
                "Ex_Dividend_Date": date,
                "Cash_Amount": float,
                "Record_Date": date,
                "Pay_Date": date,
                "Reference_Date": datetime,
                "DY": float,
                "Extra_Info": dict (JSON string)
            }

        Raises:
            ValueError: If the file cannot be read or parsed
        """
        file_path = self.params["file_path"]
        compute_frequency = self.params.get("compute_frequency", True)

        logger.info(f"Reading CEI proventos data from {file_path}")

        if not os.path.exists(file_path):
            raise ValueError(f"File not found: {file_path}")

        try:
            # Read xlsx file using calamine engine (no openpyxl warnings)
            df = pd.read_excel(file_path, engine="calamine")
            logger.info(f"Read {len(df)} rows from {file_path}")

            # Transform to standard schema
            data = self._transform(df, compute_frequency=compute_frequency)

            logger.info(f"Transformed {len(data)} proventos records")
            return data

        except Exception as e:
            logger.error(f"Error reading CEI file {file_path}: {str(e)}")
            raise ValueError(f"Failed to read CEI file: {str(e)}")

    def _transform(
        self, data: pd.DataFrame, compute_frequency: bool = True
    ) -> pd.DataFrame:
        """
        Transform CEI xlsx data to standard dividend schema.

        Args:
            data: Raw DataFrame from xlsx
            compute_frequency: Whether to compute payout frequency

        Returns:
            DataFrame with standard dividend columns plus extra_info
        """
        # Rename columns to standard names
        column_map = {
            "Data Referência": "Reference_Date_Raw",
            "Produto": "Produto_Raw",
            "Tipo": "Tipo_Raw",
            "Tipo de Evento": "Tipo_Evento_Raw",
            "Data COM": "Ex_Dividend_Date_Raw",
            "Data de Pagamento": "Pay_Date_Raw",
            "Preço Unitário Bruto": "Cash_Amount_Raw",
            "Preço Fechamento": "Preco_Fechamento_Raw",
            "DY": "DY_Raw",
            "Url Fato Relevante": "Url_Fato_Relevante_Raw",
        }

        # Select and rename available columns
        available_columns = {k: v for k, v in column_map.items() if k in data.columns}
        result = data[list(available_columns.keys())].rename(columns=available_columns).copy()

        # Extract ticker from "Produto" column (format: "TICKER - Company Name")
        def extract_ticker(produto: str) -> str:
            if pd.isna(produto):
                return None
            produto_str = str(produto).strip()
            if " - " in produto_str:
                return produto_str.split(" - ")[0].strip()
            return produto_str.strip()

        result["Ticker"] = result["Produto_Raw"].apply(extract_ticker)

        # Parse dates (BR format: DD/MM/YYYY)
        result["Ex_Dividend_Date"] = result["Ex_Dividend_Date_Raw"].apply(
            lambda x: DataTools.br_string_to_date(str(x)) if pd.notna(x) and str(x) != "-" else None
        )
        result["Record_Date"] = result["Ex_Dividend_Date"]  # Same as Ex-Dividend Date

        result["Pay_Date"] = result["Pay_Date_Raw"].apply(
            lambda x: DataTools.br_string_to_date(str(x)) if pd.notna(x) and str(x) != "-" else None
        )

        # Parse reference date (Data Referência)
        result["Reference_Date"] = result["Reference_Date_Raw"].apply(
            lambda x: DataTools.br_string_to_date(str(x)) if pd.notna(x) else datetime.now().date()
        )
        # Convert to datetime for Reference_Date column
        result["Reference_Date"] = pd.to_datetime(result["Reference_Date"])

        # Parse cash amount (BR format: comma decimal)
        def parse_br_float(x):
            if pd.isna(x) or str(x) == "-":
                return None
            return DataTools.br_string_to_float(str(x))

        result["Cash_Amount"] = result["Cash_Amount_Raw"].apply(parse_br_float)

        # Parse DY (dividend yield percentage)
        result["DY"] = result["DY_Raw"].apply(
            lambda x: parse_br_float(str(x).replace("%", "").replace(",", ".")) if pd.notna(x) and str(x) not in ["-", ""] else None
        )

        # Parse closing price
        result["Preco_Fechamento"] = result["Preco_Fechamento_Raw"].apply(parse_br_float)

        # Build extra_info JSON
        def build_extra_info(row):
            extra = {
                "url_fato_relevante": str(row["Url_Fato_Relevante_Raw"]) if "Url_Fato_Relevante_Raw" in row.index and pd.notna(row["Url_Fato_Relevante_Raw"]) and str(row["Url_Fato_Relevante_Raw"]) != "-" else None,
                "preco_unitario_bruto": row["Cash_Amount"] if row["Cash_Amount"] is not None else None,
                "preco_fechamento": row["Preco_Fechamento"] if row["Preco_Fechamento"] is not None else None,
                "tipo_evento": str(row["Tipo_Evento_Raw"]) if "Tipo_Evento_Raw" in row.index and pd.notna(row["Tipo_Evento_Raw"]) else None,
            }
            # Remove None values
            return json.dumps({k: v for k, v in extra.items() if v is not None})

        result["Extra_Info"] = result.apply(build_extra_info, axis=1)

        # Compute frequency if requested
        if compute_frequency and len(result) > 0:
            pay_dates = result["Pay_Date"].dropna().tolist()
            if pay_dates:
                freq = DataTools.date_frequency(pay_dates)
                result["Payout_Frequency"] = freq
            else:
                result["Payout_Frequency"] = None
        else:
            result["Payout_Frequency"] = None

        # Select and order final columns
        final_columns = [
            "Ticker",
            "Payout_Frequency",
            "Ex_Dividend_Date",
            "Cash_Amount",
            "Record_Date",
            "Pay_Date",
            "Reference_Date",
            "DY",
            "Extra_Info",
        ]

        return result[final_columns].copy()
