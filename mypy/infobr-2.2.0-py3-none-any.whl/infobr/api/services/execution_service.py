"""Asynchronous pipeline execution service with DB-backed tracking."""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from infobr import logger
from infobr.api.db import session_scope
from infobr.api.models import Execution
from infobr.api.repositories import ExecutionRepository, PipelineRepository
from infobr.config import get_settings
from infobr.data.pipeline import Pipeline

_MAX_WORKERS = get_settings().pipeline_runners
_EXECUTOR = ThreadPoolExecutor(max_workers=max(1, _MAX_WORKERS), thread_name_prefix="infobr-runner")


@dataclass(frozen=True)
class ExecutionDispatchResult:
    """Result returned immediately when an execution is queued."""

    execution_id: str
    status: str


@dataclass
class ScopeConflictError(Exception):
    """Raised when a requested execution conflicts with scopes already in execution."""

    requested_scopes: tuple[str, ...]
    conflicting_scopes: tuple[str, ...]
    conflicting_execution_ids: tuple[str, ...]

    def __str__(self) -> str:
        scopes = ", ".join(self.conflicting_scopes)
        execs = ", ".join(self.conflicting_execution_ids)
        return f"Scope already running: {scopes} (active executions: {execs})"


class ExecutionService:
    """Submit and track asynchronous pipeline executions."""

    @staticmethod
    def _extract_scopes_from_config(config: dict[str, Any]) -> set[str]:
        raw_scopes = config.get("scopes")
        if not isinstance(raw_scopes, list):
            return set()
        return {str(s).strip() for s in raw_scopes if str(s).strip()}

    @staticmethod
    def _resolve_requested_scopes(pipeline_name: str, params: dict[str, Any]) -> set[str]:
        with session_scope() as session:
            repo = PipelineRepository(session)
            config = repo.get_config(pipeline_name)
        if not config:
            return set()
        explicit_scope = str(params.get("scope") or "").strip()
        if explicit_scope and explicit_scope.upper() != "ALL":
            return {explicit_scope}
        return ExecutionService._extract_scopes_from_config(config)

    @staticmethod
    def _safe_params(params_json: str | None) -> dict[str, Any]:
        if not params_json:
            return {}
        try:
            payload = json.loads(params_json)
        except Exception:
            return {}
        return payload if isinstance(payload, dict) else {}

    @staticmethod
    def _ensure_scope_is_available(
        *,
        repo: ExecutionRepository,
        pipeline_name: str,
        params: dict[str, Any],
    ) -> None:
        requested_scopes = ExecutionService._resolve_requested_scopes(pipeline_name, params)
        if not requested_scopes:
            return

        conflicting_scopes: set[str] = set()
        conflicting_executions: set[str] = set()
        for active in repo.list_active():
            active_params = ExecutionService._safe_params(active.params)
            active_scopes = ExecutionService._resolve_requested_scopes(active.pipeline_name, active_params)
            overlap = requested_scopes.intersection(active_scopes)
            if overlap:
                conflicting_scopes.update(overlap)
                conflicting_executions.add(active.id)

        if conflicting_scopes:
            raise ScopeConflictError(
                requested_scopes=tuple(sorted(requested_scopes)),
                conflicting_scopes=tuple(sorted(conflicting_scopes)),
                conflicting_execution_ids=tuple(sorted(conflicting_executions)),
            )

    @staticmethod
    def dispatch_execution(
        *,
        pipeline_name: str,
        requested_by: str | None = None,
        params: dict | None = None,
    ) -> ExecutionDispatchResult:
        params = params or {}

        with session_scope() as session:
            pipe_repo = PipelineRepository(session)
            config = pipe_repo.get_config(pipeline_name)
            if not config:
                raise ValueError(f"Pipeline '{pipeline_name}' not found in database")

            exec_repo = ExecutionRepository(session)
            ExecutionService._ensure_scope_is_available(
                repo=exec_repo,
                pipeline_name=pipeline_name,
                params=params,
            )
            execution = exec_repo.create(
                pipeline_name=pipeline_name,
                status="queued",
                requested_by=requested_by,
                params=params,
            )
            execution_id = execution.id

        _EXECUTOR.submit(ExecutionService._execute, execution_id, pipeline_name, params)
        return ExecutionDispatchResult(execution_id=execution_id, status="queued")

    @staticmethod
    def _execute(execution_id: str, pipeline_name: str, params: dict) -> None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            repo.update_status(execution_id, status="running", started_at=datetime.utcnow())

        try:
            with session_scope() as session:
                pipe_repo = PipelineRepository(session)
                config = pipe_repo.get_config(pipeline_name)

            pipeline = Pipeline(pipeline_name)
            pipeline.config = config
            output = pipeline.run_and_collect(
                parallelize=bool(params.get("parallelize", True)),
                progress=bool(params.get("progress", False)),
            )

            with session_scope() as session:
                repo = ExecutionRepository(session)
                repo.update_status(
                    execution_id,
                    status="success",
                    finished_at=datetime.utcnow(),
                    output=output,
                    error_message=None,
                )
        except Exception as exc:
            logger.error(f"Pipeline execution failed for execution_id={execution_id}: {exc}")
            with session_scope() as session:
                repo = ExecutionRepository(session)
                repo.update_status(
                    execution_id,
                    status="failed",
                    finished_at=datetime.utcnow(),
                    error_message=str(exc),
                )

    @staticmethod
    def get_execution(execution_id: str) -> Execution | None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            execution = repo.get_by_id(execution_id)
            if execution:
                session.expunge(execution)
            return execution

    @staticmethod
    def list_executions(
        *,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> list[Execution]:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            items = repo.list(
                offset=offset,
                limit=limit,
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )
            for item in items:
                session.expunge(item)
            return items

    @staticmethod
    def count_executions(
        *,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> int:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            return repo.count(
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )

    @staticmethod
    def get_execution_output(execution_id: str) -> list[dict[str, Any]] | None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            return repo.get_output(execution_id)