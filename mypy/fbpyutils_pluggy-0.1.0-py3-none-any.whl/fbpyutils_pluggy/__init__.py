"""
FBPyUtils-Pluggy - Pluggy.ai API SDK for Python.

A complete Python library for interacting with the Pluggy.ai Open Finance API.

Example:
    >>> from fbpyutils_pluggy import PluggyClient
    >>> client = PluggyClient(client_id="xxx", client_secret="yyy")
    >>> connectors = client.connectors.list()
    >>> print(connectors)
"""

import os
import fbpyutils

from dotenv import load_dotenv


_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "CRITICAL")

logger = fbpyutils.get_logger()
logger.configure_from_env(env)


# Exports
from .client import PluggyClient
from .auth import PluggyAuth
from .exceptions import (
    PluggyError,
    PluggyAuthError,
    PluggyNotFoundError,
    PluggyValidationError,
    PluggyRateLimitError,
    PluggyServerError,
)
from . import models
from . import resources


__version__ = "0.1.0"
__all__ = [
    "PluggyClient",
    "PluggyAuth",
    "PluggyError",
    "PluggyAuthError",
    "PluggyNotFoundError",
    "PluggyValidationError",
    "PluggyRateLimitError",
    "PluggyServerError",
    "models",
    "resources",
    "logger",
]