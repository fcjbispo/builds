"""
Item model for Pluggy API.
"""

from enum import Enum
from typing import Optional, Dict, Any
from pydantic import ConfigDict, Field
from .base import PluggyModel


class ItemStatus(str, Enum):
    """Status of an item connection."""
    
    UPDATING = "UPDATING"
    WAITING_USER_INPUT = "WAITING_USER_INPUT"
    LOGIN_ERROR = "LOGIN_ERROR"
    OUTDATED = "OUTDATED"
    UPDATED = "UPDATED"
    ERROR = "ERROR"


class Item(PluggyModel):
    """Represents a connection to a financial institution."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    # connector can be int (ID) or dict (full object) from API
    connector_id: Optional[int] = Field(default=None, alias="connectorId")
    connector: Optional[Dict[str, Any]] = None
    
    status: ItemStatus
    execution_status: Optional[str] = Field(default=None, alias="executionStatus")
    parameter: Optional[Dict[str, Any]] = None
    last_updated_at: Optional[str] = Field(default=None, alias="lastUpdatedAt")
    webhook_url: Optional[str] = Field(default=None, alias="webhookUrl")
    error: Optional[Dict[str, Any]] = None
    consent: Optional[Dict[str, Any]] = None
    
    def model_post_init(self, __context):
        """Extract connector_id from connector object if present."""
        if self.connector and not self.connector_id:
            if isinstance(self.connector, dict):
                self.connector_id = self.connector.get('id')