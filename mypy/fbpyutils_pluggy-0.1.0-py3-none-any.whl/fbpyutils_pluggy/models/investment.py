"""
Investment model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List
from datetime import datetime
from pydantic import ConfigDict, Field
from .base import PluggyModel


class InvestmentType(str, Enum):
    """Types of investments."""
    
    MUTUAL_FUND = "MUTUAL_FUND"
    EQUITY = "EQUITY"
    FIXED_INCOME = "FIXED_INCOME"
    CRYPTOCURRENCY = "CRYPTOCURRENCY"
    ETF = "ETF"
    COE = "COE"
    OPTION = "OPTION"


class Investment(PluggyModel):
    """Represents an investment holding."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    item_id: str = Field(alias="itemId")
    account_id: str = Field(alias="accountId")
    type: InvestmentType
    name: str
    code: Optional[str] = None
    number: Optional[str] = None
    balance: float
    currency_code: str = Field(alias="currencyCode")
    value: Optional[float] = None
    quantity: Optional[float] = None
    unit_price: Optional[float] = Field(default=None, alias="unitPrice")
    date: Optional[datetime] = None
    owner: Optional[str] = None
    tax_number: Optional[str] = Field(default=None, alias="taxNumber")
    broker: Optional[str] = None