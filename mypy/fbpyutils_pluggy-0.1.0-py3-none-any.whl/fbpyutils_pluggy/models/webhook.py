"""
Webhook model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List
from datetime import datetime
from pydantic import ConfigDict, Field
from .base import PluggyModel


class WebhookEventType(str, Enum):
    """Types of webhook events."""
    
    ITEM_CREATED = "ITEM_CREATED"
    ITEM_UPDATED = "ITEM_UPDATED"
    ITEM_ERROR = "ITEM_ERROR"
    ITEM_DELETED = "ITEM_DELETED"
    CONNECTOR_UPDATED = "CONNECTOR_UPDATED"


class Webhook(PluggyModel):
    """Represents a webhook configuration."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    url: str
    event_types: List[WebhookEventType] = Field(alias="eventTypes")
    created_at: Optional[datetime] = Field(default=None, alias="createdAt")
    updated_at: Optional[datetime] = Field(default=None, alias="updatedAt")