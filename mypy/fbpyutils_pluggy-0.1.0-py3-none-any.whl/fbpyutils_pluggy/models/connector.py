"""
Connector model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import ConfigDict, Field
from datetime import datetime
from .base import PluggyModel


class ConnectorType(str, Enum):
    """Types of connectors available in Pluggy."""
    
    PERSONAL_BANK = "PERSONAL_BANK"
    BUSINESS_BANK = "BUSINESS_BANK"
    INVESTMENT = "INVESTMENT"
    CREDIT_CARD = "CREDIT_CARD"
    PAYMENT_ACCOUNT = "PAYMENT_ACCOUNT"
    REWARDS_PROGRAM = "REWARDS_PROGRAM"
    PORTFOLIO = "PORTFOLIO"
    LOAN = "LOAN"
    INSURANCE = "INSURANCE"
    DIGITAL_ECONOMY = "DIGITAL_ECONOMY"  # Novo tipo encontrado


class Connector(PluggyModel):
    """Represents a financial institution connector."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    # Core fields
    name: str
    type: Optional[str] = None  # API pode retornar tipos não documentados
    has_mfa: bool = Field(alias="hasMFA")
    oauth: Optional[bool] = False  # Optional - some connectors don't have this field
    
    # Colors
    primary_color: Optional[str] = Field(default=None, alias="primaryColor")
    secondary_color: Optional[str] = Field(default=None, alias="secondaryColor")
    
    # URLs
    institution_url: Optional[str] = Field(default=None, alias="institutionUrl")
    image_url: Optional[str] = Field(default=None, alias="imageUrl")
    oauth_url: Optional[str] = Field(default=None, alias="oauthUrl")
    
    # Metadata
    country: str
    health: Optional[Dict[str, Any]] = None
    products: Optional[List[str]] = None
    credentials: Optional[List[Dict[str, Any]]] = None
    institutions: Optional[List[Dict[str, Any]]] = None
    
    # Timestamps
    created_at: Optional[datetime] = Field(default=None, alias="createdAt")
    updated_at: Optional[datetime] = Field(default=None, alias="updatedAt")
    
    # Flags
    is_sandbox: bool = Field(default=False, alias="isSandbox")
    is_open_finance: bool = Field(default=False, alias="isOpenFinance")
    
    # Features
    supports_payment_initiation: bool = Field(default=False, alias="supportsPaymentInitiation")
    supports_scheduled_payments: bool = Field(default=False, alias="supportsScheduledPayments")
    supports_smart_transfers: bool = Field(default=False, alias="supportsSmartTransfers")
    supports_boleto_management: bool = Field(default=False, alias="supportsBoletoManagement")
    supports_automatic_pix: bool = Field(default=False, alias="supportsAutomaticPix")