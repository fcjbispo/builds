"""
Base model for Pluggy API objects.
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator
from datetime import datetime
from typing import Optional, Union


class PluggyModel(BaseModel):
    """
    Base model for Pluggy API objects.
    
    Provides common fields and configuration for all models.
    """
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    id: Union[str, int]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    @field_validator('id', mode='before')
    @classmethod
    def validate_id(cls, v):
        """Convert id to string."""
        return str(v) if v is not None else v