"""
Identity model for Pluggy API.
"""

from typing import Optional, List, Dict, Any
from pydantic import ConfigDict, Field
from .base import PluggyModel


class Identity(PluggyModel):
    """Represents user identity information."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    item_id: str = Field(alias="itemId")
    full_name: Optional[str] = Field(default=None, alias="fullName")
    tax_number: Optional[str] = Field(default=None, alias="taxNumber")
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[Dict[str, Any]] = None
    company: Optional[Dict[str, Any]] = None
    documents: Optional[List[Dict[str, Any]]] = None