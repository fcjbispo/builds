"""
Account model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List
from pydantic import ConfigDict, Field
from .base import PluggyModel


class AccountType(str, Enum):
    """Types of accounts."""
    
    BANK = "BANK"
    CREDIT = "CREDIT"
    INVESTMENT = "INVESTMENT"


class AccountSubType(str, Enum):
    """Subtypes of accounts."""
    
    CHECKING = "CHECKING"
    SAVINGS = "SAVINGS"
    CREDIT_CARD = "CREDIT_CARD"
    INVESTMENT = "INVESTMENT"
    LOAN = "LOAN"
    OTHER = "OTHER"


class Account(PluggyModel):
    """Represents a financial account."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    item_id: str = Field(alias="itemId")
    type: AccountType
    subtype: Optional[str] = None  # API returns various values like CHECKING_ACCOUNT, etc.
    name: str
    balance: float
    currency_code: str = Field(alias="currencyCode")
    bank_account_number: Optional[str] = Field(default=None, alias="bankAccountNumber")
    iban: Optional[str] = None
    bic: Optional[str] = None
    routing_number: Optional[str] = Field(default=None, alias="routingNumber")
    agency: Optional[str] = None
    number: Optional[str] = None
    portfolio: Optional[str] = None