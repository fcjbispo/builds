"""
Transaction model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import ConfigDict, Field
from .base import PluggyModel


class TransactionType(str, Enum):
    """Types of transactions."""
    
    DEBIT = "DEBIT"
    CREDIT = "CREDIT"


class TransactionCategory(str, Enum):
    """Categories of transactions."""
    
    TRANSFER = "TRANSFER"
    SALARY = "SALARY"
    RENT = "RENT"
    LOAN = "LOAN"
    UTILITIES = "UTILITIES"
    TAXES = "TAXES"
    INSURANCE = "INSURANCE"
    HEALTHCARE = "HEALTHCARE"
    EDUCATION = "EDUCATION"
    FOOD = "FOOD"
    TRANSPORT = "TRANSPORT"
    TRAVEL = "TRAVEL"
    ENTERTAINMENT = "ENTERTAINMENT"
    SHOPPING = "SHOPPING"
    SERVICES = "SERVICES"
    INVESTMENTS = "INVESTMENTS"
    OTHER = "OTHER"


class Transaction(PluggyModel):
    """Represents a financial transaction."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    account_id: str = Field(alias="accountId")
    amount: float
    type: TransactionType
    name: str
    date: datetime
    category: Optional[str] = None
    category_id: Optional[str] = Field(default=None, alias="categoryId")
    payment_data: Optional[Dict[str, Any]] = Field(default=None, alias="paymentData")
    description: Optional[str] = None
    currency_code: Optional[str] = Field(default=None, alias="currencyCode")
    reference: Optional[str] = None
    merchant: Optional[Dict[str, Any]] = None