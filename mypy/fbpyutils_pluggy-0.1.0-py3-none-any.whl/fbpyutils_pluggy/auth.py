"""
Pluggy authentication module.
"""

import httpx
from typing import Optional
from .exceptions import PluggyAuthError
from . import logger


class PluggyAuth:
    """
    Handles authentication with Pluggy API.
    
    Manages API key retrieval and refresh token logic.
    """
    
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        api_key: Optional[str] = None,
        base_url: str = "https://api.pluggy.ai",
    ):
        """
        Initialize authentication handler.
        
        Args:
            client_id: Pluggy client ID
            client_secret: Pluggy client secret
            api_key: Optional initial API key
            base_url: Pluggy API base URL
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        
    def get_api_key(self) -> str:
        """
        Get a valid API key.
        
        Returns:
            Valid API key string
            
        Raises:
            PluggyAuthError: If authentication fails
        """
        if self.api_key:
            return self.api_key
            
        # Request new API key using client credentials
        logger.info("Requesting new API key from Pluggy...")
        try:
            response = httpx.post(
                f"{self.base_url}/auth",
                json={
                    "clientId": self.client_id,
                    "clientSecret": self.client_secret,
                },
                timeout=30.0,
            )
            
            if response.status_code == 401 or response.status_code == 403:
                logger.error("Authentication failed: invalid client credentials")
                raise PluggyAuthError("Invalid client credentials")
                
            response.raise_for_status()
            data = response.json()
            self.api_key = data.get("apiKey")
            
            if not self.api_key:
                logger.error("API key not found in response")
                raise PluggyAuthError("API key not found in response")
            
            logger.info("API key obtained successfully")
            return self.api_key
            
        except httpx.RequestError as e:
            logger.error(f"Failed to authenticate: {e}")
            raise PluggyAuthError(f"Failed to authenticate: {str(e)}")
            
    def refresh_api_key(self) -> str:
        """
        Refresh the API key.
        
        Returns:
            New API key string
            
        Raises:
            PluggyAuthError: If refresh fails
        """
        logger.info("Refreshing API key...")
        # Clear current API key to force refresh
        self.api_key = None
        return self.get_api_key()