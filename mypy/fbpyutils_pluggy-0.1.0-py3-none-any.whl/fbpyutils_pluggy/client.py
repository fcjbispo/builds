"""
Pluggy HTTP client with retry logic and error handling.
"""

import time
import httpx
from typing import Optional, Dict, Any, TYPE_CHECKING
from httpx import Limits
from .auth import PluggyAuth
from .exceptions import (
    PluggyAuthError,
    PluggyNotFoundError,
    PluggyValidationError,
    PluggyRateLimitError,
    PluggyServerError,
)
from . import logger

if TYPE_CHECKING:
    from .resources import (
        ConnectorsResource,
        ItemsResource,
        AccountsResource,
        TransactionsResource,
        IdentityResource,
        WebhooksResource,
    )


class PluggyClient:
    """
    HTTP client for interacting with Pluggy API.
    
    Provides methods for GET, POST, PATCH, DELETE requests with
    automatic retry logic and error handling.
    
    Example:
        ```python
        client = PluggyClient(
            client_id="your_client_id",
            client_secret="your_client_secret"
        )
        
        # List connectors
        connectors = client.connectors.list()
        
        # Create item
        item = client.items.create(
            connector_id=201,
            parameters={"cpf": "12345678901", "password": "secret"}
        )
        ```
    """
    
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        api_key: Optional[str] = None,
        base_url: str = "https://api.pluggy.ai",
        timeout: float = 30.0,
        max_retries: int = 3,
    ):
        """
        Initialize Pluggy client.
        
        Args:
            client_id: Pluggy client ID
            client_secret: Pluggy client secret
            api_key: Optional initial API key
            base_url: Pluggy API base URL
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        self.auth = PluggyAuth(client_id, client_secret, api_key, base_url)
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Initialize HTTP client with connection pooling
        self._http_client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "fbpyutils-pluggy/0.1.0",
            },
            timeout=self.timeout,
            limits=Limits(
                max_keepalive_connections=20,
                max_connections=100,
            ),
        )
        
        # Resource cache
        self._resources: Dict[str, Any] = {}
        
    def _get_headers(self) -> Dict[str, str]:
        """Get headers with current API key."""
        api_key = self.auth.get_api_key()
        return {"X-API-KEY": api_key}
        
    def _handle_error(self, response: httpx.Response) -> None:
        """Handle HTTP errors and raise appropriate exceptions."""
        if response.status_code == 401 or response.status_code == 403:
            raise PluggyAuthError(f"Authentication error: {response.text}")
        elif response.status_code == 404:
            raise PluggyNotFoundError(f"Resource not found: {response.text}")
        elif response.status_code == 422:
            raise PluggyValidationError(f"Validation error: {response.text}")
        elif response.status_code == 429:
            raise PluggyRateLimitError(f"Rate limit exceeded: {response.text}")
        elif 500 <= response.status_code < 600:
            raise PluggyServerError(f"Server error ({response.status_code}): {response.text}")
        else:
            response.raise_for_status()
            
    def _request_with_retry(self, method: str, url: str, **kwargs) -> httpx.Response:
        """
        Make HTTP request with exponential backoff retry logic.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
            
        Raises:
            PluggyError: For various error conditions
        """
        # Merge headers
        headers = self._get_headers()
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))
        kwargs["headers"] = headers
        
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                logger.debug(f"{method} {url} (attempt {attempt + 1})")
                response = self._http_client.request(method, url, **kwargs)
                
                if response.is_success:
                    logger.debug(f"{method} {url} -> {response.status_code}")
                    return response
                    
                # Handle rate limit with special retry logic
                if response.status_code == 429:
                    if attempt < self.max_retries:
                        delay = (2 ** (attempt + 1))  # 2s, 4s, 8s
                        logger.warning(f"Rate limited, waiting {delay}s before retry...")
                        time.sleep(delay)
                        continue
                    else:
                        self._handle_error(response)
                
                # Handle other error responses
                self._handle_error(response)
                
            except (PluggyAuthError, PluggyNotFoundError) as e:
                # These errors should not be retried
                logger.error(f"{method} {url} failed: {e}")
                raise e
                
            except Exception as e:
                last_exception = e
                logger.warning(f"{method} {url} attempt {attempt + 1} failed: {e}")
                
                # If this was the last attempt, raise the exception
                if attempt == self.max_retries:
                    logger.error(f"{method} {url} failed after {self.max_retries + 1} attempts")
                    raise e
                    
                # Exponential backoff delay
                delay = (2 ** attempt) * 0.5
                time.sleep(delay)
                
        # This should never be reached, but just in case
        raise last_exception
        
    def get(self, url: str, **kwargs) -> httpx.Response:
        """
        Make GET request.
        
        Args:
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
        """
        return self._request_with_retry("GET", url, **kwargs)
        
    def post(self, url: str, **kwargs) -> httpx.Response:
        """
        Make POST request.
        
        Args:
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
        """
        return self._request_with_retry("POST", url, **kwargs)
        
    def put(self, url: str, **kwargs) -> httpx.Response:
        """
        Make PUT request.
        
        Args:
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
        """
        return self._request_with_retry("PUT", url, **kwargs)
        
    def patch(self, url: str, **kwargs) -> httpx.Response:
        """
        Make PATCH request.
        
        Args:
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
        """
        return self._request_with_retry("PATCH", url, **kwargs)
        
    def delete(self, url: str, **kwargs) -> httpx.Response:
        """
        Make DELETE request.
        
        Args:
            url: Request URL
            **kwargs: Additional request arguments
            
        Returns:
            HTTP response object
        """
        return self._request_with_retry("DELETE", url, **kwargs)
        
    # Resource properties
    @property
    def connectors(self) -> "ConnectorsResource":
        """Connectors resource."""
        if "connectors" not in self._resources:
            from .resources import ConnectorsResource
            self._resources["connectors"] = ConnectorsResource(self)
        return self._resources["connectors"]
        
    @property
    def items(self) -> "ItemsResource":
        """Items resource."""
        if "items" not in self._resources:
            from .resources import ItemsResource
            self._resources["items"] = ItemsResource(self)
        return self._resources["items"]
        
    @property
    def accounts(self) -> "AccountsResource":
        """Accounts resource."""
        if "accounts" not in self._resources:
            from .resources import AccountsResource
            self._resources["accounts"] = AccountsResource(self)
        return self._resources["accounts"]
        
    @property
    def transactions(self) -> "TransactionsResource":
        """Transactions resource."""
        if "transactions" not in self._resources:
            from .resources import TransactionsResource
            self._resources["transactions"] = TransactionsResource(self)
        return self._resources["transactions"]
        
    @property
    def identity(self) -> "IdentityResource":
        """Identity resource."""
        if "identity" not in self._resources:
            from .resources import IdentityResource
            self._resources["identity"] = IdentityResource(self)
        return self._resources["identity"]
        
    @property
    def webhooks(self) -> "WebhooksResource":
        """Webhooks resource."""
        if "webhooks" not in self._resources:
            from .resources import WebhooksResource
            self._resources["webhooks"] = WebhooksResource(self)
        return self._resources["webhooks"]
        
    def close(self) -> None:
        """Close the HTTP client session."""
        self._http_client.close()
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        
    def __del__(self):
        """Cleanup on garbage collection."""
        try:
            self.close()
        except:
            pass