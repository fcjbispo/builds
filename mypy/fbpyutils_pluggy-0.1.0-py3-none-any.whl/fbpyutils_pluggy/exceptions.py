"""
Pluggy SDK exceptions hierarchy.
"""

class PluggyError(Exception):
    """Base exception for Pluggy SDK."""
    pass


class PluggyAuthError(PluggyError):
    """Authentication error (HTTP 401/403)."""
    pass


class PluggyNotFoundError(PluggyError):
    """Resource not found error (HTTP 404)."""
    pass


class PluggyValidationError(PluggyError):
    """Validation error (HTTP 422)."""
    pass


class PluggyRateLimitError(PluggyError):
    """Rate limit exceeded error (HTTP 429)."""
    pass


class PluggyServerError(PluggyError):
    """Server error (HTTP 5xx)."""
    pass