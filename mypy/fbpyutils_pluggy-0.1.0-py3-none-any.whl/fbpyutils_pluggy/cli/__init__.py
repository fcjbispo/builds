"""
CLI module for fbpyutils-pluggy.
"""

from .main import app


__all__ = ["app"]
