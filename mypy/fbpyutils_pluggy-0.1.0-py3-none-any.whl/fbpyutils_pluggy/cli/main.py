"""
Main Entry Point for the FBPyUtils-Pluggy CLI

A command-line interface for the Pluggy.ai Open Finance API.
"""

import typer
import os

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.exceptions import PluggyError
from fbpyutils_pluggy.cli.utils.error_handler import handle_error

# Import command groups
from fbpyutils_pluggy.cli.groups import (
    connectors_app,
    items_app,
    accounts_app,
    transactions_app,
    webhooks_app,
)


# Create Typer app
app = typer.Typer(
    name="fbpyutils-pluggy",
    help="A CLI client for the Pluggy.ai Open Finance API.",
    rich_markup_mode="rich",
)

# Add command groups
app.add_typer(connectors_app, name="connectors")
app.add_typer(items_app, name="items")
app.add_typer(accounts_app, name="accounts")
app.add_typer(transactions_app, name="transactions")
app.add_typer(webhooks_app, name="webhooks")


def version_callback(value: bool):
    """Display version and exit."""
    if value:
        typer.echo(f"fbpyutils-pluggy version 0.1.0")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """
    FBPyUtils-Pluggy CLI — Open Finance made easy.
    
    Required environment variables:
    - PLUGGY_CLIENT_ID: Your Pluggy client ID
    - PLUGGY_CLIENT_SECRET: Your Pluggy client secret
    
    Get your credentials at: https://dashboard.pluggy.ai
    """
    pass


@app.command(name="status")
def check_status():
    """
    Check API connection status.
    
    Examples:
        fbpyutils-pluggy status
    """
    import os
    
    # Try new env vars first, then fallback to old ones
    client_id = os.getenv("FBPY_PLUGGY_CLIENT_ID") or os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("FBPY_PLUGGY_CLIENT_SECRET") or os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        typer.echo("❌ Environment variables not set:", err=True)
        typer.echo("", err=True)
        typer.echo("Required (in order of priority):", err=True)
        typer.echo("  1. FBPY_PLUGGY_CLIENT_ID", err=True)
        typer.echo("  2. FBPY_PLUGGY_CLIENT_SECRET", err=True)
        typer.echo("", err=True)
        typer.echo("Or (legacy):", err=True)
        typer.echo("  • PLUGGY_CLIENT_ID", err=True)
        typer.echo("  • PLUGGY_CLIENT_SECRET", err=True)
        typer.echo("", err=True)
        typer.echo("💡 Get your credentials at: https://dashboard.pluggy.ai", err=True)
        raise typer.Exit(1)
    
    try:
        with PluggyClient(client_id=client_id, client_secret=client_secret) as client:
            # Try to list connectors to verify connection
            connectors = client.connectors.list()
            typer.echo(f"✅ Connected to Pluggy API!")
            typer.echo(f"   Available connectors: {len(connectors)}")
            
    except Exception as e:
        handle_error(e)


if __name__ == "__main__":
    try:
        app()
    except Exception as e:
        handle_error(e)
