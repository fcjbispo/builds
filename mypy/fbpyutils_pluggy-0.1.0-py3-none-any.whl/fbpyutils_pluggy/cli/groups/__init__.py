"""
Command groups for Pluggy CLI.
"""

from .connectors import app as connectors_app
from .items import app as items_app
from .accounts import app as accounts_app
from .transactions import app as transactions_app
from .webhooks import app as webhooks_app


__all__ = [
    "connectors_app",
    "items_app",
    "accounts_app",
    "transactions_app",
    "webhooks_app",
]
