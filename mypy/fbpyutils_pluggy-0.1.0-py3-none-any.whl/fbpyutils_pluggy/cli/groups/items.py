"""
Items commands for Pluggy CLI.

Commands for managing connections to financial institutions.
"""

import typer
from typing import Optional

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.models import ItemStatus
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat


app = typer.Typer(
    name="items",
    help="Commands for managing connections to financial institutions.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment."""
    import os
    
    client_id = os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "PLUGGY_CLIENT_ID and PLUGGY_CLIENT_SECRET must be set in environment"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


@app.command(name="list")
def list_items(
    connector_id: Optional[int] = typer.Option(
        None,
        "--connector",
        "-c",
        help="Filter by connector ID",
    ),
    status: Optional[str] = typer.Option(
        None,
        "--status",
        "-s",
        help=f"Filter by status ({', '.join([s.value for s in ItemStatus])})",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List all items (connections to financial institutions).
    
    Examples:
        fbpyutils-pluggy items list
        fbpyutils-pluggy items list --connector 201
        fbpyutils-pluggy items list --status UPDATED
    """
    try:
        with get_client() as client:
            items = client.items.list(
                connector_id=connector_id,
                status=status,
            )
            
            if not items:
                typer.echo("No items found.")
                return
            
            format_output(
                items,
                format=output,
                title="Items",
                columns=["id", "connector_id", "status", "execution_status", "last_updated_at"],
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="get")
def get_item(
    item_id: str = typer.Argument(..., help="Item ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Get details of a specific item.
    
    Examples:
        fbpyutils-pluggy items get item-123
    """
    try:
        with get_client() as client:
            item = client.items.get(item_id)
            
            format_output(
                item,
                format=output,
                title=f"Item: {item.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="create")
def create_item(
    connector_id: int = typer.Option(
        ...,
        "--connector",
        "-c",
        help="Connector ID",
        prompt="Connector ID",
    ),
    parameters: str = typer.Option(
        ...,
        "--parameters",
        "-p",
        help="JSON string with credentials (e.g., '{\"cpf\":\"123\",\"password\":\"secret\"}')",
        prompt="Parameters (JSON)",
    ),
    webhook_url: Optional[str] = typer.Option(
        None,
        "--webhook",
        "-w",
        help="Webhook URL for status updates",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Create a new item (connect to a financial institution).
    
    Examples:
        fbpyutils-pluggy items create --connector 201 --parameters '{"cpf":"123","password":"secret"}'
    """
    import json
    
    try:
        params = json.loads(parameters)
    except json.JSONDecodeError:
        typer.echo("❌ Invalid JSON in parameters", err=True)
        raise typer.Exit(1)
    
    try:
        with get_client() as client:
            item = client.items.create(
                connector_id=connector_id,
                parameters=params,
                webhook_url=webhook_url,
            )
            
            typer.echo(f"✅ Item created successfully!")
            format_output(
                item,
                format=output,
                title=f"New Item: {item.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="update")
def update_item(
    item_id: str = typer.Argument(..., help="Item ID"),
    parameters: Optional[str] = typer.Option(
        None,
        "--parameters",
        "-p",
        help="JSON string with updated parameters",
    ),
    webhook_url: Optional[str] = typer.Option(
        None,
        "--webhook",
        "-w",
        help="Updated webhook URL",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Update an existing item.
    
    Examples:
        fbpyutils-pluggy items update item-123 --parameters '{"password":"new"}'
    """
    import json
    
    params = None
    if parameters:
        try:
            params = json.loads(parameters)
        except json.JSONDecodeError:
            typer.echo("❌ Invalid JSON in parameters", err=True)
            raise typer.Exit(1)
    
    try:
        with get_client() as client:
            item = client.items.update(
                item_id=item_id,
                parameters=params,
                webhook_url=webhook_url,
            )
            
            typer.echo(f"✅ Item updated successfully!")
            format_output(
                item,
                format=output,
                title=f"Updated Item: {item.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="delete")
def delete_item(
    item_id: str = typer.Argument(..., help="Item ID"),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
):
    """
    Delete an item.
    
    Examples:
        fbpyutils-pluggy items delete item-123
        fbpyutils-pluggy items delete item-123 --force
    """
    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete item {item_id}?")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit()
    
    try:
        with get_client() as client:
            client.items.delete(item_id)
            typer.echo(f"✅ Item {item_id} deleted successfully!")
            
    except Exception as e:
        handle_error(e)


@app.command(name="mfa")
def send_mfa(
    item_id: str = typer.Argument(..., help="Item ID"),
    mfa_value: str = typer.Argument(..., help="MFA code"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Send MFA code for items waiting for user input.
    
    Examples:
        fbpyutils-pluggy items mfa item-123 123456
    """
    try:
        with get_client() as client:
            item = client.items.send_mfa(item_id, mfa_value)
            
            typer.echo(f"✅ MFA code sent!")
            format_output(
                item,
                format=output,
                title=f"Item: {item.id}",
            )
            
    except Exception as e:
        handle_error(e)