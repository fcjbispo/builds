"""
Webhooks commands for Pluggy CLI.

Commands for managing webhook configurations.
"""

import typer
from typing import List

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.models import WebhookEventType
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat


app = typer.Typer(
    name="webhooks",
    help="Commands for managing webhook configurations.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment."""
    import os
    
    client_id = os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "PLUGGY_CLIENT_ID and PLUGGY_CLIENT_SECRET must be set in environment"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


@app.command(name="list")
def list_webhooks(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List all webhooks.
    
    Examples:
        fbpyutils-pluggy webhooks list
    """
    try:
        with get_client() as client:
            webhooks = client.webhooks.list()
            
            if not webhooks:
                typer.echo("No webhooks found.")
                return
            
            format_output(
                webhooks,
                format=output,
                title="Webhooks",
                columns=["id", "url", "event_types"],
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="get")
def get_webhook(
    webhook_id: str = typer.Argument(..., help="Webhook ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Get details of a specific webhook.
    
    Examples:
        fbpyutils-pluggy webhooks get webhook-123
    """
    try:
        with get_client() as client:
            webhook = client.webhooks.get(webhook_id)
            
            format_output(
                webhook,
                format=output,
                title=f"Webhook: {webhook.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="create")
def create_webhook(
    url: str = typer.Option(
        ...,
        "--url",
        "-u",
        help="Webhook URL",
        prompt="Webhook URL",
    ),
    event_types: List[str] = typer.Option(
        ...,
        "--events",
        "-e",
        help=f"Event types to subscribe to ({', '.join([e.value for e in WebhookEventType])})",
        prompt="Event types (comma-separated)",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Create a new webhook.
    
    Examples:
        fbpyutils-pluggy webhooks create --url https://example.com/webhook --events ITEM_CREATED,ITEM_UPDATED
    """
    try:
        # Parse event types
        event_type_list = []
        for event_str in event_types:
            for et in event_str.split(","):
                et = et.strip()
                try:
                    event_type_list.append(WebhookEventType(et))
                except ValueError:
                    typer.echo(f"❌ Invalid event type: {et}", err=True)
                    raise typer.Exit(1)
        
        with get_client() as client:
            webhook = client.webhooks.create(
                url=url,
                event_types=event_type_list,
            )
            
            typer.echo(f"✅ Webhook created successfully!")
            format_output(
                webhook,
                format=output,
                title=f"New Webhook: {webhook.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="update")
def update_webhook(
    webhook_id: str = typer.Argument(..., help="Webhook ID"),
    url: str = typer.Option(
        None,
        "--url",
        "-u",
        help="New webhook URL",
    ),
    event_types: List[str] = typer.Option(
        None,
        "--events",
        "-e",
        help=f"New event types ({', '.join([e.value for e in WebhookEventType])})",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Update an existing webhook.
    
    Examples:
        fbpyutils-pluggy webhooks update webhook-123 --url https://new-url.com
    """
    try:
        # Parse event types if provided
        event_type_list = None
        if event_types:
            event_type_list = []
            for event_str in event_types:
                for et in event_str.split(","):
                    et = et.strip()
                    try:
                        event_type_list.append(WebhookEventType(et))
                    except ValueError:
                        typer.echo(f"❌ Invalid event type: {et}", err=True)
                        raise typer.Exit(1)
        
        with get_client() as client:
            webhook = client.webhooks.update(
                webhook_id=webhook_id,
                url=url,
                event_types=event_type_list,
            )
            
            typer.echo(f"✅ Webhook updated successfully!")
            format_output(
                webhook,
                format=output,
                title=f"Updated Webhook: {webhook.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="delete")
def delete_webhook(
    webhook_id: str = typer.Argument(..., help="Webhook ID"),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
):
    """
    Delete a webhook.
    
    Examples:
        fbpyutils-pluggy webhooks delete webhook-123
        fbpyutils-pluggy webhooks delete webhook-123 --force
    """
    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete webhook {webhook_id}?")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit()
    
    try:
        with get_client() as client:
            client.webhooks.delete(webhook_id)
            typer.echo(f"✅ Webhook {webhook_id} deleted successfully!")
            
    except Exception as e:
        handle_error(e)


@app.command(name="events")
def list_events(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List available webhook event types.
    
    Examples:
        fbpyutils-pluggy webhooks events
    """
    events = [
        {"event": e.value, "description": _get_event_description(e)}
        for e in WebhookEventType
    ]
    
    format_output(
        events,
        format=output,
        title="Webhook Event Types",
        columns=["event", "description"],
    )


def _get_event_description(event_type: WebhookEventType) -> str:
    """Get description for webhook event type."""
    descriptions = {
        WebhookEventType.ITEM_CREATED: "Item was created",
        WebhookEventType.ITEM_UPDATED: "Item was updated",
        WebhookEventType.ITEM_ERROR: "Item encountered an error",
        WebhookEventType.ITEM_DELETED: "Item was deleted",
        WebhookEventType.CONNECTOR_UPDATED: "Connector was updated",
    }
    return descriptions.get(event_type, "Unknown")
