"""
Transactions commands for Pluggy CLI.

Commands for managing financial transactions.
"""

import typer
from typing import Optional

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat


app = typer.Typer(
    name="transactions",
    help="Commands for managing financial transactions.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment."""
    import os
    
    client_id = os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "PLUGGY_CLIENT_ID and PLUGGY_CLIENT_SECRET must be set in environment"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


@app.command(name="list")
def list_transactions(
    account_id: str = typer.Option(
        ...,
        "--account",
        "-a",
        help="Account ID",
        prompt="Account ID",
    ),
    from_date: Optional[str] = typer.Option(
        None,
        "--from",
        "-f",
        help="Start date (YYYY-MM-DD)",
    ),
    to_date: Optional[str] = typer.Option(
        None,
        "--to",
        "-t",
        help="End date (YYYY-MM-DD)",
    ),
    limit: int = typer.Option(
        50,
        "--limit",
        "-l",
        help="Maximum number of transactions to display",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List transactions for an account.
    
    Examples:
        fbpyutils-pluggy transactions list --account account-123
        fbpyutils-pluggy transactions list --account account-123 --from 2024-01-01 --to 2024-12-31
    """
    try:
        with get_client() as client:
            transactions = client.transactions.list(
                account_id=account_id,
                from_date=from_date,
                to_date=to_date,
            )
            
            if not transactions:
                typer.echo("No transactions found.")
                return
            
            # Apply limit
            transactions = transactions[:limit]
            
            format_output(
                transactions,
                format=output,
                title=f"Transactions for Account {account_id}",
                columns=["id", "date", "name", "amount", "type", "category"],
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="get")
def get_transaction(
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Get details of a specific transaction.
    
    Examples:
        fbpyutils-pluggy transactions get tx-123
    """
    try:
        with get_client() as client:
            transaction = client.transactions.get(transaction_id)
            
            format_output(
                transaction,
                format=output,
                title=f"Transaction: {transaction.id}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="categorize")
def update_category(
    transaction_id: str = typer.Argument(..., help="Transaction ID"),
    category_id: str = typer.Argument(..., help="Category ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Update transaction category.
    
    Examples:
        fbpyutils-pluggy transactions categorize tx-123 category-456
    """
    try:
        with get_client() as client:
            transaction = client.transactions.update_category(
                transaction_id=transaction_id,
                category_id=category_id,
            )
            
            typer.echo(f"✅ Category updated!")
            format_output(
                transaction,
                format=output,
                title=f"Transaction: {transaction.id}",
            )
            
    except Exception as e:
        handle_error(e)