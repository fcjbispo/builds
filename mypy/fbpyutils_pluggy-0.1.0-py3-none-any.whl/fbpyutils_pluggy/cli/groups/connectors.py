"""
Connectors commands for Pluggy CLI.

Commands for listing and managing financial institution connectors.
"""

import typer
from typing import Optional, List

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.models import ConnectorType
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat


app = typer.Typer(
    name="connectors",
    help="Commands for managing financial institution connectors.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment.
    
    Priority:
    1. FBPY_PLUGGY_CLIENT_ID / FBPY_PLUGGY_CLIENT_SECRET
    2. PLUGGY_CLIENT_ID / PLUGGY_CLIENT_SECRET (fallback)
    """
    import os
    
    # Try new env vars first, then fallback to old ones
    client_id = os.getenv("FBPY_PLUGGY_CLIENT_ID") or os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("FBPY_PLUGGY_CLIENT_SECRET") or os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "Environment variables not set.\n\n"
            "Please set:\n"
            "  FBPY_PLUGGY_CLIENT_ID (or PLUGGY_CLIENT_ID)\n"
            "  FBPY_PLUGGY_CLIENT_SECRET (or PLUGGY_CLIENT_SECRET)\n\n"
            "Get your credentials at: https://dashboard.pluggy.ai"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


@app.command(name="list")
def list_connectors(
    connector_type: Optional[str] = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by connector type (e.g., PERSONAL_BANK)",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List all available connectors.
    
    Examples:
        fbpyutils-pluggy connectors list
        fbpyutils-pluggy connectors list --type PERSONAL_BANK
        fbpyutils-pluggy connectors list --output json
    """
    try:
        with get_client() as client:
            connectors = client.connectors.list(connector_type=connector_type)
            
            if not connectors:
                typer.echo("No connectors found.")
                return
            
            format_output(
                connectors,
                format=output,
                title="Available Connectors",
                columns=["id", "name", "connector_type", "has_mfa", "oauth"],
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="get")
def get_connector(
    connector_id: int = typer.Argument(..., help="Connector ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Get details of a specific connector.
    
    Examples:
        fbpyutils-pluggy connectors get 201
        fbpyutils-pluggy connectors get 201 --output json
    """
    try:
        with get_client() as client:
            connector = client.connectors.get(connector_id)
            
            format_output(
                connector,
                format=output,
                title=f"Connector: {connector.name}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="validate")
def validate_connector(
    connector_id: int = typer.Argument(..., help="Connector ID"),
    parameters: str = typer.Option(
        ...,
        "--parameters",
        "-p",
        help="JSON string with parameters (e.g., '{\"cpf\":\"123\",\"password\":\"secret\"}')",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Validate connector parameters without creating an item.
    
    Examples:
        fbpyutils-pluggy connectors validate 201 --parameters '{"cpf":"123","password":"test"}'
    """
    import json
    
    try:
        params = json.loads(parameters)
    except json.JSONDecodeError:
        typer.echo("❌ Invalid JSON in parameters", err=True)
        raise typer.Exit(1)
    
    try:
        with get_client() as client:
            result = client.connectors.validate(connector_id, params)
            
            format_output(
                result,
                format=output,
                title="Validation Result",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="types")
def list_types(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List available connector types.
    
    Examples:
        fbpyutils-pluggy connectors types
    """
    types = [
        {"type": t.value, "description": _get_type_description(t)}
        for t in ConnectorType
    ]
    
    format_output(
        types,
        format=output,
        title="Connector Types",
        columns=["type", "description"],
    )


def _get_type_description(connector_type: ConnectorType) -> str:
    """Get description for connector type."""
    descriptions = {
        ConnectorType.PERSONAL_BANK: "Personal banking institutions",
        ConnectorType.BUSINESS_BANK: "Business banking institutions",
        ConnectorType.INVESTMENT: "Investment platforms",
        ConnectorType.CREDIT_CARD: "Credit card providers",
        ConnectorType.PAYMENT_ACCOUNT: "Payment accounts",
        ConnectorType.REWARDS_PROGRAM: "Rewards and loyalty programs",
        ConnectorType.PORTFOLIO: "Portfolio managers",
        ConnectorType.LOAN: "Loan providers",
        ConnectorType.INSURANCE: "Insurance companies",
    }
    return descriptions.get(connector_type, "Unknown")