"""
Output formatting utilities for CLI.
"""

import json
from enum import Enum
from typing import Any, List

import typer
from rich.console import Console
from rich.table import Table
from pydantic import BaseModel


class OutputFormat(str, Enum):
    """Supported output formats."""
    
    TABLE = "table"
    JSON = "json"
    CSV = "csv"


def format_output(
    data: Any,
    format: OutputFormat = OutputFormat.TABLE,
    title: str = "",
    columns: List[str] = None,
) -> None:
    """
    Format and print data in various formats.
    
    Args:
        data: Data to format (list of dicts, Pydantic models, or single object)
        format: Output format (table, json, csv)
        title: Optional title for table output
        columns: Optional list of column names for table
    """
    if format == OutputFormat.JSON:
        _format_json(data)
    elif format == OutputFormat.CSV:
        _format_csv(data, columns)
    else:
        _format_table(data, title, columns)


def _format_json(data: Any) -> None:
    """Format data as JSON."""
    if isinstance(data, list):
        # Convert Pydantic models to dicts
        if data and isinstance(data[0], BaseModel):
            data = [item.model_dump(by_alias=True) for item in data]
        typer.echo(json.dumps(data, indent=2, default=str))
    elif isinstance(data, BaseModel):
        typer.echo(json.dumps(data.model_dump(by_alias=True), indent=2, default=str))
    else:
        typer.echo(json.dumps(data, indent=2, default=str))


def _format_csv(data: Any, columns: List[str] = None) -> None:
    """Format data as CSV."""
    import csv
    import io
    
    if not isinstance(data, list):
        data = [data]
    
    if not data:
        typer.echo("No data to display")
        return
    
    # Convert to dicts if needed
    if isinstance(data[0], BaseModel):
        data = [item.model_dump(by_alias=True) for item in data]
    
    # Get columns from first item if not provided
    if not columns and data:
        columns = list(data[0].keys())
    
    # Write CSV
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns)
    writer.writeheader()
    writer.writerows(data)
    
    typer.echo(output.getvalue())


def _format_table(data: Any, title: str = "", columns: List[str] = None) -> None:
    """Format data as a rich table."""
    console = Console()
    
    if not isinstance(data, list):
        data = [data]
    
    if not data:
        typer.echo("No data to display")
        return
    
    # Convert to dicts if needed
    if isinstance(data[0], BaseModel):
        data = [item.model_dump(by_alias=True) for item in data]
    
    # Get columns from first item if not provided
    if not columns and data:
        columns = list(data[0].keys())
    
    # Create table
    table = Table(title=title, show_header=True, header_style="bold magenta")
    
    for col in columns:
        table.add_column(col.replace("_", " ").title())
    
    for item in data:
        row = [str(item.get(col, "")) for col in columns]
        table.add_row(*row)
    
    console.print(table)