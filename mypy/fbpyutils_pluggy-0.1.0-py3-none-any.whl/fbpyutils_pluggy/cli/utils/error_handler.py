"""
Error handling utilities for CLI.
"""

import sys
import typer
from typing import Optional

from ...exceptions import (
    PluggyError,
    PluggyAuthError,
    PluggyNotFoundError,
    PluggyValidationError,
    PluggyRateLimitError,
    PluggyServerError,
)


def handle_error(error: Exception, message: Optional[str] = None) -> None:
    """
    Handle errors with appropriate user-friendly messages.
    
    Args:
        error: The exception that occurred
        message: Optional custom message to display
    """
    if isinstance(error, PluggyAuthError):
        typer.echo(f"❌ Authentication error: {error}", err=True)
        typer.echo("💡 Check your PLUGGY_CLIENT_ID and PLUGGY_CLIENT_SECRET", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyNotFoundError):
        typer.echo(f"❌ Not found: {error}", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyValidationError):
        typer.echo(f"❌ Validation error: {error}", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyRateLimitError):
        typer.echo(f"⏳ Rate limit exceeded. Please wait before retrying.", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyServerError):
        typer.echo(f"🔥 Server error: {error}", err=True)
        typer.echo("💡 This is a temporary issue. Please try again later.", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyError):
        typer.echo(f"❌ Pluggy error: {error}", err=True)
        sys.exit(1)
        
    else:
        # Generic error
        error_msg = message or str(error)
        typer.echo(f"❌ Error: {error_msg}", err=True)
        sys.exit(1)