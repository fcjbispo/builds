"""
Accounts resource for Pluggy API.
"""

from typing import List, Optional
from ..models.account import Account
from .base import BaseResource


class AccountsResource(BaseResource):
    """Resource for interacting with accounts."""
    
    def list(
        self,
        item_id: str,
        type: Optional[str] = None,
    ) -> List[Account]:
        """
        List all accounts for an item.
        
        Args:
            item_id: Item ID
            type: Optional account type filter
            
        Returns:
            List of Account objects
        """
        params = {"itemId": item_id}
        if type:
            params["type"] = type
            
        response = self._client.get("/accounts", params=params)
        data = response.json()
        return [Account(**account) for account in data.get("results", [])]
        
    def get(self, account_id: str) -> Account:
        """
        Get a specific account by ID.
        
        Args:
            account_id: Account ID
            
        Returns:
            Account object
        """
        response = self._client.get(f"/accounts/{account_id}")
        data = response.json()
        return Account(**data)
        
    def get_balance(self, account_id: str) -> dict:
        """
        Get real-time balance for an account.
        
        Args:
            account_id: Account ID
            
        Returns:
            Balance data with 'balance' and 'currencyCode'
        """
        response = self._client.get(f"/accounts/{account_id}/balance")
        return response.json()