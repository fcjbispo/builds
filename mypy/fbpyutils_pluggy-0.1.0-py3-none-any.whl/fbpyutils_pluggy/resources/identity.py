"""
Identity resource for Pluggy API.
"""

from typing import Optional
from ..models.identity import Identity
from .base import BaseResource


class IdentityResource(BaseResource):
    """Resource for interacting with identity data."""
    
    def get_by_item(self, item_id: str) -> Optional[Identity]:
        """
        Get identity information for an item.
        
        Args:
            item_id: Item ID
            
        Returns:
            Identity object or None if not available
        """
        response = self._client.get("/identity", params={"itemId": item_id})
        data = response.json()
        
        # Identity might not be available for all items
        if not data or not data.get("id"):
            return None
            
        return Identity(**data)
        
    def get(self, identity_id: str) -> Identity:
        """
        Get identity by ID.
        
        Args:
            identity_id: Identity ID
            
        Returns:
            Identity object
        """
        response = self._client.get(f"/identity/{identity_id}")
        data = response.json()
        return Identity(**data)