"""
Connectors resource for Pluggy API.
"""

from typing import List, Optional, Dict, Any
from ..models.connector import Connector
from .base import BaseResource


class ConnectorsResource(BaseResource):
    """Resource for interacting with connectors."""
    
    def list(self, connector_type: Optional[str] = None) -> List[Connector]:
        """
        List all available connectors.
        
        Args:
            connector_type: Optional connector type filter
            
        Returns:
            List of Connector objects
        """
        params = {}
        if connector_type:
            params["type"] = connector_type
            
        response = self._client.get("/connectors", params=params)
        data = response.json()
        return [Connector(**connector) for connector in data.get("results", [])]
        
    def get(self, connector_id: int) -> Connector:
        """
        Get a specific connector by ID.
        
        Args:
            connector_id: Connector ID
            
        Returns:
            Connector object
        """
        response = self._client.get(f"/connectors/{connector_id}")
        data = response.json()
        return Connector(**data)
        
    def validate(self, connector_id: int, parameters: dict) -> dict:
        """
        Validate connector parameters.
        
        Args:
            connector_id: Connector ID
            parameters: Parameters to validate
            
        Returns:
            Validation result
        """
        response = self._client.post(
            f"/connectors/{connector_id}/validate",
            json=parameters
        )
        return response.json()