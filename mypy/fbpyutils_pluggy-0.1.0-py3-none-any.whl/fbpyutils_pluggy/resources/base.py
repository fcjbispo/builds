"""
Base resource class for Pluggy API resources.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import PluggyClient


class BaseResource:
    """
    Base class for all Pluggy API resources.
    
    Provides common functionality for interacting with the API.
    """
    
    def __init__(self, client: "PluggyClient"):
        """
        Initialize base resource.
        
        Args:
            client: PluggyClient instance
        """
        self._client = client