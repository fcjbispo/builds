"""
Transactions resource for Pluggy API.
"""

from typing import List, Optional
from datetime import date
from ..models.transaction import Transaction
from .base import BaseResource


class TransactionsResource(BaseResource):
    """Resource for interacting with transactions."""
    
    def list(
        self,
        account_id: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> List[Transaction]:
        """
        List all transactions for an account.
        
        Args:
            account_id: Account ID
            from_date: Optional start date (YYYY-MM-DD)
            to_date: Optional end date (YYYY-MM-DD)
            
        Returns:
            List of Transaction objects
        """
        params = {"accountId": account_id}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date
            
        response = self._client.get("/transactions", params=params)
        data = response.json()
        return [Transaction(**transaction) for transaction in data.get("results", [])]
        
    def get(self, transaction_id: str) -> Transaction:
        """
        Get a specific transaction by ID.
        
        Args:
            transaction_id: Transaction ID
            
        Returns:
            Transaction object
        """
        response = self._client.get(f"/transactions/{transaction_id}")
        data = response.json()
        return Transaction(**data)
        
    def update_category(
        self,
        transaction_id: str,
        category_id: str,
    ) -> Transaction:
        """
        Update transaction category.
        
        Args:
            transaction_id: Transaction ID
            category_id: New category ID
            
        Returns:
            Updated Transaction object
        """
        response = self._client.patch(
            f"/transactions/{transaction_id}",
            json={"categoryId": category_id}
        )
        data = response.json()
        return Transaction(**data)