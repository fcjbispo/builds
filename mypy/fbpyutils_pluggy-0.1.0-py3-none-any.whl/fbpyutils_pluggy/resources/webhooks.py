"""
Webhooks resource for Pluggy API.
"""

from typing import List, Optional
from ..models.webhook import Webhook, WebhookEventType
from .base import BaseResource


class WebhooksResource(BaseResource):
    """Resource for interacting with webhooks."""
    
    def list(self) -> List[Webhook]:
        """
        List all webhooks.
        
        Returns:
            List of Webhook objects
        """
        response = self._client.get("/webhooks")
        data = response.json()
        return [Webhook(**webhook) for webhook in data.get("results", [])]
        
    def get(self, webhook_id: str) -> Webhook:
        """
        Get a specific webhook by ID.
        
        Args:
            webhook_id: Webhook ID
            
        Returns:
            Webhook object
        """
        response = self._client.get(f"/webhooks/{webhook_id}")
        data = response.json()
        return Webhook(**data)
        
    def create(
        self,
        url: str,
        event_types: List[WebhookEventType],
    ) -> Webhook:
        """
        Create a new webhook.
        
        Args:
            url: Webhook URL
            event_types: List of event types to subscribe
            
        Returns:
            Created Webhook object
        """
        payload = {
            "url": url,
            "eventTypes": [event.value for event in event_types],
        }
        
        response = self._client.post("/webhooks", json=payload)
        data = response.json()
        return Webhook(**data)
        
    def update(
        self,
        webhook_id: str,
        url: Optional[str] = None,
        event_types: Optional[List[WebhookEventType]] = None,
    ) -> Webhook:
        """
        Update an existing webhook.
        
        Args:
            webhook_id: Webhook ID
            url: Optional new URL
            event_types: Optional new event types
            
        Returns:
            Updated Webhook object
        """
        payload = {}
        if url:
            payload["url"] = url
        if event_types:
            payload["eventTypes"] = [event.value for event in event_types]
            
        response = self._client.patch(f"/webhooks/{webhook_id}", json=payload)
        data = response.json()
        return Webhook(**data)
        
    def delete(self, webhook_id: str) -> None:
        """
        Delete a webhook.
        
        Args:
            webhook_id: Webhook ID
        """
        self._client.delete(f"/webhooks/{webhook_id}")