"""
Items resource for Pluggy API.
"""

from typing import List, Optional, Dict, Any
from ..models.item import Item, ItemStatus
from .base import BaseResource


class ItemsResource(BaseResource):
    """Resource for interacting with items."""
    
    def list(
        self,
        connector_id: Optional[int] = None,
        status: Optional[str] = None,
    ) -> List[Item]:
        """
        List all items.
        
        Args:
            connector_id: Optional connector ID filter
            status: Optional status filter
            
        Returns:
            List of Item objects
        """
        params = {}
        if connector_id:
            params["connectorId"] = connector_id
        if status:
            params["status"] = status
            
        response = self._client.get("/items", params=params)
        data = response.json()
        return [Item(**item) for item in data.get("results", [])]
        
    def get(self, item_id: str) -> Item:
        """
        Get a specific item by ID.
        
        Args:
            item_id: Item ID
            
        Returns:
            Item object
        """
        response = self._client.get(f"/items/{item_id}")
        data = response.json()
        return Item(**data)
        
    def create(
        self,
        connector_id: int,
        parameters: Dict[str, Any],
        webhook_url: Optional[str] = None,
    ) -> Item:
        """
        Create a new item (connect to a connector).
        
        Args:
            connector_id: Connector ID
            parameters: Connection parameters (credentials)
            webhook_url: Optional webhook URL
            
        Returns:
            Created Item object
        """
        payload = {
            "connectorId": connector_id,
            "parameters": parameters,
        }
        if webhook_url:
            payload["webhookUrl"] = webhook_url
            
        response = self._client.post("/items", json=payload)
        data = response.json()
        return Item(**data)
        
    def update(
        self,
        item_id: str,
        parameters: Optional[Dict[str, Any]] = None,
        webhook_url: Optional[str] = None,
    ) -> Item:
        """
        Update an existing item.
        
        Args:
            item_id: Item ID
            parameters: Optional new parameters
            webhook_url: Optional new webhook URL
            
        Returns:
            Updated Item object
        """
        payload = {}
        if parameters:
            payload["parameters"] = parameters
        if webhook_url:
            payload["webhookUrl"] = webhook_url
            
        response = self._client.patch(f"/items/{item_id}", json=payload)
        data = response.json()
        return Item(**data)
        
    def delete(self, item_id: str) -> None:
        """
        Delete an item.
        
        Args:
            item_id: Item ID
        """
        self._client.delete(f"/items/{item_id}")
        
    def send_mfa(self, item_id: str, mfa_value: str) -> Item:
        """
        Send MFA code for an item waiting for user input.
        
        Args:
            item_id: Item ID
            mfa_value: MFA code value
            
        Returns:
            Updated Item object
        """
        response = self._client.post(
            f"/items/{item_id}/mfa",
            json={"mfaValue": mfa_value}
        )
        data = response.json()
        return Item(**data)