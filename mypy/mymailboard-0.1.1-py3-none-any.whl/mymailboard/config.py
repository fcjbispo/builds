"""config.py — configuração efetiva do MyMailBoard.

REGRA DE PRECEDÊNCIA (definida pelo P.O. em 2026-10-13):

    1. **Banco** (schema `mymailboard`, tabela `config`) — MANDANTE. Se houver
       valor persistido, ele vence sempre (sobrevive a restart/recriação do
       container e a mudanças no `.env`).
    2. **Ambiente/.env** — usado apenas como *seed* inicial (primeira execução,
       quando a chave ainda não existe no banco).
    3. **DEFAULTS** do código — apenas fallback de último recurso.

Credenciais sensíveis (banco, Google client secret) vêm SEMPRE do ambiente —
nunca do banco, nunca hardcoded (regra FBNet: sem credencial default no código).
"""
from __future__ import annotations

import json
import os

SCHEMA = "mymailboard"
TABLE = "config"

# ── chaves de configuração editáveis na página "Config" do web app ──────────
DEFAULTS: dict[str, str] = {
    # motores LLM (por etapa do motor)
    "llm.provider": "ollama",  # ollama | openai | gateway
    "llm.base_url": "http://host.docker.internal:11434/v1",
    "llm.api_key": "",  # vazio = sem auth (Ollama local)
    "llm.classify.model": "gemma4:31b-cloud",
    "llm.infer.model": "gemma4:31b-cloud",
    "llm.embed.model": "nomic-embed-text:latest",
    "llm.temperature": "0.1",
    "llm.timeout_s": "90",
    # motor
    "engine.window_end": "2026-09-30",
    "engine.threads": "4",
    "engine.batch_limit": "100",
    "engine.body_chars_infer": "2200",
    "engine.body_chars_embed": "6000",
    # Google / OAuth
    "google.oauth_redirect": "http://localhost",
    "google.token_file": "credentials/google_token.json",
    "google.max_messages": "100000",
    # privacidade
    "privacy.mask_secrets": "true",
}

# chave de config  ->  variável de ambiente (fonte do seed inicial)
ENV_MAP: dict[str, str] = {
    "llm.provider": "LLM_PROVIDER",
    "llm.base_url": "OLLAMA_BASE",
    "llm.api_key": "LLM_API_KEY",
    "llm.classify.model": "LLM_CLASS_MODEL",
    "llm.infer.model": "LLM_INFER_MODEL",
    "llm.embed.model": "LLM_EMBED_MODEL",
    "engine.window_end": "WINDOW_END",
    "engine.threads": "THREADS",
    "engine.batch_limit": "BATCH_LIMIT",
    "google.oauth_redirect": "OAUTH_REDIRECT",
    "google.token_file": "GMAIL_TOKEN",
}

# grupos exibidos na página Config (rótulo amigável + ajuda)
GROUPS: list[dict] = [
    {
        "title": "Motor LLM — Classificação",
        "help": "Estágio que rotula cada e-mail em PENDENTE | AVALIAR | LIXO | IMPORTANTE.",
        "keys": ["llm.classify.model", "llm.provider", "llm.base_url", "llm.api_key", "llm.temperature"],
    },
    {
        "title": "Motor LLM — Inferência",
        "help": "Estágio que extrai resumo, urgência, ação necessária, categoria e palavras-chave.",
        "keys": ["llm.infer.model", "engine.body_chars_infer"],
    },
    {
        "title": "Motor LLM — Embeddings",
        "help": "Modelo de embedding para busca semântica (email/resumo/corpo).",
        "keys": ["llm.embed.model", "engine.body_chars_embed"],
    },
    {
        "title": "Motor de sincronização",
        "help": "Janela de corte, paralelismo e tamanho de lote das operações.",
        "keys": ["engine.window_end", "engine.threads", "engine.batch_limit"],
    },
    {
        "title": "Google / OAuth",
        "help": "Re-autenticação e local do token (o client secret vem do ambiente).",
        "keys": ["google.oauth_redirect", "google.token_file"],
    },
]

SECRET_KEYS = {"llm.api_key"}


def load_dotenv(path: str = ".env") -> None:
    """Carrega KEY=VALUE de um .env simples (sem dependências). Não sobrescreve
    variáveis já presentes no ambiente."""
    if not os.path.exists(path):
        return
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip("\"'"))


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def env_seed() -> dict[str, str]:
    """Valores iniciais vindos do ambiente/.env (só o que está preenchido)."""
    out: dict[str, str] = {}
    for key, var in ENV_MAP.items():
        val = os.environ.get(var, "").strip()
        if val:
            out[key] = val
    return out


def is_secret(key: str) -> bool:
    return key in SECRET_KEYS


def mask(value: str) -> str:
    """Mascara um valor sensível para exibição (nunca ecoa o valor)."""
    if not value:
        return ""
    if len(value) <= 8:
        return "•" * len(value)
    return f"{value[:4]}…{'•' * 6}…{value[-4:]}"


def as_json(values: dict) -> str:
    return json.dumps(values, ensure_ascii=False, indent=2, sort_keys=True)
