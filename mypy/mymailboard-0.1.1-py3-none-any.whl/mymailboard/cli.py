"""cli.py — comando `operation` do MyMailBoard.

    operation migrate                     cria/atualiza tabelas e views
    operation status                      fila por etapa + últimas execuções
    operation sync    --limit 100         Gmail → claw.emails
    operation classify --limit 100        classificação básica
    operation infer   --limit 50          inferência detalhada
    operation embed   --limit 200         embeddings
    operation report                      quadro da fila + totais
    operation auth    [--url-only|--code] re-autenticação Google
    operation config  --list|--set k=v|--probe
    operation serve   --port 8050         web app (Dash)
"""
from __future__ import annotations

import argparse
import json
import sys

from . import __version__, config
from .engine import ui


def _print(o) -> None:
    print(json.dumps(o, ensure_ascii=False, indent=2, default=str))


def main(argv: list[str] | None = None) -> int:
    config.load_dotenv()  # .env do diretório atual (não sobrescreve o ambiente)

    p = argparse.ArgumentParser(prog="operation", description="MyMailBoard — motor de sincronização de e-mail")
    p.add_argument("--version", action="version", version=f"mymailboard {__version__}")
    p.add_argument("--quiet", action="store_true", help="suprime progresso/resumos (erros fatais seguem)")
    p.add_argument("--no-progress", action="store_true", help="desliga a barra de progresso")
    sub = p.add_subparsers(dest="cmd")

    def add_run(name: str, help_: str) -> argparse.ArgumentParser:
        sp = sub.add_parser(name, help=help_)
        sp.add_argument("--window", default="", help="AAAA-MM-DD:AAAA-MM-DD (default: 2014-01-01 até engine.window_end)")
        sp.add_argument("--limit", type=int, default=0, help="máx. de registros nesta execução")
        sp.add_argument("--dry-run", action="store_true", help="simula sem gravar nada")
        sp.add_argument("--json", action="store_true", help="imprime o resultado em JSON")
        return sp

    sub.add_parser("migrate", help="aplica migrations e views (idempotente)")
    sub.add_parser("status", help="fila por etapa + últimas execuções")

    for name, help_ in (("sync", "Gmail → claw.emails (idempotente)"),
                        ("classify", "classificação básica (PENDENTE|AVALIAR|LIXO|IMPORTANTE)"),
                        ("infer", "inferência detalhada (resumo/urgência/ação/categoria)"),
                        ("embed", "embeddings (email/resumo/corpo)")):
        add_run(name, help_)
    sub.add_parser("report", help="quadro da fila + totais")

    sa = sub.add_parser("auth", help="re-autenticação Google (OAuth)")
    sa.add_argument("--url-only", action="store_true", help="imprime só a URL de consentimento e sai")
    sa.add_argument("--code", default="", help="URL de resposta colada (ou o code)")

    sc = sub.add_parser("config", help="configuração efetiva (banco manda)")
    sc.add_argument("--list", action="store_true", help="lista os valores e a origem de cada um")
    sc.add_argument("--set", action="append", default=[], metavar="CHAVE=VALOR", help="grava no banco")
    sc.add_argument("--seed", action="store_true", help="semeia o banco a partir do .env")
    sc.add_argument("--probe", action="store_true", help="testa o endpoint LLM configurado")

    ss = sub.add_parser("serve", help="web app (Dash)")
    ss.add_argument("--host", default="")
    ss.add_argument("--port", type=int, default=0)

    a = p.parse_args(argv)
    ui.QUIET = a.quiet
    ui.PROGRESS = not a.no_progress
    if not a.cmd:
        p.print_help()
        return 0

    # ── comandos sem banco ───────────────────────────────────────────────────
    if a.cmd == "migrate":
        from .db import migrate
        return migrate.main()

    if a.cmd == "serve":
        import os
        from .web.app import run_server
        host = a.host or os.environ.get("MAILBOARD_HOST", "0.0.0.0")
        port = a.port or int(os.environ.get("MAILBOARD_PORT", "8050"))
        run_server(host, port)
        return 0

    try:
        from . import engine
        from .db import config_store

        if a.cmd == "status":
            _print(engine.status())
            return 0

        if a.cmd == "config":
            if a.seed:
                n = config_store.seed_from_env()
                ui.ok(f"{n} chave(s) semeada(s) do .env para o banco")
            for item in a.set:
                if "=" not in item:
                    ui.fail(f"--set espera CHAVE=VALOR (recebi {item!r})")
                    return 2
                k, _, v = item.partition("=")
                n = config_store.save({k.strip(): v}, updated_by="cli")
                ui.ok(f"{k.strip()} gravado no banco" if n else f"chave desconhecida: {k.strip()}")
            if a.probe:
                _print(engine.probe())
            _print(config_store.effective_view())
            return 0

        if a.cmd == "auth":
            st = engine.auth_status()
            if a.url_only:
                _print(engine.auth_url())
                return 0
            if a.code:
                _print(engine.auth_exchange(a.code))
                return 0
            ui.say(f"token atual: {st['token_file']} (existe: {st['exists']}"
                   + (f", conta {st.get('account')}" if st.get("account") else "") + ")")
            _print(engine.auth_url())
            print("\nCole a URL de resposta:")
            try:
                resp = input("> ").strip()
            except EOFError:
                ui.fail("entrada indisponível — use --code '<url>' ou --url-only")
                return 2
            _print(engine.auth_exchange(resp))
            return 0

        # ── operações do motor ───────────────────────────────────────────────
        if a.cmd == "report":
            res = engine.run("report")
            if a.json if hasattr(a, "json") else False:
                _print(res)
            return 0
        res = engine.run(a.cmd, window=a.window or None, limit=a.limit or None, dry_run=a.dry_run)
        if getattr(a, "json", False):
            _print(res)
        return 0

    except engine.Busy as e:  # type: ignore[possibly-undefined]
        ui.fail(str(e))
        return 3
    except Exception as e:  # noqa: BLE001
        ui.fail(f"{type(e).__name__}: {str(e)[:400]}")
        return 2
    except KeyboardInterrupt:
        ui.fail("interrompido pelo usuário")
        return 130


if __name__ == "__main__":
    sys.exit(main())
