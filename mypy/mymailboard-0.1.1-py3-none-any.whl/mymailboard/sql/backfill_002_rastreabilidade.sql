-- backfill_002_rastreabilidade.sql — MyMailBoard
--
-- Adequação das execuções JÁ realizadas à rastreabilidade (opção 1+2, 2026-10-13).
--
-- NÃO é aplicado por `operation migrate` (está em sql/, fora de sql/migrations/):
-- é execução única, rodada uma vez após a migração 002.
--
-- O que preenche:
--   1. claw.mmb_runs.model — para as execuções cujo modelo é COMPROVADO (casado pela
--      janela e confirmado pelo carimbo dos e-mails daquele intervalo). Execuções de
--      origem incerta (piloto de 13/10 03h-14h) ficam com model NULL, sem chute.
--   2. claw.mmb_runs.params — apenas a marca {"origem":"backfill","reconstruido":true}
--      (o snapshot da época NÃO existe; o mmb_config só guarda o valor vigente).
--   3. claw.emails.infer_run_id — pelo intervalo de data_classificacao da execução.
--      Feito ANTES do classify: o infer sobrescrevia data_classificacao, então o
--      carimbo atual dos itens inferidos é do infer.
--   4. claw.emails.classify_run_id — idem para o classify, apenas onde ainda não há
--      vínculo. Itens que passaram pelo classify E depois pelo infer não recuperam o
--      classify_run_id: o carimbo antigo foi sobrescrito e não há como reconstruí-lo.
--
-- Rodar: psql "$FBNET_DB_URL" -f backfill_002_rastreabilidade.sql
-- Idempotente (só toca em NULL).

BEGIN;

-- ── 1) modelo das execuções comprovadas ─────────────────────────────────────
UPDATE claw.mmb_runs r
   SET model  = m.modelo,
       params = coalesce(r.params, '{}'::jsonb)
                || jsonb_build_object('origem', 'backfill', 'reconstruido', true)
  FROM (VALUES
        ('classify', DATE '2026-08-01', DATE '2026-08-31', 'gemma4:12b-32K'),
        ('classify', DATE '2026-07-01', DATE '2026-07-31', 'gemma4:12b-32K'),
        ('classify', DATE '2026-06-01', DATE '2026-06-30', 'ornith-1.5:9b-32K'),
        ('classify', DATE '2026-05-01', DATE '2026-05-31', 'gemma4:e4b-32K'),
        ('infer',    DATE '2026-08-01', DATE '2026-08-31', 'gemma4:12b-32K'),
        ('infer',    DATE '2026-06-01', DATE '2026-06-30', 'ornith-1.5:9b-32K'),
        ('infer',    DATE '2026-05-01', DATE '2026-05-31', 'gemma4:e4b-32K')
       ) AS m(mode, ws, we, modelo)
 WHERE r.mode = m.mode
   AND r.window_start = m.ws
   AND r.window_end = m.we
   AND r.model IS NULL;

-- ── 2) vínculo dos itens — infer primeiro (o carimbo atual é dele) ──────────
UPDATE claw.emails e
   SET infer_run_id = r.id
  FROM claw.mmb_runs r
 WHERE r.mode = 'infer'
   AND e.infer_run_id IS NULL
   AND e.resumo IS NOT NULL
   AND e.date_received >= r.window_start
   AND e.date_received <= r.window_end
   AND e.data_classificacao >= r.started_at - interval '2 minutes'
   AND e.data_classificacao <= coalesce(r.finished_at, r.started_at) + interval '2 minutes';

-- ── 3) vínculo dos itens — classify (o que sobrou) ──────────────────────────
UPDATE claw.emails e
   SET classify_run_id = r.id
  FROM claw.mmb_runs r
 WHERE r.mode = 'classify'
   AND e.classify_run_id IS NULL
   AND e.data_classificacao IS NOT NULL
   AND coalesce(e.classificada_por, '') <> 'fallback'
   AND e.date_received >= r.window_start
   AND e.date_received <= r.window_end
   AND e.data_classificacao >= r.started_at - interval '2 minutes'
   AND e.data_classificacao <= coalesce(r.finished_at, r.started_at) + interval '2 minutes';

-- ── 4) validação das FKs criadas com NOT VALID ──────────────────────────────
ALTER TABLE claw.emails VALIDATE CONSTRAINT emails_classify_run_fk;
ALTER TABLE claw.emails VALIDATE CONSTRAINT emails_infer_run_fk;

-- ── 5) relatório ────────────────────────────────────────────────────────────
DO $$
DECLARE
    n_cls bigint; n_inf bigint; n_sem bigint; n_runs_sem_modelo bigint;
BEGIN
    SELECT count(classify_run_id), count(infer_run_id), count(*) FILTER (WHERE classify_run_id IS NULL)
      INTO n_cls, n_inf, n_sem FROM claw.emails;
    SELECT count(*) INTO n_runs_sem_modelo FROM claw.mmb_runs WHERE model IS NULL AND processed > 0;
    RAISE NOTICE 'backfill: % e-mails com classify_run_id, % com infer_run_id, % sem vínculo de classify; % execuções seguem sem modelo (origem incerta)',
                 n_cls, n_inf, n_sem, n_runs_sem_modelo;
END $$;

COMMIT;
