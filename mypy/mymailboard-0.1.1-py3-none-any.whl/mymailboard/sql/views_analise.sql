-- ============================================================================
-- views_analise.sql — Views de análise de e-mails (claw.emails) para BI
-- FBNet / Hermes — 2026-10-13
--
-- OBJETIVO
--   Expor os e-mails como views AMIGÁVEIS A FERRAMENTAS DE BI (Power BI,
--   Metabase, Excel/ODBC): apenas colunas ESCALARES (nada de arrays ou
--   pgvector — ferramentas de BI engasgam nesses tipos), datas tipadas para
--   hierarquias de tempo nativas, nomes em pt-BR sem acento e estáveis.
--
-- COMO USAR NO POWER BI
--   * Obter Dados > PostgreSQL > schema `claw` > escolher as views v_*
--   * `v_emails_fato` é o FATO principal (1 linha por e-mail): use para
--     tabelas, matrizes e medidas DAX (contagens, %, evolução).
--   * `v_emails_tags` é a DIMENSÃO de tags (catálogo com categoria/cor/prioridade).
--   * As demais v_* já vêm agregadas por pergunta de negócio — ótimas para
--     páginas de dashboard prontas (e como validação cruzada das medidas DAX).
--   * Medidas típicas no Power BI: SUM(total), SUM(nao_lidos),
--     DIVIDE(SUM(lixo), SUM(total)) etc.
--
-- CONVENÇÕES
--   * prefixo `v_`; schema `claw` (mesmo dono de claw.emails).
--   * FUSO: todas as derivações de data/hora usam `AT TIME ZONE
--     'America/Sao_Paulo'` — o `date_received` é `timestamptz` (armazenado em
--     UTC) e sem isso e-mails das 21h–23h locais caem no dia seguinte e o
--     heatmap hora×dia sai errado.
--   * `direcao` = ENVIADO quando o e-mail tem label `SENT` ou sai de um dos
--     endereços do P.O.; senão RECEBIDO. (1.986 e-mails enviados na base.)
--   * As views NÃO aplicam a janela de corte do projeto (date_received <=
--     2026-09-30): quem consome filtra o que quiser. A view operacional de
--     pipeline (v_emails_pipeline_status) mostra a fila por mês.
--   * `v_emails_*_status` (ano-mês × pendente/avaliar/lixo/importante) já
--     existia e NÃO é tocada aqui.
--
-- REPRODUTIBILIDADE: aplicar com
--   psql "$FBNET_DB_URL" -f views_analise.sql
-- (ou o aplicador python do projeto — cada statement separado por `;`)
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 1) v_emails_fato — FATO principal (1 linha por e-mail)
--    Pergunta que responde: "quero cruzar qualquer coisa por qualquer coisa"
--    — é a base de todas as análises e de qualquer medida DAX no Power BI.
--    Colunas: identificação; tempo (data, ano, mes, ano_mes, dia da semana,
--    hora — em horário de São Paulo); direção; remetente + domínio; conteúdo
--    (assunto/resumo/palavras-chave); taxonomia (categoria/urgência/ação/
--    classification); estado (lido, anexo, nº de labels/destinatários) e
--    flags do pipeline (classificacao_ok, inferencia_ok, embedding_ok).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_fato AS
SELECT
    e.id,
    e.message_id,
    e.thread_id,
    e.date_received,
    (e.date_received AT TIME ZONE 'America/Sao_Paulo')::date              AS data,
    EXTRACT(YEAR  FROM (e.date_received AT TIME ZONE 'America/Sao_Paulo'))::int AS ano,
    EXTRACT(MONTH FROM (e.date_received AT TIME ZONE 'America/Sao_Paulo'))::int AS mes,
    to_char(e.date_received AT TIME ZONE 'America/Sao_Paulo', 'YYYY-MM')  AS ano_mes,
    EXTRACT(ISODOW FROM (e.date_received AT TIME ZONE 'America/Sao_Paulo'))::int AS dia_semana, -- 1=seg..7=dom
    CASE EXTRACT(ISODOW FROM (e.date_received AT TIME ZONE 'America/Sao_Paulo'))::int
         WHEN 1 THEN 'segunda' WHEN 2 THEN 'terca'  WHEN 3 THEN 'quarta'
         WHEN 4 THEN 'quinta'  WHEN 5 THEN 'sexta'  WHEN 6 THEN 'sabado'
         ELSE 'domingo' END                                               AS dia_semana_nome,
    EXTRACT(HOUR FROM (e.date_received AT TIME ZONE 'America/Sao_Paulo'))::int AS hora,
    CASE WHEN 'SENT' = ANY(e.labels)
              OR e.from_address ILIKE '%fcjbispo%'
              OR e.from_address ILIKE '%franciscobispo%'
         THEN 'ENVIADO' ELSE 'RECEBIDO' END                               AS direcao,
    e.from_address,
    e.remetente_principal,
    lower(substring(coalesce(e.from_address, '') from '@([A-Za-z0-9._-]+)')) AS dominio,
    e.assunto_principal,
    e.subject,
    e.resumo,
    e.palavras_chave,
    e.categoria_alto_nivel,
    e.urgencia,
    e.acao_necessaria,
    e.classification,
    e.has_attachments,
    e.readed,
    cardinality(e.labels)                                                 AS n_labels,
    array_to_string(e.to_addresses, '; ')                                 AS destinatarios,
    e.classificada_por,
    e.data_classificacao,
    (e.classification IS NOT NULL AND e.classification <> 'PENDENTE')     AS classificacao_ok,
    (e.urgencia IS NOT NULL)                                              AS inferencia_ok,
    (e.email_embedding IS NOT NULL)                                       AS embedding_ok,
    e.provider
FROM claw.emails e;

COMMENT ON VIEW claw.v_emails_fato IS
 'Fato principal: 1 linha por e-mail, apenas colunas escalares (sem arrays/pgvector), datas/horas em America/Sao_Paulo, direcao ENVIADO/RECEBIDO, dominio extraido, e flags do pipeline. Base para tabelas/medidas no Power BI.';
COMMENT ON COLUMN claw.v_emails_fato.direcao IS
 'ENVIADO = label SENT ou remetente do P.O.; RECEBIDO = demais.';
COMMENT ON COLUMN claw.v_emails_fato.classificacao_ok IS
 'true quando classification preenchida e diferente de PENDENTE.';
COMMENT ON COLUMN claw.v_emails_fato.inferencia_ok IS
 'true quando urgencia preenchida (marca da inferencia detalhada).';
COMMENT ON COLUMN claw.v_emails_fato.embedding_ok IS
 'true quando email_embedding preenchido.';


-- ---------------------------------------------------------------------------
-- 2) v_emails_por_mes — evolução mensal (volume + mix)
--    Pergunta: "como o volume e a natureza dos e-mails mudam mês a mês?"
--    Ideal para: gráfico de linhas/barras empilhadas, cards de mix,
--    acompanhamento do % de lixo/importante.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_mes AS
SELECT
    ano_mes,
    ano,
    mes,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE direcao = 'ENVIADO')                             AS enviados,
    count(*) FILTER (WHERE direcao = 'RECEBIDO')                            AS recebidos,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    count(*) FILTER (WHERE has_attachments)                                 AS com_anexo,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante,
    count(*) FILTER (WHERE classification = 'AVALIAR')                      AS avaliar,
    count(*) FILTER (WHERE classification = 'LIXO')                         AS lixo,
    count(*) FILTER (WHERE NOT classificacao_ok)                            AS pendente_classificacao,
    count(*) FILTER (WHERE urgencia = 'alta')                               AS urgencia_alta,
    round(100.0 * count(*) FILTER (WHERE classification = 'LIXO')
          / greatest(count(*), 1), 1)                                       AS pct_lixo,
    round(100.0 * count(*) FILTER (WHERE classification = 'IMPORTANTE')
          / greatest(count(*), 1), 1)                                       AS pct_importante
FROM claw.v_emails_fato
GROUP BY ano_mes, ano, mes;

COMMENT ON VIEW claw.v_emails_por_mes IS
 'Serie mensal de volume com mix (enviados/recebidos, nao lidos, anexos, importante/avaliar/lixo/pendente, urgencia alta e percentuais).';


-- ---------------------------------------------------------------------------
-- 3) v_emails_por_dia — série diária
--    Pergunta: "como foi o movimento dia a dia? houve picos?"
--    Ideal para: gráfico de linha diário com drill de data (usa a coluna
--    `data`, que o Power BI hierarquiza), detecção de picos/anomalias.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_dia AS
SELECT
    data,
    ano,
    mes,
    ano_mes,
    dia_semana_nome,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE direcao = 'ENVIADO')                             AS enviados,
    count(*) FILTER (WHERE direcao = 'RECEBIDO')                            AS recebidos,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante,
    count(*) FILTER (WHERE classification = 'LIXO')                         AS lixo
FROM claw.v_emails_fato
GROUP BY data, ano, mes, ano_mes, dia_semana_nome;

COMMENT ON VIEW claw.v_emails_por_dia IS
 'Serie diaria (America/Sao_Paulo) de volume com recebidos/enviados, nao lidos, importante e lixo — para tendencia diaria e deteccao de picos.';


-- ---------------------------------------------------------------------------
-- 4) v_emails_dia_semana_hora — heatmap
--    Pergunta: "em que dias/horários chega (e sai) o volume?"
--    Ideal para: matriz 7×24 no Power BI (linhas = dia_semana_nome,
--    colunas = hora, valor = total) — revela padrões de carga e rotina.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_dia_semana_hora AS
SELECT
    dia_semana,
    dia_semana_nome,
    hora,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE direcao = 'RECEBIDO')                            AS recebidos,
    count(*) FILTER (WHERE direcao = 'ENVIADO')                             AS enviados,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante
FROM claw.v_emails_fato
GROUP BY dia_semana, dia_semana_nome, hora;

COMMENT ON VIEW claw.v_emails_dia_semana_hora IS
 'Heatmap dia da semana x hora (horario de Sao Paulo): volume recebido/enviado por faixa — matriz 7x24 no Power BI.';


-- ---------------------------------------------------------------------------
-- 5) v_emails_por_remetente — ranking e engajamento por remetente
--    Pergunta: "de quem vem o volume? que remetentes eu leio/ignoro? qual a
--    qualidade (lixo/importante) de cada um?"
--    Ideal para: barras top-N, matriz de engajamento (%lido vs volume),
--    tabela de "quem manda spam" (lixo alto) e "quem importa" (importante alto).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_remetente AS
SELECT
    from_address,
    max(remetente_principal)                                                AS remetente_principal,
    max(dominio)                                                            AS dominio,
    count(*)                                                                AS total,
    min(data)                                                               AS primeira,
    max(data)                                                               AS ultima,
    count(*) FILTER (WHERE direcao = 'ENVIADO')                             AS enviados,
    count(*) FILTER (WHERE direcao = 'RECEBIDO')                            AS recebidos,
    count(DISTINCT thread_id)                                               AS threads,
    count(*) FILTER (WHERE readed)                                          AS lidos,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    round(100.0 * count(*) FILTER (WHERE readed) / greatest(count(*), 1), 1) AS pct_lido,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante,
    count(*) FILTER (WHERE classification = 'AVALIAR')                      AS avaliar,
    count(*) FILTER (WHERE classification = 'LIXO')                         AS lixo,
    round(100.0 * count(*) FILTER (WHERE classification = 'LIXO')
          / greatest(count(*), 1), 1)                                       AS pct_lixo,
    count(*) FILTER (WHERE urgencia = 'alta')                               AS urgencia_alta,
    count(*) FILTER (WHERE has_attachments)                                 AS com_anexo
FROM claw.v_emails_fato
GROUP BY from_address;

COMMENT ON VIEW claw.v_emails_por_remetente IS
 'Ranking por remetente: volume e janela temporal, recebidos/enviados, threads, e engajamento/qualidade (pct_lido, importante, lixo, pct_lixo, urgencia alta, anexos).';


-- ---------------------------------------------------------------------------
-- 6) v_emails_por_dominio — visão por domínio
--    Pergunta: "quais domínios dominam minha caixa? (newsletters, bancos,
--    fornecedores, redes sociais)"
--    Ideal para: treemap/barras por domínio, contagem de remetentes distintos
--    por domínio (ex.: quantos endereços do mesmo domínio me escrevem).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_dominio AS
SELECT
    dominio,
    count(*)                                                                AS total,
    count(DISTINCT from_address)                                            AS remetentes_distintos,
    count(DISTINCT thread_id)                                               AS threads,
    min(data)                                                               AS primeira,
    max(data)                                                               AS ultima,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    round(100.0 * count(*) FILTER (WHERE readed) / greatest(count(*), 1), 1) AS pct_lido,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante,
    count(*) FILTER (WHERE classification = 'LIXO')                         AS lixo,
    round(100.0 * count(*) FILTER (WHERE classification = 'LIXO')
          / greatest(count(*), 1), 1)                                       AS pct_lixo,
    count(*) FILTER (WHERE has_attachments)                                 AS com_anexo
FROM claw.v_emails_fato
GROUP BY dominio;

COMMENT ON VIEW claw.v_emails_por_dominio IS
 'Volume e qualidade por dominio do remetente (treemap/barras), com remetentes distintos, engajamento e participacao de lixo/importante.';


-- ---------------------------------------------------------------------------
-- 7) v_emails_por_categoria — taxonomia de conteúdo
--    Pergunta: "que tipos de assunto me chegam, com que urgência e exigindo
--    que ação?"
--    Ideal para: matriz categoria × urgência (valores = total) e tabela
--    categoria × ação necessária — a "fotografia" do conteúdo da caixa.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_categoria AS
SELECT
    coalesce(categoria_alto_nivel, '(sem categoria)')                       AS categoria_alto_nivel,
    coalesce(urgencia, '(sem urgencia)')                                    AS urgencia,
    coalesce(acao_necessaria, '(sem acao)')                                 AS acao_necessaria,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE direcao = 'RECEBIDO')                            AS recebidos,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    min(data)                                                               AS primeira,
    max(data)                                                               AS ultima
FROM claw.v_emails_fato
GROUP BY 1, 2, 3;

COMMENT ON VIEW claw.v_emails_por_categoria IS
 'Combinacao categoria x urgencia x acao necessaria (da inferencia detalhada) com volume, nao lidos e janela temporal.';


-- ---------------------------------------------------------------------------
-- 8) v_emails_palavras_chave — temas
--    Pergunta: "quais termos aparecem mais nos e-mails?"
--    Ideal para: nuvem de palavras / barras top-N (a coluna `palavras_chave`
--    é uma lista separada por vírgulas — aqui ela é "explodida" e agregada).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_palavras_chave AS
SELECT
    lower(trim(kw))                                                         AS palavra_chave,
    count(DISTINCT e.id)                                                    AS emails,
    min((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS primeira,
    max((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS ultima
FROM claw.emails e,
     unnest(string_to_array(coalesce(e.palavras_chave, ''), ',')) AS kw(palavra)
WHERE trim(kw.palavra) <> ''
GROUP BY 1;

COMMENT ON VIEW claw.v_emails_palavras_chave IS
 'Palavras-chave extraidas na inferencia, explodidas e agregadas (nuvem de palavras / top-N de temas).';


-- ---------------------------------------------------------------------------
-- 9) v_emails_labels — labels nativos do Gmail
--    Pergunta: "qual a composição da caixa pelos rótulos do Gmail?"
--    Ideal para: donut/barras de INBOX, CATEGORY_*, IMPORTANT, UNREAD, SENT,
--    labels personalizados (Label_*), TRASH/STARRED.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_labels AS
SELECT
    l.label,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE NOT e.readed)                                    AS nao_lidos,
    count(*) FILTER (WHERE e.classification = 'IMPORTANTE')                 AS importante,
    count(*) FILTER (WHERE e.classification = 'LIXO')                       AS lixo,
    min((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS primeira,
    max((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS ultima
FROM claw.emails e,
     unnest(e.labels) AS l(label)
GROUP BY l.label;

COMMENT ON VIEW claw.v_emails_labels IS
 'Contagem por label nativo do Gmail (INBOX/CATEGORY_*/IMPORTANT/UNREAD/SENT/Label_*/TRASH/STARRED) com nao lidos e qualidade.';


-- ---------------------------------------------------------------------------
-- 10) v_emails_tags — dimensão de tags do projeto (catálogo + uso)
--     Pergunta: "quais tags existem, como estão catalogadas e quanto já foi
--     aplicado?"
--     Ideal para: tabela de catálogo (nome, categoria, cor, prioridade) e
--     barras de aplicação por tag. ATENÇÃO: o mapa de tags ainda é pequeno
--     (639 aplicações) — a view funciona como DIMENSÃO + uso parcial.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_tags AS
SELECT
    t.tag_id,
    t.slug,
    t.name,
    t.category,
    t.description,
    t.color,
    t.priority_score,
    t.is_system,
    count(m.email_id)                                                       AS emails_taggeados,
    count(*) FILTER (WHERE e.classification = 'IMPORTANTE')                 AS importante,
    count(*) FILTER (WHERE e.urgencia = 'alta')                             AS urgencia_alta,
    min((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS primeira,
    max((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)           AS ultima
FROM claw.email_tags t
LEFT JOIN claw.email_tags_map m ON m.tag_id = t.tag_id
LEFT JOIN claw.emails e        ON e.id = m.email_id
GROUP BY t.tag_id, t.slug, t.name, t.category, t.description, t.color, t.priority_score, t.is_system;

COMMENT ON VIEW claw.v_emails_tags IS
 'Dimensao de tags (catalogo: slug/nome/categoria/cor/prioridade) com contagem de aplicacoes e qualidade dos e-mails taggeados.';


-- ---------------------------------------------------------------------------
-- 11) v_emails_threads — conversas
--     Pergunta: "quais conversas são longas/demoradas/multirremetente?"
--     Ideal para: tabela de threads (n mensagens, duração em horas,
--     participantes, se teve resposta do P.O., não lidos, importante).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_threads AS
SELECT
    thread_id,
    count(*)                                                                AS n_mensagens,
    min(data)                                                               AS primeira,
    max(data)                                                               AS ultima,
    round(EXTRACT(EPOCH FROM (max(date_received) - min(date_received))) / 3600.0, 1) AS duracao_horas,
    count(DISTINCT from_address)                                            AS participantes,
    count(*) FILTER (WHERE direcao = 'ENVIADO')                             AS enviados,
    count(*) FILTER (WHERE NOT readed)                                      AS nao_lidos,
    count(*) FILTER (WHERE classification = 'IMPORTANTE')                   AS importante,
    bool_or(direcao = 'ENVIADO')                                            AS tem_envio,
    (array_agg(assunto_principal ORDER BY date_received DESC))[1]           AS ultimo_assunto
FROM claw.v_emails_fato
WHERE thread_id IS NOT NULL
GROUP BY thread_id;

COMMENT ON VIEW claw.v_emails_threads IS
 'Conversas (thread Gmail): n mensagens, janela e duracao em horas, participantes distintos, envios, nao lidos, importante e ultimo assunto.';


-- ---------------------------------------------------------------------------
-- 12) v_emails_tempo_resposta — tempo de resposta por conversa
--     Pergunta: "quanto tempo eu levo para responder? quais conversas
--     ficaram sem resposta?"
--     Como funciona: ordena as mensagens de cada thread por data e mede o
--     intervalo entre uma mensagem RECEBIDA e a resposta ENVIADA seguinte.
--     Ideal para: histograma de horas de resposta, média/mediana por
--     remetente ou mês, e detecção de "recebido sem resposta".
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_tempo_resposta AS
WITH seq AS (
    SELECT
        thread_id,
        id,
        date_received,
        direcao,
        LAG(date_received) OVER (PARTITION BY thread_id ORDER BY date_received, id) AS anterior_em,
        LAG(direcao)       OVER (PARTITION BY thread_id ORDER BY date_received, id) AS anterior_direcao
    FROM claw.v_emails_fato
    WHERE thread_id IS NOT NULL
)
SELECT
    thread_id,
    id                                                                      AS email_resposta_id,
    anterior_em                                                             AS recebido_em,
    date_received                                                           AS respondido_em,
    round(EXTRACT(EPOCH FROM (date_received - anterior_em)) / 3600.0, 2)    AS horas_resposta,
    (date_received AT TIME ZONE 'America/Sao_Paulo')::date                  AS data_resposta
FROM seq
WHERE direcao = 'ENVIADO' AND anterior_direcao = 'RECEBIDO' AND anterior_em IS NOT NULL;

COMMENT ON VIEW claw.v_emails_tempo_resposta IS
 'Tempo de resposta por conversa: intervalo (horas) entre uma mensagem recebida e a resposta enviada seguinte na mesma thread.';


-- ---------------------------------------------------------------------------
-- 13) v_emails_acao — lista operacional de ação (o "o que fazer agora")
--     Pergunta: "o que exige a MINHA ação e há quanto tempo está esperando?"
--     Critério: classification IMPORTANTE OU (urgencia alta/media com ação
--     que não seja Nenhuma/Leitura apenas).
--     Ideal para: tabela detalhada no dashboard (com resumo e aging em dias),
--     ordenada por urgência e data; filtros por ação/categoria.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_acao AS
SELECT
    id,
    (date_received AT TIME ZONE 'America/Sao_Paulo')::date                  AS data,
    from_address,
    remetente_principal,
    dominio_calc                                                                 AS dominio,
    assunto_principal,
    resumo,
    urgencia,
    acao_necessaria,
    categoria_alto_nivel,
    classification,
    readed,
    has_attachments,
    ((now() AT TIME ZONE 'America/Sao_Paulo')::date
     - (date_received AT TIME ZONE 'America/Sao_Paulo')::date)               AS dias_esperando,
    (urgencia = 'alta')                                                      AS prioridade
FROM (
    SELECT *, lower(substring(coalesce(from_address, '') from '@([A-Za-z0-9._-]+)')) AS dominio_calc
    FROM claw.emails
) x
WHERE classification = 'IMPORTANTE'
   OR (urgencia IN ('alta', 'media')
       AND coalesce(acao_necessaria, '') NOT IN ('Nenhuma', 'Leitura apenas'))
ORDER BY CASE urgencia WHEN 'alta' THEN 1 WHEN 'media' THEN 2 ELSE 3 END, date_received DESC;

COMMENT ON VIEW claw.v_emails_acao IS
 'Fila de acao: e-mails IMPORTANTE ou de urgencia alta/media com acao pendente, com resumo, categoria, aging (dias_esperando) e flag prioridade — pensada para a tabela "o que fazer agora" no dashboard.';


-- ---------------------------------------------------------------------------
-- 14) v_emails_pipeline_status — progresso do processamento LLM
--     Pergunta: "quanto do acervo já foi classificado/inferido/embedado e o
--     que falta, mês a mês?"
--     Ideal para: cards/medidores de progresso e barras empilhadas da fila por
--     mês — acompanha as execuções do emails_pipeline.py (modos classify,
--     infer, embed) sem precisar consultar a tabela crua.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_pipeline_status AS
SELECT
    ano_mes,
    count(*)                                                                AS total,
    count(*) FILTER (WHERE classificacao_ok)                                AS classificados,
    count(*) FILTER (WHERE NOT classificacao_ok)                            AS pendentes_classificacao,
    count(*) FILTER (WHERE inferencia_ok)                                   AS inferidos,
    count(*) FILTER (WHERE NOT inferencia_ok)                               AS pendentes_inferencia,
    count(*) FILTER (WHERE embedding_ok)                                    AS embedados,
    count(*) FILTER (WHERE NOT embedding_ok)                                AS pendentes_embedding,
    round(100.0 * count(*) FILTER (WHERE classificacao_ok) / greatest(count(*), 1), 1) AS pct_classificado,
    round(100.0 * count(*) FILTER (WHERE inferencia_ok)    / greatest(count(*), 1), 1) AS pct_inferido,
    round(100.0 * count(*) FILTER (WHERE embedding_ok)     / greatest(count(*), 1), 1) AS pct_embedado,
    max(data_classificacao)::date                                           AS ultima_classificacao
FROM claw.v_emails_fato
GROUP BY ano_mes;

COMMENT ON VIEW claw.v_emails_pipeline_status IS
 'Progresso do pipeline por mes: total, classificados/inferidos/embedados e pendentes de cada etapa, com percentuais e data da ultima classificacao.';


-- ============================================================================
-- SEGUNDA RODADA (2026-10-13) — gaps encontrados na pesquisa de praticas de
-- "personal inbox analytics" (actordo.com: volume, response time, unread/
-- pending replies/backlog, top contacts/concentracao; getinboxzero.com:
-- volume recebido/enviado/lido, top senders E destinatarios, response time
-- com mediana/media e "within 1 hour").
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 15) v_emails_concentracao_remetentes — Pareto de quem gera o trabalho
--     Pergunta: "quantos remetentes geram X% da minha caixa?" (a referência
--     usa o insight "3 contatos geram 42% do seu trabalho de e-mail").
--     Colunas: posicao, remetente, total, pct_do_total, pct_acumulado,
--     remetentes_distintos, pct_dos_remetentes. Use com filtro posicao<=N
--     para a curva de Pareto no dashboard.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_concentracao_remetentes AS
WITH base AS (
    SELECT from_address, count(*) AS total
    FROM claw.v_emails_fato
    GROUP BY from_address
), tot AS (
    SELECT sum(total) AS total_geral, count(*) AS remetentes FROM base
), ranked AS (
    SELECT b.from_address, b.total,
           row_number() OVER (ORDER BY b.total DESC, b.from_address) AS posicao,
           sum(b.total) OVER (ORDER BY b.total DESC, b.from_address
                              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS acumulado
    FROM base b
)
SELECT r.posicao,
       r.from_address,
       r.total,
       round(100.0 * r.total / t.total_geral, 2)      AS pct_do_total,
       round(100.0 * r.acumulado / t.total_geral, 2)  AS pct_acumulado,
       t.remetentes                                    AS remetentes_distintos,
       round(100.0 * r.posicao / t.remetentes, 2)     AS pct_dos_remetentes
FROM ranked r CROSS JOIN tot t;

COMMENT ON VIEW claw.v_emails_concentracao_remetentes IS
 'Curva de Pareto por remetente: posicao (rank), volume, % do total, % acumulado e % dos remetentes — responde "quantos contatos geram X% da caixa".';


-- ---------------------------------------------------------------------------
-- 16) v_emails_destinatarios — para QUEM eu envio (o "Sent card")
--     Pergunta: "quem eu mais procuro/respondo?" — complementa o ranking de
--     remetentes (que cobre o lado recebido).
--     Extrai o e-mail de cada item de `to_addresses` (formato "Nome <mail>").
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_destinatarios AS
SELECT
    coalesce(lower(substring(d.dest from '([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+)')), lower(trim(d.dest))) AS destinatario,
    lower(substring(coalesce(lower(substring(d.dest from '([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+)')),
                             trim(d.dest)) from '@([A-Za-z0-9._-]+)'))                                     AS dominio,
    count(DISTINCT e.id)                                                          AS emails_enviados,
    count(DISTINCT e.thread_id)                                                   AS threads,
    min((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)                 AS primeira,
    max((e.date_received AT TIME ZONE 'America/Sao_Paulo')::date)                 AS ultima
FROM claw.emails e,
     unnest(e.to_addresses) AS d(dest)
WHERE 'SENT' = ANY(e.labels)
   OR e.from_address ILIKE '%fcjbispo%'
   OR e.from_address ILIKE '%franciscobispo%'
GROUP BY 1, 2;

COMMENT ON VIEW claw.v_emails_destinatarios IS
 'Top destinatarios dos e-mails ENVIADOS (extraidos de to_addresses): volume, threads e janela temporal — o lado "enviado" do ranking de contatos.';


-- ---------------------------------------------------------------------------
-- 17) v_emails_nao_lidos_aging — backlog de não lidos por idade
--     Pergunta: "quanto não lido eu acumulo e há quanto tempo?" (inbox health)
--     Faixas: até 1 dia / 2-7 / 8-30 / 31-90 / 90+. Ordenável pelo prefixo.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_nao_lidos_aging AS
SELECT
    CASE
        WHEN (current_date - data) <= 1  THEN 'a) ate 1 dia'
        WHEN (current_date - data) <= 7  THEN 'b) 2-7 dias'
        WHEN (current_date - data) <= 30 THEN 'c) 8-30 dias'
        WHEN (current_date - data) <= 90 THEN 'd) 31-90 dias'
        ELSE 'e) 90+ dias'
    END                                          AS faixa_idade,
    count(*)                                     AS nao_lidos,
    min(data)                                    AS mais_antigo,
    max(data)                                    AS mais_recente,
    round(avg(current_date - data), 1)           AS media_dias,
    count(*) FILTER (WHERE classification = 'IMPORTANTE') AS importante,
    count(*) FILTER (WHERE urgencia = 'alta')    AS urgencia_alta
FROM claw.v_emails_fato
WHERE NOT readed
GROUP BY 1;

COMMENT ON VIEW claw.v_emails_nao_lidos_aging IS
 'Backlog de e-mails nao lidos por faixa de idade (ate 1d, 2-7, 8-30, 31-90, 90+) com volume, idade media, importante e urgencia alta — "inbox health".';


-- ---------------------------------------------------------------------------
-- 18) v_emails_conversas_abertas — pendências de conversa (os DOIS lados)
--     Pergunta: "o que está esperando por mim?" (pending replies) e "o que
--     está esperando resposta DELES?" (follow-up).
--     `aguardando` = VOCE quando a última mensagem da thread é RECEBIDA
--     (você deve resposta) ou OUTRO quando é ENVIADA (eles devem retorno).
-- ---------------------------------------------------------------------------
-- (DROP antes do CREATE: esta view ganhou colunas no meio do SELECT, e o
--  CREATE OR REPLACE VIEW só permite ADICIONAR colunas no fim)
DROP VIEW IF EXISTS claw.v_emails_conversas_abertas;
CREATE OR REPLACE VIEW claw.v_emails_conversas_abertas AS
WITH ult AS (
    SELECT DISTINCT ON (thread_id)
           thread_id, id AS ultimo_id, direcao AS ultimo_lado, data AS ultima_data,
           from_address, remetente_principal, assunto_principal, resumo,
           urgencia, classification, categoria_alto_nivel, readed
    FROM claw.v_emails_fato
    WHERE thread_id IS NOT NULL
    ORDER BY thread_id, date_received DESC, id DESC
), meta AS (
    SELECT thread_id, count(*) AS n_mensagens, bool_or(direcao = 'ENVIADO') AS tem_envio
    FROM claw.v_emails_fato
    WHERE thread_id IS NOT NULL
    GROUP BY thread_id
), final AS (
    SELECT u.*, m.n_mensagens, m.tem_envio,
           CASE WHEN u.ultimo_lado = 'RECEBIDO' THEN 'VOCE' ELSE 'OUTRO' END AS aguardando,
           (current_date - u.ultima_data) AS dias_parado
    FROM ult u JOIN meta m USING (thread_id)
)
SELECT
    thread_id,
    ultimo_id,
    aguardando,
    ultima_data,
    dias_parado,
    n_mensagens,
    tem_envio,
    from_address,
    remetente_principal,
    assunto_principal,
    resumo,
    urgencia,
    classification,
    categoria_alto_nivel,
    readed
FROM final
-- filtro de RELEVANCIA: sem isso, toda newsletter de 1 mensagem viraria
-- "pendencia de resposta" (50k falsos). Fica o que tem contexto de conversa
-- (>=2 mensagens) ou sinal de importancia/urgencia; LIXO sempre fora.
WHERE classification IS DISTINCT FROM 'LIXO'
  AND (n_mensagens >= 2
       OR classification IN ('IMPORTANTE', 'AVALIAR')
       OR urgencia IN ('alta', 'media'));

COMMENT ON VIEW claw.v_emails_conversas_abertas IS
 'Pendencias RELEVANTES por conversa: ultima mensagem de cada thread com aguardando=VOCE (voce deve resposta) ou OUTRO (esperando retorno deles), dias_parado, n_mensagens, tem_envio. Filtra LIXO e exige >=2 mensagens ou sinal de importancia/urgencia (evita as 50k newsletters de 1 mensagem).';


-- ---------------------------------------------------------------------------
-- 19) v_emails_sla_resposta — tempo de resposta por mês com SLA
--     Pergunta: "estou respondendo mais rápido ou mais devagar? qual % dentro
--     de 1h/4h/24h?" (na referencia: "Within 1 Hour" + trend semanal)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_sla_resposta AS
SELECT
    to_char(data_resposta, 'YYYY-MM')                                              AS ano_mes,
    count(*)                                                                       AS respostas,
    round(avg(horas_resposta)::numeric, 2)                                         AS media_horas,
    round(percentile_cont(0.5) WITHIN GROUP (ORDER BY horas_resposta)::numeric, 2) AS mediana_horas,
    round(100.0 * count(*) FILTER (WHERE horas_resposta <= 1)  / count(*), 1)      AS pct_ate_1h,
    round(100.0 * count(*) FILTER (WHERE horas_resposta <= 4)  / count(*), 1)      AS pct_ate_4h,
    round(100.0 * count(*) FILTER (WHERE horas_resposta <= 24) / count(*), 1)      AS pct_ate_24h,
    round(100.0 * count(*) FILTER (WHERE horas_resposta > 24)  / count(*), 1)      AS pct_mais_24h
FROM claw.v_emails_tempo_resposta
GROUP BY 1;

COMMENT ON VIEW claw.v_emails_sla_resposta IS
 'Tempo de resposta por mes com SLA: media/mediana em horas e percentuais respondidos em ate 1h/4h/24h — evolucao da agilidade de resposta.';


-- ---------------------------------------------------------------------------
-- 20) v_emails_por_modelo — rastreabilidade das operações (por MODELO)
--     Pergunta: "qual modelo processou o quê e com que resultado?" — o que a
--     avaliação de modelos precisava e só existia por arqueologia.
--     Origem: claw.emails.classify_run_id / infer_run_id -> claw.mmb_runs.model
--     (migração 002 + backfill). Uma linha por operação × modelo.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW claw.v_emails_por_modelo AS
WITH pares AS (
    SELECT e.id AS email_id, 'classify'::text AS operacao, e.classify_run_id AS run_id,
           e.classification AS rotulo
      FROM claw.emails e
     WHERE e.classify_run_id IS NOT NULL
    UNION ALL
    SELECT e.id, 'infer'::text, e.infer_run_id, e.urgencia
      FROM claw.emails e
     WHERE e.infer_run_id IS NOT NULL
)
SELECT
    p.operacao,
    coalesce(r.model, '(nao registrado)')                                   AS modelo,
    count(*)                                                                AS emails,
    count(*) FILTER (WHERE p.rotulo = 'IMPORTANTE')                         AS importante,
    count(*) FILTER (WHERE p.rotulo = 'AVALIAR')                            AS avaliar,
    count(*) FILTER (WHERE p.rotulo = 'LIXO')                               AS lixo,
    count(*) FILTER (WHERE p.rotulo = 'PENDENTE')                           AS pendente,
    count(*) FILTER (WHERE p.rotulo IN ('alta', 'media'))                   AS urgencia_alta_media,
    min(r.started_at)::date                                                 AS primeira_execucao,
    max(r.started_at)::date                                                 AS ultima_execucao,
    count(DISTINCT r.id)                                                    AS execucoes
FROM pares p
JOIN claw.mmb_runs r ON r.id = p.run_id
GROUP BY 1, 2;

COMMENT ON VIEW claw.v_emails_por_modelo IS
 'Rastreabilidade por modelo: quantos e-mails cada modelo processou em cada operacao (classify/infer), com o mix resultante (importante/avaliar/lixo/pendente) e as datas das execucoes. Deriva de emails.classify_run_id / infer_run_id -> mmb_runs.model (migracao 002 + backfill).';
