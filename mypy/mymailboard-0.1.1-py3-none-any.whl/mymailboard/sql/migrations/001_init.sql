-- 001_init.sql — MyMailBoard v0.1.0
--
-- Tabelas de apoio do MyMailBoard no schema `claw`.
-- NOTA (decisão do P.O. em 2026-10-13): a v0.1.0 permanece no schema `claw`
-- (prefixo `mmb_` para não colidir); a migração para o schema `mymailboard`
-- (com os nomes `config`/`runs`) virá em uma versão futura.
--
-- Aplicar: operation migrate   (ou python -m mymailboard.db.migrate)

-- ── configuração efetiva (a página "Config" do web app lê/grava aqui) ──────
-- Precedência: banco (MANDANTE) > ambiente/.env (seed inicial) > DEFAULTS do código.
CREATE TABLE IF NOT EXISTS claw.mmb_config (
    key        text        PRIMARY KEY,
    value      text        NOT NULL DEFAULT '',
    is_secret  boolean     NOT NULL DEFAULT false,
    updated_at timestamptz NOT NULL DEFAULT now(),
    updated_by text        NOT NULL DEFAULT 'system'
);

COMMENT ON TABLE claw.mmb_config IS
 'MyMailBoard: configuração efetiva (motores LLM, motor de sincronização, OAuth). O banco é MANDANTE sobre o .env — o .env só semeia a primeira execução. Segredos nunca são gravados aqui (is_secret=true indica valor apenas exibido mascarado).';

-- ── histórico/estado das operações de lote ─────────────────────────────────
CREATE TABLE IF NOT EXISTS claw.mmb_runs (
    id               bigserial   PRIMARY KEY,
    mode             text        NOT NULL,          -- sync|classify|infer|embed|report
    status           text        NOT NULL,          -- running|ok|error|cancelled
    window_start     date,
    window_end       date,
    limit_n          integer,
    dry_run          boolean     NOT NULL DEFAULT false,
    total            integer,                       -- tamanho estimado do lote
    processed        integer     NOT NULL DEFAULT 0,
    ok_count         integer     NOT NULL DEFAULT 0,
    fallback_count   integer     NOT NULL DEFAULT 0,
    error_count      integer     NOT NULL DEFAULT 0,
    started_at       timestamptz NOT NULL DEFAULT now(),
    finished_at      timestamptz,
    heartbeat_at     timestamptz NOT NULL DEFAULT now(),
    message          text,
    triggered_by     text        NOT NULL DEFAULT 'cli',   -- cli|web|scheduler
    pid              integer,
    cancel_requested boolean     NOT NULL DEFAULT false     -- o web pede; o motor checa
);

CREATE INDEX IF NOT EXISTS mmb_runs_started_idx     ON claw.mmb_runs (started_at DESC);
CREATE INDEX IF NOT EXISTS mmb_runs_mode_status_idx ON claw.mmb_runs (mode, status);

COMMENT ON TABLE claw.mmb_runs IS
 'MyMailBoard: registro de cada execução do motor (progresso, contadores, cancelamento cooperativo via cancel_requested, heartbeat). Base do painel "Operações" e do histórico.';
