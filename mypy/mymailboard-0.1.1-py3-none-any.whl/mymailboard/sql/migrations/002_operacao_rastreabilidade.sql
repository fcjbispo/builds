-- 002_operacao_rastreabilidade.sql — MyMailBoard
--
-- Rastreabilidade das operações: QUAL modelo e QUAL execução processaram cada item.
-- Opção 1+2 aprovada pelo P.O. (2026-10-13). Bônus: o infer deixa de sobrescrever o
-- carimbo do classify (correção em código, não em DDL).
--
-- Idempotente: pode rodar repetidas vezes (aplicada por `operation migrate`).
--
--   Nível execução : claw.mmb_runs.model + claw.mmb_runs.params (snapshot da config)
--   Nível item     : claw.emails.classify_run_id + claw.emails.infer_run_id (FK para runs)
--
-- Com o vínculo por item, modelo/data de cada processamento saem de um JOIN com
-- claw.mmb_runs — sem duplicar informação e sem sobrescrita entre operações.

-- ── nível execução ──────────────────────────────────────────────────────────
ALTER TABLE claw.mmb_runs ADD COLUMN IF NOT EXISTS model  text;
ALTER TABLE claw.mmb_runs ADD COLUMN IF NOT EXISTS params jsonb;

COMMENT ON COLUMN claw.mmb_runs.model IS
 'MyMailBoard: modelo LLM usado nesta execução (ex.: gemma4:e4b-32K). Nulo nas execuções antigas de origem incerta (backfill não chuta).';

COMMENT ON COLUMN claw.mmb_runs.params IS
 'MyMailBoard: snapshot dos parâmetros vigentes (llm.base_url, llm.classify.model, llm.infer.model, llm.embed.model, engine.threads). params->>''origem'' = ''backfill'' marca valores reconstruídos depois do fato.';

CREATE INDEX IF NOT EXISTS mmb_runs_model_idx ON claw.mmb_runs (mode, model);

-- ── nível item ──────────────────────────────────────────────────────────────
ALTER TABLE claw.emails ADD COLUMN IF NOT EXISTS classify_run_id bigint;
ALTER TABLE claw.emails ADD COLUMN IF NOT EXISTS infer_run_id    bigint;

COMMENT ON COLUMN claw.emails.classify_run_id IS
 'MyMailBoard: execução de classify que rotulou este e-mail (FK claw.mmb_runs.id). Modelo e data saem do JOIN.';
COMMENT ON COLUMN claw.emails.infer_run_id IS
 'MyMailBoard: execução de infer que extraiu resumo/urgência/ação deste e-mail (FK claw.mmb_runs.id).';

-- FKs idempotentes. NOT VALID: vale para escritas novas na hora e a validação do
-- histórico é feita no fim do backfill (VALIDATE CONSTRAINT) — sem travar a DDL.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'emails_classify_run_fk') THEN
        ALTER TABLE claw.emails
            ADD CONSTRAINT emails_classify_run_fk FOREIGN KEY (classify_run_id)
            REFERENCES claw.mmb_runs (id) ON DELETE SET NULL NOT VALID;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'emails_infer_run_fk') THEN
        ALTER TABLE claw.emails
            ADD CONSTRAINT emails_infer_run_fk FOREIGN KEY (infer_run_id)
            REFERENCES claw.mmb_runs (id) ON DELETE SET NULL NOT VALID;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS emails_classify_run_idx ON claw.emails (classify_run_id);
CREATE INDEX IF NOT EXISTS emails_infer_run_idx    ON claw.emails (infer_run_id);
