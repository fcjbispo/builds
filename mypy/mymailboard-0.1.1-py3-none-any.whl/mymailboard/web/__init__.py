"""web — app Dash do MyMailBoard (dashboards + Operações + Config)."""
from .app import app, run_server  # noqa: F401
