"""config_page.py — página "Config" do web app.

Edita os motores LLM e o motor de sincronização. O que é salvo aqui vai para
`claw.mmb_config` e passa a ser **mandante** sobre o `.env` (regra do P.O.).
Inclui também o fluxo OAuth do Google (gerar URL → colar URL de resposta).
"""
from __future__ import annotations

import dash_bootstrap_components as dbc
from dash import Input, Output, State, html

from .. import config
from ..db import config_store
from ..engine import auth, llm

ACCENT, OK, BAD = "#22d3ee", "#34d399", "#f87171"


def _campo(item: dict):
    key = item["key"]
    if item["is_secret"]:
        ph = "•••••• (definido — digite para substituir)" if item["has_secret"] else "não definido"
        ctrl = dbc.Input(id={"type": "cfg", "key": key}, type="password", placeholder=ph,
                         className="filtro")
    elif key.endswith(("threads", "batch_limit", "timeout_s", "body_chars_infer", "body_chars_embed")):
        ctrl = dbc.Input(id={"type": "cfg", "key": key}, type="number", value=item["value"],
                         className="filtro")
    else:
        ctrl = dbc.Input(id={"type": "cfg", "key": key}, value=item["value"], className="filtro")
    cor = {"banco": OK, ".env": "#60a5fa", "default": "#64748b"}.get(item["origin"], "#64748b")
    return html.Div(
        [
            html.Div(
                [html.Span(key, className="filtro-label"), html.Span(
                    f"  ({item['origin']})", className="kpi-sub", style={"color": cor})],
                className="d-flex justify-content-between",
            ),
            ctrl,
        ],
        className="mb-2",
    )


def _grupo(g: dict, itens: dict) -> dbc.Card:
    return dbc.Card(
        dbc.CardBody(
            [html.Div(g["title"], className="bloco-titulo"),
             html.Div(g["help"], className="kpi-sub mb-2")]
            + [_campo(itens[k]) for k in g["keys"] if k in itens]
        ),
        className="painel h-100",
    )


def layout() -> list:
    itens = {i["key"]: i for i in config_store.effective_view()}
    grupos = config.GROUPS
    cards = []
    for i in range(0, len(grupos), 2):
        par = grupos[i:i + 2]
        cards.append(dbc.Row(
            [dbc.Col(_grupo(g, itens), xs=12, lg=6) for g in par], className="g-3 mb-3"))

    oauth = html.Div(id="cfg-oauth-status")
    return [
        dbc.Alert(
            [html.B("Precedência: "), "banco (mandante) > .env (seed) > default do código. "
             "O que você salvar aqui vai para ", html.Code("claw.mmb_config"),
             " e sobrevive a restart/recriação do container."],
            color="info", className="py-2 small",
        ),
        *cards,
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div("Google / OAuth", className="bloco-titulo"),
                                html.Div("O client secret vem do ambiente (nunca do banco). "
                                         "O token fica em volume, fora da imagem.",
                                         className="kpi-sub mb-2"),
                                oauth,
                                dbc.Button("1· Gerar URL de autorização", id="cfg-auth-url",
                                           color="info", outline=True, size="sm", className="me-2"),
                                html.Div(id="cfg-auth-url-out", className="small mt-2",
                                         style={"wordBreak": "break-all"}),
                                dbc.Input(id="cfg-auth-code", placeholder="2· cole aqui a URL de resposta (ou o code)",
                                          className="filtro mt-2"),
                                dbc.Button("3· Trocar e salvar token", id="cfg-auth-go",
                                           color="success", size="sm", className="mt-2"),
                            ]
                        ),
                        className="painel h-100",
                    ),
                    xs=12, lg=7,
                ),
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div("Testar endpoint LLM", className="bloco-titulo"),
                                html.Div("Faz um GET /models no endpoint configurado e lista os modelos.",
                                         className="kpi-sub mb-2"),
                                dbc.Button("🔌 Testar", id="cfg-probe", color="info", outline=True, size="sm"),
                                html.Div(id="cfg-probe-out", className="small mt-2"),
                            ]
                        ),
                        className="painel h-100",
                    ),
                    xs=12, lg=5,
                ),
            ],
            className="g-3 mb-3",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div("Ações", className="bloco-titulo"),
                                dbc.Button("💾 Salvar no banco", id="cfg-save", color="success",
                                           className="me-2 mb-2"),
                                dbc.Button("🌱 Semear do .env", id="cfg-seed", color="secondary",
                                           outline=True, className="mb-2"),
                                html.Div(id="cfg-msg", className="small"),
                            ]
                        ),
                        className="painel",
                    ),
                    xs=12,
                )
            ],
            className="mb-3",
        ),
    ]


def callbacks(app) -> None:
    @app.callback(
        Output("cfg-msg", "children"),
        Input("cfg-save", "n_clicks"), Input("cfg-seed", "n_clicks"),
        [State({"type": "cfg", "key": k}, "value") for k in config.DEFAULTS],
        prevent_initial_call=True,
    )
    def _save(n_save, n_seed, *valores):
        from dash import ctx
        if ctx.triggered_id == "cfg-seed":
            n = config_store.seed_from_env()
            return dbc.Alert(f"🌱 {n} chave(s) semeada(s) do .env para o banco.", color="info",
                             className="py-2 mb-0")
        if not n_save:
            return ""
        valores_por_chave = dict(zip(config.DEFAULTS.keys(), valores))
        # campo de segredo vazio = manter o que está no banco
        limpos = {k: v for k, v in valores_por_chave.items()
                  if v not in (None, "") or k not in config.SECRET_KEYS}
        n = config_store.save(limpos, updated_by="web")
        return dbc.Alert(f"💾 {n} valor(es) gravado(s) no banco — passam a ser mandantes sobre o .env.",
                         color="success", className="py-2 mb-0")

    @app.callback(
        Output("cfg-auth-url-out", "children"), Output("cfg-oauth-status", "children"),
        Input("cfg-auth-url", "n_clicks"), Input("cfg-auth-go", "n_clicks"),
        State("cfg-auth-code", "value"), prevent_initial_call=False,
    )
    def _oauth(n_url, n_go, code):
        from dash import ctx
        st = auth.status()
        if ctx.triggered_id == "cfg-auth-url" and n_url:
            try:
                u = auth.auth_url()
                return (html.Div([html.B("Abra e aprove: "), html.A(u["url"], href=u["url"],
                                                                     target="_blank")]),
                        dbc.Alert("URL gerada — depois de aprovar, cole a URL de resposta.",
                                  color="info", className="py-2 mb-2"))
            except Exception as e:  # noqa: BLE001
                return html.Div(f"✗ {type(e).__name__}: {str(e)[:300]}", style={"color": BAD}), \
                       dbc.Alert("falha ao gerar a URL", color="danger", className="py-2 mb-2")
        if ctx.triggered_id == "cfg-auth-go" and n_go and code:
            try:
                res = auth.exchange(code)
                return "", dbc.Alert(
                    f"✓ token salvo ({res.get('account') or 'conta não informada'}) · "
                    f"refresh_token: {'SIM' if res.get('refresh_token') else 'NÃO'} · "
                    f"escopos: {res.get('scopes')}", color="success", className="py-2 mb-2")
            except Exception as e:  # noqa: BLE001
                return html.Div(f"✗ {type(e).__name__}: {str(e)[:300]}", style={"color": BAD}), \
                       dbc.Alert("falha na troca do código", color="danger", className="py-2 mb-2")
        ok_tok = st.get("exists")
        txt = (f"token: {st.get('token_file')} · {'presente' if ok_tok else 'AUSENTE'}"
               + (f" · conta {st.get('account')}" if st.get("account") else "")
               + f" · refresh_token: {'sim' if st.get('refresh_token') else 'não'}")
        return "", dbc.Alert(txt, color="success" if ok_tok else "warning", className="py-2 mb-2")

    @app.callback(Output("cfg-probe-out", "children"), Input("cfg-probe", "n_clicks"),
                  prevent_initial_call=True)
    def _probe(n):
        if not n:
            return ""
        r = llm.probe()
        if r.get("ok"):
            return html.Div([
                html.Div(f"✓ endpoint OK — {r.get('base_url')} ({r.get('provider')})"),
                html.Div(f"modelos: {', '.join(r.get('models') or []) or '—'}", className="kpi-sub"),
                html.Div(f"classify↦{r.get('classify')} · infer↦{r.get('infer')} · embed↦{r.get('embed')}",
                         className="kpi-sub"),
            ])
        return html.Div(f"✗ {r.get('error') or r.get('status')}", style={"color": BAD})
