"""operacoes.py — painel "Operações" do web app.

Dispara as operações do motor em background, mostra o progresso ao vivo
(contadores + heartbeat de `claw.mmb_runs`), permite cancelar e lista o
histórico. Um job por vez: dois lotes LLM simultâneos sobrecarregariam a GPU.
"""
from __future__ import annotations

import collections
import threading

import dash_bootstrap_components as dbc
from dash import Input, Output, State, dash_table, dcc, html

from .. import engine
from ..db import config_store, runs
from ..engine import ui

ACCENT, WARN, BAD, OK = "#22d3ee", "#f59e0b", "#f87171", "#34d399"

LOG: collections.deque = collections.deque(maxlen=400)
_state: dict = {"mode": None, "thread": None, "started": None, "message": ""}

MODES = [
    {"label": "sync — Gmail → claw.emails", "value": "sync"},
    {"label": "classify — classificação básica", "value": "classify"},
    {"label": "infer — inferência detalhada", "value": "infer"},
    {"label": "embed — embeddings", "value": "embed"},
]


def _log_hook(event: dict) -> None:
    LOG.append(f"[{event.get('mode')}] {event.get('processed')}/{event.get('total')} "
               f"ok={event.get('ok', 0)} fallback={event.get('fallback', 0)} erros={event.get('errors', 0)}")


ui.HOOK = _log_hook


def _busy() -> bool:
    t = _state.get("thread")
    return bool(t and t.is_alive())


def _worker(mode: str, window: str, limit: int, dry_run: bool) -> None:
    _state.update({"mode": mode, "message": f"{mode} em execução…"})
    try:
        res = engine.run(mode, window=window or None, limit=limit or None,
                         dry_run=dry_run, triggered_by="web")
        _state["message"] = f"{mode}: {res.get('status')} — " + (
            f"{res.get('ok', 0)} ok, {res.get('fallback', 0)} fallback, {res.get('errors', 0)} erro(s)")
    except engine.Busy as e:
        _state["message"] = f"recusado — {e}"
    except Exception as e:  # noqa: BLE001
        _state["message"] = f"erro — {type(e).__name__}: {str(e)[:300]}"
    finally:
        _state["thread"] = None
        LOG.append(f"[{mode}] fim — {_state['message']}")


def layout() -> list:
    cfg = config_store.effective()
    return [
        dbc.Row(
            [
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody(
                            [
                                html.Div("Nova operação", className="bloco-titulo"),
                                html.Div("Modo", className="filtro-label mt-2"),
                                dcc.Dropdown(id="op-mode", options=MODES, value="classify",
                                             clearable=False, className="filtro"),
                                html.Div("Janela (AAAA-MM-DD:AAAA-MM-DD)", className="filtro-label mt-2"),
                                dbc.Input(id="op-window", value=f"2014-01-01:{cfg.get('engine.window_end')}",
                                          className="filtro", debounce=True),
                                html.Div("Limite de registros", className="filtro-label mt-2"),
                                dbc.Input(id="op-limit", type="number", value=int(cfg.get("engine.batch_limit", 100)),
                                          min=1, step=10, className="filtro"),
                                dbc.Checklist(id="op-dry",
                                              options=[{"label": " dry-run (não grava nada)", "value": "dry"}],
                                              value=[], className="mt-2 small", switch=True),
                                html.Div(
                                    [
                                        dbc.Button("▶ Executar", id="op-run", color="info", size="sm",
                                                   className="me-2 mt-2"),
                                        dbc.Button("⏹ Cancelar", id="op-cancel", color="warning",
                                                   outline=True, size="sm", className="mt-2"),
                                    ]
                                ),
                                html.Div(id="op-msg", className="mt-3 small"),
                                html.Div(
                                    "Um job por vez: dois lotes LLM simultâneos sobrecarregam a GPU. "
                                    "O lock do banco também impede a mesma operação no CLI.",
                                    className="kpi-sub mt-2",
                                ),
                            ]
                        ),
                        className="painel h-100",
                    ),
                    xs=12, lg=4,
                ),
                dbc.Col(
                    [
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.Div("Fila atual (pendentes por etapa)", className="bloco-titulo"),
                                    dcc.Loading(dcc.Graph(id="op-fila", config={"displayModeBar": False,
                                                                                "responsive": True},
                                                          style={"height": "230px"})),
                                ]
                            ),
                            className="painel mb-3",
                        ),
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.Div("Execução em andamento", className="bloco-titulo"),
                                    html.Div(id="op-progresso", className="small"),
                                    dcc.Interval(id="op-tick", interval=3000, n_intervals=0),
                                ]
                            ),
                            className="painel",
                        ),
                    ],
                    xs=12, lg=8,
                ),
            ],
            className="g-3 my-3",
        ),
        dbc.Card(
            dbc.CardBody(
                [
                    html.Div("Histórico de execuções", className="bloco-titulo"),
                    dcc.Loading(dash_table.DataTable(
                        id="op-hist",
                        columns=[{"name": c, "id": c} for c in
                                 ("run", "modo", "status", "início", "fim", "limite", "ok",
                                  "fallback", "erros", "total", "origem", "mensagem")],
                        data=[], sort_action="native", page_size=8, style_as_list_view=True,
                        style_header={"backgroundColor": "rgba(15,23,42,.9)", "color": ACCENT,
                                      "fontWeight": "700", "border": "none"},
                        style_cell={"backgroundColor": "rgba(2,6,23,.35)", "color": "#cbd5e1",
                                    "border": "none", "fontSize": "12.5px", "textAlign": "left",
                                    "maxWidth": "380px", "overflow": "hidden", "textOverflow": "ellipsis"},
                    )),
                ]
            ),
            className="painel mb-3",
        ),
        dbc.Card(
            dbc.CardBody(
                [
                    html.Div("Saída do motor", className="bloco-titulo"),
                    html.Pre(id="op-log", className="small",
                             style={"maxHeight": "240px", "overflowY": "auto", "color": "#94a3b8"}),
                ]
            ),
            className="painel mb-3",
        ),
    ]


def callbacks(app) -> None:
    @app.callback(
        Output("op-msg", "children"), Output("op-progresso", "children"), Output("op-log", "children"),
        Output("op-hist", "data"), Output("op-fila", "figure"),
        Input("op-run", "n_clicks"), Input("op-cancel", "n_clicks"), Input("op-tick", "n_intervals"),
        State("op-mode", "value"), State("op-window", "value"), State("op-limit", "value"),
        State("op-dry", "value"),
        prevent_initial_call=False,
    )
    def _tick(n_run, n_cancel, _n, mode, window, limit, dry):
        from dash import ctx
        import plotly.graph_objects as go

        triggered = ctx.triggered_id
        if triggered == "op-run" and n_run:
            if _busy():
                msg = dbc.Alert("Já existe uma operação em andamento — aguarde ou cancele.", color="warning",
                                className="py-2 mb-0")
            else:
                _state["thread"] = threading.Thread(
                    target=_worker, args=(mode, window or "", int(limit or 0), bool(dry)), daemon=True)
                _state["thread"].start()
                msg = dbc.Alert(f"▶ {mode} iniciado (run em background).", color="info", className="py-2 mb-0")
        elif triggered == "op-cancel" and n_cancel:
            ativos = runs.running()
            for r in ativos:
                runs.cancel(r["id"])
            msg = dbc.Alert(f"⏹ cancelamento solicitado para {len(ativos)} execução(ões).",
                            color="warning", className="py-2 mb-0")
        else:
            msg = html.Div(_state.get("message", ""), className="text-secondary")

        # progresso
        ativos = runs.running()
        if ativos:
            r = ativos[0]
            prog = []
            for a in ativos:
                tot = a.get("total") or 0
                done = a.get("processed") or 0
                pct = f"{100.0 * done / tot:.1f}%" if tot else "—"
                prog.append(html.Div([
                    html.B(f"{a['mode']}"),
                    f" — run #{a['id']} · {done}/{tot} ({pct}) · desde {a['started_at']:%H:%M:%S}",
                    f" · heartbeat {a['heartbeat_at']:%H:%M:%S}" if a.get("heartbeat_at") else "",
                ], className="small"))
            progresso = prog or [html.Div("—")]
        else:
            progresso = html.Div("nenhuma execução em andamento", className="text-secondary small")

        # histórico
        hist = [{
            "run": r["id"], "modo": r["mode"], "status": r["status"],
            "início": f"{r['started_at']:%d/%m %H:%M}" if r.get("started_at") else "",
            "fim": f"{r['finished_at']:%d/%m %H:%M}" if r.get("finished_at") else "",
            "limite": r.get("limit_n"), "ok": r.get("ok_count"), "fallback": r.get("fallback_count"),
            "erros": r.get("error_count"), "total": r.get("total"),
            "origem": r.get("triggered_by"), "mensagem": (r.get("message") or "")[:120],
        } for r in runs.recent(40)]

        # fila
        info = engine.batch.info()
        etapas = ["classify", "infer", "embed"]
        fig = go.Figure(go.Bar(
            x=[info.get(e) or 0 for e in etapas], y=etapas, orientation="h",
            text=[info.get(e) or 0 for e in etapas], textposition="outside",
            marker_color=[WARN, "#a78bfa", ACCENT]))
        fig.update_layout(xaxis_title="pendentes", yaxis_title="", margin=dict(l=10, r=60, t=10, b=30),
                          height=220, showlegend=False)

        return msg, progresso, "\n".join(list(LOG)[-120:]), hist, fig
