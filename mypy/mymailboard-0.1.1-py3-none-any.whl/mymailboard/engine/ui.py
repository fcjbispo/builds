"""ui.py — saída do motor: progresso, resumo e modo silencioso.

Portado do `emails_pipeline.py` (validado em produção). `HOOK`, quando definido,
recebe cada atualização de progresso — é assim que o painel "Operações" do web
app acompanha uma execução.
"""
from __future__ import annotations

import sys
import time

QUIET = False      # suprimido por --quiet (erros fatais seguem no stderr)
PROGRESS = True    # desligado por --no-progress
HOOK = None        # callable(dict) | None


def say(msg: str = "") -> None:
    if not QUIET:
        print(msg, flush=True)


def ok(msg: str) -> None:
    say(f"✓ {msg}")


def warn(msg: str) -> None:
    say(f"! {msg}")


def fail(msg: str) -> None:
    print(f"✗ {msg}", file=sys.stderr, flush=True)


def emit(event: dict) -> None:
    """Entrega um evento ao consumidor externo (web), se houver."""
    if HOOK:
        try:
            HOOK(event)
        except Exception:
            pass


class Bar:
    """Barra de progresso nativa. Em TTY desenha a barra; com saída redirecionada
    emite marcos de 25%; `--no-progress` desliga."""

    def __init__(self, total: int, label: str = ""):
        self.total = max(int(total), 1)
        self.n = 0
        self.t0 = time.time()
        self.label = label
        self.tty = sys.stdout.isatty()
        self.marks: set[int] = set()

    def update(self, k: int = 1, extra: str = "") -> None:
        self.n += k
        if not PROGRESS:
            return
        if self.tty:
            frac = self.n / self.total
            w = 28
            fill = int(w * frac)
            el = max(time.time() - self.t0, 0.001)
            sp = self.n / el
            eta = (self.total - self.n) / sp if sp > 0 else 0
            print(f'\r  {self.label}[{"█" * fill}{"░" * (w - fill)}] '
                  f'{self.n}/{self.total} ({frac * 100:3.0f}%) {sp:4.1f}/s ETA {eta:4.0f}s {extra:18s}',
                  end="", flush=True)
        else:
            for m in (25, 50, 75, 100):
                if self.n * 100 >= self.total * m and m not in self.marks:
                    self.marks.add(m)
                    say(f"  {self.label}{m}% ({self.n}/{self.total})")

    def done(self) -> None:
        if PROGRESS and self.tty:
            self.update(0)
            print()
