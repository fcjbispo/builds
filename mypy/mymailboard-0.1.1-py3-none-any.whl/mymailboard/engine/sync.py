"""sync.py — Gmail → `claw.emails` (idempotente).

Portado do `emails_pipeline.py`, com uma correção: o `threadId` do Gmail passa a
ser gravado em `thread_id` (o protótipo omitia a coluna, e as views de conversa
dependem dela).
"""
from __future__ import annotations

from datetime import datetime

from ..db import DB, config_store
from . import ui
from .prompts import extract_plain, scrub


def run(win: tuple[str, str], limit: int, dry: bool, run_id: int | None = None,
        cfg: dict | None = None) -> dict:
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    cfg = cfg or config_store.effective()
    token = cfg.get("google.token_file", "credentials/google_token.json")
    cred = Credentials.from_authorized_user_file(token)
    svc = build("gmail", "v1", credentials=cred)

    q = f'after:{win[0].replace("-", "/")} before:{win[1].replace("-", "/")}'
    got, done = 0, 0
    page = None
    bar = None
    while True:
        res = svc.users().messages().list(userId="me", q=q, pageToken=page, maxResults=100).execute()
        if bar is None:
            bar = ui.Bar(res.get("resultSizeEstimate") or 100, label="sync ")
        pairs = [("gmail_" + x["id"], x["id"]) for x in res.get("messages", []) if x.get("id")]
        existentes: set = set()
        if pairs:
            ph = ",".join(["%s"] * len(pairs))
            with DB() as db:
                existentes = {r[0] for r in db.select(
                    f"SELECT message_id FROM claw.emails WHERE message_id IN ({ph})", [p[0] for p in pairs])}
        for mid, gid in pairs:
            if mid in existentes:
                done += 1
                bar.update(extra=f"novos={got}")
                continue
            m = svc.users().messages().get(userId="me", id=gid, format="full").execute()
            done += 1
            mh = {h["name"].lower(): h["value"] for h in m["payload"].get("headers", [])}
            body = extract_plain(m["payload"])
            dr = datetime.fromtimestamp(int(m.get("internalDate", "0")) / 1000.0)
            labels = list(m.get("labelIds", []))[:50]
            if not dry:
                with DB() as db:
                    db.execute("""INSERT INTO claw.emails (message_id, thread_id, subject, from_address,
                                  date_received, body_plain, labels, has_attachments, readed, provider)
                                  VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                               (mid, m.get("threadId"), mh.get("subject") or "", mh.get("from") or "", dr,
                                scrub(body, 8000) or "", labels,
                                "ATTACHMENT" in labels, "UNREAD" not in labels, "gmail-api"))
            got += 1
            bar.update(extra=f"novos={got}")
            ui.emit({"mode": "sync", "processed": done, "total": max(bar.total, done), "ok": got})
            if got >= limit:
                break
        if got >= limit or not res.get("nextPageToken") or dry:
            break
        page = res["nextPageToken"]
    if bar:
        bar.done()
    ui.ok(f"sync concluído: {got} novo(s) gravado(s) / {done} mensagem(ns) varrida(s)"
          + (" — dry-run: NADA foi gravado" if dry else ""))
    return {"ok": got, "scanned": done, "dry": dry}
