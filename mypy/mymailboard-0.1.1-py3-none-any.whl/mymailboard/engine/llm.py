"""llm.py — cliente LLM do MyMailBoard (OpenAI-compatible).

Os parâmetros vêm da **configuração efetiva** (banco > .env > defaults), então a
página "Config" do web app troca modelo/endpoint/chave sem reiniciar o container.

Provedores suportados (todos usam o mesmo protocolo):
  - `ollama`  — Ollama local (ex.: http://host.docker.internal:11434/v1)
  - `openai`  — OpenAI ou qualquer serviço compatível
  - `gateway` — gateway de agentes do FBNet (ex.: http://hermes:8642/v1)
"""
from __future__ import annotations

import json

import requests

from ..db import config_store
from .prompts import parse_json


class Llm:
    """Cliente com os parâmetros da configuração efetiva (recarregável)."""

    def __init__(self, cfg: dict | None = None):
        self.cfg = dict(cfg or config_store.effective())

    def refresh(self) -> None:
        self.cfg = dict(config_store.effective())

    # ── parâmetros ──────────────────────────────────────────────────────────
    @property
    def base_url(self) -> str:
        return (self.cfg.get("llm.base_url") or "").rstrip("/")

    @property
    def api_key(self) -> str:
        return self.cfg.get("llm.api_key") or ""

    @property
    def temperature(self) -> float:
        try:
            return float(self.cfg.get("llm.temperature") or 0.1)
        except ValueError:
            return 0.1

    @property
    def timeout(self) -> int:
        try:
            return int(self.cfg.get("llm.timeout_s") or 90)
        except ValueError:
            return 90

    def model(self, stage: str) -> str:
        """`stage`: classify | infer | embed."""
        return self.cfg.get(f"llm.{stage}.model") or ""

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    # ── chamadas ───────────────────────────────────────────────────────────
    def chat(self, model: str, messages: list[dict], response_format: dict | None = None) -> str:
        payload = {"model": model, "messages": messages,
                   "temperature": self.temperature, "stream": False}
        if response_format:
            payload["response_format"] = response_format
        r = requests.post(f"{self.base_url}/chat/completions", json=payload,
                          headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]

    def embed(self, text: str, max_chars: int = 4000) -> list[float]:
        r = requests.post(f"{self.base_url}/embeddings",
                          json={"model": self.model("embed"), "input": (text or "")[:max_chars]},
                          headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        return r.json()["data"][0]["embedding"]

    def json_chat(self, model: str, prompt: str):
        """Chama o modelo pedindo JSON e devolve o objeto **já parseado**.

        Tenta com `response_format=json_object` e, se o provedor recusar, sem ele;
        em ambos os casos aplica o `parse_json` tolerante (```json```, texto em
        volta etc.). Retorna (objeto|None, erro|None).
        """
        last = None
        for rf in ({"type": "json_object"}, None):
            try:
                content = self.chat(model, [{"role": "system", "content": "Responda APENAS com um objeto JSON válido."},
                                             {"role": "user", "content": prompt}], rf)
                return parse_json(content), None
            except Exception as e:  # noqa: BLE001
                last = e
        return None, last

    def health(self) -> dict:
        """Teste rápido de conectividade (usado pela página Config)."""
        try:
            r = requests.get(f"{self.base_url}/models", headers=self._headers(), timeout=10)
            return {"ok": r.status_code < 400, "status": r.status_code,
                    "models": [m.get("id") for m in (r.json().get("data") or [])][:40]
                    if r.status_code < 400 else []}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "status": None, "error": f"{type(e).__name__}: {str(e)[:160]}", "models": []}


def probe() -> dict:
    """Diagnóstico do endpoint configurado (provedor, modelos disponíveis)."""
    llm = Llm()
    out = llm.health()
    out.update({"provider": llm.cfg.get("llm.provider"), "base_url": llm.base_url,
                "classify": llm.model("classify"), "infer": llm.model("infer"), "embed": llm.model("embed")})
    return out


def dumps(o) -> str:
    return json.dumps(o, ensure_ascii=False)
