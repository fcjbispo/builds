"""engine — motor do MyMailBoard.

API única usada pela CLI e pelo web app:

    from mymailboard import engine
    engine.run("classify", limit=100)          # roda um lote (com lock e histórico)
    engine.status()                            # fila + últimas execuções
    engine.auth_url() / engine.auth_exchange(code)
"""
from __future__ import annotations

from ..db import config_store, runs
from . import auth, batch, report, sync, ui
from .llm import Llm, probe  # noqa: F401

MODES = ("sync", "classify", "infer", "embed", "report")
DEFAULT_WINDOW_START = "2014-01-01"


class Busy(RuntimeError):
    """Já existe uma execução do mesmo modo em andamento (advisory lock)."""


def default_window(cfg: dict | None = None) -> tuple[str, str]:
    cfg = cfg or config_store.effective()
    return DEFAULT_WINDOW_START, cfg.get("engine.window_end", "2026-09-30")


def run(mode: str, window: str | tuple | None = None, limit: int | None = None,
        dry_run: bool = False, triggered_by: str = "cli", cfg: dict | None = None) -> dict:
    """Executa uma operação do motor.

    `mode`: sync | classify | infer | embed | report
    `window`: "AAAA-MM-DD:AAAA-MM-DD" ou tupla — default: 2014-01-01 até `engine.window_end`.
    """
    if mode not in MODES:
        raise ValueError(f"modo inválido: {mode} (use {'|'.join(MODES)})")
    cfg = cfg or config_store.effective()
    if isinstance(window, str) and window:
        win = tuple(window.split(":")[:2]) if ":" in window else (window, cfg["engine.window_end"])
    else:
        win = tuple(window) if window else default_window(cfg)
    limit = int(limit or cfg.get("engine.batch_limit", 100) or 100)

    if mode == "report":
        return {"mode": "report", "status": "ok", **report.run()}

    runs.stale(int(cfg.get("engine.stale_timeout_s", 900)))
    with runs.lock(mode) as got:
        if not got:
            ativos = runs.running(mode)
            raise Busy(f"já existe uma execução de '{mode}' em andamento"
                       + (f" (run #{ativos[0]['id']}, iniciada por {ativos[0]['triggered_by']})"
                          if ativos else ""))

        total = None
        if mode in batch.MODES:
            total = batch.count_pendentes(mode, win)
        run_id = runs.start(mode, win, limit, dry_run, triggered_by, total, cfg=cfg)
        ui.say(f"lote [{mode}]: limite {limit} | janela {win[0]} → {win[1]} "
               f"| threads {cfg.get('engine.threads')} | dry-run={dry_run} | run #{run_id}")
        try:
            if mode == "sync":
                res = sync.run(win, limit, dry_run, run_id, cfg)
                runs.finish(run_id, "ok", ok=int(res.get("ok", 0)),
                            message=f"{res.get('ok')} novo(s) / {res.get('scanned')} varrida(s)")
                return {"mode": mode, "status": "ok", "run_id": run_id, **res}

            recs = batch.fetch_lote(mode, win, limit)
            if not recs:
                ui.ok("nada a processar: a fila deste modo/janela já está vazia")
                runs.finish(run_id, "ok", message="fila vazia")
                return {"mode": mode, "status": "ok", "run_id": run_id, "ok": 0, "empty": True}

            st = batch.run_batch(recs, mode, not dry_run, win, run_id, cfg)
            status = "cancelled" if st.get("cancelled") else ("error" if st["errors"] and not st["ok"] else "ok")
            runs.finish(run_id, status, ok=st["ok"], fallback=st["fallback"], errors=st["errors"],
                        message=(f"{st['ok']} ok · {st['fallback']} fallback · {st['errors']} erro(s)"
                                 + (" · CANCELADO" if st.get("cancelled") else "")))
            return {"mode": mode, "status": status, "run_id": run_id, **st}
        except Exception as e:  # noqa: BLE001
            runs.finish(run_id, "error", message=f"{type(e).__name__}: {str(e)[:400]}")
            raise


def status(limit: int = 12) -> dict:
    """Fila atual por etapa, contadores e últimas execuções."""
    return {"queue": batch.info(), "runs": runs.recent(limit), "running": runs.running(),
            "config_llm": {k: v for k, v in config_store.effective().items() if k.startswith("llm.")}}


# ── OAuth (usado pela CLI e pela página Config) ──────────────────────────────
def auth_url() -> dict:
    return auth.auth_url()


def auth_exchange(code_or_url: str) -> dict:
    return auth.exchange(code_or_url)


def auth_status() -> dict:
    return auth.status()


__all__ = ["run", "status", "auth_url", "auth_exchange", "auth_status", "probe", "Busy", "MODES",
           "batch", "config_store", "runs", "ui"]
