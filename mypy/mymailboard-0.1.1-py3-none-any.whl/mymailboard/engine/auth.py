"""auth.py — OAuth Google (re-autenticação do token de acesso ao Gmail).

Portado do `emails_pipeline.py` (fluxo PKCE validado): exibe a URL de
consentimento, recebe a URL de resposta colada (ou o `code`), troca por token
novo, grava com backup do anterior e valida com uma chamada real ao Gmail.

Usado pela CLI (`operation auth`) e pela página Config do web app.
"""
from __future__ import annotations

import json
import os
import shutil
from datetime import datetime

from ..db import config_store
from . import ui
from .prompts import extract_code, extract_state

DEFAULT_SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.settings.basic",
    "https://www.googleapis.com/auth/contacts.readonly",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/documents",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/spreadsheets",
]


def paths(cfg: dict | None = None) -> tuple[str, str, str]:
    """(token_file, client_secret_file, oauth_redirect) da configuração efetiva."""
    cfg = cfg or config_store.effective()
    token = cfg.get("google.token_file", "credentials/google_token.json")
    secret = os.environ.get("GOOGLE_CLIENT_SECRET_FILE", "credentials/google_client_secret.json")
    redirect = cfg.get("google.oauth_redirect", "http://localhost")
    return token, secret, redirect


def load_client_config(cfg: dict | None = None):
    """client_id/secret/scopes: arquivo do client > ambiente > token atual > defaults."""
    token, secret_file, redirect = paths(cfg)
    cid = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
    csec = os.environ.get("GOOGLE_CLIENT_SECRET", "").strip()
    scopes = None
    if os.path.exists(secret_file):
        j = json.load(open(secret_file))
        j = j.get("installed") or j.get("web") or j
        cid = cid or j.get("client_id", "")
        csec = csec or j.get("client_secret", "")
    if (not cid or not csec) and os.path.exists(token):
        j = json.load(open(token))
        cid = cid or j.get("client_id", "")
        csec = csec or j.get("client_secret", "")
        scopes = j.get("scopes") or None
    if not cid or not csec:
        raise RuntimeError(
            f"sem client_id/client_secret: coloque o JSON do client (Desktop app) em "
            f"{secret_file} ou defina GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET no ambiente."
        )
    sc = os.environ.get("GOOGLE_SCOPES", "").strip()
    scopes = [s for s in sc.split() if s] or scopes or DEFAULT_SCOPES
    client = {"installed": {"client_id": cid, "client_secret": csec,
                            "auth_uri": "https://accounts.google.com/o/oauth2/v2/auth",
                            "token_uri": "https://oauth2.googleapis.com/token",
                            "redirect_uris": [redirect]}}
    return client, scopes


def _flow(cfg=None):
    from google_auth_oauthlib.flow import Flow
    client, scopes = load_client_config(cfg)
    _, _, redirect = paths(cfg)
    return Flow.from_client_config(client, scopes=scopes, redirect_uri=redirect)


def pending_path(cfg=None) -> str:
    token, _, _ = paths(cfg)
    return os.path.join(os.path.dirname(token) or ".", "google_oauth_pending.json")


def auth_url(cfg: dict | None = None) -> dict:
    """Gera a URL de consentimento e persiste o `code_verifier` para retomada."""
    cfg = cfg or config_store.effective()
    flow = _flow(cfg)
    url, state = flow.authorization_url(access_type="offline", prompt="consent",
                                        include_granted_scopes="true")
    pend = pending_path(cfg)
    os.makedirs(os.path.dirname(pend) or ".", exist_ok=True)
    with open(pend, "w") as f:
        json.dump({"state": state, "code_verifier": flow.code_verifier}, f)
    os.chmod(pend, 0o600)
    return {"url": url, "state": state}


def exchange(code_or_url: str, cfg: dict | None = None) -> dict:
    """Troca o `code` (ou a URL de resposta) por token novo e grava no token_file."""
    cfg = cfg or config_store.effective()
    token, _, _ = paths(cfg)
    flow = _flow(cfg)
    pend = pending_path(cfg)
    state = ""
    if os.path.exists(pend):
        try:
            p = json.load(open(pend))
            flow.code_verifier = p.get("code_verifier") or flow.code_verifier
            state = p.get("state", "")
        except Exception:
            pass
    code = extract_code(code_or_url)
    st = extract_state(code_or_url)
    if not code:
        raise RuntimeError('não encontrei "code=" na resposta colada — gere outra URL e repita.')
    if st and state and st != state:
        ui.warn("state diferente do esperado (siga se você colou a URL mais recente).")
    flow.fetch_token(code=code)
    cred = flow.credentials

    account = ""
    try:
        from googleapiclient.discovery import build
        prof = build("gmail", "v1", credentials=cred).users().getProfile(userId="me").execute()
        account = prof.get("emailAddress", "")
        ui.ok(f'autenticado como {account} (mensagens na conta: {prof.get("messagesTotal")})')
    except Exception as e:  # noqa: BLE001
        ui.warn(f"token obtido, mas a validação no Gmail falhou: {type(e).__name__}: {str(e)[:160]}")

    data = json.loads(cred.to_json())
    data["account"] = account or data.get("account", "")
    os.makedirs(os.path.dirname(token) or ".", exist_ok=True)
    if os.path.exists(token):
        shutil.copy2(token, token + ".bak-" + datetime.now().strftime("%Y%m%dT%H%M%S"))
    with open(token, "w") as f:
        json.dump(data, f, indent=2)
    os.chmod(token, 0o600)
    ui.ok(f"token salvo em {token} (backup do anterior ao lado)")
    ui.say(f'  refresh_token: {"SIM" if data.get("refresh_token") else "NÃO — repita o fluxo"} '
           f'| escopos concedidos: {len(data.get("scopes", []))}')
    if os.path.exists(pend):
        os.remove(pend)
    return {"account": account, "token_file": token,
            "refresh_token": bool(data.get("refresh_token")), "scopes": len(data.get("scopes", []))}


def status(cfg: dict | None = None) -> dict:
    """Situação do token (existe? expira quando? conta?)."""
    cfg = cfg or config_store.effective()
    token, secret_file, _ = paths(cfg)
    out = {"token_file": token, "exists": os.path.exists(token),
           "client_secret_file": secret_file, "client_secret_exists": os.path.exists(secret_file)}
    if out["exists"]:
        try:
            j = json.load(open(token))
            out.update({"account": j.get("account", ""), "scopes": len(j.get("scopes", [])),
                        "refresh_token": bool(j.get("refresh_token")), "expiry": j.get("expiry", "")})
        except Exception as e:  # noqa: BLE001
            out["error"] = f"{type(e).__name__}: {str(e)[:120]}"
    return out
