"""prompts.py — vocabulários, prompts e normalizadores do motor.

Portado literalmente do `emails_pipeline.py` (fluxo validado no piloto de 50
e-mails e nas cargas reais): vocabulário controlado para não deixar o modelo
inventar rótulos, e normalização tolerante a variações de resposta.
"""
from __future__ import annotations

import base64
import json
import re
import unicodedata
import urllib.parse

VOC_URG = ["baixa", "media", "alta"]
VOC_ACAO = ["Leitura apenas", "Nenhuma", "Arquivar", "Responder", "Acompanhar", "Pagamento"]
VOC_CAT = ["Publicidade/Promoção", "Investimentos/Finanças", "Notícias/Atualização",
           "Técnologia/DevOps", "Profissional/Carreira", "Spam/Lixo",
           "Documentos/Comprovantes", "Cobrança/Contas", "Forum/Comunidade", "Outros"]

PROMPT_INFER = """Analise ESTE e-mail e devolve APENAS um objeto JSON com as chaves:
{{"resumo": "resumo do conteúdo em uma frase, PT-BR, <=200 chars",
 "urgencia": "baixa|media|alta",
 "acao_necessaria": "Leitura apenas|Nenhuma|Arquivar|Responder|Acompanhar|Pagamento",
 "categoria_alto_nivel": "<uma categoria do vocabulário abaixo, <=50 chars>",
 "palavras_chave": "3-5 palavras-chave separadas por vírgula, <=200 chars",
 "remetente_principal": "nome/entidade principal do remetente, <=60 chars",
 "assunto_principal": "assunto do e-mail em PT-BR, <=80 chars"}}
Vocabulário de categoria_alto_nivel (escolha EXATAMENTE uma): {vocab}
E-mail:
De: {to}
Data: {dt}
Assunto: {subj}
Corpo:
{body}"""

PROMPT_CLASS = """Classifique este e-mail em UMA destas classes e devolve APENAS JSON:
{{"classification": "PENDENTE|AVALIAR|LIXO|IMPORTANTE"}}
Critério: IMPORTANTE = exige ação/pagamento/prazo pessoal/profissional;
LIXO = spam/promoção fria; AVALIAR = relevante, precisa de decisão; PENDENTE demais.
E-mail:
De: {to}
Data: {dt}
Assunto: {subj}
Corpo:
{body}"""

SYSTEM_JSON = "Responda APENAS com um objeto JSON válido."


def scrub(v, n: int):
    s = "" if v is None else str(v)
    s = re.sub(r"\s+", " ", s.replace("\x00", "")).strip()
    return s[:n] or None


def ascii_l(t) -> str:
    return unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().strip().lower()


def norm_urg(v) -> str:
    t = ascii_l(v)
    if t:
        for u in VOC_URG:
            if t.startswith(u[:4]):
                return u
    return "baixa"


def norm_acao(v) -> str:
    t = ascii_l(v)
    if t:
        if "leitura" in t or "lida" in t or "read" in t:
            return "Leitura apenas"
        if "respons" in t or "respond" in t:  # "responder" não contém "respons"
            return "Responder"
        if "arquiv" in t:
            return "Arquivar"
        if "acompanh" in t:
            return "Acompanhar"
        if "pagam" in t or "pagar" in t or "pay" in t:
            return "Pagamento"
    return "Nenhuma"


def norm_cat(v):
    if not v or not str(v).strip():
        return "Outros"
    t = ascii_l(v)
    for c in VOC_CAT:
        if t == ascii_l(c):
            return c
    for c in VOC_CAT:
        if any(p and p in t for p in ascii_l(c).split("/")):
            return c
    return scrub(v, 50) or "Outros"


def parse_json(txt):
    """Tolerante: aceita ```json ... ```, JSON puro ou JSON embutido no texto."""
    if not txt or not str(txt).strip():
        raise ValueError("resp vazia")
    t = str(txt).strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I | re.M)
    t = re.sub(r"```\s*$", "", t).strip()
    try:
        return json.loads(t)
    except Exception:
        pass
    for pat in (r"\{.*\}", r"\{[^\{\}]*\}"):
        m = re.search(pat, t, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    raise ValueError("sem json")


def extract_plain(payload, _out=None) -> str:
    """Texto (text/plain) de um payload do Gmail — recursivo em multipart."""
    out: list[str] = [] if _out is None else _out

    def walk(p):
        if p.get("mimeType") == "text/plain" and (p.get("body") or {}).get("data"):
            try:
                out.append(base64.urlsafe_b64decode(p["body"]["data"]).decode("utf-8", "ignore"))
            except Exception:
                pass
        for sm in (p.get("parts") or []):
            walk(sm)

    walk(payload or {})
    return "\n".join(out)


def extract_code(resp: str) -> str:
    """Extrai o `code` de uma URL de resposta do OAuth (ou aceita o code cru)."""
    if not resp:
        return ""
    m = re.search(r"[?&]code=([^&\s]+)", resp)
    if m:
        return urllib.parse.unquote(m.group(1))
    s = resp.strip()
    if re.fullmatch(r"[\w\-\./]{10,}", s) and "://" not in s:
        return s
    return ""


def extract_state(resp: str) -> str:
    m = re.search(r"[?&]state=([^&\s]+)", resp or "")
    return urllib.parse.unquote(m.group(1)) if m else ""


def vec_param(lst) -> str:
    """Vetor como literal pgvector."""
    return "[" + ",".join(f"{x:.6f}" for x in lst) + "]"


def extract_text_from_llm(j: dict, key: str) -> str:
    """Busca tolerante da chave (variações de caixa/underscore)."""
    low = {str(k).strip().lower(): (v if isinstance(v, str) else json.dumps(v, ensure_ascii=False))
           for k, v in (j or {}).items()}
    return low.get(key) or low.get(key.replace("_", " ")) or ""
