"""report.py — relatórios de fila e totais (CLI `operation report`)."""
from __future__ import annotations

from ..db import DB


def queue(limit: int = 24) -> list[tuple]:
    with DB() as db:
        return [tuple(r) for r in db.select(
            "SELECT * FROM claw.v_emails_ano_mes_status ORDER BY 1 DESC LIMIT %s", (limit,))]


def totals() -> dict:
    with DB() as db:
        r = db.select("""SELECT count(*) AS total,
                                count(*) FILTER (WHERE urgencia IS NOT NULL) AS inferidos,
                                count(*) FILTER (WHERE classification IS NOT NULL
                                                   AND classification <> 'PENDENTE') AS classificados
                         FROM claw.emails""")
    total, inferidos, classificados = (r[0] if r else (0, 0, 0))
    return {"total": total, "inferidos": inferidos, "classificados": classificados,
            "pendentes": (total or 0) - (classificados or 0)}


def run() -> dict:
    from . import ui
    ui.say("── fila (claw.v_emails_ano_mes_status) ──")
    for row in queue():
        ui.say(f"   {row}")
    ui.say("── totais ──")
    t = totals()
    ui.say(f"   total={t['total']} | inferidos={t['inferidos']} | classificados={t['classificados']}")
    ui.ok("relatório exibido acima (fila por ano-mês e totais)")
    return t
