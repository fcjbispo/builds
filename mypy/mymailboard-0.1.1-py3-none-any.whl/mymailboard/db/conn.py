"""conn.py — conexão com o PostgreSQL do FBNet.

Credenciais SOMENTE do ambiente (regra FBNet: sem default no código):
  - `FBNET_MAILBOARD_DB_URI` (ex.: postgresql://claw:***@postgresql:5432/fbnet)
  - ou `DB_HOST` / `DB_USER` / `DB_PASS` (+ `DB_PORT`, `DB_NAME`)
"""
from __future__ import annotations

import os
from urllib.parse import urlparse

import pg8000.dbapi as pg

DEFAULT_SCHEMA = "claw"


def params() -> dict:
    uri = os.environ.get("FBNET_MAILBOARD_DB_URI", "").strip()
    if uri:
        u = urlparse(uri)
        return {
            "host": u.hostname,
            "port": u.port or 5432,
            "user": u.username,
            "password": u.password,
            "database": (u.path or "/fbnet").lstrip("/"),
        }
    host = os.environ.get("DB_HOST", "").strip()
    user = os.environ.get("DB_USER", "").strip()
    pwd = os.environ.get("DB_PASS", "").strip()
    if not (host and user and pwd):
        raise SystemExit(
            "MyMailBoard: defina FBNET_MAILBOARD_DB_URI (ou DB_HOST/DB_USER/DB_PASS) "
            "no ambiente — sem credencial default no código."
        )
    return {
        "host": host,
        "port": int(os.environ.get("DB_PORT", "5432")),
        "user": user,
        "password": pwd,
        "database": os.environ.get("DB_NAME", "fbnet"),
    }


def connect(timeout: int = 15):
    """Nova conexão (pg8000.dbapi — interface DB-API, sem compilação)."""
    return pg.connect(**params(), timeout=timeout)


class DB:
    """Conexão de uso curto, com a mesma interface usada pelo motor original.

    `select(sql, params)` devolve linhas; `execute(sql, params)` grava (commit)."""

    def __enter__(self):
        self.cn = connect()
        return self

    def select(self, sql: str, params=()):
        return self.q(sql, params, fetch=True)

    def execute(self, sql: str, params=()):
        return self.q(sql, params, fetch=False)

    def q(self, sql: str, params, fetch: bool):
        cur = self.cn.cursor()
        try:
            cur.execute(sql, list(params))
            r = cur.fetchall() if fetch else None
        finally:
            cur.close()
        # Grava também quando há RETURNING (INSERT/UPDATE/DELETE ... RETURNING vêm
        # com fetch=True) — sem isso a transação era descartada no close.
        if not sql.lstrip().upper().startswith(("SELECT", "WITH")):
            self.cn.commit()
        return r

    def __exit__(self, *exc):
        self.cn.close()
        return False


def scalar(sql: str, params=(), default=None):
    """Primeira coluna da primeira linha (ou `default`)."""
    try:
        with DB() as db:
            rows = db.select(sql, params)
        return rows[0][0] if rows else default
    except Exception:
        return default
