"""views.py — leitura das views de análise de e-mail (schema `claw`) com cache.

Mesma estratégia validada no protótipo: as views são pequenas e agregadas; o
`v_emails_fato` (58k linhas) é carregado uma vez e filtrado em memória, o que
deixa os filtros do dashboard instantâneos.
"""
from __future__ import annotations

import threading
import time

import pandas as pd

from .conn import DB

TTL = int(__import__("os").environ.get("MAILBOARD_CACHE_TTL", "300"))

FATO_SQL = """
SELECT id, thread_id, date_received, data, ano, mes, ano_mes, dia_semana_nome,
       hora, direcao, from_address, remetente_principal, dominio,
       assunto_principal, resumo, categoria_alto_nivel, urgencia,
       acao_necessaria, classification, has_attachments, readed
FROM claw.v_emails_fato
"""

VIEWS: dict[str, str] = {
    "fato": FATO_SQL,
    "tempo_resposta": "SELECT * FROM claw.v_emails_tempo_resposta",
    "conversas": "SELECT * FROM claw.v_emails_conversas_abertas",
    "acao": "SELECT * FROM claw.v_emails_acao",
    "pipeline": "SELECT * FROM claw.v_emails_pipeline_status",
    "dominio": "SELECT * FROM claw.v_emails_por_dominio",
    "destinatarios": "SELECT * FROM claw.v_emails_destinatarios",
    "categoria": "SELECT * FROM claw.v_emails_por_categoria",
    "heatmap": "SELECT * FROM claw.v_emails_dia_semana_hora",
    "sla": "SELECT * FROM claw.v_emails_sla_resposta",
    "labels": "SELECT * FROM claw.v_emails_labels",
}

DT_COLS = {
    "fato": ["date_received", "data"],
    "tempo_resposta": ["recebido_em", "respondido_em", "data_resposta"],
    "conversas": ["ultima_data"],
    "acao": ["data"],
    "dominio": ["primeira", "ultima"],
    "destinatarios": ["primeira", "ultima"],
    "categoria": ["primeira", "ultima"],
    "pipeline": ["ultima_classificacao"],
}
BOOL_COLS = {"fato": ["has_attachments", "readed"]}

_cache: dict[str, pd.DataFrame] = {}
_ts: dict[str, float] = {}
_lock = threading.Lock()


def fetch_df(sql: str, params: list | None = None) -> pd.DataFrame:
    """Executa a query e devolve DataFrame (fecha a conexão sempre)."""
    cn = None
    try:
        from .conn import connect
        cn = connect(timeout=60)
        cur = cn.cursor()
        cur.execute(sql, list(params or []))
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
        cur.close()
        return pd.DataFrame(rows, columns=cols)
    finally:
        if cn:
            cn.close()


def _post(df: pd.DataFrame, name: str) -> pd.DataFrame:
    for c in DT_COLS.get(name, []):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce")
    for c in BOOL_COLS.get(name, []):
        if c in df.columns:
            df[c] = df[c].astype(bool)
    for c in df.columns:  # Decimal -> float (plotly não lida bem com Decimal)
        if df[c].dtype == object:
            sample = df[c].dropna().head(50)
            if len(sample) and all(hasattr(v, "as_tuple") for v in sample):
                df[c] = pd.to_numeric(df[c], errors="coerce").astype(float)
    if name == "fato":
        for c in ("ano", "mes", "hora"):
            df[c] = pd.to_numeric(df[c], errors="coerce").astype("Int64")
    return df


def get(name: str, force: bool = False) -> pd.DataFrame:
    """DataFrame da view com cache TTL (thread-safe)."""
    now = time.time()
    with _lock:
        if not force and name in _cache and now - _ts.get(name, 0) < TTL:
            return _cache[name]
    df = _post(fetch_df(VIEWS[name]), name)
    with _lock:
        _cache[name] = df
        _ts[name] = now
    return df


def cache_age() -> float:
    with _lock:
        if not _ts:
            return 0.0
        return round(time.time() - min(_ts.values()))


def clear_cache() -> None:
    with _lock:
        _cache.clear()
        _ts.clear()
