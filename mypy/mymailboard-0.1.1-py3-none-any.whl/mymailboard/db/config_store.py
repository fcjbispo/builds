"""config_store.py — configuração efetiva do MyMailBoard.

Precedência (decisão do P.O., 2026-10-13):
    banco (claw.mmb_config)  >  ambiente/.env (seed)  >  DEFAULTS (código)

O `.env` **semeia** a primeira execução; a partir daí o banco é o mandante e
sobrevive a restart/recriação do container. A página "Config" do web app
lê e grava nesta tabela.
"""
from __future__ import annotations

from ..config import DEFAULTS, env_seed, is_secret
from .conn import DB


def load_db() -> dict[str, str]:
    """Valores persistidos no banco ({} se a tabela ainda não existe)."""
    try:
        with DB() as db:
            rows = db.select("SELECT key, value FROM claw.mmb_config")
        return {k: (v or "") for k, v in rows}
    except Exception:
        return {}


def save(values: dict[str, str], updated_by: str = "web") -> int:
    """Grava (upsert) os valores no banco. Ignora chaves desconhecidas."""
    items = [(k, "" if v is None else str(v), is_secret(k), updated_by)
             for k, v in values.items() if k in DEFAULTS and v is not None]
    if not items:
        return 0
    with DB() as db:
        for key, value, secret, by in items:
            db.execute(
                """INSERT INTO claw.mmb_config (key, value, is_secret, updated_by, updated_at)
                   VALUES (%s, %s, %s, %s, now())
                   ON CONFLICT (key) DO UPDATE
                     SET value = EXCLUDED.value, is_secret = EXCLUDED.is_secret,
                         updated_by = EXCLUDED.updated_by, updated_at = now()""",
                (key, value, secret, by),
            )
    return len(items)


def seed_from_env(overwrite: bool = False) -> int:
    """Semeia a tabela a partir do ambiente/.env. Por padrão só o que falta."""
    seed = env_seed()
    have = load_db()
    new = {k: v for k, v in seed.items() if overwrite or k not in have}
    n = save(new, updated_by="seed:.env")
    return n


def effective() -> dict[str, str]:
    """Configuração efetiva: DEFAULTS < seed do .env < banco."""
    out = dict(DEFAULTS)
    out.update(env_seed())
    out.update(load_db())
    return out


def get(key: str, default: str = "") -> str:
    return effective().get(key, default)


def effective_view() -> list[dict]:
    """Config + origem de cada valor (para a página Config)."""
    db_vals = load_db()
    env_vals = env_seed()
    out = []
    for key, default in DEFAULTS.items():
        if key in db_vals:
            value, origin = db_vals[key], "banco"
        elif key in env_vals:
            value, origin = env_vals[key], ".env"
        else:
            value, origin = default, "default"
        out.append({
            "key": key,
            "value": "" if is_secret(key) else value,
            "has_secret": bool(value) if is_secret(key) else False,
            "origin": origin,
            "is_secret": is_secret(key),
        })
    return out
