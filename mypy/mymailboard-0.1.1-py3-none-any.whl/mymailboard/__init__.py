"""MyMailBoard — motor de sincronização de e-mail (CLI + web app) do FBNet."""

__version__ = "0.1.1"
__all__ = ["__version__"]
