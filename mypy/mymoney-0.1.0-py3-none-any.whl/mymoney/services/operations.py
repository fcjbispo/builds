"""Reusable operation/result services backed by the database."""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from fbpyutils.uuid import hash_string
from sqlalchemy import inspect, text

from mymoney import env

OPERACOES_SCHEMA = "mymoney"
OPERACOES_TABLE = "operacoes"

_ENSURED_ENGINES: set[str] = set()
_ENSURE_LOCK = threading.RLock()


@dataclass(frozen=True)
class OperationFileInfo:
    path: str
    name: str
    pipeline_name: str
    run_timestamp: str
    file_size: int
    modified_at: datetime


@dataclass(frozen=True)
class OperationSummaryError:
    scope: str | None
    error_message: str


@dataclass(frozen=True)
class OperationSummary:
    file_path: str
    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float
    errors: list[OperationSummaryError]


@dataclass(frozen=True)
class OperationPage:
    file_path: str
    page: int
    page_size: int
    total_records: int
    total_pages: int
    items: list[dict[str, Any]]


def _engine_key() -> str:
    engine = env.OP_DB_ENGINE
    url = getattr(engine, "url", None)
    return str(url) if url is not None else str(id(engine))


def _resolved_schema() -> Optional[str]:
    engine_name = env.OP_DB_ENGINE.dialect.name
    return None if engine_name == "sqlite" else OPERACOES_SCHEMA


def _table_ref() -> str:
    schema = _resolved_schema()
    return f"{schema}.{OPERACOES_TABLE}" if schema else OPERACOES_TABLE


def _json_expression(bind_name: str = "detalhes") -> str:
    if env.OP_DB_ENGINE.dialect.name == "postgresql":
        return f"CAST(:{bind_name} AS JSONB)"
    return f":{bind_name}"


def _parse_json_value(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            loaded = json.loads(value)
            return loaded if isinstance(loaded, dict) else {}
        except Exception:
            return {}
    return {}


def _json_size(value: Any) -> int:
    return len(json.dumps(value or {}, ensure_ascii=False, default=str).encode("utf-8"))


def _coerce_datetime(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value.strip():
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None


def ensure_operacoes_table() -> None:
    engine_key = _engine_key()
    with _ENSURE_LOCK:
        if engine_key in _ENSURED_ENGINES:
            return

        engine = env.OP_DB_ENGINE
        schema = _resolved_schema()
        inspector = inspect(engine)
        if inspector.has_table(OPERACOES_TABLE, schema=schema):
            _ENSURED_ENGINES.add(engine_key)
            return

        table_ref = _table_ref()
        with engine.begin() as conn:
            if engine.dialect.name == "postgresql":
                conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {OPERACOES_SCHEMA}"))
                conn.execute(
                    text(
                        f"""
                        CREATE TABLE IF NOT EXISTS {table_ref} (
                            id TEXT NOT NULL PRIMARY KEY,
                            pipeline TEXT NOT NULL,
                            escopo TEXT NOT NULL,
                            processador TEXT NOT NULL,
                            situacao TEXT NOT NULL,
                            sucesso BOOLEAN,
                            mensagem_erro TEXT,
                            iniciado_em TIMESTAMP NOT NULL,
                            finalizado_em TIMESTAMP,
                            duracao_ms BIGINT,
                            dry_run BOOLEAN NOT NULL DEFAULT FALSE,
                            esquema TEXT,
                            tabela TEXT,
                            operacao TEXT,
                            origem TEXT,
                            tipo_lancamento TEXT,
                            detalhes JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                            usuario TEXT DEFAULT 'UNKNOWN' NOT NULL
                        )
                        """
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik01 ON {table_ref} (pipeline, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik02 ON {table_ref} (escopo, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik03 ON {table_ref} (situacao, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik04 ON {table_ref} (dry_run, iniciado_em DESC)"
                    )
                )
            else:
                conn.execute(
                    text(
                        f"""
                        CREATE TABLE IF NOT EXISTS {table_ref} (
                            id TEXT NOT NULL PRIMARY KEY,
                            pipeline TEXT NOT NULL,
                            escopo TEXT NOT NULL,
                            processador TEXT NOT NULL,
                            situacao TEXT NOT NULL,
                            sucesso BOOLEAN,
                            mensagem_erro TEXT,
                            iniciado_em TIMESTAMP NOT NULL,
                            finalizado_em TIMESTAMP,
                            duracao_ms BIGINT,
                            dry_run BOOLEAN NOT NULL DEFAULT 0,
                            esquema TEXT,
                            tabela TEXT,
                            operacao TEXT,
                            origem TEXT,
                            tipo_lancamento TEXT,
                            detalhes TEXT NOT NULL DEFAULT '{{}}',
                            usuario TEXT DEFAULT 'UNKNOWN' NOT NULL
                        )
                        """
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik01 ON {table_ref} (pipeline, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik02 ON {table_ref} (escopo, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik03 ON {table_ref} (situacao, iniciado_em DESC)"
                    )
                )
                conn.execute(
                    text(
                        f"CREATE INDEX IF NOT EXISTS operacoes_ik04 ON {table_ref} (dry_run, iniciado_em DESC)"
                    )
                )

        _ENSURED_ENGINES.add(engine_key)


def _row_to_operation_info(row: dict[str, Any]) -> OperationFileInfo:
    detalhes = _parse_json_value(row.get("detalhes"))
    started_at = _coerce_datetime(row.get("iniciado_em")) or datetime.now()
    modified_at = _coerce_datetime(row.get("finalizado_em")) or started_at
    operation_name = f"{row.get('pipeline', '')}:{row.get('escopo', '')}:{row.get('id', '')}"
    return OperationFileInfo(
        path=str(row.get("id") or ""),
        name=operation_name,
        pipeline_name=str(row.get("pipeline") or ""),
        run_timestamp=started_at.strftime("%Y-%m-%d_%H-%M-%S"),
        file_size=_json_size(detalhes),
        modified_at=modified_at,
    )


def _normalize_unit_record(unit: dict[str, Any]) -> dict[str, Any]:
    dados = unit.get("dados")
    if isinstance(dados, dict):
        data_payload = [dados]
    elif isinstance(dados, list):
        data_payload = dados
    elif dados is None:
        data_payload = []
    else:
        data_payload = [{"valor": str(dados)}]

    return {
        "scope": unit.get("escopo"),
        "success": bool(unit.get("sucesso")),
        "error_message": unit.get("mensagem_erro"),
        "data": data_payload,
        "unit_key": unit.get("unidade"),
        "status": unit.get("situacao"),
        "started_at": unit.get("iniciado_em"),
        "finished_at": unit.get("finalizado_em"),
        "duration_ms": unit.get("duracao_ms"),
    }


def _fetch_operation_row(operation_id: str) -> dict[str, Any]:
    ensure_operacoes_table()
    with env.OP_DB_ENGINE.begin() as conn:
        row = conn.execute(
            text(f"SELECT * FROM {_table_ref()} WHERE id = :id"),
            {"id": operation_id},
        ).mappings().first()
    if row is None:
        raise FileNotFoundError(f"Operation not found: {operation_id}")
    return dict(row)


def _write_details(
    operation_id: str,
    detalhes: dict[str, Any],
    *,
    situacao: Optional[str] = None,
    sucesso: Optional[bool] = None,
    mensagem_erro: Optional[str] = None,
    finalizado_em: Optional[datetime] = None,
    duracao_ms: Optional[int] = None,
) -> None:
    ensure_operacoes_table()
    fields = ["detalhes = " + _json_expression("detalhes")]
    params: dict[str, Any] = {
        "id": operation_id,
        "detalhes": json.dumps(detalhes, ensure_ascii=False, default=str),
    }
    if situacao is not None:
        fields.append("situacao = :situacao")
        params["situacao"] = situacao
    if sucesso is not None:
        fields.append("sucesso = :sucesso")
        params["sucesso"] = sucesso
    if mensagem_erro is not None:
        fields.append("mensagem_erro = :mensagem_erro")
        params["mensagem_erro"] = mensagem_erro
    if finalizado_em is not None:
        fields.append("finalizado_em = :finalizado_em")
        params["finalizado_em"] = finalizado_em
    if duracao_ms is not None:
        fields.append("duracao_ms = :duracao_ms")
        params["duracao_ms"] = duracao_ms

    with env.OP_DB_ENGINE.begin() as conn:
        conn.execute(
            text(f"UPDATE {_table_ref()} SET {', '.join(fields)} WHERE id = :id"),
            params,
        )


def _build_details_summary(
    details: dict[str, Any],
    *,
    situacao: Optional[str] = None,
    finalizado_em: Optional[datetime] = None,
    duracao_ms: Optional[int] = None,
) -> dict[str, Any]:
    resumo = dict(details.get("resumo") or {})
    unidades = list(details.get("unidades") or [])
    sucesso = sum(1 for item in unidades if item.get("situacao") == "SUCCESS")
    falha = sum(1 for item in unidades if item.get("situacao") == "FAIL")
    resumo["total_unidades"] = len(unidades)
    resumo["unidades_sucesso"] = sucesso
    resumo["unidades_falha"] = falha
    if situacao is not None:
        resumo["situacao"] = situacao
    if finalizado_em is not None:
        resumo["finalizado_em"] = finalizado_em.isoformat()
    if duracao_ms is not None:
        resumo["duracao_ms"] = duracao_ms
    details["resumo"] = resumo
    details["unidades"] = unidades
    return details


class OperationRecorder:
    _instance: Optional["OperationRecorder"] = None
    _instance_lock = threading.RLock()

    def __init__(self) -> None:
        self._lock = threading.RLock()

    @classmethod
    def get_instance(cls) -> "OperationRecorder":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def start_scope(
        self,
        *,
        pipeline: str,
        escopo: str,
        processador: str,
        dry_run: bool,
        parallelize: Optional[bool] = None,
        esquema: Optional[str] = None,
        tabela: Optional[str] = None,
        operacao: Optional[str] = None,
        origem: Optional[str] = None,
        tipo_lancamento: Optional[str] = None,
    ) -> str:
        ensure_operacoes_table()
        with self._lock:
            started_at = datetime.now()
            operation_id = hash_string(
                ".".join([pipeline or "~", escopo or "~", started_at.isoformat()])
            )
            details = {
                "resumo": {
                    "pipeline": pipeline,
                    "escopo": escopo,
                    "processador": processador,
                    "situacao": "NEW",
                    "dry_run": bool(dry_run),
                    "parallelize": bool(parallelize),
                    "iniciado_em": started_at.isoformat(),
                    "finalizado_em": None,
                    "duracao_ms": None,
                    "total_unidades": 0,
                    "unidades_sucesso": 0,
                    "unidades_falha": 0,
                },
                "unidades": [],
            }
            params = {
                "id": operation_id,
                "pipeline": pipeline,
                "escopo": escopo,
                "processador": processador,
                "situacao": "NEW",
                "sucesso": None,
                "mensagem_erro": None,
                "iniciado_em": started_at,
                "finalizado_em": None,
                "duracao_ms": None,
                "dry_run": bool(dry_run),
                "esquema": esquema,
                "tabela": tabela,
                "operacao": operacao,
                "origem": origem,
                "tipo_lancamento": tipo_lancamento,
                "detalhes": json.dumps(details, ensure_ascii=False, default=str),
                "usuario": env.USER,
            }
            with env.OP_DB_ENGINE.begin() as conn:
                conn.execute(
                    text(
                        f"""
                        INSERT INTO {_table_ref()} (
                            id, pipeline, escopo, processador, situacao, sucesso,
                            mensagem_erro, iniciado_em, finalizado_em, duracao_ms,
                            dry_run, esquema, tabela, operacao, origem,
                            tipo_lancamento, detalhes, usuario
                        ) VALUES (
                            :id, :pipeline, :escopo, :processador, :situacao, :sucesso,
                            :mensagem_erro, :iniciado_em, :finalizado_em, :duracao_ms,
                            :dry_run, :esquema, :tabela, :operacao, :origem,
                            :tipo_lancamento, {_json_expression()}, :usuario
                        )
                        """
                    ),
                    params,
                )
            details = _build_details_summary(details, situacao="RUNNING")
            _write_details(operation_id, details, situacao="RUNNING")
            return operation_id

    def start_unit(
        self,
        operation_id: Optional[str],
        *,
        unidade: str,
        escopo: str,
        arquivo_origem: Optional[str] = None,
        guia: Optional[str] = None,
        tipo_unidade: Optional[str] = None,
    ) -> None:
        if not operation_id:
            return
        with self._lock:
            row = _fetch_operation_row(operation_id)
            details = _parse_json_value(row.get("detalhes"))
            units = list(details.get("unidades") or [])
            now = datetime.now().isoformat()

            existing = next((item for item in units if item.get("unidade") == unidade), None)
            if existing is None:
                units.append(
                    {
                        "unidade": unidade,
                        "escopo": escopo,
                        "arquivo_origem": arquivo_origem,
                        "guia": guia,
                        "tipo_unidade": tipo_unidade,
                        "situacao": "RUNNING",
                        "sucesso": False,
                        "mensagem_erro": None,
                        "iniciado_em": now,
                        "finalizado_em": None,
                        "duracao_ms": None,
                        "dados": [],
                    }
                )
            else:
                existing["situacao"] = "RUNNING"
                existing["iniciado_em"] = existing.get("iniciado_em") or now
                existing["finalizado_em"] = None
                existing["duracao_ms"] = None
                existing["mensagem_erro"] = None

            details["unidades"] = units
            details = _build_details_summary(details, situacao="RUNNING")
            _write_details(operation_id, details, situacao="RUNNING")

    def finish_unit(
        self,
        operation_id: Optional[str],
        *,
        unidade: str,
        sucesso: bool,
        mensagem_erro: Optional[str],
        dados: dict[str, Any],
    ) -> None:
        if not operation_id:
            return
        with self._lock:
            row = _fetch_operation_row(operation_id)
            details = _parse_json_value(row.get("detalhes"))
            units = list(details.get("unidades") or [])
            now = datetime.now()

            current = next((item for item in units if item.get("unidade") == unidade), None)
            if current is None:
                current = {
                    "unidade": unidade,
                    "escopo": dados.get("scope"),
                    "arquivo_origem": dados.get("arquivo_origem"),
                    "guia": dados.get("sheet_name"),
                    "tipo_unidade": dados.get("kind"),
                    "iniciado_em": now.isoformat(),
                }
                units.append(current)

            started_at = current.get("iniciado_em")
            started_dt: Optional[datetime] = None
            if isinstance(started_at, str) and started_at:
                try:
                    started_dt = datetime.fromisoformat(started_at)
                except ValueError:
                    started_dt = None

            current["situacao"] = "SUCCESS" if sucesso else "FAIL"
            current["sucesso"] = bool(sucesso)
            current["mensagem_erro"] = mensagem_erro
            current["finalizado_em"] = now.isoformat()
            current["duracao_ms"] = (
                int((now - started_dt).total_seconds() * 1000) if started_dt else None
            )
            current["dados"] = [dados]

            details["unidades"] = units
            details = _build_details_summary(details, situacao="RUNNING")
            _write_details(operation_id, details, situacao="RUNNING")

    def finalize_scope(
        self,
        operation_id: Optional[str],
        *,
        sucesso: bool,
        mensagem_erro: Optional[str] = None,
    ) -> None:
        if not operation_id:
            return
        with self._lock:
            row = _fetch_operation_row(operation_id)
            details = _parse_json_value(row.get("detalhes"))
            started_at = _coerce_datetime(row.get("iniciado_em"))
            finished_at = datetime.now()
            duration_ms = (
                int((finished_at - started_at).total_seconds() * 1000)
                if started_at is not None
                else None
            )
            situacao = "SUCCESS" if sucesso else "FAIL"
            details = _build_details_summary(
                details,
                situacao=situacao,
                finalizado_em=finished_at,
                duracao_ms=duration_ms,
            )
            _write_details(
                operation_id,
                details,
                situacao=situacao,
                sucesso=bool(sucesso),
                mensagem_erro=mensagem_erro,
                finalizado_em=finished_at,
                duracao_ms=duration_ms,
            )


def get_operation_recorder() -> OperationRecorder:
    return OperationRecorder.get_instance()


def list_operation_files(
    *,
    limit: int = 10,
    pipeline_name: Optional[str] = None,
    operations_dir: Optional[str] = None,
) -> list[OperationFileInfo]:
    del operations_dir
    if limit < 1:
        raise ValueError("limit must be >= 1")

    ensure_operacoes_table()
    sql = f"SELECT * FROM {_table_ref()}"
    params: dict[str, Any] = {}
    if pipeline_name:
        sql += " WHERE pipeline = :pipeline"
        params["pipeline"] = pipeline_name
    sql += " ORDER BY iniciado_em DESC LIMIT :limit"
    params["limit"] = limit

    with env.OP_DB_ENGINE.begin() as conn:
        rows = conn.execute(text(sql), params).mappings().all()
    return [_row_to_operation_info(dict(row)) for row in rows]


def read_operation_file(path: str, *, max_size_mb: int = 50) -> list[dict[str, Any]]:
    if not path:
        raise ValueError("path must be provided")
    if max_size_mb < 1:
        raise ValueError("max_size_mb must be >= 1")

    row = _fetch_operation_row(path)
    detalhes = _parse_json_value(row.get("detalhes"))
    size_mb = _json_size(detalhes) / (1024 * 1024)
    if size_mb > max_size_mb:
        raise ValueError(
            f"Operation payload is too large ({size_mb:.1f} MB). Maximum allowed: {max_size_mb} MB"
        )

    unidades = list(detalhes.get("unidades") or [])
    return [_normalize_unit_record(unit) for unit in unidades]


def get_operation_page(path: str, *, page: int, page_size: int = 50) -> OperationPage:
    if page < 1:
        raise ValueError("page must be >= 1")
    if page_size < 1:
        raise ValueError("page_size must be >= 1")

    records = read_operation_file(path)
    total_records = len(records)
    total_pages = (total_records + page_size - 1) // page_size if total_records else 0

    if total_pages == 0:
        items: list[dict[str, Any]] = []
    else:
        if page > total_pages:
            raise ValueError(f"page must be between 1 and {total_pages}")
        start = (page - 1) * page_size
        end = start + page_size
        items = records[start:end]

    return OperationPage(
        file_path=path,
        page=page,
        page_size=page_size,
        total_records=total_records,
        total_pages=total_pages,
        items=items,
    )


def summarize_operation_file(path: str) -> OperationSummary:
    records = read_operation_file(path)
    total = len(records)
    successful = sum(1 for row in records if row.get("success", False))
    failed = total - successful
    success_rate = (successful / total * 100) if total else 0.0

    errors: list[OperationSummaryError] = []
    for row in records:
        if row.get("success", False):
            continue
        msg = row.get("error_message")
        if msg:
            errors.append(
                OperationSummaryError(
                    scope=row.get("scope"),
                    error_message=str(msg),
                )
            )

    return OperationSummary(
        file_path=path,
        total_operations=total,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=success_rate,
        errors=errors,
    )


def summarize_pipeline_execution(
    pipeline_name: str,
    *,
    operations_dir: Optional[str] = None,
) -> OperationSummary | None:
    del operations_dir
    matches = list_operation_files(limit=1, pipeline_name=pipeline_name)
    if not matches:
        return None
    return summarize_operation_file(matches[0].path)
