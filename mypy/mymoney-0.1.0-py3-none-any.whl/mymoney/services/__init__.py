"""Public service exports with lazy module loading to avoid import cycles."""

from __future__ import annotations

from importlib import import_module

_OPERATIONS_EXPORTS = {
    "OperationFileInfo",
    "OperationPage",
    "OperationSummary",
    "OperationSummaryError",
    "get_operation_page",
    "list_operation_files",
    "read_operation_file",
    "summarize_operation_file",
    "summarize_pipeline_execution",
}

_PIPELINES_EXPORTS = {
    "PipelineInfo",
    "PipelineRunResult",
    "PipelineRunStats",
    "estimate_pipeline_items",
    "get_pipeline_config",
    "list_default_pipeline_names",
    "list_pipelines",
    "run_pipeline",
    "validate_pipeline_exists",
}

__all__ = sorted(_OPERATIONS_EXPORTS | _PIPELINES_EXPORTS)


def __getattr__(name: str):
    if name in _OPERATIONS_EXPORTS:
        value = getattr(import_module("mymoney.services.operations"), name)
        globals()[name] = value
        return value
    if name in _PIPELINES_EXPORTS:
        value = getattr(import_module("mymoney.services.pipelines"), name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
