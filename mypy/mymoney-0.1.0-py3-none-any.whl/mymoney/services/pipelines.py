"""Reusable pipeline domain services for TUI, API, and web frontends."""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from glob import glob
from typing import Any, Optional

from mymoney import env
from mymoney.data.elt.pipeline import Pipeline
from mymoney.services.operations import list_operation_files, summarize_operation_file

# NOTE: DEFAULT_PIPELINE_CONTRACTS, PIPELINE_ALIASES e ensure_default_pipeline_contracts
# foram removidos conforme PROMPT 017. Pipelines devem existir exclusivamente no banco de dados.


@dataclass(frozen=True)
class PipelineInfo:
    name: str
    path: str
    exists: bool
    updated_at: datetime | None


@dataclass(frozen=True)
class PipelineRunStats:
    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float


@dataclass(frozen=True)
class PipelineRunResult:
    pipeline_name: str
    success: bool
    operation_id: str | None
    operation_file: str | None
    stats: PipelineRunStats | None


def _pipelines_dir(pipelines_dir: Optional[str] = None) -> str:
    return pipelines_dir or env.PIPELINES_FOLDER


def _pipeline_path(pipeline_name: str, pipelines_dir: Optional[str] = None) -> str:
    return os.path.sep.join([_pipelines_dir(pipelines_dir), f"{pipeline_name}.json"])


def list_pipelines_from_files(pipelines_dir: Optional[str] = None) -> list[PipelineInfo]:
    """Lista pipelines de arquivos JSON (legado - será removido)."""
    folder = _pipelines_dir(pipelines_dir)
    if not os.path.exists(folder):
        return []

    result: list[PipelineInfo] = []
    for path in sorted(glob(os.path.sep.join([folder, "*.json"]))):
        name = os.path.basename(path).replace(".json", "")
        result.append(
            PipelineInfo(
                name=name,
                path=path,
                exists=True,
                updated_at=datetime.fromtimestamp(os.path.getmtime(path)),
            )
        )
    return result


def validate_pipeline_exists_in_files(pipeline_name: str, pipelines_dir: Optional[str] = None) -> None:
    """Valida se pipeline existe em arquivo (legado - será removido)."""
    if not pipeline_name:
        raise ValueError("pipeline_name must be provided")

    if not os.path.exists(_pipeline_path(pipeline_name, pipelines_dir)):
        raise FileNotFoundError(f"Pipeline not found: {pipeline_name}")


def get_pipeline_config_from_files(
    pipeline_name: str, pipelines_dir: Optional[str] = None
) -> dict[str, Any]:
    """Carrega config de arquivo (legado - será removido)."""
    import json

    validate_pipeline_exists_in_files(pipeline_name, pipelines_dir)
    path = _pipeline_path(pipeline_name, pipelines_dir)
    with open(path, "r", encoding="utf-8") as f:
        config = json.load(f)
    if not isinstance(config, dict):
        raise ValueError(f"Invalid pipeline config format for '{pipeline_name}'")
    return config


def estimate_pipeline_items(pipeline_name: str) -> int:
    resolved = _resolve_pipeline_name(pipeline_name)
    config = get_pipeline_config(resolved)
    processor = config.get("processor")
    if processor == "CeiLoadDataProcessor":
        try:
            from mymoney.data.providers.cei import OPERATIONS, _get_unprocessed_files

            input_folder = config.get("input_folder") or env.USER_CONFIG.get("CEI_DATA_FOLDER")
            files: set[str] = set()
            for _, masks, _, enabled in OPERATIONS:
                if not enabled:
                    continue
                for path in _get_unprocessed_files(input_folder, masks):
                    files.add(path)
            return len(files)
        except Exception:
            return 10
    if processor == "DataLoadDataProcessor":
        sheets = config.get("sheets", [])
        return len(sheets) if isinstance(sheets, list) else 4
    if processor in (
        "InterLoadDataProcessor",
        "InterGlobalLoadDataProcessor",
        "InterApexLoadDataProcessor",
        "InterApexNcLoadDataProcessor",
        "PicPayLoadDataProcessor",
        "InterAccountLoadDataProcessor",
        "InterGlobalAccountLoadDataProcessor",
        "InterApexAccountLoadDataProcessor",
        "InterApexNcAccountLoadDataProcessor",
        "PicPayAccountLoadDataProcessor",
        "MercadoPagoAccountLoadDataProcessor",
        "NubankAccountLoadDataProcessor",
        "NextAccountLoadDataProcessor",
    ):
        try:
            from mymoney.data.providers.inter import list_unprocessed_files

            folder_key_by_processor = {
                "InterLoadDataProcessor": "INTER_DATA_FOLDER",
                "InterGlobalLoadDataProcessor": "INTER_GLOBAL_DATA_FOLDER",
                "InterApexLoadDataProcessor": "INTER_APEX_DATA_FOLDER",
                "InterApexNcLoadDataProcessor": "INTER_APEX_NC_DATA_FOLDER",
                "PicPayLoadDataProcessor": "PICPAY_DATA_FOLDER",
                "InterAccountLoadDataProcessor": "INTER_DATA_FOLDER",
                "InterGlobalAccountLoadDataProcessor": "INTER_GLOBAL_DATA_FOLDER",
                "InterApexAccountLoadDataProcessor": "INTER_APEX_DATA_FOLDER",
                "InterApexNcAccountLoadDataProcessor": "INTER_APEX_NC_DATA_FOLDER",
                "PicPayAccountLoadDataProcessor": "PICPAY_DATA_FOLDER",
                "MercadoPagoAccountLoadDataProcessor": "MERCADO_PAGO_DATA_FOLDER",
                "NubankAccountLoadDataProcessor": "NUBANK_DATA_FOLDER",
                "NextAccountLoadDataProcessor": "NEXT_DATA_FOLDER",
            }
            input_folder = config.get("input_folder") or env.USER_CONFIG.get(
                folder_key_by_processor.get(processor, "")
            )
            masks = config.get("input_masks", [])
            return len(list_unprocessed_files(input_folder, masks))
        except Exception:
            return 1
    return 0

def _summarize_operation(operation_id: Optional[str]) -> PipelineRunStats | None:
    if not operation_id:
        return None
    summary = summarize_operation_file(operation_id)
    return PipelineRunStats(
        total_operations=summary.total_operations,
        successful_operations=summary.successful_operations,
        failed_operations=summary.failed_operations,
        success_rate=summary.success_rate,
    )


def run_pipeline(
    pipeline_name: str,
    *,
    parallelize: bool = True,
    progress: bool = False,
    progress_callback=None,
    dry_run: bool = False,
) -> PipelineRunResult:
    """Executa uma pipeline a partir do banco de dados.

    NOTE: Conforme PROMPT 017, pipelines devem existir no banco de dados.
    Use 'mymoney pipelines migrate' para migrar pipelines de arquivos JSON.
    """
    # A pipeline será carregada do banco de dados pelo nome
    pipeline = Pipeline(pipeline_name)
    callback = progress_callback
    if not progress and callback is None:
        callback = lambda *_args, **_kwargs: None

    result = pipeline.run(
        parallelize=parallelize,
        progress=progress,
        progress_callback=callback,
        dry_run=dry_run,
    )

    operation_id = result.get("operation_id")
    if not operation_id:
        matches = list_operation_files(limit=1, pipeline_name=pipeline_name)
        operation_id = matches[0].path if matches else None
    stats = _summarize_operation(operation_id)

    return PipelineRunResult(
        pipeline_name=pipeline_name,
        success=True,
        operation_id=operation_id,
        operation_file=operation_id,
        stats=stats,
    )
