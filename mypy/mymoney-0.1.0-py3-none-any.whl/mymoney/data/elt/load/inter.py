"""Inter bank load processors for various account types."""

from __future__ import annotations

import os
from datetime import date, datetime
from typing import Any

import pandas as pd
from fbpyutils import ofx as OFX

from mymoney import emit_debug_trace, env, logger
from mymoney.data.elt.load.base import (
    AccountFileDataProvider,
    AccountLoadDataProcessor,
    _build_typed_lancamentos_dataframe,
    _map_account_rows_to_lancamentos,
    _move_file_done,
    _normalize_financial_identity,
    _parse_number_br,
    _read_lines,
    _resequence_monthly_codes,
    _run_load_file,
    _split_description,
)
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation
from fbpyutils_db.database.schema import get_schema
from mymoney.data.elt.load.folders import resolve_scoped_input_folder
from mymoney.data.providers.inter import (
    INTER_APEX_DEFAULT_MASKS,
    INTER_APEX_NC_DEFAULT_MASKS,
    INTER_CC_DEFAULT_MASKS,
    INTER_DEFAULT_MASKS,
    INTER_GLOBAL_DEFAULT_MASKS,
    list_unprocessed_files,
)
from mymoney.services.operations import get_operation_recorder


def _parse_inter_csv(file_path: str) -> pd.DataFrame:
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 3:
        return pd.DataFrame(columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"])

    csv_data_line = 5
    for i, line in enumerate(csv_lines):
        if "Valor" in line:
            csv_data_line = i + 1
            break

    info_conta = csv_lines[1].split(";")[-1].strip()
    info_conta = f"077.0001.{info_conta}"

    csv_data = []
    for line in csv_lines[csv_data_line:]:
        if not line:
            continue
        raw = line.split(";")
        if len(raw) < 4:
            continue
        try:
            if len(raw) == 6:
                data_lancamento, historico, descricao, valor, _saldo = (
                    raw[0],
                    raw[1],
                    raw[2],
                    raw[4],
                    raw[5],
                )
            elif len(raw) == 5:
                data_lancamento, historico, descricao, valor, _saldo = (
                    raw[0],
                    raw[1],
                    raw[2],
                    raw[3],
                    raw[4],
                )
            else:
                data_lancamento, historico, descricao, valor = (
                    raw[0],
                    raw[1] if len(raw) > 1 else "",
                    raw[2] if len(raw) > 2 else "",
                    raw[3],
                )

            if historico:
                descricao = f"{historico.strip()}::{descricao.strip()}"
            else:
                descricao = descricao.strip().replace(" - ", "::", 1)

            valor_float = _parse_number_br(valor)
            dc = "D" if valor_float < 0 else "C"
            parsed_date = pd.to_datetime(
                datetime.strptime(data_lancamento.strip(), "%d/%m/%Y").date()
            )
            csv_data.append(
                (info_conta, 0, parsed_date, dc, descricao, valor_float, "BRL")
            )
        except Exception as exc:
            logger.error(
                f"Failed parsing INTER CSV row in file '{file_path}': {exc}. row={line}"
            )

    if not csv_data:
        return pd.DataFrame(columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"])

    data = pd.DataFrame(
        csv_data,
        columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"],
    ).sort_values(by=["conta", "data", "descricao", "valor"], ascending=True)
    data = data.reset_index(drop=True)
    data["seq"] = data.index + 1
    return data


def _parse_inter_ofx(file_path: str) -> pd.DataFrame:
    ofx_data = OFX.read_from_path(file_path)
    bank_number = ofx_data.get("routing_number")
    agency = str(ofx_data.get("branch_id", "")).split("-")[0]
    account = ofx_data.get("id")
    account_id = ".".join([str(bank_number), str(agency), str(account)])
    currency = ofx_data.get("statement", {}).get("currency", "BRL")

    transactions = []
    for i, item in enumerate(ofx_data.get("statement", {}).get("transactions", [])):
        date_value = item.get("date")
        memo = str(item.get("memo", "")).replace(" - ", "::", 1)
        amount = float(item.get("amount", 0))
        dc = "D" if amount < 0 else "C"
        transactions.append(
            (
                account_id,
                i,
                pd.to_datetime(date_value.date() if hasattr(date_value, "date") else date_value),
                dc,
                memo,
                amount,
                currency,
            )
        )

    return pd.DataFrame(
        transactions,
        columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"],
    )


def _parse_inter_pdf(_file_path: str) -> pd.DataFrame:
    from mymoney.data.providers.inter.inter_pdf import parse_inter_pdf

    return parse_inter_pdf(_file_path)


def _inter_global_parse_value(raw_value: str, dc: str) -> tuple[str, float] | None:
    if not raw_value:
        return None
    tokens = raw_value.split(" ")
    if len(tokens) < 2:
        return None
    moeda_raw, amount_raw = tokens[0], tokens[1]
    dc_normalized = str(dc or "").strip().lower()
    factor = -1 if moeda_raw.startswith("-") or dc_normalized.startswith("d") else 1
    amount = float(amount_raw.replace(".", "").replace(",", ".")) * factor
    currency = {"US$": "USD", "R$": "BRL", "\u20ac": "EUR"}.get(
        moeda_raw.replace("-", ""),
        "$",
    )
    return currency, amount


def _inter_global_parse_values(raw_values: str, dc: str) -> tuple[Any, Any]:
    first, second = raw_values.split(" | ") if "|" in raw_values else (raw_values, None)
    return _inter_global_parse_value(first, dc), _inter_global_parse_value(second, dc)


def _inter_global_parse_datetime_sequence(raw_value: str) -> tuple[date, int]:
    date_part, time_part = raw_value.split(" ")
    return datetime.strptime(date_part, "%d/%m/%Y").date(), int(time_part.replace(":", ""))


def _parse_inter_global_csv(file_path: str) -> pd.DataFrame:
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 13:
        return pd.DataFrame(columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"])

    conta = ".".join(
        [
            csv_lines[2].split(";")[1],
            csv_lines[3].split(";")[1],
            csv_lines[4].split(";")[1],
        ]
    )
    data_lines = csv_lines[12:]

    rows = []
    seq = len(data_lines)
    for line in data_lines:
        if not line:
            continue
        xline = line.split(";")
        if len(xline) < 5:
            seq -= 1
            continue
        try:
            if len(xline) == 5:
                data, xvalor, historico, descricao, compl = xline
            else:
                data, xvalor, historico, descricao, compl, _ = xline[:6]

            data_movimentacao, _clock_seq = _inter_global_parse_datetime_sequence(data)
            valor1, valor2 = _inter_global_parse_values(xvalor, historico)
            if not valor1:
                seq -= 1
                continue
            moeda, valor = valor1
            dc = "D" if valor < 0 else "C"

            if valor2:
                descricao = " - ".join([historico, descricao, str(valor2)])
            else:
                descricao = " - ".join([historico, descricao])
            if compl:
                descricao = " - ".join([descricao, compl])

            rows.append((conta, pd.to_datetime(data_movimentacao), seq, dc, descricao, valor, moeda))
        except Exception as exc:
            logger.error(
                f"Failed parsing INTER-GLOBAL CSV row in file '{file_path}': {exc}. row={line}"
            )
        finally:
            seq -= 1

    if not rows:
        return pd.DataFrame(columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"])

    data = pd.DataFrame(
        rows,
        columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"],
    ).sort_values(
        by=["conta", "data", "seq", "descricao", "valor", "moeda"],
        ascending=True,
    )
    data = data.reset_index(drop=True)
    return data


def _parse_inter_global_pdf(_file_path: str) -> pd.DataFrame:
    from mymoney.data.providers.inter_global.inter_global_pdf import parse_inter_global_pdf

    return parse_inter_global_pdf(_file_path)


def _normalize_inter_global_account_identifier(raw_value: Any) -> str | None:
    text = str(raw_value or "").strip()
    if not text:
        return None
    if "." in text:
        first_part = text.split(".", 1)[0].strip()
        if first_part.isdigit():
            return first_part
    return text


def _parse_inter_apex_pdf(_file_path: str) -> pd.DataFrame:
    from mymoney.data.providers.inter.apex import parse_inter_apex_pdf

    return parse_inter_apex_pdf(_file_path)


def _parse_inter_apex_nc_pdf(_file_path: str) -> pd.DataFrame:
    from mymoney.data.providers.inter.apex import parse_inter_apex_nc_pdf

    return parse_inter_apex_nc_pdf(_file_path)


class InterAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Inter bank account statements (CSV/OFX/PDF)."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "inter"),
        "agent": (str, False, "mm.data.elt.load.inter"),
        "source": (str, False, "mm.data.elt.load.inter"),
        "institution": (str, False, "BANCO INTER S/A"),
        "transaction_type": (str, False, "LANCAMENTOS_CONTA_CORRENTE"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(INTER_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "INTER_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "INTER"
    DEFAULT_INPUT_MASKS = INTER_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".csv": _parse_inter_csv,
        ".ofx": _parse_inter_ofx,
        ".pdf": _parse_inter_pdf,
    }
    RESEQUENCE_MONTHLY = False


class InterGlobalAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Inter Global account statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "inter_global"),
        "agent": (str, False, "mm.data.elt.load.inter_global"),
        "source": (str, False, "mm.data.elt.load.inter_global"),
        "institution": (str, False, "INTER & CO PAYMENTS INC"),
        "transaction_type": (str, False, "LANCAMENTOS_CONTA_CORRENTE"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(INTER_GLOBAL_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "INTER_GLOBAL_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "INTER_GLOBAL"
    DEFAULT_INPUT_MASKS = INTER_GLOBAL_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".csv": _parse_inter_global_csv,
        ".pdf": _parse_inter_global_pdf,
    }
    RESEQUENCE_MONTHLY = True
    ACCOUNT_NORMALIZER = staticmethod(_normalize_inter_global_account_identifier)


class InterApexAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Inter Apex statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "inter_apex"),
        "agent": (str, False, "mm.data.elt.load.inter_apex"),
        "source": (str, False, "mm.data.elt.load.inter_apex"),
        "institution": (str, False, "APEX CLEARING CORPORATION"),
        "transaction_type": (str, False, "MOVIMENTACAO"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(INTER_APEX_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "INTER_APEX_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "INTER_APEX"
    DEFAULT_INPUT_MASKS = INTER_APEX_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".pdf": _parse_inter_apex_pdf,
    }
    RESEQUENCE_MONTHLY = False


class InterApexNcAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Inter Apex Nota de Corretagem."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "inter_apex_nc"),
        "agent": (str, False, "mm.data.elt.load.inter_apex_nc"),
        "source": (str, False, "mm.data.elt.load.inter_apex_nc"),
        "institution": (str, False, "APEX CLEARING CORPORATION"),
        "transaction_type": (str, False, "NEGOCIACAO"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(INTER_APEX_NC_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "INTER_APEX_NC_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "INTER_APEX_NC"
    DEFAULT_INPUT_MASKS = INTER_APEX_NC_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".pdf": _parse_inter_apex_nc_pdf,
    }
    RESEQUENCE_MONTHLY = False


def run_inter(progress_callback=None, **overrides):
    """Run Inter bank load pipeline."""
    processor = InterAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


def run_inter_global(progress_callback=None, **overrides):
    """Run Inter Global load pipeline."""
    processor = InterGlobalAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


def run_inter_apex(progress_callback=None, **overrides):
    """Run Inter Apex load pipeline."""
    processor = InterApexAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


def run_inter_apex_nc(progress_callback=None, **overrides):
    """Run Inter Apex NC load pipeline."""
    processor = InterApexNcAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


# =============================================================================
# Credit Card Load Processor
# =============================================================================


def _extract_parcelas(descricao: str) -> tuple[int, int]:
    """Extract parcela atual and total parcelas from description.

    Common patterns:
    - "1/12" -> (1, 12)
    - "Parcela 3 de 10" -> (3, 10)
    - "3/10" -> (3, 10)

    Returns (1, 1) if no parcela info found.
    """
    import re

    text = str(descricao or "").strip()

    # Pattern: X/Y (e.g., "1/12", "3/10")
    pattern1 = r'(\d+)\s*/\s*(\d+)'
    match = re.search(pattern1, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    # Pattern: "Parcela X de Y" or "Parcela X/Y"
    pattern2 = r'[Pp]arcela\s+(\d+)\s+(?:de|/)\s*(\d+)'
    match = re.search(pattern2, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    return 1, 1


def _is_credito_cartao(descricao: str) -> bool:
    """Check if transaction is a credit (payment/refund) on credit card.

    Keywords for credit:
    - Pagamento de fatura
    - Pagamento recebido
    - Pagamento efetuado
    - Estorno
    - Devolucao
    - Cashback
    """
    text = str(descricao or "").lower()

    credit_keywords = [
        "pagamento",
        "estorno",
        "devolucao",
        "devolução",
        "cashback",
        "credito",
        "crédito",
        "recebido",
        "recebi",
    ]

    for keyword in credit_keywords:
        if keyword in text:
            return True

    return False


def _parse_inter_cc_csv(file_path: str) -> pd.DataFrame:
    """Parse Inter credit card CSV statement.

    Expected columns (typical Inter CC CSV format):
    - Data, Estabelecimento, Descrição, Valor, Parcela
    Or:
    - Data, Descrição, Valor (with parcela info embedded in description)
    """
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 2:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    # Detect header line and data start
    header_line = 0
    data_start = 1

    for i, line in enumerate(csv_lines[:10]):
        lower = line.lower()
        if any(keyword in lower for keyword in ["data", "estabelecimento", "descri", "valor"]):
            header_line = i
            data_start = i + 1
            break

    # Parse header to detect column positions
    header = csv_lines[header_line].split(";") if header_line < len(csv_lines) else []
    header = [h.strip().lower() for h in header]

    # Map column positions
    col_map = {}
    for i, h in enumerate(header):
        if "data" in h:
            col_map["data"] = i
        elif "estabelecimento" in h or "descricao" in h or "descrição" in h or "lançamento" in h:
            col_map["descricao"] = i
        elif "valor" in h:
            col_map["valor"] = i
        elif "parcela" in h:
            col_map["parcela"] = i

    # Account info - credit card statements usually show card number
    conta = "INTER_CC"
    for line in csv_lines[:5]:
        if "cartao" in line.lower() or "cartão" in line.lower():
            # Try to extract card number
            parts = line.split(";")
            if len(parts) > 1:
                conta = parts[-1].strip()
                break

    csv_data = []
    seq = 0

    for line in csv_lines[data_start:]:
        if not line:
            continue

        raw = line.split(";")
        if len(raw) < 2:
            continue

        try:
            # Extract data
            data_str = raw[col_map.get("data", 0)].strip() if col_map.get("data") is not None else ""
            descricao = raw[col_map.get("descricao", 1)].strip() if col_map.get("descricao") else ""
            valor_str = raw[col_map.get("valor", 2)].strip() if col_map.get("valor") else ""

            # Parse parcela info
            parcela_col = col_map.get("parcela")
            if parcela_col is not None and parcela_col < len(raw):
                parcela_text = raw[parcela_col].strip()
                parcela_atual, total_parcelas = _extract_parcelas(f"{descricao} {parcela_text}")
            else:
                parcela_atual, total_parcelas = _extract_parcelas(descricao)

            # Parse date
            if data_str:
                parsed_date = pd.to_datetime(
                    datetime.strptime(data_str, "%d/%m/%Y").date()
                )
            else:
                continue

            # Parse value
            valor_float = _parse_number_br(valor_str)

            # Determine credit/debit based on description
            if _is_credito_cartao(descricao):
                dc = "C"  # Credit (payment/refund)
                valor_float = abs(valor_float)  # Ensure positive for credit
            else:
                dc = "D"  # Debit (purchase)
                valor_float = -abs(valor_float)  # Ensure negative for debit

            seq += 1
            csv_data.append((
                conta, seq, parsed_date, dc, descricao, valor_float, "BRL",
                parcela_atual, total_parcelas
            ))

        except Exception as exc:
            logger.error(
                f"Failed parsing INTER CC CSV row in file '{file_path}': {exc}. row={line}"
            )

    if not csv_data:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    data = pd.DataFrame(
        csv_data,
        columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda",
                 "parcela_atual", "total_parcelas"]
    ).sort_values(by=["data", "descricao", "valor"], ascending=True)

    return data.reset_index(drop=True)


def _parse_inter_cc_pdf(file_path: str) -> pd.DataFrame:
    """Parse Inter credit card PDF statement using domain-based extraction."""
    from mymoney.data.providers.inter.inter_cc_pdf import parse_inter_cc_pdf

    return parse_inter_cc_pdf(file_path)


def _map_cartao_rows_to_lancamentos(
    account_df: pd.DataFrame,
    *,
    institution: str,
    source: str,
    transaction_type: str,
    input_file: str,
    run_at: datetime,
) -> pd.DataFrame:
    """Map credit card DataFrame rows to lancamentos format."""
    if account_df is None or account_df.empty:
        return pd.DataFrame()

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]

    for row in account_df.itertuples(index=False):
        descricao = getattr(row, "descricao", "")
        dc = getattr(row, "dc", "D")

        # Determine movement type
        if dc.upper() == "C":
            entrada_saida = "Credito"
            movimentacao = "Pagamento Fatura"
            tipo_evento = "PAGAMENTO CC"
        else:
            entrada_saida = "Debito"
            movimentacao = "Compra Cartao"
            tipo_evento = "COMPRA CC"

        # Get parcela info
        parcela_atual = getattr(row, "parcela_atual", 1) or 1
        total_parcelas = getattr(row, "total_parcelas", 1) or 1

        # Split description into movement and product
        movement, product_name = _split_description(descricao)

        seq_value = getattr(row, "seq", None)
        seq_string = None
        try:
            if seq_value is not None and str(seq_value).strip() != "":
                seq_string = str(int(seq_value)).rjust(12, "0")
        except Exception:
            seq_string = str(seq_value).strip() if seq_value is not None else None

        rows.append({
            "entrada_saida": entrada_saida,
            "data_movimentacao": pd.to_datetime(getattr(row, "data", None), errors="coerce"),
            "movimentacao": movement if movement != "Lancamento em C/C" else movimentacao,
            "nome_produto": product_name,
            "codigo_produto": seq_string,
            "instituicao": institution,
            "conta": getattr(row, "conta", "INTER_CC"),
            "valor_operacao": abs(getattr(row, "valor", 0)),
            "quantidade_disponivel": float(parcela_atual),
            "quantidade_indisponivel": float(total_parcelas),
            "tipo_produto": "CARTAO CREDITO",
            "tipo_evento": tipo_evento,
            "tipo_lancamento": transaction_type,
            "moeda": getattr(row, "moeda", "BRL"),
            "origem": source,
            "arquivo_origem": file_name,
            "data_referencia": run_at,
        })

    xdf = pd.DataFrame(rows)
    xdf = _normalize_financial_identity(
        xdf,
        institution=institution,
        transaction_type=transaction_type,
    )
    return capitalize(xdf, "lower")


class InterCartaoLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Inter credit card statements (CSV/PDF)."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "inter_cartao"),
        "agent": (str, False, "mm.data.elt.load.inter_cartao"),
        "source": (str, False, "mm.data.elt.load.inter_cartao"),
        "institution": (str, False, "BANCO INTER S/A"),
        "transaction_type": (str, False, "LANCAMENTOS_CARTAO_CREDITO"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(INTER_CC_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "INTER_CC_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "INTER_CC"
    DEFAULT_INPUT_MASKS = INTER_CC_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".csv": _parse_inter_cc_csv,
        ".pdf": _parse_inter_cc_pdf,
    }
    RESEQUENCE_MONTHLY = False

    @staticmethod
    def _process_file_runner(
        scope: str,
        input_file: str,
        load_params: dict[str, Any],
    ) -> list[list[Any]]:
        """Override to use credit card specific row mapping."""
        unit_key = input_file
        recorder = get_operation_recorder()
        recorder.start_unit(
            load_params.get("operacao_id"),
            unidade=unit_key,
            escopo=scope,
            arquivo_origem=input_file,
            tipo_unidade=load_params["transaction_type"].lower(),
        )
        emit_debug_trace(
            f"_process_file_runner start scope={scope} file={input_file} transaction_type={load_params['transaction_type']}"
        )
        logger.info(
            "Starting CC load unit: scope=%s transaction_type=%s file=%s dry_run=%s",
            scope,
            load_params["transaction_type"],
            input_file,
            load_params["dry_run"],
        )
        summary = {
            "scope": scope,
            "kind": load_params["transaction_type"].lower(),
            "arquivo_origem": input_file,
            "schema": load_params["schema"],
            "table_name": load_params["table_name"],
            "operation": load_params["operation"],
            "dry_run": load_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
            "files_detected": 1,
            "files_parsed": 0,
            "files_renamed": 0,
            "parse_failures": 0,
        }

        run_at = datetime.now()

        try:
            ext = os.path.splitext(input_file)[1].lower()
            parser = load_params["parsers"].get(ext)
            if parser is None:
                error_message = f"{os.path.basename(input_file)}: unsupported extension '{ext}'"
                summary["failures"] = 1
                summary["parse_failures"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=False,
                    mensagem_erro=error_message,
                    dados=dict(summary),
                )
                return [[scope, False, error_message, pd.DataFrame([summary])]]

            account_df = parser(input_file)
            summary["files_parsed"] = 1

            output_df = _map_cartao_rows_to_lancamentos(
                account_df,
                institution=load_params["institution"],
                source=load_params["source"],
                transaction_type=load_params["transaction_type"],
                input_file=input_file,
                run_at=run_at,
            )

            if output_df.empty:
                summary["skips"] = 1
                if not load_params["dry_run"]:
                    _move_file_done(input_file, dry_run=False)
                    summary["files_renamed"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            if load_params.get("resequence_monthly", False):
                output_df = _resequence_monthly_codes(output_df)

            table_schema = get_schema(
                load_params["schema"], load_params["table_name"], env.SCHEMAS
            )
            normalized_data = _build_typed_lancamentos_dataframe(
                table_data=output_df,
                table_schema=table_schema,
            )
            summary["records"] = len(normalized_data)

            operation_result = {
                "insertions": 0,
                "updates": 0,
                "skips": 0,
                "failures": [],
            }
            if not load_params["dry_run"]:
                operation_result = batch_table_operation(
                    operation=load_params["operation"],
                    dataframe=normalized_data,
                    engine=env.DB_ENGINE,
                    schema=load_params["schema"],
                    table_name=load_params["table_name"],
                    table_schema=table_schema,
                    table_keys=["id"],
                    commit_at=1000,
                )

            db_failures = operation_result.get("failures", [])
            db_failure_count = (
                len(db_failures) if isinstance(db_failures, list) else int(bool(db_failures))
            )
            summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
            summary["updates"] = int(operation_result.get("updates", 0) or 0)
            summary["skips"] = int(operation_result.get("skips", 0) or 0)
            summary["failures"] = int(db_failure_count)

            if db_failure_count == 0 and not load_params["dry_run"]:
                _move_file_done(input_file, dry_run=False)
                summary["files_renamed"] = 1

            success = db_failure_count == 0
            error_message = None if success else f"{db_failure_count} row(s) failed on DB operation."
            emit_debug_trace(
                f"_process_file_runner finished scope={scope} file={input_file} success={success}"
            )
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]

        except Exception as exc:
            summary["failures"] = max(1, summary["failures"])
            summary["parse_failures"] = max(1, summary["parse_failures"])
            emit_debug_trace(f"_process_file_runner fatal scope={scope} file={input_file} error={exc}")
            logger.error("CC Load unit failed: scope=%s file=%s error=%s", scope, input_file, exc)
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]


def run_inter_cartao(progress_callback=None, **overrides):
    """Run Inter credit card load pipeline."""
    processor = InterCartaoLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
