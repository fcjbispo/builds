import os
from typing import Any, Callable, Optional

import numpy as np
import pandas as pd
from fbpyutils.uuid import hash_string
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation
from fbpyutils_db.database.schema import get_schema
from fbpyutils_db.database.types import apply_dtype
from infobr.data import DataProcessor, DataProvider
from infobr.data.process import ProcessWithCallback

from mymoney import env, logger
from mymoney.data.elt.load.folders import resolve_scoped_input_folder
from mymoney.data.providers.cei import OPERATIONS, _get_unprocessed_files
from mymoney.services.operations import get_operation_recorder


def _move_file_done(file_path: Optional[str], dry_run: bool = False) -> None:
    if not file_path or dry_run:
        return

    if os.path.exists(file_path):
        os.rename(file_path, f"{file_path}.done")


def _build_lancamentos_dataframe(
    agent: str, kind: str, table_data: pd.DataFrame, table_schema: list[tuple[Any, ...]]
) -> pd.DataFrame:
    table_keys = [s[2] for s in table_schema if s[4]]
    default_currency = env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")

    rows = []
    for input_row in table_data.itertuples(index=False):
        row = {}
        for _, _, column, data_type, _ in table_schema:
            if column == "tipo_lancamento":
                value = kind.upper()
            elif column == "moeda":
                value = default_currency
            elif column == "origem":
                value = agent
            else:
                value = getattr(input_row, column, None)

            # Handle datetime type separately for pd.NaT and invalid string values
            is_datetime = data_type == "datetime"
            is_null_string = (
                is_datetime
                and isinstance(value, str)
                and value.strip() in ("", "-", "N/A")
            )
            is_null_value = pd.isna(value) or is_null_string

            if not is_null_value and value is not None and not (
                isinstance(value, float) and np.isnan(value)
            ):
                row[column] = apply_dtype(str(value), data_type)
            elif is_datetime:
                row[column] = pd.NaT
            elif data_type in ("float", "float64", "int", "int64"):
                row[column] = np.nan
            else:
                row[column] = None

        row["usuario"] = env.USER
        row["id"] = hash_string(".".join([str(row.get(k, "~")) for k in table_keys]))
        rows.append(row)

    return capitalize(pd.DataFrame(rows), "lower")


class CeiDataProvider(DataProvider):
    EXPECTED_PARAMS = {
        "input_folder": (str, True, None),
        "parallelize": (bool, False, False),
    }

    def __init__(self, params: dict) -> None:
        merged = {"parallelize": False}
        merged.update(params or {})
        super().__init__(merged)

    def get_data(self) -> list[tuple[str, list[tuple[str, Callable[[list[str]], Optional[pd.DataFrame]]]]]]:
        file_map: dict[str, list[tuple[str, Callable[[list[str]], Optional[pd.DataFrame]]]]] = {}
        for kind, input_mask, processor, enabled in OPERATIONS:
            if not enabled:
                continue
            for file_path in _get_unprocessed_files(self.params["input_folder"], input_mask):
                file_map.setdefault(file_path, []).append((kind, processor))
        return sorted(file_map.items(), key=lambda item: item[0])


class CeiLoadDataProcessor(DataProcessor):
    VALID_OPERATIONS = ("append", "upsert", "replace")
    EXPECTED_PARAMS = {
        "scope": (str, False, "cei"),
        "agent": (str, False, "mm.data.elt.load.cei"),
        "input_folder": (str, False, None),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }

    def __init__(self, params: dict) -> None:
        merged = {k: v[2] for k, v in self.EXPECTED_PARAMS.items()}
        merged.update(params or {})
        merged["input_folder"] = resolve_scoped_input_folder(
            merged.get("input_folder"),
            scope_subfolder="CEI",
            fallback_config_keys=("CEI_DATA_FOLDER", "DATA_FOLDER_CEI"),
        )
        if not merged["input_folder"]:
            raise ValueError(
                "input_folder is required (or configure DATA_FOLDER in config.json)"
            )
        super().__init__(merged)

    def _check_params(self, params: dict) -> bool:
        if not super()._check_params(params):
            return False
        operation = params.get("operation")
        if operation not in self.VALID_OPERATIONS:
            logger.error(
                f"Invalid operation '{operation}'. Expected one of {self.VALID_OPERATIONS}"
            )
            return False
        return True

    @staticmethod
    def _process_scope_runner(
        scope: str,
        file_path: str,
        file_processors: list[tuple[str, Callable[[list[str]], Optional[pd.DataFrame]]]],
        load_params: dict[str, Any],
    ) -> list[list[Any]]:
        recorder = get_operation_recorder()
        recorder.start_unit(
            load_params.get("operacao_id"),
            unidade=file_path,
            escopo=scope,
            arquivo_origem=file_path,
            tipo_unidade="cei",
        )
        summary = {
            "scope": scope,
            "kind": "cei",
            "arquivo_origem": file_path,
            "schema": load_params["schema"],
            "table_name": load_params["table_name"],
            "operation": load_params["operation"],
            "dry_run": load_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
            "files_processed": 1,
            "kinds_processados": [],
        }

        try:
            table_schema = get_schema(
                load_params["schema"], load_params["table_name"], env.SCHEMAS
            )
            db_failures_total = 0
            empty_processors = 0

            for kind, processor in file_processors:
                table_data = processor([file_path])
                if table_data is None or len(table_data) == 0:
                    empty_processors += 1
                    continue

                normalized_data = _build_lancamentos_dataframe(
                    agent=load_params["agent"],
                    kind=kind,
                    table_data=table_data,
                    table_schema=table_schema,
                )
                summary["kinds_processados"].append(kind)
                summary["records"] += len(normalized_data)

                operation_result = {
                    "insertions": 0,
                    "updates": 0,
                    "skips": 0,
                    "failures": [],
                }
                if not load_params["dry_run"]:
                    operation_result = batch_table_operation(
                        operation=load_params["operation"],
                        dataframe=normalized_data,
                        engine=env.DB_ENGINE,
                        schema=load_params["schema"],
                        table_name=load_params["table_name"],
                        table_schema=table_schema,
                        table_keys=["id"],
                        commit_at=1000,
                    )

                failures = operation_result.get("failures", [])
                failure_count = (
                    len(failures) if isinstance(failures, list) else int(bool(failures))
                )
                db_failures_total += failure_count
                summary["insertions"] += int(operation_result.get("insertions", 0) or 0)
                summary["updates"] += int(operation_result.get("updates", 0) or 0)
                summary["skips"] += int(operation_result.get("skips", 0) or 0)

            if empty_processors == len(file_processors):
                summary["skips"] = max(1, summary["skips"])

            summary["failures"] = int(db_failures_total)
            success = db_failures_total == 0
            error_message = (
                None if success else f"{db_failures_total} row(s) failed on DB operation."
            )

            if success and not load_params["dry_run"]:
                _move_file_done(file_path, dry_run=False)

            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=file_path,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]
        except Exception as exc:
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=file_path,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]

    def run(
        self, progress_callback=None
    ) -> list[list[list[Any]]]:
        provider = CeiDataProvider(
            {
                "input_folder": self.params["input_folder"],
                "parallelize": self.params.get("parallelize", False),
            }
        )
        cei_data = provider.get_data()

        process_params = [
            (
                self.params.get("scope", "cei"),
                file_path,
                file_processors,
                {
                    "agent": self.params["agent"],
                    "schema": self.params["schema"],
                    "table_name": self.params["table_name"],
                    "operation": self.params["operation"],
                    "dry_run": self.params.get("dry_run", False),
                    "operacao_id": self.params.get("operacao_id"),
                },
            )
            for file_path, file_processors in cei_data
        ]

        if not process_params:
            return [
                [
                    [
                        self.params.get("scope", "cei"),
                        True,
                        None,
                        pd.DataFrame(
                            [
                                {
                                    "scope": self.params.get("scope", "cei"),
                                    "kind": "cei",
                                    "records": 0,
                                    "insertions": 0,
                                    "updates": 0,
                                    "skips": 1,
                                    "failures": 0,
                                    "files_processed": 0,
                                    "dry_run": self.params.get("dry_run", False),
                                }
                            ]
                        ),
                    ]
                ]
            ]

        process = ProcessWithCallback(
            process=self._process_scope_runner,
            parallelize=self.params.get("parallelize", False),
            workers=(
                ProcessWithCallback.get_available_cpu_count()
                if self.params.get("parallelize", False)
                else 1
            ),
            progress_callback=progress_callback,
        )
        return process.run(process_params, progress=self.params.get("progress", False))


def run(progress_callback=None, **overrides):
    processor = CeiLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
