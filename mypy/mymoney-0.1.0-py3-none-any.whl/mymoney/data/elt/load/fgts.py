"""FGTS load processor for LANCAMENTOS_CONTA_CORRENTE."""

from __future__ import annotations

import pandas as pd

from mymoney.data.elt.load.base import AccountLoadDataProcessor
from mymoney.data.providers.cef import (
    CEF_CC_DEFAULT_MASKS,
    CEF_INSTITUTION,
    parse_fgts,
)


def _parse_fgts_file(file_path: str) -> pd.DataFrame:
    """Parse FGTS statement (PDF, DOCX, or MD) using domain-based extraction."""
    return parse_fgts(file_path)


class FgtsLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for FGTS statements from Caixa Economica Federal.

    Processes FGTS (Fundo de Garantia do Tempo de Serviço) statements
    exported from the Caixa app in PDF, DOCX, or MD formats.

    PDF is the primary format as of 2025. DOCX and MD are supported as fallbacks.

    The FGTS is treated as a checking account (LANCAMENTOS_CONTA_CORRENTE)
    with tipo_produto = "FGTS".
    """

    EXPECTED_PARAMS = {
        "scope": (str, False, "fgts"),
        "agent": (str, False, "mm.data.elt.load.cef_fgts"),
        "source": (str, False, "mm.data.elt.load.cef_fgts"),
        "institution": (str, False, CEF_INSTITUTION),
        "transaction_type": (str, False, "LANCAMENTOS_CONTA_CORRENTE"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(CEF_CC_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "use_native_pdf": (bool, False, False),
        "use_vision": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "CEF_FGTS_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "FGTS"
    DEFAULT_INPUT_MASKS = CEF_CC_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".pdf": _parse_fgts_file,
        ".docx": _parse_fgts_file,
        ".md": _parse_fgts_file,
    }
    RESEQUENCE_MONTHLY = True


def run_fgts(progress_callback=None, **overrides):
    """Run FGTS load pipeline.

    Args:
        progress_callback: Optional callback for progress updates
        **overrides: Optional parameter overrides

    Returns:
        List of processing results
    """
    processor = FgtsLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
