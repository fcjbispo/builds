"""NEXT load processor for LANCAMENTOS_CONTA_CORRENTE and LANCAMENTOS_CARTAO_CREDITO."""

from __future__ import annotations

import os
import re
from datetime import datetime
from typing import Any

import pandas as pd

from mymoney import emit_debug_trace, env, logger
from mymoney.data.elt.load.base import (
    AccountLoadDataProcessor,
    _build_typed_lancamentos_dataframe,
    _move_file_done,
    _normalize_financial_identity,
)
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation
from fbpyutils_db.database.schema import get_schema
from mymoney.data.providers.next import (
    NEXT_CC_DEFAULT_MASKS,
    NEXT_DEFAULT_MASKS,
    NEXT_INSTITUTION,
    parse_next_pdf,
    parse_next_cc_pdf,
)
from mymoney.services.operations import get_operation_recorder


def _parse_next_pdf(
    file_path: str,
    *,
    pdf_password_required: bool = True,
):
    return parse_next_pdf(
        file_path,
        pdf_password_required=pdf_password_required,
    )


def _extract_parcelas(descricao: str) -> tuple[int, int]:
    """Extract parcela atual and total parcelas from description.

    Common patterns:
    - "1/12" -> (1, 12)
    - "Parcela 3 de 10" -> (3, 10)
    - "3/10" -> (3, 10)

    Returns (1, 1) if no parcela info found.
    """
    text = str(descricao or "").strip()

    # Pattern: X/Y (e.g., "1/12", "3/10")
    pattern1 = r'(\d+)\s*/\s*(\d+)'
    match = re.search(pattern1, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    # Pattern: "Parcela X de Y" or "Parcela X/Y"
    pattern2 = r'[Pp]arcela\s+(\d+)\s+(?:de|/)\s*(\d+)'
    match = re.search(pattern2, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    return 1, 1


def _is_credito_cartao(descricao: str) -> bool:
    """Check if transaction is a credit (payment/refund) on credit card.

    Keywords for credit:
    - Pagamento de fatura
    - Pagamento recebido
    - Pagamento efetuado
    - Estorno
    - Devolucao
    - Cashback
    """
    text = str(descricao or "").lower()

    credit_keywords = [
        "pagamento",
        "estorno",
        "devolucao",
        "devolução",
        "cashback",
        "credito",
        "crédito",
        "recebido",
        "recebi",
    ]

    for keyword in credit_keywords:
        if keyword in text:
            return True

    return False


def _split_description(description: Any) -> tuple[str, str]:
    """Split description into movement and product name."""
    text = str(description or "").strip()
    if "::" in text:
        first, second = text.split("::", 1)
        return first.strip() or "Lancamento em C/C", second.strip()
    return "Lancamento em C/C", text


def _map_next_cc_rows_to_lancamentos(
    account_df: pd.DataFrame,
    *,
    institution: str,
    source: str,
    transaction_type: str,
    input_file: str,
    run_at: datetime,
) -> pd.DataFrame:
    """Map NEXT credit card DataFrame rows to lancamentos format."""
    if account_df is None or account_df.empty:
        return pd.DataFrame()

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]

    for row in account_df.itertuples(index=False):
        descricao = getattr(row, "descricao", "")
        dc = getattr(row, "dc", "D")

        # Determine movement type
        if dc.upper() == "C":
            entrada_saida = "Credito"
            movimentacao = "Pagamento Fatura"
            tipo_evento = "PAGAMENTO CC"
        else:
            entrada_saida = "Debito"
            movimentacao = "Compra Cartao"
            tipo_evento = "COMPRA CC"

        # Get parcela info
        parcela_atual = getattr(row, "parcela_atual", 1) or 1
        total_parcelas = getattr(row, "total_parcelas", 1) or 1

        # If not already set, try to extract from description
        if parcela_atual == 1 and total_parcelas == 1:
            parcela_atual, total_parcelas = _extract_parcelas(descricao)

        # Split description into movement and product
        movement, product_name = _split_description(descricao)

        seq_value = getattr(row, "seq", None)
        seq_string = None
        try:
            if seq_value is not None and str(seq_value).strip() != "":
                seq_string = str(int(seq_value)).rjust(12, "0")
        except Exception:
            seq_string = str(seq_value).strip() if seq_value is not None else None

        rows.append({
            "entrada_saida": entrada_saida,
            "data_movimentacao": pd.to_datetime(getattr(row, "data", None), errors="coerce"),
            "movimentacao": movement if movement != "Lancamento em C/C" else movimentacao,
            "nome_produto": product_name,
            "codigo_produto": seq_string,
            "instituicao": institution,
            "conta": getattr(row, "conta", "NEXT_CC"),
            "valor_operacao": abs(getattr(row, "valor", 0)),
            "quantidade_disponivel": float(parcela_atual),
            "quantidade_indisponivel": float(total_parcelas),
            "tipo_produto": "CARTAO CREDITO",
            "tipo_evento": tipo_evento,
            "tipo_lancamento": transaction_type,
            "moeda": getattr(row, "moeda", "BRL"),
            "origem": source,
            "arquivo_origem": file_name,
            "data_referencia": run_at,
        })

    xdf = pd.DataFrame(rows)
    xdf = _normalize_financial_identity(
        xdf,
        institution=institution,
        transaction_type=transaction_type,
    )
    return capitalize(xdf, "lower")


class NextAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for NEXT account statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "next"),
        "agent": (str, False, "mm.data.elt.load.next"),
        "source": (str, False, "mm.data.elt.load.next"),
        "institution": (str, False, NEXT_INSTITUTION),
        "transaction_type": (str, False, "LANCAMENTOS_CONTA_CORRENTE"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(NEXT_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pdf_password_required": (bool, False, True),
        "use_native_pdf": (bool, False, False),
        "use_vision": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "NEXT_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "NEXT"
    DEFAULT_INPUT_MASKS = NEXT_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".pdf": _parse_next_pdf,
    }
    RESEQUENCE_MONTHLY = False


class NextCartaoLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for NEXT credit card statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "next_cartao"),
        "agent": (str, False, "mm.data.elt.load.next_cartao"),
        "source": (str, False, "mm.data.elt.load.next_cartao"),
        "institution": (str, False, NEXT_INSTITUTION),
        "transaction_type": (str, False, "LANCAMENTOS_CARTAO_CREDITO"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(NEXT_CC_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pdf_password_required": (bool, False, True),
        "use_native_pdf": (bool, False, False),
        "use_vision": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "NEXT_CC_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "NEXT_CC"
    DEFAULT_INPUT_MASKS = NEXT_CC_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".pdf": parse_next_cc_pdf,
    }
    RESEQUENCE_MONTHLY = False

    @staticmethod
    def _process_file_runner(
        scope: str,
        input_file: str,
        load_params: dict[str, Any],
    ) -> list[list[Any]]:
        """Override to use credit card specific row mapping."""
        unit_key = input_file
        recorder = get_operation_recorder()
        recorder.start_unit(
            load_params.get("operacao_id"),
            unidade=unit_key,
            escopo=scope,
            arquivo_origem=input_file,
            tipo_unidade=load_params["transaction_type"].lower(),
        )
        emit_debug_trace(
            f"_process_file_runner start scope={scope} file={input_file} transaction_type={load_params['transaction_type']}"
        )
        logger.info(
            "Starting CC load unit: scope=%s transaction_type=%s file=%s dry_run=%s",
            scope,
            load_params["transaction_type"],
            input_file,
            load_params["dry_run"],
        )
        summary = {
            "scope": scope,
            "kind": load_params["transaction_type"].lower(),
            "arquivo_origem": input_file,
            "schema": load_params["schema"],
            "table_name": load_params["table_name"],
            "operation": load_params["operation"],
            "dry_run": load_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
            "files_detected": 1,
            "files_parsed": 0,
            "files_renamed": 0,
            "parse_failures": 0,
        }

        run_at = datetime.now()

        try:
            ext = os.path.splitext(input_file)[1].lower()
            parser = load_params["parsers"].get(ext)
            if parser is None:
                error_message = f"{os.path.basename(input_file)}: unsupported extension '{ext}'"
                summary["failures"] = 1
                summary["parse_failures"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=False,
                    mensagem_erro=error_message,
                    dados=dict(summary),
                )
                return [[scope, False, error_message, pd.DataFrame([summary])]]

            account_df = parser(input_file)
            summary["files_parsed"] = 1

            output_df = _map_next_cc_rows_to_lancamentos(
                account_df,
                institution=load_params["institution"],
                source=load_params["source"],
                transaction_type=load_params["transaction_type"],
                input_file=input_file,
                run_at=run_at,
            )

            if output_df.empty:
                summary["skips"] = 1
                if not load_params["dry_run"]:
                    _move_file_done(input_file, dry_run=False)
                    summary["files_renamed"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            table_schema = get_schema(
                load_params["schema"], load_params["table_name"], env.SCHEMAS
            )
            normalized_data = _build_typed_lancamentos_dataframe(
                table_data=output_df,
                table_schema=table_schema,
            )
            summary["records"] = len(normalized_data)

            operation_result = {
                "insertions": 0,
                "updates": 0,
                "skips": 0,
                "failures": [],
            }
            if not load_params["dry_run"]:
                operation_result = batch_table_operation(
                    operation=load_params["operation"],
                    dataframe=normalized_data,
                    engine=env.DB_ENGINE,
                    schema=load_params["schema"],
                    table_name=load_params["table_name"],
                    table_schema=table_schema,
                    table_keys=["id"],
                    commit_at=1000,
                )

            db_failures = operation_result.get("failures", [])
            db_failure_count = (
                len(db_failures) if isinstance(db_failures, list) else int(bool(db_failures))
            )
            summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
            summary["updates"] = int(operation_result.get("updates", 0) or 0)
            summary["skips"] = int(operation_result.get("skips", 0) or 0)
            summary["failures"] = int(db_failure_count)

            if db_failure_count == 0 and not load_params["dry_run"]:
                _move_file_done(input_file, dry_run=False)
                summary["files_renamed"] = 1

            success = db_failure_count == 0
            error_message = None if success else f"{db_failure_count} row(s) failed on DB operation."
            emit_debug_trace(
                f"_process_file_runner finished scope={scope} file={input_file} success={success}"
            )
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]

        except Exception as exc:
            summary["failures"] = max(1, summary["failures"])
            summary["parse_failures"] = max(1, summary["parse_failures"])
            emit_debug_trace(f"_process_file_runner fatal scope={scope} file={input_file} error={exc}")
            logger.error("CC Load unit failed: scope=%s file=%s error=%s", scope, input_file, exc)
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]


def run_next(progress_callback=None, **overrides):
    """Run NEXT load pipeline."""
    processor = NextAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


def run_next_cartao(progress_callback=None, **overrides):
    """Run NEXT credit card load pipeline."""
    processor = NextCartaoLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
