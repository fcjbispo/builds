from typing import Optional

LOAD_PIPELINE_MAP = {
    "cei": "mymoney.load.cei",
    "data": "mymoney.load.data",
    "inter": "mymoney.load.inter",
    "inter_global": "mymoney.load.inter_global",
    "inter-global": "mymoney.load.inter_global",
    "inter_cartao": "mymoney.load.inter_cartao",
    "inter-cartao": "mymoney.load.inter_cartao",
    "picpay": "mymoney.load.picpay",
    "picpay_cartao": "mymoney.load.picpay_cartao",
    "picpay-cartao": "mymoney.load.picpay_cartao",
    "mercado_pago": "mymoney.load.mercado_pago",
    "mercado-pago": "mymoney.load.mercado_pago",
    "mercado_pago_cartao": "mymoney.load.mercado_pago_cartao",
    "mercado-pago-cartao": "mymoney.load.mercado_pago_cartao",
    "nubank": "mymoney.load.nubank",
    "nubank_cartao": "mymoney.load.nubank_cartao",
    "nubank-cartao": "mymoney.load.nubank_cartao",
    "next": "mymoney.load.next",
    "next_cartao": "mymoney.load.next_cartao",
    "next-cartao": "mymoney.load.next_cartao",
    "fgts": "mymoney.load.fgts",
}


def run_load(
    load_name: Optional[str] = None,
    parallelize: bool = True,
    progress: bool = False,
    dry_run: bool = False,
):
    from mymoney.data.elt.pipeline import run_pipelines

    if load_name:
        pipeline_name = LOAD_PIPELINE_MAP.get(load_name, load_name)
        pipeline_names = [pipeline_name]
    else:
        pipeline_names = list(LOAD_PIPELINE_MAP.values())

    return run_pipelines(
        pipeline_names=pipeline_names,
        parallelize=parallelize,
        progress=progress,
        dry_run=dry_run,
    )
