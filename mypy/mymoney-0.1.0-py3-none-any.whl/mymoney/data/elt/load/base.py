"""Base classes and utilities for account statement load processors."""

from __future__ import annotations

import os
import inspect
import re
from datetime import datetime
from typing import Any, Callable, Optional

import numpy as np
import pandas as pd
from fbpyutils.uuid import hash_string
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation
from fbpyutils_db.database.schema import get_schema
from fbpyutils_db.database.types import apply_dtype
from infobr.data import DataProcessor, DataProvider
from infobr.data.process import ProcessWithCallback

from mymoney import emit_debug_trace, env, logger
from mymoney.data.elt.load.folders import resolve_scoped_input_folder
from mymoney.services.operations import get_operation_recorder

_CANONICAL_IDENTITY_TRANSACTION_TYPES = {
    "LANCAMENTOS_CONTA_CORRENTE",
    "LANCAMENTOS_CARTAO_CREDITO",
}


def _read_lines(file_path: str) -> list[str]:
    """Read file lines trying multiple encodings."""
    for encoding in ("utf-8", "latin-1"):
        try:
            with open(file_path, "r", encoding=encoding) as f:
                return [line.strip() for line in f]
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Unable to decode file '{file_path}' as utf-8 or latin-1.")


def _parse_number_br(value: str) -> float:
    """Parse Brazilian number format (e.g., '1.234,56' -> 1234.56)."""
    return float(str(value).replace(".", "").replace(",", "."))


def _split_description(description: Any) -> tuple[str, str]:
    """Split description into movement and product name."""
    text = str(description or "").strip()
    if "::" in text:
        first, second = text.split("::", 1)
        return first.strip() or "Lancamento em C/C", second.strip()
    return "Lancamento em C/C", text


def _normalize_statement_institution(value: Any) -> str | None:
    text = re.sub(r"\s+", " ", str(value or "").strip())
    return text or None


def _normalize_statement_account(value: Any) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    text = re.sub(r"\s+", "", text)
    text = re.sub(r"[.]{2,}", ".", text)
    text = re.sub(r"[-]{2,}", "-", text)
    return text or None


def _normalize_financial_identity(
    dataframe: pd.DataFrame,
    *,
    institution: str,
    transaction_type: str,
    account_normalizer: Optional[Callable[[Any], Any]] = None,
) -> pd.DataFrame:
    if dataframe is None or dataframe.empty:
        return dataframe

    if transaction_type not in _CANONICAL_IDENTITY_TRANSACTION_TYPES:
        return dataframe

    xdf = dataframe.copy()

    canonical_institution = _normalize_statement_institution(institution)
    if canonical_institution:
        xdf["instituicao"] = canonical_institution
    elif "instituicao" in xdf.columns:
        xdf["instituicao"] = xdf["instituicao"].apply(_normalize_statement_institution)

    if "conta" not in xdf.columns:
        xdf["conta"] = None

    xdf["conta"] = xdf["conta"].apply(_normalize_statement_account)
    if account_normalizer is not None:
        xdf["conta"] = xdf["conta"].apply(account_normalizer)
        xdf["conta"] = xdf["conta"].apply(_normalize_statement_account)

    return xdf


def _move_file_done(file_path: Optional[str], dry_run: bool = False) -> None:
    """Mark file as done by renaming with .done suffix."""
    if not file_path or dry_run:
        return
    if os.path.exists(file_path):
        os.rename(file_path, f"{file_path}.done")


def _build_typed_lancamentos_dataframe(
    table_data: pd.DataFrame,
    table_schema: list[tuple[Any, ...]],
) -> pd.DataFrame:
    """Build typed DataFrame from parsed data according to schema."""
    table_keys = [s[2] for s in table_schema if s[4]]
    default_currency = env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")

    rows = []
    for input_row in table_data.itertuples(index=False):
        row = {}
        for _, _, column, data_type, _ in table_schema:
            value = getattr(input_row, column, None)
            if column == "moeda" and (value is None or str(value).strip() == ""):
                value = default_currency

            is_datetime = data_type == "datetime"
            is_null_string = (
                is_datetime
                and isinstance(value, str)
                and value.strip() in ("", "-", "N/A")
            )
            is_null_value = pd.isna(value) or is_null_string

            if not is_null_value and value is not None and not (
                isinstance(value, float) and np.isnan(value)
            ):
                row[column] = apply_dtype(str(value), data_type)
            elif is_datetime:
                row[column] = pd.NaT
            elif data_type in ("float", "float64", "int", "int64"):
                row[column] = np.nan
            else:
                row[column] = None

        row["usuario"] = env.USER
        row["id"] = hash_string(".".join([str(row.get(k, "~")) for k in table_keys]))
        rows.append(row)

    return capitalize(pd.DataFrame(rows), "lower")


def _map_account_rows_to_lancamentos(
    account_df: pd.DataFrame,
    *,
    institution: str,
    source: str,
    transaction_type: str,
    input_file: str,
    run_at: datetime,
    account_normalizer: Optional[Callable[[Any], Any]] = None,
) -> pd.DataFrame:
    """Map account DataFrame rows to lancamentos format."""
    if account_df is None or account_df.empty:
        return pd.DataFrame()

    direct_required_columns = {"movimentacao", "nome_produto", "valor_operacao"}
    direct_has_supported_date = bool(
        {"data_movimentacao", "data_negocio"}.intersection(set(account_df.columns))
    )
    if direct_required_columns.issubset(set(account_df.columns)) and direct_has_supported_date:
        xdf = account_df.copy()
        if "entrada_saida" not in xdf.columns:
            xdf["entrada_saida"] = None
        if "data_movimentacao" not in xdf.columns:
            xdf["data_movimentacao"] = None
        if "data_negocio" not in xdf.columns:
            xdf["data_negocio"] = None
        if "conta" not in xdf.columns:
            xdf["conta"] = None
        if "instituicao" not in xdf.columns:
            xdf["instituicao"] = institution
        xdf["instituicao"] = xdf["instituicao"].fillna(institution)
        xdf["origem"] = xdf.get("origem", source)
        xdf["origem"] = xdf["origem"].fillna(source)
        xdf["tipo_lancamento"] = transaction_type
        xdf["moeda"] = xdf.get("moeda", None)
        xdf["moeda"] = xdf["moeda"].fillna(
            env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")
        )
        default_tipo_produto = (
            "CONTA CORRENTE"
            if transaction_type == "LANCAMENTOS_CONTA_CORRENTE"
            else None
        )
        default_tipo_evento = (
            "LANCAMENTO C/C"
            if transaction_type == "LANCAMENTOS_CONTA_CORRENTE"
            else None
        )
        if "tipo_produto" not in xdf.columns:
            xdf["tipo_produto"] = default_tipo_produto
        elif default_tipo_produto is not None:
            xdf["tipo_produto"] = xdf["tipo_produto"].fillna(default_tipo_produto)
        if "tipo_evento" not in xdf.columns:
            xdf["tipo_evento"] = default_tipo_evento
        elif default_tipo_evento is not None:
            xdf["tipo_evento"] = xdf["tipo_evento"].fillna(default_tipo_evento)
        if "arquivo_origem" not in xdf.columns:
            xdf["arquivo_origem"] = os.path.basename(input_file).split(".")[0]
        xdf["arquivo_origem"] = xdf["arquivo_origem"].fillna(
            os.path.basename(input_file).split(".")[0]
        )
        if "data_referencia" not in xdf.columns:
            xdf["data_referencia"] = run_at
        xdf["data_referencia"] = xdf["data_referencia"].fillna(run_at)
        xdf = _normalize_financial_identity(
            xdf,
            institution=institution,
            transaction_type=transaction_type,
            account_normalizer=account_normalizer,
        )
        return capitalize(xdf, "lower")

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]
    for row in account_df.itertuples(index=False):
        movement, product_name = _split_description(getattr(row, "descricao", None))
        seq_value = getattr(row, "seq", None)
        seq_string = None
        try:
            if seq_value is not None and str(seq_value).strip() != "":
                seq_string = str(int(seq_value)).rjust(12, "0")
        except Exception:
            seq_string = str(seq_value).strip() if seq_value is not None else None

        rows.append(
            {
                "entrada_saida": (
                    "Credito" if str(getattr(row, "dc", "D")).upper() == "C" else "Debito"
                ),
                "data_movimentacao": pd.to_datetime(
                    getattr(row, "data", None), errors="coerce"
                ),
                "movimentacao": movement,
                "nome_produto": product_name,
                "codigo_produto": seq_string,
                "instituicao": institution,
                "conta": getattr(row, "conta", None),
                "valor_operacao": getattr(row, "valor", None),
                "tipo_produto": "CONTA CORRENTE",
                "tipo_evento": "LANCAMENTO C/C",
                "tipo_lancamento": transaction_type,
                "moeda": getattr(row, "moeda", None),
                "origem": source,
                "arquivo_origem": file_name,
                "data_referencia": run_at,
            }
        )

    xdf = pd.DataFrame(rows)
    xdf = _normalize_financial_identity(
        xdf,
        institution=institution,
        transaction_type=transaction_type,
        account_normalizer=account_normalizer,
    )
    return capitalize(xdf, "lower")


def _resequence_monthly_codes(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Re-sequence monthly transaction codes for ordering."""
    if dataframe is None or dataframe.empty:
        return dataframe

    xdf = dataframe.copy()
    xdf["data_movimentacao"] = pd.to_datetime(
        xdf["data_movimentacao"], errors="coerce"
    )
    xdf["mes_movimentacao"] = (
        xdf["data_movimentacao"].dt.strftime("%Y-%m").fillna("0000-00")
    )
    xdf = xdf.sort_values(
        by=[
            "mes_movimentacao",
            "data_movimentacao",
            "movimentacao",
            "nome_produto",
            "valor_operacao",
        ],
        ascending=[True, False, True, True, True],
        na_position="last",
    ).copy()
    xdf["codigo_produto"] = (
        xdf.groupby("mes_movimentacao")
        .cumcount()
        .add(1)
        .map(lambda value: str(value).rjust(12, "0"))
    )
    return xdf.drop(columns=["mes_movimentacao"])


def _run_load_file(
    scope: str,
    input_file: str,
    load_params: dict[str, Any],
) -> list[list[Any]]:
    """Run load for a single file with error handling."""
    unit_key = input_file
    recorder = get_operation_recorder()
    recorder.start_unit(
        load_params.get("operacao_id"),
        unidade=unit_key,
        escopo=scope,
        arquivo_origem=input_file,
        tipo_unidade=load_params["transaction_type"].lower(),
    )
    emit_debug_trace(
        f"_run_load_file start scope={scope} file={input_file} transaction_type={load_params['transaction_type']}"
    )
    logger.info(
        "Starting load unit: scope=%s transaction_type=%s file=%s dry_run=%s parallelize=%s",
        scope,
        load_params["transaction_type"],
        input_file,
        load_params["dry_run"],
        load_params.get("parallelize"),
    )
    summary = {
        "scope": scope,
        "kind": load_params["transaction_type"].lower(),
        "arquivo_origem": input_file,
        "schema": load_params["schema"],
        "table_name": load_params["table_name"],
        "operation": load_params["operation"],
        "dry_run": load_params["dry_run"],
        "records": 0,
        "insertions": 0,
        "updates": 0,
        "skips": 0,
        "failures": 0,
        "files_detected": 1,
        "files_parsed": 0,
        "files_renamed": 0,
        "parse_failures": 0,
    }

    run_at = datetime.now()

    try:
        ext = os.path.splitext(input_file)[1].lower()
        parser = load_params["parsers"].get(ext)
        if parser is None:
            error_message = f"{os.path.basename(input_file)}: unsupported extension '{ext}'"
            summary["failures"] = 1
            summary["parse_failures"] = 1
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, False, error_message, pd.DataFrame([summary])]]

        emit_debug_trace(f"_run_load_file parsing file scope={scope} file={input_file}")
        logger.info(
            "Parsing file: scope=%s file=%s parser=%s",
            scope,
            input_file,
            getattr(parser, "__name__", str(parser)),
        )
        parser_kwargs = dict(load_params.get("parser_kwargs") or {})

        # Validate use_native_pdf and use_vision combinations
        use_native_pdf = parser_kwargs.get("use_native_pdf", False)
        use_vision = parser_kwargs.get("use_vision", False)

        if use_vision and not use_native_pdf:
            logger.warning(
                "use_vision=True requires use_native_pdf=True for file=%s. Disabling vision.",
                input_file,
            )
            parser_kwargs["use_vision"] = False
            use_vision = False

        if use_vision and ext != ".pdf":
            logger.warning(
                "use_vision=True requires .pdf extension for file=%s. Disabling vision.",
                input_file,
            )
            parser_kwargs["use_vision"] = False
            use_vision = False

        # Log model being used
        if use_native_pdf:
            model_name = env.USER_CONFIG.get("LLM_VISION_MODEL") if use_vision else env.USER_CONFIG.get("LLM_BASE_MODEL")
            logger.info(
                "Using LLM model: %s (native_pdf=%s, vision=%s)",
                model_name,
                use_native_pdf,
                use_vision,
            )

        if parser_kwargs:
            parser_signature = inspect.signature(parser)
            parser_parameters = parser_signature.parameters
            supports_kwargs = any(
                parameter.kind == inspect.Parameter.VAR_KEYWORD
                for parameter in parser_parameters.values()
            )
            if not supports_kwargs:
                parser_kwargs = {
                    key: value
                    for key, value in parser_kwargs.items()
                    if key in parser_parameters
                }
        account_df = parser(input_file, **parser_kwargs)
        summary["files_parsed"] = 1
        logger.info(
            "Parsed file: scope=%s file=%s rows=%s",
            scope,
            input_file,
            0 if account_df is None else len(account_df),
        )
        output_df = _map_account_rows_to_lancamentos(
            account_df,
            institution=load_params["institution"],
            source=load_params["source"],
            transaction_type=load_params["transaction_type"],
            input_file=input_file,
            run_at=run_at,
            account_normalizer=load_params.get("account_normalizer"),
        )
        if output_df.empty:
            summary["skips"] = 1
            if not load_params["dry_run"]:
                _move_file_done(input_file, dry_run=False)
                summary["files_renamed"] = 1
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=True,
                mensagem_erro=None,
                dados=dict(summary),
            )
            return [[scope, True, None, pd.DataFrame([summary])]]

        if load_params.get("resequence_monthly", False):
            output_df = _resequence_monthly_codes(output_df)

        table_schema = get_schema(
            load_params["schema"], load_params["table_name"], env.SCHEMAS
        )
        normalized_data = _build_typed_lancamentos_dataframe(
            table_data=output_df,
            table_schema=table_schema,
        )
        summary["records"] = len(normalized_data)
        logger.info(
            "Normalized dataframe ready: scope=%s file=%s records=%s",
            scope,
            input_file,
            len(normalized_data),
        )

        operation_result = {
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [],
        }
        if not load_params["dry_run"]:
            operation_result = batch_table_operation(
                operation=load_params["operation"],
                dataframe=normalized_data,
                engine=env.DB_ENGINE,
                schema=load_params["schema"],
                table_name=load_params["table_name"],
                table_schema=table_schema,
                table_keys=["id"],
                commit_at=1000,
            )

        db_failures = operation_result.get("failures", [])
        db_failure_count = (
            len(db_failures) if isinstance(db_failures, list) else int(bool(db_failures))
        )
        summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
        summary["updates"] = int(operation_result.get("updates", 0) or 0)
        summary["skips"] = int(operation_result.get("skips", 0) or 0)
        summary["failures"] = int(db_failure_count)

        if db_failure_count == 0 and not load_params["dry_run"]:
            _move_file_done(input_file, dry_run=False)
            summary["files_renamed"] = 1
            logger.info("Marked file as done: scope=%s file=%s", scope, input_file)

        success = db_failure_count == 0
        error_message = None if success else f"{db_failure_count} row(s) failed on DB operation."
        logger.info(
            "Finished load unit: scope=%s file=%s success=%s parsed=%s records=%s failures=%s",
            scope,
            input_file,
            success,
            summary["files_parsed"],
            summary["records"],
            summary["failures"],
        )
        emit_debug_trace(
            f"_run_load_file finished scope={scope} file={input_file} success={success} parsed={summary['files_parsed']} records={summary['records']}"
        )
        recorder.finish_unit(
            load_params.get("operacao_id"),
            unidade=unit_key,
            sucesso=success,
            mensagem_erro=error_message,
            dados=dict(summary),
        )
        return [[scope, success, error_message, pd.DataFrame([summary])]]
    except Exception as exc:
        summary["failures"] = max(1, summary["failures"])
        summary["parse_failures"] = max(1, summary["parse_failures"])
        emit_debug_trace(f"_run_load_file fatal scope={scope} file={input_file} error={exc}")
        logger.error("Load unit failed: scope=%s file=%s error=%s", scope, input_file, exc)
        recorder.finish_unit(
            load_params.get("operacao_id"),
            unidade=unit_key,
            sucesso=False,
            mensagem_erro=str(exc),
            dados=dict(summary),
        )
        return [[scope, False, str(exc), pd.DataFrame([summary])]]


class AccountFileDataProvider(DataProvider):
    """Data provider for listing unprocessed account files."""

    EXPECTED_PARAMS = {
        "input_folder": (str, True, None),
        "input_masks": (list, False, []),
    }

    def __init__(self, params: dict) -> None:
        from mymoney.data.providers.inter import list_unprocessed_files

        merged = {"input_masks": []}
        merged.update(params or {})
        super().__init__(merged)

    def get_data(self) -> list[str]:
        from mymoney.data.providers.inter import list_unprocessed_files

        return list_unprocessed_files(
            self.params["input_folder"],
            self.params.get("input_masks") or [],
        )


class AccountLoadDataProcessor(DataProcessor):
    """Base class for account statement load processors.

    This base class provides common functionality for loading account statements
    from various financial institutions. Concrete implementations should define:
    - EXPECTED_PARAMS: Processor-specific parameters
    - INPUT_FOLDER_CONFIG_KEY: Config key for input folder
    - INPUT_FOLDER_SUBDIR: Subfolder under DATA_FOLDER
    - DEFAULT_INPUT_MASKS: File masks to match
    - PARSER_BY_EXTENSION: Mapping of extensions to parser functions
    - RESEQUENCE_MONTHLY: Whether to re-sequence monthly codes
    """

    VALID_OPERATIONS = ("append", "upsert", "replace")
    EXPECTED_PARAMS: dict[str, tuple[type, bool, Any]] = {}
    INPUT_FOLDER_CONFIG_KEY = ""
    INPUT_FOLDER_SUBDIR = ""
    DEFAULT_INPUT_MASKS: tuple[str, ...] = ()
    PARSER_BY_EXTENSION: dict[str, Callable[[str], pd.DataFrame]] = {}
    RESEQUENCE_MONTHLY = False
    ACCOUNT_NORMALIZER: Optional[Callable[[Any], Any]] = None

    def __init__(self, params: dict) -> None:
        merged = {k: v[2] for k, v in self.EXPECTED_PARAMS.items()}
        merged.update(params or {})
        merged["input_masks"] = merged.get("input_masks") or list(self.DEFAULT_INPUT_MASKS)
        merged["input_folder"] = resolve_scoped_input_folder(
            merged.get("input_folder"),
            scope_subfolder=self.INPUT_FOLDER_SUBDIR,
            fallback_config_keys=(self.INPUT_FOLDER_CONFIG_KEY,),
        )
        if not merged["input_folder"]:
            raise ValueError(
                "input_folder is required (or configure DATA_FOLDER in config.json)"
            )
        super().__init__(merged)

    def _check_params(self, params: dict) -> bool:
        if not super()._check_params(params):
            return False
        operation = params.get("operation")
        if operation not in self.VALID_OPERATIONS:
            logger.error(
                f"Invalid operation '{operation}'. Expected one of {self.VALID_OPERATIONS}"
            )
            return False
        return True

    @staticmethod
    def _process_file_runner(
        scope: str,
        input_file: str,
        load_params: dict[str, Any],
    ) -> list[list[Any]]:
        return _run_load_file(scope=scope, input_file=input_file, load_params=load_params)

    def run(self, progress_callback=None) -> list[list[list[Any]]]:
        emit_debug_trace(f"{self.__class__.__name__}.run start scope={self.params['scope']}")
        provider = AccountFileDataProvider(
            {
                "input_folder": self.params["input_folder"],
                "input_masks": self.params.get("input_masks", []),
            }
        )
        input_files = provider.get_data()
        logger.info(
            "Resolved input files for scope=%s folder=%s count=%s files=%s",
            self.params["scope"],
            self.params["input_folder"],
            len(input_files),
            input_files,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run resolved files scope={self.params['scope']} count={len(input_files)}"
        )

        process_params = [
            (
                self.params["scope"],
                input_file,
                {
                    "schema": self.params["schema"],
                    "table_name": self.params["table_name"],
                    "operation": self.params["operation"],
                    "dry_run": self.params.get("dry_run", False),
                    "parallelize": self.params.get("parallelize", False),
                    "institution": self.params["institution"],
                    "source": self.params["source"],
                    "transaction_type": self.params["transaction_type"],
                    "parsers": self.PARSER_BY_EXTENSION,
                    "parser_kwargs": {
                        "pdf_password_required": self.params.get(
                            "pdf_password_required", False
                        ),
                        "use_native_pdf": self.params.get("use_native_pdf", False),
                        "use_vision": self.params.get("use_vision", False),
                    },
                    "account_normalizer": self.ACCOUNT_NORMALIZER,
                    "resequence_monthly": self.RESEQUENCE_MONTHLY,
                    "operacao_id": self.params.get("operacao_id"),
                },
            )
            for input_file in input_files
        ]

        process = ProcessWithCallback(
            process=self._process_file_runner,
            parallelize=self.params.get("parallelize", False),
            workers=(
                ProcessWithCallback.get_available_cpu_count()
                if self.params.get("parallelize", False)
                else 1
            ),
            progress_callback=progress_callback,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run invoking ProcessWithCallback scope={self.params['scope']} parallelize={self.params.get('parallelize', False)} progress={self.params.get('progress', False)}"
        )
        return process.run(process_params, progress=self.params.get("progress", False))
