import os
import re
from datetime import datetime
from typing import Any, Optional

import numpy as np
import pandas as pd
import polars as pl
from fbpyutils.uuid import hash_string
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation, get_batch_query
from fbpyutils_db.database.schema import get_schema
from fbpyutils_db.database.types import apply_dtype
from infobr.data import DataProcessor, DataProvider
from infobr.data.process import ProcessWithCallback
from sqlalchemy import text

from mymoney import env
from mymoney.services.operations import get_operation_recorder


def _fix_postgresql_merge_updates(updates: str) -> str:
    """
    Corrige a sintaxe do UPDATE SET no comando MERGE para PostgreSQL.

    No PostgreSQL, as colunas do target no UPDATE SET não podem ser
    qualificadas com o alias da tabela.

    Exemplo:
        Errado: UPDATE SET t.col=s.col
        Correto: UPDATE SET col=s.col

    Parameters
    ----------
    updates : str
        String com as atualizações no formato "t.col=s.col, ..."

    Returns
    -------
    str
        String corrigida no formato "col=s.col, ..."
    """
    # Remove o prefixo "t." das colunas do target no UPDATE SET
    return re.sub(r'\bt\.(\w+)\s*=\s*s\.', r'\1=s.', updates)


DEFAULT_SHEETS = [
    {
        "kind": "classificacao",
        "sheet_name": "CLASSIFICACOES",
        "table_name": "classificacoes",
        "operation": "upsert",
        "use_specialized_processor": True,
    },
    {
        "kind": "siglas",
        "sheet_name": "SIGLAS",
        "table_name": "siglas",
        "operation": "upsert",
    },
    {
        "kind": "lancamentos_futuros",
        "sheet_name": "LANCAMENTOS_FUTUROS",
        "table_name": "lancamentos_futuros",
        "operation": "upsert",
    },
    {
        "kind": "movimentacao",
        "sheet_name": "MOVIMENTACAO",
        "table_name": "lancamentos",
        "operation": "append",
    },
    {
        "kind": "negociacao",
        "sheet_name": "NEGOCIACAO",
        "table_name": "lancamentos",
        "operation": "append",
    },
    {
        "kind": "patrimonio",
        "sheet_name": "PATRIMONIO",
        "table_name": "lancamentos",
        "operation": "append",
    },
]


def _build_dataframe_for_sheet(
    input_df: pd.DataFrame, agent: str, kind: str, input_file: str, table_schema: list[tuple[Any, ...]]
) -> pd.DataFrame:
    table_keys = [c[2] for c in table_schema if c[4]]
    default_currency = env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")

    rows = []
    for input_row in input_df.to_dict(orient="records"):
        row = {}
        for _, _, column, data_type, _ in table_schema:
            if column == "tipo_lancamento":
                value = kind.upper()
            elif column == "moeda":
                value = default_currency
            elif column == "origem":
                value = agent
            elif column == "ativo":
                value = bool(input_row.get("is_active", True))
            else:
                value = input_row.get(column)

            # Handle datetime type separately for pd.NaT and invalid string values
            is_datetime = data_type == "datetime"
            is_null_string = (
                is_datetime
                and isinstance(value, str)
                and value.strip() in ("", "-", "N/A")
            )
            is_null_value = pd.isna(value) or is_null_string

            if not is_null_value and value is not None and not (
                isinstance(value, float) and np.isnan(value)
            ):
                row[column] = apply_dtype(str(value), data_type)
            elif is_datetime:
                row[column] = pd.NaT
            elif data_type in ("float", "float64", "int", "int64"):
                row[column] = np.nan
            else:
                row[column] = None

        row["arquivo_origem"] = os.path.basename(input_file).split(".")[0]
        row["data_referencia"] = datetime.now()
        row["usuario"] = env.USER
        row["id"] = hash_string(".".join([str(row.get(k, "~")) for k in table_keys]))
        rows.append(row)

    return capitalize(pd.DataFrame(rows), "lower")


class DataWorkbookProvider(DataProvider):
    EXPECTED_PARAMS = {
        "input_file": (str, True, None),
    }

    def __init__(self, params: dict) -> None:
        super().__init__(params)

    def get_data(self) -> str:
        return self.params["input_file"]


class DataLoadDataProcessor(DataProcessor):
    VALID_OPERATIONS = ("append", "upsert", "replace")
    EXPECTED_PARAMS = {
        "scope": (str, False, "data"),
        "agent": (str, False, "mm.data.elt.load.data"),
        "schema": (str, False, "mymoney"),
        "input_file": (str, False, None),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "sheets": (list, False, DEFAULT_SHEETS),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }

    def __init__(self, params: dict) -> None:
        merged = {k: v[2] for k, v in self.EXPECTED_PARAMS.items()}
        merged.update(params or {})
        merged["input_file"] = merged.get("input_file") or env.USER_CONFIG.get("DATA_FILE")
        if not merged["input_file"]:
            raise ValueError(
                "input_file is required (or configure DATA_FILE in config.json)"
            )
        super().__init__(merged)

    @staticmethod
    def _process_sheet_runner(
        scope: str,
        sheet_config: dict[str, Any],
        process_params: dict[str, Any],
    ) -> list[list[Any]]:
        kind = sheet_config["kind"]

        # Delegar para processor especializado se necessário
        if kind == "classificacao":
            from mymoney.data.elt.load.classificacao import (
                DataLoadClassificacaoProcessor,
            )
            return DataLoadClassificacaoProcessor.process_sheet(
                scope, sheet_config, process_params
            )

        summary = {
            "scope": scope,
            "kind": kind,
            "sheet_name": sheet_config["sheet_name"],
            "arquivo_origem": process_params["input_file"],
            "schema": process_params["schema"],
            "table_name": sheet_config["table_name"],
            "operation": sheet_config["operation"],
            "dry_run": process_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
        }
        unit_key = f"{process_params['input_file']}::{sheet_config['sheet_name']}"
        recorder = get_operation_recorder()
        recorder.start_unit(
            process_params["operacao_id"],
            unidade=unit_key,
            escopo=scope,
            arquivo_origem=process_params["input_file"],
            guia=sheet_config["sheet_name"],
            tipo_unidade=kind,
        )

        try:
            operation = sheet_config["operation"].lower()
            if operation not in DataLoadDataProcessor.VALID_OPERATIONS:
                raise ValueError(
                    f"Invalid operation '{operation}'. "
                    f"Expected one of {DataLoadDataProcessor.VALID_OPERATIONS}"
                )

            table_schema = get_schema(
                process_params["schema"], sheet_config["table_name"], env.SCHEMAS
            )

            input_df = capitalize(
                pl.read_excel(
                    process_params["input_file"],
                    sheet_name=sheet_config["sheet_name"],
                    engine="calamine",
                ).to_pandas(),
                "lower",
            )

            if input_df.empty:
                summary["skips"] = 1
                recorder.finish_unit(
                    process_params["operacao_id"],
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            output_df = _build_dataframe_for_sheet(
                input_df=input_df,
                agent=process_params["agent"],
                kind=kind,
                input_file=process_params["input_file"],
                table_schema=table_schema,
            )
            summary["records"] = len(output_df)

            operation_result = {
                "insertions": 0,
                "updates": 0,
                "skips": 0,
                "failures": [],
            }
            if not process_params["dry_run"]:
                # Verificar se é PostgreSQL e upsert para aplicar correção do MERGE
                if (
                    operation == "upsert"
                    and env.DB_ENGINE.dialect.name == "postgresql"
                ):
                    # Executar operação customizada com correção do MERGE
                    from fbpyutils_db.database.operations import get_batch_query
                    from fbpyutils.uuid import uuid
                    from sqlalchemy import text
                    from fbpyutils_db import logger

                    failures = []
                    pre_checks = {}
                    pos_checks = {}

                    batch_id = uuid()
                    batch_table = f"batch_{sheet_config['table_name']}_{batch_id}".replace("-", "_")
                    full_batch_table = f"{process_params['schema']}.{batch_table}"
                    full_target_table = f"{process_params['schema']}.{sheet_config['table_name']}"

                    logger.info(f"Criando tabela temporária '{full_batch_table}'")
                    _ = output_df.to_sql(
                        schema=process_params["schema"],
                        name=batch_table,
                        con=env.DB_ENGINE,
                        if_exists="replace",
                        index=False,
                        method="multi",
                        chunksize=1000,
                    )
                    logger.info(f"Inserted {len(output_df)} rows into session table '{batch_table}'")

                    try:
                        # Obter template da query e aplicar correção
                        query = get_batch_query("upsert", "postgresql")
                        query = (
                            query.replace("{table_name}", full_target_table)
                            .replace("{session_table}", full_batch_table)
                            .replace("{columns}", ", ".join(output_df.columns))
                            .replace("{matching_conditions}", " AND ".join([f"t.{k}=s.{k}" for k in ["id"]]))
                            .replace("{updates}", _fix_postgresql_merge_updates(
                                ", ".join([f"t.{col}=s.{col}" for col in output_df.columns if col != "id"])
                            ))
                            .replace("{values}", ", ".join([f"s.{col}" for col in output_df.columns]))
                            .replace("{key_columns}", "id")
                        )
                        logger.info(f"Query MERGE corrigida: {query}")

                        # Check query
                        check_sql = get_batch_query("check", "postgresql")
                        check_sql = (
                            check_sql.replace("{table_name}", full_target_table)
                            .replace("{session_table}", full_batch_table)
                            .replace("{keys}", " AND ".join([f"t.{k}=s.{k}" for k in ["id"]]))
                            .replace("{column_1}", "inserts")
                            .replace("{column_2}", "updates")
                            .replace("{column_3}", "skips")
                        )

                        pre_checks = (
                            pl.read_database(check_sql, connection=env.DB_ENGINE)
                            .to_pandas()
                            .to_dict(orient="records")[0]
                        )
                        logger.info(f"Pre-operation checks: {pre_checks}")

                        with env.DB_ENGINE.begin() as conn:
                            result = conn.execute(text(query))
                            check_result = (
                                pl.read_database(check_sql, connection=conn)
                                .to_pandas()
                                .to_dict(orient="records")
                            )
                            pos_checks = check_result[0] if check_result else {}
                            logger.info(f"Post-operation checks: {pos_checks}")
                            logger.info(f"Operation upsert completed successfully. Result: {result}")
                    except Exception as e:
                        failures.append({"step": "upsert", "row": query, "error": str(e)})
                        logger.error(f"Operation upsert failed. Error: {e}")
                        logger.info(f"SQL: {query}")
                    finally:
                        drop_sql = get_batch_query("drop", "postgresql").replace(
                            "{table_name}", full_batch_table
                        )
                        logger.info(f"Dropping session table with query: {drop_sql}")
                        with env.DB_ENGINE.connect() as conn:
                            conn.execute(text(drop_sql))
                            conn.commit()
                        logger.info(f"Dropped session table {batch_table}")

                    operation_result = {
                        "operation": "upsert",
                        "table_name": full_target_table,
                        "insertions": pre_checks.get("inserts", 0) if pre_checks else 0,
                        "updates": pos_checks.get("updates", 0) if pos_checks else 0,
                        "skips": pos_checks.get("skips", 0) if pos_checks else 0,
                        "failures": failures,
                    }
                else:
                    operation_result = batch_table_operation(
                        operation=operation,
                        dataframe=output_df,
                        engine=env.DB_ENGINE,
                        schema=process_params["schema"],
                        table_name=sheet_config["table_name"],
                        table_schema=table_schema,
                        table_keys=["id"],
                        commit_at=1000,
                    )

            failures = operation_result.get("failures", [])
            failure_count = len(failures) if isinstance(failures, list) else int(bool(failures))
            summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
            summary["updates"] = int(operation_result.get("updates", 0) or 0)
            summary["skips"] = int(operation_result.get("skips", 0) or 0)
            summary["failures"] = int(failure_count)
            # Capturar detalhes do erro para debugging
            failure_details = failures if isinstance(failures, list) and failures else []
            success = failure_count == 0
            if success:
                error_message = None
            elif failure_details:
                # Extrair mensagem de erro do primeiro failure
                first_failure = failure_details[0] if failure_details else {}
                if isinstance(first_failure, dict):
                    error_message = first_failure.get("error", f"{failure_count} row(s) failed on DB operation.")
                else:
                    error_message = str(first_failure)
            else:
                error_message = f"{failure_count} row(s) failed on DB operation."
            recorder.finish_unit(
                process_params["operacao_id"],
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]
        except Exception as exc:
            recorder.finish_unit(
                process_params["operacao_id"],
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]

    def run(
        self, progress_callback=None
    ) -> list[list[list[Any]]]:
        provider = DataWorkbookProvider({"input_file": self.params["input_file"]})
        input_file = provider.get_data()

        sheet_configs = self.params.get("sheets") or []
        process_params = [
            (
                self.params.get("scope", "data"),
                sheet_config,
                {
                    "schema": self.params["schema"],
                    "input_file": input_file,
                    "agent": self.params["agent"],
                    "dry_run": self.params.get("dry_run", False),
                    "operacao_id": self.params["operacao_id"],
                },
            )
            for sheet_config in sheet_configs
        ]

        if not process_params:
            return [
                [
                    [
                        self.params.get("scope", "data"),
                        True,
                        None,
                        pd.DataFrame(
                            [
                                {
                                    "scope": self.params.get("scope", "data"),
                                    "kind": "data",
                                    "records": 0,
                                    "insertions": 0,
                                    "updates": 0,
                                    "skips": 1,
                                    "failures": 0,
                                    "dry_run": self.params.get("dry_run", False),
                                }
                            ]
                        ),
                    ]
                ]
            ]

        process = ProcessWithCallback(
            process=self._process_sheet_runner,
            parallelize=self.params.get("parallelize", False),
            workers=(
                ProcessWithCallback.get_available_cpu_count()
                if self.params.get("parallelize", False)
                else 1
            ),
            progress_callback=progress_callback,
        )
        return process.run(process_params, progress=self.params.get("progress", False))


def run(progress_callback=None, **overrides):
    processor = DataLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
