"""Nubank load processor for LANCAMENTOS_CONTA_CORRENTE and LANCAMENTOS_CARTAO_CREDITO."""

from __future__ import annotations

import csv
import os
import re
from datetime import datetime
from typing import Any

import pandas as pd
from fbpyutils import ofx as OFX
from infobr.data.process import ProcessWithCallback

from mymoney import emit_debug_trace, logger
from mymoney.data.elt.load.base import (
    AccountFileDataProvider,
    AccountLoadDataProcessor,
    _build_typed_lancamentos_dataframe,
    _move_file_done,
    _normalize_financial_identity,
)
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.operations import batch_table_operation
from fbpyutils_db.database.schema import get_schema
from mymoney.data.providers.nubank import (
    NUBANK_CC_DEFAULT_MASKS,
    NUBANK_DEFAULT_MASKS,
    NUBANK_INSTITUTION,
    parse_nubank_pdf,
    parse_nubank_cc_pdf,
)
from mymoney.data.providers.nubank.common import (
    build_nubank_direct_dataframe,
)
from mymoney import env
from mymoney.services.operations import get_operation_recorder


def _select_nubank_files_by_precedence(input_files: list[str]) -> list[str]:
    precedence = {".csv": 0, ".ofx": 1, ".pdf": 2}
    selected_by_period: dict[str, str] = {}

    for input_file in sorted(input_files):
        stem, ext = os.path.splitext(input_file)
        ext = ext.lower()
        current = selected_by_period.get(stem)
        if current is None:
            selected_by_period[stem] = input_file
            continue

        current_ext = os.path.splitext(current)[1].lower()
        if precedence.get(ext, 999) < precedence.get(current_ext, 999):
            selected_by_period[stem] = input_file

    return [selected_by_period[stem] for stem in sorted(selected_by_period)]


def _parse_nubank_csv(file_path: str) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    with open(file_path, "r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            if not row:
                continue
            date_value = str(row.get("Data") or "").strip()
            amount_value = str(row.get("Valor") or "").strip()
            description = str(row.get("Descrição") or "").strip()
            if not date_value or not amount_value or not description:
                continue
            rows.append(
                {
                    "data_movimentacao": datetime.strptime(date_value, "%d/%m/%Y").date(),
                    "valor_operacao": float(amount_value),
                    "descricao": description,
                }
            )

    return build_nubank_direct_dataframe(
        rows,
        file_path=file_path,
        source="mm.data.elt.load.nubank",
    )


def _parse_nubank_ofx(file_path: str) -> pd.DataFrame:
    ofx_data = OFX.read_from_path(file_path)
    transactions = ofx_data.get("statement", {}).get("transactions", [])

    rows: list[dict[str, object]] = []
    for item in transactions:
        date_value = item.get("date")
        rows.append(
            {
                "data_movimentacao": (
                    date_value.date() if hasattr(date_value, "date") else date_value
                ),
                "valor_operacao": float(item.get("amount", 0)),
                "descricao": str(item.get("memo", "")).strip(),
            }
        )

    return build_nubank_direct_dataframe(
        rows,
        file_path=file_path,
        source="mm.data.elt.load.nubank",
    )


def _parse_nubank_pdf(file_path: str, *, use_native_pdf: bool = False, use_vision: bool = False) -> pd.DataFrame:
    return parse_nubank_pdf(file_path, use_native_pdf=use_native_pdf, use_vision=use_vision)


def _extract_parcelas(descricao: str) -> tuple[int, int]:
    """Extract parcela atual and total parcelas from description.

    Common patterns:
    - "1/12" -> (1, 12)
    - "Parcela 3 de 10" -> (3, 10)
    - "3/10" -> (3, 10)

    Returns (1, 1) if no parcela info found.
    """
    text = str(descricao or "").strip()

    # Pattern: X/Y (e.g., "1/12", "3/10")
    pattern1 = r'(\d+)\s*/\s*(\d+)'
    match = re.search(pattern1, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    # Pattern: "Parcela X de Y" or "Parcela X/Y"
    pattern2 = r'[Pp]arcela\s+(\d+)\s+(?:de|/)\s*(\d+)'
    match = re.search(pattern2, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    return 1, 1


def _is_credito_cartao(descricao: str) -> bool:
    """Check if transaction is a credit (payment/refund) on credit card.

    Keywords for credit:
    - Pagamento de fatura
    - Pagamento recebido
    - Pagamento efetuado
    - Estorno
    - Devolucao
    - Cashback
    - Rewards
    """
    text = str(descricao or "").lower()

    credit_keywords = [
        "pagamento",
        "estorno",
        "devolucao",
        "devolução",
        "cashback",
        "credito",
        "crédito",
        "recebido",
        "recebi",
        "rewards",
        "resgate",
    ]

    for keyword in credit_keywords:
        if keyword in text:
            return True

    return False


def _split_description(description: Any) -> tuple[str, str]:
    """Split description into movement and product name."""
    text = str(description or "").strip()
    if "::" in text:
        first, second = text.split("::", 1)
        return first.strip() or "Lancamento em C/C", second.strip()
    return "Lancamento em C/C", text


def _map_nubank_cc_rows_to_lancamentos(
    account_df: pd.DataFrame,
    *,
    institution: str,
    source: str,
    transaction_type: str,
    input_file: str,
    run_at: datetime,
) -> pd.DataFrame:
    """Map Nubank credit card DataFrame rows to lancamentos format."""
    if account_df is None or account_df.empty:
        return pd.DataFrame()

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]

    for row in account_df.itertuples(index=False):
        descricao = getattr(row, "descricao", "")
        dc = getattr(row, "dc", "D")

        # Determine movement type
        if dc.upper() == "C":
            entrada_saida = "Credito"
            movimentacao = "Pagamento Fatura"
            tipo_evento = "PAGAMENTO CC"
        else:
            entrada_saida = "Debito"
            movimentacao = "Compra Cartao"
            tipo_evento = "COMPRA CC"

        # Get parcela info
        parcela_atual = getattr(row, "parcela_atual", 1) or 1
        total_parcelas = getattr(row, "total_parcelas", 1) or 1

        # If not already set, try to extract from description
        if parcela_atual == 1 and total_parcelas == 1:
            parcela_atual, total_parcelas = _extract_parcelas(descricao)

        # Split description into movement and product
        movement, product_name = _split_description(descricao)

        seq_value = getattr(row, "seq", None)
        seq_string = None
        try:
            if seq_value is not None and str(seq_value).strip() != "":
                seq_string = str(int(seq_value)).rjust(12, "0")
        except Exception:
            seq_string = str(seq_value).strip() if seq_value is not None else None

        rows.append({
            "entrada_saida": entrada_saida,
            "data_movimentacao": pd.to_datetime(getattr(row, "data", None), errors="coerce"),
            "movimentacao": movement if movement != "Lancamento em C/C" else movimentacao,
            "nome_produto": product_name,
            "codigo_produto": seq_string,
            "instituicao": institution,
            "conta": getattr(row, "conta", "NUBANK_CC"),
            "valor_operacao": abs(getattr(row, "valor", 0)),
            "quantidade_disponivel": float(parcela_atual),
            "quantidade_indisponivel": float(total_parcelas),
            "tipo_produto": "CARTAO CREDITO",
            "tipo_evento": tipo_evento,
            "tipo_lancamento": transaction_type,
            "moeda": getattr(row, "moeda", "BRL"),
            "origem": source,
            "arquivo_origem": file_name,
            "data_referencia": run_at,
        })

    xdf = pd.DataFrame(rows)
    xdf = _normalize_financial_identity(
        xdf,
        institution=institution,
        transaction_type=transaction_type,
    )
    return capitalize(xdf, "lower")


class NubankAccountLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Nubank account statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "nubank"),
        "agent": (str, False, "mm.data.elt.load.nubank"),
        "source": (str, False, "mm.data.elt.load.nubank"),
        "institution": (str, False, "NU PAGAMENTOS S.A."),
        "transaction_type": (str, False, "LANCAMENTOS_CONTA_CORRENTE"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(NUBANK_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "use_native_pdf": (bool, False, False),
        "use_vision": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "NUBANK_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "NUBANK"
    DEFAULT_INPUT_MASKS = NUBANK_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".csv": _parse_nubank_csv,
        ".ofx": _parse_nubank_ofx,
        ".pdf": _parse_nubank_pdf,
    }
    RESEQUENCE_MONTHLY = False

    def run(self, progress_callback=None) -> list[list[list[Any]]]:
        emit_debug_trace(f"{self.__class__.__name__}.run start scope={self.params['scope']}")
        provider = AccountFileDataProvider(
            {
                "input_folder": self.params["input_folder"],
                "input_masks": self.params.get("input_masks", []),
            }
        )
        input_files = _select_nubank_files_by_precedence(provider.get_data())
        logger.info(
            "Resolved input files for scope=%s folder=%s count=%s files=%s",
            self.params["scope"],
            self.params["input_folder"],
            len(input_files),
            input_files,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run resolved files scope={self.params['scope']} count={len(input_files)}"
        )

        process_params = [
            (
                self.params["scope"],
                input_file,
                {
                    "schema": self.params["schema"],
                    "table_name": self.params["table_name"],
                    "operation": self.params["operation"],
                    "dry_run": self.params.get("dry_run", False),
                    "parallelize": self.params.get("parallelize", False),
                    "institution": self.params["institution"],
                    "source": self.params["source"],
                    "transaction_type": self.params["transaction_type"],
                    "parsers": self.PARSER_BY_EXTENSION,
                    "resequence_monthly": self.RESEQUENCE_MONTHLY,
                    "operacao_id": self.params.get("operacao_id"),
                },
            )
            for input_file in input_files
        ]

        process = ProcessWithCallback(
            process=self._process_file_runner,
            parallelize=self.params.get("parallelize", False),
            workers=(
                ProcessWithCallback.get_available_cpu_count()
                if self.params.get("parallelize", False)
                else 1
            ),
            progress_callback=progress_callback,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run invoking ProcessWithCallback scope={self.params['scope']} parallelize={self.params.get('parallelize', False)} progress={self.params.get('progress', False)}"
        )
        return process.run(process_params, progress=self.params.get("progress", False))


def _parse_nubank_cc_csv(file_path: str) -> pd.DataFrame:
    """Parse Nubank credit card CSV file (wrapper for nubank_parser)."""
    from mymoney.data.providers.nubank.nubank_parser import parse_nubank_cc
    return parse_nubank_cc(file_path)


def _parse_nubank_cc_ofx(file_path: str) -> pd.DataFrame:
    """Parse Nubank credit card OFX file (wrapper for nubank_parser)."""
    from mymoney.data.providers.nubank.nubank_parser import parse_nubank_cc
    return parse_nubank_cc(file_path)


class NubankCartaoLoadDataProcessor(AccountLoadDataProcessor):
    """Load processor for Nubank credit card statements."""

    EXPECTED_PARAMS = {
        "scope": (str, False, "nubank_cartao"),
        "agent": (str, False, "mm.data.elt.load.nubank_cartao"),
        "source": (str, False, "mm.data.elt.load.nubank_cartao"),
        "institution": (str, False, "NU PAGAMENTOS S.A."),
        "transaction_type": (str, False, "LANCAMENTOS_CARTAO_CREDITO"),
        "input_folder": (str, False, None),
        "input_masks": (list, False, list(NUBANK_CC_DEFAULT_MASKS)),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos"),
        "operation": (str, False, "append"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "use_native_pdf": (bool, False, False),
        "use_vision": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
    }
    INPUT_FOLDER_CONFIG_KEY = "NUBANK_CC_DATA_FOLDER"
    INPUT_FOLDER_SUBDIR = "NUBANK_CC"
    DEFAULT_INPUT_MASKS = NUBANK_CC_DEFAULT_MASKS
    PARSER_BY_EXTENSION = {
        ".csv": _parse_nubank_cc_csv,
        ".ofx": _parse_nubank_cc_ofx,
        ".pdf": parse_nubank_cc_pdf,
    }
    RESEQUENCE_MONTHLY = False

    def run(self, progress_callback=None) -> list[list[list[Any]]]:
        emit_debug_trace(f"{self.__class__.__name__}.run start scope={self.params['scope']}")
        provider = AccountFileDataProvider(
            {
                "input_folder": self.params["input_folder"],
                "input_masks": self.params.get("input_masks", []),
            }
        )
        input_files = _select_nubank_files_by_precedence(provider.get_data())
        logger.info(
            "Resolved input files for scope=%s folder=%s count=%s files=%s",
            self.params["scope"],
            self.params["input_folder"],
            len(input_files),
            input_files,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run resolved files scope={self.params['scope']} count={len(input_files)}"
        )

        process_params = [
            (
                self.params["scope"],
                input_file,
                {
                    "schema": self.params["schema"],
                    "table_name": self.params["table_name"],
                    "operation": self.params["operation"],
                    "dry_run": self.params.get("dry_run", False),
                    "parallelize": self.params.get("parallelize", False),
                    "institution": self.params["institution"],
                    "source": self.params["source"],
                    "transaction_type": self.params["transaction_type"],
                    "parsers": self.PARSER_BY_EXTENSION,
                    "resequence_monthly": self.RESEQUENCE_MONTHLY,
                    "operacao_id": self.params.get("operacao_id"),
                },
            )
            for input_file in input_files
        ]

        process = ProcessWithCallback(
            process=self._process_file_runner,
            parallelize=self.params.get("parallelize", False),
            workers=(
                ProcessWithCallback.get_available_cpu_count()
                if self.params.get("parallelize", False)
                else 1
            ),
            progress_callback=progress_callback,
        )
        emit_debug_trace(
            f"{self.__class__.__name__}.run invoking ProcessWithCallback scope={self.params['scope']} parallelize={self.params.get('parallelize', False)} progress={self.params.get('progress', False)}"
        )
        return process.run(process_params, progress=self.params.get("progress", False))

    @staticmethod
    def _process_file_runner(
        scope: str,
        input_file: str,
        load_params: dict[str, Any],
    ) -> list[list[Any]]:
        """Override to use credit card specific row mapping."""
        unit_key = input_file
        recorder = get_operation_recorder()
        recorder.start_unit(
            load_params.get("operacao_id"),
            unidade=unit_key,
            escopo=scope,
            arquivo_origem=input_file,
            tipo_unidade=load_params["transaction_type"].lower(),
        )
        emit_debug_trace(
            f"_process_file_runner start scope={scope} file={input_file} transaction_type={load_params['transaction_type']}"
        )
        logger.info(
            "Starting CC load unit: scope=%s transaction_type=%s file=%s dry_run=%s",
            scope,
            load_params["transaction_type"],
            input_file,
            load_params["dry_run"],
        )
        summary = {
            "scope": scope,
            "kind": load_params["transaction_type"].lower(),
            "arquivo_origem": input_file,
            "schema": load_params["schema"],
            "table_name": load_params["table_name"],
            "operation": load_params["operation"],
            "dry_run": load_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
            "files_detected": 1,
            "files_parsed": 0,
            "files_renamed": 0,
            "parse_failures": 0,
        }

        run_at = datetime.now()

        try:
            ext = os.path.splitext(input_file)[1].lower()
            parser = load_params["parsers"].get(ext)
            if parser is None:
                error_message = f"{os.path.basename(input_file)}: unsupported extension '{ext}'"
                summary["failures"] = 1
                summary["parse_failures"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=False,
                    mensagem_erro=error_message,
                    dados=dict(summary),
                )
                return [[scope, False, error_message, pd.DataFrame([summary])]]

            account_df = parser(input_file)
            summary["files_parsed"] = 1

            # Check if parser already returns data in lancamentos format (new parsers)
            # or if it needs mapping (legacy format)
            if "tipo_lancamento" in account_df.columns:
                # Data already in lancamentos format (from new parsers)
                output_df = account_df
            else:
                # Data needs mapping (from legacy PDF parser)
                output_df = _map_nubank_cc_rows_to_lancamentos(
                    account_df,
                    institution=load_params["institution"],
                    source=load_params["source"],
                    transaction_type=load_params["transaction_type"],
                    input_file=input_file,
                    run_at=run_at,
                )

            if output_df.empty:
                summary["skips"] = 1
                if not load_params["dry_run"]:
                    _move_file_done(input_file, dry_run=False)
                    summary["files_renamed"] = 1
                recorder.finish_unit(
                    load_params.get("operacao_id"),
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            if load_params.get("resequence_monthly", False):
                from mymoney.data.elt.load.base import _resequence_monthly_codes
                output_df = _resequence_monthly_codes(output_df)

            table_schema = get_schema(
                load_params["schema"], load_params["table_name"], env.SCHEMAS
            )
            normalized_data = _build_typed_lancamentos_dataframe(
                table_data=output_df,
                table_schema=table_schema,
            )
            summary["records"] = len(normalized_data)

            operation_result = {
                "insertions": 0,
                "updates": 0,
                "skips": 0,
                "failures": [],
            }
            if not load_params["dry_run"]:
                operation_result = batch_table_operation(
                    operation=load_params["operation"],
                    dataframe=normalized_data,
                    engine=env.DB_ENGINE,
                    schema=load_params["schema"],
                    table_name=load_params["table_name"],
                    table_schema=table_schema,
                    table_keys=["id"],
                    commit_at=1000,
                )

            db_failures = operation_result.get("failures", [])
            db_failure_count = (
                len(db_failures) if isinstance(db_failures, list) else int(bool(db_failures))
            )
            summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
            summary["updates"] = int(operation_result.get("updates", 0) or 0)
            summary["skips"] = int(operation_result.get("skips", 0) or 0)
            summary["failures"] = int(db_failure_count)

            if db_failure_count == 0 and not load_params["dry_run"]:
                _move_file_done(input_file, dry_run=False)
                summary["files_renamed"] = 1

            success = db_failure_count == 0
            error_message = None if success else f"{db_failure_count} row(s) failed on DB operation."
            emit_debug_trace(
                f"_process_file_runner finished scope={scope} file={input_file} success={success}"
            )
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]

        except Exception as exc:
            summary["failures"] = max(1, summary["failures"])
            summary["parse_failures"] = max(1, summary["parse_failures"])
            emit_debug_trace(f"_process_file_runner fatal scope={scope} file={input_file} error={exc}")
            logger.error("CC Load unit failed: scope=%s file=%s error=%s", scope, input_file, exc)
            recorder.finish_unit(
                load_params.get("operacao_id"),
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]


def run_nubank(progress_callback=None, **overrides):
    """Run Nubank load pipeline."""
    processor = NubankAccountLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)


def run_nubank_cartao(progress_callback=None, **overrides):
    """Run Nubank credit card load pipeline."""
    processor = NubankCartaoLoadDataProcessor(overrides)
    return processor.run(progress_callback=progress_callback)
