from __future__ import annotations

import os
from typing import Optional

from mymoney import env


def _normalize_path(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return os.path.expanduser(text)


def _expand_data_folder_token(value: Optional[str], data_folder: Optional[str]) -> Optional[str]:
    normalized = _normalize_path(value)
    if normalized is None:
        return None
    if data_folder and "{DATA_FOLDER}" in normalized:
        return normalized.replace("{DATA_FOLDER}", data_folder)
    return normalized


def resolve_scoped_input_folder(
    explicit_folder: Optional[str],
    *,
    scope_subfolder: str,
    fallback_config_keys: tuple[str, ...] = (),
) -> Optional[str]:
    """
    Resolve load input folder with precedence:
    1) explicit_folder (pipeline override)
    2) DATA_FOLDER/<scope_subfolder>
    3) fallback keys (legacy compatibility)
    """
    explicit = _normalize_path(explicit_folder)
    if explicit:
        return explicit

    cfg = env.USER_CONFIG or {}
    data_folder = _normalize_path(cfg.get("DATA_FOLDER"))
    if data_folder:
        return os.path.sep.join([data_folder, scope_subfolder])

    for key in fallback_config_keys:
        fallback = _expand_data_folder_token(cfg.get(key), data_folder)
        if fallback:
            return fallback
    return None
