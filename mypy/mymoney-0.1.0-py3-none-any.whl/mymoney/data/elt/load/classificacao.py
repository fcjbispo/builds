"""
DataLoadClassificacaoProcessor - Processador especializado para carga de classificações com embeddings.

Este processor gera embeddings vetoriais para dados de lançamentos de conta corrente,
permitindo busca RAG para classificação automática de novos lançamentos por sigla.
"""

import json
import os
from datetime import datetime
from typing import Any, Optional

import numpy as np
import pandas as pd
import polars as pl
from fbpyutils.uuid import hash_string
from fbpyutils_db.data.normalize import capitalize
from fbpyutils_db.database.schema import get_schema
from fbpyutils_db.database.types import apply_dtype
from infobr.data import DataProcessor
from sqlalchemy import text

from mymoney import env, logger
from mymoney.data.providers.unstructured.engine import (
    UnstructuredLLMConfig,
    resolve_llm_config_from_user_settings,
)
from mymoney.services.operations import get_operation_recorder


def _compose_embedding_text(row_data: dict[str, Any]) -> str:
    """
    Compõe o texto para geração de embedding a partir dos dados do lançamento.

    Formato JSON com colunas de identidade do registro (alinhado com tabela classificacoes):
    MOVIMENTACAO, DESCRICAO, DC, VALOR, MOEDA

    Parameters
    ----------
    row_data : dict
        Dicionário com os dados do registro

    Returns
    -------
    str
        Texto formatado em JSON para embedding
    """
    embedding_data = {
        "movimentacao": row_data.get("movimentacao", ""),
        "descricao": row_data.get("descricao", ""),
        "dc": row_data.get("dc", ""),
        "valor": float(row_data.get("valor", 0)) if pd.notna(row_data.get("valor")) else 0.0,
        "moeda": row_data.get("moeda", "BRL"),
    }
    return json.dumps(embedding_data, ensure_ascii=False, sort_keys=True)


def _generate_embedding(
    text: str,
    llm_config: Optional[UnstructuredLLMConfig] = None,
) -> Optional[list[float] | list[list[float]]]:
    """
    Gera embedding vetorial para o texto fornecido.

    Parameters
    ----------
    text : str
        Texto para gerar embedding
    llm_config : UnstructuredLLMConfig, optional
        Configuração do LLM. Se não fornecida, usa a config do ambiente.

    Returns
    -------
    list[float] or None
        Vetor de embedding ou None em caso de falha
    """
    try:
        from fbpyutils_ai.base import LLMServiceModel
        from fbpyutils_ai.llm import OpenAILLMService

        cfg = llm_config or resolve_llm_config_from_user_settings()

        embed_model = LLMServiceModel(
            provider=cfg.provider,
            api_base_url=cfg.api_base_url,
            api_key=cfg.api_key,
            model_id=cfg.embed_model,
        )

        llm_service = OpenAILLMService(
            base_model=embed_model,  # Not used for embeddings
            embed_model=embed_model,
            vision_model=embed_model,  # Not used for embeddings
            timeout=120,  # Timeout específico para embeddings (120s)
            retries=cfg.retries,
        )

        embedding = llm_service.generate_embeddings(text)

        if embedding and len(embedding) > 0:
            # Handle nested list case: [[v1, v2, ...]] -> [v1, v2, ...]
            if isinstance(embedding[0], list):
                embedding = embedding[0]
            return embedding
        return None

    except Exception as exc:
        error_type = type(exc).__name__
        logger.warning(f"Failed to generate embedding ({error_type}): {exc}")
        return None


def _build_classificacao_dataframe(
    input_df: pd.DataFrame,
    agent: str,
    kind: str,
    input_file: str,
    table_schema: list[tuple[Any, ...]],
) -> pd.DataFrame:
    """
    Constroi DataFrame para tabela classificacoes com embeddings.

    Parameters
    ----------
    input_df : pd.DataFrame
        DataFrame com dados de entrada da guia CLASSIFICACOES
    agent : str
        Agente/processador responsável
    kind : str
        Tipo de kind (classificacao)
    input_file : str
        Caminho do arquivo de origem
    table_schema : list
        Schema da tabela classificacoes

    Returns
    -------
    pd.DataFrame
        DataFrame formatado para carga na tabela
    """
    rows = []
    llm_config = resolve_llm_config_from_user_settings()
    arquivo_origem = os.path.basename(input_file).split(".")[0]
    data_referencia = datetime.now()
    usuario = env.USER

    for input_row in input_df.to_dict(orient="records"):
        try:
            # Extrair dados de identidade
            row_data = {
                "instituicao": input_row.get("instituicao"),
                "conta": input_row.get("conta"),
                "data_lancamento": input_row.get("data_lancamento"),
                "movimentacao": input_row.get("movimentacao"),
                "descricao": input_row.get("descricao"),
                "dc": input_row.get("dc"),
                "valor": input_row.get("valor"),
                "moeda": input_row.get("moeda"),
                "sequencia": input_row.get("sequencia"),
                "tipo_lancamento": input_row.get("tipo_lancamento"),
                "tipo_produto": input_row.get("tipo_produto"),
                "tipo_evento": input_row.get("tipo_evento"),
                "origem": input_row.get("origem"),
            }

            # Compor texto para embedding
            embedding_text = _compose_embedding_text(row_data)

            # Gerar embedding
            embedding = _generate_embedding(embedding_text, llm_config)

            if embedding is None:
                logger.warning(
                    f"Skipping record due to embedding generation failure: "
                    f"instituicao={row_data.get('instituicao')}, "
                    f"movimentacao={row_data.get('movimentacao')}, "
                    f"data={row_data.get('data_lancamento')}"
                )
                continue

            # Montar metadata JSONB
            metadata = {
                "id": input_row.get("id"),
                "instituicao": row_data["instituicao"],
                "conta": row_data["conta"],
                "data_lancamento": str(row_data["data_lancamento"]) if pd.notna(row_data["data_lancamento"]) else None,
                "movimentacao": row_data["movimentacao"],
                "descricao": row_data["descricao"],
                "dc": row_data["dc"],
                "valor": float(row_data["valor"]) if pd.notna(row_data["valor"]) else None,
                "moeda": row_data["moeda"],
                "sequencia": row_data["sequencia"],
                "tipo_lancamento": row_data["tipo_lancamento"],
                "tipo_produto": row_data["tipo_produto"],
                "tipo_evento": row_data["tipo_evento"],
                "origem": row_data["origem"],
                "embedding_text": embedding_text,
            }

            # Calcular ID se não existir
            record_id = input_row.get("id")
            if not record_id:
                record_id = hash_string(
                    ".".join([
                        str(row_data.get("instituicao", "~")),
                        str(row_data.get("conta", "~")),
                        str(row_data.get("data_lancamento", "~")),
                        str(row_data.get("movimentacao", "~")),
                        str(row_data.get("valor", "~")),
                    ])
                )

            # Use 'UNKNOWN' as default for sigla if null or empty
            sigla_val = input_row.get("sigla")
            if not sigla_val or str(sigla_val).strip() == "":
                sigla_val = "UNKNOWN"
                logger.warning(f"Sigla is null/empty for record {record_id}, using 'UNKNOWN'")

            row = {
                "id": record_id,
                "sigla": sigla_val,
                "embedding": embedding,
                "metadata": json.dumps(metadata, ensure_ascii=False, default=str),
                "arquivo_origem": arquivo_origem,
                "data_referencia": data_referencia,
                "usuario": usuario,
            }

            rows.append(row)

        except Exception as exc:
            logger.warning(f"Failed to process classification row: {exc}")
            continue

    if not rows:
        return pd.DataFrame()

    return capitalize(pd.DataFrame(rows), "lower")


def classificar_lancamento(
    lancamento_data: dict[str, Any],
    sigla: str,
    llm_config: Optional[UnstructuredLLMConfig] = None,
) -> Optional[dict[str, Any]]:
    """
    Classifica um lançamento individual gerando embedding e dados para a tabela.

    Método público para uso externo quando um lançamento precisa ser classificado
    e não possui classificação adequada existente.

    Parameters
    ----------
    lancamento_data : dict
        Dados do lançamento (instituicao, conta, data_lancamento, movimentacao, etc.)
    sigla : str
        Código da sigla para classificação
    llm_config : UnstructuredLLMConfig, optional
        Configuração do LLM

    Returns
    -------
    dict or None
        Dados formatados para inserção na tabela classificacoes, ou None em caso de falha
    """
    try:
        # Compor texto para embedding
        embedding_text = _compose_embedding_text(lancamento_data)

        # Gerar embedding
        embedding = _generate_embedding(embedding_text, llm_config)

        if embedding is None:
            logger.error("Failed to generate embedding for lancamento classification")
            return None

        # Calcular ID
        record_id = hash_string(
            ".".join([
                str(lancamento_data.get("instituicao", "~")),
                str(lancamento_data.get("conta", "~")),
                str(lancamento_data.get("data_lancamento", "~")),
                str(lancamento_data.get("movimentacao", "~")),
                str(lancamento_data.get("valor", "~")),
            ])
        )

        # Montar metadata
        metadata = {
            "id": record_id,
            "instituicao": lancamento_data.get("instituicao"),
            "conta": lancamento_data.get("conta"),
            "data_lancamento": str(lancamento_data.get("data_lancamento")),
            "movimentacao": lancamento_data.get("movimentacao"),
            "descricao": lancamento_data.get("descricao"),
            "dc": lancamento_data.get("dc"),
            "valor": float(lancamento_data.get("valor")) if pd.notna(lancamento_data.get("valor")) else None,
            "moeda": lancamento_data.get("moeda", "BRL"),
            "sequencia": lancamento_data.get("sequencia"),
            "tipo_lancamento": lancamento_data.get("tipo_lancamento"),
            "tipo_produto": lancamento_data.get("tipo_produto"),
            "tipo_evento": lancamento_data.get("tipo_evento"),
            "origem": lancamento_data.get("origem"),
            "embedding_text": embedding_text,
            "classificado_em": datetime.now().isoformat(),
        }

        return {
            "id": record_id,
            "sigla": sigla,
            "embedding": embedding,
            "metadata": metadata,
            "arquivo_origem": lancamento_data.get("arquivo_origem", "manual"),
            "data_referencia": datetime.now(),
            "usuario": env.USER,
        }

    except Exception as exc:
        logger.error(f"Failed to classify lancamento: {exc}")
        return None


def classificar(
    lancamento: dict[str, Any],
    similaridade: float = 0.95,
    llm_config: Optional[UnstructuredLLMConfig] = None,
    limit: int = 1,
) -> list[dict[str, Any]]:
    """
    Classifica um lançamento buscando as siglas mais similares via RAG.

    Gera embedding do lançamento e busca no banco as classificações mais
    similares usando cosine similarity. Retorna os dados formatados se
    a similaridade for maior ou igual ao threshold.

    Parameters
    ----------
    lancamento : dict[str, Any]
        Dados do lançamento (instituicao, conta, data_lancamento, movimentacao, etc.)
    similaridade : float
        Threshold mínimo de similaridade (0-1). Default: 0.95
    llm_config : UnstructuredLLMConfig, optional
        Configuração do LLM
    limit : int
        Número máximo de resultados a retornar. Default: 1
        Se limit <= 0, retorna todos os resultados que atendem ao threshold (máx 5).

    Returns
    -------
    list[dict]
        Lista com os dados formatados para inserção + campos adicionais:
        - similaridade: float (fator real de similaridade)
        - sigla_encontrada: str (sigla da classificação similar)
        - id_referencia: str (id do registro de referência)
        Lista vazia [] se nenhuma classificação atingir o threshold.
    """
    try:
        # Gerar embedding para o lançamento
        embedding_text = _compose_embedding_text(lancamento)
        embedding = _generate_embedding(embedding_text, llm_config)

        if embedding is None:
            logger.warning("Failed to generate embedding for classification search")
            return []

        # Flatten embedding if nested
        if isinstance(embedding[0], list):
            embedding = embedding[0]

        # Buscar classificações mais similares no banco
        embedding_str = "[" + ",".join(str(v) for v in embedding) + "]"

        # Limitar a 5 resultados máximos se limit <= 0 (retornar todos que atendem)
        query_limit = 5 if limit <= 0 else limit

        search_sql = """
            SELECT
                id,
                sigla,
                metadata,
                1 - (embedding <=> CAST(:emb AS vector)) as cosine_similarity
            FROM mymoney.classificacoes
            WHERE embedding IS NOT NULL
            ORDER BY embedding <=> CAST(:emb AS vector)
            LIMIT :lim
        """

        from sqlalchemy import text

        with env.DB_ENGINE.connect() as conn:
            results = conn.execute(
                text(search_sql),
                {"emb": embedding_str, "lim": query_limit}
            ).fetchall()

        if not results:
            logger.info("No classifications found in database")
            return []

        # Processar resultados e filtrar pelo threshold
        matches = []
        for result in results:
            similarity_score = float(result[3])

            if similarity_score >= similaridade:
                sigla_encontrada = result[1]
                id_referencia = result[0]

                logger.info(
                    f"Classification match found: sigla='{sigla_encontrada}', "
                    f"similarity={similarity_score:.4f}, ref_id={id_referencia}"
                )

                # Usar classificar_lancamento para formatar os dados
                dados = classificar_lancamento(lancamento, sigla_encontrada, llm_config)

                if dados is not None:
                    # Adicionar campos extras
                    dados["similaridade"] = similarity_score
                    dados["sigla_encontrada"] = sigla_encontrada
                    dados["id_referencia"] = id_referencia
                    matches.append(dados)

        if not matches:
            logger.info(
                f"No matches above threshold ({similaridade:.4f}) found"
            )
            return []

        return matches

    except Exception as exc:
        logger.error(f"Failed to classify lancamento via RAG: {exc}")
        return []


def _format_embedding_for_postgres(embedding: Optional[list[float] | list[list[float]]]) -> str:
    """
    Formata um vetor de embedding para o formato PostgreSQL pgvector.

    Parameters
    ----------
    embedding : list[float] or list[list[float]] or None
        Vetor de embedding. Pode ser uma lista simples [v1, v2, ...] ou
        uma lista aninhada [[v1, v2, ...]] (como retornado por algumas APIs).

    Returns
    -------
    str
        String formatada '[v1,v2,...]' ou NULL
    """
    if embedding is None or len(embedding) == 0:
        return "NULL"

    # Handle nested list case: [[v1, v2, ...]] -> [v1, v2, ...]
    if isinstance(embedding[0], list):
        embedding = embedding[0]

    return "'[" + ",".join(str(v) for v in embedding) + "]'"


def _batch_table_operation(
    operation: str,
    dataframe: pd.DataFrame,
    engine: Any,
    schema: str,
    table_name: str,
    table_keys: list[str],
    commit_at: int = 100,
) -> dict[str, Any]:
    """
    Executa operação batch em tabela PostgreSQL com suporte a tipo vector e JSONB.

    Método customizado para lidar com colunas especiais (vector, jsonb) que
    a lib fbpyutils_db não suporta nativamente.

    Parameters
    ----------
    operation : str
        Tipo de operação: 'append', 'upsert', 'replace'
    dataframe : pd.DataFrame
        DataFrame com os dados a serem inseridos/atualizados
    engine : sqlalchemy.Engine
        Conexão com o banco de dados
    schema : str
        Nome do schema
    table_name : str
        Nome da tabela
    table_keys : list[str]
        Colunas chave para identificação (ex: ['id'])
    commit_at : int
        Batch size para commit

    Returns
    -------
    dict
        Resultado da operação com insertions, updates, skips, failures
    """
    from sqlalchemy import text

    result = {
        "insertions": 0,
        "updates": 0,
        "skips": 0,
        "failures": [],
    }

    if dataframe.empty:
        result["skips"] = 1
        return result

    full_table = f"{schema}.{table_name}"
    columns = list(dataframe.columns)

    # Identificar colunas especiais
    embedding_col = "embedding" if "embedding" in columns else None
    metadata_col = "metadata" if "metadata" in columns else None

    try:
        logger.info(f"Starting batch operation: {operation} on {full_table} with {len(dataframe)} rows")
        with engine.begin() as conn:
            if operation == "replace":
                # TRUNCATE + INSERT
                conn.execute(text(f"TRUNCATE TABLE {full_table}"))
                logger.info(f"Table {full_table} truncated for replace operation")

            # Para upsert, verificar existência
            existing_ids = set()
            if operation == "upsert" and table_keys:
                key_col = table_keys[0]
                if key_col in columns:
                    ids = dataframe[key_col].tolist()
                    if ids:
                        placeholders = ",".join([f"'{i}'" for i in ids if pd.notna(i)])
                        if placeholders:
                            check_sql = f"SELECT {key_col} FROM {full_table} WHERE {key_col} IN ({placeholders})"
                            existing = conn.execute(text(check_sql)).fetchall()
                            existing_ids = {row[0] for row in existing}
                            result["updates"] = len(existing_ids)

            # Processar em batches
            batch_size = commit_at
            total_rows = len(dataframe)
            processed = 0

            for start_idx in range(0, total_rows, batch_size):
                batch_df = dataframe.iloc[start_idx:start_idx + batch_size]
                batch_insertions = 0
                batch_updates = 0

                for _, row in batch_df.iterrows():
                    # Use savepoint for each row to allow rollback on failure without aborting transaction
                    savepoint = conn.begin_nested()
                    try:
                        row_id = row.get(table_keys[0]) if table_keys else None
                        is_update = operation == "upsert" and row_id in existing_ids

                        # Preparar valores usando bindparams do SQLAlchemy
                        from sqlalchemy import bindparam
                        values = {}
                        params = {}
                        for col in columns:
                            val = row.get(col)
                            if col == embedding_col:
                                # Formato especial para vector - usar cast explícito
                                if val is None or len(val) == 0:
                                    values[col] = "NULL"
                                else:
                                    # Handle nested list
                                    if isinstance(val[0], list):
                                        val = val[0]
                                    values[col] = "CAST(:emb AS vector)"
                                    params["emb"] = "[" + ",".join(str(v) for v in val) + "]"
                            elif col == metadata_col:
                                # JSONB format
                                if val is None or (isinstance(val, float) and pd.isna(val)):
                                    values[col] = "'{}'"
                                else:
                                    json_str = json.dumps(val, ensure_ascii=False, default=str) if isinstance(val, dict) else str(val)
                                    values[col] = "CAST(:meta AS jsonb)"
                                    params["meta"] = json_str
                            elif col in table_keys and val is not None:
                                values[col] = f":{col}"
                                params[col] = str(val)
                            elif val is None or (isinstance(val, float) and pd.isna(val)):
                                values[col] = "NULL"
                            elif isinstance(val, bool):
                                values[col] = f":{col}"
                                params[col] = val
                            elif isinstance(val, (int, float)):
                                values[col] = f":{col}"
                                params[col] = val
                            elif isinstance(val, datetime):
                                values[col] = f":{col}"
                                params[col] = val
                            else:
                                values[col] = f":{col}"
                                params[col] = str(val) if val is not None else None

                        if is_update:
                            # UPDATE
                            set_clause = ", ".join([
                                f"{col} = {values[col]}"
                                for col in columns if col not in table_keys
                            ])
                            where_clause = " AND ".join([
                                f"{col} = {values[col]}"
                                for col in table_keys
                            ])
                            sql = f"UPDATE {full_table} SET {set_clause} WHERE {where_clause}"
                            stmt = text(sql).bindparams(**params)
                            conn.execute(stmt)
                            batch_updates += 1
                        else:
                            # INSERT
                            cols = ", ".join(columns)
                            vals = ", ".join(values[col] for col in columns)
                            sql = f"INSERT INTO {full_table} ({cols}) VALUES ({vals})"
                            stmt = text(sql).bindparams(**params)
                            conn.execute(stmt)
                            batch_insertions += 1

                        savepoint.commit()

                    except Exception as e:
                        savepoint.rollback()
                        error_msg = str(e)
                        row_id = row.get(table_keys[0], 'unknown') if table_keys else 'unknown'
                        logger.error(f"Failed to process row {row_id}: {error_msg}")
                        # Log the actual SQL that failed (truncated)
                        if 'sql' in locals():
                            sql_trunc = sql[:500] + "..." if len(sql) > 500 else sql
                            logger.debug(f"Failed SQL: {sql_trunc}")
                        result["failures"].append({
                            "row_id": row_id,
                            "error": error_msg,
                        })

                result["insertions"] += batch_insertions
                if operation == "upsert":
                    result["updates"] += batch_updates

                processed += len(batch_df)
                logger.info(f"Processed {processed}/{total_rows} rows for {full_table}")

        return result

    except Exception as e:
        logger.error(f"Batch operation failed: {e}")
        result["failures"].append({"error": str(e)})
        return result


class DataLoadClassificacaoProcessor:
    """
    Processor especializado para carga de classificações com geração de embeddings.

    Este processor é usado pelo DataLoadDataProcessor quando o kind é 'classificacao'.
    Também pode ser usado diretamente para classificar lançamentos individuais.
    """

    @staticmethod
    def process_sheet(
        scope: str,
        sheet_config: dict[str, Any],
        process_params: dict[str, Any],
    ) -> list[list[Any]]:
        """
        Processa uma sheet de classificacao gerando embeddings.

        Parameters
        ----------
        scope : str
            Escopo do processamento
        sheet_config : dict
            Configuração da sheet (kind, sheet_name, table_name, operation)
        process_params : dict
            Parâmetros do processo (schema, input_file, agent, dry_run, etc.)

        Returns
        -------
        list[list[Any]]
            Resultado do processamento no formato [[scope, success, error_message, summary_df]]
        """
        kind = sheet_config["kind"]
        summary = {
            "scope": scope,
            "kind": kind,
            "sheet_name": sheet_config["sheet_name"],
            "arquivo_origem": process_params["input_file"],
            "schema": process_params["schema"],
            "table_name": sheet_config["table_name"],
            "operation": sheet_config["operation"],
            "dry_run": process_params["dry_run"],
            "records": 0,
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": 0,
        }
        unit_key = f"{process_params['input_file']}::{sheet_config['sheet_name']}"
        recorder = get_operation_recorder()
        recorder.start_unit(
            process_params["operacao_id"],
            unidade=unit_key,
            escopo=scope,
            arquivo_origem=process_params["input_file"],
            guia=sheet_config["sheet_name"],
            tipo_unidade=kind,
        )

        try:
            operation = sheet_config["operation"].lower()

            table_schema = get_schema(
                process_params["schema"], sheet_config["table_name"], env.SCHEMAS
            )

            input_df = capitalize(
                pl.read_excel(
                    process_params["input_file"],
                    sheet_name=sheet_config["sheet_name"],
                    engine="calamine",
                ).to_pandas(),
                "lower",
            )

            if input_df.empty:
                summary["skips"] = 1
                recorder.finish_unit(
                    process_params["operacao_id"],
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            output_df = _build_classificacao_dataframe(
                input_df=input_df,
                agent=process_params["agent"],
                kind=kind,
                input_file=process_params["input_file"],
                table_schema=table_schema,
            )

            if output_df.empty:
                summary["skips"] = 1
                summary["failures"] = len(input_df)  # Registros que falharam
                recorder.finish_unit(
                    process_params["operacao_id"],
                    unidade=unit_key,
                    sucesso=True,  # Considera sucesso pois o processo rodou
                    mensagem_erro=f"Nenhum registro processado com sucesso (falhas: {len(input_df)})",
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            summary["records"] = len(output_df)

            operation_result = {
                "insertions": 0,
                "updates": 0,
                "skips": 0,
                "failures": [],
            }

            if not process_params["dry_run"]:
                operation_result = _batch_table_operation(
                    operation=operation,
                    dataframe=output_df,
                    engine=env.DB_ENGINE,
                    schema=process_params["schema"],
                    table_name=sheet_config["table_name"],
                    table_keys=["id"],
                    commit_at=100,
                )

            failures = operation_result.get("failures", [])
            failure_count = len(failures) if isinstance(failures, list) else int(bool(failures))
            summary["insertions"] = int(operation_result.get("insertions", 0) or 0)
            summary["updates"] = int(operation_result.get("updates", 0) or 0)
            summary["skips"] = int(operation_result.get("skips", 0) or 0)
            summary["failures"] = int(failure_count)

            success = failure_count == 0
            if success:
                error_message = None
            else:
                # Include first error details in message
                first_error = failures[0].get("error", "Unknown error") if failures and isinstance(failures[0], dict) else "Unknown error"
                error_message = f"{failure_count} row(s) failed on DB operation. First error: {first_error[:200]}"
                # Store all errors in summary for debugging
                summary["failure_details"] = failures[:10]  # Store first 10 errors

            recorder.finish_unit(
                process_params["operacao_id"],
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )
            return [[scope, success, error_message, pd.DataFrame([summary])]]

        except Exception as exc:
            recorder.finish_unit(
                process_params["operacao_id"],
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]
