"""
DataTransformClassificacaoLancamentosProcessor - Processor para classificação automática de lançamentos.

Este processor processa lançamentos da tabela `mymoney.lancamentos` sem classificação ou
marcados para reclassificação, utilizando busca RAG na tabela `mymoney.classificacoes`
para determinar a sigla apropriada.
"""

import json
from datetime import datetime
from typing import Any, Callable, Optional

import pandas as pd
from fbpyutils.uuid import hash_string
from infobr.data import DataProcessor
from sqlalchemy import text

from mymoney import env, logger
from mymoney.data.elt.load.classificacao import classificar
from mymoney.data.providers.unstructured.engine import (
    UnstructuredLLMConfig,
    resolve_llm_config_from_user_settings,
)
from mymoney.services.operations import get_operation_recorder
from infobr.data.process import ProcessWithCallback


def _compose_embedding_text_lancamento(row: dict[str, Any]) -> str:
    """
    Compõe o texto para geração de embedding a partir de um lançamento.

    Usa as mesmas colunas definidas em classificar_lancamento para consistência.

    Parameters
    ----------
    row : dict
        Dicionário com os dados do lançamento

    Returns
    -------
    str
        Texto formatado em JSON para embedding
    """
    # Mapear entrada_saida (D/C) para Debito/Credito
    dc = row.get("entrada_saida", "")
    if dc == "C":
        dc = "Credito"
    elif dc == "D":
        dc = "Debito"

    embedding_data = {
        "movimentacao": row.get("movimentacao", ""),
        "descricao": row.get("nome_produto", ""),
        "dc": dc,
        "valor": float(row.get("valor_operacao", 0)) if pd.notna(row.get("valor_operacao")) else 0.0,
        "moeda": row.get("moeda", "BRL"),
    }
    return json.dumps(embedding_data, ensure_ascii=False, sort_keys=True)


def _determinar_classificacao(
    matches: list[dict[str, Any]],
    threshold_ok: float = 0.98,
    diversity_check: bool = True,
) -> tuple[str, str]:
    """
    Determina a sigla e classificação apropriada baseado nos matches encontrados.

    Regras:
    1. Se matches >= threshold_ok: usar melhor match, classificacao = 'OK'
    2. Se matches < threshold_ok mas >= threshold_busca: usar melhor match, classificacao = 'AVALIAR'
    3. Sem matches ou abaixo do threshold: sigla = '', classificacao = 'MANUAL'
    4. Se todos os top matches têm mesma sigla (eco chamber): exigir threshold elevado ou forçar 'AVALIAR'

    Parameters
    ----------
    matches : list[dict]
        Lista de matches retornados pela função classificar
    threshold_ok : float
        Threshold para considerar classificação automática (default: 0.98)
    diversity_check : bool
        Se True, verifica diversidade dos matches para evitar "eco chamber" (default: True)

    Returns
    -------
    tuple[str, str]
        (sigla, classificacao) a serem aplicadas
    """
    if not matches:
        return "", "MANUAL"

    # Ordenar por similaridade (maior primeiro)
    matches_sorted = sorted(matches, key=lambda x: x.get("similaridade", 0), reverse=True)
    best_match = matches_sorted[0]
    best_similarity = best_match.get("similaridade", 0)

    sigla = best_match.get("sigla_encontrada", "")

    # Item 4 & 5: Verificar diversidade dos matches para detectar "eco chamber"
    if diversity_check and len(matches_sorted) >= 3:
        # Verificar se os top-3 matches têm a mesma sigla
        top_3_siglas = [m.get("sigla_encontrada", "") for m in matches_sorted[:3]]
        todas_mesmas_sigla = len(set(top_3_siglas)) == 1

        # Verificar se vêm da mesma combinação instituicao:movimentacao
        top_3_combinacoes = []
        for m in matches_sorted[:3]:
            metadata = m.get("metadata", {})
            if isinstance(metadata, str):
                import json
                metadata = json.loads(metadata)
            instituicao = metadata.get("instituicao", "")
            movimentacao = metadata.get("movimentacao", "")
            top_3_combinacoes.append(f"{instituicao}:{movimentacao}")

        todas_mesmas_combinacao = len(set(top_3_combinacoes)) == 1

        # Se todos os matches têm mesma sigla E mesma combinação → eco chamber detectado
        if todas_mesmas_sigla and todas_mesmas_combinacao:
            logger.warning(
                f"Eco chamber detectado: todos os top-3 matches têm sigla='{sigla}' "
                f"e combinação='{top_3_combinacoes[0]}'. Forçando AVALIAR."
            )
            return sigla, "AVALIAR"

    # Item 2: threshold_ok elevado para 0.98
    if best_similarity >= threshold_ok:
        return sigla, "OK"
    else:
        return sigla, "AVALIAR"


def _batch_upsert_lancamentos_detalhe(
    dataframe: pd.DataFrame,
    schema: str = "mymoney",
) -> dict[str, Any]:
    """
    Realiza upsert batch na tabela lancamentos_detalhe.

    Parameters
    ----------
    dataframe : pd.DataFrame
        DataFrame com colunas: id, sigla, classificacao, arquivo_origem, data_referencia, usuario
    schema : str
        Nome do schema

    Returns
    -------
    dict
        Resultado com insertions, updates, failures
    """
    result = {
        "insertions": 0,
        "updates": 0,
        "failures": [],
    }

    if dataframe.empty:
        return result

    full_table = f"{schema}.lancamentos_detalhe"
    columns = ["id", "sigla", "classificacao", "exclusao", "arquivo_origem", "data_referencia", "usuario"]

    try:
        with env.DB_ENGINE.begin() as conn:
            for _, row in dataframe.iterrows():
                savepoint = conn.begin_nested()
                try:
                    row_id = row.get("id")

                    # Verificar se já existe
                    check_sql = text(f"SELECT id FROM {full_table} WHERE id = :id")
                    existing = conn.execute(check_sql, {"id": row_id}).fetchone()

                    if existing:
                        # UPDATE
                        update_sql = text(f"""
                            UPDATE {full_table}
                            SET sigla = :sigla,
                                classificacao = :classificacao,
                                exclusao = :exclusao,
                                arquivo_origem = :arquivo_origem,
                                data_referencia = :data_referencia,
                                usuario = :usuario
                            WHERE id = :id
                        """)
                        conn.execute(
                            update_sql,
                            {
                                "id": row_id,
                                "sigla": row.get("sigla") or "",
                                "classificacao": row.get("classificacao", "AVALIAR"),
                                "exclusao": row.get("exclusao", False),
                                "arquivo_origem": row.get("arquivo_origem", "mm.lancamentos"),
                                "data_referencia": row.get("data_referencia", datetime.now()),
                                "usuario": row.get("usuario", env.USER),
                            }
                        )
                        result["updates"] += 1
                    else:
                        # INSERT
                        insert_sql = text(f"""
                            INSERT INTO {full_table}
                            (id, sigla, classificacao, exclusao, arquivo_origem, data_referencia, usuario)
                            VALUES
                            (:id, :sigla, :classificacao, :exclusao, :arquivo_origem, :data_referencia, :usuario)
                        """)
                        conn.execute(
                            insert_sql,
                            {
                                "id": row_id,
                                "sigla": row.get("sigla") or "",
                                "classificacao": row.get("classificacao", "AVALIAR"),
                                "exclusao": row.get("exclusao", False),
                                "arquivo_origem": row.get("arquivo_origem", "mm.lancamentos"),
                                "data_referencia": row.get("data_referencia", datetime.now()),
                                "usuario": row.get("usuario", env.USER),
                            }
                        )
                        result["insertions"] += 1

                    savepoint.commit()

                except Exception as e:
                    savepoint.rollback()
                    error_msg = str(e)
                    row_id = row.get("id", "unknown")
                    logger.error(f"Failed to upsert lancamento_detalhe {row_id}: {error_msg}")
                    result["failures"].append({
                        "row_id": row_id,
                        "error": error_msg,
                    })

        return result

    except Exception as e:
        logger.error(f"Batch upsert operation failed: {e}")
        result["failures"].append({"error": str(e)})
        return result


class DataTransformClassificacaoLancamentosProcessor(DataProcessor):
    """
    Processor para classificação automática de lançamentos via RAG.

    Processa lançamentos da tabela `mymoney.lancamentos` que:
    - Não possuem registro correspondente em `lancamentos_detalhe`
    - OU possuem registro com `classificacao` = 'RECLASSIFICAR'

    Para cada lançamento, busca classificações similares na tabela `classificacoes`
    e insere/atualiza o registro em `lancamentos_detalhe` com a sigla encontrada.
    """

    EXPECTED_PARAMS = {
        "scope": (str, False, "transform"),
        "agent": (str, False, "mm.data.elt.transform.classificacao"),
        "schema": (str, False, "mymoney"),
        "table_name": (str, False, "lancamentos_detalhe"),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "dry_run": (bool, False, False),
        "pipeline_name": (str, False, None),
        "operacao_id": (str, False, None),
        "similaridade_threshold": (float, False, 0.85),
        "threshold_ok": (float, False, 0.98),  # Elevado para evitar falsos positivos
        "diversity_check": (bool, False, True),  # Habilita detecção de eco chamber
        "batch_size": (int, False, 100),
        "limit": (int, False, 0),  # 0 = processar todos (full), N > 0 = limitar a N registros
    }

    @staticmethod
    def process(
        scope: str,
        sheet_config: dict[str, Any],
        process_params: dict[str, Any],
        limit: int = 0,
        item_callback: Optional[Callable[[int, int, str], None]] = None,
    ) -> list[list[Any]]:
        """
        Processa lançamentos para classificação automática.

        Parameters
        ----------
        scope : str
            Escopo do processamento (LANCAMENTOS_CONTA_CORRENTE ou LANCAMENTOS_CARTAO_CREDITO)
        sheet_config : dict
            Configuração da sheet
        process_params : dict
            Parâmetros do processo (schema, dry_run, similaridade_threshold, batch_size)
        limit : int
            Limite de registros a processar (0 = todos)
        item_callback : callable, optional
            Callback para reportar progresso de cada item: (current, total, item_id)

        Returns
        -------
        list[list[Any]]
            Resultado no formato [[scope, success, error_message, summary_df]]
        """
        kind = sheet_config.get("kind", "transform")
        schema = process_params.get("schema", "mymoney")
        dry_run = process_params.get("dry_run", False)

        # Configurações de threshold
        similaridade_threshold = sheet_config.get("similaridade_threshold", 0.85)
        threshold_ok = sheet_config.get("threshold_ok", 0.98)  # Elevado para evitar falsos positivos
        diversity_check = sheet_config.get("diversity_check", True)  # Habilita detecção de eco chamber
        batch_size = sheet_config.get("batch_size", 100)

        summary = {
            "scope": scope,
            "kind": kind,
            "schema": schema,
            "table_name": sheet_config.get("table_name", "lancamentos_detalhe"),
            "dry_run": dry_run,
            "similaridade_threshold": similaridade_threshold,
            "threshold_ok": threshold_ok,
            "batch_size": batch_size,
            "total_lancamentos": 0,
            "processados": 0,
            "ok": 0,
            "avaliar": 0,
            "manual": 0,
            "erros": 0,
            "insertions": 0,
            "updates": 0,
        }

        operacao_id = process_params.get("operacao_id")
        unit_key = f"transform::classificacao::{scope}"
        recorder = get_operation_recorder()
        recorder.start_unit(
            operacao_id,
            unidade=unit_key,
            escopo=scope,
            arquivo_origem="database",
            guia="lancamentos",
            tipo_unidade=kind,
        )

        try:
            # Buscar lançamentos a processar
            limit_clause = f"LIMIT {limit}" if limit > 0 else ""
            query_sql = text(f"""
                SELECT l.*
                FROM {schema}.lancamentos l
                LEFT JOIN {schema}.lancamentos_detalhe ld ON l.id = ld.id
                WHERE l.tipo_lancamento = :tipo_lancamento
                  AND (
                      ld.id IS NULL
                      OR ld.classificacao = 'RECLASSIFICAR'
                  )
                {limit_clause}
            """)

            with env.DB_ENGINE.connect() as conn:
                result = conn.execute(
                    query_sql,
                    {"tipo_lancamento": scope}
                )
                lancamentos = result.mappings().all()

            if not lancamentos:
                logger.info(f"Nenhum lançamento pendente de classificação para {scope}")
                summary["total_lancamentos"] = 0
                recorder.finish_unit(
                    operacao_id,
                    unidade=unit_key,
                    sucesso=True,
                    mensagem_erro=None,
                    dados=dict(summary),
                )
                return [[scope, True, None, pd.DataFrame([summary])]]

            summary["total_lancamentos"] = len(lancamentos)
            logger.info(f"Encontrados {len(lancamentos)} lançamentos para classificar em {scope}")

            # Preparar configuração LLM
            llm_config = resolve_llm_config_from_user_settings()

            # Processar em batches
            detalhes_to_upsert = []
            batch_count = 0

            for idx, lancamento_row in enumerate(lancamentos):
                try:
                    lancamento_dict = dict(lancamento_row)
                    lancamento_id = lancamento_dict.get("id")

                    # Reportar progresso do item
                    if item_callback:
                        instituicao = lancamento_dict.get("instituicao", "")[:15]
                        movimentacao = lancamento_dict.get("movimentacao", "")[:20]
                        item_desc = f"{instituicao}:{movimentacao}"
                        item_callback(idx + 1, len(lancamentos), item_desc)

                    # Preparar dados para classificação (campos alinhados com classificacoes)
                    lancamento_data = {
                        "movimentacao": lancamento_dict.get("movimentacao"),
                        "descricao": lancamento_dict.get("nome_produto"),
                        "dc": lancamento_dict.get("entrada_saida"),
                        "valor": lancamento_dict.get("valor_operacao"),
                        "moeda": lancamento_dict.get("moeda", "BRL"),
                    }

                    # Buscar classificações similares (limit=5 conforme especificação)
                    matches = classificar(
                        lancamento_data,
                        similaridade=similaridade_threshold,
                        llm_config=llm_config,
                        limit=5,
                    )

                    # Determinar sigla e classificacao
                    sigla, classificacao = _determinar_classificacao(
                        matches,
                        threshold_ok=threshold_ok,
                        diversity_check=diversity_check,
                    )

                    # Preparar registro para lancamentos_detalhe
                    detalhe_row = {
                        "id": lancamento_id,
                        "sigla": sigla,
                        "classificacao": classificacao,
                        "exclusao": False,
                        "arquivo_origem": "mm.lancamentos",
                        "data_referencia": datetime.now(),
                        "usuario": env.USER,
                    }
                    detalhes_to_upsert.append(detalhe_row)

                    # Atualizar contadores
                    summary["processados"] += 1
                    if classificacao == "OK":
                        summary["ok"] += 1
                    elif classificacao == "AVALIAR":
                        summary["avaliar"] += 1
                    else:
                        summary["manual"] += 1

                    # Processar batch quando atingir o tamanho
                    if len(detalhes_to_upsert) >= batch_size:
                        if not dry_run:
                            batch_result = _batch_upsert_lancamentos_detalhe(
                                pd.DataFrame(detalhes_to_upsert),
                                schema=schema,
                            )
                            summary["insertions"] += batch_result.get("insertions", 0)
                            summary["updates"] += batch_result.get("updates", 0)
                            summary["erros"] += len(batch_result.get("failures", []))

                        batch_count += 1
                        logger.info(f"Processado batch {batch_count}: {len(detalhes_to_upsert)} registros")
                        detalhes_to_upsert = []

                except Exception as exc:
                    logger.warning(f"Erro ao processar lançamento {lancamento_id}: {exc}")
                    summary["erros"] += 1
                    # Continua para o próximo (não insere registro em caso de erro técnico)
                    continue

            # Processar registros restantes
            if detalhes_to_upsert:
                if not dry_run:
                    batch_result = _batch_upsert_lancamentos_detalhe(
                        pd.DataFrame(detalhes_to_upsert),
                        schema=schema,
                    )
                    summary["insertions"] += batch_result.get("insertions", 0)
                    summary["updates"] += batch_result.get("updates", 0)
                    summary["erros"] += len(batch_result.get("failures", []))

                logger.info(f"Processado batch final: {len(detalhes_to_upsert)} registros")

            success = summary["erros"] == 0
            error_message = None if success else f"Ocorreram {summary['erros']} erros durante o processamento"

            recorder.finish_unit(
                operacao_id,
                unidade=unit_key,
                sucesso=success,
                mensagem_erro=error_message,
                dados=dict(summary),
            )

            return [[scope, success, error_message, pd.DataFrame([summary])]]

        except Exception as exc:
            recorder.finish_unit(
                operacao_id,
                unidade=unit_key,
                sucesso=False,
                mensagem_erro=str(exc),
                dados=dict(summary),
            )
            return [[scope, False, str(exc), pd.DataFrame([summary])]]

    def run(
        self, progress_callback=None
    ) -> list[list[list[Any]]]:
        """
        Executa o processamento de classificação para os scopes configurados.

        Parameters
        ----------
        progress_callback : callable, optional
            Callback para reportar progresso

        Returns
        -------
        list[list[list[Any]]]
            Resultados do processamento no formato [[[scope, success, error_message, data]]]
        """
        from tqdm import tqdm
        from sqlalchemy import text

        scopes = ["LANCAMENTOS_CONTA_CORRENTE", "LANCAMENTOS_CARTAO_CREDITO"]
        schema = self.params.get("schema", "mymoney")
        limit = self.params.get("limit", 0)

        # Contar total de lançamentos a processar (para barra de progresso)
        total_items = 0
        scope_counts = {}
        try:
            for scope in scopes:
                query_sql = text(f"""
                    SELECT COUNT(*)
                    FROM {schema}.lancamentos l
                    LEFT JOIN {schema}.lancamentos_detalhe ld ON l.id = ld.id
                    WHERE l.tipo_lancamento = :tipo_lancamento
                      AND (ld.id IS NULL OR ld.classificacao = 'RECLASSIFICAR')
                """)
                with env.DB_ENGINE.connect() as conn:
                    result = conn.execute(query_sql, {"tipo_lancamento": scope})
                    count = result.scalar() or 0
                    # Aplicar limit manualmente
                    if limit > 0:
                        count = min(count, limit)
                    scope_counts[scope] = count
                    total_items += count
        except Exception as e:
            logger.warning(f"Não foi possível contar lançamentos: {e}")
            total_items = None  # Barra sem total definido

        # Criar barra de progresso granular
        pbar = None
        if self.params.get("progress", False) and total_items:
            pbar = tqdm(
                total=total_items,
                desc="Classificando",
                unit="lançamentos",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}] {postfix}"
            )

        # Contador thread-safe para modo paralelo
        from threading import Lock
        progress_lock = Lock()
        processed_count = [0]  # Lista para mutabilidade em closure

        def _item_callback(current, total, item_desc):
            """Callback chamado para cada item processado."""
            if pbar:
                with progress_lock:
                    processed_count[0] += 1
                    pbar.update(1)
                    # Truncar descrição para caber na barra
                    desc = item_desc[:30] if item_desc else ""
                    pbar.set_postfix({"item": desc}, refresh=True)
            # Também chamar o callback original se existir
            if progress_callback:
                progress_callback(processed_count[0], total_items or total, item_desc)

        # Preparar parâmetros para cada scope
        process_params_list = [
            (
                scope,
                {
                    "kind": "transform",
                    "table_name": self.params.get("table_name", "lancamentos_detalhe"),
                    "similaridade_threshold": self.params.get("similaridade_threshold", 0.85),
                    "threshold_ok": self.params.get("threshold_ok", 0.95),
                    "batch_size": self.params.get("batch_size", 100),
                },
                {
                    "schema": schema,
                    "dry_run": self.params.get("dry_run", False),
                    "operacao_id": self.params.get("operacao_id"),
                    "agent": self.params.get("agent", "mm.data.elt.transform.classificacao"),
                },
                limit,
                _item_callback if pbar or progress_callback else None,
            )
            for scope in scopes
        ]

        def _process_scope_runner(scope, sheet_config, process_params, limit, item_cb):
            return DataTransformClassificacaoLancamentosProcessor.process(
                scope, sheet_config, process_params, limit, item_cb
            )

        try:
            if self.params.get("parallelize", False):
                process = ProcessWithCallback(
                    process=_process_scope_runner,
                    parallelize=True,
                    workers=ProcessWithCallback.get_available_cpu_count(),
                    progress_callback=None,  # Usamos item_callback internamente
                )
                results = process.run(process_params_list, progress=False)
            else:
                results = []
                for idx, (scope, sheet_config, process_params, lim, item_cb) in enumerate(process_params_list):
                    result = _process_scope_runner(scope, sheet_config, process_params, lim, item_cb)
                    results.append(result)

            return results
        finally:
            if pbar:
                pbar.close()
