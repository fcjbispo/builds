from mymoney.data.elt.tui import main


if __name__ == "__main__":
    main()
