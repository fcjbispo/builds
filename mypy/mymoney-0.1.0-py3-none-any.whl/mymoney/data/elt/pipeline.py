import json
import os
from datetime import datetime
from typing import Any, Optional

import pandas as pd

from mymoney import env, emit_debug_trace, logger
from mymoney.data.elt.load.cei import CeiLoadDataProcessor
from mymoney.data.elt.load.data import DataLoadDataProcessor
from mymoney.data.elt.load.fgts import FgtsLoadDataProcessor
from mymoney.data.elt.load.inter import (
    InterApexAccountLoadDataProcessor,
    InterApexNcAccountLoadDataProcessor,
    InterCartaoLoadDataProcessor,
    InterGlobalAccountLoadDataProcessor,
    InterAccountLoadDataProcessor,
)
from mymoney.data.elt.load.mercado_pago import (
    MercadoPagoAccountLoadDataProcessor,
    MercadoPagoCartaoLoadDataProcessor,
)
from mymoney.data.elt.load.next import (
    NextAccountLoadDataProcessor,
    NextCartaoLoadDataProcessor,
)
from mymoney.data.elt.load.nubank import (
    NubankAccountLoadDataProcessor,
    NubankCartaoLoadDataProcessor,
)
from mymoney.data.elt.load.picpay import (
    PicPayAccountLoadDataProcessor,
    PicPayCartaoLoadDataProcessor,
)
from mymoney.data.elt.transform.classificacao import DataTransformClassificacaoLancamentosProcessor
from mymoney.services.operations import get_operation_recorder


LEGACY_PROCESSOR_ALIASES = {
    "InterLoadDataProcessor": "InterAccountLoadDataProcessor",
    "InterGlobalLoadDataProcessor": "InterGlobalAccountLoadDataProcessor",
    "InterApexLoadDataProcessor": "InterApexAccountLoadDataProcessor",
    "InterApexNcLoadDataProcessor": "InterApexNcAccountLoadDataProcessor",
    "PicPayLoadDataProcessor": "PicPayAccountLoadDataProcessor",
    "MercadoPagoLoadDataProcessor": "MercadoPagoAccountLoadDataProcessor",
}


# NOTE: DEFAULT_PIPELINE_CONTRACTS foi removido conforme PROMPT 017.
# Pipelines devem ser migradas para o banco de dados via comando 'mymoney pipelines migrate'.

# NOTE: PIPELINE_ALIASES foi removido conforme PROMPT 017.
# Pipelines devem ser referenciadas pelo seu nome exato no banco de dados.


def _serialize_results(results: list[list[list[Any]]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group in results:
        if not isinstance(group, list):
            continue
        for row in group:
            if not isinstance(row, (list, tuple)) or len(row) != 4:
                continue
            scope, success, error_message, data = row
            if isinstance(data, pd.DataFrame):
                data_payload = data.to_dict(orient="records")
            elif isinstance(data, list):
                data_payload = data
            elif isinstance(data, dict):
                data_payload = [data]
            else:
                data_payload = [{"value": str(data)}]

            rows.append(
                {
                    "scope": scope,
                    "success": bool(success),
                    "error_message": error_message,
                    "data": data_payload,
                }
            )
    return rows


def save_pipeline_results(pipeline_name: str, results: list[list[list[Any]]]) -> str:
    os.makedirs(env.OPERATIONS_FOLDER, exist_ok=True)
    output_file = os.path.sep.join(
        [
            env.OPERATIONS_FOLDER,
            f"{pipeline_name}.out.{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.json",
        ]
    )
    serialized = _serialize_results(results)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(serialized, f, ensure_ascii=False, indent=4, default=str)
    return output_file


# NOTE: ensure_default_pipeline_contracts foi removido conforme PROMPT 017.
# Pipelines devem ser migradas para o banco de dados via comando 'mymoney pipelines migrate'.


class Pipeline:
    PROCESSORS = {
        "CeiLoadDataProcessor": CeiLoadDataProcessor,
        "DataLoadDataProcessor": DataLoadDataProcessor,
        "InterAccountLoadDataProcessor": InterAccountLoadDataProcessor,
        "InterGlobalAccountLoadDataProcessor": InterGlobalAccountLoadDataProcessor,
        "InterApexAccountLoadDataProcessor": InterApexAccountLoadDataProcessor,
        "InterApexNcAccountLoadDataProcessor": InterApexNcAccountLoadDataProcessor,
        "InterLoadDataProcessor": InterAccountLoadDataProcessor,
        "InterGlobalLoadDataProcessor": InterGlobalAccountLoadDataProcessor,
        "InterApexLoadDataProcessor": InterApexAccountLoadDataProcessor,
        "InterApexNcLoadDataProcessor": InterApexNcAccountLoadDataProcessor,
        "InterApexNcAccountLoadDataProcessor": InterApexNcAccountLoadDataProcessor,
        "InterCartaoLoadDataProcessor": InterCartaoLoadDataProcessor,
        "PicPayLoadDataProcessor": PicPayAccountLoadDataProcessor,
        "PicPayAccountLoadDataProcessor": PicPayAccountLoadDataProcessor,
        "PicPayCartaoLoadDataProcessor": PicPayCartaoLoadDataProcessor,
        "MercadoPagoAccountLoadDataProcessor": MercadoPagoAccountLoadDataProcessor,
        "MercadoPagoCartaoLoadDataProcessor": MercadoPagoCartaoLoadDataProcessor,
        "NubankAccountLoadDataProcessor": NubankAccountLoadDataProcessor,
        "NubankCartaoLoadDataProcessor": NubankCartaoLoadDataProcessor,
        "NextAccountLoadDataProcessor": NextAccountLoadDataProcessor,
        "NextCartaoLoadDataProcessor": NextCartaoLoadDataProcessor,
        "FgtsLoadDataProcessor": FgtsLoadDataProcessor,
        "DataTransformClassificacaoLancamentosProcessor": DataTransformClassificacaoLancamentosProcessor,
    }

    def __init__(self, pipeline_name: str):
        if not pipeline_name:
            raise ValueError("Pipeline name must be provided.")
        self.pipeline_name = PIPELINE_ALIASES.get(pipeline_name, pipeline_name)

    @property
    def path(self) -> str:
        return os.path.sep.join([env.PIPELINES_FOLDER, f"{self.pipeline_name}.json"])

    def load(self) -> dict[str, Any]:
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"Pipeline file not found: {self.path}")
        with open(self.path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError(f"Invalid pipeline contract format: {self.path}")
        return data

    def run(
        self,
        parallelize: bool = True,
        progress: bool = False,
        progress_callback=None,
        **overrides,
    ) -> dict[str, Any]:
        emit_debug_trace(
            f"Pipeline.run start pipeline_name={self.pipeline_name} parallelize={parallelize} progress={progress}"
        )
        contract = self.load()
        processor_name = contract.pop("processor", None)
        if not processor_name:
            raise ValueError("Pipeline contract must include 'processor'.")
        if processor_name not in self.PROCESSORS:
            raise ValueError(f"Unsupported processor: {processor_name}")
        emit_debug_trace(
            f"Pipeline.run loaded contract pipeline_name={self.pipeline_name} processor={processor_name}"
        )

        processor_cls = self.PROCESSORS[processor_name]
        allowed_params = set(processor_cls.EXPECTED_PARAMS.keys())
        contract["parallelize"] = parallelize
        contract["progress"] = progress
        for key, value in overrides.items():
            if key in allowed_params:
                contract[key] = value
        operation_scope = str(contract.get("scope") or processor_name)
        operation_dry_run = bool(contract.get("dry_run", False))
        operation_id = get_operation_recorder().start_scope(
            pipeline=self.pipeline_name,
            escopo=operation_scope,
            processador=processor_name,
            dry_run=operation_dry_run,
            parallelize=parallelize,
            esquema=contract.get("schema"),
            tabela=contract.get("table_name"),
            operacao=contract.get("operation"),
            origem=contract.get("source") or contract.get("agent"),
            tipo_lancamento=contract.get("transaction_type"),
        )
        contract["pipeline_name"] = self.pipeline_name
        contract["operacao_id"] = operation_id
        contract = {k: v for k, v in contract.items() if k in allowed_params}

        processor = processor_cls(contract)
        emit_debug_trace(
            f"Pipeline.run instantiated processor pipeline_name={self.pipeline_name} processor={processor_name}"
        )
        callback = progress_callback
        if not progress and callback is None:
            callback = lambda *_args, **_kwargs: None

        try:
            if callback:
                emit_debug_trace(
                    f"Pipeline.run invoking processor with callback pipeline_name={self.pipeline_name}"
                )
                results = processor.run(progress_callback=callback)
            else:
                emit_debug_trace(
                    f"Pipeline.run invoking processor without callback pipeline_name={self.pipeline_name}"
                )
                results = processor.run()
            emit_debug_trace(
                f"Pipeline.run processor returned pipeline_name={self.pipeline_name}"
            )

            success_count = 0
            failure_count = 0
            for row in _serialize_results(results):
                if row.get("success", False):
                    success_count += 1
                else:
                    failure_count += 1

            get_operation_recorder().finalize_scope(
                operation_id,
                sucesso=failure_count == 0,
                mensagem_erro=None if failure_count == 0 else f"{failure_count} unidade(s) falharam.",
            )
        except BaseException as exc:
            get_operation_recorder().finalize_scope(
                operation_id,
                sucesso=False,
                mensagem_erro=str(exc),
            )
            raise

        logger.info(
            f"Pipeline '{self.pipeline_name}' finished. "
            f"success={success_count}, failure={failure_count}, operation_id={operation_id}"
        )
        return {
            "pipeline_name": self.pipeline_name,
            "operation_id": operation_id,
            "operation_file": operation_id,
            "success_count": success_count,
            "failure_count": failure_count,
        }


def run_pipelines(
    pipeline_names: Optional[list[str]] = None,
    parallelize: bool = True,
    progress: bool = False,
    **overrides,
) -> list[dict[str, Any]]:
    """Executa pipelines a partir do banco de dados.

    NOTE: Conforme PROMPT 017, pipelines devem existir no banco de dados.
    Use 'mymoney pipelines migrate' para migrar pipelines de arquivos JSON.
    """
    if not pipeline_names:
        raise ValueError(
            "É necessário especificar os nomes das pipelines a executar. "
            "Use 'mymoney pipelines list' para ver as pipelines disponíveis no banco de dados."
        )

    results = []
    for pipeline_name in pipeline_names:
        pipeline = Pipeline(pipeline_name)
        results.append(
            pipeline.run(
                parallelize=parallelize,
                progress=progress,
                **overrides,
            )
        )
    return results
