#!/usr/bin/env python3
"""MyMoney ELT Pipeline TUI/CLI."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
)
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.text import Text

from mymoney import env, logger
from mymoney.services import (
    estimate_pipeline_items,
    get_operation_page,
    get_pipeline_config,
    list_operation_files,
    list_pipelines_from_files,
    run_pipeline,
    summarize_pipeline_execution,
    validate_pipeline_exists_in_files,
)

console = Console()


class ELT_TUI:
    PIPELINES_FOLDER = env.PIPELINES_FOLDER
    OPERATIONS_FOLDER = env.OPERATIONS_FOLDER

    def clear_screen(self) -> None:
        console.clear()

    def get_pipelines(self) -> list[tuple[str, str]]:
        """Lista pipelines disponíveis (legado - usa arquivos).n
        NOTE: Conforme PROMPT 017, pipelines devem ser migradas para o DB.
        Use 'mymoney pipelines migrate' para migrar.
        """
        items = list_pipelines_from_files(self.PIPELINES_FOLDER)
        return [(item.name, item.path) for item in items]

    def display_header(self) -> None:
        panel = Panel(
            Text("MyMoney ELT Pipeline Manager", style="bold cyan", justify="center"),
            subtitle=f"User: {env.USER}",
            box=box.SQUARE,
            border_style="blue",
        )
        console.print(panel)
        console.print()

    def display_pipelines_table(self) -> Optional[str]:
        pipelines = self.get_pipelines()
        if not pipelines:
            console.print("[yellow]Nenhuma pipeline encontrada em arquivos.[/yellow]")
            console.print("[dim]As pipelines devem ser migradas para o banco de dados.[/dim]")
            console.print("[dim]Use: mymoney pipelines migrate[/dim]")
            return None

        table = Table(
            title="Available Pipelines",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta",
        )
        table.add_column("#", style="bold cyan", width=4, justify="center")
        table.add_column("Name", style="green")
        table.add_column("File", style="dim")

        for index, (name, path) in enumerate(pipelines, 1):
            table.add_row(str(index), name, os.path.basename(path))

        console.print(table)
        console.print()

        choices = [str(i) for i in range(1, len(pipelines) + 1)] + ["q"]
        choice = Prompt.ask(
            "Select a pipeline number or q to quit",
            choices=choices,
            show_choices=False,
        )
        if choice == "q":
            return None
        return pipelines[int(choice) - 1][0]

    def display_pipeline_info(self, pipeline_name: str) -> bool:
        try:
            config = get_pipeline_config(pipeline_name, self.PIPELINES_FOLDER)
        except Exception as exc:
            console.print(f"[red]Failed to load pipeline: {exc}[/red]")
            return False

        info_rows = [
            f"[bold cyan]Name:[/bold cyan] {pipeline_name}",
            f"[bold cyan]Processor:[/bold cyan] {config.get('processor', 'N/A')}",
            f"[bold cyan]Scope:[/bold cyan] {config.get('scope', 'N/A')}",
            f"[bold cyan]Parallelize:[/bold cyan] {config.get('parallelize', False)}",
            f"[bold cyan]Dry-run default:[/bold cyan] {config.get('dry_run', False)}",
        ]
        panel = Panel(
            "\n".join(info_rows),
            title="Pipeline Configuration",
            box=box.ROUNDED,
            border_style="green",
        )
        console.print(panel)
        console.print()
        return True

    def run_pipeline_with_progress(
        self,
        pipeline_name: str,
        *,
        parallelize: bool = True,
        progress: bool = True,
        dry_run: bool = False,
    ) -> bool:
        console.print(
            f"[bold green]Running pipeline:[/bold green] [cyan]{pipeline_name}[/cyan]"
        )
        if dry_run:
            console.print("[yellow]Dry-run mode enabled: no DB writes or file renames.[/yellow]")
        console.print()

        try:
            validate_pipeline_exists_in_files(pipeline_name, self.PIPELINES_FOLDER)
        except FileNotFoundError:
            console.print(f"[red]Pipeline não encontrada: {pipeline_name}[/red]")
            console.print("[dim]As pipelines devem ser migradas para o banco de dados.[/dim]")
            console.print("[dim]Use: mymoney pipelines migrate[/dim]")
            return False

        total_items = estimate_pipeline_items(pipeline_name)

        try:
            if progress:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(bar_width=40),
                    TaskProgressColumn(),
                    console=console,
                    transient=False,
                ) as progress_display:
                    task_id = progress_display.add_task(
                        f"[cyan]Executing {pipeline_name}...[/cyan]",
                        total=total_items or None,
                    )

                    def callback(current: int, total: int, status: str):
                        if status == "running":
                            progress_display.update(task_id, total=total, completed=current)
                        elif status == "completed":
                            progress_display.update(task_id, completed=total)
                            progress_display.update(
                                task_id, description="[green]Pipeline completed[/green]"
                            )
                        elif status == "error":
                            progress_display.update(
                                task_id, description="[red]Pipeline failed[/red]"
                            )

                    run_pipeline(
                        pipeline_name,
                        parallelize=parallelize,
                        progress=False,
                        progress_callback=callback,
                        dry_run=dry_run,
                    )
            else:
                run_pipeline(
                    pipeline_name,
                    parallelize=parallelize,
                    progress=False,
                    dry_run=dry_run,
                )
        except KeyboardInterrupt:
            console.print("\n[yellow]Execution interrupted by user.[/yellow]")
            return False
        except Exception as exc:
            console.print(f"\n[red]Execution failed: {exc}[/red]")
            logger.error(f"Pipeline execution failed for '{pipeline_name}': {exc}")
            return False

        self.show_execution_summary(pipeline_name)
        return True

    def show_execution_summary(self, pipeline_name: str) -> None:
        summary = summarize_pipeline_execution(
            pipeline_name, operations_dir=self.OPERATIONS_FOLDER
        )
        if not summary:
            console.print("[yellow]No operation record found.[/yellow]")
            return

        table = Table(
            title=f"Execution Summary ({summary.file_path})",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Metric", style="bold")
        table.add_column("Value", justify="right")
        table.add_row("Total", str(summary.total_operations))
        table.add_row("Success", f"[green]{summary.successful_operations}[/green]")
        table.add_row("Failed", f"[red]{summary.failed_operations}[/red]")
        table.add_row("Success rate", f"{summary.success_rate:.1f}%")
        console.print(table)
        console.print(f"[dim]Operation ID: {summary.file_path}[/dim]")
        console.print()

    def display_results_menu(self) -> None:
        while True:
            files = list_operation_files(limit=20, operations_dir=self.OPERATIONS_FOLDER)
            if not files:
                console.print("[yellow]No operations found.[/yellow]")
                Prompt.ask("[dim]Press Enter to continue[/dim]")
                return

            table = Table(
                title="Recent Operations",
                box=box.ROUNDED,
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("#", width=4)
            table.add_column("Pipeline", style="green")
            table.add_column("Timestamp", style="cyan")
            table.add_column("ID", style="dim")

            for index, file_info in enumerate(files, 1):
                table.add_row(
                    str(index), file_info.pipeline_name, file_info.run_timestamp, file_info.path
                )
            console.print(table)
            console.print()

            choices = [str(i) for i in range(1, len(files) + 1)] + ["q"]
            choice = Prompt.ask(
                "Select an operation for details or q to return",
                choices=choices,
                show_choices=False,
            )
            if choice == "q":
                return

            selected = files[int(choice) - 1]
            self.display_result_details(selected.path)

    def display_result_details(self, file_path: str) -> None:
        page = 1
        page_size = 50

        while True:
            page_data = get_operation_page(file_path, page=page, page_size=page_size)
            self.clear_screen()
            self.display_header()

            info_panel = Panel(
                (
                    f"[bold cyan]Operation:[/bold cyan] {file_path}\n"
                    f"[bold cyan]Page:[/bold cyan] {page_data.page}/{max(page_data.total_pages, 1)}\n"
                    f"[bold cyan]Records:[/bold cyan] {page_data.total_records}"
                ),
                title="Operation Details",
                box=box.ROUNDED,
                border_style="green",
            )
            console.print(info_panel)
            console.print()

            table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
            table.add_column("Scope", style="green")
            table.add_column("Success", width=9, justify="center")
            table.add_column("Error", style="red")

            for item in page_data.items:
                ok = item.get("success", False)
                err = item.get("error_message") or ""
                table.add_row(
                    str(item.get("scope", "")),
                    "[green]yes[/green]" if ok else "[red]no[/red]",
                    str(err),
                )

            console.print(table)
            console.print()

            actions = ["q"]
            if page > 1:
                actions.append("p")
            if page < page_data.total_pages:
                actions.append("n")
            actions.append("i")

            choice = Prompt.ask(
                "Actions: n(next), p(prev), i(go to page), q(back)",
                choices=actions,
                show_choices=False,
            )
            if choice == "q":
                return
            if choice == "n" and page < page_data.total_pages:
                page += 1
            elif choice == "p" and page > 1:
                page -= 1
            elif choice == "i":
                new_page = Prompt.ask("Enter page number", default=str(page))
                try:
                    page = int(new_page)
                except ValueError:
                    pass

    def run_interactive(self) -> None:
        while True:
            self.clear_screen()
            self.display_header()

            panel = Panel(
                "\n".join(
                    [
                        "[1] List and run pipeline",
                        "[2] View operation results",
                        "[q] Quit",
                    ]
                ),
                title="Main Menu",
                box=box.ROUNDED,
                border_style="cyan",
            )
            console.print(panel)
            console.print()

            choice = Prompt.ask(
                "Choose an option",
                choices=["1", "2", "q"],
                show_choices=False,
            )
            if choice == "q":
                console.print("[bold cyan]Bye.[/bold cyan]")
                return
            if choice == "2":
                self.clear_screen()
                self.display_header()
                self.display_results_menu()
                continue

            self.clear_screen()
            self.display_header()
            pipeline_name = self.display_pipelines_table()
            if not pipeline_name:
                continue

            self.clear_screen()
            self.display_header()
            if not self.display_pipeline_info(pipeline_name):
                Prompt.ask("[dim]Press Enter to continue[/dim]")
                continue

            should_run = Confirm.ask("Run this pipeline?", default=True)
            if not should_run:
                continue

            parallel = Confirm.ask("Use parallel execution?", default=True)
            show_progress = Confirm.ask("Show progress bar?", default=True)
            dry_run = Confirm.ask("Run in dry-run mode?", default=False)

            self.run_pipeline_with_progress(
                pipeline_name,
                parallelize=parallel,
                progress=show_progress,
                dry_run=dry_run,
            )
            Prompt.ask("[dim]Press Enter to continue[/dim]")

    def run_pipeline_direct(
        self,
        pipeline_name: str,
        *,
        parallelize: bool = True,
        progress: bool = True,
        dry_run: bool = False,
    ) -> int:
        self.clear_screen()
        self.display_header()

        try:
            validate_pipeline_exists(pipeline_name, self.PIPELINES_FOLDER)
        except FileNotFoundError:
            available = ", ".join(name for name, _ in self.get_pipelines()) or "none"
            console.print(f"[red]Pipeline not found: {pipeline_name}[/red]")
            console.print(f"[dim]Available pipelines: {available}[/dim]")
            return 1

        self.display_pipeline_info(pipeline_name)
        ok = self.run_pipeline_with_progress(
            pipeline_name,
            parallelize=parallelize,
            progress=progress,
            dry_run=dry_run,
        )
        return 0 if ok else 1


def main(argv: Optional[list[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        prog="python -m mymoney.data.elt",
        description="MyMoney ELT Pipeline CLI/TUI",
    )
    parser.add_argument("-p", "--pipeline", metavar="NAME", help="Run one pipeline")
    parser.add_argument("-l", "--list", action="store_true", help="List pipelines")
    parser.add_argument("--no-parallel", action="store_true", help="Disable parallel mode")
    parser.add_argument("--no-progress", action="store_true", help="Disable progress bar")
    parser.add_argument("--dry-run", action="store_true", help="Run without DB writes")

    args = parser.parse_args(argv)
    tui = ELT_TUI()

    if args.list:
        tui.clear_screen()
        tui.display_header()
        items = tui.get_pipelines()
        if not items:
            console.print("[yellow]No pipelines found.[/yellow]")
            return
        table = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
        table.add_column("#", width=4, justify="center")
        table.add_column("Name", style="green")
        table.add_column("Path", style="dim")
        for index, (name, path) in enumerate(items, 1):
            table.add_row(str(index), name, path)
        console.print(table)
        console.print(f"\n[dim]Total: {len(items)} pipeline(s)[/dim]")
        return

    if args.pipeline:
        code = tui.run_pipeline_direct(
            args.pipeline,
            parallelize=not args.no_parallel,
            progress=not args.no_progress,
            dry_run=args.dry_run,
        )
        sys.exit(code)

    tui.run_interactive()


if __name__ == "__main__":
    main()
