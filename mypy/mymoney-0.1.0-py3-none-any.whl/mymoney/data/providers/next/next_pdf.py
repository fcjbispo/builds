from __future__ import annotations

import os
import re
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.next.common import (
    NEXT_PDF_PASSWORD_CONFIG_KEY,
    NEXT_PROVIDER,
    build_next_direct_dataframe,
    normalize_next_account,
)
from mymoney.data.providers.pdf import read_pdf_text, resolve_pdf_password


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join([_RESOURCES_DIR, "domain", "next_pdf_domain.md"])

_TRANSACTION_PATTERN = re.compile(
    r"^(?P<data>\d{2}/\d{2}/\d{4})\s+"
    r"(?P<historico>.+?)"
    r"(?:\s+(?P<docto>\d+))?"
    r"\s+(?P<amount>R\$\s*-?[\d\.,]+)"
    r"\s+(?P<saldo>R\$\s*-?[\d\.,]+)$"
)
_IGNORED_HISTORY = {"saldo anterior", "saldo do dia", "total"}


def _parse_currency(value: str) -> float:
    text = str(value or "").replace("R$", "").replace(" ", "").strip()
    return float(text.replace(".", "").replace(",", "."))


def _parse_next_pdf_text(
    text: str,
    *,
    file_path: str,
    source: str,
) -> pd.DataFrame:
    account_id = normalize_next_account(file_path=file_path, text=text)
    rows: list[dict[str, object]] = []

    for raw_line in str(text or "").splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line or not re.match(r"^\d{2}/\d{2}/\d{4}\s+", line):
            continue

        match = _TRANSACTION_PATTERN.match(line)
        if not match:
            continue

        history = str(match.group("historico") or "").strip()
        if history.lower() in _IGNORED_HISTORY:
            continue

        rows.append(
            {
                "data_movimentacao": match.group("data"),
                "movimentacao": history,
                "nome_produto": "",
                "valor_operacao": _parse_currency(match.group("amount")),
            }
        )

    return build_next_direct_dataframe(
        rows,
        file_path=file_path,
        source=source,
        account_id=account_id,
    )


def _parse_next_pdf_with_llm(
    file_path: str,
    *,
    source: str = "mm.data.elt.load.next",
    institution: str = "NEXT (237 - BANCO BRADESCO S.A.)",
    tipo_lancamento: str = "LANCAMENTOS_CONTA_CORRENTE",
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = True,
) -> pd.DataFrame:
    """Parse NEXT PDF using LLM-based extraction (via unstructured domain)."""
    from mymoney.data.providers.base import parse_unstructured_domain_pdf

    return parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="next",
        file_type="pdf",
        source_name="NEXT Bank Statement",
        source=source,
        institution=institution,
        tipo_lancamento=tipo_lancamento,
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        use_native_pdf=use_native_pdf,
    )


def parse_next_pdf(
    file_path: str,
    *,
    pdf_password: str | None = None,
    pdf_password_required: bool = True,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
    fallback_on_empty: bool = True,
) -> pd.DataFrame:
    """Parse NEXT bank statement PDF.

    Args:
        file_path: Path to the PDF file
        pdf_password: Password for encrypted PDF
        pdf_password_required: Whether password is required
        max_attempts: Maximum retry attempts for LLM extraction
        retry_delay_seconds: Delay between retries
        use_native_pdf: If True, use LLM-based extraction instead of regex
        fallback_on_empty: If True and regex returns empty, fallback to LLM

    Returns:
        DataFrame with parsed transactions
    """
    # If explicitly requested native PDF, use LLM directly
    if use_native_pdf:
        return _parse_next_pdf_with_llm(
            file_path,
            max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds,
            use_native_pdf=True,
        )

    # Otherwise, try regex-based extraction first
    resolved_password = resolve_pdf_password(
        provider=NEXT_PROVIDER,
        explicit_password=pdf_password,
        password_config_key=NEXT_PDF_PASSWORD_CONFIG_KEY,
    )
    text = read_pdf_text(
        file_path,
        password=resolved_password,
        password_required=pdf_password_required,
        context_label=f"{NEXT_PROVIDER} PDF '{file_path}'",
    )
    df = _parse_next_pdf_text(
        text,
        file_path=file_path,
        source="mm.data.elt.load.next",
    )

    # If regex extraction returned empty and fallback is enabled, try LLM
    if df.empty and fallback_on_empty:
        from mymoney import logger
        logger.warning(
            "Regex extraction returned empty for %s, falling back to LLM extraction",
            file_path
        )
        return _parse_next_pdf_with_llm(
            file_path,
            max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds,
            use_native_pdf=False,  # Use markdown conversion for fallback
        )

    return df
