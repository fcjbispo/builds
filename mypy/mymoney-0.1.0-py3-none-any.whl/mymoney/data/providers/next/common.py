from __future__ import annotations

import os
import re
from typing import Any

import pandas as pd


NEXT_DEFAULT_MASKS = ("*.pdf",)
NEXT_CC_DEFAULT_MASKS = ("*.pdf",)
NEXT_PROVIDER = "next"
NEXT_INSTITUTION = "NEXT (237 - BANCO BRADESCO S.A.)"
NEXT_BANK_CODE = "237"
NEXT_BRANCH_FALLBACK = "3750"
NEXT_ACCOUNT_FALLBACK = "501403-4"
NEXT_PDF_PASSWORD_CONFIG_KEY = "NEXT_PDF_PASSWORD"

_DIRECT_COLUMNS = [
    "entrada_saida",
    "data_movimentacao",
    "movimentacao",
    "nome_produto",
    "codigo_produto",
    "instituicao",
    "conta",
    "valor_operacao",
    "tipo_produto",
    "tipo_evento",
    "tipo_lancamento",
    "moeda",
    "origem",
]

_FILENAME_ACCOUNT_PATTERN = re.compile(
    r"NEXT_NEXT_(?P<branch>\d+)_(?P<account>\d+)_",
    re.IGNORECASE,
)
_HEADER_ACCOUNT_PATTERN = re.compile(
    r"Ag[eê]ncia:\s*(?P<branch>\d+)\s*\|\s*Conta:\s*(?P<account>[\d-]+)",
    re.IGNORECASE,
)


def _normalize_account_number(raw_account: str | None) -> str:
    account = re.sub(r"[^\d-]", "", str(raw_account or "").strip())
    if account and "-" not in account and account.isdigit() and len(account) > 1:
        account = f"{account[:-1]}-{account[-1]}"
    return account or NEXT_ACCOUNT_FALLBACK


def normalize_next_account(
    raw_branch: str | None = None,
    raw_account: str | None = None,
    *,
    file_path: str | None = None,
    text: str | None = None,
) -> str:
    branch = str(raw_branch or "").strip()
    account = str(raw_account or "").strip()

    if text and (not branch or not account):
        match = _HEADER_ACCOUNT_PATTERN.search(text)
        if match:
            branch = branch or match.group("branch")
            account = account or match.group("account")

    if file_path and (not branch or not account):
        match = _FILENAME_ACCOUNT_PATTERN.search(os.path.basename(file_path))
        if match:
            branch = branch or match.group("branch")
            account = account or match.group("account")

    branch = re.sub(r"[^\d]", "", branch) or NEXT_BRANCH_FALLBACK
    account = _normalize_account_number(account)
    return ".".join([NEXT_BANK_CODE, branch, account])


def build_next_direct_dataframe(
    items: list[dict[str, Any]],
    *,
    file_path: str,
    source: str,
    account_id: str | None = None,
) -> pd.DataFrame:
    resolved_account = account_id or normalize_next_account(file_path=file_path)
    rows: list[dict[str, Any]] = []

    for index, item in enumerate(items, start=1):
        amount = float(item["valor_operacao"])
        rows.append(
            {
                "entrada_saida": "Debito" if amount < 0 else "Credito",
                "data_movimentacao": pd.to_datetime(
                    item.get("data_movimentacao"),
                    format="%d/%m/%Y",
                    errors="coerce",
                ),
                "movimentacao": str(item.get("movimentacao") or "").strip(),
                "nome_produto": str(item.get("nome_produto") or "").strip(),
                "codigo_produto": str(index).rjust(12, "0"),
                "instituicao": NEXT_INSTITUTION,
                "conta": resolved_account,
                "valor_operacao": amount,
                "tipo_produto": "CONTA CORRENTE",
                "tipo_evento": "LANCAMENTO C/C",
                "tipo_lancamento": "LANCAMENTOS_CONTA_CORRENTE",
                "moeda": "BRL",
                "origem": source,
            }
        )

    if not rows:
        return pd.DataFrame(columns=_DIRECT_COLUMNS)

    return pd.DataFrame(rows, columns=_DIRECT_COLUMNS)
