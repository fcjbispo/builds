# Domain Rules - Nubank PDF Bank Statement

## Provider Information
- **Source**: mm.data.elt.load.nubank
- **Institution**: NU PAGAMENTOS S.A.
- **File Type**: PDF account statement
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | LANCAMENTOS_CONTA_CORRENTE |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | mm.data.elt.load.nubank |
| instituicao | NU PAGAMENTOS S.A. |
| conta | 0260.0001.2944106-1 |

## PDF Structure

The Nubank statement contains:
- Header with customer name, CPF, `Agência 0001`, `Conta 2944106-1`, and statement period
- Summary section with `Saldo inicial`, `Rendimento líquido`, `Total de entradas`, `Total de saídas`, `Saldo final do período`
- A `Movimentações` section listing explicit account transactions

Extract only explicit rows from the `Movimentações` section.

Ignore all of these:
- `Saldo inicial`
- `Rendimento líquido`
- `Total de entradas`
- `Total de saídas`
- `Saldo final do período`
- support text, footer text, customer service text, and page numbering

If the PDF says `Nenhuma movimentação realizada.`, return an empty `lancamentos` list.

## Output Requirements

- Return rows in the same order they appear in the statement.
- Return data in the `lancamentos` list using the direct checking-account structure.
- Every row must contain at least:
  - `entrada_saida`
  - `data_movimentacao`
  - `movimentacao`
  - `nome_produto`
  - `valor_operacao`
- Leave `codigo_produto` empty or null; the loader will generate the monthly sequence.

## Mapping Rules

### Date
- Parse movement dates from the `Movimentações` section.
- Convert to `YYYY-MM-DD HH:MM:SS`.
- When the PDF only shows the date, set time to `00:00:00`.

### Amount and direction
- `entrada_saida` must be `Credito` for positive values and `Debito` for negative values.
- `valor_operacao` must preserve the transaction sign.

### Description split
- The CSV layout is the canonical reference.
- Map the first business segment of the description to `movimentacao`.
- Map the remainder of the description to `nome_produto`.
- When the statement line corresponds to:
  - `Transferência Recebida Walter de Brito Reis - ...`
    - `movimentacao`: `Transferência Recebida`
    - `nome_produto`: `Walter de Brito Reis - ...`
  - `Transferência recebida pelo Pix FRANCISCO DAS CHAGAS DE JESUS BISPO - ...`
    - `movimentacao`: `Transferência recebida pelo Pix`
    - `nome_produto`: `FRANCISCO DAS CHAGAS DE JESUS BISPO - ...`

### Account and institution
- `instituicao` must always be `NU PAGAMENTOS S.A.`
- `conta` must always be `0260.0001.2944106-1`

## Important Notes

- Ignore `Identificador`, `FITID`, balances, and yield values that are not explicit transactions.
- Do not synthesize rows for rendimento or saldo movements.
- Preserve only explicit movements present in the statement body.
