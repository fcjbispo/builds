# Domain Rules - Nubank Credit Card PDF Statement

## Provider Information
- **Source**: mm.data.elt.load.nubank_cc
- **Institution**: NU PAGAMENTOS S.A.
- **File Type**: PDF (Credit Card Statement)
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | LANCAMENTOS_CARTAO_CREDITO |
| tipo_produto | CARTAO CREDITO |
| tipo_evento | COMPRA CC (for purchases) / PAGAMENTO CC (for payments) |
| moeda | BRL |
| origem | mm.data.elt.load.nubank_cc |

## PDF Table Structure

The Nubank credit card PDF statement contains transaction tables. There are TWO possible formats:

### Format A (Older - until May 2024): 5 columns
- **Data** (Date) - Format: DD/MM/YYYY
- **Estabelecimento** (Merchant) - Where the purchase was made
- **Descrição** (Description) - Additional transaction details
- **Parcela** (Installment) - Current installment / Total installments (e.g., "1/12")
- **Valor (R$)** (Value) - Amount (always positive in statement)

### Format B (Newer - from June 2024): 3 columns
- **Data** (Date) - Format: DD/MM/YYYY
- **Descrição** (Description + Merchant + Parcela combined) - Example: "Mercadolivre*2produto - Parcela 7/10"
- **Valor** (Value) - With "R$" prefix

Extract every transaction row from the statement table. Ignore page headers, footers, support text and repeated column headers.

IMPORTANT: Detect which format is present and parse accordingly:

## Transaction Examples

### Format A Examples (5 columns)

#### Example 1: Purchase in single installment
```
Input: "15/01/2024 | SUPERMERCADO EXTRA | Compra no débito | 1/1 | 150,00"
Output:
- data_movimentacao: "2024-01-15"
- movimentacao: "Compra Cartao"
- nome_produto: "SUPERMERCADO EXTRA - Compra no débito"
- entrada_saida: "Debito"
- valor_operacao: 150.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "COMPRA CC"
```

### Example 2: Purchase in installments
```
Input: "15/01/2024 | LOJA XYZ | Compra parcelada | 3/10 | 85,00"
Output:
- data_movimentacao: "2024-01-15"
- movimentacao: "Compra Cartao Parcelada"
- nome_produto: "LOJA XYZ - Compra parcelada"
- entrada_saida: "Debito"
- valor_operacao: 85.00
- quantidade_disponivel: 3
- quantidade_indisponivel: 10
- tipo_evento: "COMPRA CC"
```

### Example 3: Payment of credit card bill
```
Input: "20/01/2024 | PAGAMENTO DE FATURA | Pagamento recebido | 1/1 | -500,00"
Output:
- data_movimentacao: "2024-01-20"
- movimentacao: "Pagamento Fatura"
- nome_produto: "PAGAMENTO DE FATURA - Pagamento recebido"
- entrada_saida: "Credito"
- valor_operacao: 500.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

### Example 4: Refund/Estorno
```
Input: "18/01/2024 | ESTORNO LOJA ABC | Estorno de compra | 1/1 | -75,00"
Output:
- data_movimentacao: "2024-01-18"
- movimentacao: "Estorno"
- nome_produto: "ESTORNO LOJA ABC - Estorno de compra"
- entrada_saida: "Credito"
- valor_operacao: 75.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

### Format B Examples (3 columns - from June 2024)

#### Example 6: Purchase with installment info combined
```
Input: "18 MAI | Mercadolivre*2produto - Parcela 7/10 | R$ 58,98"
Output:
- data_movimentacao: "2024-05-18"
- movimentacao: "Compra Cartao Parcelada"
- nome_produto: "Mercadolivre*2produto"
- entrada_saida: "Debito"
- valor_operacao: 58.98
- quantidade_disponivel: 7
- quantidade_indisponivel: 10
- tipo_evento: "COMPRA CC"
```

#### Example 7: Single installment (Format B)
```
Input: "20 JUN | POSTO SHELL | R$ 150,00"
Output:
- data_movimentacao: "2024-06-20"
- movimentacao: "Compra Cartao"
- nome_produto: "POSTO SHELL"
- entrada_saida: "Debito"
- valor_operacao: 150.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "COMPRA CC"
```

#### Example 8: Payment (Format B)
```
Input: "15 JUN | PAGAMENTO DE FATURA | -R$ 500,00"
Output:
- data_movimentacao: "2024-06-15"
- movimentacao: "Pagamento Fatura"
- nome_produto: "PAGAMENTO DE FATURA"
- entrada_saida: "Credito"
- valor_operacao: 500.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

### Format A Examples (5 columns)

#### Example 5: Nubank Rewards (Programa de Pontos)
```
Input: "18/01/2024 | NUBANK REWARDS | Resgate de pontos | 1/1 | -50,00"
Output:
- data_movimentacao: "2024-01-18"
- movimentacao: "Resgate Rewards"
- nome_produto: "NUBANK REWARDS - Resgate de pontos"
- entrada_saida: "Credito"
- valor_operacao: 50.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

## Interpretation Rules

### Transaction Types
- **Compra**, **Transação**, **Compra no débito** → `movimentacao`: "Compra Cartao", `tipo_evento`: "COMPRA CC"
- **Parcela** / **Parcelado** / **Compra parcelada** → `movimentacao`: "Compra Cartao Parcelada", `tipo_evento`: "COMPRA CC"
- **Pagamento de fatura** / **Pagamento recebido** / **Pagamento efetuado** → `movimentacao`: "Pagamento Fatura", `tipo_evento`: "PAGAMENTO CC"
- **Estorno** / **Estorno de compra** → `movimentacao`: "Estorno", `tipo_evento`: "PAGAMENTO CC"
- **Devolução** / **Devolução de compra** → `movimentacao`: "Devolucao", `tipo_evento`: "PAGAMENTO CC"
- **Rewards** / **Resgate de pontos** / **NUBANK REWARDS** → `movimentacao`: "Resgate Rewards", `tipo_evento`: "PAGAMENTO CC"
- **Cashback** → `movimentacao`: "Cashback", `tipo_evento`: "PAGAMENTO CC"

### Value Sign Rules
- **Debito** (purchases): `entrada_saida`: "Debito", `valor_operacao`: positive
- **Credito** (payments/refunds): `entrada_saida`: "Credito", `valor_operacao`: positive
- Use `tipo_evento` to distinguish: "COMPRA CC" for debit, "PAGAMENTO CC" for credit
- Do NOT use negative values - always positive with correct entrada_saida

### Format Detection Rules
- If table has 5 columns → Use Format A parsing
- If table has 3 columns (Data | Description | Valor) → Use Format B parsing
- The description in Format B may contain the merchant AND parcela info combined

### Parcela Extraction (IMPORTANT)
- Look for patterns like "X/Y" or "Parcela X de Y" in the description or parcela column
- In Format B, parcela info is embedded in the description column (e.g., "Merchant - Parcela 7/10")
- **quantidade_disponivel** = current installment number (X)
- **quantidade_indisponivel** = total installments (Y)
- If no parcela info found, default both to 1
- Examples:
  - "1/12" → quantidade_disponivel: 1, quantidade_indisponivel: 12
  - "3/10" → quantidade_disponivel: 3, quantidade_indisponivel: 10
  - "Parcela 5 de 12" → quantidade_disponivel: 5, quantidade_indisponivel: 12

### Date Format Detection
- Format A: DD/MM/YYYY (e.g., "15/01/2024")
- Format B: DD MMM (e.g., "18 MAI", "20 JUN")
- Convert Format B dates using year from statement header (e.g., if statement is June 2024, "18 MAI" = "2024-05-18")

### Date Extraction
- Extract dates from the date column in the statement table
- Format: YYYY-MM-DD (convert from DD/MM/YYYY)
- Every transaction MUST have a valid date

### Account Information
- Extract card number (last 4 digits) from the statement header if available
- Map to: `conta` field (e.g., "NUBANK_CC_1234")
- If not available, use "NUBANK_CC" as default

### nome_produto Field
- Format A: Combine merchant name with description → "MERCHANT_NAME - DESCRIPTION"
- Format B: The description already contains merchant info. Extract just the merchant name, or use full description if unclear
- If merchant is not clear, use the full description
- Remove parcela info from nome_produto (e.g., "Merchant - Parcela 2/3" → "Merchant")

### Important Notes
- The PDF contains credit card (cartão de crédito) transactions
- One statement may contain multiple months of installments
- Do not skip any rows - extract every transaction from the table
- Always extract parcela information when available
- Nubank statements may have a different layout (more modern/minimalist)
- Watch for the "Fatura" section specifically
