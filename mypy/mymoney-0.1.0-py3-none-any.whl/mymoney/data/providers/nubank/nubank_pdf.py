from __future__ import annotations

import os

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf
from mymoney.data.providers.nubank.common import normalize_nubank_direct_dataframe


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join([_RESOURCES_DIR, "domain", "nubank_pdf_domain.md"])


def parse_nubank_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    dataframe = parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="nubank",
        file_type="pdf",
        source_name="Nubank Bank Statement",
        source="mm.data.elt.load.nubank",
        institution="NU PAGAMENTOS S.A.",
        tipo_lancamento="LANCAMENTOS_CONTA_CORRENTE",
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        use_native_pdf=use_native_pdf,
    )
    return normalize_nubank_direct_dataframe(
        dataframe,
        file_path=file_path,
        source="mm.data.elt.load.nubank",
    )
