"""Generic Nubank parser supporting CSV, OFX, and PDF formats.

Arquivo: mymoney/data/providers/nubank/nubank_parser.py
"""

from __future__ import annotations

import csv
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from fbpyutils import ofx as OFX

from mymoney.data.providers.nubank.common import (
    build_nubank_direct_dataframe,
    NUBANK_CC_DEFAULT_MASKS,
    NUBANK_DEFAULT_MASKS,
)
from mymoney.data.providers.nubank.nubank_pdf import parse_nubank_pdf
from mymoney.data.providers.nubank.nubank_cc_pdf import parse_nubank_cc_pdf


# Supported extensions per parser type
NUBANK_SUPPORTED_EXTENSIONS = {
    "conta_corrente": [".csv", ".ofx", ".pdf"],
    "cartao_credito": [".csv", ".ofx", ".pdf"],
}


def _extract_parcelas(descricao: str) -> tuple[int, int]:
    """Extract parcela atual and total parcelas from description.

    Common patterns:
    - "1/12" -> (1, 12)
    - "Parcela 3 de 10" -> (3, 10)
    - "3/10" -> (3, 10)

    Returns (1, 1) if no parcela info found.
    """
    text = str(descricao or "").strip()

    # Pattern: X/Y (e.g., "1/12", "3/10")
    pattern1 = r'(\d+)\s*/\s*(\d+)'
    match = re.search(pattern1, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    # Pattern: "Parcela X de Y" or "Parcela X/Y"
    pattern2 = r'[Pp]arcela\s+(\d+)\s+(?:de|/)\s*(\d+)'
    match = re.search(pattern2, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas

    return 1, 1


def _is_credito_cartao(descricao: str) -> bool:
    """Check if transaction is a credit (payment/refund) on credit card."""
    text = str(descricao or "").lower()
    credit_keywords = [
        "pagamento",
        "estorno",
        "devolucao",
        "devolução",
        "cashback",
        "credito",
        "crédito",
        "recebido",
        "recebi",
        "rewards",
        "resgate",
    ]
    return any(keyword in text for keyword in credit_keywords)


def _split_description(description: Any) -> tuple[str, str]:
    """Split description into movement and product name."""
    text = str(description or "").strip()
    if "::" in text:
        first, second = text.split("::", 1)
        return first.strip() or "Lancamento em C/C", second.strip()
    return "Lancamento em C/C", text


def _parse_nubank_csv(file_path: str) -> pd.DataFrame:
    """Parse Nubank CSV file."""
    rows: list[dict[str, object]] = []

    with open(file_path, "r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            if not row:
                continue
            date_value = str(row.get("Data") or "").strip()
            amount_value = str(row.get("Valor") or "").strip()
            description = str(row.get("Descrição") or "").strip()
            if not date_value or not amount_value or not description:
                continue
            rows.append(
                {
                    "data_movimentacao": datetime.strptime(date_value, "%d/%m/%Y").date(),
                    "valor_operacao": float(amount_value),
                    "descricao": description,
                }
            )

    return build_nubank_direct_dataframe(
        rows,
        file_path=file_path,
        source="mm.data.elt.load.nubank",
    )


def _parse_nubank_ofx(file_path: str) -> pd.DataFrame:
    """Parse Nubank OFX file."""
    ofx_data = OFX.read_from_path(file_path)
    transactions = ofx_data.get("statement", {}).get("transactions", [])

    rows: list[dict[str, object]] = []
    for item in transactions:
        date_value = item.get("date")
        rows.append(
            {
                "data_movimentacao": (
                    date_value.date() if hasattr(date_value, "date") else date_value
                ),
                "valor_operacao": float(item.get("amount", 0)),
                "descricao": str(item.get("memo", "")).strip(),
            }
        )

    return build_nubank_direct_dataframe(
        rows,
        file_path=file_path,
        source="mm.data.elt.load.nubank",
    )


def _parse_nubank_cc_csv(file_path: str) -> pd.DataFrame:
    """Parse Nubank Credit Card CSV file.

    Supports both formats:
    - Portuguese: Data,Valor,Descrição (DD/MM/YYYY)
    - English: date,title,amount (YYYY-MM-DD)

    Returns DataFrame with columns: conta, seq, data, dc, descricao, valor, moeda,
    parcela_atual, total_parcelas
    """
    rows: list[dict[str, Any]] = []
    seq = 0

    with open(file_path, "r", encoding="utf-8-sig", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        headers = reader.fieldnames or []
        header_lower = [h.lower() for h in headers]

        # Detect format based on headers
        has_pt_headers = "data" in header_lower and "valor" in header_lower and "descrição" in headers
        has_en_headers = "date" in header_lower and "amount" in header_lower

        for row in reader:
            if not row:
                continue

            # Extract values based on detected format
            if has_pt_headers:
                # Portuguese format
                date_value = str(row.get("Data") or "").strip()
                amount_value = str(row.get("Valor") or "").strip()
                description = str(row.get("Descrição") or "").strip()
                date_format = "%d/%m/%Y"
            elif has_en_headers:
                # English format (exported from Nubank app)
                date_value = str(row.get("date") or row.get("Date") or "").strip()
                amount_value = str(row.get("amount") or row.get("Amount") or "").strip()
                description = str(row.get("title") or row.get("Title") or "").strip()
                date_format = "%Y-%m-%d"
            else:
                # Try to auto-detect from available columns
                date_col = next((h for h in headers if "date" in h.lower() or "data" in h.lower()), None)
                amount_col = next((h for h in headers if "amount" in h.lower() or "valor" in h.lower()), None)
                desc_col = next((h for h in headers if h.lower() in ["descrição", "description", "title", "memo"]), None)

                if not date_col or not amount_col or not desc_col:
                    raise ValueError(
                        f"Formato CSV não reconhecido. Cabeçalhos encontrados: {headers}. "
                        f"Esperado: Data,Valor,Descrição ou date,title,amount"
                    )

                date_value = str(row.get(date_col) or "").strip()
                amount_value = str(row.get(amount_col) or "").strip()
                description = str(row.get(desc_col) or "").strip()
                # Auto-detect date format
                date_format = "%Y-%m-%d" if "-" in date_value and len(date_value) == 10 else "%d/%m/%Y"

            if not date_value or not amount_value or not description:
                continue

            # Parse amount and determine DC
            valor_float = float(amount_value)

            # Determine credit/debit
            if _is_credito_cartao(description):
                dc = "C"
                valor_float = abs(valor_float)
            else:
                dc = "D"
                valor_float = -abs(valor_float)

            # Extract parcela info
            parcela_atual, total_parcelas = _extract_parcelas(description)

            # Parse date
            try:
                parsed_date = datetime.strptime(date_value, date_format).date()
            except ValueError:
                # Try alternative format
                try:
                    alt_format = "%Y-%m-%d" if date_format == "%d/%m/%Y" else "%d/%m/%Y"
                    parsed_date = datetime.strptime(date_value, alt_format).date()
                except ValueError:
                    raise ValueError(f"Formato de data não reconhecido: {date_value}")

            seq += 1
            rows.append({
                "conta": "NUBANK_CC",
                "seq": seq,
                "data": pd.to_datetime(parsed_date),
                "dc": dc,
                "descricao": description,
                "valor": valor_float,
                "moeda": "BRL",
                "parcela_atual": parcela_atual,
                "total_parcelas": total_parcelas,
            })

    if not rows:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    return pd.DataFrame(rows)


def _parse_nubank_cc_ofx(file_path: str) -> pd.DataFrame:
    """Parse Nubank Credit Card OFX file.

    Returns DataFrame with columns: conta, seq, data, dc, descricao, valor, moeda,
    parcela_atual, total_parcelas
    """
    ofx_data = OFX.read_from_path(file_path)
    transactions = ofx_data.get("statement", {}).get("transactions", [])

    rows: list[dict[str, Any]] = []
    for i, item in enumerate(transactions):
        date_value = item.get("date")
        memo = str(item.get("memo", "")).strip()
        amount = float(item.get("amount", 0))

        # Determine credit/debit
        if _is_credito_cartao(memo):
            dc = "C"
            amount = abs(amount)
        else:
            dc = "D"
            amount = -abs(amount)

        # Extract parcela info
        parcela_atual, total_parcelas = _extract_parcelas(memo)

        rows.append({
            "conta": "NUBANK_CC",
            "seq": i + 1,
            "data": pd.to_datetime(date_value.date() if hasattr(date_value, "date") else date_value),
            "dc": dc,
            "descricao": memo,
            "valor": amount,
            "moeda": ofx_data.get("statement", {}).get("currency", "BRL"),
            "parcela_atual": parcela_atual,
            "total_parcelas": total_parcelas,
        })

    if not rows:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    return pd.DataFrame(rows)


def _map_nubank_cc_to_lancamentos(
    account_df: pd.DataFrame,
    *,
    input_file: str,
) -> pd.DataFrame:
    """Map Nubank CC DataFrame to lancamentos format."""
    if account_df is None or account_df.empty:
        return pd.DataFrame()

    from fbpyutils_db.data.normalize import capitalize
    from mymoney.data.elt.load.base import _normalize_financial_identity

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]
    run_at = datetime.now()

    for row in account_df.itertuples(index=False):
        descricao = getattr(row, "descricao", "")
        dc = getattr(row, "dc", "D")

        # Determine movement type
        if dc.upper() == "C":
            entrada_saida = "Credito"
            movimentacao = "Pagamento Fatura"
            tipo_evento = "PAGAMENTO CC"
        else:
            entrada_saida = "Debito"
            movimentacao = "Compra Cartao"
            tipo_evento = "COMPRA CC"

        # Get parcela info
        parcela_atual = getattr(row, "parcela_atual", 1) or 1
        total_parcelas = getattr(row, "total_parcelas", 1) or 1

        # Split description
        movement, product_name = _split_description(descricao)

        seq_value = getattr(row, "seq", None)
        seq_string = None
        try:
            if seq_value is not None and str(seq_value).strip() != "":
                seq_string = str(int(seq_value)).rjust(12, "0")
        except Exception:
            seq_string = str(seq_value).strip() if seq_value is not None else None

        rows.append({
            "entrada_saida": entrada_saida,
            "data_movimentacao": pd.to_datetime(getattr(row, "data", None), errors="coerce"),
            "movimentacao": movement if movement != "Lancamento em C/C" else movimentacao,
            "nome_produto": product_name,
            "codigo_produto": seq_string,
            "instituicao": "NU PAGAMENTOS S.A.",
            "conta": getattr(row, "conta", "NUBANK_CC"),
            "valor_operacao": abs(getattr(row, "valor", 0)),
            "quantidade_disponivel": float(parcela_atual),
            "quantidade_indisponivel": float(total_parcelas),
            "tipo_produto": "CARTAO CREDITO",
            "tipo_evento": tipo_evento,
            "tipo_lancamento": "LANCAMENTOS_CARTAO_CREDITO",
            "moeda": getattr(row, "moeda", "BRL"),
            "origem": "mm.data.elt.load.nubank_cc",
            "arquivo_origem": file_name,
            "data_referencia": run_at,
        })

    xdf = pd.DataFrame(rows)
    xdf = _normalize_financial_identity(
        xdf,
        institution="NU PAGAMENTOS S.A.",
        transaction_type="LANCAMENTOS_CARTAO_CREDITO",
    )
    return capitalize(xdf, "lower")


def parse_nubank(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Nubank file (CSV, OFX, or PDF) using appropriate parser.

    Args:
        file_path: Path to the file (CSV, OFX, or PDF)
        max_attempts: Maximum number of retry attempts (PDF only)
        retry_delay_seconds: Delay between retries in seconds (PDF only)
        use_native_pdf: Whether to use native PDF extraction (PDF only)

    Returns:
        DataFrame with parsed transactions

    Raises:
        ValueError: If file extension is not supported
    """
    ext = Path(file_path).suffix.lower()

    if ext not in NUBANK_SUPPORTED_EXTENSIONS["conta_corrente"]:
        supported = ", ".join(NUBANK_SUPPORTED_EXTENSIONS["conta_corrente"])
        raise ValueError(
            f"Formato '{ext}' não suportado para Nubank. "
            f"Formatos suportados: {supported}"
        )

    if ext == ".csv":
        return _parse_nubank_csv(file_path)
    elif ext == ".ofx":
        return _parse_nubank_ofx(file_path)
    elif ext == ".pdf":
        return parse_nubank_pdf(
            file_path,
            max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds,
            use_native_pdf=use_native_pdf,
        )
    else:
        # Should not reach here due to earlier check
        raise ValueError(f"Formato inesperado: {ext}")


def parse_nubank_cc(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Nubank Credit Card file (CSV, OFX, or PDF).

    Args:
        file_path: Path to the file (CSV, OFX, or PDF)
        max_attempts: Maximum number of retry attempts (PDF only)
        retry_delay_seconds: Delay between retries in seconds (PDF only)
        use_native_pdf: Whether to use native PDF extraction (PDF only)

    Returns:
        DataFrame with parsed credit card transactions in lancamentos format

    Raises:
        ValueError: If file extension is not supported
    """
    ext = Path(file_path).suffix.lower()

    if ext not in NUBANK_SUPPORTED_EXTENSIONS["cartao_credito"]:
        supported = ", ".join(NUBANK_SUPPORTED_EXTENSIONS["cartao_credito"])
        raise ValueError(
            f"Formato '{ext}' não suportado para Nubank Cartão de Crédito. "
            f"Formatos suportados: {supported}"
        )

    if ext == ".csv":
        account_df = _parse_nubank_cc_csv(file_path)
        return _map_nubank_cc_to_lancamentos(account_df, input_file=file_path)
    elif ext == ".ofx":
        account_df = _parse_nubank_cc_ofx(file_path)
        return _map_nubank_cc_to_lancamentos(account_df, input_file=file_path)
    elif ext == ".pdf":
        return parse_nubank_cc_pdf(
            file_path,
            max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds,
            use_native_pdf=use_native_pdf,
        )
    else:
        raise ValueError(f"Formato inesperado: {ext}")
