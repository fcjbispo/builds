from __future__ import annotations

import os
import re
from typing import Any

import pandas as pd


NUBANK_DEFAULT_MASKS = ("*.csv", "*.ofx", "*.pdf")
NUBANK_CC_DEFAULT_MASKS = ("*.csv", "*.ofx", "*.pdf")
NUBANK_INSTITUTION = "NU PAGAMENTOS S.A."
NUBANK_BANK_CODE = "0260"
NUBANK_BRANCH_CODE = "0001"
NUBANK_ACCOUNT_FALLBACK = "2944106-1"

_DIRECT_COLUMNS = [
    "entrada_saida",
    "data_movimentacao",
    "movimentacao",
    "nome_produto",
    "codigo_produto",
    "instituicao",
    "conta",
    "valor_operacao",
    "tipo_produto",
    "tipo_evento",
    "tipo_lancamento",
    "moeda",
    "origem",
]


def normalize_nubank_account(
    raw_account: str | None = None,
    *,
    file_path: str | None = None,
) -> str:
    account_text = str(raw_account or "").strip()
    if not account_text and file_path:
        match = re.search(r"NU_(\d+)_", os.path.basename(file_path).upper())
        if match:
            account_text = match.group(1)

    account_text = re.sub(r"[^\d-]", "", account_text)
    if account_text and "-" not in account_text and account_text.isdigit() and len(account_text) > 1:
        account_text = f"{account_text[:-1]}-{account_text[-1]}"
    if not account_text:
        account_text = NUBANK_ACCOUNT_FALLBACK

    return ".".join([NUBANK_BANK_CODE, NUBANK_BRANCH_CODE, account_text])


def split_nubank_description(description: Any) -> tuple[str, str]:
    text = re.sub(r"\s+", " ", str(description or "").strip())
    if not text:
        return "", ""
    if " - " in text:
        movement, product = text.split(" - ", 1)
        return movement.strip(), product.strip()
    return "Lancamento em C/C", text


def build_nubank_direct_dataframe(
    items: list[dict[str, Any]],
    *,
    file_path: str,
    source: str,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    account_id = normalize_nubank_account(file_path=file_path)

    for index, item in enumerate(items, start=1):
        amount = float(item["valor_operacao"])
        movement, product = split_nubank_description(item.get("descricao"))
        rows.append(
            {
                "entrada_saida": "Debito" if amount < 0 else "Credito",
                "data_movimentacao": pd.to_datetime(item["data_movimentacao"], errors="coerce"),
                "movimentacao": movement,
                "nome_produto": product,
                "codigo_produto": str(index).rjust(12, "0"),
                "instituicao": NUBANK_INSTITUTION,
                "conta": account_id,
                "valor_operacao": amount,
                "tipo_produto": "CONTA CORRENTE",
                "tipo_evento": "LANCAMENTO C/C",
                "tipo_lancamento": "LANCAMENTOS_CONTA_CORRENTE",
                "moeda": "BRL",
                "origem": source,
            }
        )

    if not rows:
        return pd.DataFrame(columns=_DIRECT_COLUMNS)

    return pd.DataFrame(rows, columns=_DIRECT_COLUMNS)


def normalize_nubank_direct_dataframe(
    dataframe: pd.DataFrame | None,
    *,
    file_path: str,
    source: str,
) -> pd.DataFrame:
    if dataframe is None or dataframe.empty:
        return pd.DataFrame(columns=_DIRECT_COLUMNS)

    xdf = dataframe.copy()
    xdf["instituicao"] = NUBANK_INSTITUTION
    xdf["conta"] = xdf.get("conta")
    xdf["conta"] = xdf["conta"].fillna(normalize_nubank_account(file_path=file_path))
    xdf["tipo_produto"] = xdf.get("tipo_produto", "CONTA CORRENTE")
    xdf["tipo_produto"] = xdf["tipo_produto"].fillna("CONTA CORRENTE")
    xdf["tipo_evento"] = xdf.get("tipo_evento", "LANCAMENTO C/C")
    xdf["tipo_evento"] = xdf["tipo_evento"].fillna("LANCAMENTO C/C")
    xdf["tipo_lancamento"] = xdf.get("tipo_lancamento", "LANCAMENTOS_CONTA_CORRENTE")
    xdf["tipo_lancamento"] = xdf["tipo_lancamento"].fillna("LANCAMENTOS_CONTA_CORRENTE")
    xdf["moeda"] = xdf.get("moeda", "BRL")
    xdf["moeda"] = xdf["moeda"].fillna("BRL")
    xdf["origem"] = xdf.get("origem", source)
    xdf["origem"] = xdf["origem"].fillna(source)
    xdf["data_movimentacao"] = pd.to_datetime(xdf.get("data_movimentacao"), errors="coerce")
    xdf["valor_operacao"] = pd.to_numeric(xdf.get("valor_operacao"), errors="coerce")
    xdf["entrada_saida"] = xdf.get("entrada_saida")
    xdf["entrada_saida"] = xdf["entrada_saida"].fillna(
        xdf["valor_operacao"].apply(lambda value: "Debito" if pd.notna(value) and value < 0 else "Credito")
    )
    xdf["movimentacao"] = xdf.get("movimentacao", "")
    xdf["movimentacao"] = xdf["movimentacao"].fillna("")
    xdf["nome_produto"] = xdf.get("nome_produto", "")
    xdf["nome_produto"] = xdf["nome_produto"].fillna("")
    xdf["codigo_produto"] = [
        str(index).rjust(12, "0")
        for index in range(1, len(xdf) + 1)
    ]

    for column in _DIRECT_COLUMNS:
        if column not in xdf.columns:
            xdf[column] = None

    return xdf[_DIRECT_COLUMNS]
