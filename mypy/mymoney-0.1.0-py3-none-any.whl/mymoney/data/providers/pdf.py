from __future__ import annotations

import os
from contextlib import contextmanager
from tempfile import NamedTemporaryFile
from typing import Iterator, Optional

from pypdf import PdfReader, PdfWriter

from mymoney import env


class PdfPasswordRequiredError(ValueError):
    """Raised when a provider requires a PDF password and none was configured."""


class PdfDecryptionError(ValueError):
    """Raised when an encrypted PDF cannot be decrypted with the provided password."""


def _normalize_secret(value: object) -> str | None:
    text = str(value or "").strip()
    return text or None


def resolve_pdf_password(
    *,
    provider: str | None = None,
    explicit_password: str | None = None,
    password_config_key: str | None = None,
) -> str | None:
    if explicit_password is not None:
        return _normalize_secret(explicit_password)

    cfg = env.USER_CONFIG or {}

    if password_config_key:
        resolved = _normalize_secret(cfg.get(password_config_key))
        if resolved:
            return resolved

    provider_key = None
    if provider:
        provider_key = f"{str(provider).upper().replace('-', '_')}_PDF_PASSWORD"
        resolved = _normalize_secret(cfg.get(provider_key))
        if resolved:
            return resolved

    password_map = cfg.get("PDF_PASSWORDS")
    if isinstance(password_map, dict) and provider:
        for key in (
            provider,
            str(provider).lower(),
            str(provider).upper(),
            str(provider).replace("-", "_"),
            str(provider).upper().replace("-", "_"),
        ):
            # Check for explicit empty string to allow "" as a valid password
            if key in password_map:
                raw = password_map.get(key)
                if raw is not None:
                    return str(raw).strip()
            resolved = _normalize_secret(password_map.get(key))
            if resolved:
                return resolved

    return _normalize_secret(cfg.get("PDF_PASSWORD"))


def _missing_password_message(label: str) -> str:
    return f"PDF password is required for {label} but was not configured."


@contextmanager
def prepare_pdf_source(
    file_path: str,
    *,
    password: str | None = None,
    password_required: bool = False,
    context_label: str | None = None,
) -> Iterator[str]:
    """Yield a readable PDF path, decrypting to a temporary file when needed."""
    label = context_label or os.path.basename(file_path)
    # Allow empty string as valid password (for PDFs with empty password encryption)
    resolved_password = password if password is not None else _normalize_secret(password)

    if password_required and resolved_password is None:
        raise PdfPasswordRequiredError(_missing_password_message(label))

    reader = PdfReader(file_path)
    if not reader.is_encrypted:
        yield file_path
        return

    if resolved_password is None:
        raise PdfPasswordRequiredError(_missing_password_message(label))

    try:
        decrypted = reader.decrypt(resolved_password)
    except Exception as exc:
        raise PdfDecryptionError(f"Could not decrypt PDF for {label}: {exc}") from exc

    if not decrypted:
        raise PdfDecryptionError(f"Invalid PDF password for {label}.")

    temp_path: Optional[str] = None
    try:
        with NamedTemporaryFile(prefix="mymoney-pdf-", suffix=".pdf", delete=False) as tmp:
            writer = PdfWriter()
            for page in reader.pages:
                writer.add_page(page)
            writer.write(tmp)
            temp_path = tmp.name

        yield temp_path
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)


def read_pdf_text(
    file_path: str,
    *,
    password: str | None = None,
    password_required: bool = False,
    context_label: str | None = None,
) -> str:
    """Read text from a PDF file, decrypting it first when necessary."""
    label = context_label or os.path.basename(file_path)
    # Allow empty string as valid password (for PDFs with empty password encryption)
    resolved_password = password if password is not None else _normalize_secret(password)

    if password_required and resolved_password is None:
        raise PdfPasswordRequiredError(_missing_password_message(label))

    reader = PdfReader(file_path)
    if reader.is_encrypted:
        if resolved_password is None:
            raise PdfPasswordRequiredError(_missing_password_message(label))
        try:
            decrypted = reader.decrypt(resolved_password)
        except Exception as exc:
            raise PdfDecryptionError(f"Could not decrypt PDF for {label}: {exc}") from exc
        if not decrypted:
            raise PdfDecryptionError(f"Invalid PDF password for {label}.")

    pages = []
    for page in reader.pages:
        pages.append(page.extract_text() or "")
    return "\n".join(pages)
