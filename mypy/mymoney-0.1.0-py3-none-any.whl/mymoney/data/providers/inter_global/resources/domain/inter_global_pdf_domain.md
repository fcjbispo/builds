# Domain Rules - INTER GLOBAL PDF Bank Statement

## Provider Information
- **Source**: mm.data.elt.load.inter_global
- **Institution**: INTER & CO PAYMENTS INC
- **File Type**: PDF (US Dollar Account Statement)
- **Currency**: USD

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | USD |
| origem | mm.data.elt.load.inter_global |

## PDF Table Structure

The INTER GLOBAL PDF statement typically contains a table with these columns:
- **Date** - Format: MM/DD/YYYY
- **Description** - Transaction description
- **Credits** ($) - Credit amounts (positive)
- **Debits** ($) - Debit amounts (positive)
- **Balance** ($) - Running balance

## Transaction Examples

### Example 1: Wire Transfer Received
```
Input: "WIRE TRANSFER FROM EXTERNAL BANK"
Output:
- entrada_saida: "Credito"
- movimentacao: "Transferencia Recebida"
- nome_produto: null (not an investment product)
- instituicao: "INTER & CO PAYMENTS INC"
```

### Example 2: Investment Account Loading
```
Input: "Carregamento de Conta Investimento"
Output:
- entrada_saida: "Debito"
- movimentacao: "Carregamento Conta Investimento"
- nome_produto: null (this is account funding, not an investment product)
- instituicao: "INTER & CO PAYMENTS INC"
```

### Example 3: Investment Account Redemption
```
Input: "Resgate de Conta Investimento"
Output:
- entrada_saida: "Credito"
- movimentacao: "Resgate Conta Investimento"
- nome_produto: null
- instituicao: "INTER & CO PAYMENTS INC"
```

### Example 4: Inter Loop Investment
```
Input: "Loop Investment"
Output:
- entrada_saida: "Debito"
- movimentacao: "Carregamento Inter Loop"
- nome_produto: "Inter Loop" (this IS an investment product)
- instituicao: "INTER & CO PAYMENTS INC"
```

## Interpretation Rules

### Transaction Types
- **Wire Transfer Received** → `movimentacao`: "Transferencia Recebida"
- **Wire Transfer Sent** → `movimentacao`: "Transferencia Enviada"
- **Investment Account Resgate** → `movimentacao`: "Resgate Conta Investimento"
- **Investment Account Carregamento** → `movimentacao`: "Carregamento Conta Investimento"
- **ACH Transfer** → `movimentacao`: "ACH Transfer"
- **Annual Fee** / **Monthly Fee** → `movimentacao`: "Taxa"
- **Loop Investment** → `movimentacao`: "Carregamento Inter Loop"

### Value Sign Rules
- Values in the CREDITS column → `entrada_saida`: "Credito", `valor_operacao`: positive
- Values in the DEBITS column → `entrada_saida`: "Debito", `valor_operacao`: positive
- Do NOT use negative values - use the correct entrada_saida instead

### Date Extraction
- Extract dates from the date column in the statement table
- Format: YYYY-MM-DD (convert from MM/DD/YYYY)
- Every transaction MUST have a valid date

### Account Information
- Extract account number and routing numbers from the statement header
- Account ID format: 9-digit number (e.g., 8895831903)
- Map account number to: `conta` field

### instituicao vs nome_produto - IMPORTANT
- `instituicao`: ALWAYS "INTER & CO PAYMENTS INC" (the bank name)
- `nome_produto`: 
  - Use "Inter Loop" ONLY for Loop Investment transactions
  - Use null for all other checking account transactions
  - Do NOT repeat "INTER & CO" in nome_produto

### Important Notes
- This is a US Dollar account (USD)
- Statement may contain both incoming and outgoing wires
- Investment account movements (resgate/carregamento) are common
- The "Loop" is an investment product - other movements are not
- Do not skip any rows - extract every transaction from the table
