from __future__ import annotations

import os
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "inter_global_pdf_domain.md"]
)


def parse_inter_global_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    return parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="inter_global",
        file_type="pdf",
        source_name="INTER GLOBAL Statement",
        source="mm.data.elt.load.inter_global",
        institution="INTER & CO PAYMENTS INC",
        tipo_lancamento="MOVIMENTACAO",
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback,
        use_native_pdf=use_native_pdf,
    )
