import os

import pandas as pd
from multiprocessing import Pool
import warnings

from typing import List, Tuple, Callable, Optional

from fbpyutils import file as FU
from fbpyutils.process import Process

from mymoney import logger

from .schemas import (
    process_schema_movimentacao,
    process_schema_eventos_provisionados,
    process_schema_negociacao,
    process_schema_posicao_acoes,
    process_schema_posicao_emprestimo_ativos,
    process_schema_posicao_etf,
    process_schema_posicao_fundos_investimento,
    process_schema_posicao_tesouro_direto,
    process_schema_posicao_renda_fixa,
    process_schema_proventos_recebidos,
    process_schema_proventos_a_receber,
)


OPERATIONS = (
    (
        "movimentacao", 
        ["movimentacao-*.xlsx"], 
        process_schema_movimentacao, 
        True
    ),
    (
        "eventos_provisionados",
        ["eventos-*.xlsx", "eventos-provisionados-*.xlsx"],
        process_schema_eventos_provisionados,
        True,
    ),
    (
        "negociacao", 
        ["negociacao-*.xlsx"], 
        process_schema_negociacao, 
        True
    ),
    (
        "posicao_acoes", 
        ["posicao-*.xlsx"], 
        process_schema_posicao_acoes, 
        True
    ),
    (
        "posicao_emprestimo_ativos",
        ["posicao-*.xlsx"],
        process_schema_posicao_emprestimo_ativos,
        True,
    ),
    (
        "posicao_etf", 
        ["posicao-*.xlsx"], 
        process_schema_posicao_etf, 
        True
    ),
    (
        "posicao_fundos_investimento",
        ["posicao-*.xlsx"],
        process_schema_posicao_fundos_investimento,
        True,
    ),
    (
        "posicao_tesouro_direto",
        ["posicao-*.xlsx"],
        process_schema_posicao_tesouro_direto,
        True,
    ),
    (
        "posicao_renda_fixa", 
        ["posicao-*.xlsx"], 
        process_schema_posicao_renda_fixa, 
        True
    ),
    # proventos_recebidos: proventos já recebidos (arquivos novos)
    (
        "proventos_recebidos", 
        ["proventos-recebidos-*.xlsx"], 
        process_schema_proventos_recebidos, 
        True
    ),
    # proventos_a_receber: proventos a receber (arquivos antigos e novos)
    (
        "proventos_a_receber", 
        ["proventos-a-receber-*.xlsx", "proventos-receber-*.xlsx"], 
        process_schema_proventos_a_receber, 
        True
    ),
)


def _get_unprocessed_files(input_folder: str, input_masks: str | List[str]) -> List[str]:
    """
    Find unprocessed files matching the input mask(s).
    
    Accepts a single mask string or a list of mask strings.
    Searches for both *.xlsx and *.xlsx.done files, but returns only
    the unprocessed ones (*.xlsx files that haven't been processed yet).
    """
    if isinstance(input_masks, str):
        input_masks = [input_masks]
    
    all_files = []
    for mask in input_masks:
        # Try both patterns: *.xlsx and *.xlsx.done
        files_xlsx = FU.find(input_folder, mask)
        done_mask = mask.replace('.xlsx', '.xlsx.done', 1)
        files_done = FU.find(input_folder, done_mask)
        all_files.extend(files_xlsx + files_done)
    
    # Filter to get unprocessed files (those without .done extension)
    unprocessed = [f for f in all_files if not f.endswith('.xlsx.done')]
    
    return unprocessed


def process_operation(
        op_name: str, input_folder: str, input_masks: str | List[str], processor: Callable
) -> Tuple[str, int, Optional[pd.DataFrame], Optional[List[str]]]:
    """
    Processes a single CEI data operation type.
    
    Note: Searches for both *.xlsx and *.xlsx.done files, but only processes
    the unprocessed ones (*.xlsx). Accepts a single mask or list of masks.
    """
    input_files = _get_unprocessed_files(input_folder, input_masks)
    
    # Log status
    if not input_files:
        # Check if files exist but were already processed
        if isinstance(input_masks, str):
            input_masks = [input_masks]
        done_files = []
        for mask in input_masks:
            done_mask = mask.replace('.xlsx', '.xlsx.done', 1)
            done_files.extend(FU.find(input_folder, done_mask))
        if done_files:
            logger.info(f"Operation '{op_name}': All {len(done_files)} files already processed (.done)")
        else:
            logger.info(f"Operation '{op_name}': No files found matching patterns {input_masks}")
    
    logger.debug(f"Found {len(input_files)} unprocessed files for operation '{op_name}': {input_files}")
    data = processor(input_files)

    rows = 0 if data is None else len(data)
    files = None if rows == 0 else input_files
    logger.info(f"process_operation() -> ('{op_name}', {rows}, DataFrame)")

    return (op_name, rows, data, files)


def get_cei_data(
    input_folder: str, parallelize: bool = True
) -> List[Tuple[str, int, Optional[pd.DataFrame], Optional[List[str]]]]:
    """
    Retrieves and processes various types of CEI data from Excel files in a specified folder.
    """
    logger.info(
        f"get_cei_data(input_folder='{input_folder}', parallelize={parallelize})"
    )
    cei_processor = Process(
        process=process_operation,
        parallelize=(parallelize and os.cpu_count() > 2),
        workers=(os.cpu_count() if parallelize else 1),
    )
    operations = []

    for op, mask, processor, enabled in OPERATIONS:
        if enabled:
            operations.append(
                (
                    op,
                    input_folder,
                    mask,
                    processor,
                )
            )
            logger.debug(f"Added enabled operation: {op}")

    logger.debug(f"Total operations to process: {len(operations)}")

    logger.info("Processing operations in parallel")

    data = cei_processor.run(operations)

    total_rows = sum(row_count for _, row_count, _, _ in data)
    total_files = sum(len(files) if files else 0 for _, _, _, files in data)
    logger.info(
        f"get_cei_data() -> Processed {len(data)} operations, {total_rows} total rows. {total_files} total files."
    )
    return data
