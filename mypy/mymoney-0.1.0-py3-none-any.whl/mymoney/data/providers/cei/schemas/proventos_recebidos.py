"""
fbpyutils_finance.cei.schemas.proventos_recebidos - CEI Proventos Recebidos Schema Processor

Purpose: This module provides functionality to process CEI 'Proventos Recebidos' (Provisioned Events) Excel files, extracting and standardizing financial event data for analysis.

Main contents:
- process_schema_proventos_recebidos() (function): Process and consolidate provisioned events data from Excel files

High-level usage pattern:
Import the function and call it with a list of CEI Excel file paths to get a consolidated DataFrame with processed event data.

Examples:
>>> from fbpyutils_finance.cei.schemas.proventos_recebidos import process_schema_proventos_recebidos
>>> result = process_schema_proventos_recebidos(['proventos-recebidos-2023-01-15.xlsx'])
>>> isinstance(result, pd.DataFrame)
True
>>> len(result.columns) > 5
True
"""

# fbpyutils_finance/cei/schemas/proventos_recebidos.py
import pandas as pd
from typing import List, Optional

from mymoney import logger
from . import excel as XL
from .utils import (
    str_to_date,
    tuple_as_str,
    deal_double_spaces,
    extract_file_info,
    extract_product_id,
)


def process_schema_proventos_recebidos(
    input_files: List[str],
) -> Optional[pd.DataFrame]:
    """
    Processes CEI 'Proventos Recebidos' (Provisioned Events) Excel files.

    Reads one or more 'proventos-recebidos-*.xlsx' files, extracts data, standardizes columns,
    performs type conversions, filters out totals, and concatenates them into a single DataFrame.

    Args:
        input_files (List[str]): A list of paths to the 'Proventos Recebidos' Excel files.

    Returns:
        Optional[pd.DataFrame]: A DataFrame containing the consolidated and processed
                                provisioned events data. Returns an empty DataFrame if
                                input_files is empty or no valid files are processed.

    Examples:
        >>> result = process_schema_proventos_recebidos([])
        >>> isinstance(result, pd.DataFrame)
        True
        >>> len(result.columns)
        12
        >>> # Test with non-existent file (should handle gracefully)
        >>> result = process_schema_proventos_recebidos(['nonexistent.xlsx'])
        >>> isinstance(result, pd.DataFrame)
        True
    """
    logger.info(
        f"process_schema_proventos_recebidos(input_files={len(input_files)} files)"
    )

    if not input_files:
        logger.debug("No input files provided, returning empty DataFrame")
        return pd.DataFrame()  # Return empty DataFrame if no input files

    xl_dataframes = []
    fields = [
        "codigo_produto",
        "nome_produto",
        "tipo_produto",
        "tipo_evento",
        "pagamento",
        "instituicao",
        "conta",
        "quantidade",
        "preco_unitario",
        "valor_operacao",
        "arquivo_origem",
        "data_referencia",
    ]

    for schema_file in input_files:
        logger.debug(f"Processing file: {schema_file}")
        try:
            schema_file_name, schema_file_date = extract_file_info(schema_file)
            logger.debug(
                f"Extracted file info: name='{schema_file_name}', date={schema_file_date}"
            )

            # Basic check if it's an 'proventos-recebidos' file (adjust if needed)
            if "proventos-recebidos" not in schema_file_name and "proventos-receber" not in schema_file_name:
                logger.warning(
                    f"Skipping file {schema_file} as it doesn't appear to be an 'proventos-recebidos' type"
                )
                print(
                    f"Warning: Skipping file {schema_file} as it doesn't appear to be an 'proventos-recebidos' type."
                )
                continue

            logger.debug(f"Loading Excel file: {schema_file}")
            xl_obj = XL.ExcelWorkbook(schema_file)
            xl_table = tuple_as_str(tuple(xl_obj.read_sheet_by_index(0)))

            if not xl_table or len(xl_table) < 2:
                logger.warning(
                    f"Skipping file {schema_file} as it contains no data or header"
                )
                print(
                    f"Warning: Skipping file {schema_file} as it contains no data or header."
                )
                continue

            header = xl_table[0]
            data = [d for d in xl_table[1:] if len(d) > 0 and d[0]]
            xl_dataframe = pd.DataFrame(data, columns=header)
            logger.debug(f"Created DataFrame with shape: {xl_dataframe.shape}")

            if xl_dataframe.empty:
                logger.warning(f"No data left in {schema_file} after filtering totals")
                print(f"Warning: No data left in {schema_file} after filtering totals.")
                continue

            # --- Data Cleaning and Transformation ---
            logger.debug("Starting data cleaning and transformation")
            column_mapping = {
                "Produto": "nome_produto_raw",
                "Tipo": "tipo_produto",
                "Tipo de Evento": "tipo_evento",
                "Pagamento": "pagamento_raw",
                "Instituição": "instituicao_raw",
                "Conta": "conta_raw",
                "Quantidade": "quantidade_raw",
                "Preço unitário": "preco_unitario_raw",
                "Valor líquido": "valor_operacao_raw",  # Assuming 'Valor líquido' maps to 'valor_operacao'
            }

            rename_dict = {
                k: v for k, v in column_mapping.items() if k in xl_dataframe.columns
            }
            xl_dataframe = xl_dataframe[list(rename_dict.keys())].rename(
                columns=rename_dict
            )
            logger.debug(f"Mapped {len(rename_dict)} columns")

            # Handle missing columns:
            for column_spec in [
                ('Conta', 'conta_raw', 'conta', '000000000'),
                ('Tipo Produto', 'tipo_produto', 'tipo_produto', 'Fundo'),
            ]:
                column_name, column_raw_name, column_df_name, default_value = column_spec
                if column_raw_name not in xl_dataframe.columns:
                    logger.debug(f"'{column_name}' column missing, adding default value")
                    xl_dataframe[column_df_name] = default_value
                else:
                    xl_dataframe[column_df_name] = xl_dataframe[column_raw_name].apply(
                        deal_double_spaces
                    )

            # Apply transformations
            xl_dataframe["nome_produto"] = xl_dataframe["nome_produto_raw"].apply(
                deal_double_spaces
            )
            xl_dataframe["codigo_produto"] = xl_dataframe["nome_produto"].apply(
                extract_product_id
            )
            logger.debug("Applied product name transformations")

            # 'tipo_produto' and 'tipo_evento' are directly mapped if they exist
            xl_dataframe["pagamento"] = pd.to_datetime(
                xl_dataframe["pagamento_raw"].apply(str_to_date),
                errors="coerce",
            )
            xl_dataframe["instituicao"] = xl_dataframe["instituicao_raw"].apply(
                deal_double_spaces
            )

            # Convert numeric columns
            logger.debug("Converting numeric columns")
            xl_dataframe["quantidade"] = pd.to_numeric(
                xl_dataframe["quantidade_raw"], errors="coerce"
            )
            xl_dataframe["preco_unitario"] = pd.to_numeric(
                xl_dataframe["preco_unitario_raw"], errors="coerce"
            )
            xl_dataframe["valor_operacao"] = pd.to_numeric(
                xl_dataframe["valor_operacao_raw"], errors="coerce"
            )

            # Add metadata
            xl_dataframe["arquivo_origem"] = schema_file_name
            xl_dataframe["data_referencia"] = schema_file_date
            logger.debug(
                f"Added metadata: file='{schema_file_name}', date={schema_file_date}"
            )

            # Ensure all expected columns exist before selecting
            for field in fields:
                if field not in xl_dataframe.columns:
                    xl_dataframe[field] = None  # Or pd.NA or appropriate default

            xl_dataframes.append(xl_dataframe[fields].copy())
            logger.debug(f"Added to results: {len(xl_dataframe)} rows")

        except ValueError as e:
            logger.error(f"ValueError processing file {schema_file}: {e}")
            print(f"Error processing file {schema_file}: {e}")
        except Exception as e:
            logger.error(
                f"Unexpected error processing file {schema_file}: {e}", exc_info=True
            )
            print(f"An unexpected error occurred while processing {schema_file}: {e}")

    if not xl_dataframes:
        logger.warning("No valid dataframes to concatenate, returning empty DataFrame")
        return pd.DataFrame(columns=fields)

    logger.debug(f"Concatenating {len(xl_dataframes)} dataframes")
    result = pd.concat(xl_dataframes, ignore_index=True)
    logger.info(
        f"process_schema_proventos_recebidos() -> DataFrame with shape {result.shape}"
    )
    return result
