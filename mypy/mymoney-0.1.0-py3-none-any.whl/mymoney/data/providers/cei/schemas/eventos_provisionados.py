"""
mymoney.data.providers.cei.schemas.eventos_provisionados - CEI Eventos Provisionados Schema Processor
"""

import pandas as pd
from typing import List, Optional

from mymoney import logger
from . import excel as XL
from .utils import (
    str_to_date,
    tuple_as_str,
    deal_double_spaces,
    extract_file_info,
    extract_product_id,
)


# Nomes de sheet aceitos para esta operação
VALID_SHEET_NAMES = ["Eventos Provisionados", "Proventos a Receber"]


def _find_sheet_index(xl_obj: XL.ExcelWorkbook, valid_names: List[str]) -> Optional[int]:
    """Encontra o índice da sheet pelo nome."""
    for idx, sheet_name in enumerate(xl_obj.sheet_names):
        if sheet_name in valid_names:
            return idx
    return None


def process_schema_eventos_provisionados(
    input_files: List[str],
) -> Optional[pd.DataFrame]:
    """
    Processes CEI 'Eventos Provisionados' Excel files.
    Supports both old format ('Proventos a Receber') and new format ('Eventos Provisionados').
    """
    logger.info(
        f"process_schema_eventos_provisionados(input_files={len(input_files)} files)"
    )

    if not input_files:
        logger.debug("No input files provided, returning empty DataFrame")
        return pd.DataFrame()

    xl_dataframes = []
    fields = [
        "codigo_produto",
        "nome_produto",
        "tipo_produto",
        "tipo_evento",
        "previsao_pagamento",
        "instituicao",
        "conta",
        "quantidade",
        "preco_unitario",
        "valor_operacao",
        "arquivo_origem",
        "data_referencia",
    ]

    for schema_file in input_files:
        logger.debug(f"Processing file: {schema_file}")
        try:
            schema_file_name, schema_file_date = extract_file_info(schema_file)
            logger.debug(
                f"Extracted file info: name='{schema_file_name}', date={schema_file_date}"
            )

            if "eventos" not in schema_file_name:
                logger.warning(
                    f"Skipping file {schema_file} as it doesn't appear to be an 'eventos' type"
                )
                print(
                    f"Warning: Skipping file {schema_file} as it doesn't appear to be an 'eventos' type."
                )
                continue

            logger.debug(f"Loading Excel file: {schema_file}")
            xl_obj = XL.ExcelWorkbook(schema_file)
            
            # Tentar encontrar a sheet correta
            sheet_idx = _find_sheet_index(xl_obj, VALID_SHEET_NAMES)
            if sheet_idx is None:
                logger.warning(
                    f"Skipping file {schema_file}: no valid sheet found. Expected one of {VALID_SHEET_NAMES}, got {xl_obj.sheet_names}"
                )
                print(
                    f"Warning: Skipping file {schema_file}: no valid sheet found."
                )
                continue
                
            xl_table = tuple_as_str(tuple(xl_obj.read_sheet_by_index(sheet_idx)))

            if not xl_table or len(xl_table) < 2:
                logger.warning(
                    f"Skipping file {schema_file} as it contains no data or header"
                )
                print(
                    f"Warning: Skipping file {schema_file} as it contains no data or header."
                )
                continue

            header = xl_table[0]
            data = [d for d in xl_table[1:] if len(d) > 0 and d[0]]
            
            xl_dataframe = pd.DataFrame(data, columns=header)
            logger.debug(f"Created DataFrame with shape: {xl_dataframe.shape}")

            if xl_dataframe.empty:
                logger.warning(f"No data left in {schema_file} after filtering")
                continue

            logger.debug("Starting data cleaning and transformation")
            column_mapping = {
                "Produto": "nome_produto_raw",
                "Tipo": "tipo_produto",
                "Tipo de Evento": "tipo_evento",
                "Previsão de pagamento": "previsao_pagamento_raw",
                "Instituição": "instituicao_raw",
                "Conta": "conta_raw",
                "Quantidade": "quantidade_raw",
                "Preço unitário": "preco_unitario_raw",
                "Valor líquido": "valor_operacao_raw",
            }

            rename_dict = {
                k: v for k, v in column_mapping.items() if k in xl_dataframe.columns
            }
            xl_dataframe = xl_dataframe[list(rename_dict.keys())].rename(
                columns=rename_dict
            )
            logger.debug(f"Mapped {len(rename_dict)} columns")

            # Handle missing columns
            if "conta_raw" not in xl_dataframe.columns:
                xl_dataframe["conta"] = "000000000"
            else:
                xl_dataframe["conta"] = xl_dataframe["conta_raw"].apply(
                    deal_double_spaces
                )

            if "tipo_produto" not in xl_dataframe.columns:
                xl_dataframe["tipo_produto"] = "Fundo"
            else:
                xl_dataframe["tipo_produto"] = xl_dataframe["tipo_produto"].apply(
                    deal_double_spaces
                )

            xl_dataframe["nome_produto"] = xl_dataframe["nome_produto_raw"].apply(
                deal_double_spaces
            )
            xl_dataframe["codigo_produto"] = xl_dataframe["nome_produto"].apply(
                extract_product_id
            )
            
            xl_dataframe["tipo_evento"] = xl_dataframe.get("tipo_evento", "RENDIMENTO")

            xl_dataframe["previsao_pagamento"] = pd.to_datetime(
                xl_dataframe["previsao_pagamento_raw"].apply(str_to_date),
                errors="coerce",
            )

            xl_dataframe["instituicao"] = xl_dataframe["instituicao_raw"].apply(
                deal_double_spaces
            )

            logger.debug("Converting numeric columns")
            xl_dataframe["quantidade"] = pd.to_numeric(
                xl_dataframe["quantidade_raw"], errors="coerce"
            )
            xl_dataframe["preco_unitario"] = pd.to_numeric(
                xl_dataframe["preco_unitario_raw"], errors="coerce"
            )
            xl_dataframe["valor_operacao"] = pd.to_numeric(
                xl_dataframe["valor_operacao_raw"], errors="coerce"
            )

            xl_dataframe["arquivo_origem"] = schema_file_name
            xl_dataframe["data_referencia"] = schema_file_date
            logger.debug(
                f"Added metadata: file='{schema_file_name}', date={schema_file_date}"
            )

            for field in fields:
                if field not in xl_dataframe.columns:
                    xl_dataframe[field] = None

            xl_dataframes.append(xl_dataframe[fields].copy())
            logger.debug(f"Added to results: {len(xl_dataframe)} rows")

        except ValueError as e:
            logger.error(f"ValueError processing file {schema_file}: {e}")
            print(f"Error processing file {schema_file}: {e}")
        except Exception as e:
            logger.error(
                f"Unexpected error processing file {schema_file}: {e}", exc_info=True
            )
            print(f"An unexpected error occurred while processing {schema_file}: {e}")

    if not xl_dataframes:
        logger.warning("No valid dataframes to concatenate, returning empty DataFrame")
        return pd.DataFrame(columns=fields)

    logger.debug(f"Concatenating {len(xl_dataframes)} dataframes")
    result = pd.concat(xl_dataframes, ignore_index=True)
    logger.info(
        f"process_schema_eventos_provisionados() -> DataFrame with shape {result.shape}"
    )
    return result
