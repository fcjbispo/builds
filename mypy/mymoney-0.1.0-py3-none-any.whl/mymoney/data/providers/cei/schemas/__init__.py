from mymoney import logger

from .movimentacao import process_schema_movimentacao
from .eventos_provisionados import process_schema_eventos_provisionados
from .negociacao import process_schema_negociacao
from .posicao_acoes import process_schema_posicao_acoes
from .posicao_emprestimo_ativos import process_schema_posicao_emprestimo_ativos
from .posicao_etf import process_schema_posicao_etf
from .posicao_fundos_investimento import process_schema_posicao_fundos_investimento
from .posicao_tesouro_direto import process_schema_posicao_tesouro_direto
from .posicao_renda_fixa import process_schema_posicao_renda_fixa
from .proventos_recebidos import process_schema_proventos_recebidos
from .proventos_a_receber import process_schema_proventos_a_receber

__all__ = [
    "process_schema_movimentacao",
    "process_schema_eventos_provisionados",
    "process_schema_negociacao",
    "process_schema_posicao_acoes",
    "process_schema_posicao_emprestimo_ativos",
    "process_schema_posicao_etf",
    "process_schema_posicao_fundos_investimento",
    "process_schema_posicao_tesouro_direto",
    "process_schema_posicao_renda_fixa",
    "process_schema_proventos_recebidos",
    "process_schema_proventos_a_receber",
]
