from __future__ import annotations

from pathlib import Path
from typing import Any

import polars as pl


class ExcelWorkbook:
    """Minimal workbook wrapper backed by calamine via Polars."""

    def __init__(self, xl_file: str | bytes):
        self._source = xl_file
        self._sheets = pl.read_excel(
            xl_file,
            sheet_id=0,
            engine="calamine",
            has_header=False,
            raise_if_empty=False,
        )
        if not isinstance(self._sheets, dict):
            sheet_name = Path(xl_file).stem if isinstance(xl_file, str) else "Sheet1"
            self._sheets = {sheet_name: self._sheets}
        self.sheet_names = list(self._sheets.keys())

    def read_sheet(self, sheet_name: str | None = None) -> tuple[tuple[Any, ...], ...]:
        sheet_name = sheet_name or self.sheet_names[0]
        if sheet_name not in self._sheets:
            raise NameError("Invalid/Nonexistent sheet.")
        return tuple(tuple(row) for row in self._sheets[sheet_name].rows())

    def read_sheet_by_index(self, index: int = 0) -> tuple[tuple[Any, ...], ...]:
        if not 0 <= index < len(self.sheet_names):
            raise IndexError("Sheet index out of range.")
        return self.read_sheet(self.sheet_names[index])
