"""FGTS parser supporting PDF, DOCX and MD formats using DoclingConverter."""

from __future__ import annotations

import os
from typing import Any, Callable, Optional

import pandas as pd


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "fgts_domain.md"]
)

# Sentinel value to detect if audit_callback was explicitly provided
_UNSET = object()


def _source_to_markdown(file_path: str) -> str:
    """Convert source file (PDF, DOCX) to markdown using DoclingConverter.

    Args:
        file_path: Path to the source file (PDF, DOCX, or MD)

    Returns:
        Markdown text extracted from the document
    """
    ext = os.path.splitext(file_path)[1].lower()

    # If already markdown, just read it
    if ext == ".md":
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()

    # Convert PDF or DOCX to markdown using DoclingCLIConverter with timeout
    try:
        from mymoney.data.providers.unstructured.docling_cli import (
            DoclingCLIConverter,
        )
        from mymoney.data.providers.unstructured.engine import _convert_with_timeout

        converter = DoclingCLIConverter()
        return _convert_with_timeout(
            converter, {"source": file_path, "input_format": ext.lstrip(".")}
        )
    except Exception as e:
        raise ValueError(f"Failed to convert {ext} to markdown: {e}")


def parse_fgts(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = _UNSET,
    chunking_enabled: bool = True,
    chunk_max_tokens: int = 10000,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse FGTS statement (PDF, DOCX, or MD) using domain-based extraction.

    The FGTS statement is first converted to markdown using
    DoclingConverter (for PDF/DOCX) or read directly (for MD),
    then processed with AI extraction to extract structured transaction data.

    Args:
        file_path: Path to the file (PDF, DOCX, or MD)
        max_attempts: Maximum number of retry attempts for AI extraction
        retry_delay_seconds: Delay between retries in seconds
        audit_callback: Optional callback for auditing the parsed payload
        chunking_enabled: Whether to enable chunking for large documents
        chunk_max_tokens: Maximum tokens per chunk
        use_native_pdf: Whether to use native PDF extraction (skip markdown conversion)

    Returns:
        DataFrame with parsed FGTS transactions
    """
    # For native PDF extraction, skip markdown conversion
    if use_native_pdf and file_path.lower().endswith('.pdf'):
        return _parse_fgts_markdown(
            markdown_content="",  # Empty, will use native PDF
            original_file_path=file_path,
            max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds,
            audit_callback=audit_callback if audit_callback is not _UNSET else None,
            chunking_enabled=False,  # Native PDF doesn't use chunking
            chunk_max_tokens=chunk_max_tokens,
            use_native_pdf=True,
        )

    # Convert source to markdown
    markdown_content = _source_to_markdown(file_path)

    # Process the markdown content
    return _parse_fgts_markdown(
        markdown_content=markdown_content,
        original_file_path=file_path,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback if audit_callback is not _UNSET else None,
        chunking_enabled=chunking_enabled,
        chunk_max_tokens=chunk_max_tokens,
        use_native_pdf=False,
    )


def _parse_fgts_markdown(
    markdown_content: str,
    original_file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    chunking_enabled: bool = True,
    chunk_max_tokens: int = 10000,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse FGTS markdown content using domain-based extraction.

    This internal function processes the markdown content.
    """
    from mymoney.data.providers.unstructured import (
        UnstructuredExtractionEngine,
        load_json_file,
        load_text_file,
        resolve_llm_config_from_user_settings,
    )
    from mymoney.data.providers.base.unstructured import (
        _payload_to_domain_records_dataframe,
        DEFAULT_SCHEMA_PATH,
        DEFAULT_SYSTEM_PROMPT_PATH,
        DEFAULT_USER_PROMPT_PATH,
    )
    from mymoney import env, logger

    # Load prompts and schema
    schema = load_json_file(DEFAULT_SCHEMA_PATH)
    system_prompt = load_text_file(DEFAULT_SYSTEM_PROMPT_PATH)
    user_prompt_template = load_text_file(DEFAULT_USER_PROMPT_PATH)
    domain_rules = load_text_file(DOMAIN_PROMPT_PATH)

    # Replace placeholders
    user_prompt_template = user_prompt_template.replace("__DOMAIN_RULES__", domain_rules)
    user_prompt_template = user_prompt_template.replace("{provider}", "cef")
    user_prompt_template = user_prompt_template.replace("{file_type}", "pdf")
    user_prompt_template = user_prompt_template.replace("{source_name}", "FGTS Statement")

    # Resolve LLM config
    cfg = env.USER_CONFIG or {}
    llm_config = resolve_llm_config_from_user_settings(
        {
            "llm_provider": cfg.get("LLM_PROVIDER"),
            "llm_api_base_url": cfg.get("LLM_BASE_URL"),
            "llm_api_key": cfg.get("LLM_API_KEY"),
            "llm_base_model": cfg.get("LLM_BASE_MODEL"),
            "llm_vision_model": cfg.get("LLM_VISION_MODEL"),
            "llm_embed_model": cfg.get("LLM_EMBED_MODEL"),
        }
    )

    # Extract structured data
    engine = UnstructuredExtractionEngine(llm_config=llm_config)

    # Enable vision fallback for PDFs (DOCX/MD files don't need it)
    is_pdf = original_file_path.lower().endswith('.pdf')

    payload = engine.extract_structured_data(
        markdown_source=markdown_content if not use_native_pdf else None,
        system_prompt=system_prompt,
        user_prompt_template=user_prompt_template,
        json_schema=schema,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback,
        chunking_enabled=chunking_enabled,
        chunk_max_tokens=chunk_max_tokens,
        pdf_source_path=original_file_path if is_pdf else None,
        use_vision_fallback=is_pdf and not use_native_pdf,  # Enable vision fallback for PDFs only when not using native PDF
        use_native_pdf=use_native_pdf,
    )

    logger.info(
        "FGTS extraction completed: file=%s transactions=%s",
        original_file_path,
        len(payload.get("lancamentos", [])) if isinstance(payload, dict) else 0,
    )

    # Convert to DataFrame
    default_currency = env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")
    return _payload_to_domain_records_dataframe(
        payload=payload,
        source="mm.data.elt.load.cef_fgts",
        institution="CAIXA ECONOMICA FEDERAL",
        tipo_lancamento="LANCAMENTOS_CONTA_CORRENTE",
        input_file=original_file_path,
        default_currency=default_currency,
    )


# Keep backward compatibility alias
parse_fgts_docx = parse_fgts
