# Domain Rules - FGTS (Fundo de Garantia) Statement

## Provider Information
- **Source**: FGTS
- **Institution**: CAIXA ECONOMICA FEDERAL
- **File Type**: PDF, DOCX, or MD (converted to Markdown via DoclingConverter)
- **Currency**: BRL
- **Tipo Lancamento**: LANCAMENTOS_CONTA_CORRENTE
- **Tipo Produto**: FGTS

## Document Structure

The FGTS statement extracted from the Caixa app contains:

1. **Header Section**:
   - Nome do Trabalhador
   - PIS/PASEP
   - CNPJ da empresa
   - Nome da empresa

2. **Balance Section**:
   - Saldo disponível (available for withdrawal)
   - Saldo bloqueado (blocked/restricted)
   - Saldo total

3. **Transactions Table**:
   - Data da movimentação
   - Tipo de movimentação
   - Descrição/Detalhamento
   - Valor
   - Saldo após movimentação

## PDF Markdown Format Handling (IMPORTANT)

When processing PDF files converted to markdown by Docling, the table structure may appear broken with each cell on a separate line. The typical format is:

```
DATA

LANÇAMENTO

SALDO ANTERIOR

03/09/2021

150-DEPOSITO AGOSTO 2021

10/10/2021

CREDITO DE JAM 0,002466
```

### Reconstruction Rules:
1. **Pattern Recognition**: Transactions follow the pattern: DATE → DESCRIPTION → (optional second date) → NEXT TRANSACTION
2. **Grouping Logic**:
   - Lines starting with DD/MM/YYYY format are transaction dates
   - Lines immediately following a date are the transaction description (LANÇAMENTO)
   - Lines with "CREDITO DE JAM" or "ATUALIZAÇÃO MONETÁRIA" are separate transactions with their own dates
   - Lines with "SAQUE" indicate withdrawal transactions
3. **Value Extraction**: For FGTS, values are NOT explicitly shown in the transaction list - only the "SALDO ANTERIOR" appears. You must:
   - Calculate approximate values from balance changes OR
   - Set `valor_operacao` to 0.01 (minimal value) if cannot be determined
   - The actual value is less important than the transaction type and date for FGTS
4. **Date Assignment**:
   - Use the date in the left column as `data_movimentacao`
   - Ignore the second date if present (usually the processing date)

### Transaction Reconstruction Examples:

**Example from broken markdown:**
```
03/09/2021

150-DEPOSITO AGOSTO 2021

10/10/2021

CREDITO DE JAM 0,002466
```

**Reconstructed as two transactions:**
1. Date: 2021-09-03, Description: "150-DEPOSITO AGOSTO 2021", Type: DEPOSITO
2. Date: 2021-10-10, Description: "CREDITO DE JAM 0,002466", Type: CORRECAO

**Saque example:**
```
02/05/2022

SAQUE DEP - COD 60

02/05/2022

SAQUE JAM - COD 60
```

**Reconstructed as:**
1. Date: 2022-05-02, Description: "SAQUE DEP - COD 60", Type: SAQUE
2. Date: 2022-05-02, Description: "SAQUE JAM - COD 60", Type: SAQUE

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | LANCAMENTOS_CONTA_CORRENTE |
| tipo_produto | FGTS |
| tipo_evento | DEPOSITO FGTS / SAQUE FGTS / CORRECAO FGTS / TRANSFERENCIA FGTS |
| moeda | BRL |
| instituicao | CAIXA ECONOMICA FEDERAL |
| origem | mm.data.elt.load.cef_fgts |

## Transaction Types Mapping

### Credit Operations (Entrada)

| Tipo no Extrato | movimentacao | entrada_saida | tipo_evento |
|-----------------|--------------|---------------|-------------|
| Depósito Mensal | Deposito FGTS | Credito | DEPOSITO FGTS |
| Depósito | Deposito FGTS | Credito | DEPOSITO FGTS |
| Transferência Entrada | Transferencia FGTS | Credito | TRANSFERENCIA ENTRADA FGTS |
| Correção Monetária | Correcao Monetaria FGTS | Credito | CORRECAO FGTS |
| Atualização Monetária | Correcao Monetaria FGTS | Credito | CORRECAO FGTS |
| Juros | Juros FGTS | Credito | JUROS FGTS |
| Remuneração | Juros FGTS | Credito | JUROS FGTS |

### Debit Operations (Saída)

| Tipo no Extrato | movimentacao | entrada_saida | tipo_evento |
|-----------------|--------------|---------------|-------------|
| Saque Desemprego | Saque Desemprego FGTS | Debito | SAQUE DESEMPREGO FGTS |
| Saque Aniversário | Saque Aniversario FGTS | Debito | SAQUE ANIVERSARIO FGTS |
| Saque por Doença | Saque Doenca FGTS | Debito | SAQUE DOENCA FGTS |
| Saque por Morte | Saque Morte FGTS | Debito | SAQUE MORTE FGTS |
| Saque para Compra de Imóvel | Saque Imovel FGTS | Debito | SAQUE IMOVEL FGTS |
| Saque - Outros | Saque Outros FGTS | Debito | SAQUE OUTROS FGTS |
| Transferência Saída | Transferencia FGTS | Debito | TRANSFERENCIA SAIDA FGTS |
| Penhora Judicial | Penhora FGTS | Debito | PENHORA FGTS |
| Bloqueio Judicial | Bloqueio FGTS | Debito | BLOQUEIO FGTS |

## Output Requirements

- Return data in the `lancamentos` list using the standard checking-account structure.
- Every row must contain at least:
  - `entrada_saida`: "Credito" for deposits/corrections, "Debito" for withdrawals
  - `data_movimentacao`: Date in YYYY-MM-DD format
  - `movimentacao`: Normalized movement type (see table above)
  - `nome_produto`: Detailed description including company name if available
  - `valor_operacao`: Positive numeric value
  - `tipo_produto`: "FGTS"
  - `tipo_evento`: One of the event types listed above
  - `tipo_lancamento`: "LANCAMENTOS_CONTA_CORRENTE"
  - `instituicao`: "CAIXA ECONOMICA FEDERAL"
  - `conta`: PIS/PASEP number or account identifier
  - `moeda`: "BRL"

- Also fill when available:
  - `quantidade_disponivel`: Available balance after transaction (if shown)
  - `quantidade_indisponivel`: Blocked balance (if shown)
  - `valor_atualizado`: Total balance after transaction (if shown)

## Transaction Examples

### Example 1: Monthly Deposit
```
Input from markdown:
Data: 15/01/2024
Tipo: Depósito Mensal
Descrição: Contribuição obrigatória referente à competência 12/2023
Valor: R$ 200,00
Saldo: R$ 5.200,00

Output:
- data_movimentacao: "2024-01-15"
- movimentacao: "Deposito FGTS"
- nome_produto: "Contribuicao obrigatoria referente a competencia 12/2023"
- entrada_saida: "Credito"
- valor_operacao: 200.00
- tipo_evento: "DEPOSITO FGTS"
- tipo_produto: "FGTS"
- tipo_lancamento: "LANCAMENTOS_CONTA_CORRENTE"
- instituicao: "CAIXA ECONOMICA FEDERAL"
- conta: [PIS/PASEP from header]
- moeda: "BRL"
```

### Example 2: Saque Aniversário
```
Input from markdown:
Data: 20/02/2024
Tipo: Saque Aniversário
Descrição: Saque referente ao aniversário - Modalidade aniversário
Valor: - R$ 1.000,00
Saldo: R$ 4.200,00

Output:
- data_movimentacao: "2024-02-20"
- movimentacao: "Saque Aniversario FGTS"
- nome_produto: "Saque referente ao aniversario - Modalidade aniversario"
- entrada_saida: "Debito"
- valor_operacao: 1000.00
- tipo_evento: "SAQUE ANIVERSARIO FGTS"
- tipo_produto: "FGTS"
- tipo_lancamento: "LANCAMENTOS_CONTA_CORRENTE"
- instituicao: "CAIXA ECONOMICA FEDERAL"
- conta: [PIS/PASEP from header]
- moeda: "BRL"
```

### Example 3: Monetary Correction
```
Input from markdown:
Data: 31/01/2024
Tipo: Correção Monetária
Descrição: Atualização monetária do período
Valor: R$ 45,50
Saldo: R$ 5.245,50

Output:
- data_movimentacao: "2024-01-31"
- movimentacao: "Correcao Monetaria FGTS"
- nome_produto: "Atualizacao monetaria do periodo"
- entrada_saida: "Credito"
- valor_operacao: 45.50
- tipo_evento: "CORRECAO FGTS"
- tipo_produto: "FGTS"
- tipo_lancamento: "LANCAMENTOS_CONTA_CORRENTE"
- instituicao: "CAIXA ECONOMICA FEDERAL"
- conta: [PIS/PASEP from header]
- moeda: "BRL"
```

## Mapping Rules

### Account Identification
- Extract PIS/PASEP from the document header
- Use PIS/PASEP as the `conta` field
- Format: just the number, no special characters
- If multiple accounts exist (multiple employers), create separate transactions for each

### Date Extraction
- Parse dates from DD/MM/YYYY format
- Convert to YYYY-MM-DD
- All transactions must have a valid date

### Amount Processing
- Always extract values as positive numbers
- Remove "R$" prefix and any thousand separators (dots)
- Use comma as decimal separator
- The `entrada_saida` field indicates the direction

### Description Building
- Combine type and description when available
- Format: "[Tipo] - [Descrição detalhada]"
- If no detailed description, use just the type
- Include employer name if available in the context

### Balance Fields
- `quantidade_disponivel`: Map from "Saldo Disponível" or "Saldo após movimentação"
- `quantidade_indisponivel`: Map from "Saldo Bloqueado" if shown
- `valor_atualizado`: Map from "Saldo Total" if shown
- These are optional - fill only if present in the document

## Important Notes

- FGTS is a government-backed savings fund for workers
- Each worker can have multiple accounts (one per employer)
- The statement shows historical transactions
- Corrections and interest are credited periodically
- Withdrawals depend on specific conditions (unemployment, birthday, illness, etc.)
- Saque Aniversário allows annual withdrawal based on birth month
- Saque Desemprego allows withdrawal when dismissed without cause
- The document may contain multiple sections if the worker has multiple employers
- Always extract ALL transactions from the statement
- Do not skip rows - even small values
- Pay attention to the transaction direction (positive/negative in source)
- **PDF Processing**: When the markdown table structure is broken, use the reconstruction rules above to identify and extract all transactions

## Required Output Format

When returning the JSON, ensure:
1. Every transaction has `data_movimentacao`, `movimentacao`, `tipo_evento`, `entrada_saida`, and `valor_operacao`
2. Dates are in YYYY-MM-DD format
3. For deposits/corrections: `entrada_saida` = "Credito"
4. For withdrawals: `entrada_saida` = "Debito"
5. If `valor_operacao` cannot be determined from the statement, use 0.01 as placeholder
