"""CEF (Caixa Economica Federal) provider for FGTS statements.

Supports PDF, DOCX, and MD formats from the Caixa FGTS app.
PDF is the primary format as of 2025, with DOCX and MD as fallbacks.
"""

from __future__ import annotations

import os
from glob import glob

from mymoney.data.providers.cef.fgts_parser import parse_fgts

# Default masks - PDF is primary format, DOCX and MD as fallbacks
CEF_DEFAULT_MASKS = ("*.pdf", "*.docx", "*.md")
CEF_PROVIDER = "cef"
CEF_INSTITUTION = "CAIXA ECONOMICA FEDERAL"
CEF_CC_DEFAULT_MASKS = ("*.pdf", "*.docx", "*.md")


def list_unprocessed_files(
    input_folder: str,
    input_masks: list[str] | tuple[str, ...],
) -> list[str]:
    """Return sorted input files that are not marked as `.done`."""
    if not input_folder:
        return []

    if not os.path.exists(input_folder):
        return []

    masks = list(input_masks or [])
    if not masks:
        masks = ["*"]

    files: set[str] = set()
    for mask in masks:
        pattern = os.path.sep.join([input_folder, mask])
        for path in glob(pattern):
            if os.path.isfile(path) and not path.endswith(".done"):
                files.add(path)

    return sorted(files)


__all__ = [
    "CEF_DEFAULT_MASKS",
    "CEF_CC_DEFAULT_MASKS",
    "CEF_PROVIDER",
    "CEF_INSTITUTION",
    "list_unprocessed_files",
    "parse_fgts",
]
