from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Callable, Optional

import pandas as pd
from infobr.data import DataProvider

from mymoney import env, logger
from mymoney.data.providers.pdf import resolve_pdf_password
from mymoney.data.providers.unstructured import (
    UnstructuredExtractionEngine,
    load_json_file,
    load_text_file,
    resolve_llm_config_from_user_settings,
)


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCE_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
_PROMPTS_DIR = os.path.sep.join([_RESOURCE_DIR, "prompts"])
DEFAULT_SCHEMA_PATH = os.path.sep.join([_RESOURCE_DIR, "schema.json"])
DEFAULT_SYSTEM_PROMPT_PATH = os.path.sep.join([_PROMPTS_DIR, "base_system_prompt.md"])
DEFAULT_USER_PROMPT_PATH = os.path.sep.join([_PROMPTS_DIR, "base_user_prompt.md"])

LANCAMENTOS_COLUMNS = [
    "entrada_saida",
    "data_movimentacao",
    "movimentacao",
    "nome_produto",
    "codigo_produto",
    "instituicao",
    "conta",
    "quantidade",
    "preco_unitario",
    "valor_operacao",
    "tipo_produto",
    "tipo_evento",
    "previsao_pagamento",
    "data_negocio",
    "mercado",
    "prazo_vencimento",
    "codigo_isin",
    "escriturador",
    "motivo",
    "administrador",
    "indexador",
    "vencimento",
    "quantidade_disponivel",
    "quantidade_indisponivel",
    "valor_aplicado",
    "valor_bruto",
    "valor_liquido",
    "valor_atualizado",
    "tipo_lancamento",
    "moeda",
    "origem",
    "arquivo_origem",
    "data_referencia",
]


def _to_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    text = text.replace("$", "").replace(" ", "")
    if "," in text and "." in text:
        text = text.replace(",", "")
    elif "," in text:
        text = text.replace(",", ".")
    try:
        return float(text)
    except Exception:
        return None


def _normalize_entrada_saida(value: Any, fallback_amount: Any) -> str:
    text = str(value or "").strip().lower()
    if text in ("credito", "crédito", "c", "credit"):
        return "Credito"
    if text in ("debito", "débito", "d", "debit"):
        return "Debito"
    amount = _to_float(fallback_amount)
    return "Debito" if amount is not None and amount < 0 else "Credito"


def _normalize_datetime(value: Any) -> Any:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    for fmt in ("%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            continue
    parsed = pd.to_datetime(text, errors="coerce", dayfirst=True)
    return None if pd.isna(parsed) else parsed.to_pydatetime()


def _payload_to_domain_records_dataframe(
    payload: dict[str, Any],
    *,
    source: str,
    institution: str,
    tipo_lancamento: str,
    input_file: str,
    default_currency: str,
) -> pd.DataFrame:
    account = payload.get("account", {}) if isinstance(payload, dict) else {}
    account_id = (
        account.get("account_id")
        or account.get("account_number")
        or account.get("number")
    )
    account_currency = account.get("currency") or default_currency

    items = payload.get("lancamentos", []) if isinstance(payload, dict) else []
    if not isinstance(items, list):
        items = []

    rows: list[dict[str, Any]] = []
    file_name = os.path.basename(input_file).split(".")[0]
    run_at = datetime.now()

    for item in items:
        if not isinstance(item, dict):
            continue
        row = {k: item.get(k) for k in LANCAMENTOS_COLUMNS}

        row["entrada_saida"] = _normalize_entrada_saida(
            item.get("entrada_saida"),
            item.get("valor_operacao"),
        )
        row["valor_operacao"] = _to_float(item.get("valor_operacao"))
        row["quantidade"] = _to_float(item.get("quantidade"))
        row["preco_unitario"] = _to_float(item.get("preco_unitario"))
        row["quantidade_disponivel"] = _to_float(item.get("quantidade_disponivel"))
        row["quantidade_indisponivel"] = _to_float(item.get("quantidade_indisponivel"))
        row["valor_aplicado"] = _to_float(item.get("valor_aplicado"))
        row["valor_bruto"] = _to_float(item.get("valor_bruto"))
        row["valor_liquido"] = _to_float(item.get("valor_liquido"))
        row["valor_atualizado"] = _to_float(item.get("valor_atualizado"))

        row["data_movimentacao"] = _normalize_datetime(item.get("data_movimentacao"))
        row["previsao_pagamento"] = _normalize_datetime(item.get("previsao_pagamento"))
        row["data_negocio"] = _normalize_datetime(item.get("data_negocio"))
        row["vencimento"] = _normalize_datetime(item.get("vencimento"))

        row["instituicao"] = row.get("instituicao") or institution
        row["conta"] = row.get("conta") or account_id
        row["tipo_lancamento"] = row.get("tipo_lancamento") or tipo_lancamento
        row["moeda"] = row.get("moeda") or account_currency or default_currency
        row["origem"] = row.get("origem") or source
        row["arquivo_origem"] = row.get("arquivo_origem") or file_name
        row["data_referencia"] = row.get("data_referencia") or run_at

        rows.append(row)

    if not rows:
        return pd.DataFrame(columns=LANCAMENTOS_COLUMNS)
    return pd.DataFrame(rows)[LANCAMENTOS_COLUMNS]


class UnstructuredDomainDataProvider(DataProvider):
    EXPECTED_PARAMS = {
        "source_file": (str, True, None),
        "source": (str, True, None),
        "institution": (str, True, None),
        "tipo_lancamento": (str, False, "MOVIMENTACAO"),
        "schema_path": (str, False, DEFAULT_SCHEMA_PATH),
        "provider": (str, True, None),
        "file_type": (str, True, None),
        "source_name": (str, True, None),
        "system_prompt_path": (str, False, DEFAULT_SYSTEM_PROMPT_PATH),
        "user_prompt_path": (str, False, DEFAULT_USER_PROMPT_PATH),
        "domain_prompt_path": (str, True, None),
        "max_attempts": (int, False, 3),
        "retry_delay_seconds": (int, False, 0),
        "llm_temperature": (float, False, 0.0),
        "llm_max_tokens": (int, False, 8192),
        "llm_provider": (str, False, None),
        "llm_api_base_url": (str, False, None),
        "llm_api_key": (str, False, None),
        "llm_base_model": (str, False, None),
        "llm_vision_model": (str, False, None),
        "llm_embed_model": (str, False, None),
        "llm_timeout": (int, False, None),
        "llm_retries": (int, False, None),
        "docling_ocr": (bool, False, True),
        "docling_ocr_engine": (str, False, "easyocr"),
        "docling_table_mode": (str, False, "accurate"),
        "docling_image_export_mode": (str, False, "placeholder"),
        "docling_force_image": (bool, False, True),
        "pdf_password": (str, False, None),
        "pdf_password_required": (bool, False, False),
        "chunking_enabled": (bool, False, True),
        "chunk_max_tokens": (int, False, 10000),
        "use_native_pdf": (bool, False, False),
    }

    def __init__(self, params: dict):
        merged = {k: v[2] for k, v in self.EXPECTED_PARAMS.items()}
        merged.update(params or {})
        self.audit_callback: Optional[Callable[[dict[str, Any]], Any]] = merged.pop(
            "audit_callback", None
        )
        if self.audit_callback is not None and not callable(self.audit_callback):
            raise ValueError("audit_callback must be callable or None.")

        # Resolve PDF password from config if not explicitly provided
        if not merged.get("pdf_password"):
            provider = merged.get("provider")
            merged["pdf_password"] = resolve_pdf_password(provider=provider)

        super().__init__(merged)

        # Resolve default prompt paths based on provider and file_type after super() is called
        self._resolve_prompt_paths()

    def _resolve_prompt_paths(self) -> None:
        """Resolve default prompt paths based on provider and file_type."""
        provider = self.params.get("provider")
        file_type = self.params.get("file_type")
        
        # Use default system/user prompts if not explicitly provided
        if self.params.get("system_prompt_path") == self.EXPECTED_PARAMS["system_prompt_path"][2]:
            self.params["system_prompt_path"] = DEFAULT_SYSTEM_PROMPT_PATH
        if self.params.get("user_prompt_path") == self.EXPECTED_PARAMS["user_prompt_path"][2]:
            self.params["user_prompt_path"] = DEFAULT_USER_PROMPT_PATH
        
        # Resolve domain prompt if not explicitly provided
        if provider and file_type and not self._user_provided("domain_prompt_path"):
            self.params["domain_prompt_path"] = self._resolve_domain_prompt_path(provider, file_type)

    def _user_provided(self, key: str) -> bool:
        """Check if user explicitly provided this parameter (not default)."""
        defaults = self.EXPECTED_PARAMS
        if key not in defaults:
            return True
        default_value = defaults[key][2]
        return self.params.get(key) != default_value

    def _resolve_domain_prompt_path(self, provider: Optional[str], file_type: Optional[str]) -> str:
        """Resolve the domain prompt path based on provider and file type."""
        if not provider or not file_type:
            raise ValueError("provider and file_type are required for domain prompt resolution")
        
        provider = provider.lower().replace("-", "_")
        file_type = file_type.lower()
        
        # Try multiple possible locations
        possible_paths = [
            os.path.sep.join([_RESOURCE_DIR, provider, "resources", "domain", f"{provider}_{file_type}_domain.md"]),
            os.path.sep.join([_RESOURCE_DIR, "domain", f"{provider}_{file_type}_domain.md"]),
            os.path.sep.join([_RESOURCE_DIR, f"{provider}_{file_type}_domain.md"]),
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
        
        raise ValueError(f"Domain prompt not found for provider={provider}, file_type={file_type}")

    def get_data(self) -> pd.DataFrame:
        logger.info(
            "Starting unstructured extraction for source_file=%s provider=%s file_type=%s max_attempts=%s",
            self.params["source_file"],
            self.params.get("provider"),
            self.params.get("file_type"),
            self.params.get("max_attempts"),
        )
        schema = load_json_file(self.params["schema_path"])
        system_prompt = load_text_file(self.params["system_prompt_path"])
        user_prompt_template = load_text_file(self.params["user_prompt_path"])
        domain_rules = load_text_file(self.params["domain_prompt_path"])
        # Replace placeholders in user prompt template
        user_prompt_template = user_prompt_template.replace("__DOMAIN_RULES__", domain_rules)
        user_prompt_template = user_prompt_template.replace("{provider}", self.params.get("provider", ""))
        user_prompt_template = user_prompt_template.replace("{file_type}", self.params.get("file_type", ""))
        user_prompt_template = user_prompt_template.replace("{source_name}", self.params.get("source_name", ""))

        llm_config = resolve_llm_config_from_user_settings(
            {
                "llm_provider": self.params.get("llm_provider"),
                "llm_api_base_url": self.params.get("llm_api_base_url"),
                "llm_api_key": self.params.get("llm_api_key"),
                "llm_base_model": self.params.get("llm_base_model"),
                "llm_vision_model": self.params.get("llm_vision_model"),
                "llm_embed_model": self.params.get("llm_embed_model"),
                "llm_timeout": self.params.get("llm_timeout"),
                "llm_retries": self.params.get("llm_retries"),
            }
        )
        engine = UnstructuredExtractionEngine(llm_config=llm_config)
        use_native_pdf = self.params.get("use_native_pdf", False)

        if use_native_pdf:
            # Skip markdown conversion, use PDF natively with automatic pagination
            logger.info(
                "Using native PDF extraction for source_file=%s (with automatic pagination if needed)",
                self.params["source_file"],
            )
            payload = engine.extract_structured_data(
                markdown_source=None,
                system_prompt=system_prompt,
                user_prompt_template=user_prompt_template,
                json_schema=schema,
                max_attempts=self.params["max_attempts"],
                retry_delay_seconds=self.params["retry_delay_seconds"],
                temperature=self.params["llm_temperature"],
                max_tokens=self.params["llm_max_tokens"],
                audit_callback=self.audit_callback,
                chunking_enabled=False,  # Native PDF uses pagination instead of chunking
                pdf_source_path=self.params["source_file"],
                use_native_pdf=True,
            )
        else:
            # Convert to markdown first (existing flow)
            markdown = engine.source_to_markdown(
                source_file=self.params["source_file"],
                input_format="pdf",
                ocr=self.params["docling_ocr"],
                ocr_engine=self.params["docling_ocr_engine"],
                table_mode=self.params["docling_table_mode"],
                image_export_mode=self.params["docling_image_export_mode"],
                force_image=self.params["docling_force_image"],
                pdf_password=self.params.get("pdf_password"),
                pdf_password_required=self.params.get("pdf_password_required", False),
            )
            logger.debug(
                "Markdown generated for source_file=%s with %s characters",
                self.params["source_file"],
                len(markdown or ""),
            )

            payload = engine.extract_structured_data(
                markdown_source=markdown,
                system_prompt=system_prompt,
                user_prompt_template=user_prompt_template,
                json_schema=schema,
                max_attempts=self.params["max_attempts"],
                retry_delay_seconds=self.params["retry_delay_seconds"],
                temperature=self.params["llm_temperature"],
                max_tokens=self.params["llm_max_tokens"],
                audit_callback=self.audit_callback,
                chunking_enabled=self.params.get("chunking_enabled", True),
                chunk_max_tokens=self.params.get("chunk_max_tokens", 10000),
                pdf_source_path=self.params["source_file"],
                use_native_pdf=False,
            )
        logger.debug(
            "Structured payload extracted for source_file=%s with %s lancamentos",
            self.params["source_file"],
            len(payload.get("lancamentos", [])) if isinstance(payload, dict) else 0,
        )
        default_currency = env.USER_CONFIG.get("DEFAULT_CURRENCY", "BRL")
        dataframe = _payload_to_domain_records_dataframe(
            payload=payload,
            source=self.params["source"],
            institution=self.params["institution"],
            tipo_lancamento=self.params["tipo_lancamento"],
            input_file=self.params["source_file"],
            default_currency=default_currency,
        )
        logger.info(
            "Finished unstructured extraction for source_file=%s rows=%s",
            self.params["source_file"],
            len(dataframe),
        )
        return dataframe


def parse_unstructured_domain_pdf(
    file_path: str,
    *,
    provider: str,
    file_type: str,
    source_name: str,
    source: str,
    institution: str,
    tipo_lancamento: str,
    domain_prompt_path: str,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    chunking_enabled: bool = True,
    chunk_max_tokens: int = 10000,
    pdf_password: str | None = None,
    pdf_password_required: bool = False,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    cfg = env.USER_CONFIG or {}
    resolved_attempts = int(
        cfg.get("LLM_EXTRACTION_MAX_ATTEMPTS", max_attempts)
    )
    resolved_retry_delay = int(
        cfg.get("LLM_EXTRACTION_RETRY_DELAY_SECONDS", retry_delay_seconds)
    )
    resolved_docling_ocr_engine = str(cfg.get("DOCLING_OCR_ENGINE", "easyocr"))
    provider = UnstructuredDomainDataProvider(
        {
            "source_file": file_path,
            "provider": provider,
            "file_type": file_type,
            "source_name": source_name,
            "source": source,
            "institution": institution,
            "tipo_lancamento": tipo_lancamento,
            "domain_prompt_path": domain_prompt_path,
            "max_attempts": resolved_attempts,
            "retry_delay_seconds": resolved_retry_delay,
            "docling_ocr_engine": resolved_docling_ocr_engine,
            "audit_callback": audit_callback,
            "chunking_enabled": chunking_enabled,
            "chunk_max_tokens": chunk_max_tokens,
            "pdf_password": pdf_password,
            "pdf_password_required": pdf_password_required,
            "use_native_pdf": use_native_pdf,
        }
    )
    return provider.get_data()
