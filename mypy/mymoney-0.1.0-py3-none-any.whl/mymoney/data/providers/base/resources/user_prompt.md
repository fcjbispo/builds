Extract data from the markdown source and output JSON strictly matching this schema:

__JSON_SCHEMA__

Output restrictions (mandatory):
- Return only the final JSON payload object with keys `account`, `period`, and `lancamentos`.
- Do not return schema metadata keys such as `$schema`, `title`, `type`, `properties`, `required`, or `default`.
- Do not wrap output with markdown code fences.
- For long documents, scan the markdown in segments and only finalize after covering the full statement.

Domain-specific extraction rules:
__DOMAIN_RULES__

General mapping guidance for each `lancamentos` item:
- `entrada_saida`: `Credito` or `Debito`.
- `data_movimentacao`: operation date (prefer date+time when available).
- `movimentacao`: operation family/type.
- `nome_produto`: operation description label.
- `valor_operacao`: signed numeric amount (negative for debits, positive for credits when possible).
- `tipo_lancamento`: launch domain code.
- `moeda`: transaction currency.
- Fill optional fields when explicit in source.
- Ignore repeated headers, footers, and column labels.
- Keep one output item per real transaction row.
- Deduplicate only exact repeated rows caused by OCR or page overlap.
- Do not merge recurring daily or monthly transactions just because descriptions are similar.

Source markdown:
__MARKDOWN_SOURCE__
