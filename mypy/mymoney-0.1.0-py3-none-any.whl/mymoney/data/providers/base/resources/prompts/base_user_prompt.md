# Base User Prompt - Lancamentos Extraction

## Context

Provider: {provider}
File Type: {file_type}
Source: {source_name}

## Document to Process

Analyze the provided document markdown and extract all financial transactions.

__MARKDOWN_SOURCE__

## Domain-Specific Rules

__DOMAIN_RULES__

## Instructions

1. Extract ALL transactions from the document - do not skip any rows
2. Map each transaction to the appropriate fields in the output structure
3. Apply the domain-specific rules for this provider and file type
4. Return the JSON in the exact format specified in the system prompt
5. For long documents, process the markdown in logical segments such as pages, repeated tables, or statement sections, then combine the extracted transactions into one final JSON payload
6. Use the account/header information first, then scan transaction rows segment by segment until the end of the document
7. Ignore repeated headers, footers, disclaimers, and column labels that appear on every page
8. If OCR or page boundaries repeat the same row, keep only the exact duplicate-free set of transactions
9. Do not collapse recurring transactions with the same description on different dates; they are separate lancamentos
10. When date and time are split across lines, combine them into one transaction timestamp before mapping fields

## Output

Return ONLY the JSON object with keys: account, period, lancamentos

Do not include any other text, explanations, or markdown formatting.
