# Domain Rules - Mercado Pago PDF Bank Statement

## Provider Information
- **Source**: mm.data.elt.load.mercado_pago
- **Institution**: MERCADO PAGO INSTituicao DE PAGAMENTO LTDA.
- **File Type**: PDF account statement
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | mm.data.elt.load.mercado_pago |

## PDF Structure

The Mercado Pago PDF statement contains:
- Header with customer name, CPF/CNPJ, Agência, Conta, and statement period (Período: De DD-MM-YYYY al DD-MM-YYYY)
- Balance summary: Saldo inicial, Entradas, Saídas, Saldo final
- Movements table with these columns:
  - **Data** - Date in DD-MM-YYYY format
  - **Descrição** - Transaction description
  - **ID da operação** - Unique operation identifier (numeric)
  - **Valor** - Transaction amount (signed: positive for credits, negative for debits)
  - **Saldo** - Running balance after transaction

Extract every movement row from the statement table. Ignore page headers, footers, support text and repeated column headers on subsequent pages.

## Output Requirements

- Return data in the `lancamentos` list using the same direct structure accepted by checking-account loaders.
- Every row must contain at least:
  - `entrada_saida`
  - `data_movimentacao`
  - `movimentacao`
  - `nome_produto`
  - `valor_operacao`
- Also fill when available:
  - `conta`
  - `instituicao`
  - `tipo_produto`
  - `tipo_evento`
  - `moeda`
  - `origem`
  - `codigo_produto` (map from "ID da operação" if present)

## Mapping Rules

### Account
- Build `conta` as `<agencia>.<conta>` when both values are available in the header.
- Example: agency `1` and account `72526899257` -> `1.72526899257`

### Date
- Parse the `Data` column in DD-MM-YYYY format.
- Convert to `YYYY-MM-DD HH:MM:SS` (set time to 00:00:00 if not available).
- Every transaction must have a valid `data_movimentacao`.

### Amount and direction
- `entrada_saida` must be `Credito` for incoming money and `Debito` for outgoing money.
- Use the sign shown in the PDF `Valor` column to determine the direction:
  - Positive values (or with `R$`) = Credito
  - Negative values (with `-` sign) = Debito
- `valor_operacao` must be returned as a positive number. Do not keep the negative sign once `entrada_saida` is defined.

### Movement description
- `movimentacao` should be a normalized business label for the movement.
- `nome_produto` should keep the original description from the PDF when there is no distinct financial product.
- For common movements, use concise labels such as:
  - `Rendimentos` - for "Rendimentos" entries
  - `Pix Recebido` - for "Transferência Pix recebida" entries
  - `Compra` - for purchase-related entries
  - `Transferencia` - for transfers

### Operation ID
- Map the "ID da operação" column to `codigo_produto` when available.
- This serves as a unique identifier for deduplication purposes.

### Specific interpretation examples
- `Rendimentos`
  - `entrada_saida`: `Credito`
  - `movimentacao`: `Rendimentos`
  - `nome_produto`: `Rendimentos`
- `Transferência Pix recebida FRANCISCO DAS CHAGAS DE JESUS BISPO`
  - `entrada_saida`: `Credito`
  - `movimentacao`: `Pix Recebido`
  - `nome_produto`: `Transferência Pix recebida`
- `Compra de Fones De Ouvido Sem Fio Jbl Tune 770nc Over Ear, Cor Preta Mercado Livre`
  - `entrada_saida`: `Debito`
  - `movimentacao`: `Compra`
  - `nome_produto`: Full description from PDF

## Important Notes

- `instituicao` must always be `MERCADO PAGO INSTituicao DE PAGAMENTO LTDA.`.
- `tipo_produto` should default to `CONTA CORRENTE`.
- `tipo_evento` should default to `LANCAMENTO C/C`.
- Ignore saldo columns for output rows; they are supporting context only.
- Do not skip rows only because saldo values are shown as `-`.
- Page numbers like "1/2", "2/2" at the bottom should be ignored.
- Multi-page statements may repeat the header table; deduplicate based on transaction data.
