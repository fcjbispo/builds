from __future__ import annotations

import os
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "mercado_pago_cc_pdf_domain.md"]
)

# Sentinel value to detect if audit_callback was explicitly provided
_UNSET = object()


def parse_mercado_pago_cc_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = _UNSET,
    chunking_enabled: bool = True,
    chunk_max_tokens: int = 10000,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Mercado Pago credit card PDF statement using domain-based extraction.

    Args:
        file_path: Path to the PDF file
        max_attempts: Maximum number of retry attempts
        retry_delay_seconds: Delay between retries in seconds
        audit_callback: Optional callback for auditing the parsed payload
        chunking_enabled: Whether to enable chunking for large PDFs
        chunk_max_tokens: Maximum tokens per chunk
        use_native_pdf: Whether to use native PDF extraction (skip markdown conversion)

    Returns:
        DataFrame with parsed credit card transactions including parcela info
    """
    return parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="mercado_pago_cc",
        file_type="pdf",
        source_name="Mercado Pago Credit Card Statement",
        source="MERCADO_PAGO_CC",
        institution="MERCADO PAGO INSTITUICAO DE PAGAMENTO LTDA.",
        tipo_lancamento="LANCAMENTOS_CARTAO_CREDITO",
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback if audit_callback is not _UNSET else None,
        chunking_enabled=chunking_enabled,
        chunk_max_tokens=chunk_max_tokens,
        use_native_pdf=use_native_pdf,
    )
