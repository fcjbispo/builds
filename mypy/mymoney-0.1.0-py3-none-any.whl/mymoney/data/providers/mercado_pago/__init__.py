from mymoney.data.providers.mercado_pago.mercado_pago_pdf import parse_mercado_pago_pdf
from mymoney.data.providers.mercado_pago.mercado_pago_cc_pdf import parse_mercado_pago_cc_pdf


MERCADO_PAGO_DEFAULT_MASKS = ("*.pdf",)
MERCADO_PAGO_CC_DEFAULT_MASKS = ("*.pdf",)


__all__ = [
    "MERCADO_PAGO_DEFAULT_MASKS",
    "MERCADO_PAGO_CC_DEFAULT_MASKS",
    "parse_mercado_pago_pdf",
    "parse_mercado_pago_cc_pdf",
]
