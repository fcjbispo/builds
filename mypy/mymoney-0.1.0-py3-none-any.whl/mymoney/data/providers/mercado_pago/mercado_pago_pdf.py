from __future__ import annotations

import os
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf
from mymoney.data.providers.pdf import resolve_pdf_password


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join([_RESOURCES_DIR, "domain", "mercado_pago_pdf_domain.md"])


def parse_mercado_pago_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    chunking_enabled: bool = True,
    chunk_max_tokens: int = 10000,
    pdf_password: str | None = None,
    pdf_password_required: bool = False,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    resolved_password = resolve_pdf_password(
        provider="mercado_pago",
        explicit_password=pdf_password,
    )
    return parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="mercado_pago",
        file_type="pdf",
        source_name="Mercado Pago Statement",
        source="mm.data.elt.load.mercado_pago",
        institution="MERCADO PAGO INSTITUICAO DE PAGAMENTO LTDA.",
        tipo_lancamento="MOVIMENTACAO",
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback,
        chunking_enabled=chunking_enabled,
        chunk_max_tokens=chunk_max_tokens,
        pdf_password=resolved_password,
        pdf_password_required=pdf_password_required,
        use_native_pdf=use_native_pdf,
    )
