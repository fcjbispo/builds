"""Cache de resultados LLM para extração de documentos."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Optional

from mymoney import env as mymoney_env


def _compute_hash(system_prompt: str, user_prompt: str) -> str:
    """Computa hash SHA256 do conteúdo dos prompts."""
    content = f"{system_prompt}||{user_prompt}"
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class LLMCache:
    """Cache em disco para resultados de chamadas LLM."""
    
    def __init__(self, cache_dir: Optional[str] = None, ttl_hours: int = 168):
        """Inicializa o cache."""
        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            # Usa USER_APP_FOLDER do mymoney (~/.mymoney)
            self.cache_dir = Path(mymoney_env.USER_APP_FOLDER) / "cache" / "llm"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = ttl_hours * 3600
    
    def _get_cache_path(self, key: str) -> Path:
        """Retorna o caminho do arquivo de cache para uma chave."""
        subdir = self.cache_dir / key[:2]
        subdir.mkdir(exist_ok=True)
        return subdir / f"{key}.json"
    
    def get(self, system_prompt: str, user_prompt: str) -> Optional[dict[str, Any]]:
        """Recupera resultado do cache se existir e for válido."""
        key = _compute_hash(system_prompt, user_prompt)
        cache_path = self._get_cache_path(key)
        
        if not cache_path.exists():
            return None
        
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                cached = json.load(f)
            
            if self.ttl_seconds >= 0:
                timestamp = cached.get("_cache_timestamp", 0)
                # TTL = 0 significa que expira imediatamente (não usar cache)
                # TTL > 0 significa tempo de vida em segundos
                if self.ttl_seconds == 0 or (time.time() - timestamp > self.ttl_seconds):
                    cache_path.unlink(missing_ok=True)
                    return None
            
            return cached.get("result")
            
        except (json.JSONDecodeError, IOError, OSError):
            cache_path.unlink(missing_ok=True)
            return None
    
    def set(self, system_prompt: str, user_prompt: str, result: dict[str, Any]) -> None:
        """Armazena resultado no cache."""
        key = _compute_hash(system_prompt, user_prompt)
        cache_path = self._get_cache_path(key)
        
        cache_entry = {
            "_cache_timestamp": time.time(),
            "_cache_key": key,
            "result": result
        }
        
        try:
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump(cache_entry, f, ensure_ascii=False, indent=2)
        except (IOError, OSError):
            pass
    
    def clear(self) -> int:
        """Limpa todo o cache. Retorna número de arquivos removidos."""
        count = 0
        for subdir in self.cache_dir.iterdir():
            if subdir.is_dir():
                for cache_file in subdir.glob("*.json"):
                    cache_file.unlink()
                    count += 1
                subdir.rmdir()
        return count
    
    def stats(self) -> dict[str, Any]:
        """Retorna estatísticas do cache."""
        total_files = 0
        total_size = 0
        
        for subdir in self.cache_dir.iterdir():
            if subdir.is_dir():
                for cache_file in subdir.glob("*.json"):
                    total_files += 1
                    total_size += cache_file.stat().st_size
        
        return {
            "cache_dir": str(self.cache_dir),
            "total_files": total_files,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "ttl_hours": self.ttl_seconds / 3600
        }
