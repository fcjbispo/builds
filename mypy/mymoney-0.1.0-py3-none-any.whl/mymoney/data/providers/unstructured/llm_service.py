"""
LLM Service corrigido com timeout efetivo e tratamento de erros robusto.

Este módulo substitui o OpenAILLMService do fbpyutils_ai com correções para:
1. Timeout efetivo na camada HTTP (socket, connect, read)
2. Tratamento correto de streaming
3. Melhor tratamento de erros e retry
"""

from __future__ import annotations

import json
import os
import socket
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

import httpx
from openai import OpenAI, APIError, APITimeoutError, APIConnectionError

from mymoney import logger


@dataclass(frozen=True)
class LLMServiceModel:
    """Configuration for an LLM model."""
    provider: str
    api_base_url: str
    api_key: str
    model_id: str


class TimeoutOpenAILLMService:
    """
    LLM Service com timeout efetivo e tratamento de erros robusto.

    Substitui o OpenAILLMService do fbpyutils_ai com correções para:
    - Timeout em todas as camadas HTTP (connect, read, write)
    - Tratamento de streaming que pode travar
    - Retry com backoff exponencial
    """

    def __init__(
        self,
        base_model: LLMServiceModel,
        embed_model: Optional[LLMServiceModel] = None,
        vision_model: Optional[LLMServiceModel] = None,
        timeout: int = 300,
        retries: int = 3,
    ):
        """
        Initialize the LLM service.

        Args:
            base_model: Configuration for the base text model
            embed_model: Configuration for the embedding model
            vision_model: Configuration for the vision model
            timeout: Timeout in seconds for HTTP operations
            retries: Number of retries for failed requests
        """
        self.base_model = base_model
        self.embed_model = embed_model or base_model
        self.vision_model = vision_model or base_model
        self.timeout = timeout
        self.retries = retries

        # Create HTTP client with proper timeout settings
        self._clients: dict[str, OpenAI] = {}
        self._init_clients()

    def _init_clients(self) -> None:
        """Initialize OpenAI clients with proper timeout configuration."""
        for name, model_config in [
            ("base", self.base_model),
            ("embed", self.embed_model),
            ("vision", self.vision_model),
        ]:
            if model_config:
                # Create httpx client with proper timeout
                # Timeout breakdown:
                # - connect: time to establish connection
                # - read: time to wait for response headers
                # - write: time to send request
                timeout_config = httpx.Timeout(
                    connect=min(30, self.timeout),  # Max 30s to connect
                    read=self.timeout,  # Max timeout for reading response
                    write=min(30, self.timeout),  # Max 30s to send
                    pool=None,  # No pool timeout
                )

                # Create HTTP client with limits and timeout
                http_client = httpx.Client(
                    timeout=timeout_config,
                    limits=httpx.Limits(
                        max_connections=10,
                        max_keepalive_connections=5,
                    ),
                )

                # Create OpenAI client with custom HTTP client
                client = OpenAI(
                    api_key=model_config.api_key or "no-key",
                    base_url=model_config.api_base_url,
                    http_client=http_client,
                    # Disable streaming by default to avoid issues
                    max_retries=0,  # We handle retries ourselves
                )

                self._clients[name] = client

    def _get_client(self, model_type: str = "base") -> OpenAI:
        """Get the appropriate client for the model type."""
        if model_type not in self._clients:
            raise ValueError(f"No client configured for model type: {model_type}")
        return self._clients[model_type]

    def _get_model_id(self, model_type: str = "base") -> str:
        """Get the model ID for the specified type."""
        if model_type == "base":
            return self.base_model.model_id
        elif model_type == "embed":
            return self.embed_model.model_id
        elif model_type == "vision":
            return self.vision_model.model_id
        else:
            raise ValueError(f"Unknown model type: {model_type}")

    def _make_request_with_retry(
        self,
        operation: Callable[[], Any],
        operation_name: str = "LLM request",
    ) -> Any:
        """
        Execute an operation with retry logic and proper timeout handling.

        Args:
            operation: Callable that performs the request
            operation_name: Name of the operation for logging

        Returns:
            Result of the operation

        Raises:
            TimeoutError: If all retries exhausted due to timeout
            APIError: If there's an API error
        """
        last_error = None

        for attempt in range(1, self.retries + 1):
            try:
                logger.debug(f"{operation_name} - attempt {attempt}/{self.retries}")

                # Execute the operation
                result = operation()

                logger.debug(f"{operation_name} - success on attempt {attempt}")
                return result

            except APITimeoutError as e:
                last_error = e
                logger.warning(
                    f"{operation_name} - timeout on attempt {attempt}/{self.retries}: {e}"
                )
                if attempt < self.retries:
                    # Exponential backoff: 1s, 2s, 4s, etc.
                    wait_time = min(2 ** (attempt - 1), 30)
                    logger.info(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)

            except APIConnectionError as e:
                last_error = e
                logger.warning(
                    f"{operation_name} - connection error on attempt {attempt}/{self.retries}: {e}"
                )
                if attempt < self.retries:
                    wait_time = min(2 ** (attempt - 1), 30)
                    logger.info(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)

            except APIError as e:
                # API errors are usually not retryable
                logger.error(f"{operation_name} - API error: {e}")
                raise

            except Exception as e:
                last_error = e
                logger.warning(
                    f"{operation_name} - unexpected error on attempt {attempt}/{self.retries}: {e}"
                )
                if attempt < self.retries:
                    wait_time = min(2 ** (attempt - 1), 30)
                    logger.info(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)

        # All retries exhausted
        error_msg = f"{operation_name} failed after {self.retries} attempts. Last error: {last_error}"
        logger.error(error_msg)
        raise TimeoutError(error_msg) from last_error

    def generate_completions(
        self,
        messages: list[dict[str, Any]],
        temperature: float = 0.0,
        max_tokens: int = 8192,
        top_p: float = 1.0,
        model_type: str = "base",
    ) -> Any:
        """
        Generate completions using the specified model.

        Args:
            messages: List of message dictionaries with 'role' and 'content'
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            top_p: Nucleus sampling parameter
            model_type: Type of model to use (base, embed, vision)

        Returns:
            Response from the LLM
        """
        client = self._get_client(model_type)
        model_id = self._get_model_id(model_type)

        def _do_request():
            # Use non-streaming mode to avoid issues
            response = client.chat.completions.create(
                model=model_id,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
                stream=False,  # Force non-streaming
            )
            return response

        return self._make_request_with_retry(
            _do_request,
            f"generate_completions(model={model_id})",
        )

    def generate_embedding(
        self,
        text: str,
        model_type: str = "embed",
    ) -> list[float]:
        """
        Generate embedding for the given text.

        Args:
            text: Text to embed
            model_type: Type of model to use (usually 'embed')

        Returns:
            List of float values representing the embedding
        """
        client = self._get_client(model_type)
        model_id = self._get_model_id(model_type)

        def _do_request():
            response = client.embeddings.create(
                model=model_id,
                input=text,
            )
            return response.data[0].embedding

        return self._make_request_with_retry(
            _do_request,
            f"generate_embedding(model={model_id})",
        )

    def describe_image(
        self,
        image_base64: str,
        prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        model_type: str = "vision",
    ) -> Any:
        """
        Describe an image using the vision model.

        Args:
            image_base64: Base64-encoded image string
            prompt: Prompt for image description
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            model_type: Type of model to use (usually 'vision')

        Returns:
            Response from the vision model
        """
        client = self._get_client(model_type)
        model_id = self._get_model_id(model_type)

        # Build messages with image
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": image_base64},
                    },
                ],
            }
        ]

        def _do_request():
            response = client.chat.completions.create(
                model=model_id,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=False,  # Force non-streaming
            )
            return response

        return self._make_request_with_retry(
            _do_request,
            f"describe_image(model={model_id})",
        )


def create_llm_service_from_config(
    llm_config: Any,
) -> TimeoutOpenAILLMService:
    """
    Factory function to create a TimeoutOpenAILLMService from config.

    Args:
        llm_config: UnstructuredLLMConfig object or dict with provider settings

    Returns:
        Configured TimeoutOpenAILLMService instance
    """
    # Handle both dataclass and dict configs
    if hasattr(llm_config, 'provider'):
        # It's a dataclass
        base_model = LLMServiceModel(
            provider=llm_config.provider,
            api_base_url=llm_config.api_base_url,
            api_key=llm_config.api_key,
            model_id=llm_config.base_model,
        )
        embed_model = LLMServiceModel(
            provider=llm_config.provider,
            api_base_url=llm_config.api_base_url,
            api_key=llm_config.api_key,
            model_id=llm_config.embed_model,
        )
        vision_model = LLMServiceModel(
            provider=llm_config.provider,
            api_base_url=llm_config.api_base_url,
            api_key=llm_config.api_key,
            model_id=llm_config.vision_model,
        )
        timeout = getattr(llm_config, 'timeout', 300)
        retries = getattr(llm_config, 'retries', 3)
    else:
        # It's a dict
        base_model = LLMServiceModel(
            provider=llm_config.get('provider', 'ollama'),
            api_base_url=llm_config.get('api_base_url', 'http://localhost:11434/v1'),
            api_key=llm_config.get('api_key', 'no-key'),
            model_id=llm_config.get('base_model', 'llama2'),
        )
        embed_model = LLMServiceModel(
            provider=llm_config.get('provider', 'ollama'),
            api_base_url=llm_config.get('api_base_url', 'http://localhost:11434/v1'),
            api_key=llm_config.get('api_key', 'no-key'),
            model_id=llm_config.get('embed_model', base_model.model_id),
        )
        vision_model = LLMServiceModel(
            provider=llm_config.get('provider', 'ollama'),
            api_base_url=llm_config.get('api_base_url', 'http://localhost:11434/v1'),
            api_key=llm_config.get('api_key', 'no-key'),
            model_id=llm_config.get('vision_model', base_model.model_id),
        )
        timeout = llm_config.get('timeout', 300)
        retries = llm_config.get('retries', 3)

    return TimeoutOpenAILLMService(
        base_model=base_model,
        embed_model=embed_model,
        vision_model=vision_model,
        timeout=timeout,
        retries=retries,
    )
