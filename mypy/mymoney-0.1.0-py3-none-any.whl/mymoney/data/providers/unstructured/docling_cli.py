"""Docling CLI wrapper as drop-in replacement for DoclingConverter.

This module provides a CLI-based alternative to fbpyutils_ai.document.DoclingConverter
that supports PDF password and other CLI-specific options.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from mymoney import logger


class DoclingCLIConverter:
    """CLI-based document converter using docling command-line tool.

    This class provides the same interface as DoclingConverter from fbpyutils_ai.document
    but uses the docling CLI directly, enabling support for PDF passwords and other
    CLI-specific options.

    Args:
        ocr: Enable OCR for image-based PDFs. Default: True.
        ocr_lang: Comma-separated OCR languages. Default: "pt,en".
        device: Device for inference (cpu/cuda/auto). Default: "auto".
        tables: Enable table extraction. Default: True.
        table_mode: Table extraction mode (fast/accurate). Default: "accurate".
        image_export_mode: Image handling mode. Default: "placeholder".
        pdf_password: Password for encrypted PDFs. Default: None.

    Example:
        converter = DoclingCLIConverter(pdf_password="secret123")
        markdown = converter.convert(
            source="/path/to/file.pdf",
            input_format="pdf",
            output_format="md"
        )
    """

    def __init__(
        self,
        *,
        ocr: bool = True,
        ocr_lang: str = "pt,en",
        device: str = "auto",
        tables: bool = True,
        table_mode: str = "accurate",
        image_export_mode: str = "placeholder",
        pdf_password: str | None = None,
    ) -> None:
        self.ocr = ocr
        self.ocr_lang = ocr_lang
        self.device = device
        self.tables = tables
        self.table_mode = table_mode
        self.image_export_mode = image_export_mode
        self.pdf_password = pdf_password

        # Verify docling CLI is available
        self._docling_cmd = shutil.which("docling")
        if not self._docling_cmd:
            raise RuntimeError(
                "docling CLI not found in PATH. "
                "Please install docling: pip install docling"
            )

    def convert(
        self,
        source: str,
        *,
        input_format: str | None = None,
        output_format: str = "md",
        ocr: bool | None = None,
        ocr_engine: str | None = None,
        table_mode: str | None = None,
        image_export_mode: str | None = None,
        force_image: bool = True,
        **kwargs: Any,
    ) -> str:
        """Convert a document to the specified output format.

        Args:
            source: Path to the input file.
            input_format: Input format (pdf, docx, etc.). Auto-detected from extension if None.
            output_format: Output format (md, html, etc.). Default: "md".
            ocr: Override OCR setting. Uses instance default if None.
            ocr_engine: OCR engine (ignored, kept for compatibility).
            table_mode: Override table mode. Uses instance default if None.
            image_export_mode: Override image export mode. Uses instance default if None.
            force_image: Include images in output (ignored, kept for compatibility).
            **kwargs: Additional arguments (pdf_password is extracted if provided).

        Returns:
            Converted document content as string.

        Raises:
            RuntimeError: If conversion fails.
            subprocess.CalledProcessError: If docling CLI returns non-zero exit code.
        """
        source_path = Path(source)
        if not source_path.exists():
            raise FileNotFoundError(f"Source file not found: {source}")

        # Auto-detect input format from extension if not provided
        fmt = (input_format or source_path.suffix.lstrip(".")).lower()
        if fmt not in ("pdf", "docx", "doc", "pptx", "html", "xlsx"):
            raise ValueError(f"Unsupported input format: {fmt}")

        # Build command arguments
        cmd = [self._docling_cmd]

        # Input/output format
        cmd.extend(["--from", fmt])
        cmd.extend(["--to", output_format])

        # OCR options
        use_ocr = ocr if ocr is not None else self.ocr
        if use_ocr:
            cmd.append("--ocr")
            if self.ocr_lang:
                cmd.extend(["--ocr-lang", self.ocr_lang])
        else:
            cmd.append("--no-ocr")

        # Device
        if self.device:
            cmd.extend(["--device", self.device])

        # Tables
        if self.tables:
            cmd.append("--tables")
            cmd.extend(["--table-mode", table_mode or self.table_mode])

        # Image export mode
        cmd.extend(["--image-export-mode", image_export_mode or self.image_export_mode])

        # PDF password (from kwargs or instance)
        pdf_password = kwargs.get("pdf_password") or self.pdf_password
        if pdf_password is not None:
            cmd.extend(["--pdf-password", pdf_password])

        # Create temporary output directory
        with tempfile.TemporaryDirectory(prefix="docling_cli_") as tmpdir:
            output_dir = Path(tmpdir)
            cmd.extend(["--output", str(output_dir)])
            cmd.append(str(source_path))

            logger.debug(f"Running docling CLI: {' '.join(cmd)}")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    check=True,
                )
                logger.debug(f"docling stdout: {result.stdout}")
                if result.stderr:
                    logger.debug(f"docling stderr: {result.stderr}")
            except subprocess.CalledProcessError as exc:
                logger.error(f"docling conversion failed: {exc.stderr}")
                raise RuntimeError(
                    f"docling conversion failed for {source}: {exc.stderr}"
                ) from exc

            # Find output file
            base_name = source_path.stem
            output_file = output_dir / f"{base_name}.{output_format}"

            if not output_file.exists():
                # Try to find any .md file in output directory
                output_files = list(output_dir.glob(f"*.{output_format}"))
                if output_files:
                    output_file = output_files[0]
                else:
                    raise RuntimeError(
                        f"docling did not produce expected output file: {output_file}"
                    )

            # Read and return content
            with open(output_file, "r", encoding="utf-8") as f:
                content = f.read()

            logger.info(
                f"Converted {source} ({len(content)} chars) using docling CLI"
            )
            return content

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"ocr={self.ocr}, "
            f"ocr_lang='{self.ocr_lang}', "
            f"device='{self.device}', "
            f"tables={self.tables}, "
            f"table_mode='{self.table_mode}', "
            f"pdf_password={'***' if self.pdf_password else None}"
            f")"
        )
