from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from dataclasses import dataclass
from typing import Any, Callable, Optional

from jsonschema import validate
from jsonschema.exceptions import ValidationError

from fbpyutils_ai.base import LLMServiceModel
from fbpyutils_ai.llm import LLM_PROVIDERS

import base64
import io

from mymoney import env, logger
from mymoney.data.providers.pdf import prepare_pdf_source
from mymoney.data.providers.unstructured.cache import LLMCache
from mymoney.data.providers.unstructured.docling_cli import DoclingCLIConverter
from mymoney.data.providers.unstructured.llm_service import (
    TimeoutOpenAILLMService,
    create_llm_service_from_config,
)


def _pdf_pages_to_base64_images(file_path: str, max_pages: int = 5) -> list[str]:
    """Convert PDF pages to base64-encoded PNG images for vision model.

    Args:
        file_path: Path to PDF file
        max_pages: Maximum number of pages to convert (default 5)

    Returns:
        List of base64-encoded image strings
    """
    try:
        from pypdf import PdfReader
        from PIL import Image
        import fitz  # PyMuPDF
    except ImportError:
        logger.warning("PyMuPDF (fitz) or PIL not available for PDF to image conversion")
        return []

    images = []
    try:
        # Open PDF with PyMuPDF
        doc = fitz.open(file_path)
        page_count = min(len(doc), max_pages)

        for page_num in range(page_count):
            page = doc[page_num]
            # Render page to image at 150 DPI
            mat = fitz.Matrix(1.5, 1.5)  # 150 DPI
            pix = page.get_pixmap(matrix=mat)

            # Convert to PIL Image
            img_data = pix.tobytes("png")
            img = Image.open(io.BytesIO(img_data))

            # Convert to base64
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            img_base64 = base64.b64encode(buffered.getvalue()).decode()
            images.append(f"data:image/png;base64,{img_base64}")

        doc.close()
        logger.info(f"Converted PDF to {len(images)} images for vision extraction")
        return images
    except Exception as e:
        logger.error(f"Failed to convert PDF to images: {e}")
        return []


# Timeout in seconds for docling conversion (default: 5 minutes)
DOCLING_TIMEOUT_SECONDS = int(os.environ.get("DOCLING_TIMEOUT_SECONDS", "300"))


def _convert_with_timeout(converter: DoclingCLIConverter, convert_params: dict) -> str:
    """Run docling conversion with timeout protection."""
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(converter.convert, **convert_params)
        try:
            return future.result(timeout=DOCLING_TIMEOUT_SECONDS)
        except FutureTimeoutError:
            logger.error(
                f"Docling conversion timed out after {DOCLING_TIMEOUT_SECONDS}s: "
                f"source={convert_params.get('source')}"
            )
            raise TimeoutError(
                f"Docling conversion timed out after {DOCLING_TIMEOUT_SECONDS} seconds"
            ) from None


def load_text_file(path: str) -> str:
    if not path:
        raise ValueError("path must be provided")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Text file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def load_json_file(path: str) -> dict[str, Any]:
    if not path:
        raise ValueError("path must be provided")
    if not os.path.exists(path):
        raise FileNotFoundError(f"JSON file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        loaded = json.load(f)
    if not isinstance(loaded, dict):
        raise ValueError(f"Invalid JSON structure for file: {path}")
    return loaded


@dataclass(frozen=True)
class UnstructuredLLMConfig:
    provider: str
    api_base_url: str
    api_key: str
    base_model: str
    vision_model: str
    embed_model: str
    timeout: int
    retries: int


def _to_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _resolve_provider(provider: str) -> dict[str, Any]:
    providers = LLM_PROVIDERS if isinstance(LLM_PROVIDERS, dict) else {}
    direct = providers.get(provider)
    if direct:
        return direct
    for key, value in providers.items():
        if str(key).lower() == str(provider).lower():
            return value
    raise ValueError(f"Unsupported LLM provider: {provider}")


def _normalize_api_base_url(provider: str, api_base_url: str) -> str:
    url = str(api_base_url or "").strip()
    if not url:
        return url

    if str(provider).lower() == "ollama":
        normalized = url.rstrip("/")
        if not normalized.endswith("/v1"):
            normalized = f"{normalized}/v1"
        return normalized

    return url


def resolve_llm_config_from_user_settings(
    overrides: Optional[dict[str, Any]] = None,
) -> UnstructuredLLMConfig:
    cfg = dict(env.USER_CONFIG or {})
    cfg.update(overrides or {})

    provider = str(cfg.get("llm_provider") or cfg.get("LLM_PROVIDER") or "ollama")
    provider_cfg = _resolve_provider(provider)
    provider_upper = str(provider).upper().replace("-", "_")

    provider_env_api_key = provider_cfg.get("env_api_key") or "NEEDS_NO_KEY"
    default_api_key = (
        "NEEDS_NO_KEY"
        if str(provider_env_api_key).upper() == "NEEDS_NO_KEY"
        else os.getenv(str(provider_env_api_key), "")
    )

    api_base_url = (
        cfg.get("llm_api_base_url")
        or cfg.get("LLM_API_BASE_URL")
        or cfg.get(f"{provider_upper}_API_BASE_URL")
        or os.getenv(f"{provider_upper}_API_BASE_URL")
        or provider_cfg.get("base_url")
    )
    api_key = (
        cfg.get("llm_api_key")
        or cfg.get("LLM_API_KEY")
        or cfg.get(f"{provider_upper}_API_KEY")
        or os.getenv(f"{provider_upper}_API_KEY")
        or default_api_key
        or "NEEDS_NO_KEY"
    )

    base_model = cfg.get("llm_base_model") or cfg.get("LLM_BASE_MODEL")
    if not base_model:
        raise ValueError("LLM_BASE_MODEL is required for unstructured extraction.")

    vision_model = (
        cfg.get("llm_vision_model")
        or cfg.get("LLM_VISION_MODEL")
        or base_model
    )
    embed_model = (
        cfg.get("llm_embed_model")
        or cfg.get("LLM_EMBED_MODEL")
        or base_model
    )

    api_base_url = _normalize_api_base_url(provider, str(api_base_url))

    return UnstructuredLLMConfig(
        provider=provider,
        api_base_url=api_base_url,
        api_key=str(api_key),
        base_model=str(base_model),
        vision_model=str(vision_model),
        embed_model=str(embed_model),
        timeout=_to_int(cfg.get("llm_timeout") or cfg.get("LLM_TIMEOUT"), 300),
        retries=_to_int(cfg.get("llm_retries") or cfg.get("LLM_RETRIES"), 3),
    )


def _extract_response_content(response: Any) -> str:
    if response is None:
        return ""

    # OpenAI SDK object
    try:
        choices = getattr(response, "choices", None)
        if choices and len(choices) > 0:
            message = getattr(choices[0], "message", None)
            if message is not None:
                content = getattr(message, "content", None)
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    parts = []
                    for item in content:
                        if isinstance(item, dict):
                            text = item.get("text")
                            if text:
                                parts.append(str(text))
                    return "\n".join(parts)
    except Exception:
        pass

    if isinstance(response, dict):
        try:
            return (
                response.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
        except Exception:
            return json.dumps(response, ensure_ascii=False, default=str)

    return str(response)


def _extract_json_payload(raw_content: str) -> dict[str, Any]:
    if not raw_content:
        raise ValueError("LLM returned empty content.")

    content = raw_content.strip()
    if content.startswith("```"):
        content = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", content)
        content = re.sub(r"\s*```$", "", content)
        content = content.strip()

    # Try parsing directly first
    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("LLM response JSON must be an object.")
        return parsed
    except Exception:
        pass

    # Try extracting JSON object from fragment
    first_obj = content.find("{")
    last_obj = content.rfind("}")
    if first_obj >= 0 and last_obj > first_obj:
        fragment = content[first_obj : last_obj + 1]
        try:
            parsed = json.loads(fragment)
            if not isinstance(parsed, dict):
                raise ValueError("LLM response JSON fragment must be an object.")
            return parsed
        except json.JSONDecodeError:
            # Try to fix common JSON errors
            fixed_fragment = _attempt_json_repair(fragment)
            try:
                parsed = json.loads(fixed_fragment)
                if isinstance(parsed, dict):
                    logger.debug("Successfully repaired malformed JSON")
                    return parsed
            except json.JSONDecodeError:
                pass

    raise ValueError("Could not parse JSON object from LLM response.")


def _attempt_json_repair(content: str) -> str:
    """Attempt to repair common JSON malformations from LLM output.

    Fixes applied:
    1. Remove trailing commas before } or ]
    2. Add missing closing braces/brackets
    3. Fix unescaped quotes in strings
    """
    # Remove trailing commas before closing brackets
    content = re.sub(r",(\s*[}\]])", r"\1", content)

    # Balance braces and brackets
    open_braces = content.count("{") - content.count("}")
    open_brackets = content.count("[") - content.count("]")

    if open_braces > 0:
        content += "}" * open_braces
    if open_brackets > 0:
        content += "]" * open_brackets

    # Try to complete truncated lancamentos array
    last_lancamento = content.rfind('"valor_operacao"')
    if last_lancamento > 0:
        # Check if we're in the middle of a lancamento object
        search_start = max(0, last_lancamento - 500)
        recent_content = content[search_start:last_lancamento]
        open_braces_in_recent = recent_content.count("{") - recent_content.count("}")

        if open_braces_in_recent > 0:
            # We're inside an incomplete object, try to close it
            content = content.rstrip()
            if not content.endswith("}"):
                # Find the last complete property
                last_comma = content.rfind(",")
                last_prop = content.rfind('"')
                if last_prop > last_comma:
                    # Likely truncated in a property value
                    content = content[:content.rfind("{", last_comma) + 1]
                    content = content.rstrip() + "}"

    return content


def _coerce_schema_like_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Coerce accidental schema-like LLM output to expected payload structure.

    Some models may return an object that mirrors JSON Schema keys
    (`properties`, `required`, `type`) with extracted data in `default`
    values and `properties.lancamentos.items`.
    """
    if not isinstance(payload, dict):
        return payload
    if isinstance(payload.get("lancamentos"), list):
        return payload

    properties = payload.get("properties")
    if not isinstance(properties, dict):
        return payload

    lancamentos_node = properties.get("lancamentos")
    if not isinstance(lancamentos_node, dict):
        return payload
    lancamentos_items = lancamentos_node.get("items")
    if not isinstance(lancamentos_items, list):
        return payload

    account_properties = (properties.get("account") or {}).get("properties", {})
    period_properties = (properties.get("period") or {}).get("properties", {})

    if not isinstance(account_properties, dict):
        account_properties = {}
    if not isinstance(period_properties, dict):
        period_properties = {}

    def _default_from(node: Any, fallback: Any = None) -> Any:
        if isinstance(node, dict) and "default" in node:
            return node.get("default")
        return fallback

    return {
        "account": {
            "institution": _default_from(account_properties.get("institution")),
            "account_id": _default_from(account_properties.get("account_id")),
            "account_number": _default_from(account_properties.get("account_number")),
            "currency": _default_from(account_properties.get("currency"), "BRL"),
        },
        "period": {
            "start_date": _default_from(period_properties.get("start_date")),
            "end_date": _default_from(period_properties.get("end_date")),
        },
        "lancamentos": lancamentos_items,
    }


def _run_audit_callback(
    payload: dict[str, Any],
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
) -> tuple[bool, Optional[str]]:
    if audit_callback is None:
        return True, None

    result = audit_callback(payload)
    if result is None:
        return True, None
    if isinstance(result, bool):
        return result, None if result else "Audit callback returned False."
    if isinstance(result, tuple) and len(result) >= 1:
        is_valid = bool(result[0])
        message = None
        if len(result) > 1 and result[1] is not None:
            message = str(result[1])
        if not is_valid and not message:
            message = "Audit callback returned invalid tuple result."
        return is_valid, message

    raise ValueError(
        "Invalid audit callback return type. Expected bool, tuple(bool, msg), or None."
    )


def _chunk_markdown_by_size(
    markdown: str,
    max_tokens: int = 10000,
    chars_per_token: int = 4,
) -> list[str]:
    """
    Split large markdown into chunks at table row boundaries.

    Args:
        markdown: The full markdown source
        max_tokens: Maximum tokens per chunk (estimated)
        chars_per_token: Character-to-token ratio for estimation

    Returns:
        List of markdown chunks, each under the token limit
    """
    max_chars = max_tokens * chars_per_token

    if len(markdown) <= max_chars:
        return [markdown]

    chunks = []
    current_pos = 0

    while current_pos < len(markdown):
        remaining = markdown[current_pos:]

        if len(remaining) <= max_chars:
            chunks.append(remaining)
            break

        segment = remaining[:max_chars]

        last_pipe_pos = segment.rfind("\n|")
        if last_pipe_pos > 0:
            chunk_end = current_pos + last_pipe_pos + 1
            chunks.append(markdown[current_pos:chunk_end])
            current_pos = chunk_end
            continue

        last_newline_pos = segment.rfind("\n")
        if last_newline_pos > 0:
            chunk_end = current_pos + last_newline_pos + 1
            chunks.append(markdown[current_pos:chunk_end])
            current_pos = chunk_end
            continue

        chunks.append(segment)
        current_pos += max_chars

    logger.info(
        "Chunked markdown: %d chunks, avg chars=%d",
        len(chunks),
        sum(len(c) for c in chunks) // len(chunks) if chunks else 0,
    )

    return chunks


def _deduplicate_lancamentos(lancamentos: list[dict]) -> list[dict]:
    """
    Remove duplicate lancamentos using composite key hash.

    Dedup key: hash(data_movimentacao + movimentacao + valor_operacao)

    Args:
        lancamentos: List of lancamento dicts

    Returns:
        Deduplicated list preserving first occurrence order
    """
    seen_hashes: set[str] = set()
    unique: list[dict] = []

    for lanc in lancamentos:
        if not isinstance(lanc, dict):
            continue

        data_mov = str(lanc.get("data_movimentacao", ""))
        movimentacao = str(lanc.get("movimentacao", ""))
        valor = str(lanc.get("valor_operacao", ""))

        composite_key = f"{data_mov}|{movimentacao}|{valor}"
        hash_key = hashlib.sha256(composite_key.encode("utf-8")).hexdigest()

        if hash_key not in seen_hashes:
            seen_hashes.add(hash_key)
            unique.append(lanc)

    logger.info(
        "Deduplicated lancamentos: %d -> %d (removed %d duplicates)",
        len(lancamentos),
        len(unique),
        len(lancamentos) - len(unique),
    )

    return unique


def _consolidate_chunk_results(
    results: list[dict[str, Any]],
) -> dict[str, Any]:
    """
    Consolidate results from multiple chunk extractions.

    Merges lancamentos lists and deduplicates.
    Preserves account/period metadata from first chunk with data.

    Args:
        results: List of payload dicts from each chunk

    Returns:
        Consolidated payload dict
    """
    all_lancamentos: list[dict] = []
    account_info: Optional[dict] = None
    period_info: Optional[dict] = None

    for result in results:
        if not isinstance(result, dict):
            continue

        lances = result.get("lancamentos", [])
        if isinstance(lances, list):
            all_lancamentos.extend(lances)

        if account_info is None and "account" in result:
            account_info = result["account"]

        if period_info is None and "period" in result:
            period_info = result["period"]

    deduped = _deduplicate_lancamentos(all_lancamentos)

    consolidated: dict[str, Any] = {"lancamentos": deduped}
    if account_info:
        consolidated["account"] = account_info
    if period_info:
        consolidated["period"] = period_info

    return consolidated


class UnstructuredExtractionEngine:
    """
    Generic unstructured extraction workflow.

    Pipeline:
    1) Source file -> markdown via DoclingConverter
    2) markdown -> structured JSON via OpenAI-compatible LLM
    3) mandatory JSON Schema validation + optional domain audit + retries
    """

    def __init__(
        self,
        llm_config: Optional[UnstructuredLLMConfig] = None,
        *,
        converter: Optional[DoclingCLIConverter] = None,
        llm_service: Optional[TimeoutOpenAILLMService] = None,
        use_cache: bool = True,
        cache_ttl_hours: int = 168,
    ) -> None:
        self.llm_config = llm_config or resolve_llm_config_from_user_settings()
        self.converter = converter or DoclingCLIConverter()
        self.use_cache = use_cache
        self.cache = LLMCache(ttl_hours=cache_ttl_hours) if use_cache else None

        if llm_service is not None:
            self.llm_service = llm_service
        else:
            self.llm_service = create_llm_service_from_config(self.llm_config)

    def source_to_markdown(
        self,
        source_file: str,
        *,
        input_format: str = "pdf",
        ocr: bool = True,
        ocr_engine: str = "easyocr",
        table_mode: str = "accurate",
        image_export_mode: str = "placeholder",
        force_image: bool = True,
        pdf_password: str | None = None,
        pdf_password_required: bool = False,
    ) -> str:
        with prepare_pdf_source(
            source_file,
            password=pdf_password,
            password_required=pdf_password_required,
            context_label=source_file,
        ) as readable_source:
            convert_params = {
                "source": readable_source,
                "input_format": input_format,
                "output_format": "md",
                "ocr": ocr,
                "ocr_engine": ocr_engine,
                "table_mode": table_mode,
                "image_export_mode": image_export_mode,
                "force_image": force_image,
            }
            logger.info(
                "Converting source to markdown: source_file=%s input_format=%s ocr=%s ocr_engine=%s table_mode=%s",
                source_file,
                input_format,
                ocr,
                ocr_engine,
                table_mode,
            )
            try:
                markdown = _convert_with_timeout(self.converter, convert_params)
                logger.info(
                    "Markdown conversion finished: source_file=%s chars=%s",
                    source_file,
                    len(markdown or ""),
                )
                return markdown
            except TimeoutError as exc:
                logger.error(
                    f"Docling conversion timed out: source={source_file}, error={exc}"
                )
                raise
            except Exception as exc:
                should_retry_without_ocr = bool(
                    ocr and (
                        isinstance(exc, subprocess.CalledProcessError)
                        or isinstance(exc, TimeoutError)
                        or "easyocr" in str(exc).lower()
                        or "docling" in str(exc).lower()
                        or "returned non-zero exit status" in str(exc).lower()
                        or "no md file found" in str(exc).lower()
                    )
                )
                if not should_retry_without_ocr:
                    raise

                logger.warning(
                    "Docling conversion with OCR failed; retrying without OCR "
                    f"(source={source_file}, error={exc})."
                )
                fallback_params = dict(convert_params)
                fallback_params["ocr"] = False
                fallback_params["force_image"] = False
                markdown = _convert_with_timeout(self.converter, fallback_params)
                logger.info(
                    "Markdown conversion finished without OCR: source_file=%s chars=%s",
                    source_file,
                    len(markdown or ""),
                )
                return markdown

    def extract_structured_data(
        self,
        *,
        markdown_source: Optional[str] = None,
        system_prompt: str,
        user_prompt_template: str,
        json_schema: dict[str, Any],
        max_attempts: int = 3,
        retry_delay_seconds: int = 0,
        temperature: float = 0.0,
        max_tokens: int = 8192,
        audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
        chunking_enabled: bool = True,
        chunk_max_tokens: int = 10000,
        pdf_source_path: Optional[str] = None,
        use_vision_fallback: bool = False,
        use_native_pdf: bool = False,
    ) -> dict[str, Any]:
        if max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        if retry_delay_seconds < 0:
            raise ValueError("retry_delay_seconds must be >= 0")
        if not isinstance(json_schema, dict) or not json_schema:
            raise ValueError("json_schema is required and must be a non-empty dict.")

        # Validate source parameters
        if use_native_pdf and not pdf_source_path:
            raise ValueError("pdf_source_path is required when use_native_pdf=True")
        if not use_native_pdf and not markdown_source:
            raise ValueError("markdown_source is required when use_native_pdf=False")

        # Use native PDF extraction when requested and PDF path is available
        if use_native_pdf and pdf_source_path and os.path.exists(pdf_source_path):
            return self._extract_with_native_pdf(
                pdf_path=pdf_source_path,
                system_prompt=system_prompt,
                user_prompt_template=user_prompt_template,
                json_schema=json_schema,
                max_attempts=max_attempts,
                retry_delay_seconds=retry_delay_seconds,
                temperature=temperature,
                max_tokens=max_tokens,
                audit_callback=audit_callback,
            )

        schema_json = json.dumps(json_schema, ensure_ascii=False, indent=2, default=str)

        # Estimate token count: ~4 chars per token for typical text
        estimated_tokens = len(markdown_source or "") // 4

        # Use chunking for large documents that exceed model context
        use_chunking = (
            chunking_enabled
            and estimated_tokens > (chunk_max_tokens * 0.8)  # 80% threshold
        )

        if use_chunking:
            logger.info(
                "Document too large (%d est. tokens), using chunking: chunk_max_tokens=%d",
                estimated_tokens,
                chunk_max_tokens,
            )
            return self._extract_with_chunking(
                markdown_source=markdown_source,
                system_prompt=system_prompt,
                user_prompt_template=user_prompt_template,
                json_schema=json_schema,
                schema_json=schema_json,
                max_attempts=max_attempts,
                retry_delay_seconds=retry_delay_seconds,
                temperature=temperature,
                max_tokens=max_tokens,
                audit_callback=audit_callback,
                chunk_max_tokens=chunk_max_tokens,
            )

        # Standard single-pass extraction for small documents
        user_prompt = (
            user_prompt_template.replace("__JSON_SCHEMA__", schema_json).replace(
                "__MARKDOWN_SOURCE__", markdown_source or ""
            )
        )

        # Verificar cache antes de chamar LLM
        if self.use_cache and self.cache:
            cached_result = self.cache.get(system_prompt, user_prompt)
            if cached_result is not None:
                logger.info(f"Cache hit for extraction - skipping LLM call")
                try:
                    validate(instance=cached_result, schema=json_schema)
                    is_valid, audit_error = _run_audit_callback(cached_result, audit_callback)
                    if is_valid:
                        return cached_result
                    else:
                        logger.warning(f"Cached result failed audit: {audit_error}")
                except Exception as e:
                    logger.warning(f"Cached result failed validation: {e}")
                    # Continuar para chamar LLM

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        logger.info(
            "Starting LLM extraction: provider=%s base_model=%s vision_model=%s max_attempts=%s timeout=%s",
            self.llm_config.provider,
            self.llm_config.base_model,
            self.llm_config.vision_model,
            max_attempts,
            self.llm_config.timeout,
        )

        last_error = ""
        last_raw_content = ""
        for attempt in range(1, max_attempts + 1):
            logger.info("LLM extraction attempt %s/%s", attempt, max_attempts)
            try:
                response = self.llm_service.generate_completions(
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    top_p=1.0,
                )
                raw_content = _extract_response_content(response)
                last_raw_content = raw_content
                payload = _extract_json_payload(raw_content)
                payload = _coerce_schema_like_payload(payload)
                validate(instance=payload, schema=json_schema)
                is_valid, audit_error = _run_audit_callback(payload, audit_callback)
                if not is_valid:
                    raise ValueError(
                        f"Audit validation failed: {audit_error or 'unknown error'}"
                    )
                # Salvar no cache
                if self.use_cache and self.cache:
                    self.cache.set(system_prompt, user_prompt, payload)
                    logger.debug(f"Result cached for extraction")
                logger.info(
                    "LLM extraction succeeded on attempt %s with %s lancamentos",
                    attempt,
                    len(payload.get("lancamentos", []))
                    if isinstance(payload, dict)
                    else 0,
                )
                return payload
            except Exception as exc:
                last_error = str(exc)
                logger.warning(
                    f"Unstructured extraction attempt {attempt}/{max_attempts} failed: {exc}"
                )
                if attempt >= max_attempts:
                    break
                messages += [
                    {
                        "role": "assistant",
                        "content": last_raw_content or f"Erro na tentativa anterior: {last_error}",
                    },
                    {
                        "role": "user",
                        "content": (
                            "Gere novamente. Retorne somente um JSON válido e aderente ao schema. "
                            f"Erro anterior: {last_error}. "
                            f"Schema: {schema_json}"
                        ),
                    },
                ]
                if retry_delay_seconds > 0:
                    time.sleep(retry_delay_seconds)

        # Try vision fallback if text extraction failed and PDF source is available
        if use_vision_fallback and pdf_source_path and os.path.exists(pdf_source_path):
            logger.warning(
                f"Text extraction failed, attempting vision fallback for {pdf_source_path}"
            )
            try:
                return self._extract_with_vision(
                    pdf_path=pdf_source_path,
                    system_prompt=system_prompt,
                    user_prompt_template=user_prompt_template,
                    json_schema=json_schema,
                    max_attempts=max_attempts,
                    audit_callback=audit_callback,
                )
            except Exception as vision_exc:
                logger.error(f"Vision fallback also failed: {vision_exc}")
                last_error = f"{last_error}; Vision fallback: {vision_exc}"

        if "ValidationError" in last_error:
            raise ValidationError(last_error)
        raise ValueError(
            f"Could not extract structured data after {max_attempts} attempts: {last_error}"
        )

    def _extract_with_vision(
        self,
        pdf_path: str,
        system_prompt: str,
        user_prompt_template: str,
        json_schema: dict[str, Any],
        max_attempts: int = 3,
        audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    ) -> dict[str, Any]:
        """Extract structured data using vision model on PDF pages.

        Falls back to vision when text-based markdown extraction fails.
        Converts PDF pages to images and sends to vision model.
        """
        logger.info(f"Starting vision-based extraction for {pdf_path}")

        # Convert PDF pages to images
        images = _pdf_pages_to_base64_images(pdf_path, max_pages=5)
        if not images:
            raise ValueError("Could not convert PDF to images for vision extraction")

        schema_json = json.dumps(json_schema, ensure_ascii=False, indent=2, default=str)

        # Build vision prompt
        user_prompt = user_prompt_template.replace("__JSON_SCHEMA__", schema_json)
        user_prompt = user_prompt.replace(
            "__MARKDOWN_SOURCE__",
            "[Document provided as images below - extract all financial transactions]",
        )

        last_error = ""
        for attempt in range(1, max_attempts + 1):
            logger.info(f"Vision extraction attempt {attempt}/{max_attempts}")
            try:
                # Use the first image with describe_image
                # For multiple pages, we could iterate or use a different approach
                vision_prompt = f"""{system_prompt}

{user_prompt}

This is page 1 of a financial document. Extract all transactions and return valid JSON.

Document page image:"""

                response = self.llm_service.describe_image(
                    images[0],  # First page
                    prompt=vision_prompt,
                    max_tokens=4096,
                )

                # Extract content from vision response
                raw_content = _extract_response_content(response)
                payload = _extract_json_payload(raw_content)
                payload = _coerce_schema_like_payload(payload)
                validate(instance=payload, schema=json_schema)
                is_valid, audit_error = _run_audit_callback(payload, audit_callback)
                if not is_valid:
                    raise ValueError(
                        f"Audit validation failed: {audit_error or 'unknown error'}"
                    )

                logger.info(
                    f"Vision extraction succeeded with {len(payload.get('lancamentos', []))} lancamentos"
                )
                return payload
            except Exception as exc:
                last_error = str(exc)
                logger.warning(f"Vision extraction attempt {attempt} failed: {exc}")
                if attempt >= max_attempts:
                    break

        raise ValueError(f"Vision extraction failed after {max_attempts} attempts: {last_error}")

    def _extract_with_native_pdf(
        self,
        pdf_path: str,
        system_prompt: str,
        user_prompt_template: str,
        json_schema: dict[str, Any],
        max_attempts: int = 3,
        retry_delay_seconds: int = 0,
        temperature: float = 0.0,
        max_tokens: int = 8192,
        audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    ) -> dict[str, Any]:
        """Extract structured data using PDF converted to images via OpenAI-compatible API.

        Converts PDF pages to images and sends them to vision-capable models
        (e.g., GPT-4o, Claude 3.5 Sonnet, Qwen-VL, Gemma3) using standard OpenAI image_url format.

        Implements automatic pagination to avoid timeouts with large PDFs.
        Pages are processed in batches of 2 to balance context vs. performance.
        """
        import tempfile
        import shutil
        from pathlib import Path

        # Get PDF page count
        try:
            from pypdf import PdfReader
            reader = PdfReader(pdf_path)
            total_pages = len(reader.pages)
        except Exception as e:
            logger.warning(f"Could not determine PDF page count: {e}, assuming 1 page")
            total_pages = 1

        logger.info(f"Starting native PDF extraction for {pdf_path} ({total_pages} pages)")

        # Decide on pagination strategy
        # Process 2 pages at a time to balance context vs. performance
        pages_per_batch = 2

        if total_pages <= pages_per_batch:
            # Small PDF: process all at once
            return self._extract_single_native_pdf_batch(
                pdf_path=pdf_path,
                system_prompt=system_prompt,
                user_prompt_template=user_prompt_template,
                json_schema=json_schema,
                max_attempts=max_attempts,
                retry_delay_seconds=retry_delay_seconds,
                temperature=temperature,
                max_tokens=max_tokens,
                audit_callback=audit_callback,
            )

        # Large PDF: process in batches
        logger.info(f"PDF has {total_pages} pages, using batch processing ({pages_per_batch} pages/batch)")

        # Create temporary directory for batch processing
        with tempfile.TemporaryDirectory() as temp_dir:
            # Split PDF into batches
            batch_files = self._split_pdf_for_batch_processing(
                pdf_path, temp_dir, pages_per_batch
            )

            logger.info(f"Split PDF into {len(batch_files)} batches")

            # Process each batch
            batch_results: list[dict[str, Any]] = []
            for i, batch_file in enumerate(batch_files, 1):
                logger.info(f"Processing batch {i}/{len(batch_files)}: {Path(batch_file).name}")
                try:
                    batch_payload = self._extract_single_native_pdf_batch(
                        pdf_path=batch_file,
                        system_prompt=system_prompt,
                        user_prompt_template=user_prompt_template,
                        json_schema=json_schema,
                        max_attempts=max_attempts,
                        retry_delay_seconds=retry_delay_seconds,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        audit_callback=audit_callback,
                    )
                    batch_results.append(batch_payload)
                    logger.info(f"Batch {i} completed with {len(batch_payload.get('lancamentos', []))} lancamentos")
                except Exception as e:
                    logger.warning(f"Batch {i} failed: {e}")
                    # Continue with other batches

            if not batch_results:
                raise ValueError("All batches failed to extract data")

            # Consolidate results
            consolidated = self._consolidate_batch_results(batch_results)
            logger.info(
                f"Native PDF extraction completed: {total_pages} pages, "
                f"{len(consolidated.get('lancamentos', []))} total lancamentos"
            )
            return consolidated

    def _split_pdf_for_batch_processing(
        self,
        pdf_path: str,
        output_dir: str,
        pages_per_batch: int = 2,
    ) -> list[str]:
        """Split a PDF into smaller batches for processing.

        Args:
            pdf_path: Path to the input PDF
            output_dir: Directory to save batch files
            pages_per_batch: Number of pages per batch

        Returns:
            List of paths to batch PDF files
        """
        from pypdf import PdfReader, PdfWriter

        reader = PdfReader(pdf_path)
        total_pages = len(reader.pages)
        batch_files: list[str] = []

        num_batches = (total_pages + pages_per_batch - 1) // pages_per_batch

        for batch_idx in range(num_batches):
            start_page = batch_idx * pages_per_batch
            end_page = min((batch_idx + 1) * pages_per_batch, total_pages)

            writer = PdfWriter()
            for page_idx in range(start_page, end_page):
                writer.add_page(reader.pages[page_idx])

            batch_filename = f"batch_{batch_idx + 1:03d}.pdf"
            batch_path = os.path.join(output_dir, batch_filename)

            with open(batch_path, "wb") as f:
                writer.write(f)

            batch_files.append(batch_path)

        return batch_files

    def _consolidate_batch_results(
        self,
        batch_results: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Consolidate results from multiple batch extractions.

        Merges lancamentos lists and preserves account/period metadata from first batch.
        """
        all_lancamentos: list[dict] = []
        account_info: Optional[dict] = None
        period_info: Optional[dict] = None

        for result in batch_results:
            if not isinstance(result, dict):
                continue

            lances = result.get("lancamentos", [])
            if isinstance(lances, list):
                all_lancamentos.extend(lances)

            # Take first non-empty account/period
            if account_info is None and "account" in result:
                account_info = result["account"]
            if period_info is None and "period" in result:
                period_info = result["period"]

        # Deduplicate by composite key
        deduped = _deduplicate_lancamentos(all_lancamentos)

        consolidated: dict[str, Any] = {"lancamentos": deduped}
        if account_info:
            consolidated["account"] = account_info
        if period_info:
            consolidated["period"] = period_info

        return consolidated

    def _extract_single_native_pdf_batch(
        self,
        pdf_path: str,
        system_prompt: str,
        user_prompt_template: str,
        json_schema: dict[str, Any],
        max_attempts: int = 3,
        retry_delay_seconds: int = 0,
        temperature: float = 0.0,
        max_tokens: int = 8192,
        audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    ) -> dict[str, Any]:
        """Extract structured data from a single PDF batch (used by _extract_with_native_pdf)."""
        images = _pdf_pages_to_base64_images(pdf_path, max_pages=5)
        if not images:
            raise ValueError("Could not convert PDF to images for native extraction")

        schema_json = json.dumps(json_schema, ensure_ascii=False, indent=2, default=str)

        user_prompt = user_prompt_template.replace("__JSON_SCHEMA__", schema_json)
        user_prompt = user_prompt.replace(
            "__MARKDOWN_SOURCE__",
            f"[Document provided as {len(images)} image(s) below - extract all financial transactions]",
        )

        content: list[dict[str, Any]] = [{"type": "text", "text": user_prompt}]
        for img_base64 in images:
            content.append({
                "type": "image_url",
                "image_url": {"url": img_base64},
            })

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": content},
        ]

        last_error = ""
        for attempt in range(1, max_attempts + 1):
            try:
                response = self.llm_service.generate_completions(
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    top_p=1.0,
                    model_type="vision",
                )
                raw_content = _extract_response_content(response)
                payload = _extract_json_payload(raw_content)
                payload = _coerce_schema_like_payload(payload)
                validate(instance=payload, schema=json_schema)
                is_valid, audit_error = _run_audit_callback(payload, audit_callback)
                if not is_valid:
                    raise ValueError(f"Audit validation failed: {audit_error or 'unknown error'}")
                return payload
            except Exception as exc:
                last_error = str(exc)
                logger.warning(f"Native PDF batch extraction attempt {attempt}/{max_attempts} failed: {exc}")
                if attempt >= max_attempts:
                    break
                if retry_delay_seconds > 0:
                    time.sleep(retry_delay_seconds)

        raise ValueError(f"Native PDF batch extraction failed after {max_attempts} attempts: {last_error}")

    def _extract_with_chunking(
        self,
        *,
        markdown_source: str,
        system_prompt: str,
        user_prompt_template: str,
        json_schema: dict[str, Any],
        schema_json: str,
        max_attempts: int,
        retry_delay_seconds: int,
        temperature: float,
        max_tokens: int,
        audit_callback: Optional[Callable[[dict[str, Any]], Any]],
        chunk_max_tokens: int,
    ) -> dict[str, Any]:
        """
        Extract structured data using chunking for large documents.

        Each chunk is processed independently and results are consolidated.
        Cache is checked per-chunk to enable partial cache hits.
        """
        chunks = _chunk_markdown_by_size(
            markdown_source, max_tokens=chunk_max_tokens
        )

        chunk_results: list[dict[str, Any]] = []
        total_chunks = len(chunks)

        for i, chunk in enumerate(chunks, start=1):
            logger.info(
                "Processing chunk %d/%d (%d chars)",
                i,
                total_chunks,
                len(chunk),
            )

            user_prompt = (
                user_prompt_template.replace("__JSON_SCHEMA__", schema_json).replace(
                    "__MARKDOWN_SOURCE__", chunk
                )
            )

            # Check cache for this specific chunk
            cached_result = None
            if self.use_cache and self.cache:
                cached_result = self.cache.get(system_prompt, user_prompt)

            if cached_result is not None:
                logger.info(
                    f"Cache hit for chunk {i}/{total_chunks} - skipping LLM call"
                )
                try:
                    validate(instance=cached_result, schema=json_schema)
                    is_valid, _ = _run_audit_callback(cached_result, audit_callback)
                    if is_valid:
                        chunk_results.append(cached_result)
                        continue
                except Exception as e:
                    logger.warning(
                        f"Cached result for chunk {i} failed validation: {e}"
                    )

            # Process chunk with LLM
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]

            chunk_extracted = False
            last_chunk_error = ""
            last_chunk_raw = ""

            for attempt in range(1, max_attempts + 1):
                try:
                    logger.info(
                        "Chunk %d/%d attempt %s/%s",
                        i,
                        total_chunks,
                        attempt,
                        max_attempts,
                    )

                    response = self.llm_service.generate_completions(
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        top_p=1.0,
                    )
                    raw_content = _extract_response_content(response)
                    last_chunk_raw = raw_content
                    payload = _extract_json_payload(raw_content)
                    payload = _coerce_schema_like_payload(payload)
                    validate(instance=payload, schema=json_schema)
                    is_valid, audit_error = _run_audit_callback(
                        payload, audit_callback
                    )
                    if not is_valid:
                        raise ValueError(
                            f"Audit validation failed: {audit_error or 'unknown error'}"
                        )

                    # Cache successful chunk result
                    if self.use_cache and self.cache:
                        self.cache.set(system_prompt, user_prompt, payload)
                        logger.debug(f"Chunk {i} result cached")

                    chunk_results.append(payload)
                    chunk_extracted = True
                    logger.info(
                        "Chunk %d/%d succeeded with %s lancamentos",
                        i,
                        total_chunks,
                        len(payload.get("lancamentos", [])),
                    )
                    break

                except Exception as exc:
                    last_chunk_error = str(exc)
                    logger.warning(
                        f"Chunk {i}/{total_chunks} attempt {attempt}/{max_attempts} failed: {exc}"
                    )

                    if attempt >= max_attempts:
                        break

                    messages += [
                        {
                            "role": "assistant",
                            "content": last_chunk_raw
                            or f"Erro na tentativa anterior: {last_chunk_error}",
                        },
                        {
                            "role": "user",
                            "content": (
                                "Gere novamente. Retorne somente um JSON válido e aderente ao schema. "
                                f"Erro anterior: {last_chunk_error}. "
                                f"Schema: {schema_json}"
                            ),
                        },
                    ]

                    if retry_delay_seconds > 0:
                        time.sleep(retry_delay_seconds)

            if not chunk_extracted:
                logger.error(
                    f"Failed to extract chunk {i}/{total_chunks} after {max_attempts} attempts: {last_chunk_error}"
                )

        if not chunk_results:
            raise ValueError(
                f"Could not extract any chunks after processing {total_chunks} chunks"
            )

        # Consolidate all chunk results
        consolidated = _consolidate_chunk_results(chunk_results)

        logger.info(
            "Chunking complete: consolidated %d chunks into %d total lancamentos",
            len(chunk_results),
            len(consolidated.get("lancamentos", [])),
        )

        return consolidated
