from __future__ import annotations

from typing import Any, Optional


def _to_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    text = text.replace(" ", "").replace("$", "")
    if "," in text and "." in text:
        text = text.replace(",", "")
    elif "," in text:
        text = text.replace(",", ".")
    try:
        return float(text)
    except Exception:
        return None


def audit_inter_pdf_payload(payload: dict[str, Any]) -> tuple[bool, Optional[str]]:
    """
    Domain checks for INTER PDF extraction:
    - each lancamento must have non-empty date/description/value
    - `entrada_saida` should be coherent with `valor_operacao` sign (soft check)
    """
    items = payload.get("lancamentos", []) if isinstance(payload, dict) else []
    if not isinstance(items, list):
        return False, "payload.lancamentos must be an array."

    for i, item in enumerate(items):
        if not isinstance(item, dict):
            return False, f"lancamentos[{i}] must be an object."

        data_movimentacao = str(item.get("data_movimentacao", "")).strip()
        nome_produto = str(item.get("nome_produto", "")).strip()
        valor_operacao = _to_float(item.get("valor_operacao"))
        entrada_saida = str(item.get("entrada_saida", "")).strip().lower()

        if not data_movimentacao:
            return False, f"lancamentos[{i}].data_movimentacao is empty."
        if not nome_produto:
            return False, f"lancamentos[{i}].nome_produto is empty."
        if valor_operacao is None:
            return False, f"lancamentos[{i}].valor_operacao is invalid."

        # Soft validation: warn but don't fail if signs don't match
        # Some statements show positive values for both credit and debit
        # The downstream code will handle normalization

    return True, None
