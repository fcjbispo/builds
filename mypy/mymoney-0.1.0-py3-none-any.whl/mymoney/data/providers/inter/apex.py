from __future__ import annotations

import os
import re
import subprocess
from datetime import datetime
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
INTER_APEX_DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "inter_apex_pdf_domain.md"]
)
INTER_APEX_NC_DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "inter_apex_nc_pdf_domain.md"]
)


def _parse_pdf_creation_date(file_path: str) -> Optional[datetime]:
    try:
        result = subprocess.run(
            ["pdfinfo", file_path],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        match = re.search(r"^CreationDate:\s*(.+)$", result.stdout, re.MULTILINE)
        if not match:
            return None
        parsed = pd.to_datetime(match.group(1).strip(), errors="coerce")
        if pd.isna(parsed):
            return None
        return parsed.to_pydatetime()
    except Exception:
        return None


def _resolve_reference_date(file_path: str) -> datetime:
    creation_date = _parse_pdf_creation_date(file_path)
    if creation_date is not None:
        return creation_date
    try:
        return datetime.fromtimestamp(os.path.getmtime(file_path))
    except Exception:
        return datetime.now()


def _apply_pdf_defaults(
    dataframe: pd.DataFrame,
    *,
    file_path: str,
    currency: str,
    source: str,
) -> pd.DataFrame:
    if dataframe is None or dataframe.empty:
        return dataframe

    xdf = dataframe.copy()
    xdf["moeda"] = currency
    xdf["origem"] = source
    xdf["arquivo_origem"] = os.path.basename(file_path)
    xdf["data_referencia"] = _resolve_reference_date(file_path)
    return xdf


def parse_inter_apex_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    df = parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="inter_apex",
        file_type="pdf",
        source_name="INTER Apex Movements Statement",
        source="mm.data.elt.load.inter_apex",
        institution="APEX CLEARING CORPORATION",
        tipo_lancamento="MOVIMENTACAO",
        domain_prompt_path=INTER_APEX_DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback,
        use_native_pdf=use_native_pdf,
    )
    return _apply_pdf_defaults(
        df,
        file_path=file_path,
        currency="USD",
        source="mm.data.elt.load.inter_apex",
    )


def parse_inter_apex_nc_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = None,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    df = parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="inter_apex_nc",
        file_type="pdf",
        source_name="INTER Apex Trade Confirmation",
        source="mm.data.elt.load.inter_apex_nc",
        institution="APEX CLEARING CORPORATION",
        tipo_lancamento="NEGOCIACAO",
        domain_prompt_path=INTER_APEX_NC_DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=audit_callback,
        use_native_pdf=use_native_pdf,
    )
    if df is not None and not df.empty:
        xdf = df.copy()
        if "data_negocio" not in xdf.columns:
            xdf["data_negocio"] = xdf.get("data_movimentacao")
        xdf["data_negocio"] = xdf["data_negocio"].fillna(xdf.get("data_movimentacao"))
        xdf["entrada_saida"] = None
        xdf["data_movimentacao"] = None
        df = xdf

    return _apply_pdf_defaults(
        df,
        file_path=file_path,
        currency="USD",
        source="mm.data.elt.load.inter_apex_nc",
    )
