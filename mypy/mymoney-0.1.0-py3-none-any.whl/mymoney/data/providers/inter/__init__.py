"""Inter providers for file discovery used by ELT loaders."""

from __future__ import annotations

import os
from glob import glob

from mymoney.data.providers.inter.apex import (
    parse_inter_apex_nc_pdf,
    parse_inter_apex_pdf,
)
from mymoney.data.providers.inter.inter_pdf import parse_inter_pdf
from mymoney.data.providers.inter.inter_cc_pdf import parse_inter_cc_pdf
from mymoney.data.providers.inter_global.inter_global_pdf import parse_inter_global_pdf
from mymoney.data.providers.inter.inter_parser import (
    INTER_SUPPORTED_EXTENSIONS,
    parse_inter,
    parse_inter_cc,
    parse_inter_global,
    parse_inter_apex,
    parse_inter_apex_nc,
)


INTER_DEFAULT_MASKS = ("*.csv", "*.ofx", "*.pdf")
INTER_GLOBAL_DEFAULT_MASKS = ("*.csv", "*.pdf")
INTER_APEX_DEFAULT_MASKS = ("*.pdf",)
INTER_APEX_NC_DEFAULT_MASKS = ("*.pdf",)
INTER_CC_DEFAULT_MASKS = ("*.csv", "*.pdf")


def list_unprocessed_files(
    input_folder: str,
    input_masks: list[str] | tuple[str, ...],
) -> list[str]:
    """Return sorted input files that are not marked as `.done`."""
    if not input_folder:
        return []

    if not os.path.exists(input_folder):
        return []

    masks = list(input_masks or [])
    if not masks:
        masks = ["*"]

    files: set[str] = set()
    for mask in masks:
        pattern = os.path.sep.join([input_folder, mask])
        for path in glob(pattern):
            if os.path.isfile(path) and not path.endswith(".done"):
                files.add(path)

    return sorted(files)


__all__ = [
    "INTER_DEFAULT_MASKS",
    "INTER_GLOBAL_DEFAULT_MASKS",
    "INTER_APEX_DEFAULT_MASKS",
    "INTER_APEX_NC_DEFAULT_MASKS",
    "INTER_CC_DEFAULT_MASKS",
    "INTER_SUPPORTED_EXTENSIONS",
    "list_unprocessed_files",
    "parse_inter_apex_nc_pdf",
    "parse_inter_apex_pdf",
    "parse_inter_pdf",
    "parse_inter_cc_pdf",
    "parse_inter_global_pdf",
    "parse_inter",
    "parse_inter_cc",
    "parse_inter_global",
    "parse_inter_apex",
    "parse_inter_apex_nc",
]
