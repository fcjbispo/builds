"""Generic Inter parser supporting CSV, OFX, and PDF formats.

Arquivo: mymoney/data/providers/inter/inter_parser.py
"""

from __future__ import annotations

import os
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any

import pandas as pd
from fbpyutils import ofx as OFX

from mymoney.data.providers.inter.inter_pdf import parse_inter_pdf
from mymoney.data.providers.inter.inter_cc_pdf import parse_inter_cc_pdf
from mymoney.data.providers.inter_global.inter_global_pdf import parse_inter_global_pdf
from mymoney.data.providers.inter.apex import parse_inter_apex_pdf, parse_inter_apex_nc_pdf


# Supported extensions per parser type
INTER_SUPPORTED_EXTENSIONS = {
    "conta_corrente": [".csv", ".ofx", ".pdf"],
    "cartao_credito": [".csv", ".pdf"],
    "global": [".csv", ".pdf"],
    "apex": [".pdf"],
    "apex_nc": [".pdf"],
}


def _read_lines(file_path: str) -> list[str]:
    """Read file lines trying multiple encodings."""
    for encoding in ("utf-8", "latin-1"):
        try:
            with open(file_path, "r", encoding=encoding) as f:
                return [line.strip() for line in f]
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Unable to decode file '{file_path}' as utf-8 or latin-1.")


def _parse_number_br(value: str) -> float:
    """Parse Brazilian number format (e.g., '1.234,56' -> 1234.56)."""
    return float(str(value).replace(".", "").replace(",", "."))


def _parse_inter_csv(file_path: str) -> pd.DataFrame:
    """Parse Inter Conta Corrente CSV file."""
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 3:
        return pd.DataFrame(columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"])

    csv_data_line = 5
    for i, line in enumerate(csv_lines):
        if "Valor" in line:
            csv_data_line = i + 1
            break

    info_conta = csv_lines[1].split(";")[-1].strip()
    info_conta = f"077.0001.{info_conta}"

    csv_data = []
    for line in csv_lines[csv_data_line:]:
        if not line:
            continue
        raw = line.split(";")
        if len(raw) < 4:
            continue
        try:
            if len(raw) == 6:
                data_lancamento, historico, descricao, valor, _saldo = (
                    raw[0], raw[1], raw[2], raw[4], raw[5]
                )
            elif len(raw) == 5:
                data_lancamento, historico, descricao, valor, _saldo = (
                    raw[0], raw[1], raw[2], raw[3], raw[4]
                )
            else:
                data_lancamento, historico, descricao, valor = (
                    raw[0], raw[1] if len(raw) > 1 else "", raw[2] if len(raw) > 2 else "", raw[3]
                )

            if historico:
                descricao = f"{historico.strip()}::{descricao.strip()}"
            else:
                descricao = descricao.strip().replace(" - ", "::", 1)

            valor_float = _parse_number_br(valor)
            dc = "D" if valor_float < 0 else "C"
            parsed_date = pd.to_datetime(
                datetime.strptime(data_lancamento.strip(), "%d/%m/%Y").date()
            )
            csv_data.append((info_conta, 0, parsed_date, dc, descricao, valor_float, "BRL"))
        except Exception as exc:
            raise ValueError(f"Failed parsing INTER CSV row: {exc}. row={line}") from exc

    if not csv_data:
        return pd.DataFrame(columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"])

    data = pd.DataFrame(
        csv_data, columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"]
    ).sort_values(by=["conta", "data", "descricao", "valor"], ascending=True)
    data = data.reset_index(drop=True)
    data["seq"] = data.index + 1
    return data


def _parse_inter_ofx(file_path: str) -> pd.DataFrame:
    """Parse Inter Conta Corrente OFX file."""
    ofx_data = OFX.read_from_path(file_path)
    bank_number = ofx_data.get("routing_number")
    agency = str(ofx_data.get("branch_id", "")).split("-")[0]
    account = ofx_data.get("id")
    account_id = ".".join([str(bank_number), str(agency), str(account)])
    currency = ofx_data.get("statement", {}).get("currency", "BRL")

    transactions = []
    for i, item in enumerate(ofx_data.get("statement", {}).get("transactions", [])):
        date_value = item.get("date")
        memo = str(item.get("memo", "")).replace(" - ", "::", 1)
        amount = float(item.get("amount", 0))
        dc = "D" if amount < 0 else "C"
        transactions.append(
            (
                account_id, i,
                pd.to_datetime(date_value.date() if hasattr(date_value, "date") else date_value),
                dc, memo, amount, currency
            )
        )

    return pd.DataFrame(
        transactions, columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda"]
    )


def parse_inter(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Inter file (CSV, OFX, or PDF) using appropriate parser.

    Args:
        file_path: Path to the file
        max_attempts: Maximum number of retry attempts (PDF only)
        retry_delay_seconds: Delay between retries in seconds (PDF only)
        use_native_pdf: Whether to use native PDF extraction (PDF only)

    Returns:
        DataFrame with parsed transactions
    """
    ext = Path(file_path).suffix.lower()

    if ext not in INTER_SUPPORTED_EXTENSIONS["conta_corrente"]:
        supported = ", ".join(INTER_SUPPORTED_EXTENSIONS["conta_corrente"])
        raise ValueError(f"Formato '{ext}' não suportado para Inter. Formatos suportados: {supported}")

    if ext == ".csv":
        return _parse_inter_csv(file_path)
    elif ext == ".ofx":
        return _parse_inter_ofx(file_path)
    elif ext == ".pdf":
        return parse_inter_pdf(
            file_path, max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds, use_native_pdf=use_native_pdf
        )
    else:
        raise ValueError(f"Formato inesperado: {ext}")


def parse_inter_cc(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Inter Credit Card file (CSV or PDF).

    Args:
        file_path: Path to the file
        max_attempts: Maximum number of retry attempts (PDF only)
        retry_delay_seconds: Delay between retries in seconds (PDF only)
        use_native_pdf: Whether to use native PDF extraction (PDF only)

    Returns:
        DataFrame with parsed credit card transactions
    """
    ext = Path(file_path).suffix.lower()

    if ext not in INTER_SUPPORTED_EXTENSIONS["cartao_credito"]:
        supported = ", ".join(INTER_SUPPORTED_EXTENSIONS["cartao_credito"])
        raise ValueError(f"Formato '{ext}' não suportado para Inter CC. Formatos suportados: {supported}")

    if ext == ".csv":
        return _parse_inter_cc_csv(file_path)
    elif ext == ".pdf":
        return parse_inter_cc_pdf(
            file_path, max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds, use_native_pdf=use_native_pdf
        )
    else:
        raise ValueError(f"Formato inesperado: {ext}")


def _extract_parcelas(descricao: str) -> tuple[int, int]:
    """Extract parcela atual and total parcelas from description."""
    text = str(descricao or "").strip()
    pattern1 = r'(\d+)\s*/\s*(\d+)'
    match = re.search(pattern1, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas
    pattern2 = r'[Pp]arcela\s+(\d+)\s+(?:de|/)\s*(\d+)'
    match = re.search(pattern2, text)
    if match:
        parcela_atual = int(match.group(1))
        total_parcelas = int(match.group(2))
        if 1 <= parcela_atual <= total_parcelas:
            return parcela_atual, total_parcelas
    return 1, 1


def _is_credito_cartao(descricao: str) -> bool:
    """Check if transaction is a credit (payment/refund) on credit card."""
    text = str(descricao or "").lower()
    credit_keywords = ["pagamento", "estorno", "devolucao", "devolução", "cashback", "credito", "crédito", "recebido", "recebi"]
    return any(keyword in text for keyword in credit_keywords)


def _parse_inter_cc_csv(file_path: str) -> pd.DataFrame:
    """Parse Inter credit card CSV statement."""
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 2:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    header_line = 0
    data_start = 1
    for i, line in enumerate(csv_lines[:10]):
        lower = line.lower()
        if any(keyword in lower for keyword in ["data", "estabelecimento", "descri", "valor"]):
            header_line = i
            data_start = i + 1
            break

    header = csv_lines[header_line].split(";") if header_line < len(csv_lines) else []
    header = [h.strip().lower() for h in header]

    col_map = {}
    for i, h in enumerate(header):
        if "data" in h:
            col_map["data"] = i
        elif "estabelecimento" in h or "descricao" in h or "descrição" in h or "lançamento" in h:
            col_map["descricao"] = i
        elif "valor" in h:
            col_map["valor"] = i
        elif "parcela" in h:
            col_map["parcela"] = i

    conta = "INTER_CC"
    for line in csv_lines[:5]:
        if "cartao" in line.lower() or "cartão" in line.lower():
            parts = line.split(";")
            if len(parts) > 1:
                conta = parts[-1].strip()
                break

    csv_data = []
    seq = 0

    for line in csv_lines[data_start:]:
        if not line:
            continue
        raw = line.split(";")
        if len(raw) < 2:
            continue
        try:
            data_str = raw[col_map.get("data", 0)].strip() if col_map.get("data") is not None else ""
            descricao = raw[col_map.get("descricao", 1)].strip() if col_map.get("descricao") else ""
            valor_str = raw[col_map.get("valor", 2)].strip() if col_map.get("valor") else ""

            parcela_col = col_map.get("parcela")
            if parcela_col is not None and parcela_col < len(raw):
                parcela_text = raw[parcela_col].strip()
                parcela_atual, total_parcelas = _extract_parcelas(f"{descricao} {parcela_text}")
            else:
                parcela_atual, total_parcelas = _extract_parcelas(descricao)

            if data_str:
                parsed_date = pd.to_datetime(datetime.strptime(data_str, "%d/%m/%Y").date())
            else:
                continue

            valor_float = _parse_number_br(valor_str)
            if _is_credito_cartao(descricao):
                dc = "C"
                valor_float = abs(valor_float)
            else:
                dc = "D"
                valor_float = -abs(valor_float)

            seq += 1
            csv_data.append((conta, seq, parsed_date, dc, descricao, valor_float, "BRL", parcela_atual, total_parcelas))
        except Exception as exc:
            raise ValueError(f"Failed parsing INTER CC CSV row: {exc}. row={line}") from exc

    if not csv_data:
        return pd.DataFrame(columns=[
            "conta", "seq", "data", "dc", "descricao", "valor", "moeda",
            "parcela_atual", "total_parcelas"
        ])

    data = pd.DataFrame(
        csv_data,
        columns=["conta", "seq", "data", "dc", "descricao", "valor", "moeda", "parcela_atual", "total_parcelas"]
    ).sort_values(by=["data", "descricao", "valor"], ascending=True)
    return data.reset_index(drop=True)


# Global parsers

def _inter_global_parse_value(raw_value: str, dc: str) -> tuple[str, float] | None:
    """Parse Inter Global value format."""
    if not raw_value:
        return None
    tokens = raw_value.split(" ")
    if len(tokens) < 2:
        return None
    moeda_raw, amount_raw = tokens[0], tokens[1]
    dc_normalized = str(dc or "").strip().lower()
    factor = -1 if moeda_raw.startswith("-") or dc_normalized.startswith("d") else 1
    amount = float(amount_raw.replace(".", "").replace(",", ".")) * factor
    currency = {"US$": "USD", "R$": "BRL", "€": "EUR"}.get(moeda_raw.replace("-", ""), "$")
    return currency, amount


def _inter_global_parse_values(raw_values: str, dc: str) -> tuple[Any, Any]:
    """Parse Inter Global values (can have two values separated by |)."""
    first, second = raw_values.split(" | ") if "|" in raw_values else (raw_values, None)
    return _inter_global_parse_value(first, dc), _inter_global_parse_value(second, dc)


def _inter_global_parse_datetime_sequence(raw_value: str) -> tuple[date, int]:
    """Parse Inter Global datetime and sequence."""
    date_part, time_part = raw_value.split(" ")
    return datetime.strptime(date_part, "%d/%m/%Y").date(), int(time_part.replace(":", ""))


def _parse_inter_global_csv(file_path: str) -> pd.DataFrame:
    """Parse Inter Global CSV statement."""
    csv_lines = _read_lines(file_path)
    if len(csv_lines) < 13:
        return pd.DataFrame(columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"])

    conta = ".".join([csv_lines[2].split(";")[1], csv_lines[3].split(";")[1], csv_lines[4].split(";")[1]])
    data_lines = csv_lines[12:]

    rows = []
    seq = len(data_lines)
    for line in data_lines:
        if not line:
            continue
        xline = line.split(";")
        if len(xline) < 5:
            seq -= 1
            continue
        try:
            if len(xline) == 5:
                data, xvalor, historico, descricao, compl = xline
            else:
                data, xvalor, historico, descricao, compl, _ = xline[:6]

            data_movimentacao, _clock_seq = _inter_global_parse_datetime_sequence(data)
            valor1, valor2 = _inter_global_parse_values(xvalor, historico)
            if not valor1:
                seq -= 1
                continue
            moeda, valor = valor1
            dc = "D" if valor < 0 else "C"

            if valor2:
                descricao = " - ".join([historico, descricao, str(valor2)])
            else:
                descricao = " - ".join([historico, descricao])
            if compl:
                descricao = " - ".join([descricao, compl])

            rows.append((conta, pd.to_datetime(data_movimentacao), seq, dc, descricao, valor, moeda))
        except Exception as exc:
            raise ValueError(f"Failed parsing INTER GLOBAL CSV row: {exc}. row={line}") from exc
        finally:
            seq -= 1

    if not rows:
        return pd.DataFrame(columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"])

    data = pd.DataFrame(
        rows, columns=["conta", "data", "seq", "dc", "descricao", "valor", "moeda"]
    ).sort_values(by=["conta", "data", "seq", "descricao", "valor", "moeda"], ascending=True)
    data = data.reset_index(drop=True)
    return data


def parse_inter_global(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Inter Global file (CSV or PDF).

    Args:
        file_path: Path to the file
        max_attempts: Maximum number of retry attempts (PDF only)
        retry_delay_seconds: Delay between retries in seconds (PDF only)
        use_native_pdf: Whether to use native PDF extraction (PDF only)

    Returns:
        DataFrame with parsed transactions
    """
    ext = Path(file_path).suffix.lower()

    if ext not in INTER_SUPPORTED_EXTENSIONS["global"]:
        supported = ", ".join(INTER_SUPPORTED_EXTENSIONS["global"])
        raise ValueError(f"Formato '{ext}' não suportado para Inter Global. Formatos suportados: {supported}")

    if ext == ".csv":
        return _parse_inter_global_csv(file_path)
    elif ext == ".pdf":
        return parse_inter_global_pdf(
            file_path, max_attempts=max_attempts,
            retry_delay_seconds=retry_delay_seconds, use_native_pdf=use_native_pdf
        )
    else:
        raise ValueError(f"Formato inesperado: {ext}")


def parse_inter_apex(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Inter Apex file (PDF only).

    Args:
        file_path: Path to the PDF file
        max_attempts: Maximum number of retry attempts
        retry_delay_seconds: Delay between retries in seconds
        use_native_pdf: Whether to use native PDF extraction

    Returns:
        DataFrame with parsed transactions
    """
    ext = Path(file_path).suffix.lower()

    if ext not in INTER_SUPPORTED_EXTENSIONS["apex"]:
        supported = ", ".join(INTER_SUPPORTED_EXTENSIONS["apex"])
        raise ValueError(f"Formato '{ext}' não suportado para Inter Apex. Formatos suportados: {supported}")

    return parse_inter_apex_pdf(
        file_path, max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds, use_native_pdf=use_native_pdf
    )


def parse_inter_apex_nc(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    """Parse Inter Apex NC file (PDF only).

    Args:
        file_path: Path to the PDF file
        max_attempts: Maximum number of retry attempts
        retry_delay_seconds: Delay between retries in seconds
        use_native_pdf: Whether to use native PDF extraction

    Returns:
        DataFrame with parsed transactions
    """
    ext = Path(file_path).suffix.lower()

    if ext not in INTER_SUPPORTED_EXTENSIONS["apex_nc"]:
        supported = ", ".join(INTER_SUPPORTED_EXTENSIONS["apex_nc"])
        raise ValueError(f"Formato '{ext}' não suportado para Inter Apex NC. Formatos suportados: {supported}")

    return parse_inter_apex_nc_pdf(
        file_path, max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds, use_native_pdf=use_native_pdf
    )
