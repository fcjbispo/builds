"""Backward-compatible import path for Inter Global PDF provider."""

from mymoney.data.providers.inter_global.inter_global_pdf import parse_inter_global_pdf

__all__ = ["parse_inter_global_pdf"]
