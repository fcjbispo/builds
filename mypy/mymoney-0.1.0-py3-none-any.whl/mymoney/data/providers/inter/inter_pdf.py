from __future__ import annotations

import os
from typing import Any, Callable, Optional

import pandas as pd

from mymoney.data.providers.base import parse_unstructured_domain_pdf
from mymoney.data.providers.inter.audit import audit_inter_pdf_payload


_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_RESOURCES_DIR = os.path.sep.join([_ROOT_DIR, "resources"])
DOMAIN_PROMPT_PATH = os.path.sep.join(
    [_RESOURCES_DIR, "domain", "inter_pdf_domain.md"]
)

# Sentinel value to detect if audit_callback was explicitly provided
_UNSET = object()


def parse_inter_pdf(
    file_path: str,
    *,
    max_attempts: int = 3,
    retry_delay_seconds: int = 0,
    audit_callback: Optional[Callable[[dict[str, Any]], Any]] = _UNSET,
    use_native_pdf: bool = False,
) -> pd.DataFrame:
    # Only use default audit if callback was NOT provided at all
    if audit_callback is _UNSET:
        resolved_audit_callback = audit_inter_pdf_payload
    else:
        resolved_audit_callback = audit_callback

    return parse_unstructured_domain_pdf(
        file_path=file_path,
        provider="inter",
        file_type="pdf",
        source_name="INTER Bank Statement",
        source="INTER",
        institution="BANCO INTER S/A",
        tipo_lancamento="MOVIMENTACAO",
        domain_prompt_path=DOMAIN_PROMPT_PATH,
        max_attempts=max_attempts,
        retry_delay_seconds=retry_delay_seconds,
        audit_callback=resolved_audit_callback,
        use_native_pdf=use_native_pdf,
    )
