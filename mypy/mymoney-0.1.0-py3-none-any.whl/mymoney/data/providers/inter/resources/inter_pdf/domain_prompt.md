Domain: INTER bank statement (Brazil account).

Interpretation rules:
- Expected records are checking account movements.
- Set `tipo_lancamento` to `MOVIMENTACAO`.
- Set `tipo_produto` to `CONTA CORRENTE`.
- Set `tipo_evento` to `LANCAMENTO C/C`.
- `movimentacao` should be a concise category from statement text.
- `nome_produto` should hold movement detail/description.
- `entrada_saida` must be `Credito` for incoming and `Debito` for outgoing.
- Currency defaults to `BRL` when not explicit.

