Domain: INTER GLOBAL account statement (USD account).

Interpretation rules:
- Expected records are checking account movements from Inter Global statements.
- Set `tipo_lancamento` to `MOVIMENTACAO`.
- Set `tipo_produto` to `CONTA CORRENTE`.
- Set `tipo_evento` to `LANCAMENTO C/C`.
- `movimentacao` should be a concise movement category.
- `nome_produto` should represent the movement detail.
- **IMPORTANT - Signs**: 
  - Values in the CREDIT column should have positive values AND `entrada_saida` = "Credito"
  - Values in the DEBIT column should have positive values AND `entrada_saida` = "Debito"
  - DO NOT use negative signs in the output - use the correct `entrada_saida` value instead
- Currency defaults to `USD` when not explicit.
- **IMPORTANT**: Always extract `data_movimentacao` in ISO format `YYYY-MM-DD` from the statement date column. Every transaction MUST have a valid date - extract from the date column in the statement table. Never leave `data_movimentacao` as null.
- Extract ALL transactions from the statement - do not skip any rows. Read every line in the transactions table.
