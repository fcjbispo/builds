# Domain Rules - INTER OFX Bank Statement

## Provider Information
- **Source**: INTER
- **Institution**: BANCO INTER S/A
- **File Type**: OFX (Open Financial Exchange)
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | INTER |

## OFX Structure

The OFX file contains:
- STMTTRN: Individual transactions
  - TRNTYPE: Transaction type (CREDIT, DEBIT, etc.)
  - DTPOSTED: Date posted
  - TRNAMT: Transaction amount
  - NAME: Transaction description
  - MEMO: Additional memo

## Interpretation Rules

### Transaction Types (TRNTYPE)
- CREDIT, DEP, DIRDEP → `entrada_saida`: "Credito"
- DEBIT, PAYMENT, WITHDRAWAL → `entrada_saida`: "Debito"

### Value Sign Rules
- OFX amounts are already signed
- Positive → `entrada_saida`: "Credito"
- Negative → `entrada_saida`: "Debito" (keep negative or convert to positive with Debito)

### Date Extraction
- Extract from DTPOSTED field
- Format: YYYY-MM-DD (parse from YYYYMMDD or YYYYMMDDHHMMSS)

### Transaction Description
- Map NAME/MEMO to: movimentacao and nome_produto
- Categorize: Pix, TED, Boleto, etc.
