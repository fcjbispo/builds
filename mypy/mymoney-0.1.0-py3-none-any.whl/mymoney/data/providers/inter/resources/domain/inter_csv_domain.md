# Domain Rules - INTER CSV Bank Statement

## Provider Information
- **Source**: INTER
- **Institution**: BANCO INTER S/A
- **File Type**: CSV (Bank Statement Export)
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | INTER |

## CSV Structure

The CSV contains columns like:
- Data
- Descrição
- Valor
- Saldo

## Interpretation Rules

### Value Sign Rules
- Positive values in CSV → `entrada_saida`: "Credito"
- Negative values in CSV → `entrada_saida`: "Debito", convert to positive for valor_operacao

### Date Extraction
- Extract from "Data" column
- Format: YYYY-MM-DD

### Transaction Types
- Parse from "Descrição" column
- Categories: Pix, TED, DOC, Boleto, Cartão, Depósito, Resgate, etc.

### Account Information
- Account number usually in filename or header
