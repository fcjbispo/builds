# Domain Rules - INTER APEX PDF Trade Confirmation

## Provider Information
- **Source**: mm.data.elt.load.inter_apex_nc
- **Institution**: APEX CLEARING CORPORATION
- **File Type**: PDF (Trade Confirmation)
- **Currency**: USD

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | NEGOCIACAO |
| moeda | USD |
| origem | mm.data.elt.load.inter_apex_nc |

## Statement Structure

This PDF is a trade confirmation. It usually contains fields such as:
- `Account Number`
- `Trade Date`
- `Settle Date`
- `B/S`
- `QTY`
- `SYM`
- `PRICE`
- `Principal`
- `Net Amount`
- `Desc`
- `Currency: USD`

## Extraction Rules

- Extract one lancamento for each confirmed trade block.
- `movimentacao`:
  - `Compra` when `B/S` is `B`
  - `Venda` when `B/S` is `S`
- `data_negocio`:
  - use `Trade Date`
- `data_movimentacao`:
  - set the same trade date during extraction if needed for schema compatibility
- `entrada_saida`:
  - use `Debito` for `Compra`
  - use `Credito` for `Venda`
- `codigo_produto`:
  - use `SYM`
- `nome_produto`:
  - use the security description from `Desc`
- `conta`:
  - use `Account Number`
- `quantidade`:
  - use `QTY` as a positive number
- `preco_unitario`:
  - use `PRICE`
- `valor_operacao`:
  - use `Net Amount` as a positive number
  - if `Net Amount` is missing, use `Principal`
- `mercado`, `tipo_produto`, `valor_liquido`:
  - use only when explicitly present
  - otherwise `null`

## Important Notes

- Preserve one record per trade.
- Do not use `Settle Date` as `data_negocio`.
- Do not invent fields not present in the confirmation.
- All numeric values must be returned as numbers, not strings.
