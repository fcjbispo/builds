# Domain Rules - INTER PDF Bank Statement

## Provider Information
- **Source**: INTER
- **Institution**: BANCO INTER S/A
- **File Type**: PDF (Bank Statement)
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | INTER |

## PDF Table Structure

The INTER PDF statement typically contains a table with these columns:
- **Data** (Date) - Format: DD/MM/YYYY
- **Lançamento** (Transaction Description) - Description of the transaction
- **Categoria** (Category) - Optional category
- **Valor (R$)** (Value) - Amount with Debito/Credito indicator

## Transaction Examples

### Example 1: Pix Received
```
Input: "Pix Recebido - JOAO SILVA"
Output:
- entrada_saida: "Credito"
- movimentacao: "Pix"
- nome_produto: null (not an investment product)
- instituicao: "BANCO INTER"
```

### Example 2: Debit Card Purchase
```
Input: "Compra com Cartão - SUPERMERCADO EXTRA"
Output:
- entrada_saida: "Debito"
- movimentacao: "Cartao Debito"
- nome_produto: null
- instituicao: "BANCO INTER"
```

### Example 3: TED Transfer Sent
```
Input: "Transferência enviada - TED"
Output:
- entrada_saida: "Debito"
- movimentacao: "TED"
- nome_produto: null
- instituicao: "BANCO INTER"
```

### Example 4: Automatic Debit
```
Input: "Débito Automático - CONTA DE LUZ"
Output:
- entrada_saida: "Debito"
- movimentacao: "Debito Automatico"
- nome_produto: null
- instituicao: "BANCO INTER"
```

## Interpretation Rules

### Transaction Types
- **Pix Recebido** / **Pix enviado** → `movimentacao`: "Pix"
- **Débito Automático** → `movimentacao`: "Debito Automatico"
- **Pagamento de Conta** → `movimentacao`: "Pagamento"
- **TED/DOC** → `movimentacao`: "TED"
- **Boleto** → `movimentacao`: "Boleto"
- **Compra com Cartão** → `movimentacao`: "Cartao Credito" or "Cartao Debito"
- **Resgate/Depósito** → `movimentacao`: "Resgate" or "Deposito"
- **Cashback** → `movimentacao`: "Cashback"

### Value Sign Rules
- Values in the CREDIT column → `entrada_saida`: "Credito", `valor_operacao`: positive
- Values in the DEBIT column → `entrada_saida`: "Debito", `valor_operacao`: positive
- Do NOT use negative values - use the correct entrada_saida instead

### Date Extraction
- Extract dates from the date column in the statement table
- Format: YYYY-MM-DD (convert from DD/MM/YYYY)
- Every transaction MUST have a valid date

### Account Information
- Extract account number from the statement header
- Map to: `conta` field

### nome_produto Field - IMPORTANT
- For INTER checking account transactions: ALWAYS use `null`
- Only populate for investment products (Fundos, ETFs, Ações, etc.)
- Do NOT put "BANCO INTER" or account holder name here

### Important Notes
- The PDF contains checking account (conta corrente) movements
- One statement may contain multiple months - extract all transactions
- Do not skip any rows - extract every transaction from the table
