# Domain Rules - INTER APEX PDF Movements Statement

## Provider Information
- **Source**: mm.data.elt.load.inter_apex
- **Institution**: APEX CLEARING CORPORATION
- **File Type**: PDF (Global Investment Movements Statement)
- **Currency**: USD

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| moeda | USD |
| origem | mm.data.elt.load.inter_apex |

## Statement Structure

This PDF is an investment movements statement. It usually contains:
- a title like `Extrato de Movimentações - Plataforma Global de Investimentos`
- a requested/generated timestamp near the top
- date group headers in Portuguese, such as `9 de janeiro de 2024`
- movement rows below each date
- each movement usually has:
  - a movement label, such as `Pagamento De Dividendos`, `Imposto Sobre Dividendos`, `Compra`, `Venda`, `Journal to`, `Journal from`
  - optionally a product/security name on the next line
  - a signed amount like `+US$ 294,95` or `-US$ 88,49`

## Extraction Rules

- Extract every movement row from the statement.
- Convert Portuguese long dates like `9 de janeiro de 2024` to `YYYY-MM-DD`.
- Use `entrada_saida`:
  - `Credito` for `+US$`
  - `Debito` for `-US$`
- `valor_operacao` must always be positive.
- `movimentacao` must be the movement label exactly or as a close normalized variant.
- `nome_produto`:
  - use the product/security name when it is explicitly shown
  - use `null` for journal/cash movements without a product line
- `codigo_produto`:
  - use only if a symbol/ticker is explicitly shown in the document
  - otherwise `null`
- `conta`:
  - extract only if explicitly present in the document
  - otherwise `null`
- `quantidade`, `preco_unitario`, `valor_liquido`, `tipo_produto`, `mercado`:
  - use only when explicitly present
  - otherwise `null`

## Important Notes

- Preserve the real semantics of the PDF.
- Do not invent ticker, quantity, unit price, or product type when not present.
- Do not merge multiple rows into one transaction.
- Do not skip movements because the amounts are small.
