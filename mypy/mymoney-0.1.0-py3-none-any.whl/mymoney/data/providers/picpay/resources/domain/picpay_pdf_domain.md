# Domain Rules - PicPay PDF Bank Statement

## Provider Information
- **Source**: mm.data.elt.load.picpay
- **Institution**: PICPAY SERVICOS S.A.
- **File Type**: PDF account statement
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | MOVIMENTACAO |
| tipo_produto | CONTA CORRENTE |
| tipo_evento | LANCAMENTO C/C |
| moeda | BRL |
| origem | mm.data.elt.load.picpay |

## PDF Table Structure

The PicPay PDF statement typically contains these elements:
- Header with `Agência`, `Conta`, customer identification and statement period
- Movements table with these columns:
  - **Data/Hora** - split over 2 lines, format `DD/MM/YYYY` and `HH:MM:SS`
  - **Descrição das Movimentações**
  - **Valor**
  - **Saldo**
  - **Saldo Sacável**

Extract every movement row from the statement table. Ignore page headers, footers, support text and repeated column headers.

## Output Requirements

- Return data in the `lancamentos` list using the same direct structure accepted by checking-account loaders.
- Every row must contain at least:
  - `entrada_saida`
  - `data_movimentacao`
  - `movimentacao`
  - `nome_produto`
  - `valor_operacao`
- Also fill when available:
  - `conta`
  - `instituicao`
  - `tipo_produto`
  - `tipo_evento`
  - `moeda`
  - `origem`

## Mapping Rules

### Account
- Build `conta` as `<agencia>.<conta>` when both values are available in the header.
- Example: agency `0001` and account `138782857` -> `0001.138782857`

### Date
- Combine the date and time shown in the `Data/Hora` column.
- Convert to `YYYY-MM-DD HH:MM:SS`.
- Every transaction must have a valid `data_movimentacao`.

### Amount and direction
- `entrada_saida` must be `Credito` for incoming money and `Debito` for outgoing money.
- Use the sign shown in the PDF to determine the direction.
- `valor_operacao` must be returned as a positive number. Do not keep the negative sign once `entrada_saida` is defined.

### Movement description
- `movimentacao` should be a normalized business label for the movement.
- `nome_produto` should keep the original movement description from the PDF when there is no distinct financial product.
- For common wallet/account movements, use concise labels such as:
  - `Pix Recebido`
  - `Pix Enviado`
  - `Rendimento`
  - `Pagamento`
  - `Transferencia`

### Specific interpretation
- `Rendimento de saldo de carteira - Renda Fixa`
  - `entrada_saida`: `Credito`
  - `movimentacao`: `Rendimento`
  - `nome_produto`: `Rendimento de saldo de carteira - Renda Fixa`
- `Pix Enviado`
  - `entrada_saida`: `Debito`
  - `movimentacao`: `Pix Enviado`
  - `nome_produto`: `Pix Enviado`
- `Pix Recebido`
  - `entrada_saida`: `Credito`
  - `movimentacao`: `Pix Recebido`
  - `nome_produto`: `Pix Recebido`

## Important Notes

- `instituicao` must always be `PICPAY SERVICOS S.A.`.
- `tipo_produto` should default to `CONTA CORRENTE`.
- `tipo_evento` should default to `LANCAMENTO C/C`.
- Ignore saldo columns for output rows; they are supporting context only.
- Do not skip rows only because saldo values are shown as `-`.
