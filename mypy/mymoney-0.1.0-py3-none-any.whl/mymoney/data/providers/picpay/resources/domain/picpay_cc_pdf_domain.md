# Domain Rules - PicPay Credit Card PDF Statement

## Provider Information
- **Source**: PICPAY_CC
- **Institution**: PICPAY SERVICOS S.A.
- **File Type**: PDF (Credit Card Statement)
- **Currency**: BRL

## Field Defaults

| Field | Value |
|-------|-------|
| tipo_lancamento | LANCAMENTOS_CARTAO_CREDITO |
| tipo_produto | CARTAO CREDITO |
| tipo_evento | COMPRA CC (for purchases) / PAGAMENTO CC (for payments) |
| moeda | BRL |
| origem | PICPAY_CC |

## PDF Table Structure

The PicPay credit card PDF statement typically contains a table with these columns:
- **Data** (Date) - Format: DD/MM/YYYY
- **Estabelecimento** (Merchant) - Where the purchase was made
- **Descrição** (Description) - Additional transaction details
- **Parcela** (Installment) - Current installment / Total installments (e.g., "1/12", "Parcela 3 de 10")
- **Valor (R$)** (Value) - Amount (always positive in statement)

Extract every transaction row from the statement table. Ignore page headers, footers, support text and repeated column headers.

## Transaction Examples

### Example 1: Purchase in single installment
```
Input: "15/01/2024 | SUPERMERCADO EXTRA | Compra a vista | 1/1 | 150,00"
Output:
- data_movimentacao: "2024-01-15"
- movimentacao: "Compra Cartao"
- nome_produto: "SUPERMERCADO EXTRA - Compra a vista"
- entrada_saida: "Debito"
- valor_operacao: 150.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "COMPRA CC"
```

### Example 2: Purchase in installments
```
Input: "15/01/2024 | LOJA XYZ | Compra parcelada | 3/10 | 85,00"
Output:
- data_movimentacao: "2024-01-15"
- movimentacao: "Compra Cartao Parcelada"
- nome_produto: "LOJA XYZ - Compra parcelada"
- entrada_saida: "Debito"
- valor_operacao: 85.00
- quantidade_disponivel: 3
- quantidade_indisponivel: 10
- tipo_evento: "COMPRA CC"
```

### Example 3: Payment of credit card bill
```
Input: "20/01/2024 | PAGAMENTO DE FATURA | Pagamento recebido | 1/1 | -500,00"
Output:
- data_movimentacao: "2024-01-20"
- movimentacao: "Pagamento Fatura"
- nome_produto: "PAGAMENTO DE FATURA - Pagamento recebido"
- entrada_saida: "Credito"
- valor_operacao: 500.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

### Example 4: Refund/Estorno
```
Input: "18/01/2024 | ESTORNO LOJA ABC | Estorno de compra | 1/1 | -75,00"
Output:
- data_movimentacao: "2024-01-18"
- movimentacao: "Estorno"
- nome_produto: "ESTORNO LOJA ABC - Estorno de compra"
- entrada_saida: "Credito"
- valor_operacao: 75.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

### Example 5: Cashback
```
Input: "18/01/2024 | CASHBACK PICPAY | Recompensa | 1/1 | -25,00"
Output:
- data_movimentacao: "2024-01-18"
- movimentacao: "Cashback"
- nome_produto: "CASHBACK PICPAY - Recompensa"
- entrada_saida: "Credito"
- valor_operacao: 25.00
- quantidade_disponivel: 1
- quantidade_indisponivel: 1
- tipo_evento: "PAGAMENTO CC"
```

## Interpretation Rules

### Transaction Types
- **Compra**, **Transação**, **Pagamento aprovado**, **Compra aprovada** → `movimentacao`: "Compra Cartao", `tipo_evento`: "COMPRA CC"
- **Parcela** / **Parcelado** / **Compra parcelada** → `movimentacao`: "Compra Cartao Parcelada", `tipo_evento`: "COMPRA CC"
- **Pagamento de fatura** / **Pagamento recebido** / **Pagamento efetuado** → `movimentacao`: "Pagamento Fatura", `tipo_evento`: "PAGAMENTO CC"
- **Estorno** / **Estorno de compra** → `movimentacao`: "Estorno", `tipo_evento`: "PAGAMENTO CC"
- **Devolução** / **Devolução de compra** → `movimentacao`: "Devolucao", `tipo_evento`: "PAGAMENTO CC"
- **Cashback** / **Recompensa** → `movimentacao`: "Cashback", `tipo_evento`: "PAGAMENTO CC"

### Value Sign Rules
- **Debito** (purchases): `entrada_saida`: "Debito", `valor_operacao`: positive
- **Credito** (payments/refunds): `entrada_saida`: "Credito", `valor_operacao`: positive
- Use `tipo_evento` to distinguish: "COMPRA CC" for debit, "PAGAMENTO CC" for credit
- Do NOT use negative values - always positive with correct entrada_saida

### Parcela Extraction (IMPORTANT)
- Look for patterns like "X/Y" or "Parcela X de Y" in the description or parcela column
- **quantidade_disponivel** = current installment number (X)
- **quantidade_indisponivel** = total installments (Y)
- If no parcela info found, default both to 1
- Examples:
  - "1/12" → quantidade_disponivel: 1, quantidade_indisponivel: 12
  - "3/10" → quantidade_disponivel: 3, quantidade_indisponivel: 10
  - "Parcela 5 de 12" → quantidade_disponivel: 5, quantidade_indisponivel: 12

### Date Extraction
- Extract dates from the date column in the statement table
- Format: YYYY-MM-DD (convert from DD/MM/YYYY)
- Every transaction MUST have a valid date

### Account Information
- Extract card number (last 4 digits) from the statement header if available
- Map to: `conta` field (e.g., "PICPAY_CC_1234")
- If not available, use "PICPAY_CC" as default

### nome_produto Field
- Combine merchant name with description
- Format: "MERCHANT_NAME - DESCRIPTION"
- If merchant is not clear, use the full description

### Important Notes
- The PDF contains credit card (cartão de crédito) transactions
- One statement may contain multiple months of installments
- Do not skip any rows - extract every transaction from the table
- Always extract parcela information when available
- PicPay credit card statements may show "Fatura de [MES]" in the header
