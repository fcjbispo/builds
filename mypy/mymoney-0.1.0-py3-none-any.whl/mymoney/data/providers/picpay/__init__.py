from mymoney.data.providers.picpay.picpay_pdf import parse_picpay_pdf
from mymoney.data.providers.picpay.picpay_cc_pdf import parse_picpay_cc_pdf


PICPAY_DEFAULT_MASKS = ("*.pdf",)
PICPAY_CC_DEFAULT_MASKS = ("*.pdf",)


__all__ = [
    "PICPAY_DEFAULT_MASKS",
    "PICPAY_CC_DEFAULT_MASKS",
    "parse_picpay_pdf",
    "parse_picpay_cc_pdf",
]
