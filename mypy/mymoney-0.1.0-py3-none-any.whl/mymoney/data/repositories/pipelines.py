"""
Repository para acesso a pipelines no banco de dados.

Arquivo: mymoney/data/repositories/pipelines.py
"""

from typing import Optional, List, Dict, Any
from sqlalchemy import text
from sqlalchemy.engine import Engine
from mymoney.api.schemas.pipelines import PipelineCreate, PipelineUpdate


class PipelineRepository:
    """Repository para CRUD de pipelines no banco de dados."""

    def __init__(self, engine: Engine):
        """
        Inicializa o repository.

        Args:
            engine: Engine SQLAlchemy para conexão com o banco.
        """
        self.engine = engine

    def get(self, pipeline_id: str) -> Optional[Dict[str, Any]]:
        """Busca pipeline por ID.

        Args:
            pipeline_id: ID da pipeline.

        Returns:
            Dict com os dados da pipeline ou None se não encontrada.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT * FROM mymoney.pipelines
                    WHERE id = :id
                """),
                {"id": pipeline_id}
            )
            row = result.mappings().first()
            return dict(row) if row else None

    def get_by_nome(self, nome: str) -> Optional[Dict[str, Any]]:
        """Busca pipeline por nome.

        Args:
            nome: Nome da pipeline.

        Returns:
            Dict com os dados da pipeline ou None se não encontrada.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT * FROM mymoney.pipelines
                    WHERE nome = :nome
                """),
                {"nome": nome}
            )
            row = result.mappings().first()
            return dict(row) if row else None

    def list(
        self,
        escopo: Optional[str] = None,
        ativo: Optional[bool] = None,
        usuario: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """Lista pipelines com filtros.

        Args:
            escopo: Filtrar por escopo.
            ativo: Filtrar por status ativo.
            usuario: Filtrar por usuário.
            limit: Limite de registros.
            offset: Offset para paginação.

        Returns:
            Lista de dicts com os dados das pipelines.
        """
        conditions = []
        params = {}

        if escopo is not None:
            conditions.append("escopo = :escopo")
            params["escopo"] = escopo

        if ativo is not None:
            conditions.append("ativo = :ativo")
            params["ativo"] = ativo

        if usuario is not None:
            conditions.append("usuario = :usuario")
            params["usuario"] = usuario

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"""
            SELECT * FROM mymoney.pipelines
            {where_clause}
            ORDER BY updated_at DESC
            LIMIT :limit OFFSET :offset
        """
        params["limit"] = limit
        params["offset"] = offset

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params)
            return [dict(row) for row in result.mappings()]

    def create(self, data: PipelineCreate, usuario: str) -> Dict[str, Any]:
        """Cria nova pipeline.

        Args:
            data: Dados da pipeline a criar.
            usuario: Usuário criador.

        Returns:
            Dict com os dados da pipeline criada.
        """
        import json
        from sqlalchemy import bindparam
        from sqlalchemy.dialects.postgresql import JSONB

        # Gerar ID automaticamente a partir do nome se não fornecido
        pipeline_id = data.id if data.id else data.generate_id()

        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    INSERT INTO mymoney.pipelines (
                        id, nome, descricao, escopo, ativo,
                        steps, parametros, usuario
                    ) VALUES (
                        :id, :nome, :descricao, :escopo, :ativo,
                        cast(:steps as jsonb), cast(:parametros as jsonb), :usuario
                    )
                    RETURNING *
                """),
                {
                    "id": pipeline_id,
                    "nome": data.nome,
                    "descricao": data.descricao,
                    "escopo": data.escopo,
                    "ativo": data.ativo,
                    "steps": json.dumps([s.dict() for s in data.steps]),
                    "parametros": json.dumps(data.parametros),
                    "usuario": usuario
                }
            )
            conn.commit()
            row = result.mappings().first()
            return dict(row)

    def update(self, pipeline_id: str, data: PipelineUpdate, usuario: str) -> Optional[Dict[str, Any]]:
        """Atualiza pipeline existente.

        Args:
            pipeline_id: ID da pipeline a atualizar.
            data: Dados para atualização.
            usuario: Usuário que está atualizando.

        Returns:
            Dict com os dados atualizados ou None se não encontrada.
        """
        import json

        # Verificar se existe
        existing = self.get(pipeline_id)
        if not existing:
            return None

        # Construir SET dinamicamente
        set_clauses = []
        params = {"id": pipeline_id, "usuario": usuario}

        if data.nome is not None:
            set_clauses.append("nome = :nome")
            params["nome"] = data.nome

        if data.descricao is not None:
            set_clauses.append("descricao = :descricao")
            params["descricao"] = data.descricao

        if data.ativo is not None:
            set_clauses.append("ativo = :ativo")
            params["ativo"] = data.ativo

        if data.steps is not None:
            set_clauses.append("steps = cast(:steps as jsonb)")
            params["steps"] = json.dumps([s.dict() for s in data.steps])

        if data.parametros is not None:
            set_clauses.append("parametros = cast(:parametros as jsonb)")
            params["parametros"] = json.dumps(data.parametros)

        if not set_clauses:
            return existing

        query = f"""
            UPDATE mymoney.pipelines
            SET {', '.join(set_clauses)}
            WHERE id = :id
            RETURNING *
        """

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params)
            conn.commit()
            row = result.mappings().first()
            return dict(row) if row else None

    def delete(self, pipeline_id: str) -> bool:
        """Remove pipeline.

        Args:
            pipeline_id: ID da pipeline a remover.

        Returns:
            True se removida, False se não encontrada.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    DELETE FROM mymoney.pipelines
                    WHERE id = :id
                """),
                {"id": pipeline_id}
            )
            conn.commit()
            return result.rowcount > 0

    def clone(self, source_id: str, new_id: str, usuario: str) -> Optional[Dict[str, Any]]:
        """Clona pipeline existente.

        Args:
            source_id: ID da pipeline fonte.
            new_id: ID da nova pipeline.
            usuario: Usuário criador.

        Returns:
            Dict com os dados da pipeline clonada ou None se fonte não encontrada.
        """
        source = self.get(source_id)
        if not source:
            return None

        # Criar nova pipeline com dados da fonte
        from mymoney.api.schemas.pipelines import PipelineCreate, PipelineStep

        steps = [PipelineStep(**s) for s in source.get("steps", [])]

        data = PipelineCreate(
            id=new_id,
            nome=f"{source['nome']} (cópia)",
            descricao=source.get("descricao"),
            escopo=source["escopo"],
            ativo=source.get("ativo", True),
            steps=steps,
            parametros=source.get("parametros", {})
        )

        return self.create(data, usuario)

    def count(self, escopo: Optional[str] = None, ativo: Optional[bool] = None) -> int:
        """Conta pipelines com filtros.

        Args:
            escopo: Filtrar por escopo.
            ativo: Filtrar por status ativo.

        Returns:
            Número de pipelines.
        """
        conditions = []
        params = {}

        if escopo is not None:
            conditions.append("escopo = :escopo")
            params["escopo"] = escopo

        if ativo is not None:
            conditions.append("ativo = :ativo")
            params["ativo"] = ativo

        where_clause = ""
        if conditions:
            where_clause = "WHERE " + " AND ".join(conditions)

        query = f"SELECT COUNT(*) as count FROM mymoney.pipelines {where_clause}"

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params)
            row = result.fetchone()
            return row[0] if row else 0
