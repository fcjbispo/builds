"""
Repository para persistência de execuções de pipelines.

Arquivo: mymoney/data/repositories/executions.py
"""

import json
from typing import Optional, List, Dict, Any
from datetime import datetime
from sqlalchemy import text
from sqlalchemy.engine import Engine


class ExecutionRepository:
    """Repository para persistência de execuções de pipelines."""

    def __init__(self, engine: Engine):
        """
        Inicializa o repository.

        Args:
            engine: Engine SQLAlchemy para conexão com o banco.
        """
        self.engine = engine

    def _generate_execution_id(self) -> str:
        """Gera um ID único para execução."""
        from fbpyutils.uuid import generate_uuid
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        uid = generate_uuid()[:8]
        return f"exec-{timestamp}-{uid}"

    def create(
        self,
        pipeline_id: str,
        usuario: str,
        parametros: Dict[str, Any]
    ) -> str:
        """
        Cria registro de execução.

        Args:
            pipeline_id: ID da pipeline.
            usuario: Usuário que iniciou a execução.
            parametros: Parâmetros da execução.

        Returns:
            ID da execução criada.
        """
        execution_id = self._generate_execution_id()

        with self.engine.connect() as conn:
            conn.execute(
                text("""
                    INSERT INTO mymoney.executions (
                        id, pipeline_id, status, parametros, usuario, created_at
                    ) VALUES (
                        :id, :pipeline_id, 'queued', :parametros::jsonb, :usuario, NOW()
                    )
                """),
                {
                    "id": execution_id,
                    "pipeline_id": pipeline_id,
                    "parametros": json.dumps(parametros),
                    "usuario": usuario
                }
            )
            conn.commit()

        return execution_id

    def get(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """
        Busca execução por ID.

        Args:
            execution_id: ID da execução.

        Returns:
            Dict com os dados da execução ou None se não encontrada.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT * FROM mymoney.executions
                    WHERE id = :id
                """),
                {"id": execution_id}
            )
            row = result.mappings().first()
            return dict(row) if row else None

    def update_status(
        self,
        execution_id: str,
        status: str,
        **kwargs
    ) -> bool:
        """
        Atualiza status da execução.

        Args:
            execution_id: ID da execução.
            status: Novo status (queued, running, completed, failed, cancelled).
            **kwargs: Campos adicionais a atualizar.

        Returns:
            True se atualizado com sucesso.
        """
        # Campos permitidos
        allowed_fields = [
            "current_step", "progress_percent", "started_at", "finished_at",
            "duration_ms", "success", "records_processed", "records_inserted",
            "records_failed", "steps_results", "error_message"
        ]

        set_clauses = ["status = :status"]
        params = {"id": execution_id, "status": status}

        for field, value in kwargs.items():
            if field in allowed_fields:
                set_clauses.append(f"{field} = :{field}")
                if isinstance(value, (dict, list)):
                    params[field] = json.dumps(value)
                else:
                    params[field] = value

        query = f"""
            UPDATE mymoney.executions
            SET {', '.join(set_clauses)}
            WHERE id = :id
        """

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params)
            conn.commit()
            return result.rowcount > 0

    def start_execution(self, execution_id: str) -> bool:
        """
        Marca execução como iniciada.

        Args:
            execution_id: ID da execução.

        Returns:
            True se atualizado com sucesso.
        """
        return self.update_status(
            execution_id,
            "running",
            started_at=datetime.now(),
            current_step=None,
            progress_percent=0
        )

    def complete_execution(
        self,
        execution_id: str,
        success: bool,
        records_processed: int = 0,
        records_inserted: int = 0,
        records_failed: int = 0,
        steps_results: Optional[List[Dict]] = None,
        error_message: Optional[str] = None
    ) -> bool:
        """
        Marca execução como concluída.

        Args:
            execution_id: ID da execução.
            success: Se foi bem-sucedida.
            records_processed: Total de registros processados.
            records_inserted: Registros inseridos.
            records_failed: Registros com falha.
            steps_results: Resultados por step.
            error_message: Mensagem de erro em caso de falha.

        Returns:
            True se atualizado com sucesso.
        """
        # Calcular duração
        exec_data = self.get(execution_id)
        duration_ms = None
        if exec_data and exec_data.get("started_at"):
            started = exec_data["started_at"]
            if isinstance(started, datetime):
                duration_ms = int((datetime.now() - started).total_seconds() * 1000)

        return self.update_status(
            execution_id,
            "completed" if success else "failed",
            finished_at=datetime.now(),
            duration_ms=duration_ms,
            success=success,
            records_processed=records_processed,
            records_inserted=records_inserted,
            records_failed=records_failed,
            steps_results=steps_results or [],
            error_message=error_message
        )

    def list_by_pipeline(
        self,
        pipeline_id: str,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Lista execuções de uma pipeline.

        Args:
            pipeline_id: ID da pipeline.
            status: Filtrar por status.
            limit: Limite de registros.
            offset: Offset para paginação.

        Returns:
            Lista de execuções.
        """
        query = """
            SELECT * FROM mymoney.executions
            WHERE pipeline_id = :pipeline_id
        """
        params = {"pipeline_id": pipeline_id, "limit": limit, "offset": offset}

        if status:
            query += " AND status = :status"
            params["status"] = status

        query += " ORDER BY created_at DESC LIMIT :limit OFFSET :offset"

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params)
            return [dict(row) for row in result.mappings()]

    def list_by_user(
        self,
        usuario: str,
        limit: int = 20,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Lista execuções de um usuário.

        Args:
            usuario: Nome do usuário.
            limit: Limite de registros.
            offset: Offset para paginação.

        Returns:
            Lista de execuções.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT * FROM mymoney.executions
                    WHERE usuario = :usuario
                    ORDER BY created_at DESC
                    LIMIT :limit OFFSET :offset
                """),
                {"usuario": usuario, "limit": limit, "offset": offset}
            )
            return [dict(row) for row in result.mappings()]

    def add_step_result(
        self,
        execution_id: str,
        step_result: Dict[str, Any]
    ) -> bool:
        """
        Adiciona resultado de um step.

        Args:
            execution_id: ID da execução.
            step_result: Dados do resultado do step.

        Returns:
            True se atualizado com sucesso.
        """
        exec_data = self.get(execution_id)
        if not exec_data:
            return False

        steps_results = exec_data.get("steps_results") or []
        if isinstance(steps_results, str):
            try:
                steps_results = json.loads(steps_results)
            except json.JSONDecodeError:
                steps_results = []

        steps_results.append(step_result)

        return self.update_status(
            execution_id,
            exec_data["status"],
            steps_results=steps_results
        )

    def add_log(
        self,
        execution_id: str,
        message: str,
        level: str = "INFO",
        step_name: Optional[str] = None
    ) -> bool:
        """
        Adiciona log à execução.

        Args:
            execution_id: ID da execução.
            message: Mensagem do log.
            level: Nível do log (DEBUG, INFO, WARNING, ERROR, CRITICAL).
            step_name: Nome do step (opcional).

        Returns:
            True se inserido com sucesso.
        """
        with self.engine.connect() as conn:
            conn.execute(
                text("""
                    INSERT INTO mymoney.execution_logs
                    (execution_id, level, message, step_name)
                    VALUES (:execution_id, :level, :message, :step_name)
                """),
                {
                    "execution_id": execution_id,
                    "level": level,
                    "message": message,
                    "step_name": step_name
                }
            )
            conn.commit()
            return True

    def get_logs(self, execution_id: str) -> List[str]:
        """
        Obtém logs da execução.

        Args:
            execution_id: ID da execução.

        Returns:
            Lista de mensagens de log formatadas.
        """
        with self.engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT level, message, step_name, created_at
                    FROM mymoney.execution_logs
                    WHERE execution_id = :execution_id
                    ORDER BY created_at ASC
                """),
                {"execution_id": execution_id}
            )
            logs = []
            for row in result.mappings():
                step_info = f"[{row['step_name']}] " if row["step_name"] else ""
                logs.append(f"[{row['created_at']}] [{row['level']}] {step_info}{row['message']}")
            return logs

    def cancel(self, execution_id: str) -> bool:
        """
        Cancela execução em andamento.

        Args:
            execution_id: ID da execução.

        Returns:
            True se cancelada com sucesso.
        """
        exec_data = self.get(execution_id)
        if not exec_data:
            return False

        if exec_data["status"] not in ["queued", "running"]:
            return False

        return self.update_status(
            execution_id,
            "cancelled",
            finished_at=datetime.now()
        )
