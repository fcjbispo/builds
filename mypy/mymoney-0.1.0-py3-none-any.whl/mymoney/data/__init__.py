import os
import json
import pandas as pd
from fbpyutils.uuid import hash_string
from datetime import datetime


def record_operations(file, db, params):
    results_file = file
    with open(results_file, 'r', encoding='utf-8') as f:
        results = json.load(f)

        operation_time = results_file.split(os.path.sep)[-1].split('.')[4].split('_')[-1]
        operation_time = datetime.strptime(operation_time, '%Y-%m-%dT%H-%M-%S')

    rows = []
    kinds = [p[3] for p in params]
    agent = params[0]
    for i, _ in enumerate(kinds):
        for data in results[i]:
            success, row = data
            row['success'] = success

            failures = row.get('failures', [])
            row['failures'] = len(failures) if failures is int else len(failures) if failures is list else 0 
            row['operation_date'] = operation_time
            row['agent'] = agent
            row['id'] = hash_string('.'.join(str(row[c]) for c in row.keys()))

            rows.append(row)

    operations = pd.DataFrame.from_dict(rows)
    operations = operations[['id'] + [c for c in operations.columns if c != 'id']].copy()
    operations.to_sql('operations', con=db, index=False, if_exists='append')