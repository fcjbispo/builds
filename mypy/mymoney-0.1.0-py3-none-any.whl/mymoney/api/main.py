"""
Entry point da API MyMoney.

Arquivo: mymoney/api/main.py

Uso:
    uv run python -m mymoney.api.main
    # ou
    uv run uvicorn mymoney.api.main:app --host 0.0.0.0 --port 9001 --reload
"""

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from mymoney import env, logger
from mymoney.api.routers import pipelines_router


# Configuração de CORS
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia ciclo de vida da aplicação."""
    logger.info("🚀 MyMoney API iniciando...")
    logger.info(f"   Database: {env.DB_URL.split('@')[-1] if '@' in env.DB_URL else 'local'}")
    logger.info(f"   API URL: http://{getattr(env, 'APP_BACKEND_HOST', '127.0.0.1')}:{getattr(env, 'APP_BACKEND_PORT', 9001)}")

    yield

    logger.info("👋 MyMoney API finalizando...")


# Criar aplicação FastAPI
app = FastAPI(
    title="MyMoney API",
    description="API REST para gerenciamento de pipelines e dados financeiros",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Health check
@app.get("/health")
async def health_check():
    """Endpoint de health check."""
    return {
        "status": "healthy",
        "version": "0.1.0",
        "database": "connected" if env.DB_URL else "not configured"
    }


# Root endpoint
@app.get("/")
async def root():
    """Endpoint raiz."""
    return {
        "message": "MyMoney API",
        "version": "0.1.0",
        "documentation": "/docs",
        "health": "/health"
    }


# Registrar routers
app.include_router(pipelines_router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn

    host = env.USER_CONFIG.get("APP_BACKEND_HOST") or getattr(env, "APP_BACKEND_HOST", "127.0.0.1")
    port = int(env.USER_CONFIG.get("APP_BACKEND_PORT") or getattr(env, "APP_BACKEND_PORT", 9001))

    uvicorn.run(
        "mymoney.api.main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )
