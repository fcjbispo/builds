# mymoney/api/__init__.py
"""MyMoney API module."""

__version__ = "0.1.0"
