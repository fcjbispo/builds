"""
Validação de configuração de pipelines.

Arquivo: mymoney/api/validation/pipeline.py
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from sqlalchemy import text
from sqlalchemy.engine import Engine
import json


@dataclass
class ValidationError:
    """Representa um erro de validação."""
    field: str
    message: str
    severity: str = "ERROR"  # ERROR, WARNING


@dataclass
class ValidationResult:
    """Resultado da validação de uma pipeline."""
    valid: bool
    errors: List[ValidationError] = field(default_factory=list)

    def add_error(self, field: str, message: str, severity: str = "ERROR"):
        """Adiciona um erro ao resultado."""
        self.errors.append(ValidationError(field, message, severity))

    @property
    def has_errors(self) -> bool:
        """Retorna True se houver erros (não apenas warnings)."""
        return any(e.severity == "ERROR" for e in self.errors)


class PipelineValidator:
    """Validador de configuração de pipelines."""

    def __init__(self, engine: Engine):
        """
        Inicializa o validador.

        Args:
            engine: Engine SQLAlchemy para conexão com o banco.
        """
        self.engine = engine

    def validate(self, config: Dict[str, Any]) -> ValidationResult:
        """
        Valida uma configuração de pipeline completa.

        Args:
            config: Dict com a configuração da pipeline.

        Returns:
            ValidationResult com o resultado da validação.
        """
        result = ValidationResult(valid=True)

        # 1. Validar estrutura básica
        self._validate_structure(config, result)
        if result.has_errors:
            result.valid = False
            return result

        # 2. Validar processors existem
        self._validate_processors(config, result)

        # 3. Validar dependências entre steps (DAG)
        self._validate_dependencies(config, result)

        # 4. Validar parâmetros dos steps
        self._validate_step_params(config, result)

        result.valid = not result.has_errors
        return result

    def _validate_structure(self, config: Dict[str, Any], result: ValidationResult):
        """Valida estrutura básica da configuração."""
        # Campos obrigatórios
        required_fields = ["id", "nome", "escopo", "steps"]
        for field in required_fields:
            if field not in config or config[field] is None:
                result.add_error(field, f"Campo obrigatório '{field}' não encontrado")

        # Validar steps é uma lista
        steps = config.get("steps", [])
        if not isinstance(steps, list):
            result.add_error("steps", "Steps deve ser uma lista")
            return

        if len(steps) == 0:
            result.add_error("steps", "Pipeline deve ter pelo menos um step")
            return

        # Validar cada step
        step_names = set()
        for idx, step in enumerate(steps):
            prefix = f"steps[{idx}]"

            if not isinstance(step, dict):
                result.add_error(prefix, "Step deve ser um objeto")
                continue

            # Campos obrigatórios do step
            if "name" not in step or not step["name"]:
                result.add_error(f"{prefix}.name", "Step deve ter um nome")
            elif step["name"] in step_names:
                result.add_error(f"{prefix}.name", f"Nome de step duplicado: '{step['name']}'")
            else:
                step_names.add(step["name"])

            if "processor" not in step or not step["processor"]:
                result.add_error(f"{prefix}.processor", "Step deve ter um processor")

    def _validate_processors(self, config: Dict[str, Any], result: ValidationResult):
        """Valida se os processors referenciados existem na tabela."""
        steps = config.get("steps", [])

        # Coletar todos os processors únicos
        processors_needed = set()
        for step in steps:
            if isinstance(step, dict) and "processor" in step:
                processors_needed.add(step["processor"])

        if not processors_needed:
            return

        # Verificar se existem no banco
        with self.engine.connect() as conn:
            for proc_name in processors_needed:
                result_db = conn.execute(
                    text("SELECT 1 FROM mymoney.processors WHERE nome = :nome"),
                    {"nome": proc_name}
                )
                if not result_db.fetchone():
                    result.add_error(
                        f"steps[*].processor",
                        f"Processor '{proc_name}' não encontrado na tabela processors",
                        "ERROR"
                    )

    def _validate_dependencies(self, config: Dict[str, Any], result: ValidationResult):
        """Valida dependências entre steps (verifica ciclos e referências)."""
        steps = config.get("steps", [])

        # Mapear nome -> índice
        step_map = {}
        for idx, step in enumerate(steps):
            if isinstance(step, dict) and "name" in step:
                step_map[step["name"]] = idx

        # Verificar dependências
        for idx, step in enumerate(steps):
            if not isinstance(step, dict):
                continue

            depends_on = step.get("depends_on", [])
            if not isinstance(depends_on, list):
                result.add_error(
                    f"steps[{idx}].depends_on",
                    "depends_on deve ser uma lista de strings"
                )
                continue

            for dep in depends_on:
                if dep not in step_map:
                    result.add_error(
                        f"steps[{idx}].depends_on",
                        f"Step dependente '{dep}' não existe"
                    )

        # Verificar ciclos (simplificado - DFS)
        if self._has_cycle(steps, step_map):
            result.add_error("steps", "Detectado ciclo nas dependências dos steps")

    def _has_cycle(self, steps: List[Dict], step_map: Dict[str, int]) -> bool:
        """Detecta ciclos no grafo de dependências usando DFS."""
        visited = set()
        rec_stack = set()

        def dfs(step_name: str) -> bool:
            if step_name in rec_stack:
                return True  # Ciclo detectado
            if step_name in visited:
                return False

            visited.add(step_name)
            rec_stack.add(step_name)

            # Obter índice do step
            idx = step_map.get(step_name)
            if idx is None or idx >= len(steps):
                rec_stack.remove(step_name)
                return False

            step = steps[idx]
            if isinstance(step, dict):
                for dep in step.get("depends_on", []):
                    if dfs(dep):
                        return True

            rec_stack.remove(step_name)
            return False

        # Verificar todos os steps
        for step in steps:
            if isinstance(step, dict) and "name" in step:
                if dfs(step["name"]):
                    return True

        return False

    def _validate_step_params(self, config: Dict[str, Any], result: ValidationResult):
        """Valida parâmetros dos steps contra schema dos processors."""
        # Implementação básica - pode ser estendida para validar contra JSON Schema
        steps = config.get("steps", [])

        for idx, step in enumerate(steps):
            if not isinstance(step, dict):
                continue

            params = step.get("parametros", {})
            if not isinstance(params, dict):
                result.add_error(
                    f"steps[{idx}].parametros",
                    "Parâmetros devem ser um objeto (dict)"
                )

    def validate_processor_params(
        self,
        processor_nome: str,
        params: Dict[str, Any]
    ) -> ValidationResult:
        """
        Valida parâmetros contra o schema de um processor específico.

        Args:
            processor_nome: Nome do processor.
            params: Parâmetros a validar.

        Returns:
            ValidationResult com o resultado.
        """
        result = ValidationResult(valid=True)

        with self.engine.connect() as conn:
            row = conn.execute(
                text("SELECT parametros_schema FROM mymoney.processors WHERE nome = :nome"),
                {"nome": processor_nome}
            ).fetchone()

            if not row:
                result.add_error("processor", f"Processor '{processor_nome}' não encontrado")
                result.valid = False
                return result

            schema = row[0] or {}
            if isinstance(schema, str):
                try:
                    schema = json.loads(schema)
                except json.JSONDecodeError:
                    schema = {}

            # Validação básica de required fields do schema
            required = schema.get("required", [])
            for field in required:
                if field not in params:
                    result.add_error(
                        f"parametros.{field}",
                        f"Campo obrigatório '{field}' não encontrado"
                    )

        result.valid = not result.has_errors
        return result
