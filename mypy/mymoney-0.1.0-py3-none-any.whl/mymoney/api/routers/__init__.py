# mymoney/api/routers/__init__.py

from mymoney.api.routers.pipelines import router as pipelines_router

__all__ = ["pipelines_router"]
