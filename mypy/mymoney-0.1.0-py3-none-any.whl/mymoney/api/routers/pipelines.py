"""
Router FastAPI para Pipelines API.

Arquivo: mymoney/api/routers/pipelines.py
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from mymoney import env
from mymoney.api.schemas.pipelines import (
    PipelineCreate, PipelineUpdate, PipelineResponse,
    PipelineExecuteRequest, PipelineExecutionResponse,
    ProcessorResponse
)
from mymoney.api.validation import PipelineValidator
from mymoney.data.repositories import PipelineRepository, ExecutionRepository


# Configuração do router
router = APIRouter(prefix="/pipelines", tags=["pipelines"])


# Dependência para obter engine do banco
def get_db_engine() -> Engine:
    """Retorna engine SQLAlchemy."""
    return create_engine(env.DB_URL)


# Dependência para obter usuário atual (placeholder - implementar com auth)
def get_current_user() -> str:
    """Retorna usuário atual."""
    return env.USER or "UNKNOWN"


@router.get("", response_model=List[PipelineResponse])
async def list_pipelines(
    escopo: Optional[str] = None,
    ativo: Optional[bool] = None,
    usuario: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    engine: Engine = Depends(get_db_engine)
):
    """Lista pipelines com filtros opcionais."""
    repo = PipelineRepository(engine)
    return repo.list(
        escopo=escopo,
        ativo=ativo,
        usuario=usuario,
        limit=limit,
        offset=offset
    )


@router.get("/{pipeline_id}", response_model=PipelineResponse)
async def get_pipeline(
    pipeline_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Obtém pipeline específica."""
    repo = PipelineRepository(engine)
    pipeline = repo.get(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline não encontrada")
    return pipeline


@router.post("", response_model=PipelineResponse, status_code=201)
async def create_pipeline(
    data: PipelineCreate,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Cria nova pipeline."""
    # Validar
    validator = PipelineValidator(engine)
    result = validator.validate(data.dict())
    if not result.valid:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "VALIDATION_ERROR",
                "message": "Configuração de pipeline inválida",
                "errors": [{"field": e.field, "message": e.message} for e in result.errors]
            }
        )

    # Verificar se já existe
    repo = PipelineRepository(engine)
    existing = repo.get(data.id)
    if existing:
        raise HTTPException(
            status_code=409,
            detail=f"Pipeline com ID '{data.id}' já existe"
        )

    return repo.create(data, usuario)


@router.put("/{pipeline_id}", response_model=PipelineResponse)
async def update_pipeline(
    pipeline_id: str,
    data: PipelineUpdate,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Atualiza pipeline existente."""
    repo = PipelineRepository(engine)

    # Verificar se existe
    existing = repo.get(pipeline_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Pipeline não encontrada")

    # Atualizar
    result = repo.update(pipeline_id, data, usuario)
    if not result:
        raise HTTPException(status_code=500, detail="Erro ao atualizar pipeline")

    return result


@router.patch("/{pipeline_id}", response_model=PipelineResponse)
async def patch_pipeline(
    pipeline_id: str,
    data: PipelineUpdate,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Atualização parcial de pipeline."""
    return await update_pipeline(pipeline_id, data, engine, usuario)


@router.delete("/{pipeline_id}", status_code=204)
async def delete_pipeline(
    pipeline_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Remove pipeline."""
    repo = PipelineRepository(engine)

    # Verificar se existe
    existing = repo.get(pipeline_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Pipeline não encontrada")

    # Deletar
    deleted = repo.delete(pipeline_id)
    if not deleted:
        raise HTTPException(status_code=500, detail="Erro ao deletar pipeline")

    return None


@router.post("/{pipeline_id}/clone", response_model=PipelineResponse)
async def clone_pipeline(
    pipeline_id: str,
    new_id: str,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Clona pipeline existente."""
    repo = PipelineRepository(engine)

    # Verificar se fonte existe
    source = repo.get(pipeline_id)
    if not source:
        raise HTTPException(status_code=404, detail="Pipeline fonte não encontrada")

    # Verificar se novo ID já existe
    existing = repo.get(new_id)
    if existing:
        raise HTTPException(
            status_code=409,
            detail=f"Pipeline com ID '{new_id}' já existe"
        )

    # Clonar
    result = repo.clone(pipeline_id, new_id, usuario)
    if not result:
        raise HTTPException(status_code=500, detail="Erro ao clonar pipeline")

    return result


@router.post("/{pipeline_id}/validate")
async def validate_pipeline(
    pipeline_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Valida configuração de pipeline sem salvar."""
    repo = PipelineRepository(engine)
    pipeline = repo.get(pipeline_id)

    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline não encontrada")

    validator = PipelineValidator(engine)
    result = validator.validate(pipeline)

    return {
        "valid": result.valid,
        "errors": [{"field": e.field, "message": e.message, "severity": e.severity}
                   for e in result.errors]
    }


@router.post("/import", response_model=PipelineResponse)
async def import_pipeline(
    data: PipelineCreate,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Importa pipeline de arquivo JSON (cria ou atualiza)."""
    # Mesma lógica de create, mas permite sobrescrever
    repo = PipelineRepository(engine)
    existing = repo.get(data.id)

    if existing:
        # Atualizar
        update_data = PipelineUpdate(**data.dict(exclude={"id"}))
        return repo.update(data.id, update_data, usuario)
    else:
        # Criar
        return repo.create(data, usuario)


# Endpoints de Execução

@router.post("/{pipeline_id}/execute", response_model=PipelineExecutionResponse)
async def execute_pipeline(
    pipeline_id: str,
    request: PipelineExecuteRequest,
    background_tasks: BackgroundTasks,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """
    Executa uma pipeline.
    Se async=false (padrão), aguarda conclusão e retorna resultado.
    Se async=true, enfileira para execução e retorna execution_id imediatamente.
    """
    repo = PipelineRepository(engine)
    pipeline = repo.get(pipeline_id)

    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline não encontrada")

    if not pipeline.get("ativo", True):
        raise HTTPException(status_code=400, detail="Pipeline está inativa")

    # Criar registro de execução
    exec_repo = ExecutionRepository(engine)
    execution_id = exec_repo.create(
        pipeline_id=pipeline_id,
        usuario=usuario,
        parametros=request.parametros
    )

    if request.async_execution:
        # Execução assíncrona: enfileira e retorna
        background_tasks.add_task(
            _execute_pipeline_task,
            engine,
            execution_id,
            pipeline,
            request.parametros
        )

        return {
            "execution_id": execution_id,
            "pipeline_id": pipeline_id,
            "status": "queued",
            "started_at": None,
            "finished_at": None,
            "message": "Pipeline enfileirada para execução"
        }
    else:
        # Execução síncrona
        return await _execute_pipeline_sync(
            engine,
            execution_id,
            pipeline,
            request.parametros,
            request.timeout
        )


@router.post("/{pipeline_id}/execute/async", response_model=PipelineExecutionResponse)
async def execute_pipeline_async(
    pipeline_id: str,
    request: PipelineExecuteRequest,
    background_tasks: BackgroundTasks,
    engine: Engine = Depends(get_db_engine),
    usuario: str = Depends(get_current_user)
):
    """Executa pipeline de forma assíncrona (shortcut para async=true)."""
    request.async_execution = True
    return await execute_pipeline(
        pipeline_id, request, background_tasks, engine, usuario
    )


@router.get("/{pipeline_id}/executions", response_model=List[PipelineExecutionResponse])
async def list_pipeline_executions(
    pipeline_id: str,
    limit: int = 20,
    offset: int = 0,
    status: Optional[str] = None,
    engine: Engine = Depends(get_db_engine)
):
    """Lista execuções da pipeline (histórico)."""
    repo = ExecutionRepository(engine)
    return repo.list_by_pipeline(pipeline_id, limit=limit, offset=offset, status=status)


@router.get("/{pipeline_id}/executions/{execution_id}", response_model=PipelineExecutionResponse)
async def get_pipeline_execution(
    pipeline_id: str,
    execution_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Obtém status/resultado de execução específica."""
    repo = ExecutionRepository(engine)
    execution = repo.get(execution_id)

    if not execution:
        raise HTTPException(status_code=404, detail="Execução não encontrada")

    if execution.get("pipeline_id") != pipeline_id:
        raise HTTPException(
            status_code=404,
            detail="Execução não pertence a esta pipeline"
        )

    return execution


@router.get("/{pipeline_id}/executions/{execution_id}/logs")
async def get_pipeline_execution_logs(
    pipeline_id: str,
    execution_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Obtém logs da execução."""
    repo = ExecutionRepository(engine)

    # Verificar se execução existe
    execution = repo.get(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execução não encontrada")

    if execution.get("pipeline_id") != pipeline_id:
        raise HTTPException(
            status_code=404,
            detail="Execução não pertence a esta pipeline"
        )

    logs = repo.get_logs(execution_id)
    return {"execution_id": execution_id, "logs": logs}


@router.post("/{pipeline_id}/executions/{execution_id}/cancel")
async def cancel_pipeline_execution(
    pipeline_id: str,
    execution_id: str,
    engine: Engine = Depends(get_db_engine)
):
    """Cancela execução em andamento."""
    repo = ExecutionRepository(engine)

    execution = repo.get(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execução não encontrada")

    if execution.get("pipeline_id") != pipeline_id:
        raise HTTPException(
            status_code=404,
            detail="Execução não pertence a esta pipeline"
        )

    result = repo.cancel(execution_id)
    if not result:
        raise HTTPException(
            status_code=400,
            detail="Não foi possível cancelar a execução (já concluída ou não encontrada)"
        )

    return {"execution_id": execution_id, "status": "cancelled"}


# Endpoints de Processors

@router.get("/processors/available", response_model=List[ProcessorResponse])
async def list_processors(
    tipo: Optional[str] = None,
    engine: Engine = Depends(get_db_engine)
):
    """Lista processors disponíveis."""
    from sqlalchemy import text

    query = "SELECT * FROM mymoney.processors"
    params = {}

    if tipo:
        query += " WHERE tipo = :tipo"
        params["tipo"] = tipo

    query += " ORDER BY nome"

    with engine.connect() as conn:
        result = conn.execute(text(query), params)
        return [dict(row) for row in result.mappings()]


# Funções auxiliares

async def _execute_pipeline_sync(
    engine: Engine,
    execution_id: str,
    pipeline: dict,
    parametros: dict,
    timeout: int
) -> PipelineExecutionResponse:
    """Executa pipeline de forma síncrona."""
    from mymoney.pipelines.executor import PipelineExecutor

    exec_repo = ExecutionRepository(engine)

    try:
        # Marcar como iniciada
        exec_repo.start_execution(execution_id)

        # Executar
        executor = PipelineExecutor(engine)
        result = await executor.execute(
            pipeline_id=pipeline["id"],
            parametros=parametros,
            execution_id=execution_id
        )

        # Atualizar como concluída
        exec_repo.complete_execution(
            execution_id=execution_id,
            success=result.get("success", False),
            records_processed=result.get("records_processed", 0),
            records_inserted=result.get("records_inserted", 0),
            records_failed=result.get("records_failed", 0),
            steps_results=result.get("steps_results", [])
        )

        return exec_repo.get(execution_id)

    except Exception as e:
        # Marcar como falha
        exec_repo.complete_execution(
            execution_id=execution_id,
            success=False,
            error_message=str(e)
        )
        raise HTTPException(status_code=500, detail=str(e))


def _execute_pipeline_task(
    engine: Engine,
    execution_id: str,
    pipeline: dict,
    parametros: dict
):
    """Task de execução assíncrona (background)."""
    import asyncio

    exec_repo = ExecutionRepository(engine)

    try:
        # Marcar como iniciada
        exec_repo.start_execution(execution_id)

        # Executar (chamar executor)
        # TODO: Implementar execução real via PipelineExecutor
        # Por enquanto, apenas simula
        import time
        time.sleep(5)  # Simular processamento

        # Marcar como concluída
        exec_repo.complete_execution(
            execution_id=execution_id,
            success=True,
            records_processed=100,
            records_inserted=100,
            records_failed=0
        )

    except Exception as e:
        exec_repo.complete_execution(
            execution_id=execution_id,
            success=False,
            error_message=str(e)
        )
