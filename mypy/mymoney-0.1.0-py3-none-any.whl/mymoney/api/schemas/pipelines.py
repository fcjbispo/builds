"""
Schemas Pydantic para Pipelines API.

Arquivo: mymoney/api/schemas/pipelines.py
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


class PipelineStep(BaseModel):
    """Representa um step em uma pipeline."""
    name: str = Field(..., min_length=1, description="Nome identificador do step")
    processor: str = Field(..., min_length=1, description="Nome curto do processor (coluna `nome` da tabela processors)")
    depends_on: List[str] = Field(default_factory=list, description="Nomes dos steps dependentes")
    parametros: Dict[str, Any] = Field(default_factory=dict, description="Parâmetros específicos do step. Ex: use_native_pdf, output_format, etc.")
    condicao: Optional[str] = Field(None, description="Expressão condicional opcional para execução")


class PipelineBase(BaseModel):
    """Base para todas as operações de pipeline."""
    nome: str = Field(..., min_length=1, max_length=255, description="Nome amigável da pipeline")
    descricao: Optional[str] = Field(None, description="Descrição opcional")
    escopo: str = Field(..., min_length=1, description="Escopo (ex: inter, nubank, cei, data)")
    ativo: bool = Field(True, description="Flag de ativação")
    steps: List[PipelineStep] = Field(default_factory=list, description="Array de steps")
    parametros: Dict[str, Any] = Field(default_factory=dict, description="Parâmetros globais")


class PipelineCreate(PipelineBase):
    """Request para criação de pipeline."""
    id: Optional[str] = Field(None, min_length=1, max_length=100, pattern=r'^[a-z0-9-_]+$', description="Identificador único. Se não fornecido, será gerado automaticamente a partir do nome.")

    def generate_id(self) -> str:
        """Gera ID hash a partir do nome."""
        from fbpyutils.uuid import hash_string
        return hash_string(self.nome)


class PipelineUpdate(BaseModel):
    """Request para atualização parcial de pipeline."""
    nome: Optional[str] = Field(None, min_length=1)
    descricao: Optional[str] = None
    ativo: Optional[bool] = None
    steps: Optional[List[PipelineStep]] = None
    parametros: Optional[Dict[str, Any]] = None


class PipelineResponse(PipelineBase):
    """Response com dados completos da pipeline."""
    id: str
    created_at: datetime
    updated_at: datetime
    usuario: str
    versao: int

    class Config:
        from_attributes = True


class PipelineExecuteRequest(BaseModel):
    """Request para execução de pipeline."""
    parametros: Dict[str, Any] = Field(default_factory=dict, description="Parâmetros para sobrescrever os globais")
    async_execution: bool = Field(default=False, alias="async", description="Se true, executa assincronamente")
    timeout: int = Field(default=300, ge=1, le=3600, description="Timeout em segundos para execução síncrona")

    class Config:
        populate_by_name = True


class PipelineStepResult(BaseModel):
    """Resultado de execução de um step."""
    name: str = Field(..., description="Nome do step")
    status: str = Field(..., description="Status: completed, failed, skipped")
    records: Optional[int] = Field(None, description="Registros processados (compatibilidade)")
    records_processed: Optional[int] = Field(None, description="Total de registros processados")
    records_inserted: Optional[int] = Field(None, description="Registros inseridos")
    records_failed: Optional[int] = Field(None, description="Registros com falha")
    duration_ms: Optional[int] = Field(None, description="Duração em milissegundos")
    error_message: Optional[str] = Field(None, description="Mensagem de erro em caso de falha")


class PipelineExecutionResponse(BaseModel):
    """Response de execução de pipeline."""
    execution_id: str = Field(..., description="ID único da execução")
    pipeline_id: str = Field(..., description="ID da pipeline")
    status: str = Field(..., description="Status: queued, running, completed, failed, cancelled")
    current_step: Optional[str] = Field(None, description="Step atual em execução")
    progress_percent: Optional[int] = Field(None, ge=0, le=100, description="Percentual de progresso")
    started_at: Optional[datetime] = Field(None, description="Data de início")
    finished_at: Optional[datetime] = Field(None, description="Data de término")
    estimated_finish: Optional[datetime] = Field(None, description="Estimativa de término")
    duration_ms: Optional[int] = Field(None, description="Duração total em milissegundos")
    success: Optional[bool] = Field(None, description="Sucesso da execução")
    records_processed: Optional[int] = Field(None, description="Total de registros processados")
    records_inserted: Optional[int] = Field(None, description="Registros inseridos")
    records_failed: Optional[int] = Field(None, description="Registros com falha")
    steps_results: List[PipelineStepResult] = Field(default_factory=list, description="Resultados por step")
    logs: List[str] = Field(default_factory=list, description="Logs da execução (resumo)")
    message: Optional[str] = Field(None, description="Mensagem adicional")

    class Config:
        from_attributes = True


class PipelineImportResponse(BaseModel):
    """Response de importação de pipelines."""
    imported: int = Field(..., description="Número de pipelines importadas")
    updated: int = Field(..., description="Número de pipelines atualizadas")
    skipped: int = Field(..., description="Número de pipelines ignoradas")
    errors: List[Dict[str, Any]] = Field(default_factory=list, description="Lista de erros")


class ProcessorSchema(BaseModel):
    """Schema JSON de parâmetros de um processor."""
    type: str = "object"
    properties: Dict[str, Any] = Field(default_factory=dict)
    required: List[str] = Field(default_factory=list)


class ProcessorBase(BaseModel):
    """Base para processors."""
    nome: str = Field(..., min_length=1, description="Nome curto (ex: inter_cartao)")
    modulo: str = Field(..., description="Caminho do módulo Python")
    classe: str = Field(..., description="Nome da classe")
    descricao: Optional[str] = Field(None, description="Descrição")
    tipo: str = Field(..., description="Tipo: extract, transform, load, utility")
    parametros_schema: Dict[str, Any] = Field(default_factory=dict, description="JSON Schema dos parâmetros")


class ProcessorCreate(ProcessorBase):
    """Request para criação de processor."""
    id: str = Field(..., min_length=1, description="Identificador único")


class ProcessorResponse(ProcessorBase):
    """Response com dados do processor."""
    id: str
    created_at: datetime

    class Config:
        from_attributes = True


class ProcessorValidateRequest(BaseModel):
    """Request para validação de parâmetros de processor."""
    parametros: Dict[str, Any] = Field(..., description="Parâmetros a validar")


class ProcessorValidateResponse(BaseModel):
    """Response de validação de parâmetros."""
    valid: bool = Field(..., description="Se os parâmetros são válidos")
    errors: List[str] = Field(default_factory=list, description="Lista de erros de validação")
