"""
My Personal Finance Management System.
"""

import os
import json
import getpass
import logging
import warnings
from datetime import datetime
from sqlalchemy import create_engine
from dotenv import load_dotenv
from fbpyutils import setup, get_env, get_logger
from fbpyutils.process import Process
from fbpyutils_db.database.schema import get_schemas

# Suprimir warnings específicos que poluem a interface
# openpyxl: "Workbook contains no default style"
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")
# Outros warnings comuns de bibliotecas de dados
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_USER_HOME_DIR = os.path.expanduser("~")
_USER_NAME = getpass.getuser()
_USER_APP_FOLDER = os.path.sep.join([_USER_HOME_DIR, ".mymoney"])

setup(os.path.sep.join([_ROOT_DIR, "app.json"]))

env = get_env()
logger = get_logger()

env.DB_URL = os.getenv("MM_DB_URL", f"sqlite:///{_USER_APP_FOLDER}/mymoney.db")
env.ROOT_FOLDER = _ROOT_DIR
env.USER = _USER_NAME.upper()
env.USER_APP_FOLDER = _USER_APP_FOLDER
env.OPERATIONS_FOLDER = os.path.sep.join([_USER_APP_FOLDER, "operations"])
env.PIPELINES_FOLDER = os.path.sep.join([_USER_APP_FOLDER, "pipelines"])
env.LOGS_FOLDER = os.path.sep.join([_USER_APP_FOLDER, "logs"])
env.SCHEMAS = get_schemas(
    os.path.sep.join([_ROOT_DIR, "data", "schemas"])
)

env.PARALLELIZABLE = Process.is_parallelizable()
_parallel_cpu_factor = max(1, int(os.getenv("MM_PARALLEL_CPU_FACTOR", "1") or "1"))
env.PARALLEL_CPU_COUNT = int(
    os.cpu_count() / _parallel_cpu_factor
    if os.cpu_count() and os.cpu_count() > 1 else 1
) if env.PARALLELIZABLE else 1

os.makedirs(_USER_APP_FOLDER, exist_ok=True)
os.makedirs(env.OPERATIONS_FOLDER, exist_ok=True)
os.makedirs(env.PIPELINES_FOLDER, exist_ok=True)
os.makedirs(env.LOGS_FOLDER, exist_ok=True)


def _normalize_config_keys(config: dict | None) -> dict:
    if not isinstance(config, dict):
        return {}

    normalized: dict = {}
    for key, value in config.items():
        normalized_key = str(key)
        if normalized_key.startswith("MM_"):
            normalized_key = normalized_key[3:]
        normalized[normalized_key] = value

    if (
        "LLM_API_BASE_URL" not in normalized
        and "LLM_BASE_URL" in normalized
    ):
        normalized["LLM_API_BASE_URL"] = normalized["LLM_BASE_URL"]

    return normalized


def _apply_runtime_log_level(log_level: str | None) -> None:
    level_name = str(log_level or "").strip().upper()
    if not level_name:
        return
    level = getattr(logging, level_name, None)
    if not isinstance(level, int):
        logger.warning(f"Invalid LOG_LEVEL '{log_level}', keeping current logger level.")
        return

    try:
        logger.setLevel(level)
    except Exception:
        pass

    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    for handler in list(root_logger.handlers) + list(getattr(logger, "handlers", [])):
        try:
            handler.setLevel(level)
        except Exception:
            continue


def _configure_runtime_logger() -> None:
    configured_level = str(env.USER_CONFIG.get("LOG_LEVEL") or env.LOG_LEVEL or "INFO")
    configured_file = str(
        env.USER_CONFIG.get("LOG_FILE")
        or env.USER_CONFIG.get("LOG_FILE_PATH")
        or env.LOG_FILE
        or os.path.sep.join([env.LOGS_FOLDER, "app.log"])
    )
    configured_handlers = env.USER_CONFIG.get("LOG_HANDLERS")
    if not configured_handlers:
        configured_handlers = ["console", "file"]

    env.LOG_LEVEL = configured_level
    env.LOG_FILE = configured_file
    env.LOG_HANDLERS = configured_handlers
    logger.configure_from_env(env)


def emit_debug_trace(message: str) -> None:
    enabled = bool(
        str(os.getenv("MM_DEBUG_TRACE") or env.USER_CONFIG.get("DEBUG_TRACE") or "")
        .strip()
        .lower()
        in ("1", "true", "yes", "on")
    )
    if not enabled:
        return

    try:
        os.makedirs(env.LOGS_FOLDER, exist_ok=True)
        trace_file = os.path.sep.join([env.LOGS_FOLDER, "trace.log"])
        with open(trace_file, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} {message}\n")
    except Exception:
        return

# NOTE: _DEFAULT_PIPELINE_CONTRACTS foi removido conforme PROMPT 017.
# Pipelines devem ser migradas para o banco de dados via comando 'mymoney pipelines migrate'.

_config_file = os.path.sep.join([env.USER_APP_FOLDER, "config.json"])
if not os.path.exists(_config_file) and not os.getenv("MM_DB_URL"):
    logger.critical(f"User configuration file not found: {_config_file}")
    raise FileNotFoundError(
        f"User configuration file not found: {_config_file}. "
        "Please create it before running the application.")

if os.path.exists(_config_file):
    try:
        logger.info(f"Loading user configuration file: {_config_file}")
        with open(_config_file, "r", encoding="utf-8") as f:
            env.USER_CONFIG = _normalize_config_keys(json.load(f))
    except Exception as e:
        logger.critical(f"Unable to load user configuration file: {e}")
        raise e
else:
    env.USER_CONFIG = {}

# Sobrescrever config.json com variáveis de ambiente MM_* se existirem
_env_overrides = {
    "DB_URL": os.getenv("MM_DB_URL"),
    "VECTORDB_URL": os.getenv("MM_VECTORDB_URL"),
    "DATA_FOLDER": os.getenv("MM_DATA_FOLDER"),
    "DATA_FOLDER_CEI": os.getenv("MM_DATA_FOLDER_CEI"),
    "DEFAULT_CURRENCY": os.getenv("MM_DEFAULT_CURRENCY"),
    "LOG_LEVEL": os.getenv("MM_LOG_LEVEL"),
    "APP_BACKEND_HOST": os.getenv("MM_APP_BACKEND_HOST"),
    "APP_BACKEND_PORT": os.getenv("MM_APP_BACKEND_PORT"),
    "PDF_PASSWORD": os.getenv("MM_PDF_PASSWORD"),
    "NEXT_PDF_PASSWORD": os.getenv("MM_NEXT_PDF_PASSWORD"),
    "LLM_PROVIDER": os.getenv("MM_LLM_PROVIDER"),
    "LLM_API_BASE_URL": os.getenv("MM_LLM_API_BASE_URL"),
    "LLM_BASE_URL": os.getenv("MM_LLM_BASE_URL"),
    "LLM_API_KEY": os.getenv("MM_LLM_API_KEY"),
    "LLM_BASE_MODEL": os.getenv("MM_LLM_BASE_MODEL"),
    "LLM_VISION_MODEL": os.getenv("MM_LLM_VISION_MODEL"),
    "LLM_EMBED_MODEL": os.getenv("MM_LLM_EMBED_MODEL"),
    "LLM_EMBED_VECTOR_DIMENSION": os.getenv("MM_LLM_EMBED_VECTOR_DIMENSION"),
    "LLM_TIMEOUT": os.getenv("MM_LLM_TIMEOUT"),
    "LLM_RETRIES": os.getenv("MM_LLM_RETRIES"),
    "LLM_EXTRACTION_MAX_ATTEMPTS": os.getenv("MM_LLM_EXTRACTION_MAX_ATTEMPTS"),
    "LLM_EXTRACTION_RETRY_DELAY_SECONDS": os.getenv("MM_LLM_EXTRACTION_RETRY_DELAY_SECONDS"),
    "DOCLING_OCR_ENGINE": os.getenv("MM_DOCLING_OCR_ENGINE"),
}
_sensitive_markers = ("PASSWORD", "SECRET", "TOKEN", "API_KEY")
for key, value in _env_overrides.items():
    if value is not None:
        env.USER_CONFIG[key] = value
        visible_value = (
            "<hidden>"
            if any(marker in key.upper() for marker in _sensitive_markers)
            else value
        )
        logger.info(f"Environment override for {key}: {visible_value}")

# Configurações com defaults
env.USER_CONFIG.setdefault("LLM_EMBED_VECTOR_DIMENSION", 768)

_configure_runtime_logger()
_apply_runtime_log_level(env.USER_CONFIG.get("LOG_LEVEL"))
emit_debug_trace("mymoney bootstrap initialized")
logger.debug(
    "Runtime configuration loaded. data_folder=%s, inter_folder=%s, inter_global_folder=%s, "
    "inter_apex_folder=%s, inter_apex_nc_folder=%s, picpay_folder=%s, llm_provider=%s, llm_base_model=%s",
    env.USER_CONFIG.get("DATA_FOLDER"),
    env.USER_CONFIG.get("INTER_DATA_FOLDER"),
    env.USER_CONFIG.get("INTER_GLOBAL_DATA_FOLDER"),
    env.USER_CONFIG.get("INTER_APEX_DATA_FOLDER"),
    env.USER_CONFIG.get("INTER_APEX_NC_DATA_FOLDER"),
    env.USER_CONFIG.get("PICPAY_DATA_FOLDER"),
    env.USER_CONFIG.get("LLM_PROVIDER"),
    env.USER_CONFIG.get("LLM_BASE_MODEL"),
)

# Retrocompatibilidade: LLM_BASE_URL -> LLM_API_BASE_URL
if (
    not env.USER_CONFIG.get("LLM_API_BASE_URL")
    and env.USER_CONFIG.get("LLM_BASE_URL")
):
    env.USER_CONFIG["LLM_API_BASE_URL"] = env.USER_CONFIG.get("LLM_BASE_URL")

_data_folder = env.USER_CONFIG.get("DATA_FOLDER")
if _data_folder:
    _scope_folders = {
        "CEI_DATA_FOLDER": "CEI",
        "INTER_DATA_FOLDER": "INTER",
        "INTER_GLOBAL_DATA_FOLDER": "INTER_GLOBAL",
        "INTER_APEX_DATA_FOLDER": "INTER_APEX",
        "INTER_APEX_NC_DATA_FOLDER": "INTER_APEX_NC",
        "PICPAY_DATA_FOLDER": "PICPAY",
        "MERCADO_PAGO_DATA_FOLDER": "MERCADO_PAGO",
        "NUBANK_DATA_FOLDER": "NUBANK",
        "NEXT_DATA_FOLDER": "NEXT",
    }
    for _config_key, _subfolder in _scope_folders.items():
        env.USER_CONFIG.setdefault(
            _config_key,
            os.path.sep.join([_data_folder, _subfolder]),
        )

# Usar DB_URL do USER_CONFIG se disponível (sobrescreve config.json)
_final_db_url = env.USER_CONFIG.get("DB_URL", env.DB_URL)
try:
    env.DB_ENGINE = create_engine(_final_db_url)
except Exception as e:
    logger.critical(f"Unable to connect/create system database: {e}")
    raise SystemError(f"Unable to connect/create system database: {e}.")

# Usar o mesmo DB_ENGINE para operações
env.OP_DB_ENGINE = env.DB_ENGINE
