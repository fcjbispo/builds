"""
Cliente HTTP para a API do MyMoney.

Arquivo: mymoney/cli/client.py
"""

import json
from typing import Optional, Dict, Any, List
import httpx
from mymoney import env, logger


class APIClientError(Exception):
    """Erro do cliente da API."""
    pass


class APIClient:
    """Cliente HTTP para a API do MyMoney."""

    def __init__(self, base_url: Optional[str] = None, timeout: int = 300):
        """
        Inicializa o cliente.

        Args:
            base_url: URL base da API (ex: http://localhost:9001/api/v1).
                     Se não fornecido, tenta detectar automaticamente.
            timeout: Timeout padrão em segundos.
        """
        self.base_url = base_url or self._detect_api_url()
        self.timeout = timeout
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _detect_api_url(self) -> str:
        """Detecta URL da API baseada nas configurações."""
        # Tentar variável de ambiente
        api_url = getattr(env, "API_BASE_URL", None)
        if api_url:
            return api_url

        # Default: localhost na porta configurada para backend
        backend_port = getattr(env, "APP_BACKEND_PORT", 9001)
        return f"http://localhost:{backend_port}/api/v1"

    def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Faz requisição HTTP."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"

        try:
            response = httpx.request(
                method=method,
                url=url,
                json=json_data,
                params=params,
                headers=self.headers,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            error_detail = ""
            try:
                error_detail = e.response.json()
            except:
                error_detail = e.response.text
            raise APIClientError(f"Erro HTTP {e.response.status_code}: {error_detail}")
        except httpx.ConnectError as e:
            raise APIClientError(
                f"Não foi possível conectar à API em {self.base_url}. "
                "Verifique se o servidor está rodando."
            )
        except Exception as e:
            raise APIClientError(f"Erro na requisição: {e}")

    # === Pipelines ===

    def list_pipelines(
        self,
        escopo: Optional[str] = None,
        ativo: Optional[bool] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Lista pipelines."""
        params = {"limit": limit}
        if escopo:
            params["escopo"] = escopo
        if ativo is not None:
            params["ativo"] = ativo
        return self._request("GET", "/pipelines", params=params)

    def get_pipeline(self, pipeline_id: str) -> Dict:
        """Obtém pipeline por ID."""
        return self._request("GET", f"/pipelines/{pipeline_id}")

    def create_pipeline(self, data: Dict) -> Dict:
        """Cria nova pipeline."""
        return self._request("POST", "/pipelines", json_data=data)

    def update_pipeline(self, pipeline_id: str, data: Dict) -> Dict:
        """Atualiza pipeline."""
        return self._request("PUT", f"/pipelines/{pipeline_id}", json_data=data)

    def delete_pipeline(self, pipeline_id: str) -> bool:
        """Remove pipeline."""
        try:
            self._request("DELETE", f"/pipelines/{pipeline_id}")
            return True
        except APIClientError as e:
            if "404" in str(e):
                return False
            raise

    def clone_pipeline(self, source_id: str, new_id: str) -> Dict:
        """Clona pipeline."""
        return self._request(
            "POST",
            f"/pipelines/{source_id}/clone",
            params={"new_id": new_id}
        )

    def validate_pipeline(self, pipeline_id: str) -> Dict:
        """Valida configuração de pipeline."""
        return self._request("POST", f"/pipelines/{pipeline_id}/validate")

    def execute_pipeline(
        self,
        pipeline_id: str,
        parametros: Optional[Dict] = None,
        async_exec: bool = False,
        timeout: int = 300
    ) -> Dict:
        """Executa pipeline."""
        data = {
            "parametros": parametros or {},
            "async": async_exec,
            "timeout": timeout
        }
        if async_exec:
            return self._request("POST", f"/pipelines/{pipeline_id}/execute/async", json_data=data)
        return self._request("POST", f"/pipelines/{pipeline_id}/execute", json_data=data)

    def get_execution(self, pipeline_id: str, execution_id: str) -> Dict:
        """Obtém status de execução."""
        return self._request("GET", f"/pipelines/{pipeline_id}/executions/{execution_id}")

    def list_executions(
        self,
        pipeline_id: str,
        status: Optional[str] = None,
        limit: int = 20
    ) -> List[Dict]:
        """Lista execuções de uma pipeline."""
        params = {"limit": limit}
        if status:
            params["status"] = status
        return self._request("GET", f"/pipelines/{pipeline_id}/executions", params=params)

    def get_execution_logs(self, pipeline_id: str, execution_id: str) -> Dict:
        """Obtém logs de uma execução."""
        return self._request("GET", f"/pipelines/{pipeline_id}/executions/{execution_id}/logs")

    def cancel_execution(self, pipeline_id: str, execution_id: str) -> Dict:
        """Cancela execução."""
        return self._request("POST", f"/pipelines/{pipeline_id}/executions/{execution_id}/cancel")

    def import_pipeline(self, data: Dict) -> Dict:
        """Importa pipeline (cria ou atualiza)."""
        return self._request("POST", "/pipelines/import", json_data=data)

    # === Processors ===

    def list_processors(self, tipo: Optional[str] = None) -> List[Dict]:
        """Lista processors disponíveis."""
        params = {}
        if tipo:
            params["tipo"] = tipo
        return self._request("GET", "/pipelines/processors/available", params=params)
