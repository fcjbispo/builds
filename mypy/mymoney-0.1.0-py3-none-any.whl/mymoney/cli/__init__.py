# mymoney/cli/__init__.py
"""CLI como cliente da API."""
