"""
Comandos CLI para gerenciamento de pipelines.

Arquivo: mymoney/cli/commands/pipelines.py
"""

import argparse
import json
import sys
from typing import Optional

from mymoney.cli.client import APIClient, APIClientError


def _print_json(data):
    """Imprime dados em formato JSON."""
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


def _print_table(headers, rows):
    """Imprime dados em formato de tabela."""
    # Calcular larguras
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))

    # Imprimir header
    header_line = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    print(header_line)
    print("-" * len(header_line))

    # Imprimir rows
    for row in rows:
        print(" | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row)))


def cmd_pipelines_list(args: argparse.Namespace) -> int:
    """Lista pipelines."""
    client = APIClient(base_url=args.api_url)

    try:
        pipelines = client.list_pipelines(
            escopo=args.scope,
            ativo=args.active,
            limit=args.limit
        )

        if args.format == "json":
            _print_json({
                "count": len(pipelines),
                "pipelines": pipelines
            })
        else:
            # Formato tabela
            headers = ["ID", "Nome", "Escopo", "Ativo", "Versão", "Atualizado"]
            rows = []
            for p in pipelines:
                rows.append([
                    p.get("id", "N/A"),
                    p.get("nome", "N/A"),
                    p.get("escopo", "N/A"),
                    "Sim" if p.get("ativo") else "Não",
                    str(p.get("versao", "N/A")),
                    p.get("updated_at", "N/A")[:19] if p.get("updated_at") else "N/A"
                ])
            _print_table(headers, rows)

        return 0
    except APIClientError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_get(args: argparse.Namespace) -> int:
    """Obtém uma pipeline pelo nome."""
    client = APIClient(base_url=args.api_url)

    try:
        # Buscar pipeline por nome
        pipeline = client.get_pipeline_by_name(args.pipeline_name)

        if args.format == "json":
            _print_json(pipeline)
        else:
            print(f"\n📋 Pipeline: {pipeline.get('nome')}")
            print(f"   ID: {pipeline.get('id')}")
            print(f"   Escopo: {pipeline.get('escopo')}")
            print(f"   Ativo: {'Sim' if pipeline.get('ativo') else 'Não'}")
            print(f"   Versão: {pipeline.get('versao')}")
            print(f"   Criado em: {pipeline.get('created_at')}")
            print(f"   Atualizado em: {pipeline.get('updated_at')}")
            print(f"\n   Steps ({len(pipeline.get('steps', []))}):")
            for step in pipeline.get("steps", []):
                print(f"      • {step.get('name')}: {step.get('processor')}")
                if step.get("depends_on"):
                    print(f"        Dependências: {', '.join(step['depends_on'])}")

        return 0
    except APIClientError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_create(args: argparse.Namespace) -> int:
    """Cria uma nova pipeline a partir de arquivo JSON."""
    client = APIClient(base_url=args.api_url)

    try:
        with open(args.file, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Detectar formato legado (contrato antigo)
        campos_antigos = ["processor", "scope", "schema", "table_name", "provider"]
        campos_novos = ["id", "nome", "escopo", "steps"]

        tem_campos_antigos = any(k in data for k in campos_antigos)
        falta_campos_novos = not all(k in data for k in campos_novos[:3])  # id, nome, escopo

        if tem_campos_antigos or falta_campos_novos:
            print(f"⚠️  Arquivo '{args.file}' parece estar no formato legado.", file=sys.stderr)
            print(f"   O comando 'create' espera o novo formato (com 'id', 'nome', 'escopo', 'steps').", file=sys.stderr)
            print(f"\n💡 Para importar pipelines do formato legado, use:", file=sys.stderr)
            print(f"   mymoney pipelines migrate {data.get('processor', data.get('scope', ''))}", file=sys.stderr)
            print(f"\n   Ou para migrar todos:", file=sys.stderr)
            print(f"   mymoney pipelines migrate", file=sys.stderr)
            return 1

        pipeline = client.create_pipeline(data)

        print(f"✅ Pipeline criada com sucesso!")
        print(f"   ID: {pipeline.get('id')}")
        print(f"   Nome: {pipeline.get('nome')}")
        print(f"   Versão: {pipeline.get('versao')}")

        return 0
    except FileNotFoundError:
        print(f"❌ Erro: Arquivo não encontrado: {args.file}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as e:
        print(f"❌ Erro: JSON inválido em {args.file}: {e}", file=sys.stderr)
        return 1
    except APIClientError as e:
        error_str = str(e)
        # Detectar erro 422 de validação por campos obrigatórios ausentes
        if "422" in error_str and any(c in error_str for c in ["nome", "escopo", "id", "steps"]):
            print(f"⚠️  Erro de validação: o arquivo não contém os campos obrigatórios.", file=sys.stderr)
            print(f"   O comando 'create' espera o novo formato (com 'id', 'nome', 'escopo', 'steps').", file=sys.stderr)
            print(f"\n💡 Para importar pipelines do formato legado, use:", file=sys.stderr)
            print(f"   mymoney pipelines migrate <pipeline_id>", file=sys.stderr)
            print(f"\n   Ou para migrar todos:", file=sys.stderr)
            print(f"   mymoney pipelines migrate", file=sys.stderr)
        else:
            print(f"❌ Erro da API: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_update(args: argparse.Namespace) -> int:
    """Atualiza uma pipeline a partir de arquivo JSON."""
    client = APIClient(base_url=args.api_url)

    try:
        with open(args.file, "r", encoding="utf-8") as f:
            data = json.load(f)

        pipeline = client.update_pipeline(args.pipeline_id, data)

        print(f"✅ Pipeline atualizada com sucesso!")
        print(f"   ID: {pipeline.get('id')}")
        print(f"   Versão: {pipeline.get('versao')}")

        return 0
    except FileNotFoundError:
        print(f"❌ Erro: Arquivo não encontrado: {args.file}", file=sys.stderr)
        return 1
    except APIClientError as e:
        print(f"❌ Erro da API: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_delete(args: argparse.Namespace) -> int:
    """Remove uma pipeline."""
    client = APIClient(base_url=args.api_url)

    try:
        if not args.yes:
            response = input(f"Tem certeza que deseja remover a pipeline '{args.pipeline_id}'? [s/N]: ")
            if response.lower() not in ["s", "sim", "y", "yes"]:
                print("Operação cancelada.")
                return 0

        success = client.delete_pipeline(args.pipeline_id)

        if success:
            print(f"✅ Pipeline '{args.pipeline_id}' removida com sucesso.")
            return 0
        else:
            print(f"❌ Pipeline '{args.pipeline_id}' não encontrada.", file=sys.stderr)
            return 1
    except APIClientError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_execute(args: argparse.Namespace) -> int:
    """Executa uma pipeline."""
    client = APIClient(base_url=args.api_url)

    # Parse parâmetros
    parametros = {}
    for param in args.param or []:
        if "=" in param:
            key, value = param.split("=", 1)
            # Tentar converter valores
            if value.lower() in ("true", "yes"):
                value = True
            elif value.lower() in ("false", "no"):
                value = False
            elif value.isdigit():
                value = int(value)
            parametros[key] = value

    try:
        if args.async_exec:
            print(f"⏳ Enfileirando execução da pipeline '{args.pipeline_id}'...")
        else:
            print(f"🚀 Executando pipeline '{args.pipeline_id}'...")
            if args.dry_run:
                print("   (modo dry-run)")

        result = client.execute_pipeline(
            pipeline_id=args.pipeline_id,
            parametros=parametros,
            async_exec=args.async_exec,
            timeout=args.timeout
        )

        if args.async_exec:
            print(f"✅ Pipeline enfileirada!")
            print(f"   Execution ID: {result.get('execution_id')}")
            print(f"   Status: {result.get('status')}")
        else:
            print(f"\n{'='*50}")
            print(f"Execução concluída!")
            print(f"{'='*50}")
            print(f"Execution ID: {result.get('execution_id')}")
            print(f"Status: {result.get('status')}")
            print(f"Sucesso: {'Sim' if result.get('success') else 'Não'}")
            print(f"\nRegistros:")
            print(f"   Processados: {result.get('records_processed', 0)}")
            print(f"   Inseridos: {result.get('records_inserted', 0)}")
            print(f"   Falhas: {result.get('records_failed', 0)}")

            if result.get("error_message"):
                print(f"\n❌ Erro: {result['error_message']}")

            if args.verbose and result.get("steps_results"):
                print(f"\nSteps executados:")
                for step in result["steps_results"]:
                    status_icon = "✅" if step.get("success") else "❌"
                    print(f"   {status_icon} {step.get('name')}: "
                          f"{step.get('records_processed', 0)} registros "
                          f"({step.get('duration_ms', 0)}ms)")

        return 0 if result.get("success") else 1
    except APIClientError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1


def cmd_pipelines_status(args: argparse.Namespace) -> int:
    """Verifica status de uma execução."""
    client = APIClient(base_url=args.api_url)

    try:
        execution = client.get_execution(args.pipeline_id, args.execution_id)

        print(f"\n📊 Status da Execução")
        print(f"   Execution ID: {execution.get('execution_id')}")
        print(f"   Pipeline: {execution.get('pipeline_id')}")
        print(f"   Status: {execution.get('status')}")

        if execution.get("current_step"):
            print(f"   Step atual: {execution.get('current_step')}")

        if execution.get("progress_percent") is not None:
            print(f"   Progresso: {execution.get('progress_percent')}%")

        if execution.get("started_at"):
            print(f"   Iniciado em: {execution.get('started_at')}")
        if execution.get("finished_at"):
            print(f"   Finalizado em: {execution.get('finished_at')}")

        if execution.get("records_processed") is not None:
            print(f"\n   Registros processados: {execution.get('records_processed')}")
            print(f"   Registros inseridos: {execution.get('records_inserted')}")
            print(f"   Registros com falha: {execution.get('records_failed')}")

        if execution.get("error_message"):
            print(f"\n   ❌ Erro: {execution['error_message']}")

        return 0
    except APIClientError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1


def _normalize_pipeline_id(pipeline_id: str) -> str:
    """Normaliza o ID da pipeline para atender ao padrão ^[a-z0-9-_]+$.

    Substitui caracteres inválidos (como .) por _.
    """
    import re
    # Converter para minúsculas
    normalized = pipeline_id.lower()
    # Substituir caracteres inválidos (não alfanuméricos, exceto _ e -) por _
    normalized = re.sub(r'[^a-z0-9-_]', '_', normalized)
    return normalized


def cmd_pipelines_migrate(args: argparse.Namespace) -> int:
    """Migra pipelines de arquivos JSON para o banco de dados."""
    import os
    from mymoney import env

    client = APIClient(base_url=args.api_url)

    # Se --file foi especificado, migrar apenas esse arquivo
    if args.file:
        if not os.path.exists(args.file):
            print(f"❌ Arquivo não encontrado: {args.file}")
            return 1

        filepath = args.file
        filename = os.path.basename(filepath)
        raw_id = filename.replace(".json", "")
        pipeline_id = _normalize_pipeline_id(raw_id)

        files_to_process = [(filename, filepath, pipeline_id, raw_id)]
    else:
        # Encontrar arquivos JSON no diretório
        pipelines_dir = env.PIPELINES_FOLDER
        if not os.path.exists(pipelines_dir):
            print(f"❌ Diretório de pipelines não encontrado: {pipelines_dir}")
            return 1

        all_files = [f for f in os.listdir(pipelines_dir) if f.endswith(".json")]
        if not all_files:
            print("Nenhum arquivo JSON encontrado em:", pipelines_dir)
            return 0

        # Filtrar por pipeline_id se especificado
        files_to_process = []
        for filename in all_files:
            if args.pipeline_id and not filename.startswith(args.pipeline_id):
                continue
            filepath = os.path.join(pipelines_dir, filename)
            raw_id = filename.replace(".json", "")
            pid = _normalize_pipeline_id(raw_id)
            files_to_process.append((filename, filepath, pid, raw_id))

    if not files_to_process:
        print("Nenhum arquivo encontrado para migração.")
        return 0

    print(f"📦 {len(files_to_process)} arquivo(s) para migração\n")

    imported = 0
    updated = 0
    skipped = 0
    errors = []

    for filename, filepath, pipeline_id, raw_id in files_to_process:

        print(f"🔄 Processando: {raw_id} (ID: {pipeline_id})...", end=" ")

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Adicionar ID se não existir (normalizado)
            if "id" not in data:
                data["id"] = pipeline_id
            if "nome" not in data:
                data["nome"] = raw_id  # Usar nome original como nome legível
            if "escopo" not in data:
                data["escopo"] = data.get("scope", pipeline_id)
            if "ativo" not in data:
                data["ativo"] = True

            # Verificar se já existe
            existing = None
            try:
                existing = client.get_pipeline(data["id"])
                if existing and not args.force:
                    print("(já existe, ignorando)")
                    skipped += 1
                    continue
            except APIClientError:
                pass  # Não existe, pode criar

            if args.dry_run:
                print("(dry-run)")
                imported += 1
                continue

            # Importar via API
            result = client.import_pipeline(data)

            if existing:
                print("(atualizado)")
                updated += 1
            else:
                print("(criado)")
                imported += 1

        except json.JSONDecodeError as e:
            print(f"(erro JSON: {e})")
            errors.append({"file": filename, "error": str(e)})
        except APIClientError as e:
            print(f"(erro API: {e})")
            errors.append({"file": filename, "error": str(e)})
        except Exception as e:
            print(f"(erro: {e})")
            errors.append({"file": filename, "error": str(e)})

    print(f"\n{'='*50}")
    print(f"Migração concluída!")
    print(f"{'='*50}")
    print(f"Criadas: {imported}")
    print(f"Atualizadas: {updated}")
    print(f"Ignoradas: {skipped}")
    print(f"Erros: {len(errors)}")

    if errors and args.verbose:
        print(f"\nDetalhes dos erros:")
        for err in errors:
            print(f"   • {err['file']}: {err['error']}")

    return 0 if len(errors) == 0 else 1


def cmd_pipelines_export(args: argparse.Namespace) -> int:
    """Exporta pipelines do banco de dados para arquivos JSON no formato legado.

    Este comando permite exportar pipelines armazenadas no banco de dados
    para arquivos JSON no formato legado (contract format), que pode ser
    usado para backup ou para re-migração após edições.
    """
    import os
    from mymoney import env

    client = APIClient(base_url=args.api_url)

    # Determinar diretório de saída
    output_dir = args.output_dir or env.PIPELINES_FOLDER
    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    # Listar pipelines do banco
    try:
        pipelines = client.list_pipelines(
            escopo=args.scope,
            ativo=None if args.all else True,
            limit=args.limit or 1000
        )
    except APIClientError as e:
        print(f"❌ Erro ao listar pipelines: {e}", file=sys.stderr)
        return 1

    if not pipelines:
        print("Nenhuma pipeline encontrada para exportação.")
        return 0

    print(f"📦 {len(pipelines)} pipeline(s) para exportação\n")

    exported = 0
    errors = []

    for pipeline in pipelines:
        pipeline_id = pipeline.get("id", "")
        pipeline_name = pipeline.get("nome", "")

        # Se --pipeline_id foi especificado, filtrar
        if args.pipeline_id and pipeline_id != args.pipeline_id:
            continue

        print(f"🔄 Exportando: {pipeline_name} (ID: {pipeline_id})...", end=" ")

        try:
            # Buscar detalhes completos da pipeline
            full_pipeline = client.get_pipeline(pipeline_id)

            # Converter para formato legado
            legacy_data = _convert_to_legacy_format(full_pipeline)

            # Determinar nome do arquivo
            filename = f"{pipeline_name}.json"
            filepath = os.path.join(output_dir, filename)

            if os.path.exists(filepath) and not args.force:
                print(f"(arquivo já existe, ignorando)")
                continue

            if args.dry_run:
                print(f"(dry-run: {filepath})")
                exported += 1
                continue

            # Escrever arquivo
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(legacy_data, f, ensure_ascii=False, indent=2)

            print(f"(exportado: {filepath})")
            exported += 1

        except APIClientError as e:
            print(f"(erro API: {e})")
            errors.append({"pipeline": pipeline_name, "error": str(e)})
        except Exception as e:
            print(f"(erro: {e})")
            errors.append({"pipeline": pipeline_name, "error": str(e)})

    print(f"\n{'='*50}")
    print(f"Exportação concluída!")
    print(f"{'='*50}")
    print(f"Exportadas: {exported}")
    print(f"Erros: {len(errors)}")

    if errors and args.verbose:
        print(f"\nDetalhes dos erros:")
        for err in errors:
            print(f"   • {err['pipeline']}: {err['error']}")

    return 0 if len(errors) == 0 else 1


def _convert_to_legacy_format(pipeline: dict) -> dict:
    """Converte pipeline do novo formato para formato legado (contract)."""
    result = {}

    # Campos do formato legado (contract)
    result["processor"] = _infer_processor_from_steps(pipeline.get("steps", []))
    result["scope"] = pipeline.get("escopo", pipeline.get("nome", ""))
    result["schema"] = "mymoney"  # Default schema
    result["provider"] = _infer_provider_from_processor(result["processor"])

    # Extrair parâmetros do primeiro step (se houver)
    steps = pipeline.get("steps", [])
    if steps:
        first_step = steps[0]
        params = first_step.get("parametros", {})
        if params:
            result["table_name"] = params.get("table_name")
            result["input_folder"] = params.get("input_folder")
            result["input_masks"] = params.get("input_masks", [])
            result["sheets"] = params.get("sheets", [])

    # Outras configurações
    result["parallelize"] = True
    result["dry_run"] = False
    result["ativo"] = pipeline.get("ativo", True)
    result["versao"] = pipeline.get("versao", 1)

    return result


def _infer_processor_from_steps(steps: list) -> str:
    """Infere o nome do processor a partir dos steps."""
    if not steps:
        return "UnknownProcessor"

    processor_map = {
        "CeiLoadDataProcessor": "CeiLoadDataProcessor",
        "InterLoadDataProcessor": "InterLoadDataProcessor",
        "InterGlobalLoadDataProcessor": "InterGlobalLoadDataProcessor",
        "InterApexLoadDataProcessor": "InterApexLoadDataProcessor",
        "InterApexNcLoadDataProcessor": "InterApexNcLoadDataProcessor",
        "PicPayLoadDataProcessor": "PicPayLoadDataProcessor",
        "InterAccountLoadDataProcessor": "InterAccountLoadDataProcessor",
        "InterGlobalAccountLoadDataProcessor": "InterGlobalAccountLoadDataProcessor",
        "InterApexAccountLoadDataProcessor": "InterApexAccountLoadDataProcessor",
        "InterApexNcAccountLoadDataProcessor": "InterApexNcAccountLoadDataProcessor",
        "PicPayAccountLoadDataProcessor": "PicPayAccountLoadDataProcessor",
        "MercadoPagoAccountLoadDataProcessor": "MercadoPagoAccountLoadDataProcessor",
        "NubankAccountLoadDataProcessor": "NubankAccountLoadDataProcessor",
        "NextAccountLoadDataProcessor": "NextAccountLoadDataProcessor",
        "DataLoadDataProcessor": "DataLoadDataProcessor",
    }

    for step in steps:
        proc = step.get("processor", "")
        if proc in processor_map:
            return processor_map[proc]

    # Fallback: usar o processor do primeiro step
    return steps[0].get("processor", "UnknownProcessor")


def _infer_provider_from_processor(processor: str) -> str:
    """Infere o provider a partir do processor."""
    provider_map = {
        "CeiLoadDataProcessor": "cei",
        "InterLoadDataProcessor": "inter",
        "InterGlobalLoadDataProcessor": "inter_global",
        "InterApexLoadDataProcessor": "inter_apex",
        "InterApexNcLoadDataProcessor": "inter_apex_nc",
        "PicPayLoadDataProcessor": "picpay",
        "InterAccountLoadDataProcessor": "inter",
        "InterGlobalAccountLoadDataProcessor": "inter_global",
        "InterApexAccountLoadDataProcessor": "inter_apex",
        "InterApexNcAccountLoadDataProcessor": "inter_apex_nc",
        "PicPayAccountLoadDataProcessor": "picpay",
        "MercadoPagoAccountLoadDataProcessor": "mercado_pago",
        "NubankAccountLoadDataProcessor": "nubank",
        "NextAccountLoadDataProcessor": "next",
        "DataLoadDataProcessor": "data",
    }
    return provider_map.get(processor, "unknown")


def add_pipelines_subparser(subparsers):
    """Adiciona o subparser 'pipelines' ao parser principal."""
    pipelines_parser = subparsers.add_parser(
        "pipelines",
        help="Gerencia pipelines no banco de dados (usa API REST).",
        description="Comandos para gerenciar pipelines armazenadas no banco de dados."
    )
    pipelines_subparsers = pipelines_parser.add_subparsers(dest="pipelines_command")

    # Global args
    pipelines_parser.add_argument(
        "--api-url",
        help="URL base da API (ex: http://localhost:9001/api/v1)"
    )

    # list
    list_parser = pipelines_subparsers.add_parser("list", help="Lista pipelines")
    list_parser.add_argument("--scope", "-s", help="Filtrar por escopo")
    list_parser.add_argument("--active", "-a", type=bool, help="Filtrar por ativo")
    list_parser.add_argument("--limit", "-l", type=int, default=100, help="Limite de resultados")
    list_parser.add_argument("--format", "-f", choices=["json", "table"], default="table")
    list_parser.set_defaults(func=cmd_pipelines_list)

    # get
    get_parser = pipelines_subparsers.add_parser("get", help="Obtém uma pipeline")
    get_parser.add_argument("pipeline_id", help="ID da pipeline")
    get_parser.add_argument("--format", "-f", choices=["json", "table"], default="table")
    get_parser.set_defaults(func=cmd_pipelines_get)

    # create
    create_parser = pipelines_subparsers.add_parser(
        "create",
        help="Cria uma pipeline de arquivo JSON (formato novo: id, nome, escopo, steps)"
    )
    create_parser.add_argument(
        "--file", "-f", required=True,
        help="Arquivo JSON com a configuração no novo formato. Para arquivos legados, use 'migrate'"
    )
    create_parser.set_defaults(func=cmd_pipelines_create)

    # update
    update_parser = pipelines_subparsers.add_parser("update", help="Atualiza uma pipeline")
    update_parser.add_argument("pipeline_id", help="ID da pipeline")
    update_parser.add_argument("--file", "-f", required=True, help="Arquivo JSON com a configuração")
    update_parser.set_defaults(func=cmd_pipelines_update)

    # delete
    delete_parser = pipelines_subparsers.add_parser("delete", help="Remove uma pipeline")
    delete_parser.add_argument("pipeline_id", help="ID da pipeline")
    delete_parser.add_argument("--yes", "-y", action="store_true", help="Não pedir confirmação")
    delete_parser.set_defaults(func=cmd_pipelines_delete)

    # execute
    execute_parser = pipelines_subparsers.add_parser("execute", help="Executa uma pipeline")
    execute_parser.add_argument("pipeline_id", help="ID da pipeline")
    execute_parser.add_argument("--param", "-p", action="append", help="Parâmetros (key=value)")
    execute_parser.add_argument("--async", "-a", dest="async_exec", action="store_true",
                                help="Executar assincronamente")
    execute_parser.add_argument("--timeout", "-t", type=int, default=300, help="Timeout em segundos")
    execute_parser.add_argument("--dry-run", "-d", action="store_true", help="Simular execução")
    execute_parser.add_argument("--verbose", "-v", action="store_true", help="Mostrar detalhes")
    execute_parser.set_defaults(func=cmd_pipelines_execute)

    # status
    status_parser = pipelines_subparsers.add_parser("status", help="Verifica status de execução")
    status_parser.add_argument("pipeline_id", help="ID da pipeline")
    status_parser.add_argument("execution_id", help="ID da execução")
    status_parser.set_defaults(func=cmd_pipelines_status)

    # migrate
    migrate_parser = pipelines_subparsers.add_parser(
        "migrate",
        help="Migra pipelines de arquivos JSON legados para o DB"
    )
    migrate_parser.add_argument(
        "--file", "-f",
        help="Arquivo JSON específico para migrar (opcional, alternativo ao diretório padrão)"
    )
    migrate_parser.add_argument("--dry-run", "-d", action="store_true", help="Simular sem aplicar")
    migrate_parser.add_argument("--force", "-f", action="store_true", help="Sobrescrever existentes")
    migrate_parser.add_argument("--verbose", "-v", action="store_true", help="Mostrar erros detalhados")
    migrate_parser.add_argument("pipeline_id", nargs="?", help="Filtrar por ID da pipeline (prefixo)")
    migrate_parser.set_defaults(func=cmd_pipelines_migrate)

    # export
    export_parser = pipelines_subparsers.add_parser(
        "export",
        help="Exporta pipelines do DB para arquivos JSON no formato legado"
    )
    export_parser.add_argument(
        "--output-dir", "-o",
        help="Diretório de saída (padrão: PIPELINES_FOLDER)"
    )
    export_parser.add_argument(
        "--scope", "-s",
        help="Filtrar por escopo"
    )
    export_parser.add_argument(
        "--limit", "-l", type=int, default=1000,
        help="Limite de pipelines (padrão: 1000)"
    )
    export_parser.add_argument(
        "--force", "-f", action="store_true",
        help="Sobrescrever arquivos existentes"
    )
    export_parser.add_argument(
        "--all", "-a", action="store_true",
        help="Exportar pipelines inativas também"
    )
    export_parser.add_argument(
        "--dry-run", "-d", action="store_true",
        help="Simular sem criar arquivos"
    )
    export_parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Mostrar erros detalhados"
    )
    export_parser.add_argument(
        "pipeline_id",
        nargs="?",
        help="Filtrar por ID específico da pipeline"
    )
    export_parser.set_defaults(func=cmd_pipelines_export)

    return pipelines_parser
