"""
Comando CLI para extração de dados de arquivos via providers.

Arquivo: mymoney/cli/commands/extract.py
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Optional

import pandas as pd

from mymoney import env, logger


# Provider function mapping (provider -> (module, function_name, supported_extensions))
_PROVIDER_FUNCTIONS = {
    "nubank": ("mymoney.data.providers.nubank", "parse_nubank", [".csv", ".ofx", ".pdf"]),
    "nubank_cc": ("mymoney.data.providers.nubank", "parse_nubank_cc", [".csv", ".ofx", ".pdf"]),
    "inter": ("mymoney.data.providers.inter", "parse_inter", [".csv", ".ofx", ".pdf"]),
    "inter_cc": ("mymoney.data.providers.inter", "parse_inter_cc", [".csv", ".pdf"]),
    "inter_global": ("mymoney.data.providers.inter", "parse_inter_global", [".csv", ".pdf"]),
    "inter_apex": ("mymoney.data.providers.inter", "parse_inter_apex", [".pdf"]),
    "picpay": ("mymoney.data.providers.picpay", "parse_picpay_pdf", [".pdf"]),
    "picpay_cc": ("mymoney.data.providers.picpay", "parse_picpay_cc_pdf", [".pdf"]),
    "mercado_pago": ("mymoney.data.providers.mercado_pago", "parse_mercado_pago_pdf", [".pdf"]),
    "mercado_pago_cc": ("mymoney.data.providers.mercado_pago", "parse_mercado_pago_cc_pdf", [".pdf"]),
    "next": ("mymoney.data.providers.next.next_pdf", "parse_next_pdf", [".pdf"]),
    "next_cc": ("mymoney.data.providers.next", "parse_next_cc_pdf", [".pdf"]),
    "cef": ("mymoney.data.providers.cef.fgts_parser", "parse_fgts", [".pdf", ".docx", ".md"]),
}


def _check_llm_dependencies() -> tuple[bool, Optional[str], Optional[str]]:
    """Verifica se as dependências de LLM estão configuradas.

    Returns:
        Tuple (ok, error_message, model_name)
    """
    cfg = env.USER_CONFIG or {}

    # Verificar provider
    llm_provider = cfg.get("LLM_PROVIDER") or cfg.get("llm_provider")
    if not llm_provider:
        return False, "LLM_PROVIDER não configurado. Configure em ~/.mymoney/config.json", None

    # Verificar base model
    llm_base_model = cfg.get("LLM_BASE_MODEL") or cfg.get("llm_base_model")
    if not llm_base_model:
        return False, "LLM_BASE_MODEL não configurado. Configure em ~/.mymoney/config.json", None

    # Verificar API base URL
    llm_api_base_url = cfg.get("LLM_API_BASE_URL") or cfg.get("llm_api_base_url")
    if not llm_api_base_url:
        return False, "LLM_API_BASE_URL não configurado. Configure em ~/.mymoney/config.json", None

    # Verificar API key (opcional para alguns providers como Ollama)
    llm_api_key = cfg.get("LLM_API_KEY") or cfg.get("llm_api_key")
    provider_upper = str(llm_provider).upper().replace("-", "_")
    provider_env_api_key = f"{provider_upper}_API_KEY"
    has_api_key = llm_api_key or env.ENV_VARS.get(provider_env_api_key)

    # Providers que geralmente precisam de API key
    providers_needing_key = ["openai", "anthropic", "gemini", "openrouter"]
    if llm_provider.lower() in providers_needing_key and not has_api_key:
        return False, f"LLM_API_KEY não configurado para provider '{llm_provider}'. Configure em ~/.mymoney/config.json ou via env var {provider_env_api_key}", None

    return True, None, llm_base_model


def _get_provider_function(provider: str):
    """Retorna a função de extração do provider especificado."""
    provider_key = provider.lower()
    mapping = _PROVIDER_FUNCTIONS.get(provider_key)
    if not mapping:
        available = ", ".join(sorted(_PROVIDER_FUNCTIONS.keys()))
        raise ValueError(f"Provider '{provider}' não encontrado. Disponíveis: {available}")

    module_path, function_name, supported_extensions = mapping
    try:
        module = __import__(module_path, fromlist=[function_name])
        return getattr(module, function_name), supported_extensions
    except (ImportError, AttributeError) as e:
        raise ValueError(f"Erro ao carregar provider '{provider}': {e}")


def _extract_data(
    file_path: str,
    provider: str,
    use_native_pdf: bool = False,
    use_vision: bool = False,
) -> tuple[pd.DataFrame, str]:
    """Extrai dados do arquivo usando o provider especificado.

    Returns:
        Tuple (DataFrame, model_name)
    """
    parse_func, supported_extensions = _get_provider_function(provider)

    # Verificar extensão do arquivo
    file_ext = Path(file_path).suffix.lower()
    if file_ext not in supported_extensions:
        ext_list = ", ".join(supported_extensions)
        raise ValueError(
            f"Extensão '{file_ext}' não suportada pelo provider '{provider}'. "
            f"Extensões suportadas: {ext_list}"
        )

    # Determinar qual modelo usar
    cfg = env.USER_CONFIG or {}
    if use_vision:
        model_name = cfg.get("LLM_VISION_MODEL") or cfg.get("llm_vision_model") or cfg.get("LLM_BASE_MODEL") or cfg.get("llm_base_model")
    else:
        model_name = cfg.get("LLM_BASE_MODEL") or cfg.get("llm_base_model")

    # Preparar kwargs base
    import inspect
    sig = inspect.signature(parse_func)
    kwargs = {}

    # Passar use_native_pdf se o provider suportar
    if "use_native_pdf" in sig.parameters:
        kwargs["use_native_pdf"] = use_native_pdf
    else:
        # Provider não suporta native PDF ainda
        if use_native_pdf:
            logger.warning(f"Provider '{provider}' não suporta --native-pdf ainda, usando conversão markdown")

    # Executar extração
    df = parse_func(file_path, **kwargs)

    return df, model_name or "desconhecido"


def _dataframe_to_format(df: pd.DataFrame, format: str) -> str:
    """Converte DataFrame para o formato solicitado."""
    if format == "csv":
        return df.to_csv(index=False)
    elif format == "json":
        return df.to_json(orient="records", force_ascii=False, indent=2)
    elif format == "md":
        # Markdown table format
        if df.empty:
            return "Nenhum dado encontrado."
        lines = ["| " + " | ".join(df.columns) + " |"]
        lines.append("| " + " | ".join(["---"] * len(df.columns)) + " |")
        for _, row in df.iterrows():
            lines.append("| " + " | ".join(str(v) for v in row.values) + " |")
        return "\n".join(lines)
    else:
        raise ValueError(f"Formato não suportado: {format}")


def cmd_extract(args: argparse.Namespace) -> int:
    """Executa extração de dados de arquivo via provider."""
    # Verificar dependências LLM
    ok, error, base_model = _check_llm_dependencies()
    if not ok:
        print(f"❌ Erro de configuração: {error}", file=sys.stderr)
        return 1

    # Verificar arquivo
    file_path = Path(args.file)
    if not file_path.exists():
        print(f"❌ Erro: Arquivo não encontrado: {args.file}", file=sys.stderr)
        return 1

    # Verificar validações específicas de --vision
    if args.vision:
        if not args.native_pdf:
            print("❌ Erro: A opção --vision só pode ser usada junto com --native-pdf", file=sys.stderr)
            return 1
        if not file_path.suffix.lower() == ".pdf":
            print("❌ Erro: A opção --vision só pode ser usada com arquivos PDF", file=sys.stderr)
            return 1

    # Determinar qual modelo será usado
    cfg = env.USER_CONFIG or {}
    model_to_use = base_model
    if args.vision and args.native_pdf:
        vision_model = cfg.get("LLM_VISION_MODEL") or cfg.get("llm_vision_model")
        if vision_model:
            model_to_use = vision_model

    try:
        # Extrair dados
        print(f"📄 Extraindo dados de: {file_path.name}")
        print(f"   Provider: {args.provider}")
        print(f"   Modelo LLM: {model_to_use}")
        if args.native_pdf:
            print(f"   Modo: PDF nativo (sem conversão markdown)")
        if args.vision:
            print(f"   Visão: Ativada (usando modelo de visão)")

        df, actual_model = _extract_data(
            str(file_path),
            args.provider,
            use_native_pdf=args.native_pdf,
            use_vision=args.vision,
        )

        print(f"   Registros extraídos: {len(df)}")

        # Converter para formato solicitado
        output = _dataframe_to_format(df, args.format)

        # Output
        if args.output:
            output_path = Path(args.output)
            output_path.write_text(output, encoding="utf-8")
            print(f"   ✅ Resultado salvo em: {output_path}")
        else:
            print()
            print(output)

        return 0

    except ValueError as e:
        print(f"❌ Erro: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        logger.error(f"Erro na extração: {e}", exc_info=True)
        print(f"❌ Erro inesperado: {e}", file=sys.stderr)
        return 1


def add_extract_subparser(subparsers) -> None:
    """Adiciona subparser para comando extract."""
    extract_parser = subparsers.add_parser(
        "extract",
        help="Extrai dados de arquivos via provider.",
        description="Extrai lançamentos financeiros de extratos bancários.",
    )
    extract_parser.add_argument(
        "file",
        help="Caminho do arquivo a ser processado (PDF, DOCX, MD, etc.)",
    )
    extract_parser.add_argument(
        "--provider",
        required=True,
        choices=list(_PROVIDER_FUNCTIONS.keys()),
        help="Provider a ser usado para extração",
    )
    extract_parser.add_argument(
        "--format",
        choices=["csv", "json", "md"],
        default="csv",
        help="Formato de saída (default: csv)",
    )
    extract_parser.add_argument(
        "--output",
        "-o",
        help="Caminho do arquivo de saída (default: stdout)",
    )
    extract_parser.add_argument(
        "--native-pdf",
        action="store_true",
        help="Usa PDF nativo sem conversão para markdown (requer modelo compatível)",
    )
    extract_parser.add_argument(
        "--vision",
        action="store_true",
        help="Usa modelo de visão para extração (requer --native-pdf e arquivo PDF). Se LLM_VISION_MODEL estiver configurado, será usado; caso contrário, mantém o modelo base",
    )
    extract_parser.set_defaults(func=cmd_extract)
