"""
Comandos CLI para gerenciamento do lifecycle da API.

Arquivo: mymoney/cli/commands/api.py
"""

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from mymoney import env, logger


PID_FILE = Path(env.USER_APP_FOLDER) / "api.pid"
LOG_FILE = Path(env.LOGS_FOLDER) / "api.log"


def _get_default_host() -> str:
    """Retorna host padrão da API."""
    return env.USER_CONFIG.get("APP_BACKEND_HOST") or "127.0.0.1"


def _get_default_port() -> int:
    """Retorna porta padrão da API."""
    port = env.USER_CONFIG.get("APP_BACKEND_PORT")
    return int(port) if port else 9001


def _get_api_url(host: str, port: int) -> str:
    """Retorna URL base da API."""
    return f"http://{host}:{port}"


def _is_api_running(host: str, port: int) -> bool:
    """Verifica se a API está respondendo."""
    import urllib.request
    try:
        urllib.request.urlopen(
            f"http://{host}:{port}/health",
            timeout=2
        )
        return True
    except:
        return False


def _read_pid() -> Optional[int]:
    """Lê PID do arquivo se existir."""
    if PID_FILE.exists():
        try:
            return int(PID_FILE.read_text().strip())
        except:
            return None
    return None


def _write_pid(pid: int):
    """Escreve PID no arquivo."""
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(pid))


def _remove_pid():
    """Remove arquivo de PID."""
    if PID_FILE.exists():
        PID_FILE.unlink()


def cmd_api_start(args: argparse.Namespace) -> int:
    """Inicia a API em background."""
    host = args.host or _get_default_host()
    port = args.port or _get_default_port()

    # Verificar se já está rodando
    if _is_api_running(host, port):
        print(f"✓ API já está rodando em http://{host}:{port}")
        return 0

    # Verificar se há PID de processo morto
    pid = _read_pid()
    if pid:
        try:
            os.kill(pid, 0)  # Verifica se processo existe
            print(f"⚠ API já iniciada (PID {pid}). Use 'mymoney api status' para verificar.")
            return 0
        except ProcessLookupError:
            _remove_pid()  # PID morto, limpar

    print(f"🚀 Iniciando API em http://{host}:{port} ...")

    # Preparar comando
    cmd = [
        sys.executable,
        "-m", "mymoney.api.main",
        "--host", host,
        "--port", str(port),
    ]

    # Abrir log
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Iniciar processo em background
    try:
        with open(LOG_FILE, "a") as log:
            process = subprocess.Popen(
                cmd,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,  # Desanexar do terminal
            )

        _write_pid(process.pid)

        # Aguardar inicialização
        print("⏳ Aguardando inicialização...", end="")
        for i in range(30):  # 30 tentativas (15 segundos)
            time.sleep(0.5)
            if _is_api_running(host, port):
                print(" OK!")
                print(f"✓ API rodando em http://{host}:{port}")
                print(f"  Logs: {LOG_FILE}")
                return 0
            print(".", end="", flush=True)

        print(" timeout!")
        print(f"⚠ API pode estar demorando. Verifique logs: {LOG_FILE}")
        return 1

    except Exception as e:
        print(f"❌ Erro ao iniciar API: {e}")
        return 1


def cmd_api_stop(args: argparse.Namespace) -> int:
    """Para a API."""
    pid = _read_pid()

    if not pid:
        # Tentar encontrar processo pela porta
        print("🔍 Buscando processo da API...")
        try:
            result = subprocess.run(
                ["lsof", "-t", "-i", f":{_get_default_port()}"],
                capture_output=True,
                text=True
            )
            if result.stdout.strip():
                pid = int(result.stdout.strip().split("\n")[0])
        except:
            pass

    if not pid:
        print("⚠ API não está rodando (nenhum PID encontrado)")
        return 0

    print(f"🛑 Parando API (PID {pid})...")

    try:
        os.kill(pid, signal.SIGTERM)

        # Aguardar parada
        for i in range(20):
            time.sleep(0.5)
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                print("✓ API parada")
                _remove_pid()
                return 0

        # Forçar kill
        print("⚠ Forçando parada...")
        os.kill(pid, signal.SIGKILL)
        _remove_pid()
        print("✓ API parada (forçado)")
        return 0

    except ProcessLookupError:
        print("✓ API já estava parada")
        _remove_pid()
        return 0
    except Exception as e:
        print(f"❌ Erro ao parar API: {e}")
        return 1


def cmd_api_status(args: argparse.Namespace) -> int:
    """Verifica status da API."""
    host = args.host or _get_default_host()
    port = args.port or _get_default_port()

    pid = _read_pid()
    running = _is_api_running(host, port)

    if running:
        status = "✓ Rodando"
        if pid:
            status += f" (PID {pid})"
        print(f"{status}")
        print(f"  URL: http://{host}:{port}")
        print(f"  Docs: http://{host}:{port}/docs")
        print(f"  Logs: {LOG_FILE}")
        return 0
    else:
        if pid:
            print(f"⚠ Processo existe (PID {pid}) mas API não responde")
            print(f"  Verifique logs: {LOG_FILE}")
            return 1
        else:
            print("✗ API não está rodando")
            print(f"  Inicie com: mymoney api start")
            return 1


def cmd_api_logs(args: argparse.Namespace) -> int:
    """Mostra logs da API."""
    if not LOG_FILE.exists():
        print("ℹ Nenhum log encontrado (API ainda não iniciada)")
        return 0

    try:
        # Tail ou cat completo
        if args.follow:
            subprocess.run(["tail", "-f", "-n", str(args.lines), str(LOG_FILE)])
        else:
            subprocess.run(["tail", "-n", str(args.lines), str(LOG_FILE)])
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as e:
        print(f"❌ Erro ao ler logs: {e}")
        return 1


def add_api_subparser(subparsers):
    """Adiciona o subparser 'api' ao parser principal."""
    api_parser = subparsers.add_parser(
        "api",
        help="Gerencia o lifecycle da API REST.",
        description="Comandos para iniciar, parar e monitorar a API MyMoney."
    )
    api_subparsers = api_parser.add_subparsers(dest="api_command")

    # Global args
    default_host = _get_default_host()
    default_port = _get_default_port()
    api_parser.add_argument(
        "--host",
        default=default_host,
        help=f"Host da API (default: {default_host})"
    )
    api_parser.add_argument(
        "--port",
        type=int,
        default=default_port,
        help=f"Porta da API (default: {default_port})"
    )

    # start
    start_parser = api_subparsers.add_parser(
        "start",
        help="Inicia a API em background"
    )
    start_parser.set_defaults(func=cmd_api_start)

    # stop
    stop_parser = api_subparsers.add_parser(
        "stop",
        help="Para a API"
    )
    stop_parser.set_defaults(func=cmd_api_stop)

    # status
    status_parser = api_subparsers.add_parser(
        "status",
        help="Verifica status da API"
    )
    status_parser.set_defaults(func=cmd_api_status)

    # logs
    logs_parser = api_subparsers.add_parser(
        "logs",
        help="Mostra logs da API"
    )
    logs_parser.add_argument(
        "-n", "--lines",
        type=int,
        default=50,
        help="Número de linhas (default: 50)"
    )
    logs_parser.add_argument(
        "-f", "--follow",
        action="store_true",
        help="Acompanhar novas linhas (tail -f)"
    )
    logs_parser.set_defaults(func=cmd_api_logs)

    return api_parser
