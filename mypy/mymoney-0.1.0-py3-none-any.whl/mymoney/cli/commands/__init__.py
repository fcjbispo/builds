# mymoney/cli/commands/__init__.py
"""Comandos do CLI."""
