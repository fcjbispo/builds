"""Application entrypoints for MyMoney."""

