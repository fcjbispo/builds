"""Single point execution app for MyMoney modules."""

from __future__ import annotations

import argparse
import json
import os
from typing import Any, Optional

from mymoney import env


def _print_json(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


def _cmd_elt(elt_args: list[str]) -> int:
    from mymoney.data.elt.tui import main as elt_main

    args = elt_args[:] if elt_args else []
    if args and args[0] == "--":
        args = args[1:]
    try:
        elt_main(args)
    except KeyboardInterrupt:
        print("\n\n✋ Operação cancelada pelo usuário.")
        return 130
    except Exception as e:
        print(f"❌ Erro na execução ELT: {e}")
        return 1
    return 0



def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mymoney",
        description=(
            "MyMoney single point execution app. "
            "Use this command to run current modules and future services."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- elt ---
    elt_parser = subparsers.add_parser(
        "elt",
        help="Run ELT interface (TUI/CLI passthrough).",
    )
    elt_parser.add_argument(
        "elt_args",
        nargs=argparse.REMAINDER,
        help="Arguments forwarded to ELT module (e.g. -p mymoney.load.cei --dry-run).",
    )

    # --- api (lifecycle management) ---
    from mymoney.cli.commands.api import add_api_subparser
    add_api_subparser(subparsers)

    # --- pipelines (gerenciamento via API REST) ---
    from mymoney.cli.commands.pipelines import add_pipelines_subparser
    add_pipelines_subparser(subparsers)

    # --- extract (extração de dados via provider) ---
    from mymoney.cli.commands.extract import add_extract_subparser
    add_extract_subparser(subparsers)

    return parser


def main(argv: Optional[list[str]] = None) -> None:
    parser = _build_parser()
    code = 0
    try:
        args, extra = parser.parse_known_args(argv)

        if args.command == "elt":
            code = _cmd_elt(args.elt_args + extra)
        elif args.command == "api":
            if extra:
                parser.error(f"unrecognized arguments: {' '.join(extra)}")
            if hasattr(args, 'func'):
                code = args.func(args)
            else:
                parser.print_help()
                code = 0
        elif args.command == "pipelines":
            if extra:
                parser.error(f"unrecognized arguments: {' '.join(extra)}")
            if hasattr(args, 'func'):
                code = args.func(args)
            else:
                parser.print_help()
                code = 0
        elif args.command == "extract":
            if extra:
                parser.error(f"unrecognized arguments: {' '.join(extra)}")
            if hasattr(args, 'func'):
                code = args.func(args)
            else:
                parser.print_help()
                code = 0
        else:
            if extra:
                parser.error(f"unrecognized arguments: {' '.join(extra)}")
            parser.print_help()
            code = 0
    except KeyboardInterrupt:
        print("\n\n✋ Operação cancelada pelo usuário.")
        code = 130
    except FileNotFoundError as e:
        print(f"\n❌ Erro: Arquivo não encontrado: {e}")
        code = 1
    except ValueError as e:
        print(f"\n❌ Erro: {e}")
        code = 1
    except RuntimeError as e:
        print(f"\n❌ Erro na execução: {e}")
        code = 1
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        code = 1
    finally:
        try:
            from mymoney import env

            env.DB_ENGINE.dispose()
        except Exception:
            pass

    raise SystemExit(code)


if __name__ == "__main__":
    main()
