"""Split PDF files into smaller chunks by page count."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from pypdf import PdfReader, PdfWriter

from mymoney import logger


def split_pdf(
    input_path: str,
    pages_per_chunk: int = 5,
    remove_original: bool = False,
    auto_confirm: bool = False,
    dry_run: bool = False,
) -> list[str]:
    """
    Split a PDF file into smaller chunks.

    Args:
        input_path: Path to the input PDF file
        pages_per_chunk: Number of pages per chunk (default: 5)
        remove_original: Whether to remove the original file after splitting
        auto_confirm: Skip confirmation prompts (default: False)
        dry_run: Show what would be done without actually doing it

    Returns:
        List of created chunk file paths

    Raises:
        FileNotFoundError: If input file does not exist
        ValueError: If input file is not a PDF
        KeyboardInterrupt: If user cancels the operation
    """
    input_path = os.path.abspath(input_path)

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Arquivo não encontrado: {input_path}")

    ext = os.path.splitext(input_path)[1].lower()
    if ext != ".pdf":
        raise ValueError(f"Arquivo deve ser PDF, mas recebeu: {ext}")

    base_name = os.path.splitext(os.path.basename(input_path))[0]
    output_dir = os.path.dirname(input_path)

    logger.info(
        "Split PDF: input=%s pages_per_chunk=%s remove_original=%s",
        input_path,
        pages_per_chunk,
        remove_original,
    )

    reader = PdfReader(input_path)
    total_pages = len(reader.pages)

    if total_pages == 0:
        raise ValueError(f"PDF está vazio: {input_path}")

    total_chunks = (total_pages + pages_per_chunk - 1) // pages_per_chunk

    print(f"\nArquivo: {os.path.basename(input_path)}")
    print(f"Total de páginas: {total_pages}")
    print(f"Páginas por chunk: {pages_per_chunk}")
    print(f"Total de chunks: {total_chunks}")

    if dry_run:
        print("\n[DRY-RUN] Arquivos que seriam criados:")
        for i in range(total_chunks):
            start_page = i * pages_per_chunk + 1
            end_page = min((i + 1) * pages_per_chunk, total_pages)
            chunk_name = f"{base_name}.{i + 1:04d}.pdf"
            print(f"  - {chunk_name} (páginas {start_page}-{end_page})")
        if remove_original:
            print(f"\n[DRY-RUN] Arquivo original seria removido: {os.path.basename(input_path)}")
        return []

    created_files: list[str] = []

    for i in range(total_chunks):
        start_page_idx = i * pages_per_chunk
        end_page_idx = min((i + 1) * pages_per_chunk, total_pages)

        writer = PdfWriter()
        for page_idx in range(start_page_idx, end_page_idx):
            writer.add_page(reader.pages[page_idx])

        chunk_name = f"{base_name}.{i + 1:04d}.pdf"
        chunk_path = os.path.join(output_dir, chunk_name)

        with open(chunk_path, "wb") as f:
            writer.write(f)

        created_files.append(chunk_path)

        start_page_num = start_page_idx + 1
        end_page_num = end_page_idx
        print(f"  Criado: {chunk_name} (páginas {start_page_num}-{end_page_num})")

    print(f"\nTotal de arquivos criados: {len(created_files)}")

    if remove_original:
        if auto_confirm:
            confirm = "y"
        else:
            print(f"\nRemover arquivo original: {os.path.basename(input_path)}?")
            print("  [y] Sim, remover após criar os chunks")
            print("  [n] Não, manter o arquivo original")
            confirm = input("\nConfirmação (y/n): ").strip().lower()

        if confirm == "y":
            os.remove(input_path)
            print(f"Arquivo original removido: {os.path.basename(input_path)}")
        else:
            print("Arquivo original mantido.")

    return created_files


def main(argv: list[str] | None = None) -> int:
    """Main entry point for split command."""
    parser = argparse.ArgumentParser(
        prog="mymoney split",
        description="Divide um arquivo PDF em chunks menores por número de páginas.",
    )
    parser.add_argument(
        "input_file",
        help="Caminho para o arquivo PDF a ser dividido",
    )
    parser.add_argument(
        "pages",
        type=int,
        nargs="?",
        default=5,
        help="Número de páginas por chunk (default: 5)",
    )
    parser.add_argument(
        "--remove-original",
        action="store_true",
        help="Remover arquivo original após criar os chunks",
    )
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Pular confirmação para remoção do arquivo original",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Mostrar o que seria feito sem executar",
    )

    args = parser.parse_args(argv)

    try:
        split_pdf(
            input_path=args.input_file,
            pages_per_chunk=args.pages,
            remove_original=args.remove_original,
            auto_confirm=args.yes,
            dry_run=args.dry_run,
        )
        return 0
    except FileNotFoundError as e:
        print(f"\n❌ Erro: {e}")
        return 1
    except ValueError as e:
        print(f"\n❌ Erro: {e}")
        return 1
    except KeyboardInterrupt:
        print("\n\n✋ Operação cancelada pelo usuário.")
        return 130
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        logger.error("Split PDF failed: %s", e)
        return 1
