"""
Executor de pipelines baseado em configuração do banco de dados.

Arquivo: mymoney/pipelines/executor.py
"""

import json
import importlib
import asyncio
from typing import Dict, Any, Optional, List, Callable
from datetime import datetime
from sqlalchemy.engine import Engine

from mymoney import logger, emit_debug_trace, env
from mymoney.data.repositories import PipelineRepository, ExecutionRepository
from mymoney.services.operations import get_operation_recorder


class PipelineConfigLoader:
    """Carrega configuração de pipeline do banco de dados."""

    def __init__(self, engine: Engine):
        self.engine = engine
        self.pipeline_repo = PipelineRepository(engine)

    def load_by_id(self, pipeline_id: str) -> Dict[str, Any]:
        """
        Carrega configuração da pipeline por ID.

        Args:
            pipeline_id: ID hash da pipeline.

        Returns:
            Dict com configuração da pipeline.

        Raises:
            ValueError: Se pipeline não encontrada no banco de dados.
        """
        config = self.pipeline_repo.get(pipeline_id)
        if config:
            emit_debug_trace(f"PipelineConfigLoader loaded from DB pipeline_id={pipeline_id}")
            return config

        raise ValueError(
            f"Pipeline com ID '{pipeline_id}' não encontrada no banco de dados. "
            f"Use 'mymoney pipelines list' para ver as pipelines disponíveis."
        )

    def load_by_name(self, pipeline_name: str) -> Dict[str, Any]:
        """
        Carrega configuração da pipeline por nome.

        Args:
            pipeline_name: Nome da pipeline.

        Returns:
            Dict com configuração da pipeline.

        Raises:
            ValueError: Se pipeline não encontrada no banco de dados.
        """
        config = self.pipeline_repo.get_by_nome(pipeline_name)
        if config:
            emit_debug_trace(f"PipelineConfigLoader loaded from DB pipeline_name={pipeline_name}")
            return config

        raise ValueError(
            f"Pipeline '{pipeline_name}' não encontrada no banco de dados. "
            f"Use 'mymoney pipelines migrate' para migrar pipelines de arquivos JSON, "
            f"ou 'mymoney pipelines list' para ver as pipelines disponíveis."
        )


class PipelineExecutor:
    """Executor de pipelines configuradas no banco de dados."""

    def __init__(self, engine: Engine):
        """
        Inicializa o executor.

        Args:
            engine: Engine SQLAlchemy para conexão com o banco.
        """
        self.engine = engine
        self.pipeline_repo = PipelineRepository(engine)
        self.execution_repo = ExecutionRepository(engine)
        self.config_loader = PipelineConfigLoader(engine)

    async def execute(
        self,
        pipeline_id: str,
        parametros: Optional[Dict[str, Any]] = None,
        execution_id: Optional[str] = None,
        progress_callback: Optional[Callable] = None
    ) -> Dict[str, Any]:
        """
        Executa uma pipeline do banco de dados.

        Args:
            pipeline_id: ID da pipeline.
            parametros: Parâmetros para sobrescrever os globais.
            execution_id: ID da execução (para tracking).
            progress_callback: Callback opcional para progresso.

        Returns:
            Dict com o resultado da execução.
        """
        emit_debug_trace(f"PipelineExecutor.execute start pipeline_id={pipeline_id}")

        # 1. Carregar config do banco de dados por nome
        try:
            config = self.config_loader.load_by_name(pipeline_id)
        except ValueError as e:
            raise ValueError(str(e))

        if not config.get("ativo", True):
            raise ValueError(f"Pipeline '{pipeline_id}' está inativa")

        # 2. Resolver parâmetros
        global_params = config.get("parametros", {})
        resolved_params = self.resolve_params(global_params, parametros or {})

        emit_debug_trace(
            f"PipelineExecutor.execute config loaded pipeline_id={pipeline_id} "
            f"steps_count={len(config.get('steps', []))}"
        )

        # 3. Construir plano de execução (ordem topológica)
        steps = config.get("steps", [])
        execution_order = self._build_execution_order(steps)

        emit_debug_trace(
            f"PipelineExecutor.execute execution plan built pipeline_id={pipeline_id} "
            f"order={execution_order}"
        )

        # 4. Executar steps em ordem
        steps_results = []
        total_records = 0
        total_inserted = 0
        total_failed = 0
        success = True
        error_message = None

        try:
            for step_idx in execution_order:
                step = steps[step_idx]
                step_name = step.get("name", f"step_{step_idx}")

                # Atualizar progresso
                if execution_id:
                    progress = int((len(steps_results) / len(steps)) * 100)
                    self.execution_repo.update_status(
                        execution_id,
                        "running",
                        current_step=step_name,
                        progress_percent=progress
                    )

                emit_debug_trace(
                    f"PipelineExecutor.execute executing step pipeline_id={pipeline_id} "
                    f"step={step_name}"
                )

                # Executar step
                step_result = await self._execute_step(
                    step=step,
                    pipeline_config=config,
                    global_params=resolved_params,
                    execution_id=execution_id,
                    progress_callback=progress_callback
                )

                steps_results.append(step_result)

                # Acumular métricas
                total_records += step_result.get("records_processed", 0)
                total_inserted += step_result.get("records_inserted", 0)
                total_failed += step_result.get("records_failed", 0)

                if not step_result.get("success", False):
                    success = False
                    error_message = step_result.get("error_message", f"Step '{step_name}' falhou")
                    emit_debug_trace(
                        f"PipelineExecutor.execute step failed pipeline_id={pipeline_id} "
                        f"step={step_name} error={error_message}"
                    )
                    break

                emit_debug_trace(
                    f"PipelineExecutor.execute step completed pipeline_id={pipeline_id} "
                    f"step={step_name} records={step_result.get('records_processed', 0)}"
                )

        except Exception as e:
            success = False
            error_message = str(e)
            emit_debug_trace(
                f"PipelineExecutor.execute exception pipeline_id={pipeline_id} error={error_message}"
            )
            logger.error(f"Erro ao executar pipeline '{pipeline_id}': {e}", exc_info=True)

        # 5. Montar resultado final
        result = {
            "pipeline_id": pipeline_id,
            "success": success,
            "records_processed": total_records,
            "records_inserted": total_inserted,
            "records_failed": total_failed,
            "steps_results": steps_results,
            "error_message": error_message,
            "started_at": datetime.now().isoformat(),
        }

        emit_debug_trace(
            f"PipelineExecutor.execute completed pipeline_id={pipeline_id} "
            f"success={success} records={total_records}"
        )

        return result

    async def _execute_step(
        self,
        step: Dict[str, Any],
        pipeline_config: Dict[str, Any],
        global_params: Dict[str, Any],
        execution_id: Optional[str] = None,
        progress_callback: Optional[Callable] = None
    ) -> Dict[str, Any]:
        """
        Executa um único step da pipeline.

        Args:
            step: Configuração do step.
            pipeline_config: Configuração completa da pipeline.
            global_params: Parâmetros resolvidos.
            execution_id: ID da execução.
            progress_callback: Callback de progresso.

        Returns:
            Dict com resultado do step.
        """
        step_name = step.get("name", "unnamed")
        processor_nome = step.get("processor")
        step_params = step.get("parametros", {})

        start_time = datetime.now()

        try:
            # Resolver parâmetros do step (step params sobrescrevem globais)
            resolved_params = self.resolve_params(global_params, step_params)

            # Buscar processor na tabela
            processor_info = self._get_processor_info(processor_nome)
            if not processor_info:
                raise ValueError(f"Processor '{processor_nome}' não encontrado")

            # Importar e instanciar processor
            processor = self._instantiate_processor(processor_info, resolved_params)

            # Executar
            emit_debug_trace(
                f"PipelineExecutor._execute_step running processor step={step_name} "
                f"processor={processor_nome}"
            )

            if hasattr(processor, 'run_async'):
                # Processor com suporte a async
                results = await processor.run_async()
            elif asyncio.iscoroutinefunction(getattr(processor, 'run', None)):
                # Método run é async
                results = await processor.run()
            else:
                # Processor síncrono - rodar em thread
                loop = asyncio.get_event_loop()
                results = await loop.run_in_executor(None, processor.run)

            # Calcular métricas
            records_processed = 0
            records_inserted = 0
            records_failed = 0

            if isinstance(results, list):
                for group in results:
                    if isinstance(group, list):
                        for row in group:
                            if isinstance(row, (list, tuple)) and len(row) >= 4:
                                _, success, _, data = row
                                if success:
                                    records_processed += len(data) if hasattr(data, '__len__') else 1
                                    records_inserted += len(data) if hasattr(data, '__len__') else 1
                                else:
                                    records_failed += 1

            duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)

            emit_debug_trace(
                f"PipelineExecutor._execute_step completed step={step_name} "
                f"records={records_processed} duration={duration_ms}ms"
            )

            return {
                "name": step_name,
                "success": True,
                "records_processed": records_processed,
                "records_inserted": records_inserted,
                "records_failed": records_failed,
                "duration_ms": duration_ms,
            }

        except Exception as e:
            duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
            error_msg = str(e)

            emit_debug_trace(
                f"PipelineExecutor._execute_step failed step={step_name} error={error_msg}"
            )

            return {
                "name": step_name,
                "success": False,
                "records_processed": 0,
                "records_inserted": 0,
                "records_failed": 0,
                "duration_ms": duration_ms,
                "error_message": error_msg,
            }

    def _get_processor_info(self, processor_nome: str) -> Optional[Dict[str, Any]]:
        """Busca informações do processor na tabela."""
        from sqlalchemy import text

        with self.engine.connect() as conn:
            result = conn.execute(
                text("SELECT * FROM mymoney.processors WHERE nome = :nome"),
                {"nome": processor_nome}
            )
            row = result.mappings().first()
            return dict(row) if row else None

    def _instantiate_processor(
        self,
        processor_info: Dict[str, Any],
        params: Dict[str, Any]
    ) -> Any:
        """
        Instancia um processor dinamicamente.

        Args:
            processor_info: Informações do processor (modulo, classe).
            params: Parâmetros para o processor.

        Returns:
            Instância do processor.
        """
        modulo_path = processor_info.get("modulo")
        classe_nome = processor_info.get("classe")

        if not modulo_path or not classe_nome:
            raise ValueError(f"Informações incompletas do processor: {processor_info}")

        emit_debug_trace(
            f"PipelineExecutor._instantiate_processor modulo={modulo_path} classe={classe_nome}"
        )

        # Importar módulo
        try:
            modulo = importlib.import_module(modulo_path)
        except ImportError as e:
            raise ValueError(f"Não foi possível importar módulo '{modulo_path}': {e}")

        # Obter classe
        processor_cls = getattr(modulo, classe_nome, None)
        if not processor_cls:
            raise ValueError(f"Classe '{classe_nome}' não encontrada no módulo '{modulo_path}'")

        # Preparar parâmetros
        # Adicionar campos padrão que processors esperam
        contract = {
            "scope": params.get("scope", processor_info.get("nome", "unknown")),
            "schema": params.get("schema", "mymoney"),
            "table_name": params.get("table_name"),
            "operation": params.get("operation", "append"),
            "parallelize": params.get("parallelize", True),
            "progress": params.get("progress", False),
            "dry_run": params.get("dry_run", False),
            **params
        }

        # Instanciar
        instance = processor_cls(contract)

        emit_debug_trace(
            f"PipelineExecutor._instantiate_processor instantiated classe={classe_nome}"
        )

        return instance

    def resolve_params(
        self,
        global_params: Dict[str, Any],
        override_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Resolve parâmetros combinando globais com sobrescritas.

        Args:
            global_params: Parâmetros globais da pipeline.
            override_params: Parâmetros para sobrescrever.

        Returns:
            Dict com parâmetros resolvidos.
        """
        result = dict(global_params)
        result.update(override_params)
        return result

    def _build_execution_order(self, steps: List[Dict[str, Any]]) -> List[int]:
        """
        Constrói ordem de execução dos steps (topológica).

        Args:
            steps: Lista de steps.

        Returns:
            Lista de índices em ordem de execução.
        """
        # Mapear nome -> índice
        name_to_idx = {}
        for idx, step in enumerate(steps):
            name = step.get("name")
            if name:
                name_to_idx[name] = idx

        # Construir grafo de dependências
        graph = {i: [] for i in range(len(steps))}
        in_degree = {i: 0 for i in range(len(steps))}

        for idx, step in enumerate(steps):
            deps = step.get("depends_on", [])
            if isinstance(deps, list):
                for dep_name in deps:
                    if dep_name in name_to_idx:
                        dep_idx = name_to_idx[dep_name]
                        graph[dep_idx].append(idx)
                        in_degree[idx] += 1

        # Ordenação topológica (Kahn's algorithm)
        queue = [i for i in range(len(steps)) if in_degree[i] == 0]
        result = []

        while queue:
            node = queue.pop(0)
            result.append(node)

            for neighbor in graph[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if len(result) != len(steps):
            raise ValueError("Ciclo detectado nas dependências dos steps")

        return result
