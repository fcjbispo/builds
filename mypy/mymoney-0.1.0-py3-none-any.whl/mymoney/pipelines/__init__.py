# mymoney/pipelines/__init__.py

from mymoney.pipelines.executor import PipelineExecutor

__all__ = ["PipelineExecutor"]
