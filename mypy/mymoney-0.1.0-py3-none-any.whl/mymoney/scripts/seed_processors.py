"""
Seed de processors para a tabela mymoney.processors.

Este script popula a tabela com os processors existentes no sistema.
Deve ser executado após a criação das tabelas (scripts/current/mymoney.processors.ddl.sql).

Uso:
    cd /home/fcjbispo/Dev/Projects/MyMoney
    uv run python -m mymoney.scripts.seed_processors
"""

import os
import sys
from sqlalchemy import create_engine, text

# Adicionar o diretório raiz ao path
sys.path.insert(0, '/home/fcjbispo/Dev/Projects/MyMoney')

from mymoney import env


# Lista de processors existentes no sistema
PROCESSORS = [
    # Load processors - Inter
    {
        "id": "proc-inter-cc",
        "nome": "inter_cc",
        "modulo": "mymoney.data.elt.load.inter",
        "classe": "InterCartaoLoadDataProcessor",
        "descricao": "Processor para carregar extratos de cartão de crédito do Inter",
        "tipo": "load"
    },
    {
        "id": "proc-inter-conta",
        "nome": "inter_conta",
        "modulo": "mymoney.data.elt.load.inter",
        "classe": "InterAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos de conta corrente do Inter",
        "tipo": "load"
    },
    {
        "id": "proc-inter-global",
        "nome": "inter_global",
        "modulo": "mymoney.data.elt.load.inter",
        "classe": "InterGlobalAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos Inter Global",
        "tipo": "load"
    },
    {
        "id": "proc-inter-apex",
        "nome": "inter_apex",
        "modulo": "mymoney.data.elt.load.inter",
        "classe": "InterApexAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos Inter Apex",
        "tipo": "load"
    },
    {
        "id": "proc-inter-apex-nc",
        "nome": "inter_apex_nc",
        "modulo": "mymoney.data.elt.load.inter",
        "classe": "InterApexNcAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos Inter Apex NC",
        "tipo": "load"
    },
    # Load processors - Nubank
    {
        "id": "proc-nubank-conta",
        "nome": "nubank_conta",
        "modulo": "mymoney.data.elt.load.nubank",
        "classe": "NubankAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos de conta do Nubank",
        "tipo": "load"
    },
    {
        "id": "proc-nubank-cc",
        "nome": "nubank_cc",
        "modulo": "mymoney.data.elt.load.nubank",
        "classe": "NubankCartaoLoadDataProcessor",
        "descricao": "Processor para carregar extratos de cartão do Nubank",
        "tipo": "load"
    },
    # Load processors - Next
    {
        "id": "proc-next-conta",
        "nome": "next_conta",
        "modulo": "mymoney.data.elt.load.next",
        "classe": "NextAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos de conta do Next",
        "tipo": "load"
    },
    {
        "id": "proc-next-cc",
        "nome": "next_cc",
        "modulo": "mymoney.data.elt.load.next",
        "classe": "NextCartaoLoadDataProcessor",
        "descricao": "Processor para carregar extratos de cartão do Next",
        "tipo": "load"
    },
    # Load processors - PicPay
    {
        "id": "proc-picpay-conta",
        "nome": "picpay_conta",
        "modulo": "mymoney.data.elt.load.picpay",
        "classe": "PicPayAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos de conta do PicPay",
        "tipo": "load"
    },
    {
        "id": "proc-picpay-cc",
        "nome": "picpay_cc",
        "modulo": "mymoney.data.elt.load.picpay",
        "classe": "PicPayCartaoLoadDataProcessor",
        "descricao": "Processor para carregar extratos de cartão do PicPay",
        "tipo": "load"
    },
    # Load processors - Mercado Pago
    {
        "id": "proc-mercado-pago-conta",
        "nome": "mercado_pago_conta",
        "modulo": "mymoney.data.elt.load.mercado_pago",
        "classe": "MercadoPagoAccountLoadDataProcessor",
        "descricao": "Processor para carregar extratos de conta do Mercado Pago",
        "tipo": "load"
    },
    {
        "id": "proc-mercado-pago-cc",
        "nome": "mercado_pago_cc",
        "modulo": "mymoney.data.elt.load.mercado_pago",
        "classe": "MercadoPagoCartaoLoadDataProcessor",
        "descricao": "Processor para carregar extratos de cartão do Mercado Pago",
        "tipo": "load"
    },
    # Load processors - CEI
    {
        "id": "proc-cei",
        "nome": "cei",
        "modulo": "mymoney.data.elt.load.cei",
        "classe": "CeiLoadDataProcessor",
        "descricao": "Processor para carregar dados da CEI (Clear)",
        "tipo": "load"
    },
    # Load processors - FGTS
    {
        "id": "proc-fgts",
        "nome": "fgts",
        "modulo": "mymoney.data.elt.load.fgts",
        "classe": "FgtsLoadDataProcessor",
        "descricao": "Processor para carregar extratos de FGTS da CEF",
        "tipo": "load"
    },
    # Load processors - Data (Excel)
    {
        "id": "proc-data-load",
        "nome": "data_load",
        "modulo": "mymoney.data.elt.load.data",
        "classe": "DataLoadDataProcessor",
        "descricao": "Processor para carregar dados do arquivo Excel MyMoneyData.xlsx",
        "tipo": "load"
    },
    # Load processors - Classificacao
    {
        "id": "proc-classificacao-load",
        "nome": "classificacao_load",
        "modulo": "mymoney.data.elt.load.classificacao",
        "classe": "DataLoadClassificacaoProcessor",
        "descricao": "Processor para carregar classificações com embeddings",
        "tipo": "load"
    },
    # Transform processors
    {
        "id": "proc-classificacao-transform",
        "nome": "classificacao_transform",
        "modulo": "mymoney.data.elt.transform.classificacao",
        "classe": "DataTransformClassificacaoLancamentosProcessor",
        "descricao": "Processor para classificar lançamentos automaticamente",
        "tipo": "transform"
    },
]


def seed_processors():
    """Popula a tabela mymoney.processors com os processors existentes."""
    engine = create_engine(env.DB_URL)

    with engine.connect() as conn:
        # Verificar se já existem processors
        result = conn.execute(text("SELECT COUNT(*) FROM mymoney.processors"))
        count = result.scalar()

        if count > 0:
            print(f"A tabela já contém {count} processors. Pulando seed.")
            return

        inserted = 0
        skipped = 0

        for proc in PROCESSORS:
            try:
                conn.execute(
                    text("""
                        INSERT INTO mymoney.processors (
                            id, nome, modulo, classe, descricao, tipo, parametros_schema
                        ) VALUES (
                            :id, :nome, :modulo, :classe, :descricao, :tipo, '{}'::jsonb
                        )
                    """),
                    proc
                )
                inserted += 1
                print(f"✓ Inserido: {proc['nome']}")
            except Exception as e:
                if "unique" in str(e).lower() or "duplicate" in str(e).lower():
                    print(f"⚠ Já existe: {proc['nome']}")
                    skipped += 1
                else:
                    print(f"✗ Erro ao inserir {proc['nome']}: {e}")

        conn.commit()

    print(f"\nSeed concluído: {inserted} inseridos, {skipped} ignorados")


if __name__ == "__main__":
    seed_processors()
