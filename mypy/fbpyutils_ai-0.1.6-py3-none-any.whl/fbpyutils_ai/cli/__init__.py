"""CLI entry point for fbpyutils-ai.

The CLI is the "application final" and owns logging (fbpyutils v1.10.0,
ADR-0007). ``fbpyutils.setup()`` is called here in the group callback — never
in package ``__init__.py`` — so ``import fbpyutils_ai`` as a library stays
inert regarding logging.
"""

import os

import typer
from rich.console import Console
from rich import print as rprint

from fbpyutils_ai import __version__
from .websearch import websearch
from .webscrape import webscrape
from .extractmd import extractmd

console = Console()

cli = typer.Typer(
    name="fbpyutils-ai",
    help="FBPyUtils AI - Command Line Interface for AI Utilities.",
    add_completion=True,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

_APP_JSON = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app.json"
)
# ponytail: text fallback only used if python-json-logger is unavailable (json is the default).
_TEXT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def _setup_logging() -> None:
    """Configure logging for the CLI (application final, ADR-0007).

    ``fbpyutils.setup()`` reads ``app.json`` (``log_format=json``,
    ``log_handlers=["file"]``) and applies the ``FBPY_LOG_LEVEL`` env override
    (handled internally by ``Env``). Falls back to a text format if
    ``python-json-logger`` is unavailable.
    """
    import fbpyutils
    from fbpyutils import Logger

    try:
        fbpyutils.setup(_APP_JSON)
    except ImportError:
        # python-json-logger missing → text fallback (path derived from app_name).
        Logger.configure_for_app(
            app_name="FBPyUtils_AI",
            log_level=os.environ.get("FBPY_LOG_LEVEL", "INFO"),
            log_format=_TEXT_FORMAT,
            log_handlers=["file"],
        )


def version_callback(value: bool) -> None:
    """Show version and exit (single source: package metadata)."""
    if value:
        rprint(f"[bold blue]fbpyutils-ai[/bold blue] version [green]{__version__}[/green]")
        raise typer.Exit()


@cli.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """FBPyUtils AI - Command Line Interface for AI Utilities."""
    _setup_logging()


cli.command(name="websearch")(websearch)
cli.command(name="webscrape")(webscrape)
cli.command(name="extractmd")(extractmd)


if __name__ == "__main__":
    cli()