"""
fbpyutils_ai — AI utilities (LLM, vector DBs, web search/scrape, document conversion).

Library logging pattern (fbpyutils v1.10.0, ADR-0007 — logger ownership belongs to
the client application):

- This package is a **library**. It does **not** call ``fbpyutils.setup()`` on
  import and does not reconfigure logging of the host process.
- Modules use ``logging.getLogger(__name__)`` with a ``NullHandler`` — silent
  until the host application configures logging.
- The CLI (``fbpyutils-ai``) is the "application final" and owns logging setup;
  see :mod:`fbpyutils_ai.cli`.

A host application that imports this library is responsible for its own
``fbpyutils.setup()``. When run via the CLI, logging is configured in the CLI
entry point.

Environment variables (read lazily by the modules that need them):

    FBPY_LOG_LEVEL          log level override (applied by the CLI setup)
    FBPY_SEMAPHORES          LLM request concurrency limit (default 6)
    FBPY_OPENAI_*            LLM provider config
    FBPY_SEARXNG_BASE_URL    SearXNG base URL
    FBPY_FIRECRAWL_*         FireCrawl config
    FBPY_VECTORDB_URL        PostgreSQL+pgvector connection string
    FBPY_CHROMADB_*          ChromaDB config
    FBPY_PINECONE_API_KEY    Pinecone API key

Example
-------
>>> import fbpyutils_ai  # no logging side effects
>>> from fbpyutils_ai.llm import OpenAILLMService
"""

import os
import logging
from importlib.metadata import version as _pkg_version, PackageNotFoundError

from dotenv import load_dotenv

# Load .env if present (no-op if absent). Host apps may pre-load their own.
_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    __version__ = _pkg_version("fbpyutils_ai")
except PackageNotFoundError:  # not installed (e.g. running from source without metadata)
    __version__ = "0.0.0+unknown"

# Library logger: silent until the host application configures logging.
logger = logging.getLogger("fbpyutils_ai")
if not logger.handlers:
    logger.addHandler(logging.NullHandler())