"""
OmniChat core functionality for FBNet OmniChat.

This module defines the OmniChat class, which provides the main logic for
handling chat interactions, including reading content from various sources,
sanitizing prompts, processing variables, and sending messages to agents.
"""

import os
import re
import requests
import pyperclip

from fbnet_omnichat import logger
from fbnet_omnichat.agents import Agent  # Agent is needed for type hinting
from fbnet_omnichat.utils import AgentFactory  # AgentFactory to create the agents
from fbpyutils.file import get_base64_data_from


class OmniChat:
    """
    Class for executing quick commands using a chat agent.

    Attributes:
        agent (Agent): The chat agent instance to be used.
    """

    def __init__(self, agent: Agent = None):
        """
        Initializes the OmniChat instance.

        Args:
            agent (Agent, optional): An instance of an Agent. If None,
                                     an agent will be created via AgentFactory based on FBNET_OMNICHAT_AGENT env var (defaults to "omnichat").
        """
        if agent is None:
            agent_name = os.environ.get("FBNET_OMNICHAT_AGENT", "omnichat")
            self.agent = AgentFactory.create_agent(agent_name)
        else:
            self.agent = agent

    def read_contents(self, path: str, as_base64: bool = False) -> str:
        """
        Reads content from a given path, which can be a local file or a URL.

        Args:
            path (str): The path to the file or URL to read.

        Returns:
            str: The content read from the path.

        Raises:
            FileNotFoundError: If a local file is not found.
            requests.RequestException: If there's an error accessing a remote URL.
        """
        try:
            if as_base64:
                return get_base64_data_from(path)

            if path.startswith(("http://", "https://")):
                proxies = {
                    "http": os.getenv("HTTP_PROXY"),
                    "https": os.getenv("HTTPS_PROXY"),
                }
                response = requests.get(path, proxies=proxies)
                response.raise_for_status()
                return response.text
            else:
                if not os.path.exists(path):
                    path = os.path.sep.join([os.getcwd(), path])
                with open(path, "r", encoding="utf-8") as arquivo:
                    return arquivo.read()
        except FileNotFoundError:
            logger.error(f"Local file not found: ({path})")
            raise FileNotFoundError(f"Local file not found: ({path})")
        except requests.RequestException as e:
            logger.error(f"Error accessing remote file: ({path}) - {e}")
            raise requests.RequestException(f"Error accessing remote file: ({path})")

    def sanitize_prompt(self, prompt: str) -> str:
        """
        Sanitizes the input prompt to remove potential code injections or unwanted patterns.

        Args:
            prompt (str): The original prompt string.

        Returns:
            str: The sanitized prompt string.
        """
        sanitized_prompt = re.sub(r"(<:)(.)($|))", "", prompt)
        sanitized_prompt = re.sub(r"\b(import|exec)\w+", "", sanitized_prompt)
        return sanitized_prompt

    def clean_result(self, result: str) -> str:
        """
        Removes code markers and extra newlines/tabs from the processed result.

        Args:
            result (str): The raw result string from the chat agent.

        Returns:
            str: The cleaned result string.
        """
        result = re.sub(r"\n", "", result, flags=re.DOTALL)
        result = re.sub(r"\t", "", result)
        return result.strip()

    def process_vars(self, text: str, var: list) -> str:
        """
        Processes variables within the text, replacing placeholders with their actual values.
        Variables can be defined directly, read from local/remote files, or from the clipboard.

        Args:
            text (str): The input text containing variable placeholders.
            var (list): A list of variable definitions in "VAR=VALUE" format.

        Returns:
            str: The text with all variables processed and replaced.

        Raises:
            ValueError: If a variable is not in the correct format or a path is empty.
            FileNotFoundError: If a file specified in a variable value is not found.
        """
        for v in var:
            key, value = v.split("=", 1)
            if not key or not value:
                logger.error(f"Variable '{v}' must be in VAR=VALUE format.")
                raise ValueError(f"Variable '{v}' must be in VAR=VALUE format.")
            key = f"{{{{{key.strip()}}}}}"
            if value.startswith("@") or value.startswith("#"):
                caminho = value[1:]  # path in portugues
                if not caminho:
                    logger.error(
                        f"Error processing variable '{v}': path cannot be empty."
                    )
                    raise ValueError(
                        f"Error processing variable '{v}': path cannot be empty."
                    )
                caminho = (
                    caminho.strip()
                    .replace("~", os.path.expanduser("~"))
                    .replace("\\", "/")
                )  # replacing ~ and \ for consistency
                if not os.path.isabs(caminho) and not caminho.startswith(
                    ("http://", "https://")
                ):
                    caminho = os.path.join(os.getcwd(), caminho)
                if not os.path.exists(caminho) and not caminho.startswith(
                    ("http://", "https://")
                ):
                    logger.error(f"Local file not found: ({caminho})")
                    raise FileNotFoundError(f"Local file not found: ({caminho})")
                as_base64 = True if value.startswith("#") else False
                value = self.read_contents(caminho, as_base64=as_base64)
            if len(value) == 1 and value[0] == "^":
                value = pyperclip.paste()
            text = text.replace(key, value.strip())
        return text

    def send(self, text: str) -> str:
        """
        Sends the processed text to the configured chat agent and returns its response.

        Args:
            text (str): The text to send to the agent.

        Returns:
            str: The response from the agent.
        """
        return self.agent.send(text)
