"""
Utility functions and classes for FBNet OmniChat.

This module provides helper utilities such as copying content to the clipboard
and a factory for creating different types of chat agents.
"""

import pyperclip
from fbnet_omnichat import logger
from fbnet_omnichat.agents import Agent
from fbnet_omnichat.agents.lmstudio import LMStudioCLIAgent
from fbnet_omnichat.agents.omni import OmniAgent
from fbnet_omnichat.agents.ollama import OllamaCLIAgent


def copy_to_clipboard(text: str) -> None:
    """
    Copies the given text to the system clipboard.

    Args:
        text (str): The text content to be copied.
    """
    try:
        pyperclip.copy(text)
        logger.debug("Content copied to clipboard.")
    except pyperclip.PyperclipException as e:
        logger.error(f"Failed to copy to clipboard: {e}")


class AgentFactory:
    """
    Factory class for creating Agent instances based on a given agent name.
    """

    @staticmethod
    def create_agent(agent_name: str) -> Agent:
        """
        Creates and returns an Agent instance based on the provided name.

        Args:
            agent_name (str): The name of the agent to create (e.g., "lmstudio", "omnichat").

        Returns:
            Agent: An instance of the specified agent.

        Raises:
            ValueError: If the agent name is not recognized.
        """
        if agent_name == "lmstudio":
            return LMStudioCLIAgent()
        elif agent_name == "omnichat":
            return OmniAgent()
        elif agent_name == "ollama":
            return OllamaCLIAgent()
        else:
            raise ValueError(
                f"Agent '{agent_name}' not recognized. Valid options are: lmstudio, omnichat, ollama."
            )
