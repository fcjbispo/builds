"""
Command-Line Interface (CLI) for FBNet OmniChat.

This module provides the main entry point for the OmniChat application,
handling command-line arguments, agent selection, and execution of chat commands.
"""

import os
import sys
import json
import click
from datetime import datetime

import requests

from fbnet_omnichat import logger, DEFAULT_AGENT
from fbnet_omnichat.omnichat import OmniChat
from fbnet_omnichat.utils import copy_to_clipboard, AgentFactory

# Load app configuration directly from app.json
_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_CONFIG_FILE = os.path.sep.join([_ROOT_DIR, "app.json"])

with open(_APP_CONFIG_FILE, "r", encoding="utf-8") as f:
    app_config = json.load(f)

APP_ABOUT = f"{app_config['app']['name']} v{app_config['app']['version']}"


@click.command()
@click.option(
    "-a",
    "--agent",
    default=None,
    help="Specifies the agent to use for the chat. Ex: lmstudio, omnichat [default: omnichat].",
)
@click.option(
    "-t",
    "--text",
    default=None,
    help="Text to be sent to the chat. If not provided, reads information from standard input.",
)
@click.option(
    "-f",
    "--file",
    default=None,
    help="Reads the content of the file pointed to by the given path and sends it to the chat. Cannot be used with --input.",
)
@click.option(
    "-o",
    "--output",
    default=None,
    help="Specifies the file where the chat result will be saved. If not provided, the result will be displayed on the console.",
)
@click.option(
    "-v",
    "--var",
    multiple=True,
    help="Add multiple variables in VAR=VALUE format. Values in ((VAR)) format will be replaced.\n"
    "Use @<local_or_remote_path> to provide a file or url with the content to be assigned to the variable as text.\n"
    "Use #<local_or_remote_path> to provide a file or url with the content to be assigned to the variable as base64 text.\n"
    "Use ^ to read content from the clipboard and use it in the variable.",
    default=[],
)
@click.option(
    "--sanitize",
    is_flag=True,
    help="Performs sanitization of the input prompt before sending to the Agent\n"
    "for possible code removal.",
)
@click.option(
    "--clean",
    is_flag=True,
    help="Removes code markers from the processed result. Ex: `python and...`",
)
@click.option(
    "--copy",
    is_flag=True,
    help="Copies the chat result to the clipboard.",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Executes the command without displaying status or progress messages,\n"
    "only errors.",
)
@click.option(
    "--no-history",
    is_flag=True,
    help="Does not record chat execution in the history log.",
)
@click.option(
    "--clear-history",
    is_flag=True,
    help="Does not record chat execution in the history log and additionally clears the history.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Only displays the call to be sent to the chat, ignoring history log flags.",
)
@click.option("--version", is_flag=True, help="Display the current tool version.")
def main(
    agent,
    text,
    file,
    output,
    var,
    sanitize,
    clean,
    copy,
    quiet,
    no_history,
    clear_history,
    dry_run,
    version,
):
    """
    FBNet OmniChat CLI tool for interacting with various chat agents.
    """
    if version:
        click.echo(APP_ABOUT)
        sys.exit(0)

    if all([text, file]):
        click.echo("Error: You cannot provide both --text and --file.", err=True)
        sys.exit(1)

    if file is not None:
        if not os.path.isfile(file):
            click.echo(f"Error: The file '{file}' does not exist.", err=True)
            sys.exit(1)
        try:
            with open(file, "r", encoding="utf-8") as f:
                text = f.read().strip()
        except Exception as e:
            click.echo(f"Error reading file '{file}': {e}", err=True)
            sys.exit(1)

    if text is None:
        if sys.stdin.isatty():  # Check if stdin is connected to a terminal
            text = click.prompt("Enter text (press Enter to finish)", type=str)
        else:
            text = sys.stdin.read().strip()

    _tab, _lf = "\t", "\n"

    agent_name = agent if agent is not None else DEFAULT_AGENT
    agent_name = agent_name.lower()

    try:
        chat_agent = AgentFactory.create_agent(agent_name)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    chat = OmniChat(agent=chat_agent)

    try:
        if sanitize:
            text = chat.sanitize_prompt(text)
        text = chat.process_vars(text, var)
        if dry_run:
            click.echo(",".join(text.split("\n")).strip(), nl=True, color=True)
        else:
            result = chat.send(text)
            if clean:
                result = chat.clean_result(result)
            if output:
                try:
                    with open(output, "w", encoding="utf-8") as f:
                        f.write(result)
                    if not quiet:
                        click.echo(f"Result saved to: ({output})", nl=True, color=True)
                except IOError as e:
                    click.echo(f"Error saving result to '{output}': {e}", err=True)
                    sys.exit(1)
            else:
                click.echo(result, nl=True, color=True)
            if copy:
                copy_to_clipboard(result)
            if not no_history:
                history_file_path = os.path.sep.join(
                    [os.path.expanduser("~"), ".rqc_history"]
                )
                write_mode = "a"
                content = f"{datetime.isoformat(datetime.now())}{_tab}{chat.agent.get_name()}{_tab}{' '.join(text.split(_lf)).strip()}{_lf}"
                if clear_history:
                    write_mode = "w"
                    content = ""
                with open(
                    history_file_path, write_mode, encoding="utf-8"
                ) as history_file:
                    history_file.write(content)
    except requests.RequestException as e:
        logger.error(f"HTTP error during chat execution: {e}", exc_info=True)
        click.echo(f"HTTP error during chat execution: {e}", err=True)
        sys.exit(1)
    except ValueError as e:  # Catching specific ValueError from AgentFactory
        logger.error(f"Error initializing agent: {e}", exc_info=True)
        click.echo(f"Error initializing agent: {e}", err=True)
        sys.exit(1)
    except (
        FileNotFoundError
    ) as e:  # Catching specific FileNotFoundError from read_contents or process_vars
        logger.error(f"File not found: {e}", exc_info=True)
        click.echo(f"File not found: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        logger.error(
            f"Error executing chat with {chat.agent.get_name()}: {str(e)}",
            exc_info=True,
        )
        click.echo(
            f"Error executing chat with {chat.agent.get_name()}: {str(e)}.", err=True
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
