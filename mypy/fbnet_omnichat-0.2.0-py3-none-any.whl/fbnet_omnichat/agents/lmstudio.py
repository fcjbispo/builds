"""
LMStudio Agent implementation for FBNet OmniChat.

This module contains the LMStudioAgent class that implements the Agent interface
for interacting with LMStudio's local language model server via CLI.
"""

import os
import subprocess
import sys  # Import sys to check OS
import shutil  # Import shutil for which()
from typing import Optional

from fbnet_omnichat import logger
from . import Agent


class LMStudioCLIAgent(Agent):
    """
    Agent implementation for LMStudio's local language model server via CLI.

    This agent communicates with a locally running LMStudio instance
    by executing the 'lms' command-line tool to generate responses.
    """

    def __init__(self):
        """
        Initialize the LMStudio agent.
        """
        self._name = "lmstudio"
        self._lms_command: Optional[str] = self._find_lms_command()
        if not self._lms_command:
            logger.error(
                "LMStudio 'lms' command not found. Please ensure LMStudio is installed and configured in your PATH."
            )
            raise FileNotFoundError("LMStudio 'lms' command not found.")

    def _find_lms_command(self) -> Optional[str]:
        """
        Finds the LMStudio CLI executable in the system's PATH.
        Handles Windows-specific executable names (lms.exe).

        Returns:
            Optional[str]: The full path to the 'lms' executable if found, None otherwise.
        """
        if sys.platform == "win32":
            # On Windows, try both 'lms.exe' and 'lms'
            command_candidates = ["lms.exe", "lms"]
        else:
            # On other OS, just try 'lms'
            command_candidates = ["lms"]

        for cmd in command_candidates:
            full_path = shutil.which(cmd)
            if full_path:
                logger.debug(f"LMStudio command '{cmd}' found at: {full_path}")
                return full_path
        return None

    def get_name(self) -> str:
        """
        Get the name of the agent.

        Returns:
            str: The name of the agent.
        """
        return self._name

    def send(self, text: str) -> str:
        """
        Send a text message to the LMStudio agent via CLI and get a response.

        Args:
            text (str): The text message to send to the agent.

        Returns:
            str: The response from the agent.
        """
        model = os.environ.get("FBNET_OMNICHAT_MODEL", "google/gemma-3n-e4b")
        # Define a safe maximum length for command-line arguments in Windows
        # Windows typically has a limit around 8191 or 32768, choosing a conservative value
        MAX_CMD_LENGTH = 4096

        input_data = None

        if len(text) > MAX_CMD_LENGTH and sys.platform == "win32":
            logger.info(
                "Prompt exceeds maximum command length for Windows. Sending via stdin."
            )
            comando = [self._lms_command, "chat", model]  # No --prompt argument
            input_data = text
        else:
            comando = [self._lms_command, "chat", "--prompt", text, model]

        logger.debug(
            f"Executing command: {' '.join(comando)} with input data: {input_data is not None}"
        )

        try:
            resultado = subprocess.run(
                comando,
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=True,
                input=input_data,  # Pass input data via stdin if set
            )
            return resultado.stdout
        except subprocess.CalledProcessError as e:
            logger.error(f"Error executing LMStudio command: {e}")
            logger.error(f"Stderr: {e.stderr}")
            return f"Error executing LMStudio command: {e.stderr}"
        except Exception as e:
            logger.error(
                f"An unexpected error occurred while communicating with LMStudio: {e}"
            )
            return f"An unexpected error occurred: {e}"
