"""
Ollama Agent implementation for FBNet OmniChat.

This module contains the OllamaCLIAgent class that implements the Agent interface
for interacting with Ollama's local language model server via CLI.
"""

import os
import subprocess
import sys  # Import sys to check OS
import shutil  # Import shutil for which()
from typing import Optional

from fbnet_omnichat import logger
from . import Agent


class OllamaCLIAgent(Agent):
    """
    Agent implementation for Ollama's local language model server via CLI.

    This agent communicates with a locally running Ollama instance
    by executing the 'ollama' command-line tool to generate responses.
    """

    def __init__(self):
        """
        Initialize the Ollama agent.
        """
        self._name = "ollama"
        self._ollama_command: Optional[str] = self._find_ollama_command()
        if not self._ollama_command:
            logger.error(
                "Ollama 'ollama' command not found. Please ensure Ollama is installed and configured in your PATH."
            )
            raise FileNotFoundError("Ollama 'ollama' command not found.")

    def _find_ollama_command(self) -> Optional[str]:
        """
        Finds the Ollama CLI executable in the system's PATH.
        Handles Windows-specific executable names (ollama.exe).

        Returns:
            Optional[str]: The full path to the 'ollama' executable if found, None otherwise.
        """
        if sys.platform == "win32":
            # On Windows, try both 'ollama.exe' and 'ollama'
            command_candidates = ["ollama.exe", "ollama"]
        else:
            # On other OS, just try 'ollama'
            command_candidates = ["ollama"]

        for cmd in command_candidates:
            full_path = shutil.which(cmd)
            if full_path:
                logger.debug(f"Ollama command '{cmd}' found at: {full_path}")
                return full_path
        return None

    def get_name(self) -> str:
        """
        Get the name of the agent.

        Returns:
            str: The name of the agent.
        """
        return self._name

    def send(self, text: str) -> str:
        """
        Send a text message to the Ollama agent via CLI and get a response.

        Args:
            text (str): The text message to send to the agent.

        Returns:
            str: The response from the agent.
        """
        model = os.environ.get("FBNET_OMNICHAT_MODEL", "llama3")
        # Define a safe maximum length for command-line arguments in Windows
        # Windows typically has a limit around 8191 or 32768, choosing a conservative value
        MAX_CMD_LENGTH = 4096

        input_data = None

        if len(text) > MAX_CMD_LENGTH and sys.platform == "win32":
            logger.info(
                "Prompt exceeds maximum command length for Windows. Sending via stdin."
            )
            comando = [
                self._ollama_command,
                "run",
                model,
            ]  # No prompt argument, use stdin
            input_data = text
        else:
            comando = [self._ollama_command, "run", model, text]

        logger.debug(
            f"Executing command: {' '.join(comando)} with input data: {input_data is not None}"
        )

        try:
            resultado = subprocess.run(
                comando,
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=True,
                input=input_data,  # Pass input data via stdin if set
            )
            return resultado.stdout
        except subprocess.CalledProcessError as e:
            logger.error(f"Error executing Ollama command: {e}")
            logger.error(f"Stderr: {e.stderr}")
            return f"Error executing Ollama command: {e.stderr}"
        except Exception as e:
            logger.error(
                f"An unexpected error occurred while communicating with Ollama: {e}"
            )
            return f"An unexpected error occurred: {e}"
