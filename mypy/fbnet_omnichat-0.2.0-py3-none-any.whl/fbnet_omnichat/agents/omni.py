"""
OmniAgent implementation for FBNet OmniChat.

This module contains the OmniAgent class that implements the Agent interface
with a simulated chat response.
"""

from . import Agent


class OmniAgent(Agent):
    """
    Agent implementation for OmniChat with a simulated response.

    This agent provides a placeholder implementation for chat interactions,
    returning a predefined simulated response.
    """

    def __init__(self):
        """
        Initialize the OmniAgent.
        """
        self._name = "omnichat"

    def get_name(self) -> str:
        """
        Get the name of the agent.

        Returns:
            str: The name of the agent.
        """
        return self._name

    def send(self, text: str) -> str:
        """
        Simulate sending a text message to the OmniAgent and get a response.

        Args:
            text (str): The text message to send to the agent.

        Returns:
            str: A simulated response from the agent.
        """
        # Simulate sending a chat command
        return f"Sent chat with input: {text}"
