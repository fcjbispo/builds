"""
Agents module for FBNet OmniChat.

This module contains the abstract base class for all agents and provides
the interface that must be implemented by any concrete agent.
"""

from abc import ABC, abstractmethod


class Agent(ABC):
    """
    Abstract base class for all chat agents.

    This class defines the interface that all agents must implement.
    Concrete agent implementations should inherit from this class
    and implement the abstract methods.
    """

    @abstractmethod
    def get_name(self) -> str:
        """
        Get the name of the agent.

        Returns:
            str: The name of the agent.
        """
        pass

    @abstractmethod
    def send(self, text: str) -> str:
        """
        Send a text message to the agent and get a response.

        Args:
            text (str): The text message to send to the agent.

        Returns:
            str: The response from the agent.
        """
        pass
