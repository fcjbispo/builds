import os
from fbpyutils import setup, get_env, get_logger

from dotenv import load_dotenv

_ = load_dotenv()  # take environment variables from .env.

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_CONFIG_FILE = os.path.sep.join([_ROOT_DIR, "app.json"])

setup(_APP_CONFIG_FILE)

env = get_env()
logger = get_logger()

DEFAULT_AGENT = os.environ.get("FBNET_OMNICHAT_AGENT", "omnichat")
