import pandas as pd
from sqlalchemy import Engine, MetaData, Table, Column
from typing import List

from fbpyutils_db import logger

# Importa funções de outros módulos
from fbpyutils_db.database.index import create_index
from fbpyutils_db.database.types import get_columns_types


def create_table(
    dataframe: pd.DataFrame,
    engine: Engine,
    table_name: str,
    schema: str = None,
    keys: List[str] = [],
    index: str = None,
) -> None:
    """Create a table in the database using a pandas DataFrame as schema.

    This function creates a database table with columns derived from the
    DataFrame's structure. Optionally creates primary keys or indexes on
    specified columns.

    Parameters
    ----------
    dataframe : pd.DataFrame
        The pandas DataFrame containing the schema information.
    engine : sqlalchemy.engine.Engine
        The SQLAlchemy engine for database connection.
    table_name : str
        The name of the table to be created.
    schema : str, optional
        The name of the schema where the table will be created.
        Default is None (default schema).
    keys : list of str, optional
        List of column names to use as keys for index or primary key
        creation. Default is empty list.
    index : {'standard', 'unique', 'primary'}, optional
        The type of index to create using the keys:
        - 'standard': Create a non-unique index
        - 'unique': Create a unique index
        - 'primary': Create a primary key constraint
        Default is None (no index created).

    Returns
    -------
    None
        The table is created in the database.

    Raises
    ------
    ValueError
        If `dataframe` is not a pandas DataFrame, `keys` is not a list,
        or `index` is not one of 'standard', 'unique', or 'primary'.

    Examples
    --------
    Create a simple table:

    >>> import pandas as pd
    >>> from sqlalchemy import create_engine
    >>> from fbpyutils_db.database.table import create_table
    >>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30]})
    >>> engine = create_engine('sqlite:///:memory:')
    >>> create_table(df, engine, 'users')

    Create a table with a unique index:

    >>> df = pd.DataFrame({'email': ['a@b.com', 'c@d.com'], 'name': ['Alice', 'Bob']})
    >>> create_table(df, engine, 'users', keys=['email'], index='unique')

    Create a table with a primary key:

    >>> df = pd.DataFrame({'id': [1, 2], 'name': ['Alice', 'Bob']})
    >>> create_table(df, engine, 'users', keys=['id'], index='primary')

    Notes
    -----
    - Column types are automatically inferred from DataFrame dtypes
    - The table is created in the specified schema or default schema
    - Index names are automatically generated as `{table_name}_i001_{uk|ik}`
    - Primary keys are created as table constraints, not indexes
    - The function uses SQLAlchemy's `create_all()` which is idempotent

    See Also
    --------
    create_index : Create an index on a table
    get_columns_types : Get column types from DataFrame
    sqlalchemy.Table : SQLAlchemy Table class
    """
    logger.info(f"Creating table '{table_name}' in schema '{schema}'")

    # Check parameters
    if not type(dataframe) == pd.DataFrame:
        logger.error("Invalid dataframe type provided")
        raise ValueError("Dataframe must be a Pandas DataFrame.")

    if keys and not type(keys) == list:
        logger.error("Invalid keys type provided")
        raise ValueError("Parameters 'keys' must be a list of str.")

    if keys and index and index not in ("standard", "unique", "primary"):
        logger.error(f"Invalid index type: {index}")
        raise ValueError(
            "If an index will be created, it must be any of standard|unique|primary."
        )

    logger.debug(f"Creating table with keys: {keys}, index type: {index}")

    metadata = MetaData(schema)

    if keys and index == "primary":
        columns = get_columns_types(dataframe, primary_keys=keys)
    else:
        columns = get_columns_types(dataframe, primary_keys=[])

    table = Table(table_name, metadata, *columns)

    # Create the index if required
    if keys and index in ("standard", "unique"):
        unique = index == "unique"
        idx_suffix = "uk" if unique else "ik"
        index_name = f"{table_name}_i001_{idx_suffix}"
        logger.debug(f"Creating {index} index '{index_name}' on columns: {keys}")
        table.indexes.add(create_index(index_name, table, keys, unique))

    logger.info(f"Creating table structure in database")
    result = metadata.create_all(engine)
    logger.info(f"Table '{table_name}' created successfully")
    return result
