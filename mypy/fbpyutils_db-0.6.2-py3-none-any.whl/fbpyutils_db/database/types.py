import pandas as pd
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql.sqltypes import TypeEngine
from typing import Any, List

from fbpyutils_db import logger

from fbpyutils_db.data.converters import (
    as_float,
    as_boolean,
    as_string,
    as_integer,
    as_dict,
    as_date,
    as_datetime,
)


def get_columns_types(
    dataframe: pd.DataFrame, primary_keys: List[str] = []
) -> List[Column]:
    """
    Returns a list of Column objects representing the columns of the given dataframe.
    Args:
        dataframe (pandas.DataFrame): The input dataframe for which column types are to be determined.
        primary_keys (List[str]): Optional list of primary key column names.
    Returns:
        list: A list of Column objects, where each object represents a column in the dataframe.
    Raises:
        None.
    Example:
        >>> df = pd.DataFrame({'A': [1, 2, 3], 'B': ['a', 'b', 'c']})
        >>> get_columns_types(df)
        [Column('A', 'int64'), Column('B', 'object')]
    Column object:
        - The Column object represents a column in a dataframe and stores its name and type.
        Attributes:
            name (str): The name of the column.
            dtype (str): The data type of the column.
        Example:
            >>> col = Column('A', 'int64')
            >>> col.name
            'A'
            >>> col.dtype
            'int64'
    """
    logger.debug(
        f"Getting column types for DataFrame with {len(dataframe.columns)} columns"
    )
    logger.debug(f"Primary keys: {primary_keys}")

    columns = []
    for col in dataframe.columns:
        col_type = get_column_type(dataframe.dtypes[col])
        is_primary = col in primary_keys
        logger.debug(f"Column '{col}': type={col_type}, primary_key={is_primary}")
        columns.append(
            Column(
                col,
                col_type,
                primary_key=is_primary,
            )
        )

    logger.info(f"Generated {len(columns)} column definitions")
    return columns


def get_column_type(dtype: str) -> TypeEngine:
    """
    Map Pandas data types to SQLAlchemy data types.

    Args:
        dtype (dtype): The Pandas data type to be mapped.

    Returns:
        sqlalchemy.sql.sqltypes.TypeEngine: The corresponding SQLAlchemy data type.
        For string columns, a default 4000 chars lenght column is created.

    """
    logger.debug(f"Mapping pandas dtype '{dtype}' to SQLAlchemy type")

    if dtype in ("int64", "int32", "int"):
        sql_type = Integer()
    elif dtype in ("float64", "float32", "float"):
        sql_type = Float()
    elif dtype == "bool":
        sql_type = Boolean()
    elif dtype == "object":
        sql_type = String(4000)
    elif dtype == "datetime64[ns]":
        sql_type = DateTime()
    else:
        logger.warning(f"Unknown pandas dtype '{dtype}', defaulting to String(4000)")
        sql_type = String(4000)

    logger.debug(f"Mapped '{dtype}' to {type(sql_type).__name__}")
    return sql_type


def map_dtype(dtype: str) -> Any:
    """Map a data type string to its corresponding converter function.

    This function returns the appropriate converter function for a given
    data type string. The converter functions are from the converters module
    and handle type conversion with proper NaN handling.

    Parameters
    ----------
    dtype : str
        The data type string to map. Valid values include:
        'string', 'object', 'date', 'datetime', 'datetime64[ns]',
        'datetime64[ms]', 'float', 'float64', 'int', 'int64',
        'bool', 'boolean', 'json', 'dict'.

    Returns
    -------
    callable
        The converter function for the specified data type.
        Returns as_string for unknown types.

    Examples
    --------
    Get converter functions for different types:

    >>> from fbpyutils_db.database.types import map_dtype
    >>> int_converter = map_dtype('int64')
    >>> int_converter('42')
    42
    >>> float_converter = map_dtype('float64')
    >>> float_converter('3.14')
    3.14

    Handle unknown types:

    >>> unknown_converter = map_dtype('unknown_type')
    >>> unknown_converter('value')
    'value'

    Notes
    -----
    - Unknown data types default to string conversion
    - Multiple aliases map to the same converter (e.g., 'bool' and 'boolean')
    - The returned function handles NaN values appropriately

    See Also
    --------
    apply_dtype : Apply a converter function to a value
    fbpyutils_db.data.converters : Type conversion functions
    """
    dtype_map = {
        "string": as_string,
        "object": as_string,
        "date": as_date,
        "datetime": as_datetime,
        "datetime64[ns]": as_datetime,
        "datetime64[ms]": as_datetime,
        "float": as_float,
        "float64": as_float,
        "int": as_integer,
        "int64": as_integer,
        "bool": as_boolean,
        "boolean": as_boolean,
        "json": as_dict,
        "dict": as_dict,
    }

    return dtype_map.get(dtype, as_string)


def apply_dtype(x, dtype) -> Any:
    """Apply a data type converter to a value.

    This function converts a value to the specified data type using the
    appropriate converter function. It handles NaN values gracefully and
    provides type-safe conversion.

    Parameters
    ----------
    x : any
        The value to convert.
    dtype : str
        The target data type. Valid values include:
        'string', 'object', 'date', 'datetime', 'datetime64[ns]',
        'datetime64[ms]', 'float', 'float64', 'int', 'int64',
        'bool', 'boolean', 'json', 'dict'.

    Returns
    -------
    any
        The converted value, or NaN/None for invalid inputs.

    Examples
    --------
    Convert values to different types:

    >>> from fbpyutils_db.database.types import apply_dtype
    >>> apply_dtype('42', 'int64')
    42
    >>> apply_dtype('3.14', 'float64')
    3.14
    >>> apply_dtype('Y', 'boolean')
    True

    Handle NaN values:

    >>> import pandas as pd
    >>> apply_dtype(pd.NA, 'int64')
    <NA>

    Notes
    -----
    - Uses map_dtype internally to get the converter function
    - All converter functions handle NaN values appropriately
    - Unknown data types default to string conversion

    See Also
    --------
    map_dtype : Get converter function for a data type
    fbpyutils_db.data.converters : Type conversion functions
    """
    f = map_dtype(dtype)
    return f(x)
