from typing import Any, List
from fbpyutils_db import logger


def ascii_table(
    data: List[List[Any]],
    columns: List[str] = [],
    alignment: str = "left",
    numrows: int = None,
) -> List[str]:
    """Create an ASCII table representation of the given data.

    This function generates a formatted ASCII table from a list of lists
    containing data values. The table includes column headers, borders,
    and configurable alignment for cell content.

    Parameters
    ----------
    data : list of list
        A list of lists representing the data rows. Each inner list
        represents a single row of data.
    columns : list of str, optional
        A list of column names. If empty or None, default column names
        (column_0, column_1, etc.) are generated. Default is empty list.
    alignment : {'left', 'right', 'center'}, optional
        The alignment of the table cells. Valid values are 'left', 'right',
        or 'center'. Default is 'left'.
    numrows : int, optional
        The number of rows to display. If None or greater than the number
        of data rows, all rows are displayed. Default is None.

    Returns
    -------
    list of str
        A list of strings representing the ASCII table, including borders
        and headers. Returns None if data is empty.

    Raises
    ------
    ValueError
        If rows have different column counts, alignment is invalid, or
        column count doesn't match data row count.

    Examples
    --------
    Create a simple ASCII table:

    >>> from fbpyutils_db.visualization.ascii_table import ascii_table
    >>> data = [['John', 25, 'USA'], ['Alice', 30, 'Canada'], ['Bob', 40, 'UK']]
    >>> columns = ['Name', 'Age', 'Country']
    >>> table = ascii_table(data, columns=columns, alignment='center')
    >>> for line in table:
    ...     print(line)
    +-------+-----+---------+
    |  Name | Age | Country |
    +-------+-----+---------+
    |  John |  25 |   USA   |
    | Alice |  30 |  Canada |
    |  Bob  |  40 |    UK   |
    +-------+-----+---------+

    Limit number of rows:

    >>> table = ascii_table(data, columns=columns, numrows=2)
    >>> len(table)  # 2 data rows + header + borders
    5

    Notes
    -----
    - Column widths are automatically calculated based on content
    - All rows must have the same number of columns
    - Empty data returns None
    - The table includes top, middle, and bottom borders

    See Also
    --------
    print_ascii_table : Print ASCII table directly to console
    print_ascii_table_from_dataframe : Create ASCII table from DataFrame
    """
    logger.debug(f"Creating ASCII table with {len(data)} rows, {len(columns)} columns")
    logger.debug(f"Alignment: {alignment}, numrows: {numrows}")

    if len(data) == 0:
        logger.warning("Empty data provided to ascii_table")
        return None

    data = [list(e) for e in data]
    columns = list([c for c in columns])
    alignment = alignment or "left"

    def pad(x, size, char=" ", where="center"):
        char = char or " "
        where = where or "center"
        return (
            str(x).rjust(size, char)
            if where == "right"
            else (
                str(x).ljust(size, char)
                if where == "left"
                else str(x).center(size, char)
            )
        )

    def line(rows, sizes, where="center"):
        return (
            "|"
            + "|".join(
                [pad(rows[i], sizes[i], where=where) for i in range(0, len(rows))]
            )
            + "|"
        )

    col_lenghts = tuple(set([len(d) for d in data]))

    if len(col_lenghts) == 0:
        return None

    if len(col_lenghts) > 1:
        raise ValueError("Number of columns mismatch among rows.")

    if alignment not in ("left", "right", "center"):
        raise ValueError("Alignment valid values: left|right|center")

    if columns is None or len(columns) == 0:
        columns = [f"column_{i}" for i in range(0, col_lenghts[0])]

    if len(columns) != col_lenghts[0]:
        logger.error(
            f"Column length mismatch: data has {col_lenghts[0]} columns, but {len(columns)} provided"
        )
        logger.debug(f"Column lengths: {col_lenghts}, columns: {columns}")
        raise ValueError(f"Number of columns mismatch with data row.")

    if numrows is None or numrows > len(data):
        numrows = len(data)
    xdata = [
        [row[i] for i in range(len(data[0])) if columns[i] in columns] for row in data
    ][0:numrows]

    max_sizes = list(
        max(n)
        for n in list(
            list(len(str(r[i])) for r in xdata) for i in range(0, len(xdata[0]))
        )
    )

    col_sizes = [len(str(c)) for c in columns]
    new_max_sizes = []
    for i, _ in enumerate(max_sizes):
        new_max_sizes.append(max(max_sizes[i], col_sizes[i]))
    max_sizes = new_max_sizes

    line_sep = "".join(["+" + "-" * i for i in max_sizes]) + "+"

    table = []
    table.append(line_sep)
    table.append(line(columns, max_sizes))
    table.append(line_sep)
    for row in data:
        table.append(line(row, max_sizes, where=alignment))
    table.append(line_sep)

    logger.debug(f"Successfully created ASCII table with {len(table)} lines")
    return table


def print_ascii_table(
    data: List[List[Any]],
    columns: List[str] = [],
    alignment: str = "left",
    numrows: int = None,
) -> None:
    """Print the ASCII table representation of the given data.

    This function creates and prints an ASCII table to the console.
    It is a convenience wrapper around `ascii_table` that directly
    outputs the formatted table.

    Parameters
    ----------
    data : list of list
        A list of lists representing the data rows. Each inner list
        represents a single row of data.
    columns : list of str, optional
        A list of column names. If empty or None, default column names
        are generated. Default is empty list.
    alignment : {'left', 'right', 'center'}, optional
        The alignment of the table cells. Valid values are 'left', 'right',
        or 'center'. Default is 'left'.
    numrows : int, optional
        The number of rows to display. If None or greater than the number
        of data rows, all rows are displayed. Default is None.

    Returns
    -------
    None
        The table is printed directly to the console.

    Examples
    --------
    Print a simple ASCII table:

    >>> from fbpyutils_db.visualization.ascii_table import print_ascii_table
    >>> data = [['John', 25, 'USA'], ['Alice', 30, 'Canada'], ['Bob', 40, 'UK']]
    >>> columns = ['Name', 'Age', 'Country']
    >>> print_ascii_table(data, columns=columns, alignment='center')
    +-------+-----+---------+
    |  Name | Age | Country |
    +-------+-----+---------+
    |  John |  25 |   USA   |
    | Alice |  30 |  Canada |
    |  Bob  |  40 |    UK   |
    +-------+-----+---------+

    Notes
    -----
    - This function prints directly to stdout
    - Returns None if data is None
    - Uses `ascii_table` internally for table generation
    - All parameters are passed through to `ascii_table`

    See Also
    --------
    ascii_table : Create ASCII table as list of strings
    print_ascii_table_from_dataframe : Print ASCII table from DataFrame
    """
    if data is None:
        return None

    logger.info(f"Printing ASCII table with {len(data) if data else 0} rows")
    table = ascii_table(data, columns=columns, alignment=alignment, numrows=numrows)

    for line in table:
        print(line)
    logger.debug(f"Successfully printed ASCII table with {len(table)} lines")
