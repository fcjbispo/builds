"""MyLibraryScanner - A Python library for file scanning and analysis using FBNet standard configuration.

This package provides functionality to:
- Scan directories and gather file information using FBNet configuration system
- Store and manage file metadata in PostgreSQL database with JSONB support
- Analyze files with AI on-demand
- Provide a CLI interface

Modules:
    core: Core scanning and file processing functionality
    database: Database operations and models with PostgreSQL JSONB support
    cli: Command-line interface
    initialization: FBNet standard configuration and logging setup

Key Features:
- FBNet standard configuration system (app.json + environment variables)
- PostgreSQL JSONB storage for flexible file metadata
- Master/detail relational schema for scan management
- AI-ready architecture with extensible metadata
- Full compatibility with existing duplicate detection views
- Comprehensive repository pattern for database operations
"""

__version__ = "1.0.0"
__author__ = "Francisco C J Bispo"
__email__ = "fcjbispo@franciscobispo.net"

# Import initialization module first (sets up configuration and logging)
# Re-export main components for easy access
from . import cli, core, database, initialization
from .database import Base, DatabaseManager, Source, SourceFile
from .initialization import (
    get_app_config,
    get_env_instance,
    get_logger_instance,
    setup_system,
)

__all__ = [  # noqa: RUF022
    # Initialization (must be called first)
    "get_app_config",
    "get_env_instance",
    "get_logger_instance",
    "setup_system",
    # Database models and managers
    "Base",
    "DatabaseManager",
    "Source",
    "SourceFile",
    # Package modules
    "cli",
    "core",
    "database",
    "initialization",
]
