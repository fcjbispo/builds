"""Sync source: standalone ``library sync_source`` (A7 — same semantics as
``scan --mode sync``), now on the PostgREST adapter with the A10 envelope.

The host is read-only; the SOURCE mirrors its registered path (the DDL no
longer stores ``source_mask`` — the sync mirrors everything under the path).
Per-file failures never abort (A5); details stay in ``source_files``.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from mylibraryscanner.api.envelope import (
    aborted,
    build_envelope,
    prune_stats,
    resolve_status,
)
from mylibraryscanner.core.sync import collect_file_records, reconcile_source
from mylibraryscanner.database.postgrest_client import (
    PostgRESTClient,
    PostgRESTError,
    PostgRESTUnavailableError,
)
from mylibraryscanner.database.postgrest_repository import (
    PostgRESTFileRepository,
    PostgRESTSourceRepository,
)
from mylibraryscanner.initialization import get_logger_instance


def _print_json(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, indent=2, ensure_ascii=False))


def _aborted_result(operation: str, message: str, *, source_name: str) -> dict[str, Any]:
    return {"exit_code": 1, "envelope": aborted(operation, message, source_name=source_name)}


def run_sync_source(
    source_name: str,
    infer: bool = False,
    ingest: bool = False,
    dry_run: bool = False,
    progress_callback: Callable[[int, int], None] | None = None,
    inference_service: Any | None = None,
) -> dict[str, Any]:
    """Incrementally sync an existing SOURCE (A7) and return result dict."""
    operation = "library_sync_source"
    log = get_logger_instance()

    try:
        client = PostgRESTClient()
        source_repo = PostgRESTSourceRepository(client)
        file_repo = PostgRESTFileRepository(client)
    except PostgRESTUnavailableError as exc:
        return _aborted_result(operation, str(exc), source_name=source_name)

    try:
        source = source_repo.get_by_name(source_name)
        if source is None:
            return _aborted_result(
                operation, f"SOURCE not found: {source_name}", source_name=source_name
            )

        target = Path(source.source_path)
        fresh = collect_file_records(
            target, "*", progress_callback=progress_callback
        )

        topic_resolver = None
        if inference_service is None and infer:
            from mylibraryscanner.core.inference import ContentInferenceService

            inference_service = ContentInferenceService()
        if inference_service is not None and getattr(inference_service, "client", None) is not None:
            from mylibraryscanner.core.topics import make_topic_resolver

            topic_resolver = make_topic_resolver(inference_service.client)

        outcome = reconcile_source(
            client,
            source,
            fresh,
            mode="sync",
            inference_service=inference_service,
            topic_resolver=topic_resolver,
            dry_run=dry_run,
        )

        stats = outcome.stats()

        if not dry_run:
            files_total = file_repo.count_by_source(source.id)
            source_repo.update(
                source.id,
                status="OK",
                files_total=files_total,
                end_extraction=datetime.now(),
            )

        if ingest and not dry_run:
            from mylibraryscanner.core.ingest import (
                make_embedding_service,
                resolve_ingest_defaults,
                run_ingest,
            )

            chunk_size, chunk_overlap, embedding_model = resolve_ingest_defaults()
            try:
                embedder = make_embedding_service()
            except Exception as exc:  # noqa: BLE001 — PS-7 friendly abort
                return _aborted_result(
                    operation,
                    f"Embedding provider unavailable ({exc}) — verify the "
                    "Ollama service and embedding configuration.",
                    source_name=source_name,
                )
            ingest_stats = run_ingest(
                client,
                source,
                file_repo,
                embedder,
                paths=outcome.affected_paths,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                embedding_model=embedding_model,
            )
            stats.update(ingest_stats)
    except PostgRESTUnavailableError as exc:
        return _aborted_result(operation, str(exc), source_name=source_name)
    except PostgRESTError as exc:
        return _aborted_result(
            operation, f"Persistence rejected the operation: {exc}",
            source_name=source_name,
        )

    processed = outcome.added + outcome.modified + outcome.unchanged + outcome.removed
    status = resolve_status(
        processed, skipped=stats.get("skipped", 0), failed=stats.get("failed", 0)
    )
    if dry_run:
        stats["dry_run"] = 1
    envelope = build_envelope(
        operation,
        source_name=source_name,
        target=source.source_path,
        options={
            "mode": "sync",
            "infer": bool(infer),
            "ingest": bool(ingest),
            "dry_run": bool(dry_run),
        },
        stats=prune_stats(stats),
        status=("OK" if dry_run else status),
    )
    log.info(
        "sync_source %s: added=%d modified=%d unchanged=%d removed=%d",
        source_name,
        outcome.added,
        outcome.modified,
        outcome.unchanged,
        outcome.removed,
    )
    exit_code = (0 if dry_run else (0 if status in ("OK", "PARTIAL") else 1))
    return {"exit_code": exit_code, "envelope": envelope}


def run_library_sync_source(
    source_name: str,
    infer: bool = False,
    ingest: bool = False,
    prune: bool = False,
    force_infer: bool = False,
    dry_run: bool = False,
    progress_callback: Callable[[int, int], None] | None = None,
) -> dict[str, Any]:
    """Run a sync and return a result dict.

    ``prune`` and ``force_infer`` are accepted and ignored: since the DDL v1
    the SOURCE is a host mirror (prune is inherent) and inference follows A4.
    """
    del prune, force_infer  # legacy flags, no longer part of A7
    try:
        inference_service = None
        if infer:
            from mylibraryscanner.core.inference import ContentInferenceService

            inference_service = ContentInferenceService()
        return run_sync_source(
            source_name=source_name,
            infer=infer,
            ingest=ingest,
            dry_run=dry_run,
            progress_callback=progress_callback,
            inference_service=inference_service,
        )
    except Exception as exc:  # noqa: BLE001
        return _aborted_result(
            "library_sync_source", f"library sync_source failed: {exc}",
            source_name=source_name,
        )


def cmd_library_sync_source(
    source_name: str,
    infer: bool = False,
    ingest: bool = False,
    prune: bool = False,
    force_infer: bool = False,
    dry_run: bool = False,
    assume_yes: bool = False,
    progress_callback: Callable[[int, int], None] | None = None,
) -> int:
    """CLI entry point for ``library sync_source``."""
    del assume_yes  # no interactive confirmation in A7 sync
    result = run_library_sync_source(
        source_name=source_name,
        infer=infer,
        ingest=ingest,
        dry_run=dry_run,
        progress_callback=progress_callback,
    )
    _print_json(result["envelope"])
    return result["exit_code"]


__all__ = ["cmd_library_sync_source", "run_library_sync_source", "run_sync_source"]