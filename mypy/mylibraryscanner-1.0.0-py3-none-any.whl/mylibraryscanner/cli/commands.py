"""CLI commands for MyLibraryScanner (v1 — envelope A10, PostgREST adapter).

Every command returns an A10 envelope (``mylibraryscanner/api/envelope.py``)
and the CLI prints it once to stdout (CL-4 JSON-first). Persistência happens
exclusively through the PostgREST adapter (ADR-0005).
"""

from __future__ import annotations

import fnmatch
import os
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from mylibraryscanner.api.envelope import (
    aborted,
    build_envelope,
    prune_stats,
    resolve_status,
)
from mylibraryscanner.cli.sync_source import cmd_library_sync_source  # re-export
from mylibraryscanner.core.sync import collect_file_records, reconcile_source
from mylibraryscanner.core.token_manager import (
    token_create,
    token_list,
    token_revoke,
    token_rotate,
)
from mylibraryscanner.database.postgrest_client import (
    PostgRESTClient,
    PostgRESTError,
    PostgRESTUnavailableError,
)
from mylibraryscanner.database.postgrest_repository import (
    PostgRESTFileRepository,
    PostgRESTSourceRepository,
)
from mylibraryscanner.initialization import get_logger_instance


def _print_json(payload: dict[str, Any]) -> None:
    import json

    print(json.dumps(payload, indent=2, ensure_ascii=False))


def _get_env_int(*names: str, default: int) -> int:
    """Return first valid integer from environment names."""
    for name in names:
        raw = os.getenv(name)
        if raw and str(raw).strip():
            try:
                return int(raw)
            except ValueError:
                pass
    return default


def _resolve_scan_tuning(
    source_kind: str,
    parallel: bool,
    max_workers: int | None,
) -> dict[str, Any]:
    """Resolve effective scan worker settings with removable-media tuning."""
    normalized_kind = str(source_kind or "LOCAL").strip().upper() or "LOCAL"
    default_parallel_workers = max(
        1,
        _get_env_int(
            "FBNET_MYLIBRARYSCANNER_SCAN_DEFAULT_MAX_WORKERS",
            "MYLIBRARYSCANNER_SCAN_DEFAULT_MAX_WORKERS",
            default=4,
        ),
    )
    removable_parallel_workers = max(
        1,
        _get_env_int(
            "FBNET_MYLIBRARYSCANNER_SCAN_REMOVABLE_MAX_WORKERS",
            "MYLIBRARYSCANNER_SCAN_REMOVABLE_MAX_WORKERS",
            default=2,
        ),
    )

    requested_workers = max_workers if max_workers is not None else default_parallel_workers
    auto_selected = max_workers is None
    effective_workers = requested_workers
    tuning_reason = "none"

    if normalized_kind == "REMOVABLE":
        if auto_selected:
            effective_workers = removable_parallel_workers
            tuning_reason = "auto_removable_profile"
        elif effective_workers > removable_parallel_workers:
            effective_workers = removable_parallel_workers
            tuning_reason = "removable_worker_cap"

    return {
        "source_kind": normalized_kind,
        "parallel": bool(parallel),
        "requested_max_workers": requested_workers,
        "effective_max_workers": effective_workers,
        "auto_selected": auto_selected,
        "tuning_applied": tuning_reason != "none",
        "tuning_reason": tuning_reason,
    }


def _normalize_path(value: str) -> str:
    return str(Path(value).expanduser().resolve())


def _aborted_result(
    operation: str,
    message: str,
    *,
    source_name: str | None = None,
    target: str | None = None,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {"exit_code": 1, "envelope": aborted(operation, message,
               source_name=source_name, target=target, options=options)}


def run_scan(
    file_or_folder: str,
    source_name: str,
    mode: str = "sync",
    source_mask: str = "*",
    source_kind: str = "LOCAL",
    parallel: bool = False,
    max_workers: int | None = None,
    infer: bool = False,
    ingest: bool = False,
    scan_progress_callback: Callable[[int, int], None] | None = None,
) -> dict[str, Any]:
    """Run the redesigned scan (A1/A3/A6/PS-4) and return ``{exit_code,
    envelope}`` with the A10 envelope (no printing)."""
    operation = "scan"
    log = get_logger_instance()
    target = Path(file_or_folder).expanduser().resolve()
    if not target.exists():
        return _aborted_result(
            operation,
            f"Path does not exist: {target}",
            source_name=source_name,
            target=str(target),
        )

    if ingest and not infer:
        # ingest depends on inference (A8) — same run or prior inference.
        pass  # valid only when files already carry inference in the db

    tuning = _resolve_scan_tuning(source_kind, parallel, max_workers)
    resolved_kind = str(tuning["source_kind"])
    options = {
        "mode": mode,
        "infer": bool(infer),
        "ingest": bool(ingest),
        "pattern": source_mask,
        "source_kind": resolved_kind,
        "parallel": bool(parallel),
        "max_workers": int(tuning["effective_max_workers"]),
    }

    try:
        client = PostgRESTClient()
        source_repo = PostgRESTSourceRepository(client)
    except PostgRESTUnavailableError as exc:
        return _aborted_result(
            operation, str(exc), source_name=source_name, target=str(target),
            options=options,
        )

    try:
        source = source_repo.get_by_name(source_name)
        if source is not None and _normalize_path(source.source_path) != _normalize_path(
            str(target)
        ):
            # A3: divergent path → ABORTED, ask for correction.
            return _aborted_result(
                operation,
                (
                    f"Path diverges from the one registered on SOURCE "
                    f"'{source_name}' (registered: {source.source_path}). "
                    f"Use the registered path or choose another --source_name."
                ),
                source_name=source_name,
                target=str(target),
                options=options,
            )

        fresh = collect_file_records(
            target,
            source_mask,
            parallel=bool(parallel),
            max_workers=int(tuning["effective_max_workers"]),
            source_kind=resolved_kind,
            progress_callback=scan_progress_callback,
        )

        if source is None:
            source = source_repo.create(
                source_name,
                str(target),
                source_kind=resolved_kind,
            )

        inference_service = None
        topic_resolver = None
        if infer:
            from mylibraryscanner.core.inference import ContentInferenceService
            from mylibraryscanner.core.topics import make_topic_resolver

            inference_service = ContentInferenceService()
            if getattr(inference_service, "client", None) is not None:
                topic_resolver = make_topic_resolver(inference_service.client)

        outcome = reconcile_source(
            client,
            source,
            fresh,
            mode=mode,
            inference_service=inference_service,
            topic_resolver=topic_resolver,
        )

        stats = outcome.stats()
        if ingest:
            from mylibraryscanner.core.ingest import (
                resolve_ingest_defaults,
                run_ingest,
            )

            chunk_size, chunk_overlap, embedding_model = resolve_ingest_defaults()
            embedder = None
            try:
                from mylibraryscanner.core.ingest import make_embedding_service

                embedder = make_embedding_service()
            except Exception as exc:  # noqa: BLE001 — PS-7 friendly abort
                return _aborted_result(
                    operation,
                    f"Embedding provider unavailable ({exc}) — verify the "
                    "Ollama service and embedding configuration.",
                    source_name=source_name,
                    target=str(target),
                    options=options,
                )
            from mylibraryscanner.database.postgrest_repository import (
                PostgRESTFileRepository as _FileRepo,
            )

            ingest_stats = run_ingest(
                client,
                source,
                _FileRepo(client),
                embedder,
                paths=outcome.affected_paths,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                embedding_model=embedding_model,
            )
            stats.update(ingest_stats)

        files_total = PostgRESTFileRepository(client).count_by_source(source.id)
        source_repo.update(
            source.id,
            status="OK",
            files_total=files_total,
            end_extraction=datetime.now(),
        )
    except PostgRESTUnavailableError as exc:
        return _aborted_result(
            operation, str(exc), source_name=source_name, target=str(target),
            options=options,
        )
    except PostgRESTError as exc:
        return _aborted_result(
            operation,
            f"Persistence rejected the operation: {exc}",
            source_name=source_name,
            target=str(target),
            options=options,
        )
    except Exception as exc:  # noqa: BLE001 — nunca traceback p/ o usuário (PS-7/AUTH-7)
        log.error("scan %s failed unexpectedly: %s", target, exc)
        return _aborted_result(
            operation,
            f"Unexpected failure ({exc.__class__.__name__}): {exc}",
            source_name=source_name,
            target=str(target),
            options=options,
        )

    processed = outcome.added + outcome.modified + outcome.unchanged + outcome.removed
    status = resolve_status(
        processed, skipped=stats.get("skipped", 0), failed=stats.get("failed", 0)
    )
    envelope = build_envelope(
        operation,
        source_name=source_name,
        target=str(target),
        options=options,
        stats=prune_stats(stats),
        status=status,
    )
    log.info("scan %s: %s processed=%d", target, status, processed)
    return {"exit_code": 0 if status in ("OK", "PARTIAL") else 1, "envelope": envelope}


def cmd_scan_target(
    file_or_folder: str,
    source_name: str,
    mode: str = "sync",
    source_mask: str = "*",
    source_kind: str = "LOCAL",
    parallel: bool = False,
    max_workers: int | None = None,
    infer: bool = False,
    ingest: bool = False,
) -> int:
    """Scan file or folder into the SOURCE and print the A10 envelope."""
    result = run_scan(
        file_or_folder,
        source_name,
        mode=mode,
        source_mask=source_mask,
        source_kind=source_kind,
        parallel=parallel,
        max_workers=max_workers,
        infer=infer,
        ingest=ingest,
    )
    _print_json(result["envelope"])
    return result["exit_code"]


def cmd_library_list_sources(pattern: str = "*") -> int:
    """List sources (envelope A10; findings in ``results``)."""
    operation = "library_list_sources"
    try:
        client = PostgRESTClient()
        repo = PostgRESTSourceRepository(client)
        sources = repo.get_all()
        filtered = [s for s in sources if fnmatch.fnmatch(s.source_name, pattern)]
        results = [
            {
                "source_name": s.source_name,
                "source_kind": s.source_kind,
                "status": s.status,
                "files_total": s.files_total,
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "updated_at": s.updated_at.isoformat() if s.updated_at else None,
            }
            for s in filtered
        ]
        envelope = build_envelope(
            operation,
            options={"pattern": pattern},
            status="OK",
            results=results,
        )
        envelope["stats"] = {"sources": len(results)}
        _print_json(envelope)
        return 0
    except PostgRESTUnavailableError as exc:
        _print_json(aborted(operation, str(exc), options={"pattern": pattern}))
        return 1


def cmd_library_remove_source(source_name: str, assume_yes: bool = False) -> int:
    """Remove a SOURCE and all related files (cascade; confirmation by default)."""
    operation = "library_remove_source"
    try:
        client = PostgRESTClient()
        repo = PostgRESTSourceRepository(client)
        file_repo = PostgRESTFileRepository(client)
        source = repo.get_by_name(source_name)
        if source is None:
            # AUTH-7/A3 friendly ABORT; no stack trace.
            _print_json(
                aborted(operation, f"SOURCE not found: {source_name}",
                        source_name=source_name)
            )
            return 1

        if not assume_yes:
            answer = input(
                f"Confirm deletion of source '{source_name}' and all related "
                f"files? [y/N]: "
            ).strip()
            if answer.lower() not in {"y", "yes"}:
                _print_json(
                    aborted(operation, "Canceled by the user",
                            source_name=source_name)
                )
                return 1

        files_removed = file_repo.count_by_source(source.id)
        repo.delete(source.id)  # FK cascade cleans files and kb_chunks
        envelope = build_envelope(
            operation,
            source_name=source_name,
            target=source.source_path,
            stats=prune_stats({"removed": files_removed}),
            status="OK",
        )
        _print_json(envelope)
        return 0
    except PostgRESTUnavailableError as exc:
        _print_json(aborted(operation, str(exc), source_name=source_name))
        return 1
    except PostgRESTError as exc:
        _print_json(
            aborted(operation, f"Persistence rejected the operation: {exc}",
                    source_name=source_name)
        )
        return 1
    except KeyboardInterrupt:
        _print_json(aborted(operation, "Canceled by the user",
                            source_name=source_name))
        return 1


def cmd_library_infer_source(source_name: str) -> int:
    """Infer content for files of a SOURCE (envelope A10)."""
    result = run_library_infer_source(source_name)
    _print_json(result["envelope"])
    return result["exit_code"]


def run_library_infer_source(
    source_name: str,
    progress_callback: Callable[[int, int], None] | None = None,
) -> dict[str, Any]:
    """Infer summaries for every file of a SOURCE (explicit overwrite)."""
    operation = "library_infer_source"
    log = get_logger_instance()
    try:
        client = PostgRESTClient()
        source_repo = PostgRESTSourceRepository(client)
        file_repo = PostgRESTFileRepository(client)
        source = source_repo.get_by_name(source_name)
        if source is None:
            return _aborted_result(operation, f"SOURCE not found: {source_name}",
                                   source_name=source_name)

        from mylibraryscanner.core.inference import (
            MAX_INFERENCE_CHARS,
            ContentInferenceService,
        )

        service = ContentInferenceService(max_inference_chars=MAX_INFERENCE_CHARS)
        topic_resolver = None
        if getattr(service, "client", None) is not None:
            from mylibraryscanner.core.topics import make_topic_resolver

            topic_resolver = make_topic_resolver(service.client)
        files = file_repo.get_by_source(source.id)
        inferred = skipped = failed = 0

        for index, row in enumerate(files, start=1):
            if row.status not in ("OK", "PENDING"):
                failed += 1
            else:
                inference = service.infer_file(row.file_path, details=row.details)
                if inference:
                    topics = (
                        topic_resolver(inference, list(row.topics))
                        if topic_resolver
                        else None
                    )
                    values: dict[str, Any] = {
                        "inference": inference[:MAX_INFERENCE_CHARS]
                    }
                    if topics is not None:
                        values["topics"] = topics
                    client.update("source_files", values, params={"id": str(row.id)})
                    inferred += 1
                else:
                    skipped += 1
            if progress_callback:
                progress_callback(index, len(files))

        processed = inferred + skipped + failed
        status = resolve_status(processed, skipped=skipped, failed=failed)
        envelope = build_envelope(
            operation,
            source_name=source_name,
            target=source.source_path,
            options={"overwrite_existing": True},
            stats=prune_stats(
                {"files_read": len(files), "inferred": inferred,
                 "skipped": skipped, "failed": failed}
            ),
            status=status,
        )
        log.info("infer_source %s: inferred=%d/%d", source_name, inferred, len(files))
        return {"exit_code": 0 if status in ("OK", "PARTIAL") else 1,
                "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _aborted_result(operation, str(exc), source_name=source_name)
    except PostgRESTError as exc:
        return _aborted_result(
            operation, f"Persistence rejected the operation: {exc}",
            source_name=source_name,
        )


def cmd_library_ingest_source(
    source_name: str,
    pattern: str = "*",
) -> int:
    """Ingest (KB) the inferable files of a SOURCE (envelope A10)."""
    result = run_library_ingest_source(source_name, pattern=pattern)
    _print_json(result["envelope"])
    return result["exit_code"]


def run_library_ingest_source(
    source_name: str,
    pattern: str = "*",
) -> dict[str, Any]:
    """Reingest the whole SOURCE (default ``--pattern`` * — explicit overwrite)."""
    operation = "library_ingest_source"
    try:
        client = PostgRESTClient()
        source_repo = PostgRESTSourceRepository(client)
        file_repo = PostgRESTFileRepository(client)
        source = source_repo.get_by_name(source_name)
        if source is None:
            return _aborted_result(
                operation, f"SOURCE not found: {source_name}", source_name=source_name
            )

        from mylibraryscanner.core.ingest import (
            make_embedding_service,
            resolve_ingest_defaults,
            run_ingest,
        )

        chunk_size, chunk_overlap, embedding_model = resolve_ingest_defaults()
        try:
            embedder = make_embedding_service()
        except Exception as exc:  # noqa: BLE001 — PS-7 friendly abort
            return _aborted_result(
                operation,
                f"Embedding provider unavailable ({exc}) — verify the Ollama "
                "service and embedding configuration.",
                source_name=source_name,
            )

        counters = run_ingest(
            client,
            source,
            file_repo,
            embedder,
            pattern=pattern,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            embedding_model=embedding_model,
        )
        processed = counters["ingested"] + counters["skipped"] + counters["failed"]
        status = resolve_status(
            processed,
            skipped=counters["skipped"],
            failed=counters["failed"],
        )
        envelope = build_envelope(
            operation,
            source_name=source_name,
            target=source.source_path,
            options={
                "pattern": pattern,
                "chunk_size": chunk_size,
                "chunk_overlap": chunk_overlap,
                "embedding_model": embedding_model,
            },
            stats=prune_stats(counters),
            status=status,
        )
        return {"exit_code": 0 if status in ("OK", "PARTIAL") else 1,
                "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _aborted_result(operation, str(exc), source_name=source_name)
    except PostgRESTError as exc:
        return _aborted_result(
            operation, f"Persistence rejected the operation: {exc}",
            source_name=source_name,
        )


def cmd_library_search(
    query: str,
    mode: str = "hybrid",
    source_name: str | None = None,
    file_pattern: str = "*",
    mime: str | None = None,
    limit: int = 10,
    offset: int = 0,
    min_similarity: float = 0.0,
    export: str | None = None,
) -> int:
    """KB search (A8) — 4 modes; envelope + optional export (D7)."""
    result = run_library_search(
        query,
        mode=mode,
        source_name=source_name,
        file_pattern=file_pattern,
        mime=mime,
        limit=limit,
        offset=offset,
        min_similarity=min_similarity,
        export=export,
    )
    _print_json(result["envelope"])
    return result["exit_code"]


def run_library_search(
    query: str,
    mode: str = "hybrid",
    source_name: str | None = None,
    file_pattern: str = "*",
    mime: str | None = None,
    limit: int = 10,
    offset: int = 0,
    min_similarity: float = 0.0,
    export: str | None = None,
) -> dict[str, Any]:
    """Run a search and return ``{exit_code, envelope}`` (export applied)."""
    log = get_logger_instance()
    try:
        client = PostgRESTClient()
        from mylibraryscanner.core.ingest import make_embedding_service

        try:
            embedder = make_embedding_service()
        except Exception:  # noqa: BLE001 — PS-7 friendly abort
            embedder = None
        from mylibraryscanner.core.search import export_envelope, run_search

        result = run_search(
            client,
            query=query,
            mode=mode,
            source_name=source_name,
            file_pattern=file_pattern,
            mime=mime,
            limit=limit,
            offset=offset,
            min_similarity=min_similarity,
            embedding_fn=embedder,
        )
        envelope = result["envelope"]
        if export:
            try:
                export_envelope(dict(envelope), export)
            except ValueError as exc:
                envelope = dict(envelope)
                envelope["message"] = str(exc)
                envelope["status"] = "ABORTED"
                return {"exit_code": 1, "envelope": envelope}
            log.info("search export written: %s", export)
        return result
    except PostgRESTUnavailableError as exc:
        return _aborted_result("search", str(exc), source_name=source_name)
    except PostgRESTError as exc:
        return _aborted_result(
            "search", f"Persistence rejected the operation: {exc}",
            source_name=source_name,
        )


# ----------------------------------------------------------------------
# token group (AUTH-1..7 — F5)
# ----------------------------------------------------------------------

def _token_aborted(operation: str, message: str, *, token_name: str | None = None):
    return {
        "exit_code": 1,
        "envelope": aborted(operation, message, source_name=token_name),
    }


def cmd_token_create(token_name: str, expires: str | None = None) -> int:
    result = run_token_create(token_name, expires=expires)
    _print_json(result["envelope"])
    return result["exit_code"]


def run_token_create(token_name: str, expires: str | None = None) -> dict[str, Any]:
    """Create an api key — plaintext shown ONCE at the envelope root."""
    operation = "token_create"
    try:
        expires_at = _parse_expires(expires)
        client = PostgRESTClient()
        plaintext, _row = token_create(client, token_name, expires_at=expires_at)
        envelope = build_envelope(
            operation,
            source_name=token_name,
            options={"expires": expires or None},
            status="OK",
        )
        envelope["token"] = plaintext  # AUTH-1c: única exibição em claro
        return {"exit_code": 0, "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _token_aborted(operation, str(exc), token_name=token_name)
    except PostgRESTError as exc:
        return _token_aborted(operation, f"Persistence rejected: {exc}",
                              token_name=token_name)


def cmd_token_list() -> int:
    result = run_token_list()
    _print_json(result["envelope"])
    return result["exit_code"]


def run_token_list() -> dict[str, Any]:
    """List tokens — id/name/active/dates; NEVER the token nor the hash."""
    operation = "token_list"
    try:
        client = PostgRESTClient()
        records = token_list(client)
        results = [
            {
                "id": r.id,
                "token_name": r.token_name,
                "active": r.active,
                "created_at": r.created_at.isoformat() if r.created_at else None,
                "last_used_at": r.last_used_at.isoformat() if r.last_used_at else None,
                "expires_at": r.expires_at.isoformat() if r.expires_at else None,
            }
            for r in records
        ]
        envelope = build_envelope(
            operation,
            status="OK",
            stats={"tokens": len(results)},
            results=results,
        )
        return {"exit_code": 0, "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _token_aborted(operation, str(exc))


def cmd_token_revoke(token_name: str) -> int:
    result = run_token_revoke(token_name)
    _print_json(result["envelope"])
    return result["exit_code"]


def run_token_revoke(token_name: str) -> dict[str, Any]:
    """Soft revoke (active=false) — audit preserved."""
    operation = "token_revoke"
    try:
        client = PostgRESTClient()
        revoked = token_revoke(client, token_name)
        if not revoked:
            return _token_aborted(operation, f"TOKEN not found or already revoked: {token_name}",
                                  token_name=token_name)
        envelope = build_envelope(
            operation,
            source_name=token_name,
            status="OK",
            stats={"revoked": revoked},
        )
        return {"exit_code": 0, "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _token_aborted(operation, str(exc), token_name=token_name)
    except PostgRESTError as exc:
        return _token_aborted(operation, f"Persistence rejected: {exc}",
                              token_name=token_name)


def cmd_token_rotate(token_name: str) -> int:
    result = run_token_rotate(token_name)
    _print_json(result["envelope"])
    return result["exit_code"]


def run_token_rotate(token_name: str) -> dict[str, Any]:
    """Rotation: revoke + new secret, SAME name (new plaintext shown once)."""
    operation = "token_rotate"
    try:
        client = PostgRESTClient()
        plaintext, _row = token_rotate(client, token_name)
        if plaintext is None:
            return _token_aborted(operation, f"TOKEN not found: {token_name}",
                                  token_name=token_name)
        envelope = build_envelope(operation, source_name=token_name, status="OK",
                                  stats={"rotated": 1})
        envelope["token"] = plaintext  # única exibição do novo segredo
        return {"exit_code": 0, "envelope": envelope}
    except PostgRESTUnavailableError as exc:
        return _token_aborted(operation, str(exc), token_name=token_name)
    except PostgRESTError as exc:
        return _token_aborted(operation, f"Persistence rejected: {exc}",
                              token_name=token_name)


def _parse_expires(expires: str | None) -> datetime | None:
    """ISO datetime string → datetime (None when absent)."""
    if not expires:
        return None
    return datetime.fromisoformat(expires)


__all__ = [
    "cmd_library_infer_source",
    "cmd_library_ingest_source",
    "cmd_library_list_sources",
    "cmd_library_remove_source",
    "cmd_library_search",
    "cmd_library_sync_source",
    "cmd_scan_target",
    "cmd_token_create",
    "cmd_token_list",
    "cmd_token_revoke",
    "cmd_token_rotate",
    "run_library_infer_source",
    "run_library_ingest_source",
    "run_library_search",
    "run_scan",
    "run_token_create",
    "run_token_list",
    "run_token_revoke",
    "run_token_rotate",
]