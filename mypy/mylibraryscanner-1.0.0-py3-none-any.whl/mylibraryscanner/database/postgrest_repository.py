"""PostgREST-backed repositories for MyLibraryScanner (ADR-0005 adapter).

Implements the repository surface used by the library on top of
:class:`PostgRESTClient`, mirroring the ``mylibrary`` schema (DDL v1.0.1):
``sources`` and ``source_files``. Records are lightweight dataclasses — no
SQLAlchemy models cross this boundary.

Dependency check (PS-7): constructing a repository performs a PostgREST health
check once per operation and raises :class:`PostgRESTUnavailableError`
(ABORTED-friendly) when the service is down.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from mylibraryscanner.database.postgrest_client import (
    PostgRESTClient,
)


@dataclass
class SourceRecord:
    """Row shape of ``mylibrary.sources`` (DDL v1.0.1)."""

    id: str
    source_name: str
    source_kind: str
    source_path: str
    start_extraction: datetime | None = None
    end_extraction: datetime | None = None
    status: str = "PENDING"
    files_total: int = 0
    created_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass
class SourceFileRecord:
    """Row shape of ``mylibrary.source_files`` (DDL v1.0.1)."""

    id: str
    source_id: str
    file_path: str
    status: str = "PENDING"
    status_message: str | None = None
    inference: str | None = None
    topics: list[str] = field(default_factory=list)
    md5sum: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    processed_at: datetime | None = None


def _parse_datetime(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def _source_record(row: dict[str, Any]) -> SourceRecord:
    return SourceRecord(
        id=row["id"],
        source_name=row.get("source_name", ""),
        source_kind=row.get("source_kind", "LOCAL"),
        source_path=row.get("source_path", ""),
        start_extraction=_parse_datetime(row.get("start_extraction")),
        end_extraction=_parse_datetime(row.get("end_extraction")),
        status=row.get("status", "PENDING"),
        files_total=int(row.get("files_total") or 0),
        created_at=_parse_datetime(row.get("created_at")),
        updated_at=_parse_datetime(row.get("updated_at")),
    )


def _file_record(row: dict[str, Any]) -> SourceFileRecord:
    return SourceFileRecord(
        id=row["id"],
        source_id=row.get("source_id", ""),
        file_path=row.get("file_path", ""),
        status=row.get("status", "PENDING"),
        status_message=row.get("status_message"),
        inference=row.get("inference"),
        topics=list(row.get("topics") or []),
        md5sum=row.get("md5sum"),
        details=row.get("details") or {},
        processed_at=_parse_datetime(row.get("processed_at")),
    )


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


class PostgRESTSourceRepository:
    """Source CRUD over the PostgREST table API (schema ``mylibrary``)."""

    def __init__(self, client: PostgRESTClient) -> None:
        self.client = client
        self.client.ensure_available()

    def _as_uuid(self, value: uuid.UUID | str) -> str:
        return str(value)

    def create(
        self,
        source_name: str,
        source_path: str,
        source_kind: str = "LOCAL",
        *,
        start_extraction: datetime | None = None,
        end_extraction: datetime | None = None,
        status: str = "PENDING",
        files_total: int = 0,
    ) -> SourceRecord:
        """Insert a source (implicit creation per A1)."""
        created = self.client.insert(
            "sources",
            [
                {
                    "source_name": source_name,
                    "source_kind": source_kind,
                    "source_path": source_path,
                    "start_extraction": _iso(start_extraction or datetime.now()),
                    "status": status,
                    "files_total": files_total,
                }
            ],
            select="*",
        )
        return _source_record(created[0])

    def get_by_id(self, source_id: uuid.UUID | str) -> SourceRecord | None:
        row = self.client.get_one("sources", params={"id": f"eq.{source_id}"})
        return _source_record(row) if row else None

    def get_by_name(self, source_name: str) -> SourceRecord | None:
        row = self.client.get_one(
            "sources", params={"source_name": f"eq.{source_name}"}
        )
        return _source_record(row) if row else None

    def get_all(self, pattern: str | None = None) -> list[SourceRecord]:
        params = {"order": "created_at.desc"}
        if pattern and pattern != "*":
            params["source_name"] = f"like.{pattern}"
        return [
            _source_record(row) for row in self.client.get("sources", params=params)
        ]

    def get_by_status(self, status: str) -> list[SourceRecord]:
        rows = self.client.get("sources", params={"status": f"eq.{status}"})
        return [_source_record(row) for row in rows]

    def update(
        self,
        source_id: uuid.UUID | str,
        *,
        source_name: str | None = None,
        source_path: str | None = None,
        source_kind: str | None = None,
        start_extraction: datetime | None = None,
        end_extraction: datetime | None = None,
        status: str | None = None,
        files_total: int | None = None,
        updated_at: datetime | None = None,
    ) -> SourceRecord | None:
        """Patch source fields (PATCH only sends provided fields)."""
        values: dict[str, Any] = {"updated_at": _iso(updated_at or datetime.now())}
        if source_name:
            values["source_name"] = source_name
        if source_path:
            values["source_path"] = source_path
        if source_kind:
            values["source_kind"] = source_kind
        if start_extraction:
            values["start_extraction"] = _iso(start_extraction)
        if end_extraction:
            values["end_extraction"] = _iso(end_extraction)
        if status:
            values["status"] = status
        if files_total is not None:
            values["files_total"] = files_total
        rows = self.client.update(
            "sources", values, params={"id": str(source_id)}
        )
        return _source_record(rows[0]) if rows else None

    def delete(self, source_id: uuid.UUID | str) -> bool:
        """Delete the source; cascade removes files and kb_chunks (DDL)."""
        return self.client.delete("sources", params={"id": str(source_id)}) > 0

    def count(self) -> int:
        return self.client.count("sources")


class PostgRESTFileRepository:
    """SourceFile CRUD over the PostgREST table API (schema ``mylibrary``)."""

    def __init__(self, client: PostgRESTClient) -> None:
        self.client = client
        self.client.ensure_available()

    @staticmethod
    def _file_row(file_data: dict[str, Any], source_id: uuid.UUID | str) -> dict[str, Any]:
        details = file_data.get("details") or {}
        row: dict[str, Any] = {
            "source_id": str(source_id),
            "file_path": file_data["file_path"],
            "status": file_data.get("status", "OK"),
            "status_message": file_data.get("status_message"),
            "inference": file_data.get("inference"),
            "md5sum": details.get("md5sum") if isinstance(details, dict) else None,
            "details": details,
            "processed_at": _iso(file_data.get("processed_at") or datetime.now()),
        }
        # Topics SEMPRE presente (mesmo vazio): um POST em batch exige o MESMO
        # conjunto de chaves em todas as linhas — chave omitida em algumas linhas
        # vira 400 "All object keys must match" no fim do reconcile inteiro.
        # Preservação real (merge-duplicates não zerar curadoria) é papel do
        # engine: ele só envia tópicos existentes/quando gerados.
        row["topics"] = list(file_data.get("topics") or [])
        return row

    def create(
        self,
        source_id: uuid.UUID | str,
        file_path: str,
        status: str = "OK",
        status_message: str | None = None,
        inference: str | None = None,
        details: dict[str, Any] | None = None,
        *,
        topics: list[str] | None = None,
        upsert: bool = False,
    ) -> SourceFileRecord:
        """Insert (or upsert) a single file record."""
        file_data: dict[str, Any] = {
            "file_path": file_path,
            "status": status,
            "status_message": status_message,
            "inference": inference,
            "details": details or {},
        }
        if topics:
            file_data["topics"] = list(topics)
        rows = self.client.insert(
            "source_files",
            [self._file_row(file_data, source_id)],
            upsert=upsert,
            on_conflict="source_id,file_path" if upsert else None,
            select="*",
        )
        return _file_record(rows[0])

    def create_batch(
        self,
        source_id: uuid.UUID | str,
        files_data: list[dict[str, Any]],
        *,
        upsert: bool = False,
    ) -> int:
        """Insert file records in one HTTP call (batch, A9)."""
        if not files_data:
            return 0
        rows = [
            self._file_row(file_data, source_id) for file_data in files_data
        ]
        created = self.client.insert(
            "source_files",
            rows,
            upsert=upsert,
            on_conflict="source_id,file_path" if upsert else None,
            select="*",
        )
        return len(created)

    def get_by_id(self, file_id: uuid.UUID | str) -> SourceFileRecord | None:
        row = self.client.get_one("source_files", params={"id": f"eq.{file_id}"})
        return _file_record(row) if row else None

    def get_by_source(self, source_id: uuid.UUID | str) -> list[SourceFileRecord]:
        rows = self.client.get(
            "source_files",
            params={"source_id": f"eq.{source_id}", "order": "file_path"},
        )
        return [_file_record(row) for row in rows]

    def get_by_md5(self, md5sum: str) -> list[SourceFileRecord]:
        rows = self.client.get("source_files", params={"md5sum": f"eq.{md5sum}"})
        return [_file_record(row) for row in rows]

    def get_errors(self, source_id: uuid.UUID | str) -> list[SourceFileRecord]:
        rows = self.client.get(
            "source_files",
            params={"source_id": f"eq.{source_id}", "status": "eq.ERROR"},
        )
        return [_file_record(row) for row in rows]

    def count_by_source(self, source_id: uuid.UUID | str) -> int:
        return self.client.count("source_files", params={"source_id": str(source_id)})

    def count_errors_by_source(self, source_id: uuid.UUID | str) -> int:
        return self.client.count(
            "source_files",
            params={"source_id": str(source_id), "status": "ERROR"},
        )

    def delete_by_source(self, source_id: uuid.UUID | str) -> int:
        return self.client.delete(
            "source_files", params={"source_id": str(source_id)}
        )

    def delete_by_path(self, source_id: uuid.UUID | str, file_path: str) -> int:
        """Delete one file row by (source_id, file_path); cascade hits kb_chunks."""
        return self.client.delete(
            "source_files",
            params={"source_id": str(source_id), "file_path": file_path},
        )


__all__ = [
    "PostgRESTFileRepository",
    "PostgRESTSourceRepository",
    "SourceFileRecord",
    "SourceRecord",
]