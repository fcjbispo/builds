"""Ingest for MyLibraryScanner v1 (A8/D9) — inference → chunks → KB.

Chunking 512/64 characters over the file's *inference* (ingest depends on
prior inference by design — A8/D9; a file without inference is skipped, A5).
Embeddings: nomic-embed-text (768d) via the configured Ollama profile.
Writes go to ``kb_chunks`` in ONE PostgREST call per file (batch, A9); the
``tsv`` fills via the database trigger. Re-ingestion overwrites the file's
chunks (delete + insert in the same pass).
"""

from __future__ import annotations

import fnmatch
from collections.abc import Callable, Iterable, Sequence
from typing import Any

from mylibraryscanner.database.postgrest_client import PostgRESTClient
from mylibraryscanner.database.postgrest_repository import (
    PostgRESTFileRepository,
    SourceFileRecord,
    SourceRecord,
)
from mylibraryscanner.initialization import get_app_config, get_logger_instance

EMBEDDING_DIM = 768

EmbeddingFunction = Callable[[str], Sequence[float] | None]

DEFAULT_CHUNK_SIZE = 512
DEFAULT_CHUNK_OVERLAP = 64


def chunk_text(
    text: str,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[str]:
    """Deterministic sliding-window chunker (D9 — 512/64 by default).

    Exact guarantees: chunks are at most ``chunk_size`` characters; the last
    chunk keeps the tail even when shorter than the overlap; empty text
    yields no chunks.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if chunk_overlap < 0 or chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be in [0, chunk_size)")
    clean = (text or "").strip()
    if not clean:
        return []

    step = chunk_size - chunk_overlap
    chunks: list[str] = []
    start = 0
    length = len(clean)
    while start < length:
        chunk = clean[start : start + chunk_size]
        chunks.append(chunk.strip())
        if start + chunk_size >= length:
            break
        start += step
    final = [c for c in chunks if c]
    return final if final else [clean[:chunk_size]]


def resolve_ingest_defaults() -> tuple[int, int, str]:
    """(chunk_size, chunk_overlap, embedding_model) from app.json."""
    config = get_app_config().get("config", {})
    size = max(1, int(config.get("llm_embedding_chunk_size", DEFAULT_CHUNK_SIZE)))
    overlap = max(
        0, min(int(config.get("llm_embedding_chunk_overlap", DEFAULT_CHUNK_OVERLAP)), size - 1)
    )
    model = str(config.get("llm_embedding_model", "nomic-embed-text")).strip() or "nomic-embed-text"
    return size, overlap, model


def make_embedding_service() -> EmbeddingFunction:
    """Embedding function backed by the configured Ollama profile (local)."""
    from mylibraryscanner.core.embedding import EmbeddingService

    return EmbeddingService().create_embedding


def ingest_file_chunks(
    client: PostgRESTClient,
    row: SourceFileRecord,
    embedding_fn: EmbeddingFunction,
    *,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    embedding_model: str = "nomic-embed-text",
    dry_run: bool = False,
) -> int:
    """Ingest ONE file (chunks in a single PostgREST call) → chunks count.

    Re-ingestion overwrites: existing chunks of the row are deleted before
    the batch insert (A9). An empty vector or a dimension mismatch fails
    this file only — never the whole run (A5).
    Returns −1 when the row has no inference to ingest (caller skips it).
    """
    text = (row.inference or "").strip()
    if not text:
        return -1

    chunks = chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    rows: list[dict[str, Any]] = []
    for index, chunk in enumerate(chunks):
        vector = list(embedding_fn(chunk) or [])
        if not vector:
            raise ValueError(f"embedding empty for chunk {index} of {row.file_path}")
        if len(vector) != EMBEDDING_DIM:
            raise ValueError(
                f"embedding dimension {len(vector)} != {EMBEDDING_DIM} "
                f"(model: {embedding_model})"
            )
        rows.append(
            {
                "source_file_id": row.id,
                "chunk_index": index,
                "text": chunk,
                "embedding": vector,
                "embedding_model": embedding_model,
            }
        )
    if dry_run:
        return len(rows)

    # A9: overwrite previous chunks of this file (delete + 1 batch insert).
    client.delete("kb_chunks", params={"source_file_id": str(row.id)})
    client.insert("kb_chunks", rows)
    return len(rows)


def run_ingest(
    client: PostgRESTClient,
    source: SourceRecord,
    file_repo: PostgRESTFileRepository,
    embedding_fn: EmbeddingFunction | None,
    *,
    pattern: str = "*",
    paths: Iterable[str] | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    embedding_model: str = "nomic-embed-text",
    dry_run: bool = False,
) -> dict[str, int]:
    """Ingest files of a SOURCE; returns A10 counters (never aborts, A5).

    ``paths`` restricts the run to specific files (the scan flow ingests
    only what the reconcile touched); ``pattern`` filters by file name
    (ingest_source). Files without inference are skipped (A5).
    """
    rows = file_repo.get_by_source(source.id)
    selected = [r for r in rows if not paths or r.file_path in set(paths)]
    if pattern and pattern != "*":
        selected = [r for r in selected if fnmatch.fnmatch(r.file_path, pattern)]

    counters = {
        "files_read": len(rows),
        "ingested": 0,
        "skipped": 0,
        "failed": 0,
    }
    log = get_logger_instance()
    for row in selected:
        try:
            if embedding_fn is None:
                raise ValueError("embedding provider not configured (Ollama)")
            written = ingest_file_chunks(
                client,
                row,
                embedding_fn,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                embedding_model=embedding_model,
                dry_run=dry_run,
            )
        except Exception as exc:  # noqa: BLE001 — per-file failure (A5)
            log.warning("ingest failed for %s: %s", row.file_path, exc)
            counters["failed"] += 1
            continue
        if written < 0:
            counters["skipped"] += 1
        else:
            counters["ingested"] += written
    return counters


__all__ = [
    "EMBEDDING_DIM",
    "chunk_text",
    "ingest_file_chunks",
    "make_embedding_service",
    "resolve_ingest_defaults",
    "run_ingest",
]