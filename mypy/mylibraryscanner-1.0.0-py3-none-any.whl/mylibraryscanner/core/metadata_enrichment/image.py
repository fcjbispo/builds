"""Image metadata enrichment."""

from __future__ import annotations

import json
from fractions import Fraction
from pathlib import Path
from typing import Any


def _jsonable(value: Any) -> Any:
    """Coerce metadata values to JSON-native types.

    Pillow EXIF returns ``IFDRational`` (ratio) values, bytes and custom
    objects that are not JSON-serializable — the details JSONB write would
    crash the whole scan (TypeError at request encode). Normalize here, at
    the extraction point.
    """
    if isinstance(value, (Fraction, float)) or (hasattr(value, "numerator") and hasattr(value, "denominator")):
        try:
            return float(value)
        except Exception:  # noqa: BLE001 — degenerate ratios
            return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").replace("\x00", "").strip()
    if isinstance(value, dict):
        return {str(key): _jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(val) for val in value]
    if isinstance(value, (int, bool)) or value is None or isinstance(value, str):
        return value
    try:
        json.dumps(value)
        return value
    except Exception:  # noqa: BLE001 — último recurso
        return str(value)


def extract_image_metadata(file_path: str) -> dict[str, Any]:
    """Extract specialized image metadata.

    Uses Pillow when available. Returns partial metadata when dependencies are absent.
    """
    metadata: dict[str, Any] = {}
    path = Path(file_path)
    metadata["extension"] = path.suffix.lower()

    try:
        from PIL import ExifTags, Image  # type: ignore
    except Exception:
        return metadata

    try:
        with Image.open(path) as image:
            metadata["width"] = int(image.width)
            metadata["height"] = int(image.height)
            metadata["format"] = image.format
            metadata["mime_type"] = image.get_format_mimetype()
            metadata["color_mode"] = image.mode
            metadata["bands"] = list(image.getbands())

            try:
                metadata["bits_per_channel"] = image.bits
            except Exception:
                # Pillow does not provide this attribute for all formats.
                pass

            exif_data: dict[str, Any] = {}
            exif_raw = image.getexif()
            if exif_raw:
                for tag_id, value in exif_raw.items():
                    key = ExifTags.TAGS.get(tag_id, str(tag_id))
                    exif_data[key] = _jsonable(value)

            if exif_data:
                metadata["camera_make"] = exif_data.get("Make")
                metadata["camera_model"] = exif_data.get("Model")
                metadata["capture_datetime"] = exif_data.get("DateTimeOriginal")
                metadata["software"] = exif_data.get("Software")
                metadata["copyright"] = exif_data.get("Copyright")
                metadata["iso"] = exif_data.get("ISOSpeedRatings")
                metadata["exposure_time"] = exif_data.get("ExposureTime")
                metadata["aperture"] = exif_data.get("FNumber")
                metadata["orientation"] = exif_data.get("Orientation")
                metadata["exif"] = {
                    k: v for k, v in exif_data.items() if v is not None
                }
    except Exception:
        return metadata

    return metadata

