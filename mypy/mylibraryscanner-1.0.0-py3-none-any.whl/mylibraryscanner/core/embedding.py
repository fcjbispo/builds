"""Embedding helpers for MyLibraryScanner."""

from __future__ import annotations

from mylibraryscanner.core.llm_client import LLMClient
from mylibraryscanner.initialization import get_app_config


class EmbeddingService:
    """Generate vector embeddings using the configured embedding profile."""

    # ponytail: 300s — Ollama enfileira embeddings quando um LLM grande está
    # residente na VRAM (30s+ de espera já medido); configurável quando doer.
    EMBEDDING_TIMEOUT = 300

    def __init__(self) -> None:
        config = get_app_config().get("config", {})
        self.chunk_size = int(config.get("llm_embedding_chunk_size", 150))
        self.chunk_overlap = int(config.get("llm_embedding_chunk_overlap", 35))
        self.client = LLMClient()

    def create_embedding(self, text: str) -> list[float] | None:
        if not text or not text.strip():
            return None
        return self.client.create_embedding(text.strip(), timeout=self.EMBEDDING_TIMEOUT)

