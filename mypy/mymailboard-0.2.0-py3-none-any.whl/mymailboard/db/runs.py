"""runs.py — execuções do motor: histórico, progresso, cancelamento e lock.

- Cada operação abre uma linha em `claw.mmb_runs` (status=running), atualiza os
  contadores e o heartbeat, e fecha com `ok`/`error`/`cancelled`.
- **Rastreabilidade** (opção 1+2, 2026-10-13): a execução grava o **modelo** usado
  (`model`) e um **snapshot dos parâmetros** (`params` jsonb); o item processado
  guarda o `run_id` (`emails.classify_run_id` / `emails.infer_run_id`) — modelo e
  data de cada processamento saem do JOIN com esta tabela.
- `cancel_requested` é checado pelo motor a cada item (cancelamento cooperativo).
- `lock(mode)` usa advisory lock do PostgreSQL: container e CLI no host nunca
  rodam a mesma operação ao mesmo tempo.
"""
from __future__ import annotations

import json
import os
import time
from contextlib import contextmanager

from .conn import DB, connect

VALID_MODES = ("sync", "classify", "infer", "embed", "report")

# chaves do snapshot de parâmetros gravado em `mmb_runs.params`
PARAM_KEYS = ("llm.provider", "llm.base_url", "llm.classify.model", "llm.infer.model",
              "llm.embed.model", "llm.decision.model", "llm.temperature", "llm.timeout_s",
              "engine.threads", "engine.batch_limit", "engine.window_end",
              "engine.body_chars_infer", "engine.body_chars_embed")


def model_of(mode: str, cfg: dict | None) -> str | None:
    """Modelo LLM da etapa (`classify`/`infer`/`embed`); None para sync/report."""
    cfg = cfg or {}
    key = f"llm.{mode}.model"
    return cfg.get(key) or None


def snapshot(cfg: dict | None) -> dict | None:
    """Snapshot dos parâmetros vigentes (para `mmb_runs.params`)."""
    if not cfg:
        return None
    return {k: cfg.get(k) for k in PARAM_KEYS if cfg.get(k) not in (None, "")}


def start(mode: str, window: tuple | None = None, limit: int | None = None,
          dry_run: bool = False, triggered_by: str = "cli", total: int | None = None,
          cfg: dict | None = None) -> int:
    with DB() as db:
        rows = db.select(
            """INSERT INTO claw.mmb_runs (mode, status, window_start, window_end, limit_n,
                                          dry_run, triggered_by, total, pid, model, params)
               VALUES (%s, 'running', %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb) RETURNING id""",
            (mode, window[0] if window else None, window[1] if window else None,
             limit, dry_run, triggered_by, total, os.getpid(),
             model_of(mode, cfg),
             json.dumps(snapshot(cfg), ensure_ascii=False) if cfg else None),
        )
    return rows[0][0]


def progress(run_id: int, processed: int, ok: int, fallback: int = 0, errors: int = 0) -> None:
    _update(run_id, processed=processed, ok_count=ok, fallback_count=fallback,
            error_count=errors, heartbeat_at=None)


def finish(run_id: int, status: str, ok: int = 0, fallback: int = 0, errors: int = 0,
           processed: int | None = None, message: str | None = None) -> None:
    with DB() as db:
        db.execute(
            """UPDATE claw.mmb_runs
                  SET status=%s, ok_count=%s, fallback_count=%s, error_count=%s,
                      processed=COALESCE(%s, processed), finished_at=now(), heartbeat_at=now(),
                      message=%s
                WHERE id=%s""",
            (status, ok, fallback, errors, processed, (message or "")[:2000], run_id),
        )


def _update(run_id: int, **cols) -> None:
    sets, params = [], []
    for k, v in cols.items():
        if k == "heartbeat_at" and v is None:
            sets.append("heartbeat_at = now()")
        else:
            sets.append(f"{k} = %s")
            params.append(v)
    params.append(run_id)
    try:
        with DB() as db:
            db.execute(f"UPDATE claw.mmb_runs SET {', '.join(sets)} WHERE id = %s", params)
    except Exception:
        pass  # o progresso nunca derruba a operação


def cancel_requested(run_id: int) -> bool:
    try:
        with DB() as db:
            rows = db.select("SELECT cancel_requested FROM claw.mmb_runs WHERE id=%s", (run_id,))
        return bool(rows and rows[0][0])
    except Exception:
        return False


def cancel(run_id: int) -> bool:
    with DB() as db:
        db.execute("UPDATE claw.mmb_runs SET cancel_requested=true WHERE id=%s AND status='running'",
                   (run_id,))
    return True


def recent(limit: int = 25) -> list[dict]:
    with DB() as db:
        rows = db.select(
            """SELECT id, mode, status, window_start, window_end, limit_n, dry_run, total,
                      processed, ok_count, fallback_count, error_count, started_at, finished_at,
                      heartbeat_at, triggered_by, cancel_requested, message, model
                 FROM claw.mmb_runs ORDER BY started_at DESC LIMIT %s""", (limit,))
    cols = ("id", "mode", "status", "window_start", "window_end", "limit_n", "dry_run", "total",
            "processed", "ok_count", "fallback_count", "error_count", "started_at", "finished_at",
            "heartbeat_at", "triggered_by", "cancel_requested", "message", "model")
    return [dict(zip(cols, r)) for r in rows]


def por_modelo(mode: str | None = None) -> list[dict]:
    """Execuções agregadas por modelo — responde "qual modelo rendeu o quê".

    Com `mode` filtra uma operação (classify/infer); sem, agrega todas as etapas LLM.
    """
    sql = """SELECT mode, coalesce(model, '(nao registrado)') AS modelo,
                    count(*)                                          AS execucoes,
                    sum(processed)                                    AS processados,
                    sum(ok_count)                                     AS ok,
                    sum(fallback_count)                               AS fallback,
                    sum(error_count)                                  AS erros,
                    round(sum(ok_count) * 100.0 / greatest(sum(processed), 1), 1) AS pct_ok,
                    min(started_at)::date                             AS primeira,
                    max(started_at)::date                             AS ultima
               FROM claw.mmb_runs
              WHERE processed IS NOT NULL"""
    params: list = []
    if mode:
        sql += " AND mode = %s"
        params.append(mode)
    sql += " GROUP BY 1, 2 ORDER BY 1, 4 DESC"
    with DB() as db:
        rows = db.select(sql, params)
    cols = ("mode", "modelo", "execucoes", "processados", "ok", "fallback", "erros",
            "pct_ok", "primeira", "ultima")
    return [dict(zip(cols, r)) for r in rows]


def running(mode: str | None = None) -> list[dict]:
    sql = ("SELECT id, mode, status, started_at, heartbeat_at, processed, total, triggered_by "
           "FROM claw.mmb_runs WHERE status='running'")
    params: list = []
    if mode:
        sql += " AND mode = %s"
        params.append(mode)
    with DB() as db:
        rows = db.select(sql + " ORDER BY started_at DESC", params)
    cols = ("id", "mode", "status", "started_at", "heartbeat_at", "processed", "total", "triggered_by")
    return [dict(zip(cols, r)) for r in rows]


def stale(timeout_s: int = 900) -> int:
    """Marca como 'error' execuções sem heartbeat (container morto no meio)."""
    with DB() as db:
        db.execute(
            """UPDATE claw.mmb_runs SET status='error', finished_at=now(),
                      message=COALESCE(message,'') || ' [heartbeat expirado]'
                WHERE status='running' AND heartbeat_at < now() - make_interval(secs => %s)""",
            (timeout_s,),
        )
        rows = db.select("SELECT count(*) FROM claw.mmb_runs WHERE status='running'")
    return rows[0][0]


@contextmanager
def lock(mode: str, wait_s: int = 0):
    """Advisory lock por modo. `wait_s=0` falha na hora se já houver execução.

    Usa conexão dedicada: o lock só é liberado ao fechar (fim do bloco) ou se a
    conexão cair — o que é exatamente o comportamento desejado."""
    cn = connect(timeout=10)
    got = False
    try:
        cur = cn.cursor()
        cur.execute("SELECT pg_try_advisory_lock(hashtext('mmb:' || %s))", [mode])
        got = bool(cur.fetchone()[0])
        if not got and wait_s > 0:
            t0 = time.time()
            while not got and time.time() - t0 < wait_s:
                time.sleep(1)
                cur.execute("SELECT pg_try_advisory_lock(hashtext('mmb:' || %s))", [mode])
                got = bool(cur.fetchone()[0])
        cur.close()
        yield got
    finally:
        try:
            cur = cn.cursor()
            cur.execute("SELECT pg_advisory_unlock_all()")
            cur.close()
        except Exception:
            pass
        cn.close()
