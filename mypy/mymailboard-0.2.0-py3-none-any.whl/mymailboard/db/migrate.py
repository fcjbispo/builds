"""migrate.py — aplica as migrations e as views de análise do MyMailBoard.

Uso:
    mymailboard migrate          # aplica tudo (idempotente)
    python -m mymailboard.db.migrate
"""
from __future__ import annotations

import pathlib
import sys

from .conn import DB

SQL_DIR = pathlib.Path(__file__).resolve().parent.parent / "sql"


def _files() -> list[pathlib.Path]:
    out = sorted((SQL_DIR / "migrations").glob("*.sql"))
    views = SQL_DIR / "views_analise.sql"
    if views.exists():
        out.append(views)
    return out


def apply(path: pathlib.Path) -> int:
    """Executa um arquivo .sql inteiro (simple query do PG aceita vários statements)."""
    sql = path.read_text(encoding="utf-8")
    with DB() as db:
        cur = db.cn.cursor()
        try:
            cur.execute(sql)
        except Exception as e:
            db.cn.rollback()
            print(f"  ✗ {path.name}: {type(e).__name__}: {str(e)[:200]}", file=sys.stderr)
            return 1
        finally:
            cur.close()
        db.cn.commit()
    n = sql.count("CREATE OR REPLACE VIEW") + sql.count("CREATE TABLE IF NOT EXISTS")
    print(f"  ✓ {path.name} ({n} objeto(s))")
    return 0


def main() -> int:
    files = _files()
    if not files:
        print("  ! nenhum .sql encontrado", file=sys.stderr)
        return 1
    print(f"MyMailBoard — aplicando {len(files)} arquivo(s) SQL em claw:")
    errs = sum(apply(f) for f in files)
    print("─" * 60)
    print(f"  {len(files) - errs} ok · {errs} erro(s)")
    return 1 if errs else 0


if __name__ == "__main__":
    raise SystemExit(main())
