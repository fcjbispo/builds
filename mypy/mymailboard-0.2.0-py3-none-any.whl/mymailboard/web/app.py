"""app.py — FBNet Mail Insights: dashboards reativos sobre as views de e-mail.

App Dash (Plotly + dash-bootstrap-components) que le as views de analise do
schema `claw` e apresenta 5 paineis:

  1. Visao geral  — volume no tempo, quando os e-mails chegam, distribuicao
  2. Quem me escreve — Pareto de remetentes, dominios, destinatarios, tabela
  3. Pendencias   — backlog de nao lidos por idade + conversas em aberto
  4. Minha resposta — SLA/mediana de tempo de resposta, distribuicao
  5. Pipeline     — progresso da classificacao/inferencia/embedding

Filtros globais (periodo, direcao, classificacao, busca) sao reativos: todos
os paineis reagem a eles. Os dados vem com cache TTL (data_layer.py).

Rodar:  python app.py            (porta 8050 por default)
Env:    FBNET_EMAILDASH_DB_URI   credenciais (obrigatorio)
        EMAILDASH_PORT / EMAILDASH_CACHE_TTL
"""
from __future__ import annotations

import os

import dash
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
from dash import Input, Output, State, dash_table, dcc, html

from ..db import views as dl
from . import config_page as cfg_page
from . import operacoes as op_page

ACCENT, ACCENT2, WARN, BAD, OK = "#22d3ee", "#a78bfa", "#f59e0b", "#f87171", "#34d399"

# ----------------------------------------------------------------------------
# Tema Plotly (dark, fundo transparente, grid discreta)
# ----------------------------------------------------------------------------
pio.templates["fbnet"] = go.layout.Template(
    layout=go.Layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, system-ui, Segoe UI, sans-serif", color="#cbd5e1", size=12),
        colorway=[ACCENT, WARN, ACCENT2, OK, BAD, "#60a5fa", "#fbbf24", "#f472b6"],
        xaxis=dict(gridcolor="rgba(148,163,184,.14)", zerolinecolor="rgba(148,163,184,.25)"),
        yaxis=dict(gridcolor="rgba(148,163,184,.14)", zerolinecolor="rgba(148,163,184,.25)"),
        hoverlabel=dict(bgcolor="#0b1220", bordercolor=ACCENT, font=dict(color="#e2e8f0")),
        margin=dict(l=48, r=18, t=46, b=42),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0),
        title=dict(font=dict(size=14, color="#e2e8f0")),
    )
)
pio.templates.default = "fbnet"

GRAPH_CFG = {"displayModeBar": False, "responsive": True}
TAB_STYLE = {
    "backgroundColor": "rgba(15,23,42,.65)",
    "border": "1px solid rgba(148,163,184,.18)",
    "borderRadius": "10px",
    "color": "#cbd5e1",
    "padding": "8px 14px",
    "marginRight": "6px",
}
TAB_SEL_STYLE = {
    "backgroundColor": "rgba(34,211,238,.16)",
    "border": "1px solid rgba(34,211,238,.55)",
    "borderRadius": "10px",
    "color": ACCENT,
    "fontWeight": "700",
    "padding": "8px 14px",
    "marginRight": "6px",
}


def card(titulo: str, corpo, sub: str = "", cor: str = ACCENT, largura: int = 3):
    return dbc.Col(
        dbc.Card(
            dbc.CardBody(
                [
                    html.Div(titulo, className="kpi-label"),
                    html.Div(corpo, className="kpi-value"),
                    html.Div(sub, className="kpi-sub"),
                ]
            ),
            className="kpi-card h-100",
            style={"borderTop": f"3px solid {cor}"},
        ),
        xs=6, sm=6, md=4, lg=largura,
    )


def bloco(titulo: str, grafico_id: str, altura: int = 340):
    return dbc.Card(
        dbc.CardBody(
            [
                html.Div(titulo, className="bloco-titulo"),
                dcc.Loading(dcc.Graph(id=grafico_id, config=GRAPH_CFG, style={"height": altura})),
            ]
        ),
        className="painel h-100",
    )


def tabela(tid: str, colunas: list[str], tipos_ok: bool = True):
    return dash_table.DataTable(
        id=tid,
        columns=[{"name": c, "id": c} for c in colunas],
        data=[],
        sort_action="native",
        filter_action="native",
        page_action="native",
        page_size=12,
        export_format="csv",
        style_as_list_view=True,
        style_table={"overflowX": "auto", "minWidth": "100%"},
        style_header={
            "backgroundColor": "rgba(15,23,42,.9)",
            "color": ACCENT,
            "fontWeight": "700",
            "border": "none",
            "borderBottom": "1px solid rgba(148,163,184,.3)",
        },
        style_cell={
            "backgroundColor": "rgba(2,6,23,.35)",
            "color": "#cbd5e1",
            "border": "none",
            "borderBottom": "1px solid rgba(148,163,184,.08)",
            "fontSize": "12.5px",
            "textAlign": "left",
            "maxWidth": "320px",
            "overflow": "hidden",
            "textOverflow": "ellipsis",
            "whiteSpace": "nowrap",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "rgba(15,23,42,.35)"},
            {"if": {"filter_query": "{urgência} = alta"}, "color": BAD, "fontWeight": "600"},
        ],
    )


# ----------------------------------------------------------------------------
# App + layout
# ----------------------------------------------------------------------------
app = dash.Dash(__name__, title="MyMailBoard · FBNet Mail Insights",
                external_stylesheets=["/assets/bootstrap.min.css"], suppress_callback_exceptions=False)
app.config.suppress_callback_exceptions = True

app.layout = dbc.Container(
    [
        html.Div(
            [
                html.Div(
                    [
                        html.H1("📬 FBNet Mail Insights", className="mb-0 titulo"),
                        html.Div(id="subtitulo", className="subtitulo"),
                    ],
                    className="flex-grow-1",
                ),
                dbc.Stack(
                    [
                        dbc.Button("🔄 Atualizar", id="btn-refresh", color="info", outline=True,
                                   size="sm", className="me-2"),
                        html.Span(id="cache-badge", className="badge-chip"),
                    ],
                    direction="horizontal",
                    className="align-items-center",
                ),
            ],
            className="header d-flex align-items-center justify-content-between py-3",
        ),
        dbc.Card(
            dbc.CardBody(
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.Div("Período", className="filtro-label"),
                                dcc.Dropdown(id="f-periodo", clearable=False, className="filtro"),
                            ],
                            xs=12, sm=6, lg=3,
                        ),
                        dbc.Col(
                            [
                                html.Div("Direção", className="filtro-label"),
                                dcc.Dropdown(id="f-direcao", clearable=False, className="filtro"),
                            ],
                            xs=12, sm=6, lg=3,
                        ),
                        dbc.Col(
                            [
                                html.Div("Classificação", className="filtro-label"),
                                dcc.Dropdown(id="f-classif", multi=True, placeholder="todas",
                                             className="filtro"),
                            ],
                            xs=12, sm=6, lg=3,
                        ),
                        dbc.Col(
                            [
                                html.Div("Buscar (remetente/assunto/domínio)", className="filtro-label"),
                                dbc.Input(id="f-busca", placeholder="ex.: azul, boleto, linkedin…",
                                          debounce=True, className="filtro"),
                            ],
                            xs=12, sm=6, lg=3,
                        ),
                    ],
                    className="g-2",
                )
            ),
            className="painel mb-3 painel-filtros",
        ),
        html.Div(id="cards-kpi", className="mb-2"),
        dcc.Tabs(
            [
                dcc.Tab(
                    [
                        dbc.Row(
                            [
                                dbc.Col(bloco("Volume por mês (por direção)", "g-volume", 360), xs=12, lg=8),
                                dbc.Col(bloco("Classificação", "g-classif", 360), xs=12, lg=4),
                            ],
                            className="g-3 my-3",
                        ),
                        dbc.Row(
                            [
                                dbc.Col(bloco("Quando os e-mails chegam (dia × hora)", "g-heat", 380), xs=12, lg=7),
                                dbc.Col(bloco("Categoria de alto nível", "g-categoria", 380), xs=12, lg=5),
                            ],
                            className="g-3 mb-3",
                        ),
                    ],
                    label="📊 Visão geral", style=TAB_STYLE, selected_style=TAB_SEL_STYLE,
                ),
                dcc.Tab(
                    [
                        dbc.Row(
                            [
                                dbc.Col(bloco("Pareto de remetentes (top 25)", "g-pareto", 380), xs=12, lg=7),
                                dbc.Col(bloco("Top domínios", "g-dominio", 380), xs=12, lg=5),
                            ],
                            className="g-3 my-3",
                        ),
                        dbc.Row(
                            [
                                dbc.Col(bloco("Para quem eu envio (top destinatários)", "g-dest", 340), xs=12, lg=5),
                                dbc.Col(
                                    dbc.Card(
                                        dbc.CardBody(
                                            [
                                                html.Div("Remetentes no período", className="bloco-titulo"),
                                                dcc.Loading(tabela("t-remetentes",
                                                                   ["remetente", "total", "não lidos", "% lido",
                                                                    "importante", "% lixo", "último"])),
                                            ]
                                        ),
                                        className="painel h-100",
                                    ),
                                    xs=12, lg=7,
                                ),
                            ],
                            className="g-3 mb-3",
                        ),
                    ],
                    label="👥 Quem me escreve", style=TAB_STYLE, selected_style=TAB_SEL_STYLE,
                ),
                dcc.Tab(
                    [
                        dbc.Row(
                            [
                                dbc.Col(bloco("Backlog de não lidos por idade", "g-aging", 330), xs=12, lg=6),
                                dbc.Col(bloco("Conversas em aberto", "g-abertas", 330), xs=12, lg=6),
                            ],
                            className="g-3 my-3",
                        ),
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.Div(
                                        [
                                            html.Span("Conversas aguardando ação", className="bloco-titulo"),
                                            dcc.RadioItems(
                                                id="f-aguardando",
                                                options=[
                                                    {"label": " 🤚 Eu devo resposta", "value": "VOCE"},
                                                    {"label": " 📤 Esperando retorno deles", "value": "OUTRO"},
                                                ],
                                                value="VOCE",
                                                inline=True,
                                                className="ms-3 d-inline-block small",
                                            ),
                                        ],
                                        className="mb-2",
                                    ),
                                    dcc.Loading(
                                        tabela("t-conversas",
                                               ["assunto", "remetente", "dias parado", "urgência",
                                                "classificação", "msg", "última"])
                                    ),
                                ]
                            ),
                            className="painel mb-3",
                        ),
                    ],
                    label="⏳ Pendências", style=TAB_STYLE, selected_style=TAB_SEL_STYLE,
                ),
                dcc.Tab(
                    [
                        dbc.Row(
                            [
                                dbc.Col(bloco("Tempo de resposta por mês (mediana e média)", "g-sla", 360), xs=12, lg=7),
                                dbc.Col(bloco("Dentro do SLA (% por faixa)", "g-sla-barras", 360), xs=12, lg=5),
                            ],
                            className="g-3 my-3",
                        ),
                        dbc.Row(
                            [
                                dbc.Col(bloco("Distribuição do tempo de resposta", "g-hist", 340), xs=12, lg=7),
                                dbc.Col(
                                    dbc.Card(
                                        dbc.CardBody(
                                            [
                                                html.Div("Respostas medidas (por mês)", className="bloco-titulo"),
                                                dcc.Loading(tabela("t-sla",
                                                                   ["ano_mês", "respostas", "mediana (h)",
                                                                    "% ≤1h", "% ≤4h", "% ≤24h"])),
                                            ]
                                        ),
                                        className="painel h-100",
                                    ),
                                    xs=12, lg=5,
                                ),
                            ],
                            className="g-3 mb-3",
                        ),
                    ],
                    label="⚡ Minha resposta", style=TAB_STYLE, selected_style=TAB_SEL_STYLE,
                ),
                dcc.Tab(
                    [
                        dbc.Row(
                            [
                                dbc.Col(bloco("Progresso do pipeline por mês", "g-pipe", 380), xs=12, lg=8),
                                dbc.Col(bloco("Fila atual (pendências)", "g-pipe-fila", 380), xs=12, lg=4),
                            ],
                            className="g-3 my-3",
                        ),
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.Div("Detalhe por mês", className="bloco-titulo"),
                                    dcc.Loading(tabela("t-pipe",
                                                       ["ano_mês", "total", "classificados", "pendentes",
                                                        "% classificado", "% inferido", "% embedado"])),
                                ]
                            ),
                            className="painel mb-3",
                        ),
                    ],
                    label="🧪 Pipeline", style=TAB_STYLE, selected_style=TAB_SEL_STYLE,
                ),
                dcc.Tab(op_page.layout(), label="⚙ Operações", style=TAB_STYLE,
                        selected_style=TAB_SEL_STYLE),
                dcc.Tab(cfg_page.layout(), label="🔧 Config", style=TAB_STYLE,
                        selected_style=TAB_SEL_STYLE),
            ],
            className="mb-4",
        ),
        html.Div(
            [
                html.Span("Fonte: views claw.v_emails_* (PostgreSQL FBNet) · app Dash em fbnet/apps/emaildash · "),
                html.Span("Agente: Hermes (orquestrador FBNet)"),
            ],
            className="rodape",
        ),
    ],
    fluid=True,
    className="px-3 px-lg-4 pb-4",
)


# ----------------------------------------------------------------------------
# Helpers de filtro
# ----------------------------------------------------------------------------
def _ref_date(fato: pd.DataFrame) -> pd.Timestamp:
    """Data de referencia = ultimo e-mail carregado (o sync pode estar atrasado;
    usar `hoje` daria janelas vazias)."""
    d = fato["data"].max()
    return pd.Timestamp(d) if pd.notna(d) else pd.Timestamp.today().normalize()


def _aplicar(fato: pd.DataFrame, periodo: str, direcao: str, classif: list | None, busca: str | None) -> pd.DataFrame:
    df = fato
    ref = _ref_date(fato)
    if periodo and periodo != "tudo":
        if periodo.startswith("ano:"):
            df = df[df["ano"] == int(periodo.split(":")[1])]
        else:
            dias = int(periodo.rstrip("d"))
            df = df[df["data"] >= ref - pd.Timedelta(days=dias)]
    if direcao and direcao != "tudo":
        df = df[df["direcao"] == direcao]
    if classif:
        df = df[df["classification"].isin(classif)]
    if busca:
        b = busca.strip().lower()
        mask = (
            df["from_address"].fillna("").str.lower().str.contains(b, regex=False)
            | df["remetente_principal"].fillna("").str.lower().str.contains(b, regex=False)
            | df["assunto_principal"].fillna("").str.lower().str.contains(b, regex=False)
            | df["dominio"].fillna("").str.lower().str.contains(b, regex=False)
        )
        df = df[mask]
    return df


def _filtro_inputs() -> list:
    return [Input("f-periodo", "value"), Input("f-direcao", "value"),
            Input("f-classif", "value"), Input("f-busca", "value")]


def _vazio(msg: str) -> go.Figure:
    f = go.Figure()
    f.add_annotation(text=msg, showarrow=False, font=dict(size=14, color="#64748b"))
    f.update_layout(xaxis_visible=False, yaxis_visible=False, height=320)
    return f


def _registros(df: pd.DataFrame) -> list[dict]:
    """Converte para registros JSON-safe (sem NaN/Decimal)."""
    d = df.copy()
    for c in d.columns:
        if pd.api.types.is_datetime64_any_dtype(d[c]):
            d[c] = d[c].dt.strftime("%Y-%m-%d")
        elif pd.api.types.is_float_dtype(d[c]):
            d[c] = d[c].round(2)
    return d.where(pd.notnull(d), None).to_dict("records")


# ----------------------------------------------------------------------------
# 0) Filtros: opções que dependem dos dados (anos disponíveis) + refresh
# ----------------------------------------------------------------------------
@app.callback(
    Output("f-periodo", "options"), Output("f-periodo", "value"),
    Output("f-direcao", "options"), Output("f-direcao", "value"),
    Output("f-classif", "options"),
    Output("subtitulo", "children"), Output("f-busca", "value"),
    Input("btn-refresh", "n_clicks"),
    prevent_initial_call=False,
)
def _init(_n):
    if _n:
        dl.clear_cache()
    fato = dl.get("fato", force=bool(_n))
    anos = sorted([int(a) for a in fato["ano"].dropna().unique()], reverse=True)
    per_opts = [{"label": "📅 Tudo (2014→hoje)", "value": "tudo"},
                {"label": "Últimos 90 dias de dados", "value": "90d"},
                {"label": "Últimos 12 meses de dados", "value": "365d"}]
    per_opts += [{"label": f"Ano {a}", "value": f"ano:{a}"} for a in anos]
    dir_opts = [{"label": "📥 Recebidos + 📤 Enviados", "value": "tudo"},
                {"label": "📥 Recebidos", "value": "RECEBIDO"},
                {"label": "📤 Enviados", "value": "ENVIADO"}]
    cls_opts = [{"label": c.title(), "value": c}
                for c in ["IMPORTANTE", "AVALIAR", "PENDENTE", "LIXO"]
                if c in set(fato["classification"].dropna().unique())]
    ref = _ref_date(fato)
    sub = (f"{len(fato):,} e-mails · {fato['data'].min():%d/%m/%Y} → {ref:%d/%m/%Y} · "
           f"{fato['from_address'].nunique():,} remetentes · dados de {ref:%d/%m/%Y}"
           ).replace(",", ".")
    return per_opts, "tudo", dir_opts, "tudo", cls_opts, sub, None


@app.callback(Output("cache-badge", "children"), Input("f-busca", "value"))
def _badge(_):
    return f"cache {dl.cache_age()}s"


# ----------------------------------------------------------------------------
# 1) Cards de KPI
# ----------------------------------------------------------------------------
@app.callback(Output("cards-kpi", "children"), *_filtro_inputs())
def _kpis(periodo, direcao, classif, busca):
    fato = dl.get("fato")
    df = _aplicar(fato, periodo, direcao, classif, busca)
    n = len(df)
    if not n:
        return dbc.Alert("Nenhum e-mail no filtro atual.", color="warning", className="mb-0")
    nao_lidos = int((~df["readed"]).sum())
    imp = int((df["classification"] == "IMPORTANTE").sum())
    lixo = int((df["classification"] == "LIXO").sum())
    pend = int((df["classification"].isin(["AVALIAR", "PENDENTE"])).sum())
    rem = df["from_address"].nunique()
    env = int((df["direcao"] == "ENVIADO").sum())

    # conversas (filtradas por direcao/periodo quando possivel)
    conv = dl.get("conversas")
    conv_f = conv
    if periodo and periodo != "tudo":
        ref = _ref_date(fato)
        if periodo.startswith("ano:"):
            conv_f = conv_f[conv_f["ultima_data"].dt.year == int(periodo.split(":")[1])]
        else:
            conv_f = conv_f[conv_f["ultima_data"] >= ref - pd.Timedelta(days=int(periodo.rstrip("d")))]
    eu = int((conv_f["aguardando"] == "VOCE").sum())
    deles = int((conv_f["aguardando"] == "OUTRO").sum())

    # resposta
    tr = dl.get("tempo_resposta")
    med = tr["horas_resposta"].median()
    tr_p = tr
    if periodo and periodo != "tudo" and tr["data_resposta"].notna().any():
        ref = _ref_date(fato)
        if periodo.startswith("ano:"):
            tr_p = tr[tr["data_resposta"].dt.year == int(periodo.split(":")[1])]
        else:
            tr_p = tr[tr["data_resposta"] >= ref - pd.Timedelta(days=int(periodo.rstrip("d")))]
    med_p = tr_p["horas_resposta"].median() if len(tr_p) else med

    pct = lambda x: f"{100.0 * x / n:.1f}%" if n else "—"
    return dbc.Row(
        [
            card("Total no filtro", f"{n:,}".replace(",", "."), f"{env:,} enviados · {n - env:,} recebidos".replace(",", "."), ACCENT),
            card("Não lidos", f"{nao_lidos:,}".replace(",", "."), f"{pct(nao_lidos)} do total", WARN),
            card("Importantes", f"{imp:,}".replace(",", "."), f"{pct(imp)} do total", OK),
            card("Fila de triagem", f"{pend:,}".replace(",", "."), "classificação AVALIAR/PENDENTE", ACCENT2),
            card("🤚 Você deve resposta", f"{eu:,}".replace(",", "."), "conversas aguardando você", BAD),
            card("📤 Aguardando retorno", f"{deles:,}".replace(",", "."), "esperando resposta deles", "#60a5fa"),
            card("Mediana de resposta", f"{med_p:.1f} h" if pd.notna(med_p) else "—",
                 f"global: {med:.1f} h" if pd.notna(med) else "sem dados", OK),
            card("Lixo", f"{lixo:,}".replace(",", "."), f"{pct(lixo)} · {rem:,} remetentes no filtro".replace(",", "."), BAD),
        ],
        className="g-3",
    )


# ----------------------------------------------------------------------------
# 2) Visão geral
# ----------------------------------------------------------------------------
@app.callback(Output("g-volume", "figure"), *_filtro_inputs())
def _volume(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    g = df.groupby(["ano_mes", "direcao"]).size().reset_index(name="n")
    fig = px.bar(g, x="ano_mes", y="n", color="direcao", barmode="stack",
                 labels={"ano_mes": "", "n": "e-mails", "direcao": "direção"},
                 color_discrete_map={"RECEBIDO": ACCENT, "ENVIADO": ACCENT2})
    tot = df.groupby("ano_mes").size().reset_index(name="n").sort_values("ano_mes")
    tot["mm3"] = tot["n"].rolling(3, min_periods=1).mean()
    fig.add_scatter(x=tot["ano_mes"], y=tot["mm3"], mode="lines", name="média móvel 3m",
                    line=dict(color=WARN, width=1.6, dash="dot"))
    fig.update_layout(barmode="stack", bargap=0.25, xaxis=dict(tickangle=-60, nticks=24))
    return fig


@app.callback(Output("g-heat", "figure"), *_filtro_inputs())
def _heat(periodo, direcao, classif, busca):
    fato = dl.get("fato")
    df = _aplicar(fato, periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    ordem = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
    g = df.groupby(["dia_semana_nome", "hora"]).size().reset_index(name="n")
    piv = g.pivot(index="dia_semana_nome", columns="hora", values="n").reindex(ordem).fillna(0)
    fig = px.imshow(piv, aspect="auto", color_continuous_scale=["#0b1220", "#155e75", ACCENT, WARN],
                    labels=dict(x="hora do dia", y="", color="e-mails"))
    fig.update_layout(coloraxis_colorbar=dict(thickness=10, len=0.7))
    fig.update_xaxes(dtick=2)
    return fig


@app.callback(Output("g-classif", "figure"), *_filtro_inputs())
def _classif(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    g = df["classification"].fillna("(não classificado)").value_counts().reset_index()
    g.columns = ["classification", "n"]
    fig = px.pie(g, names="classification", values="n", hole=0.55,
                 color="classification",
                 color_discrete_map={"IMPORTANTE": OK, "AVALIAR": WARN, "PENDENTE": ACCENT2,
                                     "LIXO": BAD, "(não classificado)": "#475569"})
    fig.update_traces(textinfo="label+percent", textposition="outside")
    fig.update_layout(showlegend=False)
    return fig


@app.callback(Output("g-categoria", "figure"), *_filtro_inputs())
def _categoria(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    g = df["categoria_alto_nivel"].fillna("(não inferido)").value_counts().head(12).reset_index()
    g.columns = ["categoria", "n"]
    fig = px.bar(g.sort_values("n"), x="n", y="categoria", orientation="h", text="n",
                 labels={"n": "e-mails", "categoria": ""})
    fig.update_traces(textposition="outside", marker_color=ACCENT2)
    fig.update_layout(margin=dict(l=10, r=40, t=20, b=30))
    return fig


# ----------------------------------------------------------------------------
# 3) Quem me escreve
# ----------------------------------------------------------------------------
@app.callback(Output("g-pareto", "figure"), *_filtro_inputs())
def _pareto(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    g = (df.groupby("remetente_principal").size().sort_values(ascending=False)
         .head(25).reset_index(name="n"))
    g["curto"] = g["remetente_principal"].str.slice(0, 34)
    tot = len(df)
    g["acum"] = 100.0 * g["n"].cumsum() / tot
    fig = go.Figure()
    fig.add_bar(x=g["curto"], y=g["n"], name="e-mails", marker_color=ACCENT,
                hovertemplate="%{x}<br>%{y} e-mails<extra></extra>")
    fig.add_scatter(x=g["curto"], y=g["acum"], name="% acumulado", yaxis="y2", mode="lines+markers",
                    line=dict(color=WARN, width=2), marker=dict(size=5),
                    hovertemplate="%{y:.1f}% acumulado<extra></extra>")
    fig.update_layout(
        yaxis=dict(title="e-mails"),
        yaxis2=dict(title="% acumulado", overlaying="y", side="right", showgrid=False, range=[0, 105]),
        xaxis=dict(tickangle=-55, tickfont=dict(size=10)),
        bargap=0.35, margin=dict(b=140),
    )
    return fig


@app.callback(Output("g-dominio", "figure"), *_filtro_inputs())
def _dominio(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return _vazio("sem dados")
    g = df["dominio"].fillna("(sem domínio)").value_counts().head(15).reset_index()
    g.columns = ["dominio", "n"]
    fig = px.bar(g.sort_values("n"), x="n", y="dominio", orientation="h", text="n",
                 labels={"n": "e-mails", "dominio": ""})
    fig.update_traces(textposition="outside", marker_color=ACCENT)
    fig.update_layout(margin=dict(l=10, r=45, t=20, b=30), yaxis=dict(tickfont=dict(size=10)))
    return fig


@app.callback(Output("g-dest", "figure"), *_filtro_inputs())
def _dest(periodo, direcao, classif, busca):
    df = dl.get("destinatarios")
    fato = dl.get("fato")
    # filtra destinatarios pelo periodo (se possivel) e pela busca
    if periodo and periodo != "tudo":
        ref = _ref_date(fato)
        if periodo.startswith("ano:"):
            df = df[df["ultima"].dt.year == int(periodo.split(":")[1])]
        else:
            df = df[df["ultima"] >= ref - pd.Timedelta(days=int(periodo.rstrip("d")))]
    if busca:
        b = busca.strip().lower()
        df = df[df["destinatario"].fillna("").str.lower().str.contains(b, regex=False)]
    if not len(df):
        return _vazio("sem dados")
    g = df.head(15).sort_values("emails_enviados")
    fig = px.bar(g, x="emails_enviados", y="destinatario", orientation="h", text="emails_enviados",
                 labels={"emails_enviados": "e-mails enviados", "destinatario": ""})
    fig.update_traces(textposition="outside", marker_color=ACCENT2)
    fig.update_layout(margin=dict(l=10, r=45, t=20, b=30), yaxis=dict(tickfont=dict(size=10)))
    return fig


@app.callback(Output("t-remetentes", "data"), *_filtro_inputs())
def _t_rem(periodo, direcao, classif, busca):
    df = _aplicar(dl.get("fato"), periodo, direcao, classif, busca)
    if not len(df):
        return []
    g = df.groupby("remetente_principal").agg(
        total=("id", "count"),
        **{"não lidos": ("readed", lambda s: int((~s).sum()))},
        importante=("classification", lambda s: int((s == "IMPORTANTE").sum())),
        lixo=("classification", lambda s: int((s == "LIXO").sum())),
    ).reset_index()
    g["% lido"] = (100.0 * (g["total"] - g["não lidos"]) / g["total"]).round(1)
    g["% lixo"] = (100.0 * g["lixo"] / g["total"]).round(1)
    ult = df.groupby("remetente_principal")["data"].max().reset_index(name="último")
    g = g.merge(ult, on="remetente_principal")
    g = g.rename(columns={"remetente_principal": "remetente"})[
        ["remetente", "total", "não lidos", "% lido", "importante", "% lixo", "último"]]
    return _registros(g.sort_values("total", ascending=False).head(400))


# ----------------------------------------------------------------------------
# 4) Pendências
# ----------------------------------------------------------------------------
@app.callback(Output("g-aging", "figure"),
              Input("btn-refresh", "n_clicks"))
def _aging(_n):
    df = dl.get("nao_lidos_aging") if "nao_lidos_aging" in dl.VIEWS else None
    if df is None:
        # derivado do proprio fato (nota: respeita "tudo", e um retrato da base)
        fato = dl.get("fato")
        nl = fato[~fato["readed"]].copy()
        ref = _ref_date(fato)
        bins = [0, 1, 7, 30, 90, 10**6]
        labs = ["até 1 dia", "2-7 dias", "8-30 dias", "31-90 dias", "90+ dias"]
        nl["idade"] = (ref - nl["data"]).dt.days
        nl["faixa"] = pd.cut(nl["idade"], bins=bins, labels=labs, right=True)
        g = nl.groupby("faixa", observed=False).agg(nao_lidos=("id", "count"),
                                                    importante=("classification", lambda s: int((s == "IMPORTANTE").sum()))
                                                    ).reset_index()
        g.columns = ["faixa", "nao_lidos", "importante"]
    else:
        g = df.rename(columns={"faixa_idade": "faixa", "importante": "importante"})
    fig = go.Figure()
    fig.add_bar(x=g["faixa"], y=g["nao_lidos"], name="não lidos", marker_color=WARN,
                text=g["nao_lidos"], textposition="outside")
    fig.add_bar(x=g["faixa"], y=g["importante"], name="importantes", marker_color=OK,
                text=g["importante"], textposition="outside")
    fig.update_layout(barmode="group", yaxis_title="e-mails", xaxis_title="",
                      margin=dict(t=30), yaxis=dict(type="log"))
    return fig


@app.callback(Output("g-abertas", "figure"), Input("btn-refresh", "n_clicks"))
def _abertas(_n):
    conv = dl.get("conversas")
    g = conv.groupby("aguardando").agg(conversas=("thread_id", "count"),
                                       media_dias=("dias_parado", "mean")).reset_index()
    g["lado"] = g["aguardando"].map({"VOCE": "🤚 você deve resposta", "OUTRO": "📤 esperando deles"})
    fig = px.bar(g, x="lado", y="conversas", text="conversas", color="lado",
                 color_discrete_map={"🤚 você deve resposta": BAD, "📤 esperando deles": "#60a5fa"})
    fig.update_traces(textposition="outside")
    for _, r in g.iterrows():
        fig.add_annotation(x=r["lado"], y=r["conversas"], text=f"{r['media_dias']:.0f} dias (média)",
                           showarrow=False, yshift=22, font=dict(size=10, color="#94a3b8"))
    fig.update_layout(showlegend=False, yaxis_title="conversas", xaxis_title="", margin=dict(t=30))
    return fig


@app.callback(Output("t-conversas", "data"),
              Input("btn-refresh", "n_clicks"), Input("f-aguardando", "value"),
              Input("f-busca", "value"))
def _t_conv(_n, aguardando, busca):
    conv = dl.get("conversas")
    df = conv[conv["aguardando"] == aguardando].copy()
    if busca:
        b = busca.strip().lower()
        df = df[df["assunto_principal"].fillna("").str.lower().str.contains(b, regex=False)
                | df["remetente_principal"].fillna("").str.lower().str.contains(b, regex=False)]
    df["assunto"] = df["assunto_principal"].fillna("(sem assunto)").str.slice(0, 90)
    df["remetente"] = df["remetente_principal"].fillna("(?)").str.slice(0, 42)
    df["dias parado"] = df["dias_parado"]
    df["urgência"] = df["urgencia"].fillna("—")
    df["classificação"] = df["classification"].fillna("—")
    df["msg"] = df["n_mensagens"]
    df["última"] = df["ultima_data"]
    cols = ["assunto", "remetente", "dias parado", "urgência", "classificação", "msg", "última"]
    return _registros(df.sort_values(["dias parado"], ascending=False)[cols].head(500))


# ----------------------------------------------------------------------------
# 5) Minha resposta
# ----------------------------------------------------------------------------
@app.callback(Output("g-sla", "figure"), Input("btn-refresh", "n_clicks"))
def _sla(_n):
    sla = dl.get("sla").sort_values("ano_mes")
    sla = sla[sla["respostas"] >= 1]
    if not len(sla):
        return _vazio("sem dados de resposta")
    fig = go.Figure()
    fig.add_scatter(x=sla["ano_mes"], y=sla["mediana_horas"], mode="lines+markers",
                    name="mediana (h)", line=dict(color=ACCENT, width=2.2), marker=dict(size=6))
    fig.add_scatter(x=sla["ano_mes"], y=sla["media_horas"], mode="lines", name="média (h)",
                    line=dict(color=WARN, width=1.4, dash="dot"))
    fig.update_layout(yaxis=dict(title="horas", type="log"), xaxis=dict(tickangle=-60))
    return fig


@app.callback(Output("g-sla-barras", "figure"), Input("btn-refresh", "n_clicks"))
def _sla_barras(_n):
    tr = dl.get("tempo_resposta")
    h = tr["horas_resposta"].dropna()
    if not len(h):
        return _vazio("sem dados")
    faixas = [("≤ 1 h", (h <= 1).sum()), ("≤ 4 h", (h <= 4).sum()),
              ("≤ 24 h", (h <= 24).sum()), ("≤ 72 h", (h <= 72).sum())]
    g = pd.DataFrame(faixas, columns=["faixa", "n"])
    g["pct"] = (100.0 * g["n"] / len(h)).round(1)
    fig = px.bar(g, x="faixa", y="pct", text=g["pct"].astype(str) + "%",
                 labels={"faixa": "", "pct": "% das respostas"})
    fig.update_traces(marker_color=[OK, ACCENT, WARN, BAD], textposition="outside")
    fig.update_layout(yaxis=dict(range=[0, 108]), margin=dict(t=30))
    return fig


@app.callback(Output("g-hist", "figure"), Input("btn-refresh", "n_clicks"))
def _hist(_n):
    tr = dl.get("tempo_resposta")
    h = tr["horas_resposta"].dropna()
    if not len(h):
        return _vazio("sem dados")
    hc = h[h <= h.quantile(0.98)]
    fig = px.histogram(hc, nbins=48, labels={"value": "horas até responder"},
                       color_discrete_sequence=[ACCENT2])
    fig.update_layout(showlegend=False, yaxis_title="respostas", xaxis_title="horas")
    return fig


@app.callback(Output("t-sla", "data"), Input("btn-refresh", "n_clicks"))
def _t_sla(_n):
    sla = dl.get("sla").sort_values("ano_mes", ascending=False).copy()
    sla = sla.rename(columns={"ano_mes": "ano_mês", "mediana_horas": "mediana (h)"})
    sla["% ≤1h"] = sla["pct_ate_1h"]
    sla["% ≤4h"] = sla["pct_ate_4h"]
    sla["% ≤24h"] = sla["pct_ate_24h"]
    return _registros(sla[["ano_mês", "respostas", "mediana (h)", "% ≤1h", "% ≤4h", "% ≤24h"]].head(200))


# ----------------------------------------------------------------------------
# 6) Pipeline
# ----------------------------------------------------------------------------
@app.callback(Output("g-pipe", "figure"), Input("btn-refresh", "n_clicks"))
def _pipe(_n):
    p = dl.get("pipeline").sort_values("ano_mes")
    if not len(p):
        return _vazio("sem dados")
    fig = go.Figure()
    fig.add_bar(x=p["ano_mes"], y=p["classificados"], name="classificados", marker_color=OK)
    fig.add_bar(x=p["ano_mes"], y=p["pendentes_classificacao"], name="pendentes", marker_color=BAD)
    fig.update_layout(barmode="stack", xaxis=dict(tickangle=-60), yaxis_title="e-mails",
                      margin=dict(t=30))
    return fig


@app.callback(Output("g-pipe-fila", "figure"), Input("btn-refresh", "n_clicks"))
def _pipe_fila(_n):
    p = dl.get("pipeline")
    tot = pd.DataFrame({
        "etapa": ["classificação", "inferência", "embedding"],
        "pendentes": [int(p["pendentes_classificacao"].sum()), int(p["pendentes_inferencia"].sum()),
                      int(p["pendentes_embedding"].sum())],
    })
    fig = px.bar(tot, x="pendentes", y="etapa", orientation="h", text="pendentes",
                 color="etapa", color_discrete_sequence=[ACCENT2, WARN, ACCENT])
    fig.update_traces(textposition="outside")
    fig.update_layout(showlegend=False, xaxis_title="e-mails pendentes", yaxis_title="", margin=dict(t=20))
    return fig


@app.callback(Output("t-pipe", "data"), Input("btn-refresh", "n_clicks"))
def _t_pipe(_n):
    p = dl.get("pipeline").sort_values("ano_mes", ascending=False).rename(columns={
        "ano_mes": "ano_mês", "pendentes_classificacao": "pendentes",
        "pct_classificado": "% classificado", "pct_inferido": "% inferido",
        "pct_embedado": "% embedado"})
    return _registros(p[["ano_mês", "total", "classificados", "pendentes",
                         "% classificado", "% inferido", "% embedado"]].head(200))


# registra as páginas novas (Operações e Config) no app
op_page.callbacks(app)
cfg_page.callbacks(app)


def run_server(host: str = "0.0.0.0", port: int = 8050) -> None:
    """Sobe o servidor do web app (usado por `mymailboard serve`)."""
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    run_server(os.environ.get("MAILBOARD_HOST", "0.0.0.0"),
               int(os.environ.get("MAILBOARD_PORT", "8050")))
