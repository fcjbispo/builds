"""batch.py — estágios LLM em lote (classify/infer/embed) com histórico e progresso.

Portado do `emails_pipeline.py` (fluxo validado), com quatro adições:
  - parâmetros vindos da configuração efetiva (banco > .env > defaults);
  - cada execução é registrada em `claw.mmb_runs` (progresso, heartbeat, contadores);
  - **cancelamento cooperativo**: `claw.mmb_runs.cancel_requested` é checado a cada item;
  - **rastreabilidade** (opção 1+2, 2026-10-13): cada item processado grava o `run_id` da
    execução que o processou (`classify_run_id` / `infer_run_id`) — modelo e data do
    processamento saem do JOIN com `claw.mmb_runs`. Correção: o `infer` **não** mexe mais
    em `classificada_por`/`data_classificacao` (antes sobrescrevia o carimbo do classify).
"""
from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..db import DB, config_store, runs
from . import ui
from .llm import Llm
from .prompts import (PROMPT_CLASS, PROMPT_INFER, VOC_ACAO, VOC_CAT, VOC_URG, ascii_l,
                      extract_text_from_llm, norm_acao, norm_cat, norm_urg, parse_json,
                      scrub, vec_param)

MODES = ("classify", "infer", "embed")

# critérios do classify como criteria do choice tipado (ticket 193): 3 CLASSES.
# PENDENTE NÃO é classe: é só estado de fila (fallback/erro) — senão o modelo
# devolve "demais" e o item re-loopa na fila para sempre.
CLASS_CRITERIA = {
    "IMPORTANTE": "exige ação/pagamento/prazo pessoal/profissional",
    "LIXO": "spam/promoção fria",
    "AVALIAR": "relevante, precisa de decisão",
}
URG_CRITERIA = {
    "baixa": "não pede nada em prazo próximo — leitura/arquivo",
    "media": "acompanhar em dias (prazo difuso)",
    "alta": "prazo ou pagamento crítico agora",
}
ACAO_CRITERIA = {
    "Leitura apenas": "informativo — só ler",
    "Nenhuma": "sem ação derivada do conteúdo",
    "Arquivar": "guardar como referência",
    "Responder": "pede resposta minha",
    "Acompanhar": "monitorar até resolução",
    "Pagamento": "envolve pagar/boleto/parcela",
}

COND = {
    "infer": "urgencia IS NULL",
    "classify": "(classification IS NULL OR classification='' OR classification='PENDENTE')",
    "embed": "email_embedding IS NULL",
}


def _where(mode: str) -> str:
    return f"date_received >= %s::timestamp AND date_received < %s::timestamp AND {COND[mode]}"


def fetch_lote(mode: str, win: tuple[str, str], limit: int) -> list[dict]:
    """Busca o próximo lote da fila (mais recentes primeiro)."""
    if mode == "embed":
        sql = f"""SELECT id, coalesce(subject,''), coalesce(resumo,''), coalesce(left(body_plain,6000),'')
                  FROM claw.emails WHERE {_where(mode)} ORDER BY id DESC LIMIT %s"""
        keep = ("subj", "resumo", "body")
    else:
        sql = f"""SELECT id, subject, from_address, date_received::date, coalesce(left(body_plain,2200),'')
                  FROM claw.emails WHERE {_where(mode)} ORDER BY date_received DESC, id DESC LIMIT %s"""
        keep = ("subj", "to", "dr", "body")
    with DB() as db:
        rows = db.select(sql, (win[0], win[1], limit))
    out = []
    for r in rows:
        rec = {"id": r[0]}
        rec.update(dict(zip(keep, r[1:])))
        out.append(rec)
    return out


def count_pendentes(mode: str, win: tuple[str, str]) -> int | None:
    """Tamanho restante da fila deste modo/janela (checkpoint no banco)."""
    try:
        with DB() as db:
            r = db.select(f"SELECT count(*) FROM claw.emails WHERE {_where(mode)}", (win[0], win[1]))
        return r[0][0] if r else None
    except Exception:
        return None


# ── estágios ────────────────────────────────────────────────────────────────
def work_infer(rec: dict, db, llm: Llm, cfg: dict, run_id: int | None = None) -> str:
    prompt = PROMPT_INFER.format(vocab=" | ".join(VOC_CAT),
                                 to=rec.get("to") or "(desconhecido)", dt=rec.get("dr") or "",
                                 subj=scrub(rec.get("subj"), 300) or "",
                                 body=scrub(rec.get("body"), int(cfg.get("engine.body_chars_infer", 2200))) or "")
    j, err = llm.json_chat(llm.model("infer"), prompt)
    if not isinstance(j, dict):
        ui.warn(f"fallback id={rec['id']}: {type(err).__name__ if err else 'sem-JSON'}: {str(err)[:140] if err else ''}")
        # NÃO grava classificada_por/data_classificacao: esse carimbo pertence ao classify.
        db.execute("""UPDATE claw.emails SET urgencia='baixa', acao_necessaria='Nenhuma',
                      categoria_alto_nivel='Outros',
                      resumo=%s, summary_embedding=%s::vector,
                      embedding_status='fallback', infer_run_id=%s WHERE id=%s""",
                   ("(falha sem JSON em 2 tentativas) " + (scrub(err, 170) or ""),
                    vec_param(llm.embed("(sem resumo)" + (scrub(err, 60) or ""))), run_id, rec["id"]))
        return "fallback"
    g = lambda k: extract_text_from_llm(j, k)  # noqa: E731
    urg, acao = norm_urg(g("urgencia")), norm_acao(g("acao_necessaria"))
    urg_p = acao_p = None
    if llm.decision_on():
        # closed-sets do infer sob decisão tipada (v0.2.0, ticket #192):
        # urgência/ação decididos por choice com probabilidade; resumo/keywords
        # continuam generativos. Falha aqui NÃO derruba o item (mantém o generativo).
        try:
            st = _state(rec, cfg)
            st["resumo"] = scrub(g("resumo"), 400) or ""
            resp = llm.decision(st,
                                {"urgencia": {"type": "choice",
                                              "instructions": "Nível de urgência para tratar este e-mail.",
                                              "criteria": URG_CRITERIA},
                                 "acao": {"type": "choice",
                                          "instructions": "AÇÃO necessária que o e-mail exige — a principal.",
                                          "criteria": ACAO_CRITERIA}})
            ans = resp.get("answers") or {}
            a_u, a_a = ans.get("urgencia") or {}, ans.get("acao") or {}
            if a_u.get("choice") in VOC_URG:
                urg = a_u["choice"]
                p = (a_u.get("probabilities") or {}).get(urg)
                urg_p = None if p is None else float(p)
            if a_a.get("choice") in VOC_ACAO:
                acao = a_a["choice"]
                p = (a_a.get("probabilities") or {}).get(acao)
                acao_p = None if p is None else float(p)
        except Exception as e:  # noqa: BLE001
            ui.warn(f"decision id={rec['id']}: {type(e).__name__}: {str(e)[:120]} — mantendo generativo")
    db.execute("""UPDATE claw.emails SET resumo=%s, urgencia=%s, acao_necessaria=%s,
                  urgencia_prob=%s, acao_prob=%s,
                  categoria_alto_nivel=%s, palavras_chave=%s, remetente_principal=%s,
                  assunto_principal=%s, infer_run_id=%s,
                  summary_embedding=%s::vector, embedding_status='ok' WHERE id=%s""",
               (scrub(g("resumo"), 2000), urg, acao, urg_p, acao_p,
                norm_cat(g("categoria_alto_nivel")), scrub(g("palavras_chave"), 200),
                scrub(g("remetente_principal"), 200), scrub(g("assunto_principal"), 300),
                run_id,
                vec_param(llm.embed(scrub(g("resumo"), 4000) or scrub(rec.get("subj"), 120) or "(sem resumo)")),
                rec["id"]))
    return "ok"


def _state(rec: dict, cfg: dict) -> dict:
    """Contexto do e-mail como `state` do System One (mesmo material do prompt).

    Tudo como string: o pg8000 devolve `date`/`datetime` crus e o payload é JSON.
    """
    return {"assunto": scrub(rec.get("subj"), 300) or "",
            "remetente": rec.get("to") or "(desconhecido)",
            "data": str(rec.get("dr") or ""),
            "corpo": scrub(rec.get("body"), int(cfg.get("engine.body_chars_infer", 2200))) or ""}


def work_classify(rec: dict, db, llm: Llm, cfg: dict, run_id: int | None = None) -> str:
    """Classificação do e-mail.

    Com `llm.decision.model` configurado (v0.2.0, ticket #192), a **decisão tipada é
    primária**: choice com probabilidades no System One e a probabilidade do rótulo
    escolhido vai para `emails.classify_prob`. O LLM generativo fica de FALLBACK
    (erro/choice fora do vocabulário) e é o caminho quando a decisão está OFF.
    """
    if llm.decision_on():
        try:
            resp = llm.decision(_state(rec, cfg),
                               {"triagem": {"type": "choice",
                                            "instructions": "Classifique o e-mail na triagem da caixa de entrada escolhendo UMA opção.",
                                            "criteria": CLASS_CRITERIA}})
            a = (resp.get("answers") or {}).get("triagem") or {}
            val = a.get("choice")
            if val in CLASS_CRITERIA:
                p = (a.get("probabilities") or {}).get(val)
                db.execute("""UPDATE claw.emails SET classification=%s, classificada_por=%s,
                              data_classificacao=now(), classify_run_id=%s, classify_prob=%s
                              WHERE id=%s""",
                           (val, llm.decision_model(), run_id,
                            None if p is None else float(p), rec["id"]))
                return "ok"
            ui.warn(f"decision id={rec['id']}: choice fora do vocabulário ({val!r}) — seguindo generativo")
        except Exception as e:  # noqa: BLE001
            ui.warn(f"decision id={rec['id']}: {type(e).__name__}: {str(e)[:120]} — seguindo generativo")
    prompt = PROMPT_CLASS.format(to=rec.get("to") or "(desconhecido)", dt=rec.get("dr") or "",
                                 subj=scrub(rec.get("subj"), 300) or "",
                                 body=scrub(rec.get("body"), int(cfg.get("engine.body_chars_infer", 2200))) or "")
    j, err = llm.json_chat(llm.model("classify"), prompt)
    if not isinstance(j, dict):
        ui.warn(f"fallback id={rec['id']}: {type(err).__name__ if err else 'sem-JSON'}: {str(err)[:140] if err else ''}")
        db.execute("""UPDATE claw.emails SET classificada_por='fallback',
                      classification='PENDENTE', data_classificacao=now(),
                      classify_run_id=%s WHERE id=%s""", (run_id, rec["id"]))
        return "fallback"
    vals = [v for k, v in j.items() if "class" in str(k).lower()]
    c = ascii_l(vals[0] if vals else "")
    val = ("IMPORTANTE" if c.startswith("im") else "LIXO" if c.startswith("li")
           else "AVALIAR" if c.startswith("av") else "PENDENTE")
    db.execute("""UPDATE claw.emails SET classification=%s, classificada_por=%s,
                  data_classificacao=now(), classify_run_id=%s WHERE id=%s""",
               (val, llm.model("classify"), run_id, rec["id"]))
    return "ok"


def work_embed(rec: dict, db, llm: Llm, cfg: dict, run_id: int | None = None) -> str:
    """Gera os 3 embeddings (email/resumo/corpo) com o modelo configurado.

    `run_id` é aceito por uniformidade com as outras etapas: o embed já se identifica
    pelo par `embedding_model`/`embedding_version`, então não há coluna de vínculo.
    """
    base = ((rec.get("subj") or "")[:150] + ". " + (scrub(rec.get("resumo"), 400) or "(sem resumo)")).strip()
    e_msg = llm.embed(base or "(sem)")
    e_sum = llm.embed(scrub(rec.get("resumo"), 4000) or "(sem resumo)")
    e_body = llm.embed(scrub(rec.get("body"), int(cfg.get("engine.body_chars_embed", 6000))) or "(vazio)")
    db.execute("""UPDATE claw.emails SET
                  email_embedding=%s::vector, summary_embedding=%s::vector, body_embedding=%s::vector,
                  embedding_model=%s, embedding_version=COALESCE(embedding_version, 0) + 1,
                  embedding_status='ok' WHERE id=%s""",
               (vec_param(e_msg), vec_param(e_sum), vec_param(e_body), llm.model("embed"), rec["id"]))
    return "ok"


# ── runner ───────────────────────────────────────────────────────────────────
def run_batch(recs: list[dict], mode: str, apply: bool, win: tuple[str, str],
              run_id: int | None = None, cfg: dict | None = None) -> dict:
    cfg = cfg or config_store.effective()
    llm = Llm(cfg)
    threads = max(1, int(cfg.get("engine.threads", 4) or 4))
    st = {"ok": 0, "fallback": 0, "dry": 0, "errors": 0, "cancelled": False}
    t0 = time.time()
    total = len(recs)
    fn = {"infer": work_infer, "classify": work_classify, "embed": work_embed}[mode]
    bar = ui.Bar(total, label=f"{mode} ")
    last_push = [0.0]

    def check_cancel() -> bool:
        return bool(run_id) and runs.cancel_requested(run_id)

    def push(force: bool = False) -> None:
        now = time.time()
        if run_id and (force or now - last_push[0] > 3):
            last_push[0] = now
            done = st["ok"] + st["fallback"] + st["dry"] + st["errors"]
            runs.progress(run_id, done, st["ok"], st["fallback"], st["errors"])
            ui.emit({"mode": mode, "processed": done, "total": total, **st})

    def one(rec):
        if st["cancelled"]:
            return
        if not apply:
            st["dry"] += 1
        else:
            try:
                with DB() as db:
                    r = fn(rec, db, llm, cfg, run_id)
                st[r] += 1
            except Exception as e:  # noqa: BLE001
                st["errors"] += 1
                st["fallback"] += 0
                ui.warn(f"ERR id={rec['id']}: {type(e).__name__}: {str(e)[:120]}")
        bar.update(extra=f'ok={st["ok"]} fb={st["fallback"]}')

    with ThreadPoolExecutor(threads) as ex:
        futs = [ex.submit(one, r) for r in recs]
        for i, f in enumerate(as_completed(futs), 1):
            f.result()
            if i % 5 == 0:
                push()
                if check_cancel():
                    st["cancelled"] = True
                    ui.warn("cancelamento solicitado — parando após o lote em voo")
                    for x in futs[i:]:
                        x.cancel()
                    break
    bar.done()
    push(force=True)
    restante = count_pendentes(mode, win) if apply else None
    summary(mode, st, t0, win, restante)
    return st


def summary(mode: str, st: dict, t0: float, win: tuple[str, str], restante: int | None = None) -> None:
    """Resumo final da operação de lote (suprimido por --quiet)."""
    if ui.QUIET:
        return
    el = max(time.time() - t0, 0.001)
    print("─" * 68)
    print(f"RESUMO — modo {mode} | janela {win[0]} → {win[1]}")
    print(f"  ✓ sucesso          : {st['ok']}")
    if st.get("fallback"):
        print(f"  ! fallback         : {st['fallback']}")
    if st.get("errors"):
        print(f"  ✗ erros            : {st['errors']}")
    if st.get("dry"):
        print(f"  · simulação        : {st['dry']} (dry-run — NADA foi gravado)")
    if st.get("cancelled"):
        print("  ⏹ cancelado        : interrompido a pedido")
    print(f"  tempo              : {el:.0f}s  ({st['ok'] / el:.1f} registros/s)")
    if restante is not None:
        print(f"  fila restante      : {restante} registro(s) neste modo/janela")
        if restante == 0 and (st["ok"] or st["dry"]):
            print("  ✓ fila deste modo/janela concluída")
    print("─" * 68)


def info(cfg: dict | None = None) -> dict:
    """Fila atual por etapa (para o painel Operações / CLI status)."""
    cfg = cfg or config_store.effective()
    win = ("2014-01-01", cfg.get("engine.window_end", "2026-09-30"))
    out = {}
    with DB() as db:
        for m in MODES:
            try:
                r = db.select(f"SELECT count(*) FROM claw.emails WHERE {_where(m)}", (win[0], win[1]))
                out[m] = r[0][0] if r else None
            except Exception:
                out[m] = None
        r = db.select("""SELECT count(*), count(*) FILTER (WHERE urgencia IS NOT NULL),
                                count(*) FILTER (WHERE classification IS NOT NULL AND classification<>'PENDENTE')
                         FROM claw.emails""")
        out["total"], out["inferidos"], out["classificados"] = (r[0] if r else (None, None, None))
    return out


def dumps(o) -> str:
    return json.dumps(o, ensure_ascii=False, default=str)
