-- 003_decision_tipada.sql — MyMailBoard
--
-- Decisão tipada (System One) — v0.2.0, ticket MyBacklog #192.
-- Registra por item a PROBABILIDADE do rótulo/nível escolhido pelo modelo de
-- decisão (config `llm.decision.model`, ex.: nimble via /v1/systemone):
--   classify_prob : probabilidade do rótulo de triagem (classify)
--   urgencia_prob : probabilidade do nível de urgência (infer)
--   acao_prob     : probabilidade da ação necessária (infer)
-- Nulo = item decidido pelo caminho generativo (ou decisão desligada).
-- Idempotente: pode rodar repetidas vezes (aplicada por `operation migrate`).

ALTER TABLE claw.emails ADD COLUMN IF NOT EXISTS classify_prob real;
ALTER TABLE claw.emails ADD COLUMN IF NOT EXISTS urgencia_prob real;
ALTER TABLE claw.emails ADD COLUMN IF NOT EXISTS acao_prob real;

COMMENT ON COLUMN claw.emails.classify_prob IS
 'MyMailBoard: probabilidade (System One) do rótulo de triagem Escolhido pelo modelo de decisão; nulo = decisão generativa ou recurso desligado.';
COMMENT ON COLUMN claw.emails.urgencia_prob IS
 'MyMailBoard: probabilidade (System One) do nível de urgência escolhido no infer; nulo = decisão generativa ou recurso desligado.';
COMMENT ON COLUMN claw.emails.acao_prob IS
 'MyMailBoard: probabilidade (System One) da ação necessária escolhida no infer; nulo = decisão generativa ou recurso desligado.';