"""MyMailBoard — motor de sincronização de e-mail (CLI + web app) do FBNet."""

__version__ = "0.2.0"
__all__ = ["__version__"]
