"""
MyCodebase MCP Server - Model Context Protocol implementation for codebase search and analysis.

This module exposes MyCodebase tools to LLMs and agents via the MCP protocol.
"""

__version__ = "0.1.0"
__author__ = "Freya <freya@openclaw.local>"

from mycodebase.mcp.server import mcp_app
from mycodebase.mcp.tools import search, info, rebuild, status

# Backward-compatible alias
app = mcp_app

__all__ = ["mcp_app", "app", "search", "info", "rebuild", "status"]
