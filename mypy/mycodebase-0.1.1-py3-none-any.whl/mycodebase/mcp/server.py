"""
MyCodebase MCP Server - Main entry point.

Exposes MyCodebase tools to LLMs and agents via the Model Context Protocol (MCP).
"""

from fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

# Create MCP server instance
mcp_app = FastMCP(
    name="MyCodebase MCP Server",
    instructions="Search and analyze codebases. Provides tools for fulltext/semantic search, file/symbol info, index rebuild, and health checks."
)


@mcp_app.custom_route("/health", methods=["GET"])
async def health_check(request: Request) -> JSONResponse:
    """Health check endpoint for Docker/container orchestration."""
    return JSONResponse({"status": "ok"})


# Register tools — import lazily inside each handler to avoid circular deps
@mcp_app.tool
async def search(
    query: str,
    mode: str = "hybrid",
    limit: int = 10,
    threshold: float = 0.7
) -> dict:
    """
    Search the codebase for files, symbols, or code snippets.

    Args:
        query: Search query string
        mode: Search mode - fulltext, semantic, or hybrid
        limit: Maximum number of results (default: 10)
        threshold: Minimum relevance threshold 0.0-1.0 (default: 0.7)

    Returns:
        Search results with matches and metadata
    """
    from mycodebase.mcp.tools import search as _search_impl
    return await _search_impl(query, mode, limit, threshold)


@mcp_app.tool
async def info(target: str) -> dict:
    """
    Get detailed information about a file or symbol in the codebase.

    Args:
        target: File path or symbol name to query

    Returns:
        Information about the target including location, type, and references
    """
    from mycodebase.mcp.tools import info as _info_impl
    return await _info_impl(target)


@mcp_app.tool
async def rebuild(
    project_name: str | None = None,
    force: bool = False,
    verbose: bool = False
) -> dict:
    """
    Trigger a rebuild of the codebase index.

    Args:
        project_name: Project name to rebuild (optional)
        force: Force full rebuild (default: False)
        verbose: Enable verbose output (default: False)

    Returns:
        Rebuild status and statistics
    """
    from mycodebase.mcp.tools import rebuild as _rebuild_impl
    return await _rebuild_impl(project_name, force, verbose)


@mcp_app.tool
async def status() -> dict:
    """
    Check the health status of MyCodebase databases and services.

    Returns:
        Health status of PostgreSQL, Neo4j, and API services
    """
    from mycodebase.mcp.tools import status as _status_impl
    return await _status_impl()


def main():
    mcp_app.run(
        transport="http",
        host="0.0.0.0",
        port=8080
    )


if __name__ == "__main__":
    main()
