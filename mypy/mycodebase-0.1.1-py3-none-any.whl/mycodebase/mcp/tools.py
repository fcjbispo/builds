"""
MyCodebase MCP Tools - Tool definitions for the MCP server.

Each tool calls the MyCodebase REST API.
"""

import httpx
from typing import Optional, Literal
from mycodebase.core.config import config


def _api_base_url() -> str:
    """Get API base URL from config."""
    return f"{config.api_url}/api/v1"


def _handle_api_error(exc: Exception, operation: str) -> dict:
    """Convert API/HTTP exceptions into MCP-friendly error responses."""
    if isinstance(exc, httpx.ConnectError):
        return {
            "error": True,
            "message": f"Cannot connect to MyCodebase API for {operation}. Is the API server running?",
            "details": str(exc),
        }
    if isinstance(exc, httpx.TimeoutException):
        return {
            "error": True,
            "message": f"Request to MyCodebase API timed out during {operation}.",
            "details": str(exc),
        }
    if isinstance(exc, httpx.HTTPStatusError):
        return {
            "error": True,
            "message": f"MyCodebase API returned an error for {operation}.",
            "status_code": exc.response.status_code,
            "details": exc.response.text[:500],
        }
    return {
        "error": True,
        "message": f"Unexpected error during {operation}.",
        "details": str(exc),
    }


async def search(
    query: str,
    mode: Literal["fulltext", "semantic", "hybrid"] = "hybrid",
    limit: int = 10,
    threshold: float = 0.7
) -> dict:
    """
    Search the codebase for files, symbols, or code snippets.

    Args:
        query: Search query string
        mode: Search mode - fulltext (text search), semantic (vector search), or hybrid (both)
        limit: Maximum number of results to return (default: 10)
        threshold: Minimum relevance threshold (0.0-1.0, default: 0.7)

    Returns:
        dict: Search results with matches and metadata
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{_api_base_url()}/search",
                json={
                    "query": query,
                    "mode": mode,
                    "limit": limit,
                    "threshold": threshold
                },
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    except Exception as e:
        return _handle_api_error(e, "search")


async def info(target: str) -> dict:
    """
    Get detailed information about a file or symbol in the codebase.

    Args:
        target: File path or symbol name to query

    Returns:
        dict: Information about the target including location, type, and references
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{_api_base_url()}/info",
                params={"target": target},
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    except Exception as e:
        return _handle_api_error(e, "info")


async def rebuild(
    project_name: Optional[str] = None,
    force: bool = False,
    verbose: bool = False
) -> dict:
    """
    Trigger a rebuild of the codebase index.

    Args:
        project_name: Name of the project to rebuild (optional, uses default if not provided)
        force: Force full rebuild even if no changes detected (default: False)
        verbose: Enable verbose output (default: False)

    Returns:
        dict: Rebuild status and statistics
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{_api_base_url()}/rebuild",
                json={
                    "project_name": project_name,
                    "force": force,
                    "verbose": verbose
                },
                timeout=300.0  # Rebuilds can take longer
            )
            response.raise_for_status()
            return response.json()
    except Exception as e:
        return _handle_api_error(e, "rebuild")


async def status() -> dict:
    """
    Check the health status of MyCodebase databases and services.

    Returns:
        dict: Health status of PostgreSQL, Neo4j, and API services
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{_api_base_url()}/status",
                timeout=10.0
            )
            response.raise_for_status()
            return response.json()
    except Exception as e:
        return _handle_api_error(e, "status")
