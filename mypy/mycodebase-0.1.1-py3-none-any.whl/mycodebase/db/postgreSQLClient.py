"""PostgreSQL client with pgvector support"""

import os
import logging
from contextlib import contextmanager
from typing import Optional, List, Dict, Any
import psycopg2
import hashlib


logger = logging.getLogger(__name__)


class PostgreSQLClient:
    """Client for PostgreSQL with pgvector extensions"""
    
    def __init__(self, connection_string: Optional[str] = None):
        from mycodebase.core.config import config  # type: ignore
        self.connection_string = connection_string or config.db_uri
        self._conn = None
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = psycopg2.connect(self.connection_string)
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def initialize_schema(self):
        """
        Create initial schema with tables and indexes.
        
        Note: Requires superuser privileges for extension creation.
        If extensions already exist, this will proceed with table creation.
        """
        
        # Try to create extensions (may fail without superuser)
        extensions_sql = """
        CREATE EXTENSION IF NOT EXISTS vector;
        CREATE EXTENSION IF NOT EXISTS pg_trgm;
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(extensions_sql)
                    logger.info("Extensions created/verified")
                except Exception as e:
                    logger.warning(f"Extension creation skipped (may already exist or lack privileges): {e}")
        
        create_tables_sql = """
        -- Files table
        CREATE TABLE IF NOT EXISTS files (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            path TEXT NOT NULL UNIQUE,
            project_name TEXT NOT NULL,
            language TEXT NOT NULL,
            hash BYTEA NOT NULL,
            size_bytes INTEGER NOT NULL,
            line_count INTEGER NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW(),
            indexed_at TIMESTAMPTZ DEFAULT NOW(),
            git_blame JSONB,
            metadata JSONB
        );
        
        -- Symbols table
        CREATE TABLE IF NOT EXISTS symbols (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            file_id UUID REFERENCES files(id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            signature TEXT,
            docstring TEXT,
            start_line INTEGER,
            end_line INTEGER,
            embedding vector(768),
            ast_json JSONB
        );
        
        -- Dependencies table
        CREATE TABLE IF NOT EXISTS dependencies (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            source_file_id UUID REFERENCES files(id) ON DELETE CASCADE,
            target_module TEXT NOT NULL,
            target_symbol TEXT,
            import_type TEXT,
            line_number INTEGER
        );
        
        -- Indexes
        CREATE INDEX IF NOT EXISTS idx_files_project ON files (project_name);
        CREATE INDEX IF NOT EXISTS idx_files_language ON files (language);
        CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols (name);
        
        -- Full-text search index (GIN with trigram)
        CREATE INDEX IF NOT EXISTS idx_symbols_search ON symbols 
        USING GIN ((name || ' ' || COALESCE(docstring, '')) gin_trgm_ops);
        
        -- Vector similarity index (HNSW for cosine similarity)
        CREATE INDEX IF NOT EXISTS idx_symbols_embedding ON symbols 
        USING hnsw (embedding vector_cosine_ops);
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(create_tables_sql)
    
    def insert_file(self, path: str, project_name: str, language: str, 
                    content: bytes, metadata: Optional[dict] = None) -> str:
        """
        Insert or update a file record.
        
        Args:
            path: File path
            project_name: Project name
            language: Programming language
            content: File content bytes (used for hash)
            metadata: Optional metadata dict (will be JSON serialized)
            
        Returns:
            File ID in database
        """
        import json
        
        file_hash = hashlib.sha256(content).digest()
        size_bytes = len(content) if content else 0
        line_count = content.count(b'\n') + 1 if content else 0
        
        # Serialize metadata to JSON string for psycopg2
        metadata_json = json.dumps(metadata) if metadata else None
        
        sql = """
        INSERT INTO files (path, project_name, language, hash, size_bytes, line_count, metadata)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (path) DO UPDATE SET
            hash = EXCLUDED.hash,
            size_bytes = EXCLUDED.size_bytes,
            line_count = EXCLUDED.line_count,
            updated_at = NOW(),
            metadata = COALESCE(EXCLUDED.metadata, files.metadata)
        RETURNING id
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (path, project_name, language, file_hash, 
                                  size_bytes, line_count, metadata_json))
                result = cur.fetchone()
                return str(result[0])
    
    def insert_symbol(self, file_id: str, name: str, symbol_type: str,
                      signature: Optional[str] = None, docstring: Optional[str] = None,
                      start_line: Optional[int] = None, end_line: Optional[int] = None,
                      embedding: Optional[list] = None, ast_json: Optional[dict] = None) -> str:
        """Insert a symbol record"""
        
        sql = """
        INSERT INTO symbols (file_id, name, type, signature, docstring, 
                            start_line, end_line, embedding, ast_json)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (file_id, name, symbol_type, signature, 
                                  docstring, start_line, end_line, 
                                  embedding, ast_json))
                result = cur.fetchone()
                return str(result[0])
    
    def insert_dependency(self, source_file_id: str, target_module: str,
                          target_symbol: Optional[str] = None,
                          import_type: Optional[str] = None,
                          line_number: Optional[int] = None) -> str:
        """Insert a dependency record"""
        
        sql = """
        INSERT INTO dependencies (source_file_id, target_module, target_symbol, 
                                  import_type, line_number)
        VALUES (%s, %s, %s, %s, %s)
        RETURNING id
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (source_file_id, target_module, target_symbol,
                                  import_type, line_number))
                result = cur.fetchone()
                return str(result[0])
    
    def delete_symbols_for_file(self, file_id: str):
        """Delete all symbols for a file (for reindexing)"""
        sql = "DELETE FROM symbols WHERE file_id = %s"
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (file_id,))
    
    def delete_file(self, path: str, project_name: str) -> bool:
        """
        Delete a file record and cascade to symbols/dependencies.
        
        Args:
            path: File path
            project_name: Project name
            
        Returns:
            True if file was deleted, False if not found
        """
        sql = """
        DELETE FROM files
        WHERE path = %s AND project_name = %s
        RETURNING id
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (path, project_name))
                result = cur.fetchone()
                return result is not None
    
    def search_fulltext(self, query: str, limit: int = 20) -> list:
        """Full-text search on symbol names and docstrings"""
        sql = """
        SELECT s.name, f.path, s.type, s.signature, s.docstring,
               ts_rank(to_tsvector('english', s.name || ' ' || COALESCE(s.docstring, '')), 
                       plainto_tsquery(%s)) as score
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE to_tsvector('english', s.name || ' ' || COALESCE(s.docstring, '')) @@ plainto_tsquery(%s)
        ORDER BY score DESC
        LIMIT %s
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (query, query, limit))
                columns = [desc[0] for desc in cur.description]
                return [dict(zip(columns, row)) for row in cur.fetchall()]
    
    def health_check(self) -> bool:
        """Check if database is accessible"""
        try:
            with self.get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")
                    return True
        except Exception:
            return False
    
    def search_semantic(
        self,
        query_embedding: List[float],
        limit: int = 20,
        threshold: float = 0.5
    ) -> List[Dict[str, Any]]:
        """
        Semantic search using vector similarity.
        
        Args:
            query_embedding: Query embedding vector
            limit: Maximum results
            threshold: Minimum cosine similarity threshold
            
        Returns:
            List of matching symbols with scores
        """
        embedding_str = '[' + ','.join(map(str, query_embedding)) + ']'
        
        sql = """
        SELECT s.name, f.path, s.type, s.signature, s.docstring,
               s.start_line, s.end_line,
               1 - (s.embedding <=> %s::vector) as similarity_score
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE 1 - (s.embedding <=> %s::vector) >= %s
        ORDER BY similarity_score DESC
        LIMIT %s
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (embedding_str, embedding_str, threshold, limit))
                columns = [desc[0] for desc in cur.description]
                return [dict(zip(columns, row)) for row in cur.fetchall()]
    
    def search_hybrid(
        self,
        query_text: str,
        query_embedding: List[float],
        limit: int = 20,
        text_weight: float = 0.4,
        semantic_weight: float = 0.6
    ) -> List[Dict[str, Any]]:
        """
        Hybrid search combining full-text and semantic search.
        
        Args:
            query_text: Text query for full-text search
            query_embedding: Query embedding vector
            limit: Maximum results
            text_weight: Weight for full-text score (0-1)
            semantic_weight: Weight for semantic score (0-1)
            
        Returns:
            List of matching symbols with combined scores
        """
        embedding_str = '[' + ','.join(map(str, query_embedding)) + ']'
        
        sql = """
        WITH text_search AS (
            SELECT s.id, s.name, f.path, s.type, s.signature, s.docstring,
                   s.start_line, s.end_line,
                   ts_rank(to_tsvector('english', s.name || ' ' || COALESCE(s.docstring, '')), 
                           plainto_tsquery(%s)) as text_score
            FROM symbols s
            JOIN files f ON s.file_id = f.id
            WHERE to_tsvector('english', s.name || ' ' || COALESCE(s.docstring, '')) @@ plainto_tsquery(%s)
        ),
        semantic_search AS (
            SELECT s.id,
                   1 - (s.embedding <=> %s::vector) as semantic_score
            FROM symbols s
            WHERE 1 - (s.embedding <=> %s::vector) >= 0.3
        )
        SELECT 
            ts.name, ts.path, ts.type, ts.signature, ts.docstring,
            ts.start_line, ts.end_line,
            ts.text_score,
            ss.semantic_score,
            (%s * ts.text_score + %s * ss.semantic_score) as combined_score
        FROM text_search ts
        JOIN semantic_search ss ON ts.id = ss.id
        ORDER BY combined_score DESC
        LIMIT %s
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (
                    query_text, query_text,
                    embedding_str, embedding_str,
                    text_weight, semantic_weight,
                    limit
                ))
                columns = [desc[0] for desc in cur.description]
                return [dict(zip(columns, row)) for row in cur.fetchall()]
    
    def update_symbol_embedding(self, symbol_id: str, embedding: List[float]):
        """
        Update embedding for a symbol.
        
        Args:
            symbol_id: Symbol UUID
            embedding: Embedding vector
        """
        embedding_str = '[' + ','.join(map(str, embedding)) + ']'
        
        sql = """
        UPDATE symbols
        SET embedding = %s::vector
        WHERE id = %s
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (embedding_str, symbol_id))
    
    def get_symbols_for_embedding(self, batch_size: int = 100) -> List[Dict[str, Any]]:
        """
        Get symbols that need embeddings (where embedding is NULL).
        
        Args:
            batch_size: Maximum number of symbols to return
            
        Returns:
            List of symbols needing embeddings
        """
        sql = """
        SELECT s.id, s.name, s.signature, s.docstring, f.path
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE s.embedding IS NULL
        LIMIT %s
        """
        
        with self.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (batch_size,))
                columns = [desc[0] for desc in cur.description]
                return [dict(zip(columns, row)) for row in cur.fetchall()]
    
    def is_empty(self, project_name: Optional[str] = None) -> bool:
        """
        Check if the files table is empty (first run detection).

        Args:
            project_name: If provided, check only for this project.
                         If None, check globally.

        Returns:
            True if no files are indexed, False otherwise
        """
        if project_name:
            sql = """
            SELECT COUNT(*) FROM files WHERE project_name = %s
            """
        else:
            sql = """
            SELECT COUNT(*) FROM files
            """

        try:
            with self.get_connection() as conn:
                with conn.cursor() as cur:
                    if project_name:
                        cur.execute(sql, (project_name,))
                    else:
                        cur.execute(sql)
                    result = cur.fetchone()
                    count = result[0] if result else 0
                    return count == 0
        except Exception as e:
            logger.warning(f"Error checking if DB is empty: {e}")
            # Assume empty on error to be safe
            return True
