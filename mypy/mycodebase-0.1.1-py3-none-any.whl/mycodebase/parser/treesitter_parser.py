"""Tree-sitter parser for extracting symbols from source code.

This module provides a wrapper around Tree-sitter for parsing multiple
programming languages and extracting code symbols (functions, classes, etc.)
and dependencies (imports, requires).
"""

import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


logger = logging.getLogger(__name__)


class SymbolType(str, Enum):
    """Types of code symbols"""
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"
    VARIABLE = "variable"
    IMPORT = "import"
    CONSTANT = "constant"


@dataclass
class Symbol:
    """Represents a code symbol (function, class, etc.)"""
    name: str
    type: SymbolType
    file_path: str
    start_line: int
    end_line: int
    signature: Optional[str] = None
    docstring: Optional[str] = None
    ast_json: Optional[Dict] = None


@dataclass
class Dependency:
    """Represents an import/require dependency"""
    target_module: str
    target_symbol: Optional[str]
    import_type: str  # 'import', 'from...import', 'require'
    line_number: int


class TreeSitterParser:
    """Wrapper around Tree-sitter for parsing multiple languages"""
    
    def __init__(self):
        self._languages = {}
        self._parsers = {}
        
        # Available grammars (need to be built)
        self.supported_languages = {
            "python": "tree-sitter-python",
            "typescript": "tree-sitter-typescript",
            "javascript": "tree-sitter-javascript",
            "go": "tree-sitter-go",
            "bash": "tree-sitter-bash",
        }
    
    def _get_language(self, language: str):
        """Get or load a language grammar"""
        if language not in self._languages:
            try:
                # Try to load the grammar
                # Note: In production, these need to be pre-compiled
                grammar_name = self.supported_languages.get(language)
                if grammar_name:
                    module = __import__(grammar_name.replace("-", "_"))
                    from tree_sitter import Language
                    self._languages[language] = Language(module.language())
                else:
                    return None
            except ImportError:
                return None

        return self._languages.get(language)
    
    def _get_parser(self, language: str):
        """Get or create a parser for a language"""
        if language not in self._parsers:
            lang = self._get_language(language)
            if lang:
                from tree_sitter import Parser
                parser = Parser(lang)
                self._parsers[language] = parser
        
        return self._parsers.get(language)
    
    def detect_language(self, file_path: str) -> Optional[str]:
        """Detect programming language from file extension"""
        path = Path(file_path)
        ext_map = {
            ".py": "python",
            ".ts": "typescript",
            ".tsx": "typescript",
            ".js": "javascript",
            ".jsx": "javascript",
            ".go": "go",
            ".sh": "bash",
            ".bash": "bash",
        }
        return ext_map.get(path.suffix.lower())
    
    def parse_file(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Parse a file and extract symbols and dependencies"""
        path = Path(file_path)
        
        if not path.exists():
            return None
        
        language = self.detect_language(str(path))
        if not language:
            return None
        
        parser = self._get_parser(language)
        if not parser:
            # Grammar not available - skip this file
            return {"symbols": [], "dependencies": [], "language": language}
        
        try:
            content = path.read_bytes()
            tree = parser.parse(content)
            
            symbols = self._extract_symbols(tree, language, str(path))
            dependencies = self._extract_dependencies(tree, language, str(path))
            
            return {
                "symbols": symbols,
                "dependencies": dependencies,
                "language": language,
            }
        except Exception as e:
            # Parser failed - log and continue
            logger.warning(f"Parser error for {file_path}: {e}")
            return {"symbols": [], "dependencies": [], "language": language}
    
    def _extract_symbols(self, tree, language: str, file_path: str) -> List[Symbol]:
        """Extract symbols (functions, classes) from AST"""
        symbols = []
        
        if language == "python":
            symbols = self._extract_python_symbols(tree, file_path)
        elif language in ("typescript", "javascript"):
            symbols = self._extract_ts_js_symbols(tree, language, file_path)
        # Add more languages as needed
        
        return symbols
    
    def _extract_python_symbols(self, tree, file_path: str) -> List[Symbol]:
        """Extract Python functions and classes"""
        symbols = []
        root_node = tree.root_node
        
        def traverse(node):
            # Function definition
            if node.type == "function_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = name_node.text.decode()
                    params_node = node.child_by_field_name("parameters")
                    signature = f"def {name}{params_node.text.decode()}" if params_node else f"def {name}()"
                    
                    # Extract docstring if present
                    docstring = self._extract_python_docstring(node)
                    
                    symbols.append(Symbol(
                        name=name,
                        type=SymbolType.FUNCTION,
                        file_path=file_path,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        signature=signature,
                        docstring=docstring
                    ))
            
            # Class definition
            elif node.type == "class_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = name_node.text.decode()
                    
                    symbols.append(Symbol(
                        name=name,
                        type=SymbolType.CLASS,
                        file_path=file_path,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1
                    ))
            
            # Recurse into children
            for child in node.children:
                traverse(child)
        
        traverse(root_node)
        return symbols
    
    def _extract_python_docstring(self, node) -> Optional[str]:
        """Extract docstring from a Python function/class node"""
        body = node.child_by_field_name("body")
        if body and body.children:
            first_child = body.children[0]
            if first_child.type == "expression_statement":
                expr = first_child.child(0)
                if expr and expr.type == "string":
                    return expr.text.decode().strip('"\'')
        return None
    
    def _extract_ts_js_symbols(self, tree, language: str, file_path: str) -> List[Symbol]:
        """Extract TypeScript/JavaScript functions and classes"""
        symbols = []
        root_node = tree.root_node
        
        def traverse(node):
            # Function declaration
            if node.type in ("function_declaration", "arrow_function", "method_definition"):
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = name_node.text.decode()
                    symbols.append(Symbol(
                        name=name,
                        type=SymbolType.FUNCTION,
                        file_path=file_path,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1
                    ))
            
            # Class declaration
            elif node.type == "class_declaration":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = name_node.text.decode()
                    symbols.append(Symbol(
                        name=name,
                        type=SymbolType.CLASS,
                        file_path=file_path,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1
                    ))
            
            for child in node.children:
                traverse(child)
        
        traverse(root_node)
        return symbols
    
    def _extract_dependencies(self, tree, language: str, file_path: str) -> List[Dependency]:
        """Extract import/require dependencies from AST"""
        dependencies = []
        root_node = tree.root_node
        
        if language == "python":
            dependencies = self._extract_python_imports(root_node, file_path)
        elif language in ("typescript", "javascript"):
            dependencies = self._extract_ts_js_imports(root_node, file_path)
        
        return dependencies
    
    def _extract_python_imports(self, root_node, file_path: str) -> List[Dependency]:
        """Extract Python import statements"""
        deps = []
        
        def traverse(node):
            if node.type == "import_statement":
                # import foo.bar
                alias_node = node.child_by_field_name("name")
                if alias_node:
                    module = alias_node.text.decode()
                    deps.append(Dependency(
                        target_module=module,
                        target_symbol=None,
                        import_type="import",
                        line_number=node.start_point[0] + 1
                    ))
            
            elif node.type == "import_from_statement":
                # from foo.bar import baz
                module_node = node.child_by_field_name("module_name")
                if module_node:
                    module = module_node.text.decode()
                    # Get imported names
                    names = []
                    for child in node.children:
                        if child.type == "aliased_import" or child.type == "dotted_name":
                            names.append(child.text.decode())
                    
                    deps.append(Dependency(
                        target_module=module,
                        target_symbol=", ".join(names) if names else None,
                        import_type="from...import",
                        line_number=node.start_point[0] + 1
                    ))
            
            for child in node.children:
                traverse(child)
        
        traverse(root_node)
        return deps
    
    def _extract_ts_js_imports(self, root_node, language: str, file_path: str) -> List[Dependency]:
        """Extract TypeScript/JavaScript import statements"""
        deps = []
        
        def traverse(node):
            if node.type == "import_statement":
                # import X from 'module'
                source_node = node.child_by_field_name("source")
                if source_node:
                    module = source_node.text.decode().strip("'\"")
                    deps.append(Dependency(
                        target_module=module,
                        target_symbol=None,
                        import_type="import",
                        line_number=node.start_point[0] + 1
                    ))
            
            elif node.type == "require_call":
                # const X = require('module')
                arg = node.child_by_field_name("arguments")
                if arg and arg.child_count > 0:
                    module = arg.child(0).text.decode().strip("'\"")
                    deps.append(Dependency(
                        target_module=module,
                        target_symbol=None,
                        import_type="require",
                        line_number=node.start_point[0] + 1
                    ))
            
            for child in node.children:
                traverse(child)
        
        traverse(root_node)
        return deps
