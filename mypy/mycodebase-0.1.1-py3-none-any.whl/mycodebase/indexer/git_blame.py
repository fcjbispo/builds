"""Git blame extraction for codebase files"""

import subprocess
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass


logger = logging.getLogger(__name__)


@dataclass
class BlameLine:
    """Represents a single line's blame information"""
    line_number: int
    commit_hash: str
    author: str
    author_email: str
    author_time: str
    content: str


class GitBlameExtractor:
    """
    Extracts git blame information for files.
    
    Uses `git blame --porcelain` for machine-readable output.
    """
    
    def __init__(self, repo_path: Optional[str] = None):
        """
        Initialize the git blame extractor.
        
        Args:
            repo_path: Path to git repository root (auto-detected if None)
        """
        self.repo_path = Path(repo_path) if repo_path else None
        self._git_root: Optional[Path] = None
    
    def _find_git_root(self, file_path: Path) -> Optional[Path]:
        """
        Find the git repository root for a file.
        
        Args:
            file_path: Path to file
            
        Returns:
            Path to git root or None if not in a repo
        """
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--show-toplevel'],
                cwd=file_path.parent,
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return Path(result.stdout.strip())
        except Exception as e:
            logger.debug(f"Failed to find git root: {e}")
        return None
    
    def _get_relative_path(self, file_path: Path, git_root: Path) -> str:
        """Get path relative to git root"""
        try:
            return str(file_path.relative_to(git_root))
        except ValueError:
            return str(file_path)
    
    def extract_blame(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Extract git blame for a file.
        
        Args:
            file_path: Path to file to blame
            
        Returns:
            Dict with blame information or None if not versioned
        """
        path = Path(file_path)
        
        if not path.exists():
            logger.debug(f"File does not exist: {file_path}")
            return None
        
        # Find git root
        git_root = self._find_git_root(path)
        if not git_root:
            logger.debug(f"Not in a git repository: {file_path}")
            return None
        
        # Get relative path
        rel_path = self._get_relative_path(path, git_root)
        
        try:
            result = subprocess.run(
                ['git', 'blame', '--porcelain', rel_path],
                cwd=git_root,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                # File might not be tracked
                if 'no such path' in result.stderr.lower() or 'not tracked' in result.stderr.lower():
                    logger.debug(f"File not tracked by git: {file_path}")
                    return None
                logger.warning(f"Git blame failed for {file_path}: {result.stderr}")
                return None
            
            return self._parse_porcelain_output(result.stdout, path)
            
        except subprocess.TimeoutExpired:
            logger.warning(f"Git blame timeout for {file_path}")
            return None
        except Exception as e:
            logger.error(f"Git blame error for {file_path}: {e}")
            return None
    
    def _parse_porcelain_output(self, output: str, file_path: Path) -> Dict[str, Any]:
        """
        Parse git blame --porcelain output.
        
        Args:
            output: Raw porcelain output
            file_path: Path to the file
            
        Returns:
            Structured blame information
        """
        lines_info = []
        current_commit = {}
        line_number = 0
        
        for line in output.split('\n'):
            if not line:
                continue
            
            # Commit hash line (starts with hash)
            if len(line) >= 40 and all(c in '0123456789abcdef' for c in line[:40]):
                parts = line.split(' ')
                current_commit = {
                    'commit_hash': parts[0],
                    'line_number': int(parts[2]) if len(parts) > 2 else line_number
                }
                line_number = current_commit['line_number']
            
            # Author info
            elif line.startswith('author '):
                current_commit['author'] = line[7:]
            elif line.startswith('author-mail '):
                current_commit['author_email'] = line[12:].strip('<>')
            elif line.startswith('author-time '):
                current_commit['author_time'] = line[12:]
            elif line.startswith('author-tz '):
                current_commit['author_tz'] = line[10:]
            
            # Content line (starts with tab)
            elif line.startswith('\t'):
                current_commit['content'] = line[1:]
                lines_info.append(current_commit.copy())
                line_number += 1
                current_commit = {}
        
        # Build summary
        if not lines_info:
            return {'file': str(file_path), 'lines': [], 'summary': {}}
        
        authors = {}
        for line_info in lines_info:
            author = line_info.get('author', 'Unknown')
            authors[author] = authors.get(author, 0) + 1
        
        return {
            'file': str(file_path),
            'lines': lines_info,
            'summary': {
                'total_lines': len(lines_info),
                'authors': authors,
                'num_authors': len(authors)
            }
        }
    
    def extract_blame_batch(self, file_paths: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Extract git blame for multiple files.
        
        Args:
            file_paths: List of file paths
            
        Returns:
            Dict mapping file paths to blame info
        """
        results = {}
        for file_path in file_paths:
            blame_info = self.extract_blame(file_path)
            if blame_info:
                results[file_path] = blame_info
        return results
