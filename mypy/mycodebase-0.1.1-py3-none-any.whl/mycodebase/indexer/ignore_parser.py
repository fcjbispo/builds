"""Parser for .codebaseignore files (similar to .gitignore)"""

import fnmatch
import os
import re
from pathlib import Path
from typing import List, Set, Optional


class IgnoreParser:
    """
    Parser for .codebaseignore files.
    
    Supports glob patterns similar to .gitignore:
    - `*.pyc` - matches any .pyc file
    - `build/` - matches build directory
    - `**/logs/` - matches logs directory anywhere
    - `temp/*` - matches anything directly in temp/
    - `!important.log` - negation (don't ignore)
    - `# comment` - comments
    """
    
    def __init__(self, ignore_file_path: Optional[str] = None):
        """
        Initialize the ignore parser.
        
        Args:
            ignore_file_path: Path to .codebaseignore file
        """
        self.ignore_file_path = Path(ignore_file_path) if ignore_file_path else None
        self.patterns: List[tuple] = []  # List of (pattern, is_negation) tuples
        self._load_patterns()
    
    def _load_patterns(self):
        """Load patterns from .codebaseignore file"""
        if not self.ignore_file_path or not self.ignore_file_path.exists():
            return
        
        try:
            content = self.ignore_file_path.read_text()
            for line in content.splitlines():
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                # Check for negation
                is_negation = line.startswith('!')
                if is_negation:
                    line = line[1:]
                
                # Normalize path separators
                line = line.replace('\\', '/')
                
                self.patterns.append((line, is_negation))
        except Exception as e:
            print(f"Warning: Could not load .codebaseignore: {e}")
    
    def _pattern_matches(self, pattern: str, file_path: str, is_directory: bool = False) -> bool:
        """
        Check if a pattern matches a file path.
        
        Args:
            pattern: The glob pattern
            file_path: Relative file path to check
            is_directory: Whether the path is a directory
            
        Returns:
            True if pattern matches
        """
        # Normalize path
        file_path = file_path.replace('\\', '/')
        
        # Directory pattern (ends with /)
        if pattern.endswith('/'):
            pattern = pattern.rstrip('/')
            # Check if any component of the path matches the directory pattern
            path_parts = file_path.split('/')
            for i, part in enumerate(path_parts):
                if fnmatch.fnmatch(part, pattern):
                    # This component matches - if it's a directory match, ignore everything under it
                    return True
            return False
        
        # Pattern with ** (matches any directory depth)
        if '**' in pattern:
            # Convert ** to regex
            regex_pattern = pattern.replace('.', r'\.').replace('**', '.*')
            regex_pattern = regex_pattern.replace('*', '[^/]*')
            regex_pattern = f'^{regex_pattern}$'
            return bool(re.match(regex_pattern, file_path))
        
        # Pattern contains / (matches from root)
        if '/' in pattern:
            return fnmatch.fnmatch(file_path, pattern)
        
        # Pattern without / (matches anywhere in path)
        # Check each component and the filename
        path_parts = file_path.split('/')
        for part in path_parts:
            if fnmatch.fnmatch(part, pattern):
                return True
        
        return False
    
    def should_ignore(self, file_path: str, is_directory: bool = False) -> bool:
        """
        Check if a file or directory should be ignored.
        
        Args:
            file_path: Path to check (relative to project root)
            is_directory: Whether the path is a directory
            
        Returns:
            True if the file should be ignored
        """
        # Normalize to relative path
        file_path = file_path.lstrip('/')
        
        ignored = False
        for pattern, is_negation in self.patterns:
            if self._pattern_matches(pattern, file_path, is_directory):
                ignored = not is_negation
        
        return ignored
    
    def add_pattern(self, pattern: str, is_negation: bool = False):
        """
        Add a pattern programmatically.
        
        Args:
            pattern: Glob pattern
            is_negation: Whether this is a negation pattern
        """
        self.patterns.append((pattern, is_negation))
    
    def clear_patterns(self):
        """Clear all loaded patterns"""
        self.patterns.clear()
