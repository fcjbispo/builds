"""Ollama embeddings client with batch generation and caching"""

import hashlib
import logging
from typing import List, Optional, Dict, Any
from pathlib import Path
import json
import ollama
from datetime import datetime, timedelta


logger = logging.getLogger(__name__)


class EmbeddingCache:
    """Cache for embeddings to avoid regeneration"""
    
    def __init__(self, cache_dir: Optional[str] = None):
        from mycodebase.core.config import config
        self.cache_dir = Path(cache_dir) if cache_dir else Path.home() / ".mycodebase" / "embedding_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_index: Dict[str, Dict[str, Any]] = {}
        self._load_index()
    
    def _load_index(self):
        """Load cache index from disk"""
        index_file = self.cache_dir / "cache_index.json"
        if index_file.exists():
            try:
                with open(index_file, 'r') as f:
                    self._cache_index = json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load cache index: {e}")
                self._cache_index = {}
    
    def _save_index(self):
        """Save cache index to disk"""
        index_file = self.cache_dir / "cache_index.json"
        try:
            with open(index_file, 'w') as f:
                json.dump(self._cache_index, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save cache index: {e}")
    
    def _compute_content_hash(self, content: str) -> str:
        """Compute SHA256 hash of content"""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()
    
    def get(self, content: str) -> Optional[List[float]]:
        """
        Get cached embedding for content.
        
        Args:
            content: Text content to get embedding for
            
        Returns:
            Cached embedding vector or None if not found/expired
        """
        content_hash = self._compute_content_hash(content)
        
        if content_hash in self._cache_index:
            cache_entry = self._cache_index[content_hash]
            
            # Check if cache is still valid (7 days TTL)
            cached_at = datetime.fromisoformat(cache_entry['cached_at'])
            if datetime.now() - cached_at > timedelta(days=7):
                logger.debug(f"Cache expired for content hash {content_hash[:8]}")
                del self._cache_index[content_hash]
                self._save_index()
                return None
            
            # Load embedding from file
            embedding_file = self.cache_dir / f"{content_hash}.npy"
            if embedding_file.exists():
                try:
                    import numpy as np
                    embedding = np.load(embedding_file).tolist()
                    logger.debug(f"Cache hit for content hash {content_hash[:8]}")
                    return embedding
                except Exception as e:
                    logger.warning(f"Failed to load cached embedding: {e}")
                    del self._cache_index[content_hash]
                    self._save_index()
                    return None
        
        return None
    
    def set(self, content: str, embedding: List[float]):
        """
        Cache an embedding for content.
        
        Args:
            content: Text content
            embedding: Embedding vector
        """
        content_hash = self._compute_content_hash(content)
        
        # Save embedding to file
        embedding_file = self.cache_dir / f"{content_hash}.npy"
        try:
            import numpy as np
            np.save(embedding_file, np.array(embedding, dtype=np.float32))
            
            # Update index
            self._cache_index[content_hash] = {
                'cached_at': datetime.now().isoformat(),
                'dimension': len(embedding),
                'size_bytes': embedding_file.stat().st_size
            }
            self._save_index()
            
            logger.debug(f"Cached embedding for content hash {content_hash[:8]}")
        except Exception as e:
            logger.warning(f"Failed to cache embedding: {e}")
    
    def clear(self):
        """Clear all cached embeddings"""
        for f in self.cache_dir.glob("*.npy"):
            f.unlink()
        self._cache_index = {}
        self._save_index()
        logger.info("Embedding cache cleared")
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_size = sum(
            f.stat().st_size for f in self.cache_dir.glob("*.npy")
        )
        return {
            'cache_dir': str(self.cache_dir),
            'num_embeddings': len(self._cache_index),
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2)
        }


class OllamaClient:
    """
    Client for generating embeddings via Ollama.
    
    Features:
    - Batch generation for performance
    - Content-based caching (avoid regeneration)
    - Configurable model and dimension
    - Timeout handling
    """
    
    # Heuristic: average ~4 characters per token for English/code text.
    # This is conservative; actual ratio varies by language and content.
    _CHARS_PER_TOKEN_ESTIMATE = 4.0

    def __init__(
        self,
        host: Optional[str] = None,
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        context_length: Optional[int] = None,
        batch_size: int = 32,
        timeout: int = 30
    ):
        """
        Initialize Ollama embeddings client.

        Args:
            host: Ollama host (default: from config)
            model: Embedding model name (default: from config)
            dimension: Expected embedding dimension (default: from config)
            context_length: Maximum tokens per text (default: from config)
            batch_size: Number of texts to embed per batch
            timeout: Timeout in seconds per request
        """
        from mycodebase.core.config import config

        self.host = host or config.ollama_host
        self.model = model or config.ollama_model
        self.dimension = dimension or config.embedding_dimension
        self.context_length = context_length or config.embedding_context_length
        self.batch_size = batch_size
        self.timeout = timeout
        
        # Initialize Ollama client
        ollama_host = self.host if self.host.startswith("http://") or self.host.startswith("https://") else f"http://{self.host}"
        self._client = ollama.Client(host=ollama_host)
        
        # Initialize cache
        self.cache = EmbeddingCache()
        
        logger.info(
            f"OllamaClient initialized: host={self.host}, model={self.model}, "
            f"dim={self.dimension}, context_length={self.context_length}"
        )
    
    def _truncate_texts(self, texts: List[str]) -> List[str]:
        """
        Truncate texts to fit within the model's context length.

        Uses a character-based heuristic (chars / 4.0) as a conservative
        token estimate. Preserves the beginning of each text since the
        most semantically relevant information (symbol name, signature)
        typically appears first.

        Args:
            texts: List of raw texts

        Returns:
            List of possibly-truncated texts
        """
        max_chars = int(self.context_length * self._CHARS_PER_TOKEN_ESTIMATE)
        truncated = []

        for text in texts:
            if len(text) > max_chars:
                logger.warning(
                    f"Text exceeds context limit ({self.context_length} tokens, "
                    f"~{max_chars} chars). Truncating from {len(text)} to {max_chars} chars."
                )
                truncated.append(text[:max_chars])
            else:
                truncated.append(text)

        return truncated

    def _generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts using Ollama's native batch endpoint.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        import random
        import time

        # Enforce context length limit before sending to Ollama
        texts = self._truncate_texts(texts)

        max_retries = 5
        base_delay = 2.0

        for attempt in range(max_retries):
            try:
                response = self._client.embed(
                    model=self.model,
                    input=texts
                )
                return response['embeddings']
            except Exception as e:
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                    logger.warning(f"Embedding batch failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {delay:.1f}s...")
                    time.sleep(delay)
                else:
                    logger.error(f"Embedding batch failed after {max_retries} attempts: {e}")
                    raise

        return [[0.0] * self.dimension for _ in texts]
    
    def generate_embedding(self, text: str, use_cache: bool = True) -> List[float]:
        """
        Generate embedding for text with optional caching.
        
        Args:
            text: Text to embed
            use_cache: Whether to use cache (default: True)
            
        Returns:
            Embedding vector
        """
        # Try cache first
        if use_cache:
            cached = self.cache.get(text)
            if cached:
                logger.debug(f"Using cached embedding for text ({len(text)} chars)")
                return cached
        
        # Generate new embedding
        logger.debug(f"Generating embedding for text ({len(text)} chars)")
        embedding = self._generate_embeddings([text])[0]
        
        # Validate dimension
        if len(embedding) != self.dimension:
            logger.warning(
                f"Embedding dimension mismatch: expected {self.dimension}, got {len(embedding)}"
            )
        
        # Cache it
        if use_cache:
            self.cache.set(text, embedding)
        
        return embedding
    
    def generate_batch(self, texts: List[str], use_cache: bool = True) -> List[List[float]]:
        """
        Generate embeddings for multiple texts in batches using Ollama's native batch endpoint.

        Args:
            texts: List of texts to embed
            use_cache: Whether to use cache (default: True)

        Returns:
            List of embedding vectors
        """
        logger.info(f"Generating embeddings for {len(texts)} texts (batch_size={self.batch_size})")

        embeddings = [None] * len(texts)
        texts_to_embed = []
        indices_to_embed = []

        # Check cache first
        for idx, text in enumerate(texts):
            if use_cache:
                cached = self.cache.get(text)
                if cached:
                    embeddings[idx] = cached
                    continue
            texts_to_embed.append(text)
            indices_to_embed.append(idx)

        if not texts_to_embed:
            logger.info(f"All {len(texts)} embeddings served from cache")
            return embeddings

        logger.info(f"Embedding {len(texts_to_embed)} texts (cached: {len(texts) - len(texts_to_embed)})")

        # Process in batches using Ollama's native batch endpoint
        import time
        for i in range(0, len(texts_to_embed), self.batch_size):
            batch_texts = texts_to_embed[i:i + self.batch_size]
            batch_indices = indices_to_embed[i:i + self.batch_size]
            batch_num = (i // self.batch_size) + 1
            total_batches = (len(texts_to_embed) + self.batch_size - 1) // self.batch_size

            logger.debug(f"Processing batch {batch_num}/{total_batches} ({len(batch_texts)} texts)")

            # Small delay between batches to avoid overwhelming Ollama
            if batch_num > 1:
                time.sleep(0.5)

            batch_embeddings = self._generate_embeddings(batch_texts)

            for idx_in_batch, (text_idx, embedding) in enumerate(zip(batch_indices, batch_embeddings)):
                if len(embedding) != self.dimension:
                    logger.warning(
                        f"Embedding dimension mismatch: expected {self.dimension}, got {len(embedding)}"
                    )

                if use_cache:
                    self.cache.set(batch_texts[idx_in_batch], embedding)

                embeddings[text_idx] = embedding

        logger.info(f"Generated {len(embeddings)} embeddings")
        return embeddings
    
    def generate_symbol_embedding(
        self,
        name: str,
        signature: Optional[str] = None,
        docstring: Optional[str] = None,
        use_cache: bool = True
    ) -> List[float]:
        """
        Generate embedding for a code symbol.
        
        Creates a rich text representation combining name, signature, and docstring.
        
        Args:
            name: Symbol name (function, class, etc.)
            signature: Function/method signature
            docstring: Documentation string
            use_cache: Whether to use cache
            
        Returns:
            Embedding vector
        """
        # Build rich text representation
        text_parts = [name]
        if signature:
            text_parts.append(signature)
        if docstring:
            text_parts.append(docstring)
        
        text = "\n".join(text_parts)
        
        logger.debug(f"Generating embedding for symbol: {name}")
        return self.generate_embedding(text, use_cache=use_cache)
    
    def health_check(self) -> bool:
        """Check if Ollama is accessible"""
        try:
            # Try to list models
            models = self._client.list()
            logger.debug(f"Ollama health check OK, {len(models.get('models', []))} models available")
            return True
        except Exception as e:
            logger.error(f"Ollama health check failed: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the embedding model"""
        try:
            models = self._client.list()
            for model in models.get('models', []):
                if model['name'] == self.model:
                    return {
                        'name': model['name'],
                        'size': model.get('size', 0),
                        'digest': model.get('digest', '')[:16]
                    }
            return {'name': self.model, 'status': 'not_found'}
        except Exception as e:
            logger.error(f"Failed to get model info: {e}")
            return {'name': self.model, 'error': str(e)}
    
    def cache_stats(self) -> Dict[str, Any]:
        """Get embedding cache statistics"""
        return self.cache.stats()
    
    def clear_cache(self):
        """Clear the embedding cache"""
        self.cache.clear()
