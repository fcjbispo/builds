"""Ollama embeddings integration"""
