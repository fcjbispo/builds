"""Centralized application configuration using Pydantic Settings v2.

This module provides a single source of truth for all non-sensitive
InfoBR configuration. Sensitive values (secrets) are handled by
infobr.secrets to avoid accidental logging.

Hierarchy (highest to lowest priority):
  1. Environment variables (os.environ)
  2. ~/.infobr/config.json (user persisted config)
  3. .env file in project root
  4. Safe defaults defined here

Usage:
    from infobr.config import get_settings
    settings = get_settings()
    print(settings.api_port)  # validated int
"""

from __future__ import annotations

import os
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

from pydantic import Field, computed_field
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict


# ---------------------------------------------------------------------------
# Environment overrides (dev/test/prod/local)
# ---------------------------------------------------------------------------

_ENV_OVERRIDES: dict[str, dict[str, Any]] = {
    "dev": {
        "api_reload": True,
        "api_workers": 1,
        "db_pool_size": 5,
    },
    "test": {
        "db_url": "sqlite:///:memory:",
        "api_rate_limit_max_requests": 9999,
        "password_iterations": 100000,
    },
    "prod": {
        "api_reload": False,
        "api_workers": 4,
    },
    "local": {},
}


class _JsonConfigSettingsSource(PydanticBaseSettingsSource):
    """Custom Pydantic Settings source that reads ~/.infobr/config.json."""

    def get_field_value(self, field: Any, field_name: str) -> tuple[Any, str, bool]:
        # Not used; we override __call__ instead
        return None, "", False

    def __call__(self) -> dict[str, Any]:
        home = Path(os.getenv("INFOBR_HOME", Path.home() / ".infobr")).expanduser()
        config_path = home / "config.json"
        if not config_path.exists():
            return {}
        try:
            import json

            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                warnings.warn(f"{config_path} must contain a JSON object; ignoring.")
                return {}
            # Map old flat keys to new snake_case where obvious
            mapped: dict[str, Any] = {}
            for key, value in data.items():
                # e.g. ALPHA_VANTAGE_API_KEY is a secret -> skipped here
                mapped[key.lower()] = value
            return mapped
        except Exception as exc:
            warnings.warn(f"Failed to load {config_path}: {exc}")
            return {}


class InfoBRSettings(BaseSettings):
    """Non-sensitive application configuration.

    All fields are validated at import time. Defaults are safe for local
    development. Production deployments must set required values via env vars.
    """

    model_config = SettingsConfigDict(
        env_prefix="INFOBR_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        # Allow custom JSON source below
    )

    # ------------------------------------------------------------------
    # Environment & service identity
    # ------------------------------------------------------------------
    env: Literal["dev", "test", "prod", "local"] = Field(
        default="local",
        description="Runtime environment profile",
    )
    home: Path = Field(
        default_factory=lambda: Path.home() / ".infobr",
        description="User data directory",
    )
    service_mode: Literal["api", "webapp", "tui"] = Field(
        default="api",
        description="Which service mode to run",
    )

    # ------------------------------------------------------------------
    # API / Uvicorn
    # ------------------------------------------------------------------
    api_host: str = Field(default="0.0.0.0", description="API bind host")
    api_port: int = Field(default=8500, ge=1, le=65535, description="API bind port")
    api_reload: bool = Field(default=False, description="Uvicorn auto-reload (dev only)")
    api_workers: int = Field(default=1, ge=1, description="Uvicorn worker processes")
    api_base_url: str = Field(
        default="http://127.0.0.1:8500/api/v1",
        description="URL used by Streamlit client to reach API",
    )

    # ------------------------------------------------------------------
    # Database
    # ------------------------------------------------------------------
    db_url: str = Field(
        default="",
        description="SQLAlchemy database URL (auto-defaults to SQLite under home)",
    )
    db_pool_size: int = Field(default=25, ge=1, description="SQLAlchemy pool size")
    db_max_overflow: int = Field(
        default=35, ge=0, description="SQLAlchemy max overflow connections"
    )
    db_pool_timeout: int = Field(
        default=60, ge=1, description="SQLAlchemy pool timeout (seconds)"
    )
    db_pool_recycle: int = Field(
        default=1800, ge=1, description="SQLAlchemy pool recycle (seconds)"
    )

    # ------------------------------------------------------------------
    # Rate limiting
    # ------------------------------------------------------------------
    api_rate_limit_max_requests: int = Field(
        default=120, ge=1, description="Max API requests per window"
    )
    api_rate_limit_window_seconds: int = Field(
        default=60, ge=1, description="API rate limit window (seconds)"
    )
    auth_login_rate_limit_max_requests: int = Field(
        default=20, ge=1, description="Max login attempts per window"
    )
    auth_login_rate_limit_window_seconds: int = Field(
        default=60, ge=1, description="Login rate limit window (seconds)"
    )

    # ------------------------------------------------------------------
    # Password / Auth
    # ------------------------------------------------------------------
    password_min_length: int = Field(default=8, ge=4, description="Minimum password length")
    password_iterations: int = Field(
        default=310000, ge=100000, description="PBKDF2 iterations"
    )
    login_max_attempts: int = Field(
        default=5, ge=1, description="Max failed logins before lockout"
    )
    login_lock_minutes: int = Field(
        default=15, ge=1, description="Account lockout duration (minutes)"
    )
    login_token_ttl_hours: int = Field(
        default=12, ge=1, description="Web login token TTL (hours)"
    )
    token_ttl_days: int = Field(
        default=30, ge=1, description="API bearer token TTL (days)"
    )

    # ------------------------------------------------------------------
    # Pipeline
    # ------------------------------------------------------------------
    pipeline_runners: int = Field(
        default=2, ge=1, description="Max concurrent pipeline runners"
    )
    pipeline_execution_timeout_minutes: int = Field(
        default=60, ge=1, description="Maximum minutes a pipeline execution may run"
    )

    # ------------------------------------------------------------------
    # Optional external services
    # ------------------------------------------------------------------
    redis_url: str = Field(
        default="",
        description="Redis URL for distributed rate limiting (optional)",
    )

    # ------------------------------------------------------------------
    # Computed paths (read-only)
    # ------------------------------------------------------------------
    @computed_field  # type: ignore[misc]
    @property
    def pipelines_path(self) -> Path:
        return self.home / "pipelines"

    @computed_field  # type: ignore[misc]
    @property
    def operations_path(self) -> Path:
        return self.home / "operations"

    @computed_field  # type: ignore[misc]
    @property
    def logs_path(self) -> Path:
        return self.home / "logs"

    # ------------------------------------------------------------------
    # Validators & model hooks
    # ------------------------------------------------------------------
    def model_post_init(self, __context: Any) -> None:
        """Apply environment overrides and normalize derived values."""
        # Ensure home directory exists
        self.home = self.home.expanduser()
        os.makedirs(self.home, exist_ok=True)
        os.makedirs(self.pipelines_path, exist_ok=True)
        os.makedirs(self.operations_path, exist_ok=True)
        os.makedirs(self.logs_path, exist_ok=True)

        # Auto-default db_url when empty
        if not self.db_url:
            self.db_url = f"sqlite:///{self.home}/infbr.db"

        # Apply env-specific overrides only when the corresponding env var
        # is not explicitly set (user preferences take precedence).
        _env_var_map: dict[str, str] = {
            "api_reload": "INFOBR_API_RELOAD",
            "api_workers": "INFOBR_API_WORKERS",
            "db_pool_size": "INFOBR_DB_POOL_SIZE",
            "db_url": "INFOBR_DB_URL",
            "api_rate_limit_max_requests": "INFOBR_API_RATE_LIMIT_MAX_REQUESTS",
            "password_iterations": "INFOBR_PASSWORD_ITERATIONS",
            "login_token_ttl_hours": "INFOBR_LOGIN_TOKEN_TTL_HOURS",
            "token_ttl_days": "INFOBR_TOKEN_TTL_DAYS",
        }
        overrides = _ENV_OVERRIDES.get(self.env, {})
        for key, value in overrides.items():
            if hasattr(self, key):
                env_var = _env_var_map.get(key)
                # Only override if user hasn't set the corresponding env var
                if env_var is None or env_var not in os.environ:
                    object.__setattr__(self, key, value)

        # Prod sanity checks
        if self.env == "prod":
            if not self.redis_url:
                warnings.warn(
                    "INFOBR_REDIS_URL is not set. Redis-backed rate limiting is "
                    "strongly recommended for production deployments.",
                    RuntimeWarning,
                    stacklevel=2,
                )
            if self.api_reload:
                warnings.warn(
                    "INFOBR_API_RELOAD=True in production is not recommended.",
                    RuntimeWarning,
                    stacklevel=2,
                )

    # Allow loading from JSON config file alongside env vars
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings,
        env_settings,
        dotenv_settings,
        file_secret_settings,
    ):
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            _JsonConfigSettingsSource(settings_cls),
            file_secret_settings,
        )


# ---------------------------------------------------------------------------
# Lazy singleton accessors
# ---------------------------------------------------------------------------

@lru_cache
def get_settings() -> InfoBRSettings:
    """Return the validated, cached application settings singleton."""
    return InfoBRSettings()
