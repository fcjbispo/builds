"""Pipeline loader and runner (DB-backed)."""

import os
import json
from datetime import datetime
from typing import Any

from infobr import logger, env
from infobr.data.series import SeriesExtractDataProcessor, SeriesLoadDataProcessor


class Pipeline:
    PROCESSORS = {
        "SeriesExtractDataProcessor": SeriesExtractDataProcessor,
        "SeriesLoadDataProcessor": SeriesLoadDataProcessor,
    }

    def __init__(self, pipeline_name: str):
        if not pipeline_name:
            raise ValueError("Pipeline name must be provided.")
        self.pipeline_name = pipeline_name
        self.config: dict[str, Any] | None = None

    def load(self) -> dict[str, Any] | None:
        if self.config:
            return self.config
        file_path = os.path.sep.join(
            [env.USER_APP_FOLDER, "pipelines", f"{self.pipeline_name}.json"]
        )
        if not os.path.exists(file_path):
            logger.error(f"Pipeline file not found: {file_path}")
            return None
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def run_and_collect(
        self,
        parallelize: bool = True,
        progress: bool = False,
        progress_callback=None,
    ) -> list[dict[str, Any]]:
        """Run pipeline and return results as list of dicts (for DB storage)."""
        storage_folder = env.USER_CONFIG.get("SERIES_HISTORY_FOLDER")

        pipeline = self.load()
        if not pipeline:
            raise ValueError(f"Pipeline '{self.pipeline_name}' could not be loaded.")

        pipeline["storage_folder"] = storage_folder
        pipeline["parallelize"] = parallelize
        pipeline["progress"] = progress

        if "processor" not in pipeline:
            raise ValueError("Pipeline must specify a 'processor'.")

        processor = self.PROCESSORS[pipeline.pop("processor")](pipeline)

        if progress_callback:
            results = processor.run(progress_callback=progress_callback)
        else:
            results = processor.run()

        output = []
        for r in results:
            scope, success, error_message, data = r
            output.append(
                {
                    "scope": scope,
                    "success": success,
                    "error_message": error_message,
                    "data": data.to_dict(orient="records"),
                }
            )
        return output

    def run(
        self,
        parallelize: bool = True,
        progress: bool = False,
        progress_callback=None,
    ) -> list[dict[str, Any]]:
        """Run pipeline and return results (alias for run_and_collect)."""
        return self.run_and_collect(
            parallelize=parallelize,
            progress=progress,
            progress_callback=progress_callback,
        )