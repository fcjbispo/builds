"""FastAPI application factory for InfoBR REST API."""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from infobr.api.errors import (
    http_exception_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from infobr.api.routers.auth import router as auth_router
from infobr.api.routers.admin import router as admin_router
from infobr.api.routers.executions import router as executions_router
from infobr.api.routers.health import router as health_router
from infobr.api.routers.pipelines import router as pipelines_router
from infobr.api.services.execution_service import ExecutionService


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup/shutdown lifecycle hooks."""
    ExecutionService.recover_orphaned_executions()
    yield


def create_app() -> FastAPI:
    """Create and configure the InfoBR API application."""
    app = FastAPI(
        title="InfoBR API",
        version="2.2.1",
        description="InfoBR REST API with DB-backed pipeline management.",
        lifespan=_lifespan,
    )

    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)

    app.include_router(health_router, prefix="/api/v1", tags=["health"])
    app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(pipelines_router, prefix="/api/v1", tags=["pipelines"])
    app.include_router(executions_router, prefix="/api/v1", tags=["executions"])
    app.include_router(admin_router, prefix="/api/v1", tags=["admin"])

    return app


app = create_app()
