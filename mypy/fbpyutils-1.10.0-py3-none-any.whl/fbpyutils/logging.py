"""
Application Logging Infrastructure and Configuration Management

This module provides a comprehensive logging system for the FBPyUtils application with
singleton pattern implementation, automatic configuration from environment settings,
and support for both traditional text and JSON log formats. The module handles thread-safe
file logging with rotation, console output, and runtime reconfiguration capabilities.

The module offers five primary capabilities:

* **Singleton Logger Management**: Centralized logging instance ensuring consistent
  configuration across the application with automatic environment integration.

* **Multi-Format Support**: Both traditional text formatting and JSON structured logging
  with automatic formatter selection based on configuration preferences.

* **File Logging with Rotation**: Thread-safe file logging using ConcurrentRotatingFileHandler
  with automatic rotation, backup management, and UTF-8 encoding support.

* **Runtime Configuration**: Dynamic reconfiguration capabilities allowing log level,
  format, and handler changes without application restart.

* **Environment Integration**: Automatic configuration from Env singleton with environment
  variable precedence and fallback to sensible defaults.

Key Features:
-------------
* **Thread-Safe Operations**: Concurrent logging support for multi-threaded applications
* **Automatic Rotation**: File-based logging with size-based rotation and backup management
* **JSON Structured Logging**: Support for machine-readable log formats with python-json-logger
* **Environment Precedence**: Configuration values overridden by environment variables
* **NullHandler Fallback**: Safe default behavior when no handlers are configured
* **Configuration Validation**: Comprehensive error handling for invalid configurations

Dependencies:
-------------
* `logging`: Python's core logging functionality
 standard logging module for* `concurrent_log_handler`: Thread-safe file logging with rotation support
* `pythonjsonlogger` (optional): JSON formatting with fallback to text
* `os`: File system operations for log path management and directory creation
* `typing`: Type hints for configuration parameters and return values

Usage Examples:
---------------
Basic logging setup and usage:

>>> from fbpyutils import setup, get_logger
>>> setup()  # Configures logger from environment
>>> logger = get_logger()
>>> logger.info("Application started successfully")
>>> logger.warning("Low memory detected: {usage}%", usage=85)

JSON format logging:

>>> from fbpyutils.logging import Logger
>>> config = {'log_level': 'DEBUG', 'log_format': 'json', 'log_handlers': ['file']}
>>> Logger.configure_from_config_dict(config)
>>> logger = get_logger()
>>> logger.info("Processing request", extra_data={"user_id": 123, "endpoint": "/api/users"})

Runtime reconfiguration:

>>> from fbpyutils import get_logger
>>> logger = get_logger()
>>> # Update environment settings
>>> env.LOG_LEVEL = 'DEBUG'
>>> logger.configure_from_env(env)
>>> logger.debug("Debug logging enabled")

File and console logging:

>>> from fbpyutils.logging import Logger
>>> Logger.configure('MyApp', 'INFO', log_format='json')
>>> logger = get_logger()
>>> logger.info("Application initialized", version="1.0.0")
# Logs to ~/.myapp/logs/app.log (path derived from app_name; ADR-0007).

Notes:
------
* **Client ownership (PLAN_004 / ADR-0007):** the logger belongs to the client
  application, never to FBPyUtils. Clients MUST provide an `app.json` and call
  `fbpyutils.setup('app.json')` at startup. The logger name derives from
  `app.name` and the default log path from `~/.{app_name}/logs/app.log`.
* **Best practice:** every client application should call `fbpyutils.setup()` once
  at initialization. Using logging without setup emits a single warning and falls
  back to a NullHandler (graceful degradation, no raise).
* Internal FBPyUtils modules do NOT call `setup()` on import; they log to
  `logging.getLogger(__name__)` with a NullHandler and propagate to the root logger.
* Default `log_handlers` is `["console"]` only. Add `"file"` and/or `"sqlite"`
  explicitly to enable those destinations.
* `SQLiteLogHandler` persists records (including `app_name`/`app_version`) via the
  stdlib `sqlite3` module — no external dependency.
* JSON format requires pythonjsonlogger package installation
* File logging automatically creates directories as needed
* ConcurrentRotatingFileHandler ensures thread-safe file operations
* Environment variables override configuration file values

Cross-References:
-----------------
* See `fbpyutils.env` for environment configuration integration
* See `fbpyutils.setup()` for automatic logger configuration
"""

import json
import logging
import os
import sqlite3
import threading
import warnings
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from concurrent_log_handler import ConcurrentRotatingFileHandler

try:
    from pythonjsonlogger import jsonlogger

    JSON_LOGGER_AVAILABLE = True
except ImportError:
    JSON_LOGGER_AVAILABLE = False


# PLAN_004 3.4.2: handler registry. Maps a `log_handlers` string to its handler
# class. PostgreSQL/MongoDB enter this registry in future releases; v1.10.0 ships
# console, file and sqlite (sqlite3 from the stdlib, no external dependency).
_HANDLER_REGISTRY: Dict[str, type] = {
    "console": logging.StreamHandler,
    "file": ConcurrentRotatingFileHandler,
    "sqlite": None,  # bound below after SQLiteLogHandler is defined
    "none": logging.NullHandler,
}


class SQLiteLogHandler(logging.Handler):
    """Persist log records to a SQLite database (PLAN_004 3.4).

    Uses the stdlib ``sqlite3`` module (no external dependency). Schema per
    section 3.4.1, including the client ``app_name`` and ``app_version`` columns.

    The connection is opened with ``check_same_thread=False`` and every emit is
    serialized by a lock, so the handler is safe for multi-threaded logging.
    """

    # ponytail: standard LogRecord attributes excluded from extra_json.
    _STANDARD_ATTRS = frozenset(
        {
            "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
            "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
            "created", "msecs", "relativeCreated", "thread", "threadName",
            "processName", "process", "taskName", "message",
        }
    )

    _SCHEMA_SQL = (
        "CREATE TABLE IF NOT EXISTS logs ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "timestamp TEXT NOT NULL, "
        "level TEXT NOT NULL, "
        "logger TEXT NOT NULL, "
        "module TEXT, "
        "func_name TEXT, "
        "message TEXT NOT NULL, "
        "app_name TEXT, "
        "app_version TEXT, "
        "extra_json TEXT)"
    )

    def __init__(self, db_path: str, app_name: Optional[str] = None,
                 app_version: Optional[str] = None):
        super().__init__()
        self._db_path = db_path
        self._app_name = app_name
        self._app_version = app_version
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute(self._SCHEMA_SQL)
        self._conn.commit()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            ts = datetime.fromtimestamp(record.created, timezone.utc).isoformat()
            extra = {
                k: v
                for k, v in record.__dict__.items()
                if k not in self._STANDARD_ATTRS and not k.startswith("_")
            }
            extra_json = json.dumps(extra, default=str) if extra else None
            with self._lock:
                self._conn.execute(
                    "INSERT INTO logs (timestamp, level, logger, module, func_name, "
                    "message, app_name, app_version, extra_json) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ts,
                        record.levelname,
                        record.name,
                        record.module,
                        record.funcName,
                        record.getMessage(),
                        self._app_name,
                        self._app_version,
                        extra_json,
                    ),
                )
                self._conn.commit()
        except Exception:
            self.handleError(record)

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass
        super().close()


_HANDLER_REGISTRY["sqlite"] = SQLiteLogHandler


# Forward declaration of Env to avoid circular import
class Env:
    pass


class Logger:
    """Singleton logging class providing static interface to Python's logging module.

    Ensures single logger instance. Must be configured via fbpyutils.setup() which calls get_from_env().
    Supports reconfiguration at runtime. Uses ConcurrentRotatingFileHandler for thread-safe logging.
    Supports both JSON and traditional text log formats.

    Attributes:
        DEBUG (int): DEBUG log level constant.
        INFO (int): INFO log level constant.
        WARNING (int): WARNING log level constant.
        ERROR (int): ERROR log level constant.
        CRITICAL (int): CRITICAL log level constant.

    Example:
        >>> from fbpyutils import setup, get_logger
        >>> setup()  # Configures logger
        >>> logger = get_logger()
        >>> logger.info("Application started")
        # Logs to console and file if configured.
    """

    _instance: Optional["Logger"] = None

    # Log levels available as class attributes for convenience.
    DEBUG: int = logging.DEBUG
    INFO: int = logging.INFO
    WARNING: int = logging.WARNING
    ERROR: int = logging.ERROR
    CRITICAL: int = logging.CRITICAL

    _logger: logging.Logger = logging.getLogger("fbpyutils")
    _is_configured: bool = False
    # ponytail: warn once when logging is used without setup() (Q5), not raise.
    _unconfigured_warned: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @staticmethod
    def _create_formatter(log_format: str) -> logging.Formatter:
        """Creates appropriate formatter based on log format specification.

        Args:
            log_format (str): Format string or 'json' for JSON formatting.

        Returns:
            logging.Formatter: Configured formatter instance.

        Raises:
            ImportError: If 'json' format requested but python-json-logger not installed.
        """
        if log_format.lower() == "json":
            if not JSON_LOGGER_AVAILABLE:
                raise ImportError(
                    "JSON logging format requires 'python-json-logger' package. "
                    "Install it with: pip install python-json-logger"
                )
            return jsonlogger.JsonFormatter(
                "%(asctime)s %(name)s %(levelname)s %(funcName)s %(lineno)d %(message)s",
                timestamp=True,
            )
        else:
            return logging.Formatter(log_format)

    @staticmethod
    def _configure_internal(config_dict: Dict[str, Any]) -> None:
        """Internal method to configure logging from a dictionary.

        Sets level, format, and handlers (console/file). Clears existing handlers to avoid duplicates.
        Supports both JSON and traditional text log formats.

        Args:
            config_dict (Dict[str, Any]): Config with 'app_name', 'log_level', 'log_format',
                'log_handlers'. Log paths are always derived from app_name (ADR-0007);
                'log_file_path'/'sqlite_log_path', if present, are ignored with a warning.

        Raises:
            ValueError: If no valid handlers are configured.
            ImportError: If JSON format requested but python-json-logger not installed.
        """
        app_name = config_dict.get("app_name")
        if app_name and isinstance(app_name, str):
            Logger._logger = logging.getLogger(app_name.lower())

        log_level_str = config_dict.get("log_level", "INFO").upper()
        log_format = config_dict.get(
            "log_format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

        # PLAN_004 3.2.3 / ADR-0007: the log path is ALWAYS derived from app_name
        # as ~/.{app_name}/logs/app.log. It is not configurable — the application
        # folder is the central location for all app data.
        if config_dict.get("log_file_path") is not None or config_dict.get("sqlite_log_path") is not None:
            warnings.warn(
                "log_file_path/sqlite_log_path are no longer configurable (ADR-0007); "
                "log paths are always derived from app_name as ~/.{app_name}/logs/.",
                stacklevel=2,
            )
        log_file_path = os.path.expanduser(
            os.path.sep.join(["~", f".{(app_name or 'app').lower()}", "logs", "app.log"])
        )

        # Q6: default handler is console only — avoid polluting client folders with files.
        log_handlers = config_dict.get("log_handlers")
        if log_handlers is None:
            log_handlers = ["console"]

        numeric_level = getattr(logging, log_level_str, logging.INFO)
        Logger._logger.setLevel(numeric_level)

        # Clear existing handlers to prevent duplicate logs on re-configuration
        if Logger._logger.handlers:
            for handler in Logger._logger.handlers[:]:
                handler.close()
                Logger._logger.removeHandler(handler)

        formatter = Logger._create_formatter(log_format)

        # File Handler
        if "file" in log_handlers:
            if log_file_path:
                try:
                    log_dir = os.path.dirname(log_file_path)
                    if log_dir and not os.path.exists(log_dir):
                        os.makedirs(log_dir)

                    file_handler = ConcurrentRotatingFileHandler(
                        log_file_path,
                        maxBytes=256 * 1024,  # 256 KB
                        backupCount=5,
                        encoding="utf-8",
                    )
                    file_handler.setFormatter(formatter)
                    Logger._logger.addHandler(file_handler)
                except Exception as e:
                    print(f"Error setting up file logger at {log_file_path}: {e}")

        # Console Handler
        if "console" in log_handlers:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            Logger._logger.addHandler(console_handler)

        # SQLite Handler (PLAN_004 3.4 / ADR-0007): path always derived from app_name.
        if "sqlite" in log_handlers:
            sqlite_path = os.path.expanduser(
                os.path.sep.join(["~", f".{(app_name or 'app').lower()}", "logs", "app.db"])
            )
            try:
                log_dir = os.path.dirname(sqlite_path)
                if log_dir and not os.path.exists(log_dir):
                    os.makedirs(log_dir)
                sqlite_handler = SQLiteLogHandler(
                    sqlite_path,
                    app_name=app_name,
                    app_version=config_dict.get("app_version"),
                )
                Logger._logger.addHandler(sqlite_handler)
            except Exception as e:
                print(f"Error setting up sqlite logger at {sqlite_path}: {e}")

        # Add NullHandler only if no other handlers are configured
        if not Logger._logger.hasHandlers():
            null_handler = logging.NullHandler()
            Logger._logger.addHandler(null_handler)

        # check if at least one handler is added
        if not Logger._logger.hasHandlers():
            raise ValueError(
                "No valid log handlers configured. Please check 'log_handlers' in the configuration. Valid options are 'none', 'console', 'file' and 'sqlite'."
            )

        Logger._is_configured = True

    @classmethod
    def get_from_env(cls, env: "Env") -> "Logger":
        """Gets the singleton Logger instance configured from an Env object.

        Primary method for obtaining configured logger after fbpyutils.setup().

        Args:
            env (Env): Configured Env instance with LOG_LEVEL, LOG_FORMAT, etc.

        Returns:
            Logger: The configured singleton logger instance.

        Example:
            >>> from fbpyutils import setup, get_logger
            >>> setup()
            >>> logger = get_logger()  # Calls get_from_env internally
            >>> logger.info("Test log")
            # Logs according to Env config.
        """
        config = {
            "log_level": env.LOG_LEVEL,
            "log_format": env.LOG_FORMAT,
            "log_handlers": env.LOG_HANDLERS,
            "app_name": getattr(env.APP, "name", None),
            "app_version": getattr(env.APP, "version", None),
        }
        cls._configure_internal(config)
        return cls()

    @staticmethod
    def configure_from_env(env: "Env") -> None:
        """Re-configures the logger at runtime from an Env object.

        Logs a confirmation message after reconfiguration.

        Args:
            env (Env): Env instance with updated logging settings.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> # Update env LOG_LEVEL to 'DEBUG'
            >>> logger.configure_from_env(env)
            # Logs: Logging system re-configured from Env.
        """
        config_dict = {
            "log_level": env.LOG_LEVEL,
            "log_format": env.LOG_FORMAT,
            "log_handlers": env.LOG_HANDLERS,
            "app_name": getattr(env.APP, "name", None),
            "app_version": getattr(env.APP, "version", None),
        }
        Logger._configure_internal(config_dict)
        Logger._logger.info("Logging system re-configured from Env.")

    @staticmethod
    def configure_from_config_dict(config_dict: Dict[str, Any]) -> None:
        """Re-configures the logger from a configuration dictionary.

        Args:
            config_dict (Dict[str, Any]): Dict with 'log_level', 'log_format', etc.

        Example:
            >>> from fbpyutils.logging import Logger
            >>> config = {'log_level': 'DEBUG', 'log_handlers': ['console']}
            >>> Logger.configure_from_config_dict(config)
            # Logs: Logging system re-configured.
        """
        Logger._configure_internal(config_dict)
        Logger._logger.info("Logging system re-configured.")

    @staticmethod
    def configure(
        app_name: str, log_level: str, log_format: str = None
    ) -> None:
        """Convenience method to configure logger with basic parameters.

        Uses file handler by default. The log file path is always derived from
        ``app_name`` as ``~/.{app_name}/logs/app.log`` (ADR-0007, not configurable).

        Args:
            app_name (str): Logger name; also drives the log path.
            log_level (str): Log level like 'INFO'.
            log_format (str, optional): Log format string or 'json'. Defaults to standard.

        Example:
            >>> from fbpyutils.logging import Logger
            >>> Logger.configure('MyApp', 'DEBUG', log_format='json')
            # Configures logger for 'MyApp' at DEBUG level with JSON format; logs to ~/.myapp/logs/app.log.
        """
        Logger.configure_from_config_dict(
            {
                "log_level": log_level,
                "log_format": log_format,
                "log_handlers": ["file"],
                "app_name": app_name,
            }
        )

    @staticmethod
    def _check_configured():
        """Checks if logger is configured; warns once if not (Q5).

        Internal method called by logging methods. Does NOT raise — the NullHandler
        on the underlying logger absorbs the call so callers keep working without setup().
        Best practice: call fbpyutils.setup('app.json') at application startup.
        """
        if not Logger._is_configured and not Logger._unconfigured_warned:
            warnings.warn(
                "fbpyutils.logging is being used without setup(). "
                "Call fbpyutils.setup('app.json') at application startup for correct "
                "logger name, handlers and log path. Until then, logs may not appear.",
                stacklevel=3,
            )
            Logger._unconfigured_warned = True

    @staticmethod
    def configure_for_app(
        app_name: str,
        log_level: str = "INFO",
        log_format: Optional[str] = None,
        log_handlers: Optional[list] = None,
    ) -> "Logger":
        """Configure the logger for a client application independent of the Env singleton.

        Convenience API (PLAN_004 3.2.2). The log path is always derived from
        ``app_name`` as ``~/.{app_name.lower()}/logs/app.log`` (ADR-0007, not
        configurable). When ``log_handlers`` is omitted it defaults to ``["console"]``
        (Q6).

        Args:
            app_name: Client application name; used as the logger name (lowercased)
                and to derive the log path.
            log_level: Log level string (e.g. 'INFO', 'DEBUG').
            log_format: Format string or 'json'. None -> library default.
            log_handlers: List of handler names. None -> ['console'].

        Returns:
            The configured singleton Logger instance.
        """
        config_dict = {
            "app_name": app_name,
            "log_level": log_level,
            "log_format": log_format,
            "log_handlers": log_handlers,
        }
        Logger._configure_internal(config_dict)
        return Logger()

    @staticmethod
    def debug(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with DEBUG severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.debug("Debugging user %s", "Alice")
            # Logs at DEBUG level if enabled.
        """
        Logger._check_configured()
        Logger._logger.debug(message, *args, **kwargs)

    @staticmethod
    def info(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with INFO severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.info("User %s logged in", "Alice")
            # Logs at INFO level.
        """
        Logger._check_configured()
        Logger._logger.info(message, *args, **kwargs)

    @staticmethod
    def warning(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with WARNING severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.warning("Low disk space for user %s", "Alice")
            # Logs at WARNING level.
        """
        Logger._check_configured()
        Logger._logger.warning(message, *args, **kwargs)

    @staticmethod
    def error(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with ERROR severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.error("Failed to process file for user %s", "Alice")
            # Logs at ERROR level.
        """
        Logger._check_configured()
        Logger._logger.error(message, *args, **kwargs)

    @staticmethod
    def critical(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with CRITICAL severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.critical("System shutdown initiated")
            # Logs at CRITICAL level.
        """
        Logger._check_configured()
        Logger._logger.critical(message, *args, **kwargs)

    @staticmethod
    def log(log_type: int, log_text: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with a custom log level on the root logger.

        Args:
            log_type (int): Log level constant (e.g., logging.DEBUG).
            log_text (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> import logging
            >>> logger = get_logger()
            >>> logger.log(logging.WARNING, "Custom warning: %s", "Test")
            # Logs at WARNING level.
        """
        Logger._check_configured()
        Logger._logger.log(log_type, log_text, *args, **kwargs)
