"""
Excel File Processing and Workbook Management Utilities

This module provides comprehensive Excel file processing capabilities supporting both legacy .xls and modern .xlsx
formats with unified interfaces for reading, writing, and workbook manipulation. The module handles both file
paths and in-memory bytes operations with automatic format detection and pandas DataFrame integration.

The module offers five primary capabilities:

* **Format Detection**: Automatic detection of .xls vs .xlsx formats with appropriate engine selection
  (xlrd for .xls, openpyxl for .xlsx) with fallback mechanisms.

* **Workbook Management**: Unified ExcelWorkbook class providing consistent interfaces for sheet operations
  across different Excel formats with sheet discovery and validation.

* **Sheet Reading**: Multiple reading strategies including by name, index, and bulk operations
  with proper data type preservation and error handling.

* **DataFrame Integration**: Seamless integration with pandas DataFrames for data manipulation
  and analysis workflows with automatic type conversion and formatting.

* **Workbook Writing**: Support for creating new workbooks and appending sheets with conflict resolution
  through automatic sheet naming and index management.

Key Features:
-------------
* **Dual Format Support**: Handles both .xls (legacy) and .xlsx (modern) Excel files
* **Automatic Engine Selection**: Chooses optimal processing engine based on file format
* **Memory Efficiency**: Supports both file path and in-memory byte operations
* **Sheet Discovery**: Automatic sheet name extraction and validation
* **Type Preservation**: Maintains Excel data types (dates, numbers, booleans) during processing
* **Conflict Resolution**: Smart sheet naming for append operations
* **Error Handling**: Comprehensive validation and graceful error recovery
* **Thread Safety**: Safe concurrent access patterns for multi-threaded environments

Dependencies:
---------------
* `openpyxl`: Modern .xlsx file processing with cell-level access
* `xlrd`: Legacy .xls file reading support
* `pandas`: DataFrame integration and analysis workflows
* `datetime`: Date/time type preservation from Excel cells
* `typing`: Type hints for parameter validation and IDE support
* `warnings`: Warning suppression for library-specific deprecations
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Read Excel files by sheet name:

>>> from fbpyutils.xlsx import ExcelWorkbook
>>> wb = ExcelWorkbook('/path/to/file.xlsx')
>>> wb.sheet_names
['Data', 'Summary']
>>> rows = wb.read_sheet('Data')
>>> rows[0]
('Name', 'Age', 'Department', 'Salary')

Read specific sheets by index:

>>> wb.read_sheet_by_index(1)  # Second sheet
>>> # Returns tuple of tuples with cell values
>>> data = wb.read_sheet('Summary')
>>> len(data) > 0
True

Process Excel files from bytes:

>>> with open('file.xlsx', 'rb') as f:
...     content = f.read()
>>> wb = ExcelWorkbook(content)
>>> sheet_names = wb.sheet_names
>>> print(f"Found {len(sheet_names)} sheets: {sheet_names}")

Convenience functions for quick access:

>>> from fbpyutils.xlsx import get_sheet_names, get_sheet_by_name, get_all_sheets
>>> sheets = get_sheet_names('data.xlsx')
>>> sheet_data = get_sheet_by_name('data.xlsx', 'Sales')
>>> all_sheets = get_all_sheets('data.xlsx')
>>> all_sheets.keys()
dict_keys(['Sheet1', 'Sales', 'Summary'])

Write DataFrames to Excel:

>>> import pandas as pd
>>> from fbpyutils.xlsx import write_to_sheet
>>> df = pd.DataFrame({'A': [1, 2, 3], 'B': ['x', 'y', 'z']})
>>> write_to_sheet(df, 'output.xlsx', 'Data')
>>> # Appends additional sheets with conflict resolution
>>> df2 = pd.DataFrame({'C': [4, 5, 6]})
>>> write_to_sheet(df2, 'output.xlsx', 'Data')  # Creates 'Data1'

Notes:
------
* File format detection is automatic based on file content and extension
* Legacy .xls support limited to reading operations
* .xlsx files support both reading and writing operations
* Cell values preserved in original Excel types where possible
* Empty cells represented as None values
* Date/time cells converted to Python datetime objects
* Formula cells show calculated values (data_only=True)

Error Handling:
--------------
* FileNotFoundError: Excel file path does not exist
* ValueError: Invalid file format or corrupted workbook
* NameError: Specified sheet name not found
* IndexError: Sheet index out of range
* TypeError: Invalid input type (must be str path or bytes)
* OSError: File access permissions or I/O errors

Performance Considerations:
------------------------
* Large workbooks: Memory usage scales with workbook size
* Format detection: Automatic engine selection overhead minimal
* Sheet reading: Efficient for targeted sheet access
* DataFrame operations: Optimized for pandas integration
* File I/O: Synchronous operations with proper buffering

Cross-References:
-----------------
* See `pandas.DataFrame` for data manipulation capabilities
* See `openpyxl` for advanced Excel formatting options
* See `xlrd` for legacy .xls file specifications
* See `fbpyutils.logging` for operation tracking and debugging
* See `fbpyutils.setup()` for proper initialization requirements
"""

import os
import io
import openpyxl
import xlrd
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
from typing import Union, Dict
import warnings
from fbpyutils import get_logger

import fbpyutils

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

XLS, XLSX = 0, 1


class ExcelWorkbook:
    """Unified interface for .xls/.xlsx workbooks using openpyxl (xlsx) or xlrd (xls).

    Automatically detects format from bytes or path. Provides sheet reading by name/index.

    Attributes:
        workbook: Underlying workbook (openpyxl.Workbook or xlrd.Book).
        sheet_names (list[str]): List of sheet names.
        kind (int): XLS (0) or XLSX (1).

    Example:
        >>> from fbpyutils.xlsx import ExcelWorkbook
        >>> wb = ExcelWorkbook('/path/to/file.xlsx')
        >>> wb.sheet_names
        ['Sheet1', 'Data']
        >>> rows = wb.read_sheet('Sheet1')
        >>> len(rows) > 0
        True
    """

    def __init__(self, xl_file: Union[str, bytes]):
        """Initializes ExcelWorkbook from file path or bytes, detecting .xls/.xlsx format.

        Tries openpyxl first, falls back to xlrd for .xls. Suppresses warnings during load.

        Args:
            xl_file (Union[str, bytes]): File path (str) or bytes content.

        Raises:
            FileNotFoundError: Path does not exist.
            TypeError: Invalid input type.
            ValueError: Cannot open as valid Excel.

        Example:
            >>> from fbpyutils.xlsx import ExcelWorkbook
            >>> wb = ExcelWorkbook('/path/to/file.xlsx')
            >>> wb.kind
            1  # XLSX
            >>> wb.sheet_names
            ['DataSheet']
            >>> wb_bytes = open('/path/to/file.xls', 'rb').read()
            >>> wb2 = ExcelWorkbook(wb_bytes)
            >>> wb2.kind
            0  # XLS
        """
        data = None

        if isinstance(xl_file, str):
            if os.path.exists(xl_file):
                try:
                    with open(xl_file, "rb") as f:
                        data = f.read()
                    _logger.info(f"Successfully read Excel file from path: {xl_file}")
                except (OSError, IOError) as e:
                    _logger.error(f"Error reading the Excel file {xl_file}: {e}")
                    raise
            else:
                _logger.error(f"Excel file not found: {xl_file}")
                raise FileNotFoundError(f"File {xl_file} does not exist.")
        elif isinstance(xl_file, bytes):
            data = xl_file
            _logger.info("Received Excel file as bytes.")
        else:
            _logger.error(
                f"Invalid file reference type: {type(xl_file)}. Must be a file path (str) or bytes."
            )
            raise TypeError(
                "Invalid file reference. Must be a file path or array of bytes."
            )

        self.workbook = None
        self.sheet_names = None
        self.kind = XLSX

        try:
            xl_data = io.BytesIO(data)
            warnings.simplefilter("ignore")
            self.workbook = openpyxl.open(xl_data, data_only=True)
            self.sheet_names = self.workbook.sheetnames
        except Exception as e_xlsx:
            _logger.warning(
                f"Failed to open with openpyxl, trying xlrd. Error: {e_xlsx}"
            )
            try:
                xl_data.seek(0)
                self.workbook = xlrd.open_workbook(file_contents=xl_data.read())
                self.sheet_names = self.workbook.sheet_names()
                self.kind = XLS
            except Exception as e_xls:
                _logger.error(
                    f"Failed to open workbook with both openpyxl and xlrd. XLSX error: {e_xlsx}, XLS error: {e_xls}"
                )
                raise ValueError(
                    "Could not open workbook. Invalid file format or corrupted file."
                ) from e_xls
        finally:
            warnings.simplefilter("default")
        _logger.info(
            f"ExcelWorkbook initialized: format={'XLSX' if self.kind == XLSX else 'XLS'}, "
            f"sheets={len(self.sheet_names)}, sheet_names={self.sheet_names}"
        )

    def read_sheet(
        self, sheet_name: str = None
    ) -> tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]:
        """Reads sheet data as tuple of rows (each row a tuple of cell values).

        Defaults to first sheet if name not provided. Uses iter_rows for xlsx, cell_value for xls.

        Args:
            sheet_name (str, optional): Sheet name. Defaults to first sheet.

        Returns:
            tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]: Rows of cell values.

        Raises:
            NameError: Sheet name not found.

        Example:
            >>> from fbpyutils.xlsx import ExcelWorkbook
            >>> wb = ExcelWorkbook('/path/to/file.xlsx')
            >>> rows = wb.read_sheet('Data')
            >>> rows[0]  # First row
            ('Header1', 1.0, datetime(2023, 1, 1), True)
            >>> rows = wb.read_sheet()  # First sheet
            >>> len(rows) > 0
            True
        """
        sheet_name = sheet_name or self.sheet_names[0]

        if sheet_name not in self.sheet_names:
            _logger.error(
                f"Invalid or nonexistent sheet name: {sheet_name}. Available sheets: {self.sheet_names}"
            )
            raise NameError("Invalid/Nonexistent sheet.")

        try:
            if self.kind == XLSX:
                sh = self.workbook[sheet_name]
                rows = tuple(tuple(c.value for c in r) for r in sh.iter_rows())
            else:  # XLS
                sh = self.workbook.sheet_by_name(sheet_name)
                rows = tuple(
                    tuple(sh.cell_value(r, c) for c in range(sh.ncols))
                    for r in range(sh.nrows)
                )
            _logger.info(
                f"Successfully read sheet '{sheet_name}'. Rows read: {len(rows)}"
            )
            return rows
        except Exception as e:
            _logger.error(f"Error reading sheet '{sheet_name}': {e}")
            raise

    def read_sheet_by_index(
        self, index: int = 0
    ) -> tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]:
        """Reads sheet data by 0-based index.

        Args:
            index (int): Sheet index. Defaults to 0 (first sheet).

        Returns:
            tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]: Rows of cell values.

        Raises:
            IndexError: Index out of range.

        Example:
            >>> from fbpyutils.xlsx import ExcelWorkbook
            >>> wb = ExcelWorkbook('/path/to/file.xlsx')
            >>> rows = wb.read_sheet_by_index(1)  # Second sheet
            >>> rows[0]
            ('Col1', 'Col2', 100)
        """
        if not 0 <= index < len(self.sheet_names):
            _logger.error(
                f"Invalid or nonexistent sheet index: {index}. Total sheets: {len(self.sheet_names)}"
            )
            raise IndexError("Sheet index out of range.")

        return self.read_sheet(self.sheet_names[index])


def get_sheet_names(xl_file: Union[str, bytes]) -> list[str]:
    """Retrieves sheet names from Excel file (path or bytes).

    Convenience wrapper around ExcelWorkbook.

    Args:
        xl_file (Union[str, bytes]): File path or bytes.

    Returns:
        list[str]: List of sheet names.

    Example:
        >>> from fbpyutils.xlsx import get_sheet_names
        >>> sheets = get_sheet_names('/path/to/file.xlsx')
        >>> sheets
        ['Sheet1', 'Summary']
    """
    try:
        xl = ExcelWorkbook(xl_file)
        _logger.info(f"Retrieved sheet names from file: {xl.sheet_names}")
        return xl.sheet_names
    except Exception as e:
        _logger.error(f"Error getting sheet names from {xl_file}: {e}")
        raise


def get_sheet_by_name(
    xl_file: Union[str, bytes], sheet_name: str
) -> tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]:
    """Reads specific sheet by name from Excel file (path or bytes).

    Convenience wrapper around ExcelWorkbook.read_sheet.

    Args:
        xl_file (Union[str, bytes]): File path or bytes.
        sheet_name (str): Sheet name.

    Returns:
        tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]: Sheet rows.

    Example:
        >>> from fbpyutils.xlsx import get_sheet_by_name
        >>> rows = get_sheet_by_name('/path/to/file.xlsx', 'Data')
        >>> rows[0]
        ('Name', 'Value', 42.0)
    """
    try:
        xl = ExcelWorkbook(xl_file)
        sheet_content = xl.read_sheet(sheet_name)
        _logger.info(f"Successfully retrieved sheet '{sheet_name}' from file.")
        return sheet_content
    except Exception as e:
        _logger.error(f"Error getting sheet by name '{sheet_name}' from {xl_file}: {e}")
        raise


def get_all_sheets(
    xl_file: Union[str, bytes],
) -> Dict[str, tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]]:
    """Reads all sheets from Excel file into dict of sheet_name: rows.

    Convenience wrapper around ExcelWorkbook for all sheets.

    Args:
        xl_file (Union[str, bytes]): File path or bytes.

    Returns:
        Dict[str, tuple[tuple[Union[str, float, int, bool, datetime, None], ...], ...]]: {sheet_name: rows}.

    Example:
        >>> from fbpyutils.xlsx import get_all_sheets
        >>> all_sheets = get_all_sheets('/path/to/file.xlsx')
        >>> all_sheets.keys()
        dict_keys(['Sheet1', 'Sheet2'])
        >>> all_sheets['Sheet1'][0]
        ('Header', 1.0)
    """
    try:
        xl = ExcelWorkbook(xl_file)
        sheet_names = xl.sheet_names
        all_sheets_content = {
            sheet_name: tuple(xl.read_sheet(sheet_name)) for sheet_name in sheet_names
        }
        _logger.info(
            f"Successfully retrieved all sheets from file: {len(all_sheets_content)} sheets"
        )
        return all_sheets_content
    except Exception as e:
        _logger.error(f"Error getting all sheets from {xl_file}: {e}")
        raise


def write_to_sheet(df: pd.DataFrame, workbook_path: str, sheet_name: str) -> None:
    """Writes DataFrame to Excel sheet, creating new workbook or appending with unique name if exists.

    Uses openpyxl engine, freezes first row, no index. Appends to existing .xlsx, creates indexed name if sheet exists.

    Args:
        df (pd.DataFrame): DataFrame to write.
        workbook_path (str): Path to .xlsx file.
        sheet_name (str): Sheet name; appends number if exists (e.g., 'Data1').

    Example:
        >>> import pandas as pd
        >>> from fbpyutils.xlsx import write_to_sheet
        >>> df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
        >>> write_to_sheet(df, 'output.xlsx', 'Data')
        # Creates output.xlsx with 'Data' sheet.
        >>> df2 = pd.DataFrame({'C': [5]})
        >>> write_to_sheet(df2, 'output.xlsx', 'Data')  # Creates 'Data1'
        # Appends 'Data1' sheet to output.xlsx.
    """
    try:
        if not os.path.exists(workbook_path):
            _logger.info(f"Creating new workbook: {workbook_path} with sheet '{sheet_name}'")
            df.to_excel(
                workbook_path,
                sheet_name=sheet_name,
                index=False,
                freeze_panes=(1, 0),
                header=True,
            )
            _logger.info(
                f"Successfully created new workbook with sheet '{sheet_name}'"
            )
        else:
            _logger.info(f"Appending to existing workbook: {workbook_path}")
            warnings.simplefilter("ignore")
            try:
                with pd.ExcelWriter(
                    workbook_path, engine="openpyxl", mode="a", if_sheet_exists="new"
                ) as writer:
                    temp_book = load_workbook(workbook_path)
                    current_sheet_names = temp_book.sheetnames
                    temp_book.close()

                    final_sheet_name = sheet_name
                    index = 0
                    while final_sheet_name in current_sheet_names:
                        index += 1
                        final_sheet_name = f"{sheet_name}{index}"

                    df.to_excel(
                        writer,
                        sheet_name=final_sheet_name,
                        index=False,
                        freeze_panes=(1, 0),
                        header=True,
                    )
                _logger.info(
                    f"Successfully wrote DataFrame to sheet '{final_sheet_name}' in existing workbook: {workbook_path}"
                )
            except Exception as e:
                _logger.error(
                    f"Error writing to existing Excel workbook {workbook_path}: {e}"
                )
                raise
            finally:
                warnings.simplefilter("default")
    except Exception as e:
        _logger.error(f"Critical error in write_to_sheet: {e}")
        raise
