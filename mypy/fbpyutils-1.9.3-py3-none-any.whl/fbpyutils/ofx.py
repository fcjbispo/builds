"""
OFX Financial Data Processing and Parsing Utilities

This module provides comprehensive OFX (Open Financial Exchange) file processing capabilities
for parsing financial data into structured dictionaries. It supports reading from file paths
or strings with options for native datetime or ISO string date formats, making it suitable
for banking data analysis, financial reporting, and transaction processing workflows.

The module offers four primary capabilities:

* **OFX File Parsing**: Comprehensive parsing of OFX files containing bank statements,
  credit card transactions, and investment account data using the ofxparse library.

* **Date Format Conversion**: Flexible date formatting with support for both native Python
  datetime objects and ISO string representations for different integration needs.

* **Data Structure Extraction**: Structured extraction of account information, institution
  details, statement periods, transaction details, and balance information.

* **CLI Interface**: Command-line interface for parsing and printing OFX files as JSON
  for integration with other tools and workflows.

Key Features:
-------------
* **Multi-Account Support**: Handles bank, credit card, and investment account types
* **Transaction Parsing**: Comprehensive transaction metadata including payee, type, amount, memo
* **Institution Information**: Extracts bank/financial institution details and routing information
* **Date Flexibility**: Choose between native datetime objects or ISO string formats
* **Error Handling**: Robust error handling with graceful degradation for corrupted files
* **CLI Integration**: Command-line interface for file processing and JSON output

Dependencies:
-------------
* `ofxparse`: OFX file parsing library for financial data extraction
* `json`: JSON serialization for CLI output and data export
* `datetime`: Date and time processing for transaction timestamps
* `fbpyutils.uuid`: UUID generation for transaction identification
* `fbpyutils.logging`: Logging infrastructure for operation tracking
* `typing`: Type hints for function parameters and return values

Usage Examples:
---------------
Parse OFX file with native datetime objects:

>>> from fbpyutils.ofx import read_from_path
>>> data = read_from_path('/path/to/bank_statement.ofx')
>>> data['type']
'BANK'
>>> data['statement']['currency']
'USD'
>>> len(data['statement']['transactions'])
15

Parse with ISO string dates:

>>> data = read_from_path('/path/to/statement.ofx', native_date=False)
>>> data['statement']['start_date']
'2023-10-01T00:00:00'

Parse OFX from string:

>>> from fbpyutils.ofx import read
>>> with open('file.ofx', 'rb') as f:
...     data = read(f, native_date=True)
>>> transaction = data['statement']['transactions'][0]
>>> transaction['payee']
'Store Name'
>>> transaction['amount']
-25.50

Format dates for different uses:

>>> from fbpyutils.ofx import format_date
>>> from datetime import datetime
>>> dt = datetime(2023, 10, 15, 10, 30)
>>> format_date(dt, native=True)
datetime.datetime(2023, 10, 15, 10, 30)
>>> format_date(dt, native=False)
'2023-10-15T10:30:00'

Notes:
------
* OFX files must be in valid format for successful parsing
* Transaction IDs are generated using MD5 hashing of account and transaction details
* All monetary amounts are parsed as floats with proper sign handling
* Date parsing handles various OFX date formats automatically
* CLI output uses JSON format for easy integration with other tools

Error Handling:
---------------
* File not found: Returns empty dictionary with error logging
* Corrupted OFX data: Graceful error handling with detailed logging
* Invalid date formats: Error logging with fallback handling
* Missing required fields: Partial data extraction with warning messages

Cross-References:
-----------------
* See `fbpyutils.uuid` for transaction ID generation utilities
* See `fbpyutils.logging` for operation logging and error tracking
* See `fbpyutils.setup()` for proper initialization requirements
"""

from os import path
from ofxparse import OfxParser

import json
import sys
import getopt

from fbpyutils import get_logger, uuid
from typing import Dict, Union
from datetime import datetime

import fbpyutils

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

account_types = ["UNKNOWN", "BANK", "CREDIT_CARD", "INVESTMENT"]
"""List of OFX account type strings corresponding to codes 0-3."""


def format_date(x: datetime, native: bool = True) -> Union[datetime, str]:
    """Formats OFX datetime to native object or ISO string.

    Args:
        x (datetime): OFX datetime object.
        native (bool): If True, returns datetime; False for ISO string. Defaults to True.

    Returns:
        Union[datetime, str]: Native datetime or ISO-formatted string.

    Example:
        >>> from datetime import datetime
        >>> from fbpyutils.ofx import format_date
        >>> dt = datetime(2023, 10, 27, 10, 0)
        >>> format_date(dt, native=True)
        datetime.datetime(2023, 10, 27, 10, 0)
        >>> format_date(dt, native=False)
        '2023-10-27T10:00:00'
    """
    if native:
        return x
    else:
        return x.isoformat()


def read(x, native_date: bool = True) -> Dict:
    """Parses OFX data from file handle or string into structured dictionary.

    Handles bank/credit card statements, institutions, and transactions.
    Uses format_date for date handling.

    Args:
        x: File handle or string with OFX data.
        native_date (bool): True for datetime objects, False for ISO strings. Defaults to True.

    Returns:
        Dict: Parsed OFX data with account, institution, statement (transactions), or {} on error.

    Example:
        >>> from fbpyutils.ofx import read
        >>> with open('file.ofx', 'rb') as f:
        ...     data = read(f)
        >>> data
        {
            'id': '123456',
            'type': 'BANK',
            'institution': {'fid': '999', 'organization': 'BANK NAME'},
            'statement': {
                'start_date': datetime(2023, 10, 1, 0, 0),
                'end_date': datetime(2023, 10, 31, 0, 0),
                'balance': 1000.0,
                'currency': 'USD',
                'transactions': [
                    {
                        'payee': 'Store',
                        'type': 'DEBIT',
                        'date': datetime(2023, 10, 15, 0, 0),
                        'amount': -50.0,
                        'id': 'txn_hash',
                        'memo': 'PURCHASE',
                        ...
                    },
                    ...
                ]
            }
        }
    """
    try:
        ofx = OfxParser.parse(x)
    except Exception as e:
        _logger.error(f"Error parsing OFX data: {e}")
        return {}
    else:
        acct = ofx.account

        ofx_data = {
            "id": acct.account_id,
            "routing_number": acct.routing_number,
            "branch_id": acct.branch_id,
            "type": account_types[acct.type],
            "institution": {},
            "statement": {},
        }

        if acct.institution is not None:
            inst = acct.institution
            ofx_data["institution"] = {
                "fid": inst.fid,
                "organization": inst.organization.upper(),
            }

        if acct.statement is not None:
            stmt = acct.statement
            ofx_data["statement"] = {
                "start_date": format_date(stmt.start_date, native_date),
                "end_date": format_date(stmt.end_date, native_date),
                "balance_date": format_date(stmt.balance_date, native_date),
                "balance": float(stmt.balance),
                "currency": stmt.currency.upper(),
                "transactions": [],
            }

            if len(stmt.transactions) > 0:
                if acct.type in (1, 2):
                    i = 0
                    for transaction in stmt.transactions:
                        trn = {
                            "payee": transaction.payee,
                            "type": transaction.type.upper(),
                            "date": format_date(transaction.date, native_date),
                            "amount": float(transaction.amount),
                            "id": uuid.hash_string(
                                "~".join(
                                    [
                                        acct.account_id,
                                        acct.routing_number,
                                        format_date(stmt.start_date, False),
                                        format_date(stmt.end_date, False),
                                        str(i),
                                    ]
                                )
                            ),
                            "memo": transaction.memo.upper(),
                            "sic": transaction.sic,
                            "mcc": transaction.mcc,
                            "checknum": transaction.checknum,
                        }
                        ofx_data["statement"]["transactions"].append(trn)
                        i = i + 1

        transaction_count = len(ofx_data.get("statement", {}).get("transactions", []))
        _logger.info(
            f"OFX data parsed successfully: account_type={ofx_data.get('type')}, "
            f"transactions={transaction_count}, currency={ofx_data.get('statement', {}).get('currency', 'N/A')}"
        )
        return ofx_data


def read_from_path(x: str, native_date: bool = True) -> Dict:
    """Reads and parses an OFX file from a given path.

    Opens the file in binary mode and passes to read() for parsing.

    Args:
        x (str): Path to the OFX file.
        native_date (bool): True for datetime objects, False for ISO strings. Defaults to True.

    Returns:
        Dict: Parsed OFX data or {} if file not found or error.

    Example:
        >>> from fbpyutils.ofx import read_from_path
        >>> data = read_from_path('/path/to/file.ofx', native_date=False)
        >>> data['statement']['currency']
        'USD'
        >>> data['statement']['transactions'][0]['amount']
        -25.0
    """
    try:
        with open(x, "rb") as f:
            ofx_data = read(f, native_date)
        _logger.info(f"Successfully read OFX data from file: {x}")
        return ofx_data
    except FileNotFoundError:
        _logger.error(f"OFX file not found: {x}")
        return {}
    except OSError as e:
        _logger.error(f"OS error when reading OFX file {x}: {e}")
        return {}
    except Exception as e:
        _logger.error(f"An unexpected error occurred while reading OFX file {x}: {e}")
        raise


# ----


def main(argv):
    """CLI entry point for the OFX module.

    Handles --print <file> to parse and print OFX as JSON, --help for usage.

    Args:
        argv (list): Command-line arguments like sys.argv[1:].

    Example:
        >>> import sys
        >>> from fbpyutils.ofx import main
        >>> main(['--print', '/path/to/file.ofx'])
        {
            "id": "123456",
            "type": "BANK",
            ...
        }
        >>> main(['--help'])
        Use: python -m fbpyutils.ofx --print <file_path>
    """
    _logger.info("OFX module main function started.")
    helper_msg = "Use: python -m fbpyutils.ofx --print <file_path>"
    source_path = ""

    opts, args = [], []
    try:
        opts, args = getopt.getopt(argv, "", ["print=", "help"])
    except getopt.GetoptError:
        _logger.error(f"Invalid command line option. {helper_msg}")
        print(helper_msg)
        sys.exit(2)

    if not opts:
        _logger.warning("No options provided. Displaying helper message and exiting.")
        print(helper_msg)
        sys.exit(2)

    for opt, arg in opts:
        if opt == "--help":
            _logger.info(
                "Help option requested. Displaying helper message and exiting."
            )
            print(helper_msg)
            sys.exit(0)
        elif opt == "--print":
            source_path = arg

    if not source_path and not any(opt[0] == "--help" for opt in opts):
        _logger.error(f"No source path provided for --print option. {helper_msg}")
        print(helper_msg)
        sys.exit(2)

    if source_path:
        if path.exists(source_path):
            _logger.info(f"Processing OFX file: {source_path}")
            try:
                ofx_data = read_from_path(source_path, native_date=False)
                print(json.dumps(ofx_data, sort_keys=True, indent=4))
                _logger.info(
                    f"Successfully processed and printed OFX data from {source_path}."
                )
                sys.exit(0)
            except Exception as e:
                error_msg = (
                    "Invalid or corrupted file: %s" % (source_path.split(path.sep)[-1])
                )
                _logger.error(f"{error_msg}. Exception: {e}")
                print(error_msg)
                sys.exit(2)
        else:
            _logger.error(f"File not found: {source_path}")
            print("File not found.")
            sys.exit(2)
    _logger.info("OFX module main function finished.")


if __name__ == "__main__":
    main(sys.argv[1:])
