"""
Transactions resource for Pluggy API.
"""

from typing import List, Optional
from datetime import date
from ..models.transaction import Transaction
from ..exceptions import PluggyPaginationError
from .base import BaseResource

# Safety cap for cursor pagination (contract: api/extraction-contract.md §3)
MAX_PAGES = 100


class TransactionsResource(BaseResource):
    """Resource for interacting with transactions."""
    
    def list(
        self,
        account_id: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        max_pages: int = MAX_PAGES,
    ) -> List[Transaction]:
        """
        List all transactions for an account (GET /v2/transactions, cursor pagination).
        
        Args:
            account_id: Account ID
            from_date: Optional start date (YYYY-MM-DD) — sent as dateFrom
            to_date: Optional end date (YYYY-MM-DD) — sent as dateTo
            max_pages: Safety cap of pages per call (raises PluggyPaginationError)
            
        Returns:
            List of Transaction objects
            
        Raises:
            PluggyPaginationError: If more than max_pages pages are needed
        """
        params = {"accountId": account_id}
        if from_date:
            params["dateFrom"] = from_date
        if to_date:
            params["dateTo"] = to_date
            
        transactions: List[Transaction] = []
        url = "/v2/transactions"
        pages = 0
        
        while True:
            response = self._client.get(url, params=params)
            data = response.json()
            transactions.extend(
                Transaction(**transaction) for transaction in data.get("results", [])
            )
            pages += 1
            
            next_page = data.get("next")
            if not next_page:
                break
            if pages >= max_pages:
                raise PluggyPaginationError(
                    f"PAGINATION_LIMIT: exceeded {max_pages} pages for account {account_id}"
                )
            # 'next' is a ready-made query string (filters + after cursor),
            # append as-is to the endpoint path — never rebuild 'after' (docs.pluggy.ai)
            url = f"/v2/transactions{next_page}"
            params = None
            
        return transactions
        
    def get(self, transaction_id: str) -> Transaction:
        """
        Get a specific transaction by ID.
        
        Args:
            transaction_id: Transaction ID
            
        Returns:
            Transaction object
        """
        response = self._client.get(f"/transactions/{transaction_id}")
        data = response.json()
        return Transaction(**data)
        
    def update_category(
        self,
        transaction_id: str,
        category_id: str,
    ) -> Transaction:
        """
        Update transaction category.
        
        Args:
            transaction_id: Transaction ID
            category_id: New category ID
            
        Returns:
            Updated Transaction object
        """
        response = self._client.patch(
            f"/transactions/{transaction_id}",
            json={"categoryId": category_id}
        )
        data = response.json()
        return Transaction(**data)