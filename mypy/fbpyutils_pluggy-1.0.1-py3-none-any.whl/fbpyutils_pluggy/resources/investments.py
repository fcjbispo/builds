"""
Investments resource for Pluggy API (GET /investments, page-based).
"""

from typing import List, Optional

from ..models.investment import Investment, InvestmentTransaction
from ..exceptions import PluggyPaginationError
from .base import BaseResource

DEFAULT_PAGE_SIZE = 500
MAX_PAGES = 100


class InvestmentsResource(BaseResource):
    """Resource for investment positions and their transactions."""

    def list(
        self,
        item_id: str,
        type: Optional[str] = None,
        page_size: int = DEFAULT_PAGE_SIZE,
        max_pages: int = MAX_PAGES,
    ) -> List[Investment]:
        """
        List all investment positions of an item (GET /investments).

        Args:
            item_id: Item ID
            type: Optional position type filter (FIXED_INCOME, EQUITY, ...)
            page_size: Records per page (API default 500)
            max_pages: Safety cap of pages per call

        Returns:
            List of Investment objects

        Raises:
            PluggyPaginationError: If more than max_pages pages are needed
        """
        investments: List[Investment] = []
        page = 1

        while True:
            params: dict = {"itemId": item_id, "pageSize": page_size, "page": page}
            if type is not None:
                params["type"] = type
            response = self._client.get("/investments", params=params)
            data = response.json()
            investments.extend(Investment(**inv) for inv in data.get("results", []))

            total_pages = data.get("totalPages") or 1
            if page >= total_pages:
                break
            if page >= max_pages:
                raise PluggyPaginationError(
                    f"PAGINATION_LIMIT: exceeded {max_pages} pages for item {item_id}"
                )
            page += 1

        return investments

    def get_by_id(self, investment_id: str) -> Investment:
        """
        Retrieve one investment position (GET /investments/{id}).

        Args:
            investment_id: Investment ID

        Returns:
            Investment object

        Raises:
            PluggyNotFoundError: If the investment does not exist
        """
        response = self._client.get(f"/investments/{investment_id}")
        return Investment(**response.json())

    def list_transactions(
        self,
        investment_id: str,
        page_size: int = DEFAULT_PAGE_SIZE,
        max_pages: int = MAX_PAGES,
    ) -> List[InvestmentTransaction]:
        """
        List all transactions of an investment (GET /investments/{id}/transactions).

        Args:
            investment_id: Investment ID
            page_size: Records per page (API default 500)
            max_pages: Safety cap of pages per call

        Returns:
            List of InvestmentTransaction objects

        Raises:
            PluggyPaginationError: If more than max_pages pages are needed
        """
        transactions: List[InvestmentTransaction] = []
        page = 1

        while True:
            response = self._client.get(
                f"/investments/{investment_id}/transactions",
                params={"pageSize": page_size, "page": page},
            )
            data = response.json()
            transactions.extend(
                InvestmentTransaction(**tx) for tx in data.get("results", [])
            )

            total_pages = data.get("totalPages") or 1
            if page >= total_pages:
                break
            if page >= max_pages:
                raise PluggyPaginationError(
                    f"PAGINATION_LIMIT: exceeded {max_pages} pages for investment {investment_id}"
                )
            page += 1

        return transactions
