"""
Loans resource for Pluggy API (GET /loans, page-based).
"""

from typing import List

from ..models.loan import Loan
from ..exceptions import PluggyPaginationError
from .base import BaseResource

DEFAULT_PAGE_SIZE = 500
MAX_PAGES = 100


class LoansResource(BaseResource):
    """Resource for interacting with credit operation contracts."""

    def list(
        self,
        item_id: str,
        page_size: int = DEFAULT_PAGE_SIZE,
        max_pages: int = MAX_PAGES,
    ) -> List[Loan]:
        """
        List all loans of an item (GET /loans).

        Args:
            item_id: Item ID
            page_size: Records per page (API default 500)
            max_pages: Safety cap of pages per call

        Returns:
            List of Loan objects

        Raises:
            PluggyPaginationError: If more than max_pages pages are needed
        """
        loans: List[Loan] = []
        page = 1

        while True:
            response = self._client.get(
                "/loans",
                params={"itemId": item_id, "pageSize": page_size, "page": page},
            )
            data = response.json()
            loans.extend(Loan(**loan) for loan in data.get("results", []))

            total_pages = data.get("totalPages") or 1
            if page >= total_pages:
                break
            if page >= max_pages:
                raise PluggyPaginationError(
                    f"PAGINATION_LIMIT: exceeded {max_pages} pages for item {item_id}"
                )
            page += 1

        return loans
