"""
Bills resource for Pluggy API (credit card statements).
"""

from typing import List, Optional
from ..models.bills import Bill
from ..exceptions import PluggyPaginationError
from .base import BaseResource

DEFAULT_PAGE_SIZE = 500
MAX_PAGES = 100


class BillsResource(BaseResource):
    """Resource for interacting with credit card bills."""

    def list(
        self,
        account_id: str,
        page_size: int = DEFAULT_PAGE_SIZE,
        max_pages: int = MAX_PAGES,
    ) -> List[Bill]:
        """
        List all bills for a credit card account (GET /bills, page-based).

        Args:
            account_id: Credit card account ID
            page_size: Records per page (API default 500)
            max_pages: Safety cap of pages per call

        Returns:
            List of Bill objects

        Raises:
            PluggyPaginationError: If more than max_pages pages are needed
        """
        bills: List[Bill] = []
        page = 1

        while True:
            response = self._client.get(
                "/bills",
                params={
                    "accountId": account_id,
                    "pageSize": page_size,
                    "page": page,
                },
            )
            data = response.json()
            bills.extend(Bill(**bill) for bill in data.get("results", []))

            total_pages = data.get("totalPages") or 1
            if page >= total_pages:
                break
            if page >= max_pages:
                raise PluggyPaginationError(
                    f"PAGINATION_LIMIT: exceeded {max_pages} pages for account {account_id}"
                )
            page += 1

        return bills

    def get_by_id(self, bill_id: str) -> Bill:
        """
        Get a specific bill by ID (GET /bills/{id}).

        Args:
            bill_id: Bill ID

        Returns:
            Bill object
        """
        response = self._client.get(f"/bills/{bill_id}")
        return Bill(**response.json())
