"""
Resources for Pluggy API.
"""

from .base import BaseResource
from .connectors import ConnectorsResource
from .items import ItemsResource
from .accounts import AccountsResource
from .transactions import TransactionsResource
from .bills import BillsResource
from .loans import LoansResource
from .investments import InvestmentsResource
from .identity import IdentityResource
from .webhooks import WebhooksResource

__all__ = [
    "BaseResource",
    "ConnectorsResource",
    "ItemsResource",
    "AccountsResource",
    "TransactionsResource",
    "BillsResource",
    "LoansResource",
    "InvestmentsResource",
    "IdentityResource",
    "WebhooksResource",
]