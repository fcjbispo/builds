"""
Investment models for Pluggy API (GET /investments — positions, not account types).
"""

from typing import Any, Dict, List, Optional
from pydantic import ConfigDict, Field
from .base import PluggyModel


class Investment(PluggyModel):
    """Represents an investment position (holding) of an item."""

    model_config = ConfigDict(populate_by_name=True)

    # id/created_at/updated_at inherited from PluggyModel
    item_id: str = Field(alias="itemId")
    type: str  # FIXED_INCOME | EQUITY | MUTUAL_FUND | ETF | COE | CRYPTOCURRENCY | OPTION
    name: str
    balance: float
    currency_code: str = Field(alias="currencyCode")
    date: str  # position date (ISO date-time, JSON-safe)
    subtype: Optional[str] = None
    number: Optional[str] = None
    code: Optional[str] = None
    isin: Optional[str] = None
    value: Optional[float] = None
    quantity: Optional[float] = None
    amount: Optional[float] = None
    amount_profit: Optional[float] = Field(default=None, alias="amountProfit")
    amount_withdrawal: Optional[float] = Field(default=None, alias="amountWithdrawal")
    amount_original: Optional[float] = Field(default=None, alias="amountOriginal")
    taxes: Optional[float] = None
    taxes2: Optional[float] = None
    owner: Optional[str] = None
    issuer: Optional[str] = None
    issuer_cnpj: Optional[str] = Field(default=None, alias="issuerCNPJ")
    status: Optional[str] = None
    due_date: Optional[str] = Field(default=None, alias="dueDate")
    issue_date: Optional[str] = Field(default=None, alias="issueDate")
    purchase_date: Optional[str] = Field(default=None, alias="purchaseDate")
    grace_period_date: Optional[str] = Field(default=None, alias="gracePeriodDate")
    rate: Optional[float] = None
    rate_type: Optional[str] = Field(default=None, alias="rateType")
    fixed_annual_rate: Optional[float] = Field(default=None, alias="fixedAnnualRate")
    annual_rate: Optional[float] = Field(default=None, alias="annualRate")
    last_month_rate: Optional[float] = Field(default=None, alias="lastMonthRate")
    last_twelve_months_rate: Optional[float] = Field(default=None, alias="lastTwelveMonthsRate")
    rate_periodicity: Optional[str] = Field(default=None, alias="ratePeriodicity")
    indexer_additional_info: Optional[str] = Field(default=None, alias="indexerAdditionalInfo")
    tax_exempt: Optional[bool] = Field(default=None, alias="taxExempt")
    price_factor: Optional[float] = Field(default=None, alias="priceFactor")
    debtor: Optional[Dict[str, Any]] = None
    coupon_payment: Optional[Dict[str, Any]] = Field(default=None, alias="couponPayment")
    metadata: Optional[Dict[str, Any]] = None
    institution: Optional[Dict[str, Any]] = None
    transactions: Optional[List[Dict[str, Any]]] = None


class InvestmentTransaction(PluggyModel):
    """Represents a movement of an investment (buy/sell/etc)."""

    model_config = ConfigDict(populate_by_name=True)

    # id inherited from PluggyModel
    type: str  # BUY | SELL | ...
    date: str  # ISO date-time, JSON-safe
    # the endpoint response has no investment id — injected when aggregating
    investment_id: Optional[str] = Field(default=None, alias="investmentId")
    movement_type: Optional[str] = Field(default=None, alias="movementType")
    quantity: Optional[float] = None
    value: Optional[float] = None
    amount: Optional[float] = None
    agreed_rate: Optional[float] = Field(default=None, alias="agreedRate")
    indexer_percentage: Optional[float] = Field(default=None, alias="indexerPercentage")
    price_factor: Optional[float] = Field(default=None, alias="priceFactor")
    trade_date: Optional[str] = Field(default=None, alias="tradeDate")
    expenses: Optional[Dict[str, Any]] = None
    description: Optional[str] = None
    net_amount: Optional[float] = Field(default=None, alias="netAmount")
    brokerage_number: Optional[str] = Field(default=None, alias="brokerageNumber")
