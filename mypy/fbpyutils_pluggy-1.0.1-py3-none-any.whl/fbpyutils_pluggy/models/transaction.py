"""
Transaction model for Pluggy API.
"""

from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import ConfigDict, Field, model_validator
from .base import PluggyModel


class TransactionType(str, Enum):
    """Types of transactions."""
    
    DEBIT = "DEBIT"
    CREDIT = "CREDIT"


class TransactionCategory(str, Enum):
    """Categories of transactions."""
    
    TRANSFER = "TRANSFER"
    SALARY = "SALARY"
    RENT = "RENT"
    LOAN = "LOAN"
    UTILITIES = "UTILITIES"
    TAXES = "TAXES"
    INSURANCE = "INSURANCE"
    HEALTHCARE = "HEALTHCARE"
    EDUCATION = "EDUCATION"
    FOOD = "FOOD"
    TRANSPORT = "TRANSPORT"
    TRAVEL = "TRAVEL"
    ENTERTAINMENT = "ENTERTAINMENT"
    SHOPPING = "SHOPPING"
    SERVICES = "SERVICES"
    INVESTMENTS = "INVESTMENTS"
    OTHER = "OTHER"


class Transaction(PluggyModel):
    """Represents a financial transaction (GET /v2/transactions schema)."""
    
    model_config = ConfigDict(
        populate_by_name=True,
    )
    
    account_id: str = Field(alias="accountId")
    amount: float
    # 'type' is optional in the v2 schema
    type: Optional[TransactionType] = None
    # v2 has no 'name' field — keep the attribute for display, filled from description
    name: Optional[str] = None
    date: datetime
    category: Optional[str] = None
    category_id: Optional[str] = Field(default=None, alias="categoryId")
    payment_data: Optional[Dict[str, Any]] = Field(default=None, alias="paymentData")
    description: Optional[str] = None
    currency_code: Optional[str] = Field(default=None, alias="currencyCode")
    reference: Optional[str] = None
    merchant: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    balance: Optional[float] = None
    credit_card_metadata: Optional[Dict[str, Any]] = Field(
        default=None, alias="creditCardMetadata"
    )

    @model_validator(mode="after")
    def _fill_name_from_description(self) -> "Transaction":
        if not self.name and self.description:
            self.name = self.description
        return self