"""
Bill (credit card statement) models for Pluggy API.
"""

from typing import Optional, List
from pydantic import ConfigDict, Field
from .base import PluggyModel


class BillFinanceCharge(PluggyModel):
    """A charge (IOF, interest, fee) associated to a bill."""

    model_config = ConfigDict(populate_by_name=True)

    type: str
    amount: float
    currency_code: str = Field(alias="currencyCode")
    additional_info: Optional[str] = Field(default=None, alias="additionalInfo")


class BillPayment(PluggyModel):
    """A payment made against a bill."""

    model_config = ConfigDict(populate_by_name=True)

    value_type: str = Field(alias="valueType")
    payment_date: str = Field(alias="paymentDate")  # ISO date, JSON-safe
    amount: float
    currency_code: str = Field(alias="currencyCode")
    payment_mode: Optional[str] = Field(default=None, alias="paymentMode")


class Bill(PluggyModel):
    """Represents a credit card bill (fatura)."""

    model_config = ConfigDict(populate_by_name=True)

    due_date: str = Field(alias="dueDate")  # vencimento (ISO date)
    total_amount: float = Field(alias="totalAmount")
    total_amount_currency_code: str = Field(alias="totalAmountCurrencyCode")
    bill_closing_date: Optional[str] = Field(default=None, alias="billClosingDate")
    minimum_payment_amount: Optional[float] = Field(
        default=None, alias="minimumPaymentAmount"
    )
    allows_installments: Optional[bool] = Field(default=None, alias="allowsInstallments")
    finance_charges: List[BillFinanceCharge] = Field(alias="financeCharges")
    payments: List[BillPayment]

    @property
    def is_closed(self) -> bool:
        """A bill is closed once its closing date exists (docs.pluggy.ai)."""
        return self.bill_closing_date is not None
