"""
Loan model for Pluggy API (GET /loans — own product, not an account type).
"""

from typing import Any, Dict, Optional
from pydantic import ConfigDict, Field
from .base import PluggyModel


class Loan(PluggyModel):
    """Represents a credit operation contract (loan/financing)."""

    model_config = ConfigDict(populate_by_name=True)

    item_id: str = Field(alias="itemId")
    date: Optional[str]  # when the loan data was collected (nullable)
    product_name: str = Field(alias="productName")
    currency_code: str = Field(alias="currencyCode")
    kind: str  # LOAN | FINANCING | INVOICE_FINANCING | UNARRANGED_ACCOUNT_OVERDRAFT
    type: Optional[str] = None
    contract_number: Optional[str] = Field(default=None, alias="contractNumber")
    contract_amount: Optional[float] = Field(default=None, alias="contractAmount")
    contract_date: Optional[str] = Field(default=None, alias="contractDate")
    due_date: Optional[str] = Field(default=None, alias="dueDate")
    installments: Optional[Dict[str, Any]] = None
