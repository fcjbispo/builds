"""
Persistent connection registry (ADR-0008 — single source of state).

Stores the mapping connection name → Pluggy itemId plus consent metadata.
File: ~/.fbpyutils_pluggy/registry.json (atomic writes, 0600).
"""

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from .exceptions import ConnectionNotFoundError

REGISTRY_VERSION = 1
DEFAULT_REGISTRY_PATH = Path.home() / ".fbpyutils_pluggy" / "registry.json"


class Registry:
    """Read/write the registry JSON file."""

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else DEFAULT_REGISTRY_PATH
        self._data: Dict[str, Any] = {"version": REGISTRY_VERSION, "connections": {}}

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "Registry":
        registry = cls(path)
        if registry.path.exists():
            text = registry.path.read_text(encoding="utf-8")
            data = json.loads(text) if text.strip() else {}
            registry._data["connections"] = data.get("connections", {})
        return registry

    @property
    def connections(self) -> Dict[str, Any]:
        return self._data["connections"]

    def save(self) -> None:
        """Atomically write the registry with 0600 permissions."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=".registry-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, self.path)  # atomic; mkstemp already created 0600
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    def resolve(self, name: str) -> Dict[str, Any]:
        """Return the connection entry or raise ConnectionNotFoundError."""
        try:
            return self.connections[name]
        except KeyError:
            raise ConnectionNotFoundError(
                f"CONNECTION_NOT_FOUND: '{name}' not in {self.path}"
            ) from None

    def upsert_connection(
        self,
        name: str,
        item_id: str,
        connector_id: Optional[int] = None,
        consent: Optional[Dict[str, Any]] = None,
        coverage: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        entry = self.connections.get(name, {})
        entry["item_id"] = item_id
        if connector_id is not None:
            entry["connector_id"] = connector_id
        entry["consent"] = consent if consent is not None else entry.get("consent", {})
        entry["coverage"] = coverage if coverage is not None else entry.get("coverage", {})
        self.connections[name] = entry
        return entry

    def set_consent(self, name: str, **fields: Any) -> Dict[str, Any]:
        consent = self.resolve(name).setdefault("consent", {})
        consent.update(fields)
        return consent
