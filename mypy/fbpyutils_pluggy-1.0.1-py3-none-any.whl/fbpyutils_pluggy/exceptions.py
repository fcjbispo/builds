"""
Pluggy SDK exceptions hierarchy.
"""

class PluggyError(Exception):
    """Base exception for Pluggy SDK."""
    pass


class PluggyAuthError(PluggyError):
    """Authentication error (HTTP 401/403)."""
    pass


class PluggyNotFoundError(PluggyError):
    """Resource not found error (HTTP 404)."""
    pass


class PluggyValidationError(PluggyError):
    """Validation error (HTTP 422)."""
    pass


class PluggyRateLimitError(PluggyError):
    """Rate limit exceeded error (HTTP 429)."""
    pass


class PluggyPaginationError(PluggyError):
    """Pagination safety limit exceeded (code: PAGINATION_LIMIT)."""
    pass


class ConnectionNotFoundError(PluggyError):
    """Named connection not found in registry (contract: CONNECTION_NOT_FOUND, exit 2)."""


class ConsentExpiredError(PluggyError):
    """Consent expired or connection broken (contract: CONSENT_EXPIRED, exit 3)."""


class PluggyServerError(PluggyError):
    """Server error (HTTP 5xx)."""
    pass