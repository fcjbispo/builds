"""
connect command: list registered connections with live consent status.
"""

from datetime import datetime, timezone
from typing import Dict, Optional

import typer

from fbpyutils_pluggy.registry import Registry
from fbpyutils_pluggy.exceptions import PluggyError
from fbpyutils_pluggy.cli.utils.client import get_client
from fbpyutils_pluggy.cli.utils.consent import consent_status
from fbpyutils_pluggy.cli.utils.error_handler import handle_error


def connect(
    name: Optional[str] = typer.Argument(
        None, help="Connection name (default: all registered connections)"
    ),
):
    """List registered connections and their real consent status (registry + /items/{id})."""
    try:
        registry = Registry.load()

        if name:
            entries: Dict[str, dict] = {name: registry.resolve(name)}
        else:
            if not registry.connections:
                typer.echo(
                    "No connections registered. Run `fbpyutils-pluggy auth` first."
                )
                return
            entries = dict(registry.connections)

        client = get_client()
        rows = []
        for conn, entry in entries.items():
            item = client.items.get(entry["item_id"])
            status, expires = consent_status(item)
            consent = entry.setdefault("consent", {})
            consent["last_status"] = status
            if expires:
                consent["expires_at"] = expires
            rows.append(
                (conn, entry["item_id"], item.status.value, status, expires or "-")
            )

        registry.save()

        header = ("CONNECTION", "ITEM_ID", "ITEM_STATUS", "CONSENT", "EXPIRES")
        widths = [
            max(len(str(row[i])) for row in [header] + rows)
            for i in range(len(header))
        ]
        typer.echo("  ".join(h.ljust(w) for h, w in zip(header, widths)))
        for row in rows:
            typer.echo("  ".join(str(c).ljust(w) for c, w in zip(row, widths)))
    except PluggyError as error:
        handle_error(error)
    except Exception as error:
        handle_error(error)
