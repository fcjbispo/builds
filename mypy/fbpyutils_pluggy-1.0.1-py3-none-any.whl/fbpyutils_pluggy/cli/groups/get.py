"""
get command: on-demand extraction to the JSON envelope (extraction-contract@1.0.0).
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import NoReturn, Optional

import typer

from fbpyutils_pluggy.registry import Registry
from fbpyutils_pluggy.exceptions import (
    ConnectionNotFoundError,
    ConsentExpiredError,
)
from fbpyutils_pluggy.cli.utils.client import get_client
from fbpyutils_pluggy.cli.utils.consent import consent_status
from fbpyutils_pluggy.cli.utils.error_handler import handle_error

CONTRACT_TAG = "extraction-contract@1.0.0"


def _contract_error(code: str, message: str, exit_code: int) -> NoReturn:
    payload = {"error": {"code": code, "message": message, "detail": {}}}
    typer.echo(json.dumps(payload, ensure_ascii=False), err=True)
    raise typer.Exit(exit_code)


def _is_yyyy_mm(value: str) -> bool:
    return len(value) == 7 and value[4] == "-" and value[:4].isdigit() and value[5:].isdigit()


def _find_bill(client, accounts, due_date, bill_id, connection):
    """Find the bill matching --due-date (YYYY-MM prefix) or --bill-id (contract §4)."""
    credit_accounts = [a for a in accounts if a.type and a.type.value == "CREDIT"]
    for account in credit_accounts or accounts:
        for bill in client.bills.list(str(account.id)):
            if bill_id and bill.id == bill_id:
                return bill
            if due_date and bill.due_date.startswith(due_date):
                return bill
    wanted = due_date or bill_id
    _contract_error(
        "BILL_NOT_FOUND",
        f"no bill matches {wanted} for connection '{connection}'",
        1,
    )


def get(
    connection: str = typer.Argument(..., help="Connection name from the registry"),
    item_id: Optional[str] = typer.Option(
        None, "--item-id", help="Use this itemId instead of the registry"
    ),
    from_date: Optional[str] = typer.Option(
        None, "--from", help="Window start, YYYY-MM-DD (modality A)"
    ),
    to_date: Optional[str] = typer.Option(
        None, "--to", help="Window end, YYYY-MM-DD (modality A)"
    ),
    due_date: Optional[str] = typer.Option(
        None, "--due-date", help="Bill due date, YYYY-MM (modality B)"
    ),
    bill_id: Optional[str] = typer.Option(
        None, "--bill-id", help="Bill ID (modality B)"
    ),
    output_to: Optional[Path] = typer.Option(
        None, "--output-to", help="Write JSON to file instead of stdout"
    ),
):
    """Extract accounts + transactions for a connection (contract envelope)."""
    # --- argument validation (outside try: contract exit codes, no handler) ---
    modality_a = bool(from_date or to_date)
    modality_b = bool(due_date or bill_id)

    if modality_a and modality_b:
        _contract_error(
            "USAGE_MIXED_MODALITIES",
            "Do not mix period (--from/--to) and bill (--due-date/--bill-id) arguments",
            2,
        )
    if not modality_a and not modality_b:
        raise typer.BadParameter(
            "Provide a period (--from + --to) or a bill (--due-date or --bill-id)"
        )
    if modality_a and not (from_date and to_date):
        raise typer.BadParameter("Modality A requires both --from and --to")
    if due_date and not _is_yyyy_mm(due_date):
        raise typer.BadParameter("--due-date must be YYYY-MM")

    try:
        registry = Registry.load()
        resolved_id = item_id if item_id else registry.resolve(connection)["item_id"]

        client = get_client()

        # consent gate: live check BEFORE any extraction call (contract §4)
        item = client.items.get(resolved_id)
        status, _ = consent_status(item)
        if status != "CONNECTED":
            raise ConsentExpiredError(
                f"consent is {status} — run `fbpyutils-pluggy auth {connection}` again"
            )

        accounts = client.accounts.list(item_id=resolved_id)

        modality = "A"
        window = {"from": from_date, "to": to_date}
        bill_out = None
        if modality_a:
            transactions = []
            for account in accounts:
                transactions.extend(
                    client.transactions.list(str(account.id), from_date, to_date)
                )
        else:
            modality = "B"
            window = {"due_date": due_date} if due_date else {"bill_id": bill_id}
            bill = _find_bill(client, accounts, due_date, bill_id, connection)
            # transactions window = closing → due (open bill: month start of due date)
            tx_from = bill.bill_closing_date or f"{bill.due_date[:7]}-01"
            tx_to = bill.due_date
            transactions = []
            for account in accounts:
                transactions.extend(
                    client.transactions.list(str(account.id), tx_from, tx_to)
                )
            # client-side grouping: v2 has no billId filter (ADR-0009)
            transactions = [
                t
                for t in transactions
                if (t.credit_card_metadata or {}).get("billId") == bill.id
            ]
            bill_out = bill

        data = {
            "accounts": [a.model_dump(mode="json", by_alias=True) for a in accounts],
            "transactions": [
                t.model_dump(mode="json", by_alias=True) for t in transactions
            ],
        }
        if bill_out is not None:
            data["bills"] = [bill_out.model_dump(mode="json", by_alias=True)]

        envelope = {
            "meta": {
                "generated_at": datetime.now(timezone.utc)
                .isoformat()
                .replace("+00:00", "Z"),
                "item_id": resolved_id,
                "connection": connection,
                "modality": modality,
                "window": window,
                "contract": CONTRACT_TAG,
            },
            "data": data,
        }

        # registry coverage: record extraction date (contract §5)
        entry = registry.connections.get(connection)
        if entry and entry.get("item_id") == resolved_id:
            today = datetime.now(timezone.utc).date().isoformat()
            extractions = entry.setdefault("coverage", {}).setdefault(
                "last_extractions", []
            )
            if today not in extractions:
                extractions.append(today)
            registry.save()

        output = json.dumps(envelope, ensure_ascii=False, indent=2)
        if output_to:
            try:
                output_to.write_text(output + "\n", encoding="utf-8")
            except OSError as error:
                _contract_error(
                    "OUTPUT_WRITE_FAIL", f"could not write {output_to}: {error}", 1
                )
        else:
            typer.echo(output)
    except typer.Exit:
        raise  # contract exit codes from _contract_error must not be re-handled
    except (ConsentExpiredError, ConnectionNotFoundError) as error:
        handle_error(error)
    except Exception as error:
        handle_error(error)
