"""
auth command: register a connection (itemId copied from Dashboard) in the registry.
"""

from datetime import datetime, timezone
from typing import Optional

import typer

from fbpyutils_pluggy.registry import Registry
from fbpyutils_pluggy.exceptions import PluggyError
from fbpyutils_pluggy.cli.utils.client import get_client
from fbpyutils_pluggy.cli.utils.consent import consent_status
from fbpyutils_pluggy.cli.utils.error_handler import handle_error


def auth(
    name: str = typer.Argument(..., help="Connection name (e.g. itau)"),
    item_id: str = typer.Option(
        ...,
        "--item-id",
        "-i",
        help="itemId copied from the Pluggy Dashboard (Meu Pluggy guide, step 3)",
    ),
    connector_id: Optional[int] = typer.Option(
        None, "--connector-id", help="Connector ID (default: from the live item)"
    ),
):
    """Validate a Dashboard itemId against the API and register it in the registry."""
    try:
        client = get_client()
        item = client.items.get(item_id)  # live validation + consent info
        status, expires = consent_status(item)

        registry = Registry.load()
        created = name not in registry.connections
        registry.upsert_connection(
            name,
            item_id=item_id,
            connector_id=connector_id if connector_id is not None else item.connector_id,
            consent={
                "created_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": expires,
                "last_status": status,
            },
        )
        registry.save()

        verb = "Registered" if created else "Updated"
        extra = f", expires {expires}" if expires else ""
        typer.echo(f"{verb} '{name}' → {item_id} (consent: {status}{extra})")
    except PluggyError as error:
        handle_error(error)
    except Exception as error:
        handle_error(error)
