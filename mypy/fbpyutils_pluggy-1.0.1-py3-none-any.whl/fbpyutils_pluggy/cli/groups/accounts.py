"""
Accounts commands for Pluggy CLI.

Commands for managing financial accounts.
"""

import typer

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat


app = typer.Typer(
    name="accounts",
    help="Commands for managing financial accounts.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment.
    
    Priority:
    1. FBPY_PLUGGY_CLIENT_ID / FBPY_PLUGGY_CLIENT_SECRET
    2. PLUGGY_CLIENT_ID / PLUGGY_CLIENT_SECRET (fallback)
    """
    import os
    
    # Try new env vars first, then fallback to old ones
    client_id = os.getenv("FBPY_PLUGGY_CLIENT_ID") or os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("FBPY_PLUGGY_CLIENT_SECRET") or os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "Environment variables not set.\n\n"
            "Please set:\n"
            "  FBPY_PLUGGY_CLIENT_ID (or PLUGGY_CLIENT_ID)\n"
            "  FBPY_PLUGGY_CLIENT_SECRET (or PLUGGY_CLIENT_SECRET)\n\n"
            "Get your credentials at: https://dashboard.pluggy.ai"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


@app.command(name="list")
def list_accounts(
    item_id: str = typer.Option(
        ...,
        "--item",
        "-i",
        help="Item ID",
        prompt="Item ID",
    ),
    account_type: str = typer.Option(
        None,
        "--type",
        "-t",
        help="Filter by account type (BANK, CREDIT, INVESTMENT)",
    ),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    List accounts for an item.
    
    Examples:
        fbpyutils-pluggy accounts list --item item-123
        fbpyutils-pluggy accounts list --item item-123 --type BANK
    """
    try:
        with get_client() as client:
            accounts = client.accounts.list(
                item_id=item_id,
                type=account_type,
            )
            
            if not accounts:
                typer.echo("No accounts found.")
                return
            
            format_output(
                accounts,
                format=output,
                title=f"Accounts for Item {item_id}",
                columns=["id", "name", "type", "subtype", "balance", "currency_code"],
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="get")
def get_account(
    account_id: str = typer.Argument(..., help="Account ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE,
        "--output",
        "-o",
        help="Output format",
    ),
):
    """
    Get details of a specific account.
    
    Examples:
        fbpyutils-pluggy accounts get account-123
    """
    try:
        with get_client() as client:
            account = client.accounts.get(account_id)
            
            format_output(
                account,
                format=output,
                title=f"Account: {account.name}",
            )
            
    except Exception as e:
        handle_error(e)


@app.command(name="balance")
def get_balance(
    account_id: str = typer.Argument(..., help="Account ID"),
):
    """
    Get real-time balance for an account.
    
    Examples:
        fbpyutils-pluggy accounts balance account-123
    """
    try:
        with get_client() as client:
            balance = client.accounts.get_balance(account_id)
            
            typer.echo(f"Balance: {balance['balance']} {balance['currencyCode']}")
            
    except Exception as e:
        handle_error(e)