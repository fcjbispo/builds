"""
Error handling utilities for CLI.
"""

import json
import sys
import typer
from typing import Optional

from ...exceptions import (
    PluggyError,
    PluggyAuthError,
    PluggyNotFoundError,
    PluggyValidationError,
    PluggyRateLimitError,
    PluggyServerError,
    PluggyPaginationError,
    ConnectionNotFoundError,
    ConsentExpiredError,
)


def handle_error(error: Exception, message: Optional[str] = None) -> None:
    """
    Handle errors with appropriate user-friendly messages.

    Args:
        error: The exception that occurred
        message: Optional custom message to display
    """
    if isinstance(error, ConnectionNotFoundError):
        # contract §4: CONNECTION_NOT_FOUND → exit 2, JSON error on stderr
        payload = {
            "error": {
                "code": "CONNECTION_NOT_FOUND",
                "message": str(error),
                "detail": {},
            }
        }
        typer.echo(json.dumps(payload, ensure_ascii=False), err=True)
        sys.exit(2)

    if isinstance(error, ConsentExpiredError):
        # contract §4: CONSENT_EXPIRED → exit 3, JSON error on stderr
        payload = {
            "error": {"code": "CONSENT_EXPIRED", "message": str(error), "detail": {}}
        }
        typer.echo(json.dumps(payload, ensure_ascii=False), err=True)
        sys.exit(3)

    if isinstance(error, PluggyAuthError):
        # contract §4: PLUGGY_AUTH_FAILED → exit 4, JSON error on stderr
        payload = {
            "error": {"code": "PLUGGY_AUTH_FAILED", "message": str(error), "detail": {}}
        }
        typer.echo(json.dumps(payload, ensure_ascii=False), err=True)
        sys.exit(4)
        
    elif isinstance(error, PluggyNotFoundError):
        typer.echo(f"❌ Not found: {error}", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyValidationError):
        typer.echo(f"❌ Validation error: {error}", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyRateLimitError):
        typer.echo(f"⏳ Rate limit exceeded. Please wait before retrying.", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyServerError):
        typer.echo(f"🔥 Server error: {error}", err=True)
        typer.echo("💡 This is a temporary issue. Please try again later.", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyPaginationError):
        typer.echo(f"❌ PAGINATION_LIMIT: {error}", err=True)
        sys.exit(1)
        
    elif isinstance(error, PluggyError):
        typer.echo(f"❌ Pluggy error: {error}", err=True)
        sys.exit(1)
        
    else:
        # Generic error
        error_msg = message or str(error)
        typer.echo(f"❌ Error: {error_msg}", err=True)
        sys.exit(1)