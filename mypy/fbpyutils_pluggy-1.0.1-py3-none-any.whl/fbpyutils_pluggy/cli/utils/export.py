"""
Export utilities for financial data.
"""

import json
import csv
from pathlib import Path
from typing import List, Any, Union
import os

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


def export_to_json(data: Union[List[Any], dict], filepath: Path) -> None:
    """Export data to JSON file.
    
    Args:
        data: Data to export (list of dicts or dict)
        filepath: Path to output file
    """
    # Ensure parent directory exists
    filepath.parent.mkdir(parents=True, exist_ok=True)

    # Convert Pydantic models to plain JSON data
    if isinstance(data, list) and data and hasattr(data[0], "model_dump"):
        data = [item.model_dump(mode="json", by_alias=True) for item in data]
    elif hasattr(data, "model_dump"):
        data = data.model_dump(mode="json", by_alias=True)

    # Convert to JSON and save
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)


def export_to_csv(data: Union[List[Any], dict], filepath: Path) -> None:
    """Export data to CSV file.
    
    Args:
        data: Data to export (list of dicts or dict)
        filepath: Path to output file
    """
    # Ensure parent directory exists
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    # Handle single dict by converting to list
    if isinstance(data, dict):
        data = [data]
    
    # Handle empty data
    if not data:
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            pass  # Create empty file
        return
    
    # Extract fieldnames from first item
    fieldnames = []
    if data and isinstance(data[0], dict):
        fieldnames = list(data[0].keys())
    elif hasattr(data[0], '__dict__'):
        fieldnames = list(data[0].__dict__.keys())
    
    # Write CSV
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for item in data:
            if isinstance(item, dict):
                writer.writerow(item)
            elif hasattr(item, '__dict__'):
                writer.writerow(item.__dict__)
            else:
                # Handle primitive values
                writer.writerow({'value': str(item)})


def export_to_xlsx(data: Union[List[Any], dict], filepath: Path, sheet_name: str = "Data") -> None:
    """Export data to Excel file.
    
    Args:
        data: Data to export (list of dicts or dict)
        filepath: Path to output file
        sheet_name: Name of the sheet to create
    """
    if not PANDAS_AVAILABLE:
        raise ImportError("pandas is required for XLSX export. Install with: pip install pandas openpyxl")
    
    # Ensure parent directory exists
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    # Handle single dict by converting to list
    if isinstance(data, dict):
        data = [data]
    
    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    # Save to Excel
    df.to_excel(filepath, sheet_name=sheet_name, index=False)


def auto_export(data: Any, filepath: Path) -> None:
    """Auto-detect format from extension and export.
    
    Args:
        data: Data to export (list of dicts/models, single dict, or single model)
        filepath: Path to output file with extension
    """
    # Ensure filepath is a Path object
    if isinstance(filepath, str):
        filepath = Path(filepath)
    
    # Get extension
    ext = filepath.suffix.lower()
    
    # Export based on extension
    if ext == '.json':
        export_to_json(data, filepath)
    elif ext == '.csv':
        export_to_csv(data, filepath)
    elif ext in ['.xlsx', '.xls']:
        export_to_xlsx(data, filepath)
    else:
        # Default to JSON
        export_to_json(data, filepath.with_suffix('.json'))


def validate_iso_date(date_str: str) -> bool:
    """Validate that a string is in ISO date format (YYYY-MM-DD).
    
    Args:
        date_str: Date string to validate
        
    Returns:
        True if valid ISO date, False otherwise
    """
    if not date_str:
        return True
    
    try:
        from datetime import datetime
        datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False


def create_output_directory(filepath: Path) -> None:
    """Create output directory if it doesn't exist.
    
    Args:
        filepath: Path to output file
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)
