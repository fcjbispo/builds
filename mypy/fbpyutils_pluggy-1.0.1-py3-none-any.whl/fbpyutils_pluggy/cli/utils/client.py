"""
Shared CLI helper to build a PluggyClient from environment.
"""

import os

import typer

from fbpyutils_pluggy import PluggyClient


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment.

    Priority:
    1. FBPY_PLUGGY_CLIENT_ID / FBPY_PLUGGY_CLIENT_SECRET
    2. PLUGGY_CLIENT_ID / PLUGGY_CLIENT_SECRET (fallback)
    """
    client_id = os.getenv("FBPY_PLUGGY_CLIENT_ID") or os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("FBPY_PLUGGY_CLIENT_SECRET") or os.getenv(
        "PLUGGY_CLIENT_SECRET"
    )

    if not client_id or not client_secret:
        raise typer.BadParameter(
            "Environment variables not set.\n\n"
            "Please set:\n"
            "  FBPY_PLUGGY_CLIENT_ID (or PLUGGY_CLIENT_ID)\n"
            "  FBPY_PLUGGY_CLIENT_SECRET (or PLUGGY_CLIENT_SECRET)\n\n"
            "Get your credentials at: https://dashboard.pluggy.ai"
        )

    return PluggyClient(client_id=client_id, client_secret=client_secret)
