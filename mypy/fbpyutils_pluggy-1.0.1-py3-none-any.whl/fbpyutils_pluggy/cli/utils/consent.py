"""
Consent status helpers shared by the auth/connect/get commands (contract §4/§5).
"""

from datetime import datetime, timezone
from typing import Optional, Tuple


def _parse_iso(value: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def consent_status(item) -> Tuple[str, Optional[str]]:
    """Derive contract consent status (CONNECTED|EXPIRED|...) from a live item.

    Returns:
        (status, expires_at)
    """
    expires = item.consent_expires_at
    if expires:
        parsed = _parse_iso(expires)
        if parsed and parsed <= datetime.now(timezone.utc):
            return "EXPIRED", expires
    if item.status and item.status.value == "UPDATED":
        return "CONNECTED", expires
    return (item.status.value if item.status else "UNKNOWN"), expires
