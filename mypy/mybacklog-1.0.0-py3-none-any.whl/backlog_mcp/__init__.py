"""MyBacklogManager MCP Server package."""

from backlog_mcp.server import mcp

__all__ = ["mcp"]
