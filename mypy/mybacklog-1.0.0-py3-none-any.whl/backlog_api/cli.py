"""MyBacklogManager CLI — Manages build, execution, and container lifecycle."""

from __future__ import annotations

import importlib.metadata
import os
import shutil
import subprocess
import sys
from pathlib import Path

import typer
from typing_extensions import Annotated


def _get_version() -> str:
    """Read version from package metadata."""
    try:
        return importlib.metadata.version("mybacklog")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

APP_NAME = "MyBacklogManager"
IMAGE_NAME = "mybacklog"
IMAGE_TAG = "latest"
CONTAINER_NAME = "mybacklog"
API_PORT = 8833
WEB_PORT = 8834
DATA_DIR = Path.cwd()

GREEN = typer.colors.GREEN
YELLOW = typer.colors.YELLOW
BLUE = typer.colors.BLUE
RED = typer.colors.RED

SYSTEMD_USER_DIR = Path.home() / ".config" / "systemd" / "user"
SYSTEMD_SERVICE_NAME = f"{CONTAINER_NAME}.service"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _info(msg: str) -> None:
    typer.secho(f"[INFO] {msg}", fg=BLUE)


def _ok(msg: str) -> None:
    typer.secho(f"[OK] {msg}", fg=GREEN)


def _warn(msg: str) -> None:
    typer.secho(f"[AVISO] {msg}", fg=YELLOW, err=True)


def _err(msg: str) -> None:
    typer.secho(f"[ERRO] {msg}", fg=RED, err=True)


def _run(cmd: list[str], check: bool = True, capture: bool = False) -> str:
    """Execute command via subprocess."""
    result = subprocess.run(
        cmd,
        check=check,
        capture_output=capture,
        text=True,
    )
    return result.stdout.strip() if capture else ""


def _check_podman() -> None:
    """Check if Podman is installed."""
    if not shutil.which("podman"):
        _err("Podman not found. Install with: sudo dnf install podman")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

app = typer.Typer(
    name=APP_NAME,
    help="CLI to manage MyBacklogManager via Podman.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"{APP_NAME} {_get_version()}")
        raise typer.Exit()


@app.callback()
def _main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    """Callback for global options."""
    pass


@app.command()
def build() -> None:
    """Build Podman image."""
    _check_podman()
    _info(f"Building image {IMAGE_NAME}:{IMAGE_TAG}...")
    try:
        _run(["podman", "build", "-t", f"{IMAGE_NAME}:{IMAGE_TAG}", "."])
        _ok("Build complete!")
    except subprocess.CalledProcessError as e:
        _err(f"Build failed: {e}")
        raise typer.Exit(1)


@app.command()
def run(
    api_port: Annotated[int, typer.Option("--api-port", help="API port")] = API_PORT,
    web_port: Annotated[int, typer.Option("--web-port", help="Web frontend port")] = WEB_PORT,
) -> None:
    """Run container with API + React frontend."""
    _check_podman()
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if _container_exists():
        _warn("Removing previous container...")
        _run(["podman", "rm", "-f", CONTAINER_NAME], check=False)

    _info("Starting container...")
    _info(f"API: http://localhost:{api_port}")
    _info(f"Web: http://localhost:{web_port}")

    try:
        _run(
            [
                "podman", "run",
                "--detach",
                "--name", CONTAINER_NAME,
                "--publish", f"{api_port}:{api_port}",
                "--publish", f"{web_port}:{web_port}",
                "--volume", f"{DATA_DIR}/backlog.db:/app/backlog.db:Z",
                "--restart", "unless-stopped",
                f"{IMAGE_NAME}:{IMAGE_TAG}",
            ]
        )
        _ok("Container started!")
        import time
        time.sleep(2)
        _run(
            [
                "podman", "ps",
                "--filter", f"name={CONTAINER_NAME}",
                "--format", "table {{.Names}}\t{{.Status}}\t{{.Ports}}",
            ]
        )
    except subprocess.CalledProcessError as e:
        _err(f"Failed to start container: {e}")
        raise typer.Exit(1)


@app.command()
def api(
    port: Annotated[int, typer.Option("--port", "-p", help="API port")] = API_PORT,
    host: Annotated[str, typer.Option("--host", "-h", help="Bind host")] = "127.0.0.1",
) -> None:
    """Run API locally (without container)."""
    _info(f"Starting API at http://{host}:{port}")
    try:
        os.execvp(
            "uv",
            [
                "uv", "run", "uvicorn", "backlog_api.app.main:app",
                "--host", host,
                "--port", str(port),
                "--reload",
                "--log-level", "info",
            ],
        )
    except FileNotFoundError:
        _err("Command 'uv' not found. Install uv.")
        raise typer.Exit(1)


@app.command()
def web(
    port: Annotated[int, typer.Option("--port", "-p", help="Vite dev server port")] = 5173,
    host: Annotated[str, typer.Option("--host", "-h", help="Bind host")] = "0.0.0.0",
    api_url: Annotated[str, typer.Option("--api-url", help="API URL for proxy")] = "http://localhost:8833",
) -> None:
    """Run Vite dev server locally (requires API running)."""
    _warn(f"Make sure the API is running at {api_url}")
    _info(f"Starting Vite dev server at http://{host}:{port}")
    js_dir = Path(__file__).resolve().parents[1] / "backlog_manager_js"
    if not (js_dir / "package.json").exists():
        _err(f"Frontend directory not found: {js_dir}")
        raise typer.Exit(1)
    env = os.environ.copy()
    env["VITE_API_URL"] = api_url
    try:
        os.chdir(js_dir)
        os.execvpe(
            "npx",
            ["npx", "vite", f"--port={port}", f"--host={host}"],
            env,
        )
    except FileNotFoundError:
        _err("Command 'npx' not found. Install Node.js.")
        raise typer.Exit(1)


@app.command()
def stop() -> None:
    """Stop the container."""
    if _container_exists():
        _run(["podman", "stop", CONTAINER_NAME])
        _ok("Container stopped.")
    else:
        _warn("Container is not running.")


@app.command()
def logs(
    follow: Annotated[bool, typer.Option("--follow", "-f", help="Follow logs in real time")] = False,
    tail: Annotated[int, typer.Option("--tail", "-n", help="Number of lines at the end")] = 100,
) -> None:
    """Show container logs."""
    if not _container_exists():
        _warn("Container not found.")
        return
    cmd = ["podman", "logs", f"--tail={tail}"]
    if follow:
        cmd.append("--follow")
    cmd.append(CONTAINER_NAME)
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        typer.echo()


@app.command()
def clean() -> None:
    """Remove container and image."""
    _check_podman()

    if _container_exists():
        _run(["podman", "rm", "-f", CONTAINER_NAME], check=False)
        _ok("Container removed.")
    else:
        _warn("No container to remove.")

    if _image_exists():
        _run(["podman", "rmi", f"{IMAGE_NAME}:{IMAGE_TAG}"], check=False)
        _ok("Image removed.")
    else:
        _warn("No image to remove.")


@app.command()
def clean_db(
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Confirm without prompt")] = False,
) -> None:
    """Remove local database (backlog.db)."""
    db_path = DATA_DIR / "backlog.db"

    if not db_path.exists():
        _warn("No local database found.")
        return

    if not confirm:
        _warn(f"This will permanently delete: {db_path}")
        choice = typer.prompt("Are you sure? [y/N]", default="N")
        if choice.lower() not in ("s", "sim", "y", "yes"):
            _info("Operation cancelled.")
            return

    try:
        db_path.unlink()
        _ok("Local database removed.")
    except OSError as e:
        _err(f"Failed to remove database: {e}")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Systemd user service
# ---------------------------------------------------------------------------


def _container_exists() -> bool:
    """Check if container exists."""
    result = subprocess.run(
        ["podman", "container", "exists", CONTAINER_NAME],
        capture_output=True,
    )
    return result.returncode == 0


def _image_exists() -> bool:
    """Check if image exists."""
    result = subprocess.run(
        ["podman", "image", "exists", f"{IMAGE_NAME}:{IMAGE_TAG}"],
        capture_output=True,
    )
    return result.returncode == 0


SYSTEMD_SERVICE_TEMPLATE = """[Unit]
Description=MyBacklogManager (Podman)
After=network-online.target
Wants=network-online.target

[Service]
Restart=always
ExecStartPre=-/usr/bin/podman rm -f {container_name}
ExecStart=/usr/bin/podman run \\
    --name {container_name} \\
    --publish {api_port}:{api_port} \\
    --publish {web_port}:{web_port} \\
    --volume {data_dir}/backlog.db:/app/backlog.db:Z \\
    --restart unless-stopped \\
    {image_name}:{image_tag}
ExecStop=/usr/bin/podman stop -t 10 {container_name}
ExecStopPost=-/usr/bin/podman rm -f {container_name}

[Install]
WantedBy=default.target
"""


@app.command()
def enable() -> None:
    """Configure auto-start via systemd user service."""
    _check_podman()
    SYSTEMD_USER_DIR.mkdir(parents=True, exist_ok=True)

    service_path = SYSTEMD_USER_DIR / SYSTEMD_SERVICE_NAME
    service_content = SYSTEMD_SERVICE_TEMPLATE.format(
        container_name=CONTAINER_NAME,
        image_name=IMAGE_NAME,
        image_tag=IMAGE_TAG,
        api_port=API_PORT,
        web_port=WEB_PORT,
        data_dir=DATA_DIR,
    )
    service_path.write_text(service_content)
    _ok(f"Service created at {service_path}")

    try:
        _run(["systemctl", "--user", "daemon-reload"])
        _run(["systemctl", "--user", "enable", SYSTEMD_SERVICE_NAME])
        _ok("Service enabled for auto-start.")
        _info("Use 'systemctl --user start mybacklog' to start now.")
    except subprocess.CalledProcessError as e:
        _err(f"Failed to enable service: {e}")
        raise typer.Exit(1)


@app.command()
def disable() -> None:
    """Remove auto-start via systemd user service."""
    service_path = SYSTEMD_USER_DIR / SYSTEMD_SERVICE_NAME
    if not service_path.exists():
        _warn("Systemd service not found.")
        return

    try:
        _run(["systemctl", "--user", "stop", SYSTEMD_SERVICE_NAME], check=False)
        _run(["systemctl", "--user", "disable", SYSTEMD_SERVICE_NAME], check=False)
        service_path.unlink()
        _run(["systemctl", "--user", "daemon-reload"])
        _ok("Service disabled and removed.")
    except subprocess.CalledProcessError as e:
        _err(f"Failed to disable service: {e}")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    app()


if __name__ == "__main__":
    main()