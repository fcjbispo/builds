"""Entry point da API FastAPI."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backlog_api.app.database import init_database
from backlog_api.app.routers import items

# Inicializa banco na importação
init_database()

app = FastAPI(
    title="MyBacklogManager API",
    description="API REST para gerenciamento de backlogs de projetos",
    version="1.0.0",
)

# CORS para permitir acesso do frontend React
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registra routers
app.include_router(items.router)


@app.get("/health")
def health_check() -> dict:
    """Endpoint de health check."""
    return {"status": "ok", "service": "mybacklog-api"}


@app.get("/")
def root() -> dict:
    """Raiz da API."""
    return {
        "message": "MyBacklogManager API",
        "docs": "/docs",
        "redoc": "/redoc",
    }
