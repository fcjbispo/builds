#!/usr/bin/env python3
"""
InfoBR ELT Pipeline TUI CLI

Interface de linha de comando interativa para gerenciar e executar pipelines ELT.

Usage:
    python -m infobr.data.elt                    # Modo interativo TUI
    python -m infobr.data.elt -p series.extract  # Executar pipeline diretamente
    python -m infobr.data.elt -l                 # Listar pipelines disponíveis
    python -m infobr.data.elt --health           # Health check (sem autenticação)

Modo batch (sem prompt interativo):
    INFOBR_USERNAME=admin INFOBR_PASSWD=secret python -m infobr.data.elt -l
    INFOBR_USERNAME=admin INFOBR_PASSWD=secret python -m infobr.data.elt -p series.extract.FX

Autenticação e admin (via API REST):
    INFOBR_USERNAME=admin INFOBR_PASSWD=secret python -m infobr.data.elt --list-tokens
"""

import os
import sys
import time
import json
import argparse
from datetime import datetime, timedelta, timezone
from importlib.metadata import version as get_version
from typing import Any, List, Tuple

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.prompt import Prompt, Confirm
from rich import box

from infobr import logger, env
from infobr.api.client import ApiClient, ApiResult

console = Console()


def _data(result: ApiResult) -> dict[str, Any]:
    """Return the result data as a dict, tolerating None."""
    return result.data if isinstance(result.data, dict) else {}


class ELT_TUI:
    """
    Terminal User Interface for InfoBR ELT Pipelines.
    """

    POLL_INTERVAL_SECONDS = 2.0
    POLL_TIMEOUT_SECONDS = 3600

    def __init__(self, api_client: ApiClient):
        self.client = api_client
        self.token: str = ""
        self.profile: str | None = None
        self.pipelines: List[Tuple[str, str]] = []
        self.selected_pipeline: str | None = None

    @property
    def is_admin(self) -> bool:
        """Whether the authenticated token carries the ADMIN profile."""
        return self.profile == "ADMIN"

    def clear_screen(self):
        """Clear terminal screen."""
        console.clear()

    def authenticate(self) -> bool:
        """Authenticate with the API and store the bearer token.

        Reads credentials from INFOBR_USERNAME and INFOBR_PASSWD env vars
        (batch mode). Falls back to interactive prompt if env vars are not set.
        """
        email = os.environ.get("INFOBR_USERNAME", "").strip()
        password = os.environ.get("INFOBR_PASSWD", "").strip()

        if email and password:
            console.print("[dim]🔐 Autenticação via variáveis de ambiente[/dim]")
        else:
            console.print("[cyan]🔐 Autenticação API[/cyan]")
            console.print()
            email = Prompt.ask("[cyan]Email[/cyan]")
            password = Prompt.ask("[cyan]Senha[/cyan]", password=True)

        result = self.client.login(email=email, password=password)
        if not result.ok:
            console.print(f"[red]❌ Falha na autenticação: {result.error}[/red]")
            return False

        self.token = _data(result).get("access_token", "")
        if not self.token:
            console.print("[red]❌ Token não encontrado na resposta[/red]")
            return False

        self.profile = _data(result).get("profile")
        console.print("[green]✓ Autenticado[/green]")
        if self.profile:
            console.print(f"[dim]Perfil: {self.profile}[/dim]")
        console.print()
        return True

    def show_me(self) -> bool:
        """Show the current authenticated token context (USER/ADMIN)."""
        result = self.client.auth_me(token=self.token)
        if not result.ok:
            console.print(f"[red]❌ Falha ao obter contexto: {result.error}[/red]")
            return False
        data = _data(result)
        console.print("[bold cyan]Token atual[/bold cyan]")
        console.print(f"  Email: {data.get('email', 'unknown')}")
        console.print(f"  Perfil: {data.get('profile', 'unknown')}")
        console.print(f"  Esquema: {data.get('scheme', 'Bearer')}")
        return True

    def do_logout(self) -> bool:
        """Revoke the current token (USER/ADMIN)."""
        result = self.client.logout(token=self.token)
        if not result.ok:
            console.print(f"[red]❌ Falha no logout: {result.error}[/red]")
            return False
        console.print("[green]✓ Logout realizado; token revogado[/green]")
        return True

    def change_own_password(self) -> bool:
        """Change the authenticated user's own password (USER/ADMIN)."""
        current = Prompt.ask("[cyan]Senha atual[/cyan]", password=True)
        new = Prompt.ask("[cyan]Nova senha (mín. 8 caracteres)[/cyan]", password=True)
        confirm = Prompt.ask("[cyan]Confirme a nova senha[/cyan]", password=True)
        if new != confirm:
            console.print("[red]❌ Senhas não conferem[/red]")
            return False
        result = self.client.password_change(
            token=self.token, current_password=current, new_password=new
        )
        if not result.ok:
            console.print(f"[red]❌ Falha ao alterar senha: {result.error}[/red]")
            return False
        console.print("[green]✓ Senha alterada com sucesso[/green]")
        return True

    def set_password_admin(self) -> bool:
        """Create/overwrite a credential password (ADMIN only)."""
        email = Prompt.ask("[cyan]Email do usuário[/cyan]")
        profile = Prompt.ask("[cyan]Perfil (USER/ADMIN)[/cyan]").strip().upper()
        new = Prompt.ask("[cyan]Nova senha (mín. 8 caracteres)[/cyan]", password=True)
        result = self.client.password_set(
            token=self.token, email=email, profile=profile, password=new
        )
        if not result.ok:
            console.print(f"[red]❌ Falha ao definir senha: {result.error}[/red]")
            return False
        console.print(f"[green]✓ Senha definida para {email}[/green]")
        return True

    def reset_password_admin(self) -> bool:
        """Reset the password for an existing credential (ADMIN only)."""
        email = Prompt.ask("[cyan]Email do usuário[/cyan]")
        profile = Prompt.ask("[cyan]Perfil (USER/ADMIN, opcional)[/cyan]").strip().upper() or None
        new = Prompt.ask("[cyan]Nova senha (mín. 8 caracteres)[/cyan]", password=True)
        result = self.client.password_reset(
            token=self.token, email=email, new_password=new, profile=profile
        )
        if not result.ok:
            console.print(f"[red]❌ Falha ao resetar senha: {result.error}[/red]")
            return False
        console.print(f"[green]✓ Senha resetada para {email}[/green]")
        return True

    def create_token_admin(self) -> bool:
        """Issue a new token for a user (ADMIN only)."""
        email = Prompt.ask("[cyan]Email do usuário[/cyan]")
        profile = Prompt.ask("[cyan]Perfil (USER/ADMIN)[/cyan]").strip().upper()
        ttl_days = Prompt.ask("[cyan]Validade em dias (ex.: 30)[/cyan]", default="30")
        try:
            expires_at = datetime.now(timezone.utc) + timedelta(days=int(ttl_days))
        except ValueError:
            console.print("[red]❌ Validade inválida[/red]")
            return False
        result = self.client.create_token(
            token=self.token, email=email, profile=profile, expires_at=expires_at
        )
        if not result.ok:
            console.print(f"[red]❌ Falha ao criar token: {result.error}[/red]")
            return False
        data = _data(result)
        console.print("[green]✓ Token criado[/green]")
        console.print(f"  ID: {data['token'].get('id')}")
        console.print(f"  Prefixo: {data['token'].get('token_prefix')}")
        console.print(f"  Expira: {data['token'].get('expires_at')}")
        console.print(f"  Token bruto: [bold]{data.get('raw_token')}[/bold]")
        return True

    def list_tokens_admin(self) -> bool:
        """List tokens (ADMIN only)."""
        result = self.client.list_tokens(token=self.token, limit=100)
        if not result.ok:
            console.print(f"[red]❌ Falha ao listar tokens: {result.error}[/red]")
            return False
        items = _data(result).get("items", [])
        if not items:
            console.print("[yellow]Nenhum token encontrado[/yellow]")
            return True
        table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
        table.add_column("ID", style="cyan")
        table.add_column("Email", style="green")
        table.add_column("Perfil", style="bold")
        table.add_column("Prefixo", style="dim")
        table.add_column("Ativo", justify="center")
        table.add_column("Expira", style="dim")
        for tok in items:
            table.add_row(
                str(tok.get("id", "")),
                str(tok.get("email", "")),
                str(tok.get("profile", "")),
                str(tok.get("token_prefix", "")),
                "✓" if tok.get("is_active") else "✗",
                str(tok.get("expires_at", "")),
            )
        console.print(table)
        return True

    def revoke_token_admin(self) -> bool:
        """Revoke a token (ADMIN only)."""
        token_id = Prompt.ask("[cyan]ID do token[/cyan]").strip()
        result = self.client.revoke_token(token=self.token, token_id=token_id)
        if not result.ok:
            console.print(f"[red]❌ Falha ao revogar token: {result.error}[/red]")
            return False
        console.print(f"[green]✓ Token {token_id} revogado[/green]")
        return True

    def rotate_token_admin(self) -> bool:
        """Rotate a token (ADMIN only)."""
        token_id = Prompt.ask("[cyan]ID do token[/cyan]").strip()
        result = self.client.rotate_token(token=self.token, token_id=token_id)
        if not result.ok:
            console.print(f"[red]❌ Falha ao rotacionar token: {result.error}[/red]")
            return False
        data = _data(result)
        console.print(f"[green]✓ Token {token_id} rotacionado[/green]")
        console.print(f"  Novo token bruto: [bold]{data.get('raw_token')}[/bold]")
        return True

    def auth_menu(self):
        """Interactive menu for authentication and admin operations.

        Admin-only operations are only shown when the authenticated token
        carries the ADMIN profile, honoring endpoint privileges.
        """
        while True:
            self.clear_screen()
            self.display_header()
            self.show_me()

            options = [
                "[1] Trocar minha senha",
                "[2] Logout",
            ]
            if self.is_admin:
                options.extend(
                    [
                        "[3] Definir senha de usuário (admin)",
                        "[4] Resetar senha de usuário (admin)",
                        "[5] Criar token (admin)",
                        "[6] Listar tokens (admin)",
                        "[7] Revogar token (admin)",
                        "[8] Rotacionar token (admin)",
                    ]
                )
            options.append("q Voltar")

            console.print(Panel(
                "\n".join(options),
                title="🔐 Autenticação e Admin",
                box=box.ROUNDED,
                border_style="magenta",
            ))
            console.print()

            choices = ["1", "2"] + (["3", "4", "5", "6", "7", "8"] if self.is_admin else []) + ["q"]
            choice = Prompt.ask(
                "[cyan]Escolha uma opção ou q para voltar[/cyan]",
                choices=choices,
                show_choices=False,
            )

            if choice == "q":
                return
            if choice == "1":
                self.change_own_password()
            elif choice == "2":
                self.do_logout()
                console.print("[yellow]Saindo...[/yellow]")
                return
            elif self.is_admin and choice == "3":
                self.set_password_admin()
            elif self.is_admin and choice == "4":
                self.reset_password_admin()
            elif self.is_admin and choice == "5":
                self.create_token_admin()
            elif self.is_admin and choice == "6":
                self.list_tokens_admin()
            elif self.is_admin and choice == "7":
                self.revoke_token_admin()
            elif self.is_admin and choice == "8":
                self.rotate_token_admin()

            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

    def get_pipelines(self) -> List[Tuple[str, str]]:
        """List all available pipelines from the API."""
        result = self.client.list_pipelines(token=self.token)
        if not result.ok:
            console.print(f"[red]❌ Erro ao listar pipelines: {result.error}[/red]")
            return []

        items = _data(result).get("items", [])
        return [
            (item["name"], item.get("updated_at") or item.get("created_at") or "")
            for item in items
        ]

    def display_header(self):
        """Display application header."""
        header = Panel(
            Text("📊 InfoBR ELT Pipeline Manager", style="bold cyan", justify="center"),
            subtitle=f"v{get_version('infobr')} | User: {env.USER}",
            box=box.SQUARE,
            border_style="blue"
        )
        console.print(header)
        console.print()

    def display_pipelines_table(self) -> str | None:
        """Display pipelines in an interactive table and return selection."""
        self.pipelines = self.get_pipelines()

        if not self.pipelines:
            console.print("[yellow]⚠️  Nenhuma pipeline encontrada![/yellow]")
            console.print(f"[dim]API: {self.client.base_url}/pipelines[/dim]")
            return None

        table = Table(
            title="📁 Pipelines Disponíveis",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta",
            row_styles=["", "dim"]
        )

        table.add_column("#", style="bold cyan", width=4, justify="center")
        table.add_column("Nome", style="green", min_width=25)
        table.add_column("Atualizado", style="dim", min_width=40)
        table.add_column("Status", style="blue", width=10, justify="center")

        for idx, (name, updated_at) in enumerate(self.pipelines, 1):
            display_name = name.replace(".", " ").replace("_", " ").title()
            table.add_row(
                str(idx),
                display_name,
                str(updated_at),
                "[green]✓[/green]"
            )

        console.print(table)
        console.print()

        # Interactive selection
        choices = [str(i) for i in range(1, len(self.pipelines) + 1)]
        choices.append("q")

        choice = Prompt.ask(
            "[cyan]Selecione uma pipeline (número) ou q para sair[/cyan]",
            choices=choices,
            show_choices=False
        )

        if choice == "q":
            return None

        selected_idx = int(choice) - 1
        return self.pipelines[selected_idx][0]

    def display_pipeline_info(self, pipeline_name: str) -> bool:
        """Display detailed information about a pipeline."""
        result = self.client.get_pipeline(token=self.token, pipeline_name=pipeline_name)

        if not result.ok:
            console.print(f"[red]❌ Pipeline não encontrada: {pipeline_name}[/red]")
            return False

        config = _data(result).get("config", {})

        # Create info panel
        info_text = []
        info_text.append(f"[bold cyan]Nome:[/bold cyan] {pipeline_name}")

        if "processor" in config:
            info_text.append(f"[bold cyan]Processor:[/bold cyan] {config['processor']}")

        if "scopes" in config:
            scopes = config["scopes"]
            info_text.append(f"[bold cyan]Scopes:[/bold cyan] {len(scopes)} item(s)")
            for scope in scopes:
                info_text.append(f"  • {scope}")

        if "llm" in config:
            llm = config["llm"] or "Não definido"
            info_text.append(f"[bold cyan]LLM:[/bold cyan] {llm}")

        if "timeout" in config:
            info_text.append(f"[bold cyan]Timeout:[/bold cyan] {config['timeout']}ms")

        if "parallelize" in config:
            parallel = "Sim" if config["parallelize"] else "Não"
            info_text.append(f"[bold cyan]Paralelização:[/bold cyan] {parallel}")

        info_text.append(f"[dim]API: {self.client.base_url}/pipelines/{pipeline_name}[/dim]")

        panel = Panel(
            "\n".join(info_text),
            title="📋 Configuração da Pipeline",
            box=box.ROUNDED,
            border_style="green"
        )
        console.print(panel)
        console.print()
        return True

    def run_pipeline_with_progress(self, pipeline_name: str, parallelize: bool = True, progress: bool = True):
        """Execute pipeline via API with rich progress display."""
        console.print()
        console.print(f"[bold green]🚀 Iniciando pipeline:[/bold green] [cyan]{pipeline_name}[/cyan]")
        console.print("[dim]Pressione Ctrl+C para interromper[/dim]")
        console.print()

        total_items = self._estimate_pipeline_items(pipeline_name)

        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(bar_width=40),
                TaskProgressColumn(),
                console=console,
                transient=False
            ) as progress_display:

                task = progress_display.add_task(
                    f"[cyan]Despachando {pipeline_name}...[/cyan]",
                    total=None,
                )

                # Dispatch execution via API
                result = self.client._request(
                    "POST",
                    f"/pipelines/{pipeline_name}/execute",
                    token=self.token,
                    json_payload={
                        "parallelize": parallelize,
                        "progress": progress,
                        "params": {},
                    },
                )

                if not result.ok:
                    console.print(f"[red]❌ Erro ao despachar execução: {result.error}[/red]")
                    return False

                execution_id = _data(result).get("execution_id", "")
                if not execution_id:
                    console.print("[red]❌ execution_id não encontrado na resposta[/red]")
                    return False

                progress_display.update(task, description="[cyan]Executando na API...[/cyan]")

                # Poll execution status until terminal
                elapsed = 0.0
                while elapsed < self.POLL_TIMEOUT_SECONDS:
                    time.sleep(self.POLL_INTERVAL_SECONDS)
                    elapsed += self.POLL_INTERVAL_SECONDS

                    poll = self.client._request(
                        "GET",
                        f"/executions/{execution_id}",
                        token=self.token,
                    )
                    if not poll.ok:
                        progress_display.update(
                            task,
                            description=f"[yellow]Aviso: {poll.error}[/yellow]",
                        )
                        continue

                    status = _data(poll).get("status", "")

                    if status in ("success", "completed"):
                        progress_display.update(
                            task,
                            total=100,
                            completed=100,
                            description="[green]✓ Pipeline concluída![/green]",
                        )
                        break
                    elif status in ("failed", "canceled", "cancelled", "error"):
                        error_msg = _data(poll).get("error_message", "Erro desconhecido")
                        progress_display.update(
                            task,
                            description=f"[red]✗ {error_msg}[/red]",
                        )
                        console.print(f"\n[red]❌ Execução falhou: {error_msg}[/red]")
                        return False
                    elif status == "running":
                        progress_display.update(
                            task,
                            description=f"[cyan]Processando dados... ({elapsed:.0f}s)[/cyan]",
                        )
                        progress_display.advance(task)
                    else:
                        progress_display.update(
                            task,
                            description=f"[cyan]Status: {status}[/cyan]",
                        )
                else:
                    progress_display.update(task, description="[red]Timeout[/red]")
                    console.print(f"\n[red]❌ Timeout após {self.POLL_TIMEOUT_SECONDS}s[/red]")
                    return False

            # Show results summary (outside Progress context)
            self.show_execution_summary(execution_id)
            return True

        except KeyboardInterrupt:
            console.print("\n[yellow]⚠️  Pipeline interrompida pelo usuário[/yellow]")
            return False
        except Exception as e:
            console.print(f"\n[red]❌ Erro na execução: {str(e)}[/red]")
            logger.error(f"Pipeline execution failed: {e}")
            return False

    def _estimate_pipeline_items(self, pipeline_name: str) -> int:
        """Estimate total items to process for a pipeline from API config."""
        try:
            result = self.client.get_pipeline(token=self.token, pipeline_name=pipeline_name)
            if not result.ok:
                return 0
            config = _data(result).get("config", {})
            return len(config.get("scopes", []))
        except Exception as e:
            logger.warning(f"Could not estimate pipeline items: {e}")
            return 0

    def display_results_menu(self):
        """Display results menu with option to view detailed results."""
        while True:
            try:
                result = self.client._request(
                    "GET",
                    "/executions",
                    token=self.token,
                    query_params={"offset": 0, "limit": 10},
                )

                if not result.ok:
                    console.print(f"[red]❌ Erro ao listar execuções: {result.error}[/red]")
                    return

                items = _data(result).get("items", [])

                if not items:
                    console.print("[yellow]⚠️  Nenhuma execução encontrada[/yellow]")
                    console.print()
                    Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
                    return

                table = Table(
                    title="📁 Últimas Execuções",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                table.add_column("#", width=3)
                table.add_column("Pipeline", style="green")
                table.add_column("Timestamp", style="cyan")
                table.add_column("Status", justify="center")

                for idx, item in enumerate(items, 1):
                    name = item.get("pipeline_name", "unknown")
                    timestamp = item.get("created_at", "")
                    status = item.get("status", "")

                    if status in ("success", "completed"):
                        status_str = "[green]✓[/green]"
                    elif status in ("failed", "canceled", "cancelled", "error"):
                        status_str = "[red]✗[/red]"
                    elif status == "running":
                        status_str = "[yellow]⟳[/yellow]"
                    else:
                        status_str = status

                    table.add_row(str(idx), name, timestamp, status_str)

                console.print(table)
                console.print()

                # Menu options
                choices = [str(i) for i in range(1, len(items) + 1)]
                choices.append("q")

                choice = Prompt.ask(
                    "[cyan]Selecione um resultado para ver detalhes ou q para sair[/cyan]",
                    choices=choices,
                    show_choices=False
                )

                if choice == "q":
                    return
                else:
                    # View detailed results
                    selected_idx = int(choice) - 1
                    if 0 <= selected_idx < len(items):
                        execution_id = items[selected_idx].get("id", "")
                        self.display_result_details(execution_id)
                    else:
                        console.print("[red]❌ Seleção inválida[/red]")

            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Menu interrompido[/yellow]")
                return

    def display_result_details(self, execution_id: str):
        """Display detailed results from an execution with pagination support."""
        try:
            results = self._fetch_all_execution_results(execution_id)

            if not results:
                console.print("[yellow]⚠️  Nenhum resultado encontrado[/yellow]")
                return

            total_records = len(results)
            RECORDS_PER_PAGE = 50

            # Determine navigation mode based on total records
            use_pagination = total_records > RECORDS_PER_PAGE

            if use_pagination:
                self._display_paginated_results(results, execution_id, RECORDS_PER_PAGE)
            else:
                self._display_individual_results(results, execution_id)
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠️  Visualização interrompida[/yellow]")
            return
        except Exception as e:
            console.print(f"[red]❌ Erro inesperado: {str(e)}[/red]")
            console.print(f"[dim]Tipo: {type(e).__name__}[/dim]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

    def _fetch_all_execution_results(self, execution_id: str) -> list:
        """Fetch all result items for an execution from the API."""
        result = self.client._request(
            "GET",
            f"/executions/{execution_id}/results",
            token=self.token,
            query_params={"page": 1, "page_size": 500},
        )

        if not result.ok:
            if result.status_code == 409:
                console.print("[yellow]⚠️  Execução ainda em andamento[/yellow]")
                return []
            if result.status_code == 404:
                console.print("[yellow]⚠️  Execução sem resultados[/yellow]")
                return []
            raise Exception(f"API error {result.status_code}: {result.error}")

        data = _data(result)
        all_items = list(data.get("items", []))
        total_pages = data.get("total_pages", 1)

        for page in range(2, total_pages + 1):
            page_result = self.client._request(
                "GET",
                f"/executions/{execution_id}/results",
                token=self.token,
                query_params={"page": page, "page_size": 500},
            )
            if page_result.ok:
                all_items.extend(_data(page_result).get("items", []))

        return all_items

    def _display_paginated_results(self, results: list, execution_id: str, records_per_page: int):
        """Display results with pagination navigation (for large datasets)."""
        total_records = len(results)
        total_pages = (total_records + records_per_page - 1) // records_per_page
        current_page = 0

        while True:
            try:
                self.clear_screen()
                self.display_header()

                # Calculate page boundaries
                start_idx = current_page * records_per_page
                end_idx = min(start_idx + records_per_page, total_records)
                page_records = results[start_idx:end_idx]

                # Display execution info with pagination details
                console.print(Panel(
                    f"[bold cyan]Execução:[/bold cyan] {execution_id}\n"
                    f"[bold cyan]Página:[/bold cyan] {current_page + 1} de {total_pages} "
                    f"({start_idx + 1}-{end_idx} de {total_records} registros)",
                    title="📊 Detalhes do Resultado (Modo Paginação)",
                    box=box.ROUNDED,
                    border_style="green"
                ))
                console.print()

                # Create summary table for the page
                summary_table = Table(
                    title=f"📋 Resumo da Página {current_page + 1}",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                summary_table.add_column("Scope", style="green", min_width=25)
                summary_table.add_column("Status", style="bold", width=10, justify="center")
                summary_table.add_column("Erro", style="red", max_width=40)

                success_count = 0
                error_count = 0

                for record in page_records:
                    success = record.get("success", False)
                    if success:
                        success_count += 1
                        status = "[green]✓[/green]"
                    else:
                        error_count += 1
                        status = "[red]✗[/red]"

                    error_msg = ""
                    if record.get("error_message"):
                        error_msg = str(record["error_message"])[:60]
                        if len(error_msg) == 60:
                            error_msg += "..."

                    summary_table.add_row(
                        str(record.get("scope", "N/A")),
                        status,
                        error_msg
                    )

                console.print(summary_table)
                console.print()

                # Page statistics
                stats_table = Table(box=box.ROUNDED, show_header=False)
                stats_table.add_column("Métrica", style="bold")
                stats_table.add_column("Valor", justify="right")

                stats_table.add_row("Registros nesta página", str(len(page_records)))
                stats_table.add_row("[green]Sucessos na página[/green]", f"[green]{success_count}[/green]")
                if error_count > 0:
                    stats_table.add_row("[red]Erros na página[/red]", f"[red]{error_count}[/red]")
                stats_table.add_row("", "")
                stats_table.add_row("Total de registros", str(total_records))

                # Calculate overall statistics
                total_success = sum(1 for r in results if r.get("success", False))
                total_errors = total_records - total_success
                stats_table.add_row("[green]Total de sucessos[/green]", f"[green]{total_success}[/green]")
                if total_errors > 0:
                    stats_table.add_row("[red]Total de erros[/red]", f"[red]{total_errors}[/red]")
                stats_table.add_row("Taxa de sucesso geral", f"{(total_success/total_records*100):.1f}%")

                console.print(stats_table)
                console.print()

                # Navigation menu
                nav_options = []
                if current_page > 0:
                    nav_options.append("p Página anterior")
                if current_page < total_pages - 1:
                    nav_options.append("n Próxima página")
                nav_options.extend(["i Ir para página", "q Sair"])

                nav_text = " | ".join(nav_options)
                console.print(f"[cyan]{nav_text}[/cyan]")
                console.print()

                # Get navigation choice
                available_choices = []
                if current_page > 0:
                    available_choices.append("p")
                if current_page < total_pages - 1:
                    available_choices.append("n")
                available_choices.extend(["i", "q"])

                choice = Prompt.ask(
                    "[cyan]Escolha uma opção[/cyan]",
                    choices=available_choices,
                    show_choices=False
                )

                if choice == "p" and current_page > 0:
                    current_page -= 1
                elif choice == "n" and current_page < total_pages - 1:
                    current_page += 1
                elif choice == "i":
                    page_num = Prompt.ask(
                        f"[cyan]Ir para página (1-{total_pages})[/cyan]",
                        default=str(current_page + 1)
                    )
                    try:
                        new_page = int(page_num) - 1
                        if 0 <= new_page < total_pages:
                            current_page = new_page
                        else:
                            console.print(f"[red]❌ Página inválida. Deve estar entre 1 e {total_pages}[/red]")
                            time.sleep(1)
                    except ValueError:
                        console.print("[red]❌ Número de página inválido[/red]")
                        time.sleep(1)
                elif choice == "q":
                    return

            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Navegação interrompida[/yellow]")
                return

    def _display_individual_results(self, results: list, execution_id: str):
        """Display results with individual record navigation (for small datasets)."""
        current_index = 0
        total_records = len(results)

        while True:
            try:
                self.clear_screen()
                self.display_header()

                # Display execution info
                console.print(Panel(
                    f"[bold cyan]Execução:[/bold cyan] {execution_id}\n"
                    f"[bold cyan]Registro:[/bold cyan] {current_index + 1} de {total_records}",
                    title="📊 Detalhes do Resultado",
                    box=box.ROUNDED,
                    border_style="green"
                ))
                console.print()

                # Get current record
                record = results[current_index]

                # Display record details in table format
                details_table = Table(
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                details_table.add_column("Campo", style="bold", width=20)
                details_table.add_column("Valor", min_width=40)

                # Basic info
                details_table.add_row("Scope", str(record.get("scope", "N/A")))
                details_table.add_row("Success", "[green]✓ Sim[/green]" if record.get("success") else "[red]✗ Não[/red]")

                if record.get("error_message"):
                    details_table.add_row("Error", f"[red]{record['error_message']}[/red]")

                # Parameters section
                if "data" in record and "params" in record["data"]:
                    details_table.add_row("", "")
                    details_table.add_row("[bold magenta]Parâmetros[/bold magenta]", "")
                    params = record["data"]["params"]

                    for key, value in params.items():
                        if isinstance(value, (str, int, float, bool)):
                            details_table.add_row(f"  {key}", str(value))
                        elif isinstance(value, list) and len(value) <= 3:
                            details_table.add_row(f"  {key}", ", ".join(map(str, value)))
                        elif isinstance(value, list):
                            details_table.add_row(f"  {key}", f"Lista com {len(value)} itens")
                        else:
                            details_table.add_row(f"  {key}", str(type(value).__name__))

                # Output file
                if "data" in record and "output_file_path" in record["data"]:
                    details_table.add_row("", "")
                    details_table.add_row("[bold magenta]Arquivo de Saída[/bold magenta]", record["data"]["output_file_path"])

                console.print(details_table)
                console.print()

                # Navigation menu
                nav_options = []
                if current_index > 0:
                    nav_options.append("p Anterior")
                if current_index < total_records - 1:
                    nav_options.append("n Próximo")
                nav_options.extend(["q Sair"])

                nav_text = " | ".join(nav_options)
                console.print(f"[cyan]{nav_text}[/cyan]")
                console.print()

                # Get navigation choice
                available_choices = []
                if current_index > 0:
                    available_choices.append("p")
                if current_index < total_records - 1:
                    available_choices.append("n")
                available_choices.append("q")

                choice = Prompt.ask(
                    "[cyan]Escolha uma opção[/cyan]",
                    choices=available_choices,
                    show_choices=False
                )

                if choice == "p" and current_index > 0:
                    current_index -= 1
                elif choice == "n" and current_index < total_records - 1:
                    current_index += 1
                elif choice == "q":
                    return

            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Navegação interrompida[/yellow]")
                return

    def show_execution_summary(self, execution_id: str):
        """Display summary of an execution from the API."""
        result = self.client._request(
            "GET",
            f"/executions/{execution_id}/results",
            token=self.token,
            query_params={"page": 1, "page_size": 500},
        )

        if not result.ok:
            if result.status_code == 409:
                console.print("[yellow]⚠️  Execução ainda em andamento[/yellow]")
            else:
                console.print(f"[yellow]⚠️  Erro ao obter resultados: {result.error}[/yellow]")
            return

        data = _data(result)
        total_ops = data.get("total_operations", 0)
        successful = data.get("successful_operations", 0)
        failed = data.get("failed_operations", 0)
        success_rate = data.get("success_rate", 0.0)

        if total_ops == 0:
            console.print("[yellow]⚠️  Nenhum resultado encontrado[/yellow]")
            return

        try:
            summary_table = Table(
                title=f"📊 Resumo da Execução ({execution_id})",
                box=box.ROUNDED,
                show_header=True,
                header_style="bold cyan"
            )

            summary_table.add_column("Métrica", style="bold")
            summary_table.add_column("Valor", justify="right")

            summary_table.add_row("Total de operações", str(total_ops))
            summary_table.add_row("[green]Sucessos[/green]", f"[green]{successful}[/green]")
            if failed > 0:
                summary_table.add_row("[red]Falhas[/red]", f"[red]{failed}[/red]")
            summary_table.add_row("Taxa de sucesso", f"{success_rate:.1f}%")

            console.print(summary_table)
            console.print()

            # Show errors if any
            if failed > 0:
                # Fetch all items across pages to find errors
                all_items = list(data.get("items", []))
                total_pages = data.get("total_pages", 1)
                for page in range(2, total_pages + 1):
                    page_result = self.client._request(
                        "GET",
                        f"/executions/{execution_id}/results",
                        token=self.token,
                        query_params={"page": page, "page_size": 500},
                    )
                    if page_result.ok:
                        all_items.extend(_data(page_result).get("items", []))

                error_table = Table(
                    title="❌ Operações com Erro",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold red"
                )
                error_table.add_column("Scope", style="cyan")
                error_table.add_column("Erro", style="red", max_width=60)

                for item in all_items:
                    if not item.get("success", False):
                        error_table.add_row(
                            str(item.get("scope", "N/A")),
                            str(item.get("error_message", ""))
                        )

                console.print(error_table)
                console.print()

            console.print(f"[dim]📁 Execução: {execution_id}[/dim]")
        except Exception as e:
            console.print(f"[yellow]⚠️  Erro inesperado ao ler resultado: {str(e)}[/yellow]")
            console.print(f"[dim]Tipo: {type(e).__name__}[/dim]")

    def _interactive_import_pipeline(self) -> None:
        """Interactive pipeline import from a JSON file."""
        file_path = Prompt.ask("[cyan]Caminho do arquivo JSON[/cyan]")

        if not os.path.exists(file_path):
            console.print(f"[red]❌ Arquivo não encontrado: {file_path}[/red]")
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
            return

        force = Confirm.ask("[cyan]Sobrescrever se já existir?[/cyan]", default=False)

        console.print()
        _import_pipeline(self, file_path, force=force)
        console.print()
        Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

    def _interactive_export_pipeline(self) -> None:
        """Interactive pipeline export to a JSON file."""
        pipelines = self.get_pipelines()
        if not pipelines:
            console.print("[yellow]Nenhuma pipeline disponível.[/yellow]")
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
            return

        console.print("[bold]Pipelines disponíveis:[/bold]")
        for idx, (name, _) in enumerate(pipelines, 1):
            console.print(f"  [cyan]{idx}[/cyan] {name}")
        console.print()

        choices = [str(i) for i in range(1, len(pipelines) + 1)]
        choice = Prompt.ask("[cyan]Escolha a pipeline[/cyan]", choices=choices, show_choices=False)
        selected_name = pipelines[int(choice) - 1][0]

        output_path = Prompt.ask("[cyan]Arquivo de destino[/cyan]")

        console.print()
        _export_pipeline(self, selected_name, output_path)
        console.print()
        Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

    def _interactive_export_execution(self) -> None:
        """Interactive execution export to a JSON file."""
        execution_id = Prompt.ask("[cyan]ID da execução[/cyan]").strip()
        if not execution_id:
            console.print("[red]❌ ID não pode ser vazio[/red]")
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
            return

        output_path = Prompt.ask("[cyan]Arquivo de destino[/cyan]")

        console.print()
        _export_execution(self, execution_id, output_path)
        console.print()
        Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

    def run_interactive(self):
        """Run interactive TUI mode."""
        while True:
            self.clear_screen()
            self.display_header()

            # Show menu
            menu_options = [
                "[1] Listar e executar pipeline",
                "[2] Ver últimos resultados",
                "[3] Importar pipeline",
                "[4] Exportar pipeline",
                "[5] Exportar execução",
                "[6] Autenticação e admin",
                "q Sair"
            ]

            menu_panel = Panel(
                "\n".join(menu_options),
                title="⚡ Menu Principal",
                box=box.ROUNDED,
                border_style="cyan"
            )
            console.print(menu_panel)
            console.print()

            choice = Prompt.ask(
                "[cyan]Escolha uma opção (1-6 ou q para sair)[/cyan]",
                choices=["1", "2", "3", "4", "5", "6", "q"],
                show_choices=False
            )

            if choice == "q":
                console.print("\n[bold cyan]👋 Até logo![/bold cyan]")
                break

            elif choice == "1":
                self.clear_screen()
                self.display_header()

                pipeline_name = self.display_pipelines_table()

                if pipeline_name:
                    self.clear_screen()
                    self.display_header()

                    if self.display_pipeline_info(pipeline_name):
                        console.print()
                        confirm = Confirm.ask(
                            f"[green]Executar pipeline '{pipeline_name}'? (Enter=Sim, Ctrl+C=Não)[/green]",
                            default=True
                        )

                        if confirm:
                            # Ask for execution options
                            console.print()
                            parallel = Confirm.ask(
                                "[cyan]Usar paralelização? (Enter=Sim, Ctrl+C=Não)[/cyan]",
                                default=True
                            )
                            show_progress = Confirm.ask(
                                "[cyan]Mostrar progresso detalhado? (Enter=Sim, Ctrl+C=Não)[/cyan]",
                                default=True
                            )

                            self.run_pipeline_with_progress(
                                pipeline_name,
                                parallelize=parallel,
                                progress=show_progress
                            )

                            console.print()
                            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")

            elif choice == "2":
                self.clear_screen()
                self.display_header()
                self.display_results_menu()

            elif choice == "3":
                self.clear_screen()
                self.display_header()
                self._interactive_import_pipeline()

            elif choice == "4":
                self.clear_screen()
                self.display_header()
                self._interactive_export_pipeline()

            elif choice == "5":
                self.clear_screen()
                self.display_header()
                self._interactive_export_execution()

            elif choice == "6":
                self.auth_menu()

    def run_pipeline_direct(self, pipeline_name: str, parallelize: bool = True, progress: bool = True):
        """Run pipeline directly (non-interactive mode)."""
        self.clear_screen()
        self.display_header()

        if not self.display_pipeline_info(pipeline_name):
            pipelines = self.get_pipelines()
            available_names = [p[0] for p in pipelines]
            console.print(f"[dim]Disponíveis: {', '.join(available_names) or 'Nenhuma'}[/dim]")
            sys.exit(1)

        console.print()

        success = self.run_pipeline_with_progress(pipeline_name, parallelize, progress)
        sys.exit(0 if success else 1)


def _import_pipeline(tui: "ELT_TUI", file_path: str, *, force: bool = False) -> None:
    """Import a pipeline from a JSON file into the database."""
    if not os.path.exists(file_path):
        console.print(f"[red]❌ Arquivo não encontrado: {file_path}[/red]")
        sys.exit(1)

    with open(file_path, "r", encoding="utf-8") as f:
        try:
            config = json.load(f)
        except json.JSONDecodeError as exc:
            console.print(f"[red]❌ JSON inválido: {exc}[/red]")
            sys.exit(1)

    if not isinstance(config, dict):
        console.print("[red]❌ Formato inválido: esperado um objeto JSON[/red]")
        sys.exit(1)

    name = config.get("name") or os.path.splitext(os.path.basename(file_path))[0]
    pipeline_config = {k: v for k, v in config.items() if k != "name"}

    result = tui.client._request(
        "POST",
        "/pipelines/import",
        token=tui.token,
        json_payload={"name": name, "config": pipeline_config, "force": force},
    )

    if result.ok:
        data = _data(result)
        action = "importada" if data.get("created") else "atualizada"
        console.print(f"[green]✓ Pipeline '{name}' {action}[/green]")
    else:
        error_msg = result.error if isinstance(result.error, str) else _data(result).get("detail", result.error)
        console.print(f"[red]❌ Falha ao importar: {error_msg}[/red]")
        sys.exit(1)


def _export_pipeline(tui: "ELT_TUI", pipeline_name: str, output_path: str) -> None:
    """Export a pipeline configuration from the database to a JSON file."""
    result = tui.client._request(
        "GET",
        f"/pipelines/{pipeline_name}/export",
        token=tui.token,
    )

    if not result.ok:
        error_msg = result.error if isinstance(result.error, str) else _data(result).get("detail", result.error)
        console.print(f"[red]❌ Falha ao exportar: {error_msg}[/red]")
        sys.exit(1)

    data = _data(result)
    payload = {"name": data.get("name", pipeline_name), **data.get("config", {})}

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=4, ensure_ascii=False)

    console.print(f"[green]✓ Pipeline '{pipeline_name}' exportada para {output_path}[/green]")


def _export_execution(tui: "ELT_TUI", execution_id: str, output_path: str) -> None:
    """Export an execution's output from the database to a JSON file."""
    result = tui.client._request(
        "GET",
        f"/executions/{execution_id}/export",
        token=tui.token,
    )

    if not result.ok:
        error_msg = result.error if isinstance(result.error, str) else _data(result).get("detail", result.error)
        console.print(f"[red]❌ Falha ao exportar: {error_msg}[/red]")
        sys.exit(1)

    data = _data(result)
    payload = data.get("output", [])

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=4, ensure_ascii=False)

    console.print(f"[green]✓ Execução '{execution_id}' exportada para {output_path}[/green]")


def main():
    """Main entry point."""
    api_base_url = os.environ.get("INFOBR_API_BASE_URL")
    if not api_base_url:
        console.print("[red]❌ INFOBR_API_BASE_URL não definida[/red]")
        console.print("[dim]Ex: export INFOBR_API_BASE_URL=http://127.0.0.1:8500/api/v1[/dim]")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        prog="python -m infobr.data.elt",
        description="InfoBR ELT Pipeline CLI - Gerencie pipelines de extração de dados financeiros",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos:
  python -m infobr.data.elt                           # Modo interativo TUI
  python -m infobr.data.elt -p series.extract.full    # Executar pipeline diretamente
  python -m infobr.data.elt -l                        # Listar pipelines disponíveis
  python -m infobr.data.elt --health                  # Health check (sem auth)
  python -m infobr.data.elt -p teste --no-parallel    # Executar sem paralelização

Autenticação e admin (via API REST):
  python -m infobr.data.elt --auth-me                # Contexto do token (USER/ADMIN)
  python -m infobr.data.elt --logout                 # Revogar token atual (USER/ADMIN)
  python -m infobr.data.elt --change-password        # Trocar própria senha (USER/ADMIN)
  python -m infobr.data.elt --set-password           # Definir senha de usuário (ADMIN)
  python -m infobr.data.elt --reset-password         # Resetar senha de usuário (ADMIN)
  python -m infobr.data.elt --create-token           # Criar token para usuário (ADMIN)
  python -m infobr.data.elt --list-tokens            # Listar tokens (ADMIN)
  python -m infobr.data.elt --revoke-token <ID>      # Revogar token (ADMIN)
  python -m infobr.data.elt --rotate-token <ID>      # Rotacionar token (ADMIN)

Importação/Exportação de pipelines:
  python -m infobr.data.elt --import-pipeline my.json          # Importar pipeline
  python -m infobr.data.elt --import-pipeline my.json --force  # Sobrescrever existente
  python -m infobr.data.elt --export-pipeline series.extract.FX -o out.json

Exportação de execuções:
  python -m infobr.data.elt --export-execution abc123 -o result.json

Modo batch (sem prompt interativo):
  INFOBR_USERNAME=admin INFOBR_PASSWD=secret python -m infobr.data.elt -l
  INFOBR_USERNAME=admin INFOBR_PASSWD=secret python -m infobr.data.elt -p series.extract.FX
        """
    )

    parser.add_argument(
        "-p", "--pipeline",
        metavar="NAME",
        help="Nome da pipeline para executar (modo direto)"
    )

    parser.add_argument(
        "-l", "--list",
        action="store_true",
        help="Listar todas as pipelines disponíveis"
    )

    parser.add_argument(
        "--no-parallel",
        action="store_true",
        help="Desativar paralelização na execução"
    )

    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Desativar exibição de progresso"
    )

    parser.add_argument(
        "--health",
        action="store_true",
        help="Verificar saúde da API (sem autenticação) e sair"
    )

    parser.add_argument(
        "--import-pipeline",
        metavar="FILE",
        help="Importar uma pipeline de um arquivo JSON para o banco de dados"
    )

    parser.add_argument(
        "--export-pipeline",
        metavar="NAME",
        help="Exportar a pipeline NAME do banco para um arquivo JSON (usar com --output)"
    )

    parser.add_argument(
        "--export-execution",
        metavar="ID",
        help="Exportar o output da execução ID para um arquivo JSON (usar com --output)"
    )

    parser.add_argument(
        "--output", "-o",
        metavar="FILE",
        help="Arquivo de destino para exportação (usar com --export-pipeline ou --export-execution)"
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Sobrescrever pipeline existente ao importar (usar com --import-pipeline)"
    )

    parser.add_argument(
        "--auth-me",
        action="store_true",
        help="Exibir o contexto do token autenticado (GET /auth/me)"
    )

    parser.add_argument(
        "--logout",
        action="store_true",
        help="Revogar o token atual (POST /auth/logout)"
    )

    parser.add_argument(
        "--change-password",
        action="store_true",
        help="Alterar a própria senha (POST /auth/password/change)"
    )

    parser.add_argument(
        "--set-password",
        action="store_true",
        help="Definir senha de um usuário (admin; POST /auth/password/set)"
    )

    parser.add_argument(
        "--reset-password",
        action="store_true",
        help="Resetar senha de um usuário (admin; POST /auth/password/reset)"
    )

    parser.add_argument(
        "--create-token",
        action="store_true",
        help="Criar um token para um usuário (admin; POST /auth/tokens)"
    )

    parser.add_argument(
        "--list-tokens",
        action="store_true",
        help="Listar tokens (admin; GET /auth/tokens)"
    )

    parser.add_argument(
        "--revoke-token",
        metavar="ID",
        help="Revogar um token por ID (admin; POST /auth/tokens/{id}/revoke)"
    )

    parser.add_argument(
        "--rotate-token",
        metavar="ID",
        help="Rotacionar um token por ID (admin; POST /auth/tokens/{id}/rotate)"
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s {get_version("infobr")}"
    )

    args = parser.parse_args()

    client = ApiClient(base_url=api_base_url)

    if args.health:
        result = client._request("GET", "/health")
        if result.ok:
            data = _data(result)
            console.print(f"[green]✓ API saudável[/green]")
            console.print(f"  Status: {data.get('status', 'unknown')}")
            console.print(f"  Version: {data.get('version', 'unknown')}")
            sys.exit(0)
        else:
            console.print(f"[red]❌ API indisponível[/red]")
            console.print(f"  Status code: {result.status_code}")
            console.print(f"  Error: {result.error}")
            sys.exit(1)

    tui = ELT_TUI(client)

    if not tui.authenticate():
        sys.exit(1)

    if args.auth_me:
        sys.exit(0 if tui.show_me() else 1)
    elif args.logout:
        sys.exit(0 if tui.do_logout() else 1)
    elif args.change_password:
        sys.exit(0 if tui.change_own_password() else 1)

    if args.set_password or args.reset_password or args.create_token or args.list_tokens or args.revoke_token or args.rotate_token:
        if not tui.is_admin:
            console.print(f"[red]❌ Operação restrita ao perfil ADMIN (autenticado como {tui.profile or 'desconhecido'})[/red]")
            sys.exit(1)

    if args.set_password:
        sys.exit(0 if tui.set_password_admin() else 1)
    elif args.reset_password:
        sys.exit(0 if tui.reset_password_admin() else 1)
    elif args.create_token:
        sys.exit(0 if tui.create_token_admin() else 1)
    elif args.list_tokens:
        sys.exit(0 if tui.list_tokens_admin() else 1)
    elif args.revoke_token:
        sys.exit(0 if tui.revoke_token_admin() else 1)
    elif args.rotate_token:
        sys.exit(0 if tui.rotate_token_admin() else 1)

    if args.import_pipeline:
        _import_pipeline(tui, args.import_pipeline, force=args.force)
    elif args.export_pipeline:
        if not args.output:
            console.print("[red]❌ --export-pipeline requer --output FILE[/red]")
            sys.exit(1)
        _export_pipeline(tui, args.export_pipeline, args.output)
    elif args.export_execution:
        if not args.output:
            console.print("[red]❌ --export-execution requer --output FILE[/red]")
            sys.exit(1)
        _export_execution(tui, args.export_execution, args.output)
    elif args.list:
        # List mode
        tui.clear_screen()
        tui.display_header()
        pipelines = tui.get_pipelines()

        if pipelines:
            table = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
            table.add_column("#", width=4, justify="center")
            table.add_column("Nome", style="green")
            table.add_column("Atualizado", style="dim")

            for idx, (name, updated_at) in enumerate(pipelines, 1):
                table.add_row(str(idx), name, str(updated_at))

            console.print(table)
            console.print(f"\n[dim]Total: {len(pipelines)} pipeline(s)[/dim]")
        else:
            console.print("[yellow]Nenhuma pipeline encontrada.[/yellow]")

    elif args.pipeline:
        # Direct execution mode
        tui.run_pipeline_direct(
            args.pipeline,
            parallelize=not args.no_parallel,
            progress=not args.no_progress
        )
    else:
        # Interactive TUI mode
        tui.run_interactive()


if __name__ == "__main__":
    main()