"""InfoBR - Brazilian Financial Information System.

Entrypoint that bootstraps the application. It now delegates all
configuration to the centralized Pydantic Settings layer
(infobr.config / infobr.secrets) while keeping the legacy fbpyutils
env object populated for backward compatibility with existing modules.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine

# ---------------------------------------------------------------------------
# Load .env before Pydantic Settings picks it up
# ---------------------------------------------------------------------------
_ = load_dotenv()

# ---------------------------------------------------------------------------
# Centralized configuration (single source of truth)
# ---------------------------------------------------------------------------
from infobr.config import get_settings
from infobr.secrets import get_secrets

settings = get_settings()
secrets = get_secrets()

# ---------------------------------------------------------------------------
# Legacy fbpyutils bootstrap — still required by several modules
# ---------------------------------------------------------------------------
from fbpyutils import get_env, get_logger, setup

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

setup(os.path.sep.join([_ROOT_DIR, "app.json"]))

env = get_env()
logger = get_logger()

# ---------------------------------------------------------------------------
# Populate legacy env object with values from the new settings model
# ---------------------------------------------------------------------------
env.DB_URL = settings.db_url
env.ROOT_FOLDER = _ROOT_DIR
env.USER = settings.home.name.upper()
env.USER_APP_FOLDER = str(settings.home)
env.USER_CONFIG = {}

from fbpyutils_db.database.schema import get_schemas

env.SCHEMAS = get_schemas(os.path.sep.join([_ROOT_DIR, "data", "schemas"]))

# ---------------------------------------------------------------------------
# Ensure directories exist (idempotent — model_post_init already does this)
# ---------------------------------------------------------------------------
os.makedirs(settings.home, exist_ok=True)
os.makedirs(settings.pipelines_path, exist_ok=True)
os.makedirs(settings.operations_path, exist_ok=True)
os.makedirs(settings.logs_path, exist_ok=True)

# ---------------------------------------------------------------------------
# Load user config.json (legacy flat format — still supported)
# ---------------------------------------------------------------------------
_config_file = settings.home / "config.json"
if not _config_file.exists():
    _config_file.write_text(
        json.dumps(env.USER_CONFIG, indent=4, ensure_ascii=False),
        encoding="utf-8",
    )
else:
    try:
        with open(_config_file, "r", encoding="utf-8") as f:
            file_config = json.load(f)
        if isinstance(file_config, dict):
            for key, value in file_config.items():
                env.USER_CONFIG[key] = value
    except Exception:
        logger.warning("Failed to parse %s; using empty user config.", _config_file)

# ---------------------------------------------------------------------------
# Backward-compat: expose token pepper on legacy env object
# ---------------------------------------------------------------------------
env.TOKEN_PEPPER = secrets.token_pepper

# ---------------------------------------------------------------------------
# Backward-compat: map user config.json keys to legacy env attributes
# ---------------------------------------------------------------------------
if "SUPPORTED_LLMS" in env.USER_CONFIG:
    env.SUPPORTED_LLMS = env.USER_CONFIG["SUPPORTED_LLMS"]

# ---------------------------------------------------------------------------
# SQLite WAL mode (VULN-005)
# ---------------------------------------------------------------------------
@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_conn, connection_record):
    import sqlite3

    if isinstance(dbapi_conn, sqlite3.Connection):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.close()


# ---------------------------------------------------------------------------
# SQLAlchemy engine creation using validated settings
# ---------------------------------------------------------------------------
try:
    db_engine_options: dict[str, object] = {
        "pool_pre_ping": True,
        "pool_use_lifo": True,
    }
    if not settings.db_url.startswith("sqlite"):
        db_engine_options.update(
            {
                "pool_size": settings.db_pool_size,
                "max_overflow": settings.db_max_overflow,
                "pool_timeout": settings.db_pool_timeout,
                "pool_recycle": settings.db_pool_recycle,
            }
        )
    env.DB = create_engine(settings.db_url, **db_engine_options)
except Exception as e:
    logger.critical("Unable to connect/create system database: %s", e)
    raise SystemError(f"Unable to connect/create system database: {e}.")
