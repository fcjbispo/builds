"""API-041: integration tests for critical endpoint flow."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin
from infobr.api.main import app
from infobr.api.services import ExecutionDispatchResult


def _admin_token():
    return SimpleNamespace(email="admin@example.com", profile="ADMIN", token_prefix="admintok")


def test_critical_flow_create_token_dispatch_execution_and_fetch_results(monkeypatch):
    app.dependency_overrides[require_admin] = _admin_token

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace()
        session.expunge = lambda _obj: None
        yield session

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

    def fake_issue_token(_repo, **_kwargs):
        token = SimpleNamespace(
            id="tok-admin-1",
            email="client@example.com",
            profile="ADMIN",
            token_prefix="rawtoken",
            expires_at=None,
            is_active=True,
            last_used_at=None,
            created_at=datetime.now(timezone.utc),
            updated_at=None,
            created_by="admin@example.com",
        )
        return token, "raw-token-value"

    monkeypatch.setattr("infobr.api.routers.auth.session_scope", fake_session_scope)
    monkeypatch.setattr("infobr.api.routers.auth.TokenRepository", FakeTokenRepo)
    monkeypatch.setattr("infobr.api.routers.auth.TokenService.issue_token", fake_issue_token)

    monkeypatch.setattr(
        "infobr.api.routers.pipelines.ExecutionService.dispatch_execution",
        lambda **_kwargs: ExecutionDispatchResult(execution_id="exec-001", status="queued"),
    )

    execution_obj = SimpleNamespace(
        id="exec-001",
        pipeline_name="series.extract.full",
        status="success",
        requested_by="admin@example.com",
        params='{"parallelize": true}',
        output='[{"id": "op1", "success": true}, {"id": "op2", "success": false}]',
        started_at=datetime.now(timezone.utc),
        finished_at=datetime.now(timezone.utc),
        error_message=None,
        created_at=datetime.now(timezone.utc),
        updated_at=None,
    )
    monkeypatch.setattr(
        "infobr.api.routers.executions.ExecutionService.get_execution",
        lambda _execution_id: execution_obj,
    )
    monkeypatch.setattr(
        "infobr.api.routers.executions.ExecutionService.get_execution_output",
        lambda _execution_id: [
            {"id": "op1", "success": True},
            {"id": "op2", "success": False},
        ],
    )

    client = TestClient(app)

    create_token_resp = client.post(
        "/api/v1/auth/tokens",
        json={
            "email": "client@example.com",
            "profile": "ADMIN",
            "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
        },
    )
    assert create_token_resp.status_code == 201
    assert create_token_resp.json()["token"]["email"] == "client@example.com"
    assert create_token_resp.json()["raw_token"] == "raw-token-value"

    dispatch_resp = client.post(
        "/api/v1/pipelines/series.extract.full/execute",
        json={"parallelize": True, "progress": False, "params": {"scope": "ALL"}},
    )
    assert dispatch_resp.status_code == 202
    assert dispatch_resp.json()["execution_id"] == "exec-001"

    execution_detail_resp = client.get("/api/v1/executions/exec-001")
    assert execution_detail_resp.status_code == 200
    assert execution_detail_resp.json()["status"] == "success"

    execution_results_resp = client.get("/api/v1/executions/exec-001/results?page=1&page_size=50")
    assert execution_results_resp.status_code == 200
    payload = execution_results_resp.json()
    assert payload["execution_id"] == "exec-001"
    assert payload["total_operations"] == 2
    assert payload["failed_operations"] == 1
    assert len(payload["items"]) == 2

    app.dependency_overrides.clear()


def test_execution_results_returns_409_while_running(monkeypatch):
    app.dependency_overrides[require_admin] = _admin_token
    running_execution = SimpleNamespace(
        id="exec-002",
        pipeline_name="series.load.full",
        status="running",
        requested_by="admin@example.com",
        params="{}",
        output=None,
        started_at=datetime.now(timezone.utc),
        finished_at=None,
        error_message=None,
        created_at=datetime.now(timezone.utc),
        updated_at=None,
    )
    monkeypatch.setattr(
        "infobr.api.routers.executions.ExecutionService.get_execution",
        lambda _execution_id: running_execution,
    )

    client = TestClient(app)
    resp = client.get("/api/v1/executions/exec-002/results")
    assert resp.status_code == 409
    assert "in progress" in resp.json()["details"]

    app.dependency_overrides.clear()