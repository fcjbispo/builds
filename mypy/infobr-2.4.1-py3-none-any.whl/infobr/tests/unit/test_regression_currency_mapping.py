"""
Teste de regressão para o bug: currency ausente em _build_load_params

currency nunca era definido nos parâmetros de load, então
DOMAIN_MAP.get((kind, None)) retornava None para dominio_nome,
causando NotNullViolation em todas as pipelines STOCK/DIVIDEND.
"""

import pytest
from infobr.data.series import Series, SeriesLoadDataProcessor


class TestBuildLoadParamsCurrency:
    """Verifica que _build_load_params define currency corretamente por scope."""

    @pytest.fixture
    def processor(self, tmp_path):
        """Fixture que cria um SeriesLoadDataProcessor com params mínimos válidos."""
        return SeriesLoadDataProcessor({
            "storage_folder": str(tmp_path),
            "scopes": [],
            "parallelize": False,
            "progress": False,
            "batch_size": 10000,
            "truncate_before_load": False,
            "schema": "infobr",
            "dry_run": False,
            "operation": "append",
        })

    def _get_param_for_scope(self, processor, scope_name):
        """Helper que extrai o primeiro param dict para um dado scope."""
        params = processor._build_load_params()
        for scope, data in params:
            if scope == scope_name:
                return data["params"][0]
        raise ValueError(f"Scope {scope_name} not found in _build_load_params")

    def test_fii_dividends_has_currency_brl(self, processor):
        param = self._get_param_for_scope(processor, Series.FII_DIVIDENDS)
        assert param.get("currency") == "BRL"

    def test_fii_prices_has_currency_brl(self, processor):
        param = self._get_param_for_scope(processor, Series.FII_PRICES)
        assert param.get("currency") == "BRL"

    def test_etf_dividends_has_currency_usd(self, processor):
        param = self._get_param_for_scope(processor, Series.ETF_DIVIDENDS)
        assert param.get("currency") == "USD"

    def test_etf_prices_has_currency_usd(self, processor):
        param = self._get_param_for_scope(processor, Series.ETF_PRICES)
        assert param.get("currency") == "USD"

    def test_eu_dividends_has_currency_eur(self, processor):
        param = self._get_param_for_scope(processor, Series.EU_DIVIDENDS)
        assert param.get("currency") == "EUR"
        assert param.get("sub_folders") == ["DIVIDEND", "EU"]

    def test_eu_prices_has_currency_eur(self, processor):
        param = self._get_param_for_scope(processor, Series.EU_PRICES)
        assert param.get("currency") == "EUR"
        assert param.get("sub_folders") == ["STOCK", "EU"]

    def test_fx_history_has_no_currency(self, processor):
        param = self._get_param_for_scope(processor, Series.FX_HISTORY)
        assert param.get("currency") is None

    def test_calendario_proventos_has_no_currency(self, processor):
        param = self._get_param_for_scope(processor, Series.CALENDARIO_PROVENTOS)
        assert param.get("currency") is None

    def test_currency_maps_to_valid_dominio(self, processor):
        """
        Combinação (kind, currency) de cada pipeline deve existir em DOMAIN_MAP.
        """
        from infobr.data.series import SeriesLoadDataProcessor

        scope_kind_currency = [
            (Series.FII_DIVIDENDS, "DIVIDEND", "BRL"),
            (Series.FII_PRICES, "STOCK", "BRL"),
            (Series.ETF_DIVIDENDS, "DIVIDEND", "USD"),
            (Series.ETF_PRICES, "STOCK", "USD"),
            (Series.EU_DIVIDENDS, "DIVIDEND", "EUR"),
            (Series.EU_PRICES, "STOCK", "EUR"),
            (Series.FX_HISTORY, "FX", None),
            (Series.CALENDARIO_PROVENTOS, "CALENDARIO_PROVENTOS", None),
        ]
        for scope, kind, currency in scope_kind_currency:
            dominio = SeriesLoadDataProcessor.DOMAIN_MAP.get((kind, currency))
            assert dominio is not None, (
                f"Scope {scope}: DOMAIN_MAP missing entry for ({kind}, {currency})"
            )

    def test_eur_maps_to_eu_dominios(self, processor):
        """EUR deve mapear para domínios europeus distintos (ACAO_EU / DIVIDENDO_EU)."""
        from infobr.data.series import SeriesLoadDataProcessor

        assert SeriesLoadDataProcessor.DOMAIN_MAP[("STOCK", "EUR")] == "ACAO_EU"
        assert SeriesLoadDataProcessor.DOMAIN_MAP[("DIVIDEND", "EUR")] == "DIVIDENDO_EU"
