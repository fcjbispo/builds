"""API-048: health endpoint reports the current API version."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from infobr.api.routers.health import _api_version, healthcheck


def test_health_returns_installed_version():
    result = healthcheck()
    assert result.status == "ok"
    assert result.service == "infobr-api"
    assert result.version == version("infobr")


def test_api_version_falls_back_to_unknown(monkeypatch):
    def _raise(*_args, **_kwargs):
        raise PackageNotFoundError("infobr")

    monkeypatch.setattr("infobr.api.routers.health.version", _raise)
    assert _api_version() == "unknown"