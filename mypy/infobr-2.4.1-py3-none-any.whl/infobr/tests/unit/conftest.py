"""Shared pytest fixtures for the InfoBR unit test suite."""

from __future__ import annotations

import os

import pytest


# All INFOBR_* environment variables known to the application.
# Tests that instantiate InfoBRSettings or InfoBRSecrets should use the
# `clean_env` fixture to avoid non-deterministic behaviour when these vars
# are exported in the developer shell.
_KNOWN_INFOBR_ENV_VARS: list[str] = [
    "INFOBR_ENV",
    "INFOBR_HOME",
    "INFOBR_SERVICE_MODE",
    "INFOBR_API_HOST",
    "INFOBR_API_PORT",
    "INFOBR_API_RELOAD",
    "INFOBR_API_WORKERS",
    "INFOBR_API_BASE_URL",
    "INFOBR_DB_URL",
    "INFOBR_DB_POOL_SIZE",
    "INFOBR_DB_MAX_OVERFLOW",
    "INFOBR_DB_POOL_TIMEOUT",
    "INFOBR_DB_POOL_RECYCLE",
    "INFOBR_API_RATE_LIMIT_MAX_REQUESTS",
    "INFOBR_API_RATE_LIMIT_WINDOW_SECONDS",
    "INFOBR_AUTH_LOGIN_RATE_LIMIT_MAX_REQUESTS",
    "INFOBR_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS",
    "INFOBR_PASSWORD_MIN_LENGTH",
    "INFOBR_PASSWORD_ITERATIONS",
    "INFOBR_LOGIN_MAX_ATTEMPTS",
    "INFOBR_LOGIN_LOCK_MINUTES",
    "INFOBR_LOGIN_TOKEN_TTL_HOURS",
    "INFOBR_TOKEN_TTL_DAYS",
    "INFOBR_PIPELINE_RUNNERS",
    "INFOBR_PIPELINE_EXECUTION_TIMEOUT_MINUTES",
    "INFOBR_REDIS_URL",
    "INFOBR_TOKEN_PEPPER",
    "INFOBR_ALPHA_VANTAGE_API_KEY",
    "INFOBR_FIRECRAWL_API_KEY",
    "INFOBR_FIRECRAWL_BASE_URL",
    "INFOBR_LMSTUDIO_API_BASE",
    "INFOBR_OLLAMA_API_BASE",
    "INFOBR_PIP_EXTRA_INDEX_MOUNT_SOURCE",
    "INFOBR_HOME_HOST",
]


@pytest.fixture
def clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Remove all known INFOBR_* environment variables before a test.

    Use this fixture when a test instantiates ``InfoBRSettings`` or
    ``InfoBRSecrets`` directly and expects clean defaults.
    """
    for var in _KNOWN_INFOBR_ENV_VARS:
        monkeypatch.delenv(var, raising=False)
