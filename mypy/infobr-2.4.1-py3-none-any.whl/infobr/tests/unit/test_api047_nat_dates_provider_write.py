"""API-047: regression tests for NaT dates in provider write helpers."""

from __future__ import annotations

import os
import tempfile
from datetime import datetime

import pandas as pd
import pytest

from infobr.data.providers import write_stock_data, write_fx_data, write_dividend_data


@pytest.fixture
def tmp_data_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def _read_csv(path: str | None) -> pd.DataFrame:
    assert path is not None and os.path.exists(path)
    return pd.read_csv(path, sep=";", parse_dates=["Date"])


def test_write_stock_data_drops_nat_dates(tmp_data_dir):
    df = pd.DataFrame({
        "Ticker": ["A", "A", "A"],
        "Date": [
            pd.Timestamp("2026-08-01"),
            pd.Timestamp("2026-08-02"),
            pd.NaT,
        ],
        "Open": [1.0, 2.0, 3.0],
        "High": [1.1, 2.1, 3.1],
        "Low": [0.9, 1.9, 2.9],
        "Close": [1.0, 2.0, 3.0],
        "Volume": [100, 200, 300],
        "Reference_Date": [datetime.now()] * 3,
    })

    path = write_stock_data(df, tmp_data_dir)
    assert path is not None
    result = _read_csv(path)
    assert len(result) == 2  # 1 NaT row dropped, 2 valid rows kept
    assert set(result["Ticker"].tolist()) == {"A"}


def test_write_fx_data_drops_nat_dates(tmp_data_dir):
    df = pd.DataFrame({
        "From": ["USD", "USD", "EUR"],
        "To": ["BRL", "BRL", "BRL"],
        "Date": [
            pd.Timestamp("2026-08-01"),
            pd.NaT,
            pd.Timestamp("2026-08-02"),
        ],
        "Open": [1.0, 2.0, 3.0],
        "High": [1.1, 2.1, 3.1],
        "Low": [0.9, 1.9, 2.9],
        "Close": [1.0, 2.0, 3.0],
        "Reference_Date": [datetime.now()] * 3,
    })

    path = write_fx_data(df, tmp_data_dir)
    assert path is not None
    result = _read_csv(path)
    # Both currency pairs have at least one valid date after dropping NaT.
    assert len(os.listdir(tmp_data_dir)) == 2
    assert len(result) >= 1
    assert bool(pd.notna(result["Date"]).all())


def test_write_dividend_data_drops_nat_pay_dates(tmp_data_dir):
    df = pd.DataFrame({
        "Ticker": ["A", "A", "B"],
        "Payout_Frequency": ["Monthly", "Monthly", "Quarterly"],
        "Ex_Dividend_Date": [pd.Timestamp("2026-08-01"), pd.Timestamp("2026-08-02"), pd.NaT],
        "Cash_Amount": [1.0, 2.0, 3.0],
        "Record_Date": [pd.Timestamp("2026-08-01"), pd.Timestamp("2026-08-02"), pd.NaT],
        "Pay_Date": [pd.Timestamp("2026-08-15"), pd.NaT, pd.Timestamp("2026-08-20")],
        "Reference_Date": [datetime.now()] * 3,
    })

    path = write_dividend_data(df, tmp_data_dir)
    assert path is not None
    result = pd.read_csv(path, sep=";")
    # Both tickers have at least one valid Pay_Date after dropping NaT.
    assert len(os.listdir(tmp_data_dir)) == 2
    assert len(result) >= 1
    assert bool(pd.notna(result["Pay_Date"]).all())


def test_write_stock_data_returns_none_when_all_dates_nat(tmp_data_dir):
    df = pd.DataFrame({
        "Ticker": ["A", "A"],
        "Date": [pd.NaT, pd.NaT],
        "Open": [1.0, 2.0],
        "High": [1.1, 2.1],
        "Low": [0.9, 1.9],
        "Close": [1.0, 2.0],
        "Volume": [100, 200],
        "Reference_Date": [datetime.now(), datetime.now()],
    })

    path = write_stock_data(df, tmp_data_dir)
    assert path is None
