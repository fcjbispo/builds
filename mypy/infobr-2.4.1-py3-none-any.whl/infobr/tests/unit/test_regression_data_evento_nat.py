"""
Teste de regressão para o bug: data_evento NaT após _coerce_datetime causa
NotNullViolation no INSERT.

Quando um CSV contém um valor inválido na coluna de data (ex: '20int'),
_coerce_datetime com errors='coerce' converte para NaT silenciosamente.
A linha com data_evento=NaT chega ao INSERT e falha com NotNullViolation
porque data_evento é NOT NULL (eixo temporal universal da tabela series).

Fix B: _filter_invalid_data_evento filtra e loga linhas com data_evento
inválido após _coerce_datetime, antes de chegar ao DB.

Esse bug afetou a pipeline series.load.FX (log 2026-08-05_13-50-34.json):
  FX_DAILY_EUR_BBR_BACKFILL_BLOCK_3_AUG25.csv tinha '20int' na coluna Date.
"""

import pytest
import pandas as pd
import numpy as np

from infobr.data.series import SeriesLoadDataProcessor


class TestFilterInvalidDataEvento:
    """Verifica que _filter_invalid_data_evento filtra linhas com data_evento NaT."""

    def test_all_valid_dates_unchanged(self):
        """DataFrame com todas as datas válidas deve retornar inalterado."""
        df = pd.DataFrame({
            "data_evento": [pd.Timestamp("2025-08-10"), pd.Timestamp("2025-08-08")],
            "ticker": ["EURBRL", "USDBRL"],
        })
        result = SeriesLoadDataProcessor._filter_invalid_data_evento(df, "FX History")
        assert len(result) == 2
        assert result["ticker"].tolist() == ["EURBRL", "USDBRL"]

    def test_filters_nat_rows(self):
        """Linhas com data_evento NaT devem ser filtradas."""
        df = pd.DataFrame({
            "data_evento": [pd.NaT, pd.Timestamp("2025-08-08"), pd.NaT],
            "ticker": ["BAD1", "GOOD", "BAD2"],
        })
        result = SeriesLoadDataProcessor._filter_invalid_data_evento(df, "FX History")
        assert len(result) == 1
        assert result["ticker"].tolist() == ["GOOD"]

    def test_filters_none_rows(self):
        """Linhas com data_evento None devem ser filtradas."""
        df = pd.DataFrame({
            "data_evento": [None, "2025-08-08"],
            "ticker": ["BAD", "GOOD"],
        })
        result = SeriesLoadDataProcessor._filter_invalid_data_evento(df, "FX History")
        assert len(result) == 1
        assert result["ticker"].tolist() == ["GOOD"]

    def test_empty_dataframe_unchanged(self):
        """DataFrame vazio deve retornar sem erro."""
        df = pd.DataFrame({"data_evento": [], "ticker": []})
        result = SeriesLoadDataProcessor._filter_invalid_data_evento(df, "FX History")
        assert len(result) == 0

    def test_no_data_evento_column_unchanged(self):
        """DataFrame sem coluna data_evento deve retornar inalterado."""
        df = pd.DataFrame({"ticker": ["EURBRL"]})
        result = SeriesLoadDataProcessor._filter_invalid_data_evento(df, "FX History")
        assert len(result) == 1


class TestTransformFxInvalidDate:
    """Verifica que _transform_fx filtra linhas com Date corrompida."""

    def test_fx_corrupted_date_filtered(self):
        """Linha com '20int' na coluna Date deve ser filtrada, demais linhas preservadas."""
        df = pd.DataFrame({
            "From": ["EUR", "EUR", "EUR"],
            "To": ["BRL", "BRL", "BRL"],
            "Date": ["2025-08-10", "20int", "2025-08-08"],
            "Open": [5.642, 5.602, 5.625],
            "High": [5.675, 5.632, 5.652],
            "Low": [5.638, 5.598, 5.621],
            "Close": [5.661, 5.621, 5.648],
            "Reference_Date": ["2025-08-10", "2025-08-10", "2025-08-10"],
        })
        result = SeriesLoadDataProcessor._transform_fx(df, "FX History")

        assert len(result) == 2
        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "CAMBIO").all()
        assert result["data_evento"].notna().all()

    def test_fx_all_valid_dates_unchanged(self):
        """FX com todas as datas válidas deve retornar todas as linhas."""
        df = pd.DataFrame({
            "From": ["EUR", "USD"],
            "To": ["BRL", "BRL"],
            "Date": ["2025-08-10", "2025-08-08"],
            "Open": [5.642, 4.852],
            "High": [5.675, 4.875],
            "Low": [5.638, 4.841],
            "Close": [5.661, 4.868],
            "Reference_Date": ["2025-08-10", "2025-08-10"],
        })
        result = SeriesLoadDataProcessor._transform_fx(df, "FX History")
        assert len(result) == 2
        assert result["data_evento"].notna().all()


class TestTransformStockInvalidDate:
    """Verifica que _transform_stock filtra linhas com Date corrompida."""

    def test_stock_corrupted_date_filtered(self):
        """Linha com data corrompida deve ser filtrada."""
        df = pd.DataFrame({
            "Ticker": ["AAPL", "AAPL", "AAPL"],
            "Date": ["2025-03-07", "NOTADATE", "2025-03-06"],
            "Open": [100.0, 101.0, 99.0],
            "High": [110.0, 111.0, 105.0],
            "Low": [90.0, 91.0, 88.0],
            "Close": [105.0, 106.0, 102.0],
            "Volume": [1000, 2000, 1500],
            "Reference_Date": ["2025-03-07", "2025-03-07", "2025-03-07"],
        })
        result = SeriesLoadDataProcessor._transform_stock(df, "ETFs Prices", "USD")

        assert len(result) == 2
        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "ACAO_US").all()
        assert result["data_evento"].notna().all()


class TestTransformDividendInvalidDate:
    """Verifica que _transform_dividend filtra linhas com Pay_Date corrompida."""

    def test_dividend_corrupted_pay_date_filtered(self):
        """Linha com Pay_Date corrompida deve ser filtrada."""
        df = pd.DataFrame({
            "Ticker": ["AAPL", "AAPL", "AAPL"],
            "Payout_Frequency": ["Quarterly", "Quarterly", "Quarterly"],
            "Ex_Dividend_Date": ["2026-05-15", "2026-05-15", "2026-05-15"],
            "Record_Date": ["2026-05-16", "2026-05-16", "2026-05-16"],
            "Pay_Date": ["2026-05-30", "BADPAY", "2026-05-29"],
            "Cash_Amount": [0.25, 0.25, 0.25],
            "Reference_Date": ["2026-05-28", "2026-05-28", "2026-05-28"],
        })
        result = SeriesLoadDataProcessor._transform_dividend(df, "ETF Dividends", "USD")

        assert len(result) == 2
        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "DIVIDENDO_US").all()
        assert result["data_evento"].notna().all()


class TestTransformCalendarioProventosInvalidDate:
    """Verifica que _transform_calendario_proventos filtra linhas com data corrompida."""

    def test_calendario_both_dates_corrupted_filtered(self):
        """Linha onde Pay_Date e Ex_Dividend_Date são inválidos deve ser filtrada."""
        df = pd.DataFrame({
            "Ticker": ["PETR4", "PETR4", "VALE3"],
            "Payout_Frequency": ["Trimestral", "Trimestral", "Mensal"],
            "Ex_Dividend_Date": ["2026-06-15", "BADEX", "2026-07-10"],
            "Record_Date": ["2026-06-16", "2026-06-16", "2026-07-11"],
            "Pay_Date": ["2026-06-30", "BADPAY", "2026-07-25"],
            "Cash_Amount": [1.50, 1.50, 0.80],
            "Reference_Date": ["2026-06-28", "2026-06-28", "2026-07-28"],
            "DY": [5.2, 5.2, 3.1],
            "Extra_Info": ['{"tipo": "dividendo"}', '{"tipo": "dividendo"}', '{"tipo": "jcp"}'],
        })
        result = SeriesLoadDataProcessor._transform_calendario_proventos(df, "Calendario Proventos")

        assert len(result) == 2
        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "CALENDARIO_PROVENTOS").all()
        assert result["data_evento"].notna().all()