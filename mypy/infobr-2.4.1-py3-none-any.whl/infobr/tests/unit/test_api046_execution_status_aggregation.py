"""API-046: execution status aggregation and timeout behaviour."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from infobr.api.services import ExecutionService


class FakeExecutionRepository:
    """In-memory execution repository for unit tests."""

    def __init__(self):
        self.rows: dict[str, SimpleNamespace] = {}

    def get_by_id(self, execution_id: str):
        return self.rows.get(execution_id)

    def update_status(self, execution_id, *, status, started_at=None, finished_at=None, error_message=None, output=None):
        row = self.rows.get(execution_id)
        if row is None:
            return None
        row.status = status
        if started_at is not None:
            row.started_at = started_at
        if finished_at is not None:
            row.finished_at = finished_at
        if error_message is not None:
            row.error_message = error_message
        if output is not None:
            row.output = output
        row.updated_at = datetime.utcnow()
        return row

    def list_active(self):
        return [r for r in self.rows.values() if r.status in ("queued", "running")]


def _fake_session_scope(repo: FakeExecutionRepository):
    @contextmanager
    def _scope():
        class _Session:
            pass

        yield _Session()

    return _scope


def test_aggregate_status_all_scopes_success():
    output = [
        {"scope": "A", "success": True, "error_message": None},
        {"scope": "B", "success": True, "error_message": None},
    ]
    status, error = ExecutionService._aggregate_status(output)
    assert status == "success"
    assert error is None


def test_aggregate_status_one_scope_fails():
    output = [
        {"scope": "A", "success": True, "error_message": None},
        {"scope": "B", "success": False, "error_message": "boom"},
    ]
    status, error = ExecutionService._aggregate_status(output)
    assert status == "failed"
    assert "1 of 2 scope(s) failed" in error
    assert "[B] boom" in error


def test_aggregate_status_multiple_scope_errors_summarized():
    output = [
        {"scope": "A", "success": False, "error_message": "e1; e2"},
        {"scope": "B", "success": False, "error_message": "e3"},
    ]
    status, error = ExecutionService._aggregate_status(output)
    assert status == "failed"
    assert "2 of 2 scope(s) failed" in error
    assert "[A] e1" in error
    assert "[A] e2" in error
    assert "[B] e3" in error


def test_aggregate_status_empty_output():
    status, error = ExecutionService._aggregate_status([])
    assert status == "success"
    assert error is None


def test_is_expired_true_for_old_start():
    old = datetime.utcnow() - timedelta(minutes=181)
    assert ExecutionService._is_expired(old) is True


def test_is_expired_false_for_recent_start():
    recent = datetime.utcnow() - timedelta(minutes=90)
    assert ExecutionService._is_expired(recent) is False


def test_is_expired_handles_timezone_aware_datetime():
    old = datetime.now(timezone.utc) - timedelta(minutes=181)
    assert ExecutionService._is_expired(old) is True


@contextmanager
def _patch_session_repo(repo):
    import infobr.api.services.execution_service as svc

    original_scope = svc.session_scope
    original_repo = svc.ExecutionRepository
    try:
        svc.session_scope = _fake_session_scope(repo)
        svc.ExecutionRepository = lambda _session: repo
        yield
    finally:
        svc.session_scope = original_scope
        svc.ExecutionRepository = original_repo


def test_recover_orphaned_executions_marks_stale_running_as_failed(monkeypatch, clean_env):
    repo = FakeExecutionRepository()
    stale = SimpleNamespace(
        id="exec-stale",
        pipeline_name="series.extract.FII_PRICES",
        status="running",
        created_at=datetime.utcnow() - timedelta(minutes=240),
        started_at=datetime.utcnow() - timedelta(minutes=210),
        finished_at=None,
        error_message=None,
        updated_at=None,
    )
    recent = SimpleNamespace(
        id="exec-recent",
        pipeline_name="series.extract.FX",
        status="running",
        created_at=datetime.utcnow() - timedelta(minutes=5),
        started_at=datetime.utcnow() - timedelta(minutes=5),
        finished_at=None,
        error_message=None,
        updated_at=None,
    )
    repo.rows = {"exec-stale": stale, "exec-recent": recent}

    with _patch_session_repo(repo):
        recovered = ExecutionService.recover_orphaned_executions()

    assert recovered == 1
    assert stale.status == "failed"
    assert "orphaned" in stale.error_message
    assert recent.status == "running"
    assert recent.error_message is None


def test_recover_orphaned_executions_marks_stale_queued_as_failed(monkeypatch, clean_env):
    repo = FakeExecutionRepository()
    stale = SimpleNamespace(
        id="exec-queued-stale",
        pipeline_name="series.load.FX",
        status="queued",
        created_at=datetime.utcnow() - timedelta(minutes=240),
        started_at=None,
        finished_at=None,
        error_message=None,
        updated_at=None,
    )
    repo.rows = {"exec-queued-stale": stale}

    with _patch_session_repo(repo):
        recovered = ExecutionService.recover_orphaned_executions()

    assert recovered == 1
    assert stale.status == "failed"
    assert "orphaned" in stale.error_message


def test_execute_aborts_when_execution_missing(monkeypatch, clean_env):
    repo = FakeExecutionRepository()

    with _patch_session_repo(repo):
        # Should not raise; just log and return.
        ExecutionService._execute("missing-id", "series.extract.FX", {})

    assert repo.rows == {}


def test_execute_marks_expired_before_running(monkeypatch, clean_env):
    repo = FakeExecutionRepository()
    stale = SimpleNamespace(
        id="exec-expired",
        pipeline_name="series.extract.FX",
        status="queued",
        created_at=datetime.utcnow() - timedelta(minutes=240),
        started_at=None,
        finished_at=None,
        error_message=None,
        updated_at=None,
    )
    repo.rows = {"exec-expired": stale}

    with _patch_session_repo(repo):
        ExecutionService._execute("exec-expired", "series.extract.FX", {})

    assert stale.status == "failed"
    assert "exceeded" in stale.error_message
    assert stale.started_at is None
    assert stale.finished_at is not None
