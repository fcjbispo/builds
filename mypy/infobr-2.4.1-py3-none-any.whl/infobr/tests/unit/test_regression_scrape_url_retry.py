"""
Teste de regressão para o retry com backoff de DataTools.scrape_url.

O provider StockAnalysis (usado por ETF_PRICES, EU_PRICES, etc.) sofre com
HTTP 403/429 intermitentes do stockanalysis.com durante execuções longas.
A correção adiciona retry com User-Agent rotation e backoff exponencial
em DataTools.scrape_url, refletindo em todas as pipelines que o utilizam.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import patch, MagicMock

import pytest

from infobr.data.tools import DataTools


class TestScrapeUrlRetry:
    """DataTools.scrape_url deve retry em status 403/429/5xx."""

    @staticmethod
    def _make_response(status_code: int | None, error: str | None = None) -> dict[str, Any]:
        return {
            "data": {"markdown": "", "metadata": {"statusCode": status_code}},
            "error": error,
        }

    @pytest.fixture
    def _patch_secrets(self, monkeypatch):
        """Provide a no-op secrets object for scrape_url."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        secrets = MagicMock()
        secrets.firecrawl_base_url = ""
        secrets.firecrawl_api_key = ""
        with patch("infobr.secrets.get_secrets", return_value=secrets):
            yield secrets

    def test_scrape_url_retries_on_403_and_succeeds(self, _patch_secrets):
        """Retry deve eventualmente aceitar uma resposta 200 após 403s."""
        responses = [
            self._make_response(403),
            self._make_response(403),
            self._make_response(200),
        ]
        call_iter = iter(responses)
        call_count = {"n": 0}

        def _sync_request(*args, **kwargs):
            call_count["n"] += 1
            return MagicMock(json=lambda: next(call_iter))

        with patch(
            "fbpyutils.http.HTTPClient",
            return_value=MagicMock(sync_request=_sync_request, _sync_client=None),
        ):
            with patch("httpx.Client"):
                result = DataTools.scrape_url(
                    "https://stockanalysis.com/etf/VYM/history/",
                    timeout=30000,
                    max_retries=3,
                )

        assert result["data"]["metadata"]["statusCode"] == 200
        assert call_count["n"] == 3

    def test_scrape_url_fails_after_exhausted_retries(self, _patch_secrets):
        """Após esgotar retries, ValueError deve ser levantado."""
        responses = [
            self._make_response(403),
            self._make_response(403),
            self._make_response(403),
        ]
        call_iter = iter(responses)

        def _sync_request(*args, **kwargs):
            return MagicMock(json=lambda: next(call_iter))

        with patch(
            "fbpyutils.http.HTTPClient",
            return_value=MagicMock(sync_request=_sync_request, _sync_client=None),
        ):
            with patch("httpx.Client"):
                with pytest.raises(ValueError, match=r"HTTP Error \(403\)"):
                    DataTools.scrape_url(
                        "https://stockanalysis.com/etf/VYM/history/",
                        timeout=30000,
                        max_retries=3,
                    )

    def test_scrape_url_no_retry_on_immediate_200(self, _patch_secrets):
        """Não deve retry se a primeira resposta já for 200."""
        responses = [self._make_response(200)]
        call_iter = iter(responses)
        call_count = {"n": 0}

        def _sync_request(*args, **kwargs):
            call_count["n"] += 1
            return MagicMock(json=lambda: next(call_iter))

        with patch(
            "fbpyutils.http.HTTPClient",
            return_value=MagicMock(sync_request=_sync_request, _sync_client=None),
        ):
            with patch("httpx.Client"):
                result = DataTools.scrape_url(
                    "https://stockanalysis.com/etf/VYM/history/",
                    timeout=30000,
                    max_retries=3,
                )

        assert result["data"]["metadata"]["statusCode"] == 200
        assert call_count["n"] == 1

    def test_scrape_url_user_agent_rotates(self, _patch_secrets):
        """Cada tentativa deve enviar um User-Agent diferente."""
        responses = [
            self._make_response(403),
            self._make_response(403),
            self._make_response(200),
        ]
        call_iter = iter(responses)
        captured_agents: list[str] = []

        def _sync_request(*args, **kwargs):
            return MagicMock(json=lambda: next(call_iter))

        with patch(
            "fbpyutils.http.HTTPClient",
            return_value=MagicMock(sync_request=_sync_request, _sync_client=None),
        ):
            with patch("httpx.Client") as mock_httpx:
                def _capture_and_call(*args, **kwargs):
                    headers = kwargs.get("headers", {})
                    captured_agents.append(headers.get("User-Agent", ""))
                    return MagicMock()

                mock_httpx.side_effect = _capture_and_call
                DataTools.scrape_url(
                    "https://stockanalysis.com/etf/VYM/history/",
                    timeout=30000,
                    max_retries=3,
                )

        assert len(captured_agents) == 3
        assert len(set(captured_agents)) >= 2
