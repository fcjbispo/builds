"""API-045: scope-level concurrency lock for pipeline execution dispatch."""

from __future__ import annotations

from contextlib import contextmanager
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin
from infobr.api.main import app
from infobr.api.routers import pipelines as pipelines_router
from infobr.api.services import ExecutionService, ScopeConflictError


def test_dispatch_execution_blocks_when_scope_conflicts(monkeypatch):
    active_execution = SimpleNamespace(
        id="exec-active-1",
        pipeline_name="series.extract.full",
        params='{"scope":"FII_PRICES"}',
        status="running",
    )

    class FakeExecRepo:
        def __init__(self, _session):
            self.create_called = False

        def list_active(self):
            return [active_execution]

        def create(self, **_kwargs):
            self.create_called = True
            raise AssertionError("create must not be called on scope conflict")

    class FakePipelineRepo:
        def __init__(self, _session):
            pass

        def get_config(self, _name):
            return {"scopes": ["FII_PRICES", "FII_DY"]}

    @contextmanager
    def fake_session_scope():
        yield SimpleNamespace()

    monkeypatch.setattr("infobr.api.services.execution_service.session_scope", fake_session_scope)
    monkeypatch.setattr("infobr.api.services.execution_service.ExecutionRepository", FakeExecRepo)
    monkeypatch.setattr("infobr.api.services.execution_service.PipelineRepository", FakePipelineRepo)

    with pytest.raises(ScopeConflictError) as exc:
        ExecutionService.dispatch_execution(
            pipeline_name="series.extract.full",
            requested_by="admin@example.com",
            params={"scope": "FII_PRICES"},
        )
    assert "FII_PRICES" in str(exc.value)
    assert "exec-active-1" in str(exc.value)


def test_pipeline_execute_route_returns_409_on_scope_conflict(monkeypatch):
    app.dependency_overrides[require_admin] = lambda: SimpleNamespace(
        email="admin@example.com", profile="ADMIN"
    )
    monkeypatch.setattr(
        pipelines_router.ExecutionService,
        "dispatch_execution",
        lambda **_kwargs: (_ for _ in ()).throw(
            ScopeConflictError(
                requested_scopes=("FII_PRICES",),
                conflicting_scopes=("FII_PRICES",),
                conflicting_execution_ids=("exec-active-1",),
            )
        ),
    )

    client = TestClient(app)
    resp = client.post(
        "/api/v1/pipelines/series.extract.full/execute",
        json={"parallelize": True, "progress": False, "params": {"scope": "FII_PRICES"}},
    )
    assert resp.status_code == 409
    payload = resp.json()
    assert "details" in payload
    assert payload["details"]["conflicting_scopes"] == ["FII_PRICES"]
    assert payload["details"]["conflicting_execution_ids"] == ["exec-active-1"]

    app.dependency_overrides.clear()