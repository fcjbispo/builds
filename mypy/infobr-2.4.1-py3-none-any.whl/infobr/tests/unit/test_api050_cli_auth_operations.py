"""API-050: CLI authentication operations honor endpoint privileges."""

from __future__ import annotations

import sys

import pytest

from infobr.data.elt import ELT_TUI
from infobr.api.client import ApiResult


class _FakeClient:
    """Minimal ApiClient stub that records dispatched endpoints."""

    def __init__(self):
        self.calls: list[tuple] = []
        self.base_url = "http://localhost:8500/api/v1"

    def _record(self, name, result, **kwargs):
        self.calls.append((name, kwargs))
        return result

    def login(self, *, email, password):
        return self._record("login", ApiResult(ok=True, status_code=200, data={
            "access_token": "tok",
            "email": email,
            "profile": "ADMIN",
        }), email=email)

    def auth_me(self, *, token):
        return self._record("auth_me", ApiResult(ok=True, status_code=200, data={
            "authenticated": True,
            "scheme": "Bearer",
            "email": "a@b.com",
            "profile": "ADMIN",
        }), token=token)

    def logout(self, *, token):
        return self._record("logout", ApiResult(ok=True, status_code=200, data={"success": True}), token=token)

    def list_tokens(self, *, token, limit=100):
        return self._record("list_tokens", ApiResult(ok=True, status_code=200, data={
            "items": [{"id": "t1", "email": "a@b.com", "profile": "ADMIN",
                       "token_prefix": "ab", "is_active": True}], "total": 1}))


def _make_tui(profile: str | None = "USER") -> ELT_TUI:
    client = _FakeClient()
    tui = ELT_TUI(client)
    tui.token = "tok"
    tui.profile = profile
    return tui


def test_authenticate_stores_profile(monkeypatch):
    monkeypatch.setenv("INFOBR_USERNAME", "A@B.COM")
    monkeypatch.setenv("INFOBR_PASSWD", "secret")
    tui = ELT_TUI(_FakeClient())
    assert tui.authenticate() is True
    assert tui.token == "tok"
    assert tui.profile == "ADMIN"
    assert tui.is_admin is True


def test_is_admin_reflects_profile():
    assert _make_tui("USER").is_admin is False
    assert _make_tui("ADMIN").is_admin is True
    assert _make_tui(None).is_admin is False


def test_show_me_and_logout_dispatch_to_api():
    tui = _make_tui("USER")
    assert tui.show_me() is True
    assert (tui.client.calls[0][0], tui.client.calls[0][1]["token"]) == ("auth_me", "tok")

    assert tui.do_logout() is True
    assert tui.client.calls[1][0] == "logout"


def test_list_tokens_admin_dispatches_and_renders():
    tui = _make_tui("ADMIN")
    assert tui.list_tokens_admin() is True
    assert tui.client.calls[0][0] == "list_tokens"


def test_admin_batch_operations_blocked_for_user(monkeypatch):
    """Batch flags for admin endpoints must fail when profile is not ADMIN."""

    import infobr.data.elt as elt_mod

    captured: dict = {}

    def fake_authenticate(self):
        self.token = "tok"
        self.profile = "USER"
        return True

    def fake_list_tokens_admin(self):
        captured["called"] = True
        return True

    monkeypatch.setenv("INFOBR_API_BASE_URL", "http://127.0.0.1:8500/api/v1")
    monkeypatch.setattr(sys, "argv", ["infobr-data-elt", "--list-tokens"])
    monkeypatch.setattr(elt_mod.ELT_TUI, "authenticate", fake_authenticate)
    monkeypatch.setattr(elt_mod.ELT_TUI, "list_tokens_admin", fake_list_tokens_admin)

    with pytest.raises(SystemExit) as exc:
        elt_mod.main()
    assert exc.value.code == 1
    assert not captured.get("called")


def test_admin_batch_operations_blocked_for_user_create_token(monkeypatch):
    """--create-token and friends are also admin-only."""

    import infobr.data.elt as elt_mod

    def fake_authenticate(self):
        self.token = "tok"
        self.profile = "USER"
        return True

    monkeypatch.setenv("INFOBR_API_BASE_URL", "http://127.0.0.1:8500/api/v1")
    monkeypatch.setattr(sys, "argv", ["infobr-data-elt", "--create-token"])
    monkeypatch.setattr(elt_mod.ELT_TUI, "authenticate", fake_authenticate)

    with pytest.raises(SystemExit) as exc:
        elt_mod.main()
    assert exc.value.code == 1