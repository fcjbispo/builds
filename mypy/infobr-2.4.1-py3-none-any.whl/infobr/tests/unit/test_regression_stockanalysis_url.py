"""
Teste de regressão para o bug: StockAnalysis provider montava a URL a partir de
kind=asset_type (tipo='etf'), causando HTTP 404 em ativos que não são ETFs
(stocks/REITs/BDCs em /stocks/) e não cobrindo papéis estrangeiros (/quote/ams/,
/quote/epa/).

A correção usa o campo infobr.ativos.url (URL-base com placeholder {ticker}) como
fonte do path; o provider apenas substitui {ticker} e anexa a seção (history/ ou
dividend/). Valida os 4 padrões reais do campo url.
"""

import pytest
from infobr.data.providers.stockanalysis import (
    _resolve_url,
    StockAnalysisStockDataProvider,
    StockAnalysisDividendDataProvider,
)


class TestResolveUrl:
    """_resolve_url deve cobrir todos os padrões de infobr.ativos.url."""

    @pytest.mark.parametrize(
        "url_template,ticker,section,expected",
        [
            # ETF US
            (
                "https://stockanalysis.com/etf/{ticker}/",
                "VYM",
                "history",
                "https://stockanalysis.com/etf/VYM/history/",
            ),
            (
                "https://stockanalysis.com/etf/{ticker}/",
                "VYM",
                "dividend",
                "https://stockanalysis.com/etf/VYM/dividend/",
            ),
            # Stock/REIT/BDC US (antes mal-classificados como etf -> 404)
            (
                "https://stockanalysis.com/stocks/{ticker}/",
                "O",
                "history",
                "https://stockanalysis.com/stocks/O/history/",
            ),
            (
                "https://stockanalysis.com/stocks/{ticker}/",
                "STAG",
                "dividend",
                "https://stockanalysis.com/stocks/STAG/dividend/",
            ),
            # ETF UCITS Amsterdã
            (
                "https://stockanalysis.com/quote/ams/{ticker}/",
                "IPRP",
                "history",
                "https://stockanalysis.com/quote/ams/IPRP/history/",
            ),
            # Stock Paris (EPA)
            (
                "https://stockanalysis.com/quote/epa/{ticker}/",
                "TTE",
                "dividend",
                "https://stockanalysis.com/quote/epa/TTE/dividend/",
            ),
        ],
    )
    def test_resolve_url_patterns(self, url_template, ticker, section, expected):
        assert _resolve_url(url_template, ticker, section) == expected

    def test_resolve_url_handles_missing_trailing_slash(self):
        # Robustez: url-base sem barra final ainda monta URL válida.
        assert (
            _resolve_url("https://stockanalysis.com/etf/{ticker}", "VYM", "history")
            == "https://stockanalysis.com/etf/VYM/history/"
        )


class TestProviderExpectedParams:
    """Providers devem exigir `url` (não mais `asset_type`)."""

    def test_stock_provider_requires_url(self):
        assert "url" in StockAnalysisStockDataProvider.EXPECTED_PARAMS
        assert StockAnalysisStockDataProvider.EXPECTED_PARAMS["url"][1] is True
        assert "asset_type" not in StockAnalysisStockDataProvider.EXPECTED_PARAMS

    def test_dividend_provider_requires_url(self):
        assert "url" in StockAnalysisDividendDataProvider.EXPECTED_PARAMS
        assert StockAnalysisDividendDataProvider.EXPECTED_PARAMS["url"][1] is True
        assert "asset_type" not in StockAnalysisDividendDataProvider.EXPECTED_PARAMS