"""Repository for pipeline executions stored in the database."""

from __future__ import annotations

from datetime import datetime
import json
from typing import Any
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from infobr.api.models import Execution


class ExecutionRepository:
    """CRUD operations for pipeline executions."""

    VALID_STATUSES = {"queued", "running", "success", "failed", "canceled"}

    def __init__(self, session: Session):
        self.session = session

    @staticmethod
    def _new_id() -> str:
        return uuid4().hex[:32]

    @staticmethod
    def _normalize_status(status: str) -> str:
        value = (status or "").strip().lower()
        if value not in ExecutionRepository.VALID_STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. Expected one of {sorted(ExecutionRepository.VALID_STATUSES)}"
            )
        return value

    def create(
        self,
        *,
        pipeline_name: str,
        status: str = "queued",
        requested_by: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> Execution:
        row = Execution(
            id=self._new_id(),
            pipeline_name=pipeline_name,
            status=self._normalize_status(status),
            requested_by=requested_by,
            params=json.dumps(params, ensure_ascii=False, sort_keys=True) if params else None,
            created_at=datetime.utcnow(),
        )
        self.session.add(row)
        self.session.flush()
        return row

    def get_by_id(self, execution_id: str) -> Execution | None:
        stmt = select(Execution).where(Execution.id == execution_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def list(
        self,
        *,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> list[Execution]:
        stmt = (
            select(Execution)
            .order_by(Execution.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        if pipeline_name:
            stmt = stmt.where(Execution.pipeline_name == pipeline_name)
        if status:
            stmt = stmt.where(Execution.status == self._normalize_status(status))
        if requested_by:
            stmt = stmt.where(Execution.requested_by == requested_by)
        return list(self.session.execute(stmt).scalars().all())

    def count(
        self,
        *,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> int:
        stmt = select(func.count(Execution.id))
        if pipeline_name:
            stmt = stmt.where(Execution.pipeline_name == pipeline_name)
        if status:
            stmt = stmt.where(Execution.status == self._normalize_status(status))
        if requested_by:
            stmt = stmt.where(Execution.requested_by == requested_by)
        return int(self.session.execute(stmt).scalar_one())

    def list_active(self) -> list[Execution]:
        stmt = (
            select(Execution)
            .where(Execution.status.in_(("queued", "running")))
            .order_by(Execution.created_at.desc())
        )
        return list(self.session.execute(stmt).scalars().all())

    def update_status(
        self,
        execution_id: str,
        *,
        status: str,
        started_at: datetime | None = None,
        finished_at: datetime | None = None,
        error_message: str | None = None,
        output: list[dict[str, Any]] | None = None,
    ) -> Execution | None:
        row = self.get_by_id(execution_id)
        if not row:
            return None

        row.status = self._normalize_status(status)
        if started_at is not None:
            row.started_at = started_at
        if finished_at is not None:
            row.finished_at = finished_at
        if error_message is not None:
            row.error_message = error_message
        if output is not None:
            row.output = json.dumps(output, ensure_ascii=False, default=str)
        row.updated_at = datetime.utcnow()
        self.session.flush()
        return row

    def get_output(self, execution_id: str) -> list[dict[str, Any]] | None:
        row = self.get_by_id(execution_id)
        if not row or not row.output:
            return None
        return json.loads(row.output)

    def get_params(self, execution_id: str) -> dict[str, Any]:
        row = self.get_by_id(execution_id)
        if not row or not row.params:
            return {}
        try:
            return json.loads(row.params)
        except (json.JSONDecodeError, TypeError):
            return {}