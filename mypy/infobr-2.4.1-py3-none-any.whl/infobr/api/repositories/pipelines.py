"""Repository for pipeline configurations stored in the database."""

from __future__ import annotations

from datetime import datetime
import json
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from infobr.api.models import Pipeline


class PipelineRepository:
    """CRUD operations for pipeline configurations."""

    def __init__(self, session: Session):
        self.session = session

    def get_by_name(self, name: str) -> Pipeline | None:
        stmt = select(Pipeline).where(Pipeline.name == name)
        return self.session.execute(stmt).scalar_one_or_none()

    def list(self, *, offset: int = 0, limit: int = 100) -> list[Pipeline]:
        stmt = (
            select(Pipeline)
            .order_by(Pipeline.name)
            .offset(offset)
            .limit(limit)
        )
        return list(self.session.execute(stmt).scalars().all())

    def count(self) -> int:
        return int(self.session.execute(select(func.count(Pipeline.name))).scalar_one())

    def create(self, *, name: str, config: dict[str, Any]) -> Pipeline:
        row = Pipeline(
            name=name,
            config=json.dumps(config, ensure_ascii=False, sort_keys=True),
            created_at=datetime.utcnow(),
        )
        self.session.add(row)
        self.session.flush()
        return row

    def upsert(self, *, name: str, config: dict[str, Any]) -> Pipeline:
        row = self.get_by_name(name)
        if row:
            row.config = json.dumps(config, ensure_ascii=False, sort_keys=True)
            row.updated_at = datetime.utcnow()
            self.session.flush()
            return row
        return self.create(name=name, config=config)

    def delete(self, name: str) -> bool:
        row = self.get_by_name(name)
        if not row:
            return False
        self.session.delete(row)
        self.session.flush()
        return True

    def get_config(self, name: str) -> dict[str, Any] | None:
        row = self.get_by_name(name)
        if not row:
            return None
        return json.loads(row.config)