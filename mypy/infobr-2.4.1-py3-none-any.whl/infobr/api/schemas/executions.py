"""Execution endpoint schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class ExecutionView(BaseModel):
    """Execution tracking row exposed by API."""
    id: str
    pipeline_name: str
    status: str
    requested_by: str | None
    params: dict[str, Any] | None
    started_at: datetime | None
    finished_at: datetime | None
    error_message: str | None
    created_at: datetime
    updated_at: datetime | None


class ExecutionListResponse(BaseModel):
    """Paginated execution list response."""
    items: list[ExecutionView]
    total: int
    offset: int
    limit: int


class ExecutionResultsResponse(BaseModel):
    """Paginated operation results bound to one execution."""
    execution_id: str
    status: str
    page: int
    page_size: int
    total_records: int
    total_pages: int
    items: list[dict[str, Any]]
    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float


class ExecutionExportResponse(BaseModel):
    """Response when exporting an execution's output to JSON."""
    execution_id: str
    pipeline_name: str
    output: list[dict[str, Any]]


class MigrateResponse(BaseModel):
    """Response from the migration endpoint."""
    pipelines_imported: int
    operations_imported: int
    errors: list[str]