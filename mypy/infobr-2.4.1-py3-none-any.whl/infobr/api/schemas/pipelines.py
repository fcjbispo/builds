"""Pipeline endpoint schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PipelineListItem(BaseModel):
    """Pipeline metadata exposed by API."""
    name: str
    created_at: datetime
    updated_at: datetime | None


class PipelineListResponse(BaseModel):
    """Response payload for pipeline listing."""
    items: list[PipelineListItem]
    total: int


class PipelineDetailResponse(BaseModel):
    """Response payload for pipeline detail/config."""
    name: str
    config: dict[str, Any]
    created_at: datetime
    updated_at: datetime | None


class PipelineImportRequest(BaseModel):
    """Payload to import a pipeline from JSON config."""
    name: str = Field(min_length=1, max_length=128)
    config: dict[str, Any]
    force: bool = False


class PipelineImportResponse(BaseModel):
    """Response when importing a pipeline."""
    name: str
    created: bool
    updated_at: datetime | None


class PipelineExecuteRequest(BaseModel):
    """Payload to enqueue one pipeline execution."""
    parallelize: bool = True
    progress: bool = False
    params: dict[str, Any] = Field(default_factory=dict)


class PipelineExecuteDispatchResponse(BaseModel):
    """Immediate async dispatch response."""
    execution_id: str
    status: str
    pipeline_name: str


class PipelineExportResponse(BaseModel):
    """Response when exporting a pipeline to JSON."""
    name: str
    config: dict[str, Any]