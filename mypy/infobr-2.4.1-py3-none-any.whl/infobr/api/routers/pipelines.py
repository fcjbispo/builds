"""Pipeline management routes (ADMIN)."""

from __future__ import annotations

import json
from fastapi import APIRouter, Depends, HTTPException, status

from infobr.api.dependencies.security import require_admin
from infobr.api.models import Token
from infobr.api.db import session_scope
from infobr.api.repositories import PipelineRepository
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.pipelines import (
    PipelineDetailResponse,
    PipelineExecuteDispatchResponse,
    PipelineExecuteRequest,
    PipelineExportResponse,
    PipelineImportRequest,
    PipelineImportResponse,
    PipelineListItem,
    PipelineListResponse,
)
from infobr.api.services import ExecutionService, ScopeConflictError

router = APIRouter()


@router.get(
    "/pipelines",
    response_model=PipelineListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipelines_list(
    _current_token: Token = Depends(require_admin),
    offset: int = 0,
    limit: int = 100,
) -> PipelineListResponse:
    with session_scope() as session:
        repo = PipelineRepository(session)
        items = repo.list(offset=offset, limit=limit)
        total = repo.count()
        result_items = [
            PipelineListItem(
                name=p.name,
                created_at=p.created_at,
                updated_at=p.updated_at,
            )
            for p in items
        ]
    return PipelineListResponse(items=result_items, total=total)


@router.get(
    "/pipelines/{pipeline_name}",
    response_model=PipelineDetailResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_detail(
    pipeline_name: str,
    _current_token: Token = Depends(require_admin),
) -> PipelineDetailResponse:
    with session_scope() as session:
        repo = PipelineRepository(session)
        p = repo.get_by_name(pipeline_name)
        if not p:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found",
            )
        config = json.loads(p.config)
        result = PipelineDetailResponse(
            name=p.name,
            config=config,
            created_at=p.created_at,
            updated_at=p.updated_at,
        )
    return result


@router.post(
    "/pipelines/import",
    response_model=PipelineImportResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        409: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_import(
    payload: PipelineImportRequest,
    _current_token: Token = Depends(require_admin),
) -> PipelineImportResponse:
    with session_scope() as session:
        repo = PipelineRepository(session)
        existing = repo.get_by_name(payload.name)
        if existing and not payload.force:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Pipeline '{payload.name}' already exists. Use force=true to overwrite.",
            )
        row = repo.upsert(name=payload.name, config=payload.config)
        created = existing is None
        return PipelineImportResponse(
            name=row.name,
            created=created,
            updated_at=row.updated_at,
        )


@router.post(
    "/pipelines/{pipeline_name}/execute",
    response_model=PipelineExecuteDispatchResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        409: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_execute(
    pipeline_name: str,
    payload: PipelineExecuteRequest | None = None,
    current_token: Token = Depends(require_admin),
) -> PipelineExecuteDispatchResponse:
    request = payload or PipelineExecuteRequest()
    params = dict(request.params)
    params["parallelize"] = request.parallelize
    params["progress"] = request.progress

    try:
        dispatch = ExecutionService.dispatch_execution(
            pipeline_name=pipeline_name,
            requested_by=current_token.email,
            params=params,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except ScopeConflictError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "message": str(exc),
                "requested_scopes": list(exc.requested_scopes),
                "conflicting_scopes": list(exc.conflicting_scopes),
                "conflicting_execution_ids": list(exc.conflicting_execution_ids),
            },
        ) from exc
    return PipelineExecuteDispatchResponse(
        execution_id=dispatch.execution_id,
        status=dispatch.status,
        pipeline_name=pipeline_name,
    )


@router.get(
    "/pipelines/{pipeline_name}/export",
    response_model=PipelineExportResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_export(
    pipeline_name: str,
    _current_token: Token = Depends(require_admin),
) -> PipelineExportResponse:
    with session_scope() as session:
        repo = PipelineRepository(session)
        p = repo.get_by_name(pipeline_name)
        if not p:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found",
            )
        config = json.loads(p.config)
    return PipelineExportResponse(name=pipeline_name, config=config)


@router.delete(
    "/pipelines/{pipeline_name}",
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_delete(
    pipeline_name: str,
    _current_token: Token = Depends(require_admin),
) -> None:
    with session_scope() as session:
        repo = PipelineRepository(session)
        deleted = repo.delete(pipeline_name)
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pipeline not found",
            )