"""Admin routes (ADMIN) — migration from filesystem to DB."""

from __future__ import annotations

import json
import os
from glob import glob
from fastapi import APIRouter, Depends, status

from infobr import env
from infobr.api.dependencies.security import require_admin
from infobr.api.db import session_scope
from infobr.api.repositories import PipelineRepository, ExecutionRepository
from infobr.api.models import Token
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.executions import MigrateResponse

router = APIRouter()


@router.post(
    "/admin/migrate",
    response_model=MigrateResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def migrate_from_filesystem(
    _current_token: Token = Depends(require_admin),
) -> MigrateResponse:
    """Migrate pipelines and operations from filesystem JSON to database."""
    pipelines_imported = 0
    operations_imported = 0
    errors: list[str] = []

    pipelines_dir = os.path.sep.join([env.USER_APP_FOLDER, "pipelines"])
    operations_dir = os.path.sep.join([env.USER_APP_FOLDER, "operations"])

    with session_scope() as session:
        pipe_repo = PipelineRepository(session)
        exec_repo = ExecutionRepository(session)

        # Migrate pipelines
        if os.path.exists(pipelines_dir):
            for path in sorted(glob(os.path.sep.join([pipelines_dir, "*.json"]))):
                name = os.path.basename(path).replace(".json", "")
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    if not isinstance(config, dict):
                        errors.append(f"Pipeline '{name}': invalid config format")
                        continue
                    pipe_repo.upsert(name=name, config=config)
                    pipelines_imported += 1
                except Exception as exc:
                    errors.append(f"Pipeline '{name}': {exc}")

        # Migrate operations as executions
        if os.path.exists(operations_dir):
            for path in sorted(
                glob(os.path.sep.join([operations_dir, "*.out.*.json"])),
                key=os.path.getmtime,
            ):
                basename = os.path.basename(path)
                parts = basename.split(".out.")
                pipeline_name = parts[0] if parts else ""
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        output = json.load(f)
                    if not isinstance(output, list):
                        errors.append(f"Operation '{basename}': invalid format")
                        continue
                    exec_repo.create(
                        pipeline_name=pipeline_name,
                        status="success",
                    )
                    operations_imported += 1
                except Exception as exc:
                    errors.append(f"Operation '{basename}': {exc}")

    return MigrateResponse(
        pipelines_imported=pipelines_imported,
        operations_imported=operations_imported,
        errors=errors,
    )