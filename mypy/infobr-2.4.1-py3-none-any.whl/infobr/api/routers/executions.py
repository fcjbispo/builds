"""Execution tracking routes (ADMIN)."""

from __future__ import annotations

import json
from fastapi import APIRouter, Depends, HTTPException, Query, status

from infobr.api.dependencies.security import require_admin
from infobr.api.models import Execution, Token
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.executions import (
    ExecutionExportResponse,
    ExecutionListResponse,
    ExecutionResultsResponse,
    ExecutionView,
)
from infobr.api.services import ExecutionService

router = APIRouter()


def _execution_to_view(execution: Execution) -> ExecutionView:
    params = None
    if execution.params:
        try:
            params = json.loads(execution.params)
        except (json.JSONDecodeError, TypeError):
            params = None
    return ExecutionView(
        id=execution.id,
        pipeline_name=execution.pipeline_name,
        status=execution.status,
        requested_by=execution.requested_by,
        params=params,
        started_at=execution.started_at,
        finished_at=execution.finished_at,
        error_message=execution.error_message,
        created_at=execution.created_at,
        updated_at=execution.updated_at,
    )


@router.get(
    "/executions",
    response_model=ExecutionListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def executions_list(
    _current_token: Token = Depends(require_admin),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    pipeline_name: str | None = Query(default=None),
    status_filter: str | None = Query(default=None, alias="status"),
    requested_by: str | None = Query(default=None),
) -> ExecutionListResponse:
    try:
        items = ExecutionService.list_executions(
            offset=offset,
            limit=limit,
            pipeline_name=pipeline_name,
            status=status_filter,
            requested_by=requested_by,
        )
        total = ExecutionService.count_executions(
            pipeline_name=pipeline_name,
            status=status_filter,
            requested_by=requested_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    return ExecutionListResponse(
        items=[_execution_to_view(e) for e in items],
        total=total,
        offset=offset,
        limit=limit,
    )


@router.get(
    "/executions/{execution_id}",
    response_model=ExecutionView,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def execution_detail(
    execution_id: str,
    _current_token: Token = Depends(require_admin),
) -> ExecutionView:
    execution = ExecutionService.get_execution(execution_id)
    if not execution:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Execution not found",
        )
    return _execution_to_view(execution)


@router.get(
    "/executions/{execution_id}/results",
    response_model=ExecutionResultsResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        409: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def execution_results(
    execution_id: str,
    _current_token: Token = Depends(require_admin),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=500),
) -> ExecutionResultsResponse:
    execution = ExecutionService.get_execution(execution_id)
    if not execution:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Execution not found",
        )

    if not execution.output:
        if execution.status in {"queued", "running"}:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Execution is still in progress; results are not available yet",
            )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Execution has no output",
        )

    output = ExecutionService.get_execution_output(execution_id)
    if output is None:
        output = []

    total_records = len(output)
    total_pages = (total_records + page_size - 1) // page_size if total_records else 0

    if total_pages == 0:
        items = []
    else:
        if page > total_pages:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"page must be between 1 and {total_pages}",
            )
        start = (page - 1) * page_size
        end = start + page_size
        items = output[start:end]

    total_ops = total_records
    successful = sum(1 for r in output if r.get("success", False))
    failed = total_ops - successful
    success_rate = (successful / total_ops * 100) if total_ops else 0.0

    return ExecutionResultsResponse(
        execution_id=execution.id,
        status=execution.status,
        page=page,
        page_size=page_size,
        total_records=total_records,
        total_pages=total_pages,
        items=items,
        total_operations=total_ops,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=success_rate,
    )


@router.get(
    "/executions/{execution_id}/export",
    response_model=ExecutionExportResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def execution_export(
    execution_id: str,
    _current_token: Token = Depends(require_admin),
) -> ExecutionExportResponse:
    execution = ExecutionService.get_execution(execution_id)
    if not execution:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Execution not found",
        )
    output = ExecutionService.get_execution_output(execution_id) or []
    return ExecutionExportResponse(
        execution_id=execution.id,
        pipeline_name=execution.pipeline_name,
        output=output,
    )