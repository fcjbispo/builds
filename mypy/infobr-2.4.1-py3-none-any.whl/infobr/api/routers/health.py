"""Health routes."""

from importlib.metadata import PackageNotFoundError, version

from fastapi import APIRouter

from infobr.api.schemas.common import HealthResponse
from infobr.api.schemas.errors import ErrorResponse

router = APIRouter()


def _api_version() -> str:
    """Return the installed InfoBR package version."""
    try:
        return version("infobr")
    except PackageNotFoundError:  # pragma: no cover - fallback for source runs
        return "unknown"


@router.get(
    "/health",
    response_model=HealthResponse,
    responses={500: {"model": ErrorResponse}},
)
def healthcheck() -> HealthResponse:
    """Liveness endpoint for API base checks."""
    return HealthResponse(status="ok", service="infobr-api", version=_api_version())
