"""Pipeline ORM model (DB-backed pipeline configuration)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from infobr import env
from infobr.api.db import Base

_SCHEMA = "infobr" if env.DB.dialect.name == "postgresql" else None


class Pipeline(Base):
    """Pipeline configuration stored in the database."""

    __tablename__ = "pipelines"
    __table_args__ = {"schema": _SCHEMA} if _SCHEMA else {}

    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    config: Mapped[str] = mapped_column(Text(), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(), nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)