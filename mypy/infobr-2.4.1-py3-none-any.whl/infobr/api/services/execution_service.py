"""Asynchronous pipeline execution service with DB-backed tracking."""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from infobr import logger
from infobr.api.db import session_scope
from infobr.api.models import Execution
from infobr.api.repositories import ExecutionRepository, PipelineRepository
from infobr.config import get_settings
from infobr.data.pipeline import Pipeline

_MAX_WORKERS = get_settings().pipeline_runners
_EXECUTION_TIMEOUT_MINUTES = get_settings().pipeline_execution_timeout_minutes
_EXECUTOR = ThreadPoolExecutor(max_workers=max(1, _MAX_WORKERS), thread_name_prefix="infobr-runner")


@dataclass(frozen=True)
class ExecutionDispatchResult:
    """Result returned immediately when an execution is queued."""

    execution_id: str
    status: str


@dataclass
class ScopeConflictError(Exception):
    """Raised when a requested execution conflicts with scopes already in execution."""

    requested_scopes: tuple[str, ...]
    conflicting_scopes: tuple[str, ...]
    conflicting_execution_ids: tuple[str, ...]

    def __str__(self) -> str:
        scopes = ", ".join(self.conflicting_scopes)
        execs = ", ".join(self.conflicting_execution_ids)
        return f"Scope already running: {scopes} (active executions: {execs})"


class ExecutionService:
    """Submit and track asynchronous pipeline executions."""

    @staticmethod
    def _save_partial_result(execution_id: str, scope: str, success: bool, error_message: str | None, data: list | None):
        """Save a single scope result to the database during execution."""
        try:
            with session_scope() as session:
                repo = ExecutionRepository(session)
                # Get current output array, append new result
                execution = repo.get_by_id(execution_id)
                if not execution:
                    return
                
                current_output = json.loads(execution.output) if execution.output else []
                new_result = {
                    "scope": scope,
                    "success": success,
                    "error_message": error_message,
                    "data": data or []
                }
                current_output.append(new_result)
                
                # Pass list, repository will convert to JSON
                repo.update_status(
                    execution_id,
                    status=execution.status,  # Keep current status
                    output=current_output,
                    error_message=execution.error_message
                )
        except Exception as e:
            logger.error(f"Failed to save partial result for execution {execution_id}: {e}")

    @staticmethod
    def _extract_scopes_from_config(config: dict[str, Any]) -> set[str]:
        raw_scopes = config.get("scopes")
        if not isinstance(raw_scopes, list):
            return set()
        return {str(s).strip() for s in raw_scopes if str(s).strip()}

    @staticmethod
    def _resolve_requested_scopes(pipeline_name: str, params: dict[str, Any]) -> set[str]:
        with session_scope() as session:
            repo = PipelineRepository(session)
            config = repo.get_config(pipeline_name)
        if not config:
            return set()
        explicit_scope = str(params.get("scope") or "").strip()
        if explicit_scope and explicit_scope.upper() != "ALL":
            return {explicit_scope}
        return ExecutionService._extract_scopes_from_config(config)

    @staticmethod
    def _safe_params(params_json: str | None) -> dict[str, Any]:
        if not params_json:
            return {}
        try:
            payload = json.loads(params_json)
        except Exception:
            return {}
        return payload if isinstance(payload, dict) else {}

    @staticmethod
    def _ensure_scope_is_available(
        *,
        repo: ExecutionRepository,
        pipeline_name: str,
        params: dict[str, Any],
    ) -> None:
        requested_scopes = ExecutionService._resolve_requested_scopes(pipeline_name, params)
        if not requested_scopes:
            return

        conflicting_scopes: set[str] = set()
        conflicting_executions: set[str] = set()
        for active in repo.list_active():
            active_params = ExecutionService._safe_params(active.params)
            active_scopes = ExecutionService._resolve_requested_scopes(active.pipeline_name, active_params)
            overlap = requested_scopes.intersection(active_scopes)
            if overlap:
                conflicting_scopes.update(overlap)
                conflicting_executions.add(active.id)

        if conflicting_scopes:
            raise ScopeConflictError(
                requested_scopes=tuple(sorted(requested_scopes)),
                conflicting_scopes=tuple(sorted(conflicting_scopes)),
                conflicting_execution_ids=tuple(sorted(conflicting_executions)),
            )

    @staticmethod
    def dispatch_execution(
        *,
        pipeline_name: str,
        requested_by: str | None = None,
        params: dict | None = None,
    ) -> ExecutionDispatchResult:
        params = params or {}

        with session_scope() as session:
            pipe_repo = PipelineRepository(session)
            config = pipe_repo.get_config(pipeline_name)
            if not config:
                raise ValueError(f"Pipeline '{pipeline_name}' not found in database")

            exec_repo = ExecutionRepository(session)
            ExecutionService._ensure_scope_is_available(
                repo=exec_repo,
                pipeline_name=pipeline_name,
                params=params,
            )
            execution = exec_repo.create(
                pipeline_name=pipeline_name,
                status="queued",
                requested_by=requested_by,
                params=params,
            )
            execution_id = execution.id

        _EXECUTOR.submit(ExecutionService._execute, execution_id, pipeline_name, params)
        return ExecutionDispatchResult(execution_id=execution_id, status="queued")

    @staticmethod
    def _aggregate_status(output: list[dict[str, Any]] | None) -> tuple[str, str | None]:
        """Return aggregated (status, error_message) based on scope results.

        An execution is successful only when every scope reports success.
        Individual scope errors are summarized in error_message.
        """
        if not output:
            return "success", None

        failed = [item for item in output if not item.get("success")]
        if not failed:
            return "success", None

        total = len(output)
        failed_count = len(failed)
        messages: list[str] = []
        for item in failed:
            scope = item.get("scope", "unknown")
            msg = item.get("error_message") or "unspecified error"
            # error_message may contain multiple ';'-separated errors from child items
            for part in str(msg).split(";"):
                part = part.strip()
                if part:
                    messages.append(f"[{scope}] {part}")

        # Keep the summary compact; store full per-scope details in output JSON.
        summary = f"{failed_count} of {total} scope(s) failed"
        details = "; ".join(messages[:5])
        if len(messages) > 5:
            details += f"; and {len(messages) - 5} more error(s)"
        error_message = f"{summary}: {details}" if details else summary
        return "failed", error_message

    @staticmethod
    def _is_expired(started_at: datetime | None) -> bool:
        if not started_at:
            return False
        cutoff = datetime.utcnow() - timedelta(minutes=_EXECUTION_TIMEOUT_MINUTES)
        # started_at may be timezone-aware or naive; make both naive UTC for comparison.
        if started_at.tzinfo is not None:
            started_at = started_at.replace(tzinfo=None)
        return started_at < cutoff

    @staticmethod
    def _execute(execution_id: str, pipeline_name: str, params: dict) -> None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            execution = repo.get_by_id(execution_id)
            if execution is None:
                logger.error(f"Execution {execution_id} not found; aborting runner")
                return
            if ExecutionService._is_expired(execution.started_at or execution.created_at):
                repo.update_status(
                    execution_id,
                    status="failed",
                    finished_at=datetime.utcnow(),
                    error_message=(
                        f"Execution exceeded the {_EXECUTION_TIMEOUT_MINUTES}-minute timeout "
                        "before completing"
                    ),
                )
                return
            repo.update_status(execution_id, status="running", started_at=datetime.utcnow())

        try:
            with session_scope() as session:
                pipe_repo = PipelineRepository(session)
                config = pipe_repo.get_config(pipeline_name)

            pipeline = Pipeline(pipeline_name)
            pipeline.config = config

            # execution_id goes to run_and_collect() as kwarg for partial
            # result saving (Opção B); no mutation of request params needed
            output = pipeline.run_and_collect(
                parallelize=bool(params.get("parallelize", True)),
                progress=bool(params.get("progress", False)),
                execution_id=execution_id,
            )

            status, error_message = ExecutionService._aggregate_status(output)

            # Final timeout guard: a long-running pipeline may still exceed the limit.
            with session_scope() as session:
                repo = ExecutionRepository(session)
                execution = repo.get_by_id(execution_id)
                if execution and ExecutionService._is_expired(execution.started_at):
                    status = "failed"
                    error_message = (
                        f"Execution exceeded the {_EXECUTION_TIMEOUT_MINUTES}-minute timeout "
                        "after completing"
                    )
                repo.update_status(
                    execution_id,
                    status=status,
                    finished_at=datetime.utcnow(),
                    output=output,
                    error_message=error_message,
                )
        except Exception as exc:
            logger.error(f"Pipeline execution failed for execution_id={execution_id}: {exc}")
            with session_scope() as session:
                repo = ExecutionRepository(session)
                repo.update_status(
                    execution_id,
                    status="failed",
                    finished_at=datetime.utcnow(),
                    error_message=str(exc),
                )

    @staticmethod
    def recover_orphaned_executions() -> int:
        """Mark stale running/queued executions as failed on service startup.

        Returns the number of recovered executions.
        """
        cutoff = datetime.utcnow() - timedelta(minutes=_EXECUTION_TIMEOUT_MINUTES)
        recovered = 0
        with session_scope() as session:
            repo = ExecutionRepository(session)
            for execution in repo.list_active():
                timestamp = execution.started_at or execution.created_at
                if timestamp is None:
                    continue
                if timestamp.tzinfo is not None:
                    timestamp = timestamp.replace(tzinfo=None)
                if timestamp < cutoff:
                    repo.update_status(
                        execution.id,
                        status="failed",
                        finished_at=datetime.utcnow(),
                        error_message=(
                            f"Execution orphaned: service restarted before completion "
                            f"(exceeded {_EXECUTION_TIMEOUT_MINUTES}-minute threshold)"
                        ),
                    )
                    recovered += 1
                    logger.warning(
                        f"Recovered orphaned execution {execution.id} "
                        f"({execution.pipeline_name}) as failed"
                    )
        if recovered:
            logger.info(f"Recovered {recovered} orphaned execution(s)")
        return recovered

    @staticmethod
    def get_execution(execution_id: str) -> Execution | None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            execution = repo.get_by_id(execution_id)
            if execution:
                session.expunge(execution)
            return execution

    @staticmethod
    def list_executions(
        *,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> list[Execution]:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            items = repo.list(
                offset=offset,
                limit=limit,
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )
            for item in items:
                session.expunge(item)
            return items

    @staticmethod
    def count_executions(
        *,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> int:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            return repo.count(
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )

    @staticmethod
    def get_execution_output(execution_id: str) -> list[dict[str, Any]] | None:
        with session_scope() as session:
            repo = ExecutionRepository(session)
            return repo.get_output(execution_id)