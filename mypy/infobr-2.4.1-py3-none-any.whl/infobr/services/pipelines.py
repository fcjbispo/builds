"""Reusable pipeline domain services for TUI and API (DB-backed)."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from infobr import env, logger
from infobr.data.pipeline import Pipeline


@dataclass(frozen=True)
class PipelineInfo:
    """Pipeline metadata."""

    name: str
    created_at: datetime
    updated_at: datetime | None


@dataclass(frozen=True)
class PipelineRunStats:
    """Execution aggregate stats from operation output."""

    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float


@dataclass(frozen=True)
class PipelineRunResult:
    """Pipeline execution service result."""

    pipeline_name: str
    success: bool
    output: list[dict[str, Any]] | None
    stats: PipelineRunStats | None


def list_pipelines(pipelines_dir: str | None = None) -> list[PipelineInfo]:
    """List available pipelines from the database."""
    from infobr.api.db import session_scope
    from infobr.api.repositories import PipelineRepository

    with session_scope() as session:
        repo = PipelineRepository(session)
        items = repo.list(offset=0, limit=1000)
        return [
            PipelineInfo(
                name=p.name,
                created_at=p.created_at,
                updated_at=p.updated_at,
            )
            for p in items
        ]


def validate_pipeline_exists(pipeline_name: str, pipelines_dir: str | None = None) -> None:
    """Validate pipeline exists in the database."""
    if not pipeline_name:
        raise ValueError("pipeline_name must be provided")

    from infobr.api.db import session_scope
    from infobr.api.repositories import PipelineRepository

    with session_scope() as session:
        repo = PipelineRepository(session)
        if not repo.get_by_name(pipeline_name):
            raise FileNotFoundError(f"Pipeline not found: {pipeline_name}")


def get_pipeline_config(pipeline_name: str, pipelines_dir: str | None = None) -> dict[str, Any]:
    """Read pipeline config from the database."""
    from infobr.api.db import session_scope
    from infobr.api.repositories import PipelineRepository

    with session_scope() as session:
        repo = PipelineRepository(session)
        config = repo.get_config(pipeline_name)
    if not config:
        raise FileNotFoundError(f"Pipeline not found: {pipeline_name}")
    return config


def estimate_pipeline_items(pipeline_name: str, pipelines_dir: str | None = None) -> int:
    """Best-effort estimate of items to process."""
    try:
        config = get_pipeline_config(pipeline_name)
        scopes = config.get("scopes", [])
        total = 0

        import polars as pl

        for scope in scopes:
            scope_value = str(scope).lower()
            if "fii" in scope_value:
                total += pl.read_database(
                    "select count(*) as n from infobr.ativos where tipo = 'fii' and ativo = 1",
                    env.DB,
                )[0, 0]
            elif "etf" in scope_value:
                total += pl.read_database(
                    "select count(*) as n from infobr.ativos where url like 'https://stockanalysis.com/%' and ativo = 1 and coalesce(moeda,'USD') = 'USD'",
                    env.DB,
                )[0, 0]
            elif "eu" in scope_value:
                total += pl.read_database(
                    "select count(*) as n from infobr.ativos where url like 'https://stockanalysis.com/%' and ativo = 1 and moeda = 'EUR'",
                    env.DB,
                )[0, 0]
            elif "fx" in scope_value:
                total += (
                    pl.read_database(
                        "select count(*) as n from infobr.ativos where tipo = 'fx' and ativo = 1",
                        env.DB,
                    )[0, 0]
                    * 2
                )
        return int(total)
    except Exception as exc:
        logger.warning(f"Could not estimate pipeline items for '{pipeline_name}': {exc}")
        return 0


def run_pipeline(
    pipeline_name: str,
    *,
    parallelize: bool = True,
    progress: bool = False,
    progress_callback=None,
) -> PipelineRunResult:
    """Execute one pipeline and return a normalized run result."""
    config = get_pipeline_config(pipeline_name)

    pipeline = Pipeline(pipeline_name)
    pipeline.config = config
    output = pipeline.run_and_collect(
        parallelize=parallelize,
        progress=progress,
        progress_callback=progress_callback,
    )

    total = len(output)
    successful = sum(1 for r in output if r.get("success", False))
    failed = total - successful
    stats = PipelineRunStats(
        total_operations=total,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=(successful / total * 100) if total else 0.0,
    )

    return PipelineRunResult(
        pipeline_name=pipeline_name,
        success=True,
        output=output,
        stats=stats,
    )