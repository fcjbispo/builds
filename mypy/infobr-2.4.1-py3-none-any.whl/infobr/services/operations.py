"""Reusable operation/result services for TUI and API (DB-backed)."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class OperationSummaryError:
    """Error entry from operation output."""

    scope: str | None
    error_message: str


@dataclass(frozen=True)
class OperationSummary:
    """Aggregate summary for an execution output."""

    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float
    errors: list[OperationSummaryError]


@dataclass(frozen=True)
class OperationPage:
    """Paginated operation entries."""

    page: int
    page_size: int
    total_records: int
    total_pages: int
    items: list[dict[str, Any]]


def get_operation_page(
    execution_id: str,
    *,
    page: int,
    page_size: int = 50,
) -> OperationPage:
    """Return paginated operation records from DB execution output."""
    if page < 1:
        raise ValueError("page must be >= 1")
    if page_size < 1:
        raise ValueError("page_size must be >= 1")

    from infobr.api.db import session_scope
    from infobr.api.repositories import ExecutionRepository

    with session_scope() as session:
        repo = ExecutionRepository(session)
        output = repo.get_output(execution_id)

    if output is None:
        output = []

    total_records = len(output)
    total_pages = (total_records + page_size - 1) // page_size if total_records else 0

    if total_pages == 0:
        items: list[dict[str, Any]] = []
    else:
        if page > total_pages:
            raise ValueError(f"page must be between 1 and {total_pages}")
        start = (page - 1) * page_size
        end = start + page_size
        items = output[start:end]

    return OperationPage(
        page=page,
        page_size=page_size,
        total_records=total_records,
        total_pages=total_pages,
        items=items,
    )


def summarize_operation_output(output: list[dict[str, Any]]) -> OperationSummary:
    """Aggregate summary from operation output list."""
    total = len(output)
    successful = sum(1 for row in output if row.get("success", False))
    failed = total - successful
    success_rate = (successful / total * 100) if total else 0.0

    errors: list[OperationSummaryError] = []
    for row in output:
        if row.get("success", False):
            continue
        message = row.get("error_message")
        if message:
            errors.append(
                OperationSummaryError(
                    scope=row.get("scope"),
                    error_message=str(message),
                )
            )

    return OperationSummary(
        total_operations=total,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=success_rate,
        errors=errors,
    )


def summarize_execution(execution_id: str) -> OperationSummary | None:
    """Summarize execution output from DB."""
    from infobr.api.db import session_scope
    from infobr.api.repositories import ExecutionRepository

    with session_scope() as session:
        repo = ExecutionRepository(session)
        output = repo.get_output(execution_id)

    if output is None:
        return None
    return summarize_operation_output(output)