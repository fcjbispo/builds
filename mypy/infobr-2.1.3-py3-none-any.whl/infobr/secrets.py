"""Isolated secrets management for InfoBR.

This module handles all sensitive configuration (API keys, peppers,
credentials) in a dedicated Pydantic Settings class that is **never**
serialized, logged, or exposed through APIs.

Usage:
    from infobr.secrets import get_secrets
    secrets = get_secrets()
    print(secrets.token_pepper)  # validated non-empty str

Security rules:
  - `repr(secrets)` hides all field values.
  - `secrets.model_dump()` raises unless explicitly allowed.
  - Never import this module inside log-heavy paths.
"""

from __future__ import annotations

import os
import secrets as _secrets
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


# ---------------------------------------------------------------------------
# Backward-compat pepper loader (deprecated, to be removed in v2.2)
# ---------------------------------------------------------------------------

def _load_legacy_pepper() -> str:
    """Try to load pepper from legacy ~/.infobr/.pepper file.

    Returns empty string if file doesn't exist.
    """
    home = Path(os.getenv("INFOBR_HOME", Path.home() / ".infobr")).expanduser()
    pepper_file = home / ".pepper"
    if not pepper_file.exists():
        return ""
    try:
        pepper = pepper_file.read_text(encoding="utf-8").strip()
        if pepper and len(pepper) >= 32:
            warnings.warn(
                f"INFOBR_TOKEN_PEPPER loaded from {pepper_file}. "
                "For production security, move this value to the "
                "INFOBR_TOKEN_PEPPER environment variable. "
                "File-based pepper loading is deprecated and will be removed in v2.2.",
                DeprecationWarning,
                stacklevel=3,
            )
            return pepper
    except Exception:
        pass
    return ""


def _generate_pepper() -> str:
    """Generate a secure 256-bit pepper."""
    return _secrets.token_hex(32)


# ---------------------------------------------------------------------------
# Secrets model
# ---------------------------------------------------------------------------

class InfoBRSecrets(BaseSettings):
    """Sensitive configuration values.

    Fields are loaded exclusively from environment variables (env_prefix)
    and optionally from a `.env` file. No JSON file source is used here
    to reduce the chance of secrets being persisted in plain text.
    """

    model_config = SettingsConfigDict(
        env_prefix="INFOBR_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ------------------------------------------------------------------
    # Core secrets
    # ------------------------------------------------------------------
    token_pepper: str = Field(
        default="",
        description="256-bit pepper for token hashing (hex). Required.",
    )

    # ------------------------------------------------------------------
    # External provider API keys (optional)
    # ------------------------------------------------------------------
    alpha_vantage_api_key: str = Field(
        default="",
        description="Alpha Vantage API key (optional)",
    )

    # ------------------------------------------------------------------
    # FireCrawl (optional)
    # ------------------------------------------------------------------
    firecrawl_api_key: str = Field(
        default="",
        description="FireCrawl API key (optional)",
    )
    firecrawl_base_url: str = Field(
        default="",
        description="FireCrawl base URL (optional)",
    )

    # ------------------------------------------------------------------
    # Multi-modal LLM endpoints (optional)
    # ------------------------------------------------------------------
    lmstudio_api_base: str = Field(
        default="",
        description="LMStudio API base URL (optional)",
    )
    ollama_api_base: str = Field(
        default="",
        description="Ollama API base URL (optional)",
    )

    # ------------------------------------------------------------------
    # Security hardening
    # ------------------------------------------------------------------
    def model_post_init(self, __context: Any) -> None:
        """Validate pepper presence with backward-compat fallback."""
        # Try legacy file-based pepper if env var is missing
        if not self.token_pepper:
            legacy = _load_legacy_pepper()
            if legacy:
                object.__setattr__(self, "token_pepper", legacy)

        # If still missing, auto-generate (same behavior as old __init__.py)
        # but warn loudly.
        if not self.token_pepper:
            pepper = _generate_pepper()
            object.__setattr__(self, "token_pepper", pepper)
            home = Path(os.getenv("INFOBR_HOME", Path.home() / ".infobr")).expanduser()
            home.mkdir(parents=True, exist_ok=True)
            pepper_file = home / ".pepper"
            pepper_file.write_text(pepper, encoding="utf-8")
            pepper_file.chmod(0o600)
            warnings.warn(
                f"Generated new token pepper and saved to {pepper_file}. "
                "For production security, move this value to the "
                f"INFOBR_TOKEN_PEPPER environment variable: "
                f"export INFOBR_TOKEN_PEPPER='{pepper}'",
                RuntimeWarning,
                stacklevel=3,
            )

        if len(self.token_pepper) < 32:
            raise ValueError(
                "INFOBR_TOKEN_PEPPER is required and must be at least 32 characters. "
                "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
            )

    def __repr__(self) -> str:
        return "InfoBRSecrets(<redacted>)"

    def __str__(self) -> str:
        return "InfoBRSecrets(<redacted>)"

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Override to discourage accidental serialization."""
        raise RuntimeError(
            "Explicitly use model_dump(include={...}) or model_dump_json(include={...}) "
            "if you really need to serialize secrets."
        )


# ---------------------------------------------------------------------------
# Lazy singleton accessor
# ---------------------------------------------------------------------------

@lru_cache
def get_secrets() -> InfoBRSecrets:
    """Return the validated, cached secrets singleton."""
    return InfoBRSecrets()
