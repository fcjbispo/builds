"""Environment-specific configuration overrides for InfoBR.

This module defines per-environment defaults that are applied by
InfoBRSettings.model_post_init(). It is separate from config.py so that
environment profiles can be inspected and extended without touching the
settings schema itself.

Usage:
    from infobr.config import get_settings
    settings = get_settings()  # env overrides already applied
"""

from __future__ import annotations

from typing import Any


def get_env_overrides(env: str) -> dict[str, Any]:
    """Return override dictionary for a given environment name.

    Args:
        env: One of "dev", "test", "prod", "local".

    Returns:
        Mapping of field names to override values.
    """
    return _ENV_OVERRIDES.get(env, {})


# ---------------------------------------------------------------------------
# Override tables
# ---------------------------------------------------------------------------

_ENV_OVERRIDES: dict[str, dict[str, Any]] = {
    "dev": {
        "api_reload": True,
        "api_workers": 1,
        "db_pool_size": 5,
        "api_rate_limit_max_requests": 9999,
    },
    "test": {
        "db_url": "sqlite:///:memory:",
        "api_rate_limit_max_requests": 9999,
        "password_iterations": 100000,
        "login_token_ttl_hours": 1,
        "token_ttl_days": 1,
    },
    "prod": {
        "api_reload": False,
        "api_workers": 4,
    },
    "local": {
        # Defaults in InfoBRSettings are already tuned for local usage
    },
}


def list_env_profiles() -> list[str]:
    """Return the list of supported environment profile names."""
    return list(_ENV_OVERRIDES.keys())


def describe_env_profile(env: str) -> dict[str, Any]:
    """Return a human-readable description of what an env profile changes."""
    overrides = get_env_overrides(env)
    defaults = {
        "dev": "Development mode with auto-reload enabled.",
        "test": "Test mode with in-memory SQLite and relaxed limits.",
        "prod": "Production mode with multiple workers and hardened defaults.",
        "local": "Local single-user mode with SQLite default.",
    }
    return {
        "name": env,
        "description": defaults.get(env, "Custom environment profile."),
        "overrides": overrides,
    }
