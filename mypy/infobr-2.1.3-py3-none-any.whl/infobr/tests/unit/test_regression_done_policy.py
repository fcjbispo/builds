"""
Teste de regressão para a política de marcação .done nas pipelines load.

Política: arquivo é renomeado como .done se NÃO houver failures de DB
nem erros de validação. A operação padrão para a tabela series é "append".

O _load_dataframe_to_db converte UniqueViolation (registro já existe)
em skips antes de retornar o db_result, garantindo que o log de operação
não polua com "erros" que são comportamento esperado.

Cenários de sucesso (.done):
- 0 insertions + 100 skips + 0 failures + 0 errors
- 50 insertions + 50 skips + 0 failures + 0 errors

Cenários de falha (NÃO .done):
- 50 insertions + 1 real failure (NotNullViolation, InternalError_)
- 0 insertions + 0 skips + 1 validation error
"""

import os
import tempfile

import pandas as pd
from unittest.mock import patch

from infobr.data.series import SeriesLoadDataProcessor


class TestDonePolicy:
    """Verifica política de .done baseada em failures/errors."""

    def _setup_runner(self, db_result, validation_errors=None, dry_run=False):
        """Helper para simular _process_file_runner com resultado controlado."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False
        ) as f:
            f.write("From,To,Date,Open,High,Low,Close\n")
            f.write("EUR,BRL,2026-05-28,5.88,5.90,5.85,5.87\n")
            file_path = f.name

        loader_param = {
            "kind": "FX",
            "schema": "infobr",
            "target_table": "series",
            "dry_run": dry_run,
            "operation": "append",
        }

        try:
            with patch.object(
                SeriesLoadDataProcessor,
                "_read_file",
                staticmethod(lambda fp, kind: pd.DataFrame({
                    "From": ["EUR"],
                    "To": ["BRL"],
                    "Date": ["2026-05-28"],
                    "Open": [5.88],
                    "High": [5.90],
                    "Low": [5.85],
                    "Close": [5.87],
                })),
            ), patch.object(
                SeriesLoadDataProcessor,
                "_validate_against_schema",
                staticmethod(lambda kind, df: validation_errors or []),
            ), patch.object(
                SeriesLoadDataProcessor,
                "_load_dataframe_to_db",
                staticmethod(lambda df, lp: db_result),
            ):
                result = SeriesLoadDataProcessor._process_file_runner(
                    "FX History", file_path, loader_param
                )
            return result, file_path
        finally:
            pass

    def test_all_skips_no_failures_done_file(self):
        """0 insertions + 100 skips + 0 failures → arquivo RENOMEADO, success=True."""
        db_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 100,
            "failures": [],
        }
        result, file_path = self._setup_runner(db_result)

        scope, success, error_message, return_data = result
        assert success is True
        assert error_message is None
        assert not os.path.exists(file_path)
        assert os.path.exists(f"{file_path}.done")

        os.unlink(f"{file_path}.done")

    def test_some_insertions_no_failures_done_file(self):
        """50 insertions + 50 skips + 0 failures → arquivo RENOMEADO, success=True."""
        db_result = {
            "operation": "append",
            "insertions": 50,
            "updates": 0,
            "skips": 50,
            "failures": [],
        }
        result, file_path = self._setup_runner(db_result)

        scope, success, error_message, return_data = result
        assert success is True
        assert error_message is None
        assert not os.path.exists(file_path)
        assert os.path.exists(f"{file_path}.done")

        os.unlink(f"{file_path}.done")

    def test_real_failures_no_done_file(self):
        """50 insertions + 1 real failure → arquivo NÃO renomeado."""
        db_result = {
            "operation": "append",
            "insertions": 50,
            "updates": 0,
            "skips": 49,
            "failures": [{"step": "insert", "error": "(psycopg.errors.NotNullViolation) null value in column"}],
        }
        result, file_path = self._setup_runner(db_result)

        scope, success, error_message, return_data = result
        assert success is False
        assert error_message is not None
        assert "1 DB failures" in error_message
        assert os.path.exists(file_path)
        assert not os.path.exists(f"{file_path}.done")

        os.unlink(file_path)

    def test_validation_errors_no_done_file(self):
        """0 insertions + validation errors → arquivo NÃO renomeado, success=False."""
        db_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [],
        }
        result, file_path = self._setup_runner(
            db_result, validation_errors=["missing column dominio_nome"]
        )

        scope, success, error_message, return_data = result
        assert success is False
        assert error_message is not None
        assert "1 validation errors" in error_message
        assert os.path.exists(file_path)
        assert not os.path.exists(f"{file_path}.done")

        os.unlink(file_path)

    def test_failures_and_errors_no_done_file(self):
        """1 real failure + 1 validation error → mensagem combinada, success=False."""
        db_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [{"step": "insert", "error": "(psycopg.errors.InternalError_) cannot read"}],
        }
        result, file_path = self._setup_runner(
            db_result, validation_errors=["schema error"]
        )

        scope, success, error_message, return_data = result
        assert success is False
        assert "1 DB failures" in error_message
        assert "1 validation errors" in error_message
        assert os.path.exists(file_path)
        assert not os.path.exists(f"{file_path}.done")

        os.unlink(file_path)

    def test_dry_run_preserves_file(self):
        """dry_run=True → arquivo original preservado, success=True."""
        db_result = None  # não é chamado em dry_run
        result, file_path = self._setup_runner(db_result, dry_run=True)

        scope, success, error_message, return_data = result
        assert success is True
        assert error_message is None
        assert os.path.exists(file_path)
        assert not os.path.exists(f"{file_path}.done")

        os.unlink(file_path)

    def test_return_data_reflects_skips(self):
        """return_data contém skips corretamente."""
        db_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 100,
            "failures": [],
        }
        result, file_path = self._setup_runner(db_result)

        scope, success, error_message, return_data = result
        assert return_data["insertions"].iloc[0] == 0
        assert return_data["updates"].iloc[0] == 0
        assert return_data["skips"].iloc[0] == 100
        assert return_data["failures"].iloc[0] == []

        os.unlink(f"{file_path}.done")


class TestLoadDataframeToDbFiltersUniqueViolation:
    """Verifica que _load_dataframe_to_db converte UniqueViolation em skips."""

    def test_unique_violations_converted_to_skips(self):
        """100 UniqueViolation failures → 0 failures + 100 skips."""
        raw_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [
                {"step": "perform insert", "error": "(psycopg.errors.UniqueViolation) duplicate key"}
                for _ in range(100)
            ],
        }

        # Simular o que _load_dataframe_to_db faz internamente
        operation = "append"
        result = dict(raw_result)
        if operation == "append" and result.get("failures"):
            real_failures = []
            duplicate_skips = 0
            for failure in result["failures"]:
                if "UniqueViolation" in str(failure.get("error", "")):
                    duplicate_skips += 1
                else:
                    real_failures.append(failure)
            result["failures"] = real_failures
            result["skips"] = result.get("skips", 0) + duplicate_skips

        assert len(result["failures"]) == 0
        assert result["skips"] == 100

    def test_mixed_failures_keeps_real_only(self):
        """1 UniqueViolation + 1 NotNullViolation → 1 failure + 1 skip."""
        raw_result = {
            "operation": "append",
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [
                {"step": "perform insert", "error": "(psycopg.errors.UniqueViolation) duplicate"},
                {"step": "perform insert", "error": "(psycopg.errors.NotNullViolation) null value"},
            ],
        }

        operation = "append"
        result = dict(raw_result)
        if operation == "append" and result.get("failures"):
            real_failures = []
            duplicate_skips = 0
            for failure in result["failures"]:
                if "UniqueViolation" in str(failure.get("error", "")):
                    duplicate_skips += 1
                else:
                    real_failures.append(failure)
            result["failures"] = real_failures
            result["skips"] = result.get("skips", 0) + duplicate_skips

        assert len(result["failures"]) == 1
        assert "NotNullViolation" in result["failures"][0]["error"]
        assert result["skips"] == 1

    def test_upsert_does_not_filter(self):
        """operation='upsert': UniqueViolation permanece como failure."""
        raw_result = {
            "operation": "upsert",
            "insertions": 0,
            "updates": 0,
            "skips": 0,
            "failures": [
                {"step": "perform insert", "error": "(psycopg.errors.UniqueViolation) duplicate"},
            ],
        }

        operation = "upsert"
        result = dict(raw_result)
        if operation == "append" and result.get("failures"):
            real_failures = []
            duplicate_skips = 0
            for failure in result["failures"]:
                if "UniqueViolation" in str(failure.get("error", "")):
                    duplicate_skips += 1
                else:
                    real_failures.append(failure)
            result["failures"] = real_failures
            result["skips"] = result.get("skips", 0) + duplicate_skips

        # upsert não entra no if, então não filtra
        assert len(result["failures"]) == 1
        assert result["skips"] == 0
