"""Tests for VULN-002: Redis-based rate limiting."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from infobr.api.services.rate_limit import (
    InMemoryRateLimiter,
    RedisRateLimiter,
    _utc_now_ts,
    build_default_rate_limiter,
)

try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False


class TestInMemoryRateLimiter:
    """Tests for the InMemoryRateLimiter."""

    def test_init_validates_parameters(self):
        with pytest.raises(ValueError, match="max_requests must be"):
            InMemoryRateLimiter(max_requests=0, window_seconds=60)
        with pytest.raises(ValueError, match="window_seconds must be"):
            InMemoryRateLimiter(max_requests=10, window_seconds=0)

    def test_allow_empty_key_returns_true(self):
        limiter = InMemoryRateLimiter(max_requests=5, window_seconds=60)
        assert limiter.allow("") == (True, 0)
        assert limiter.allow(None) == (True, 0)

    def test_allow_respects_limit(self):
        limiter = InMemoryRateLimiter(max_requests=3, window_seconds=60)
        key = "test-key"

        # First 3 requests should be allowed
        assert limiter.allow(key) == (True, 0)
        assert limiter.allow(key) == (True, 0)
        assert limiter.allow(key) == (True, 0)

        # 4th request should be denied
        allowed, retry_after = limiter.allow(key)
        assert allowed is False
        assert retry_after > 0

    def test_allow_different_keys_independent(self):
        limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)

        assert limiter.allow("key1") == (True, 0)
        assert limiter.allow("key1") == (True, 0)
        assert limiter.allow("key1")[0] is False  # rate limited

        # key2 should still be allowed
        assert limiter.allow("key2") == (True, 0)

    def test_reset_clears_all(self):
        limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)
        limiter.allow("key1")
        limiter.allow("key1")
        assert limiter.allow("key1")[0] is False

        limiter.reset()
        assert limiter.allow("key1") == (True, 0)

    def test_window_expires_old_requests(self):
        limiter = InMemoryRateLimiter(max_requests=2, window_seconds=60)
        now = _utc_now_ts()

        # Add requests at specific times
        limiter.allow("key", now_ts=now - 120)  # 2 minutes ago
        limiter.allow("key", now_ts=now - 120)
        # Old requests (older than window_seconds) should have expired
        assert limiter.allow("key", now_ts=now)[0] is True

        # After window passes, requests should be allowed
        future = now + 70  # More than window_seconds in future
        limiter.allow("key", now_ts=future)  # Old requests expired
        assert limiter.allow("key", now_ts=future) == (True, 0)


@pytest.mark.skipif(not REDIS_AVAILABLE, reason="redis package not installed")
class TestRedisRateLimiter:
    """Tests for the RedisRateLimiter."""

    def test_init_validates_parameters(self):
        mock_redis = MagicMock()
        with pytest.raises(ValueError, match="max_requests must be"):
            RedisRateLimiter(redis_client=mock_redis, max_requests=0, window_seconds=60)
        with pytest.raises(ValueError, match="window_seconds must be"):
            RedisRateLimiter(redis_client=mock_redis, max_requests=10, window_seconds=0)

    def test_allow_empty_key_returns_true(self):
        mock_redis = MagicMock()
        mock_redis.pipeline.return_value.execute.return_value = [0, 0, []]
        limiter = RedisRateLimiter(
            redis_client=mock_redis, max_requests=5, window_seconds=60
        )
        assert limiter.allow("") == (True, 0)
        assert limiter.allow(None) == (True, 0)

    def test_allow_uses_redis_sorted_sets(self):
        mock_redis = MagicMock()
        mock_pipe = MagicMock()
        mock_redis.pipeline.return_value = mock_pipe
        mock_pipe.execute.return_value = [0, 1, []]  # zrem, count=1, oldest=[]

        limiter = RedisRateLimiter(
            redis_client=mock_redis, max_requests=3, window_seconds=60
        )
        result = limiter.allow("test-key")

        # Verify pipeline operations
        mock_redis.pipeline.assert_called_once()
        mock_pipe.zremrangebyscore.assert_called_once()
        mock_pipe.zcard.assert_called_once()
        mock_pipe.zrange.assert_called_once()

        # Should be allowed (count < max_requests)
        assert result == (True, 0)

        # Verify zadd was called to add the request
        mock_pipe.zadd.assert_called_once()
        mock_pipe.expire.assert_called_once()

    def test_allow_denies_when_limit_reached(self):
        mock_redis = MagicMock()
        mock_pipe = MagicMock()
        mock_redis.pipeline.return_value = mock_pipe
        # count=5 (== max_requests), oldest entry at timestamp 1000
        mock_pipe.execute.return_value = [0, 5, [["req1", 1000.0]]]

        limiter = RedisRateLimiter(
            redis_client=mock_redis, max_requests=5, window_seconds=60
        )
        result = limiter.allow("test-key", now_ts=1020.0)

        # Should be denied with retry_after calculated
        allowed, retry_after = result
        assert allowed is False
        assert retry_after > 0
        assert retry_after <= 60

    def test_reset_scans_and_deletes_keys(self):
        mock_redis = MagicMock()
        mock_redis.scan.side_effect = [
            (42, ["rate_limit:key1", "rate_limit:key2"]),
            (0, ["rate_limit:key3"]),
        ]

        limiter = RedisRateLimiter(
            redis_client=mock_redis, max_requests=5, window_seconds=60
        )
        limiter.reset()

        # Should scan for keys and delete them
        mock_redis.scan.assert_called()
        mock_redis.delete.assert_called_with(
            "rate_limit:key1", "rate_limit:key2", "rate_limit:key3"
        )

    def test_key_prefix_customization(self):
        mock_redis = MagicMock()
        mock_pipe = MagicMock()
        mock_redis.pipeline.return_value = mock_pipe
        mock_pipe.execute.return_value = [0, 1, []]

        limiter = RedisRateLimiter(
            redis_client=mock_redis,
            max_requests=5,
            window_seconds=60,
            key_prefix="custom_prefix",
        )
        limiter.allow("my-key")

        # Verify the correct key was used
        mock_pipe.zremrangebyscore.assert_called_with(
            "custom_prefix:my-key", 0, pytest.approx(_utc_now_ts() - 60, abs=1)
        )


class TestBuildDefaultRateLimiter:
    """Tests for the build_default_rate_limiter factory function."""

    def test_builds_in_memory_without_redis_url(self, monkeypatch):
        from infobr.config import get_settings

        get_settings.cache_clear()
        monkeypatch.delenv("INFOBR_REDIS_URL", raising=False)
        limiter = build_default_rate_limiter()
        assert isinstance(limiter, InMemoryRateLimiter)

    @pytest.mark.skipif(not REDIS_AVAILABLE, reason="redis package not installed")
    def test_builds_redis_with_valid_url(self, monkeypatch):
        from infobr.config import get_settings

        get_settings.cache_clear()
        monkeypatch.setenv("INFOBR_REDIS_URL", "redis://localhost:6379/0")

        with patch("redis.from_url") as mock_from_url:
            mock_client = MagicMock()
            mock_client.ping.return_value = True
            mock_from_url.return_value = mock_client

            limiter = build_default_rate_limiter()
            assert isinstance(limiter, RedisRateLimiter)
            mock_from_url.assert_called_once_with(
                "redis://localhost:6379/0", decode_responses=True
            )

    @pytest.mark.skipif(not REDIS_AVAILABLE, reason="redis package not installed")
    def test_fallbacks_to_in_memory_on_redis_failure(self, monkeypatch):
        from infobr.config import get_settings

        get_settings.cache_clear()
        monkeypatch.setenv("INFOBR_REDIS_URL", "redis://invalid:6379")

        with patch("redis.from_url") as mock_from_url:
            mock_from_url.side_effect = Exception("Connection refused")

            with pytest.warns(RuntimeWarning, match="Falling back"):
                limiter = build_default_rate_limiter()
                assert isinstance(limiter, InMemoryRateLimiter)

    def test_uses_env_config(self, monkeypatch):
        from infobr.config import get_settings

        get_settings.cache_clear()
        monkeypatch.setenv("INFOBR_API_RATE_LIMIT_MAX_REQUESTS", "200")
        monkeypatch.setenv("INFOBR_API_RATE_LIMIT_WINDOW_SECONDS", "120")
        monkeypatch.delenv("INFOBR_REDIS_URL", raising=False)

        limiter = build_default_rate_limiter()
        assert isinstance(limiter, InMemoryRateLimiter)
        assert limiter.max_requests == 200
        assert limiter.window_seconds == 120


def test_utc_now_ts_returns_float():
    """Test that _utc_now_ts returns a float timestamp."""
    ts = _utc_now_ts()
    assert isinstance(ts, float)
    # Should be approximately now
    expected = datetime.now(timezone.utc).timestamp()
    assert abs(ts - expected) < 1.0
