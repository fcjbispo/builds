"""API-040: unit tests for auth/tokens/rbac."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from infobr.api.dependencies import security
from infobr.api.services.tokens import TokenService


def _token(**kwargs):
    base = {
        "id": "tok1",
        "email": "user@example.com",
        "token_hash": "x",
        "token_prefix": "tok1pref",
        "is_active": True,
        "expires_at": datetime.now(timezone.utc) + timedelta(days=30),
        "profile": "USER",
    }
    base.update(kwargs)
    return SimpleNamespace(**base)


def test_normalize_profile_accepts_user_admin():
    assert TokenService.normalize_profile("user") == "USER"
    assert TokenService.normalize_profile(" ADMIN ") == "ADMIN"


def test_normalize_profile_rejects_invalid():
    with pytest.raises(ValueError):
        TokenService.normalize_profile("guest")


def test_hash_token_is_deterministic_and_uses_pepper():
    t1 = TokenService.hash_token("raw-token", pepper="pep1")
    t2 = TokenService.hash_token("raw-token", pepper="pep1")
    t3 = TokenService.hash_token("raw-token", pepper="pep2")
    assert t1 == t2
    assert t1 != t3


def test_is_expired_handles_future_and_past():
    now = datetime.now(timezone.utc)
    assert TokenService.is_expired(now + timedelta(minutes=1), now=now) is False
    assert TokenService.is_expired(now - timedelta(minutes=1), now=now) is True


def test_is_expired_rejects_none():
    with pytest.raises(ValueError) as exc:
        TokenService.is_expired(None, now=datetime.now(timezone.utc))
    assert "expires_at is required" in str(exc.value)


def test_validate_bearer_token_success_and_touch():
    raw = "abc123"
    token_hash = TokenService.hash_token(raw)
    expires_at = datetime.now(timezone.utc) + timedelta(days=30)
    tok = _token(id="tok-ok", token_hash=token_hash, is_active=True, expires_at=expires_at)

    class Repo:
        def __init__(self):
            self.touched = False

        def get_by_token_hash(self, value):
            return tok if value == token_hash else None

        def touch_last_used(self, token_id):
            assert token_id == "tok-ok"
            self.touched = True
            return tok

    repo = Repo()
    result = TokenService.validate_bearer_token(repo, raw_token=raw, touch_last_used=True)
    assert result is tok
    assert repo.touched is True


def test_validate_bearer_token_fails_for_missing_inactive_or_expired():
    raw = "abc123"
    token_hash = TokenService.hash_token(raw)
    expired = datetime.now(timezone.utc) - timedelta(seconds=1)

    class RepoMissing:
        def get_by_token_hash(self, _):
            return None

    class RepoInactive:
        def get_by_token_hash(self, _):
            return _token(token_hash=token_hash, is_active=False)

    class RepoExpired:
        def get_by_token_hash(self, _):
            return _token(token_hash=token_hash, is_active=True, expires_at=expired)

    assert TokenService.validate_bearer_token(RepoMissing(), raw_token=raw) is None
    assert TokenService.validate_bearer_token(RepoInactive(), raw_token=raw) is None
    assert TokenService.validate_bearer_token(RepoExpired(), raw_token=raw) is None


def test_require_user_and_require_admin_rules():
    user = _token(profile="USER")
    admin = _token(profile="ADMIN")
    guest = _token(profile="GUEST")

    assert security.require_user(user) is user
    assert security.require_user(admin) is admin
    with pytest.raises(HTTPException) as exc:
        security.require_user(guest)
    assert exc.value.status_code == 403

    assert security.require_admin(admin) is admin
    with pytest.raises(HTTPException) as exc2:
        security.require_admin(user)
    assert exc2.value.status_code == 403


def test_issue_token_requires_expires_at():
    """VULN-003: expires_at must be provided and cannot be None."""

    class MockRepo:
        def create(self, **kwargs):
            return SimpleNamespace(**kwargs, id="tok1")

    expires_at = datetime.now(timezone.utc) + timedelta(days=30)

    # Success case: expires_at provided
    token, raw = TokenService.issue_token(
        MockRepo(), email="user@test.com", profile="USER", expires_at=expires_at
    )
    assert token is not None
    assert raw is not None

    # Failure case: expires_at is None
    with pytest.raises(ValueError) as exc:
        TokenService.issue_token(
            MockRepo(), email="user@test.com", profile="USER", expires_at=None
        )
    assert "expires_at is required" in str(exc.value)


def test_rotate_token_requires_expires_at():
    """VULN-003: rotate_token must receive expires_at."""

    class MockRepo:
        def rotate(self, token_id, **kwargs):
            return SimpleNamespace(id=token_id, **kwargs)

    expires_at = datetime.now(timezone.utc) + timedelta(days=30)

    # Success case: expires_at provided
    token, raw = TokenService.rotate_token(MockRepo(), token_id="tok1", expires_at=expires_at)
    assert token is not None
    assert raw is not None

    # Failure case: expires_at is None
    with pytest.raises(ValueError) as exc:
        TokenService.rotate_token(MockRepo(), token_id="tok1", expires_at=None)
    assert "expires_at is required" in str(exc.value)


def test_hash_token_rejects_empty_pepper():
    """VULN-006: hash_token must reject empty pepper."""
    # Test with explicitly empty pepper
    with pytest.raises(ValueError) as exc:
        TokenService.hash_token("some-token", pepper="")
    assert "pepper is not configured" in str(exc.value)

    # Test with valid pepper (should work)
    result = TokenService.hash_token("some-token", pepper="test-pepper-123")
    assert result is not None
    assert len(result) == 64  # SHA-256 hex length


def test_hash_token_uses_provided_pepper():
    """VULN-006: hash_token uses provided pepper parameter."""
    result1 = TokenService.hash_token("token", pepper="pepper1")
    result2 = TokenService.hash_token("token", pepper="pepper1")
    result3 = TokenService.hash_token("token", pepper="pepper2")

    # Same pepper = same hash
    assert result1 == result2
    # Different pepper = different hash
    assert result1 != result3


def test_default_expiration_returns_utc_datetime(monkeypatch):
    """VULN-003: default_expiration returns UTC datetime from settings."""
    from infobr.config import get_settings

    get_settings.cache_clear()
    monkeypatch.delenv("INFOBR_TOKEN_TTL_DAYS", raising=False)

    before = datetime.now(timezone.utc)
    default_exp = TokenService.default_expiration()
    after = datetime.now(timezone.utc)

    expected_days = get_settings().token_ttl_days
    assert default_exp.tzinfo is not None
    assert (default_exp - before).days == expected_days
    assert (after - default_exp).days <= 0


def test_get_current_token_rejects_empty_credentials():
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="   ")
    with pytest.raises(HTTPException) as exc:
        security.get_current_token(creds)
    assert exc.value.status_code == 401


def test_get_current_token_success_and_invalid(monkeypatch):
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="token-ok")
    token_ok = _token(profile="ADMIN")

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunged=False)
        session.expunge = lambda _obj: setattr(session, "expunged", True)
        yield session

    class Repo:
        def __init__(self, _session):
            pass

    monkeypatch.setattr(security, "session_scope", fake_session_scope)
    monkeypatch.setattr(security, "TokenRepository", Repo)

    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: token_ok,
    )
    assert security.get_current_token(creds) is token_ok

    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: None,
    )
    with pytest.raises(HTTPException) as exc:
        security.get_current_token(creds)
    assert exc.value.status_code == 401
