"""
Teste de regressão para o bug: separador decimal por vírgula em CSVs causa
falha de validação do schema JSON (e NaN silencioso na transformação).

Quando o sistema roda em locale pt_BR, pd.to_csv escreve números com vírgula
decimal (ex: 62,48). O leitor pd.read_csv sem decimal="," lê esses valores como
strings. A validação do schema JSON falha porque '62,48' não é do tipo 'number'.
Mesmo que a validação fosse relaxada, pd.to_numeric com errors='coerce' converte
silenciosamente para NaN, perdendo os dados.

Esse bug afetou a pipeline ETF_PRICES (kind=STOCK) e potencialmente FX e DIVIDEND.
"""

import pytest
import pandas as pd
import numpy as np
import tempfile
import os

from infobr.data.series import SeriesLoadDataProcessor


class TestNormalizeDecimalColumns:
    """Verifica que _normalize_decimal_columns converte vírgula decimal corretamente."""

    def test_comma_decimal_columns_converted_to_float(self):
        """Colunas com vírgula decimal devem virar float."""
        df = pd.DataFrame({
            "Ticker": ["DGRO", "DGRO"],
            "Open": ["62,48", "62,51"],
            "High": ["63,44", "62,86"],
            "Volume": ["2039123", "2561516"],
        })
        result = SeriesLoadDataProcessor._normalize_decimal_columns(df)

        # Colunas com vírgula decimal são convertidas para float
        assert result["Open"].dtype == np.float64
        assert result["High"].dtype == np.float64
        assert result["Open"].iloc[0] == 62.48
        assert result["Open"].iloc[1] == 62.51
        # Colunas sem vírgula (como Volume inteiro) preservam tipo object
        # — na prática pd.read_csv já as inferiria como int64
        assert result["Volume"].dtype == object
        assert result["Ticker"].dtype == object

    def test_dot_decimal_unchanged(self):
        """Colunas com ponto decimal devem permanecer inalteradas."""
        df = pd.DataFrame({
            "Open": [62.48, 62.51],
            "High": [63.44, 62.86],
        })
        result = SeriesLoadDataProcessor._normalize_decimal_columns(df)

        assert result["Open"].dtype == np.float64
        assert result["Open"].iloc[0] == 62.48

    def test_non_numeric_string_columns_preserved(self):
        """Colunas de texto (com vírgula textual) não devem ser alteradas."""
        df = pd.DataFrame({
            "Description": ["foo, bar", "baz, qux"],
            "Ticker": ["DGRO", "HDV"],
        })
        result = SeriesLoadDataProcessor._normalize_decimal_columns(df)

        assert result["Description"].tolist() == ["foo, bar", "baz, qux"]
        assert result["Ticker"].tolist() == ["DGRO", "HDV"]

    def test_mixed_columns_partial_numeric(self):
        """Colunas com valores numéricos e texto devem ser preservadas (heurística segura)."""
        df = pd.DataFrame({
            "Mixed": ["62,48", "DGRO"],
        })
        result = SeriesLoadDataProcessor._normalize_decimal_columns(df)

        # Como contém letra, a heurística não deve converter
        assert result["Mixed"].tolist() == ["62,48", "DGRO"]

    def test_empty_column_ignored(self):
        """Colunas vazias não devem causar erro."""
        df = pd.DataFrame({
            "Empty": [None, None],
            "Numeric": ["62,48", "63,44"],
        })
        result = SeriesLoadDataProcessor._normalize_decimal_columns(df)

        assert result["Empty"].isna().all()
        assert result["Numeric"].iloc[0] == 62.48


class TestReadFileWithCommaDecimal:
    """Verifica que _read_file lida corretamente com CSVs de locale pt_BR."""

    def test_read_csv_comma_decimal(self):
        """CSV com separador ; e vírgula decimal deve ser lido corretamente."""
        csv_content = """Ticker;Date;Open;High;Low;Close;Volume;Reference_Date
DGRO;2025-03-07;62,48;63,44;62,47;63,31;2039123;2025-03-12
DGRO;2025-03-06;62,51;62,86;62,18;62,6;2561516;2025-03-12
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8") as f:
            f.write(csv_content)
            temp_path = f.name

        try:
            df = SeriesLoadDataProcessor._read_file(temp_path, "STOCK")
            assert df["Open"].dtype == np.float64
            assert df["Close"].dtype == np.float64
            assert df["Volume"].dtype in (np.int64, np.float64)
            assert df["Open"].iloc[0] == 62.48
            assert df["Close"].iloc[0] == 63.31
            assert df["Close"].iloc[1] == 62.60  # 62,6 -> 62.6
        finally:
            os.unlink(temp_path)

    def test_validation_passes_after_read(self):
        """A validação do schema deve passar após ler CSV com vírgula decimal."""
        csv_content = """Ticker;Date;Open;High;Low;Close;Volume;Reference_Date
DGRO;2025-03-07;62,48;63,44;62,47;63,31;2039123;2025-03-12
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8") as f:
            f.write(csv_content)
            temp_path = f.name

        try:
            df = SeriesLoadDataProcessor._read_file(temp_path, "STOCK")
            errors = SeriesLoadDataProcessor._validate_against_schema("STOCK", df)
            assert errors == []
        finally:
            os.unlink(temp_path)

    def test_transform_passes_after_read(self):
        """A transformação STOCK deve produzir valores corretos após leitura."""
        csv_content = """Ticker;Date;Open;High;Low;Close;Volume;Reference_Date
DGRO;2025-03-07;62,48;63,44;62,47;63,31;2039123;2025-03-12
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8") as f:
            f.write(csv_content)
            temp_path = f.name

        try:
            df = SeriesLoadDataProcessor._read_file(temp_path, "STOCK")
            transformed = SeriesLoadDataProcessor._transform_stock(df, "ETFs Prices", "USD")
            assert transformed["abertura"].iloc[0] == 62.48
            assert transformed["fechamento"].iloc[0] == 63.31
            assert transformed["volume"].iloc[0] == 2039123
            assert transformed["dominio_nome"].iloc[0] == "ACAO_US"
        finally:
            os.unlink(temp_path)
