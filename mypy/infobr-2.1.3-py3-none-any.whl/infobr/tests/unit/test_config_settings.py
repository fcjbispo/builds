"""Unit tests for the centralized configuration layer (InfoBRSettings / InfoBRSecrets)."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from infobr.config import InfoBRSettings, get_settings
from infobr.secrets import InfoBRSecrets, get_secrets


class TestInfoBRSettings:
    """Tests for the non-sensitive settings model."""

    def test_defaults_local(self) -> None:
        """Local env should use safe defaults."""
        settings = InfoBRSettings()
        assert settings.env == "local"
        assert settings.api_port == 8500
        assert settings.api_host == "0.0.0.0"
        assert settings.api_reload is False
        assert settings.api_workers == 1
        assert settings.db_pool_size == 25
        assert settings.password_min_length == 8
        assert settings.password_iterations == 310000
        assert settings.login_max_attempts == 5
        assert settings.login_lock_minutes == 15
        assert settings.login_token_ttl_hours == 12
        assert settings.token_ttl_days == 30
        assert settings.pipeline_runners == 2

    def test_env_test_overrides(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test profile should override DB URL and relax limits."""
        monkeypatch.setenv("INFOBR_ENV", "test")
        # Override any external .env file value for this test
        monkeypatch.setenv("INFOBR_DB_URL", "sqlite:///:memory:")
        # Isolate from shell-exported env vars that would block overrides
        monkeypatch.delenv("INFOBR_API_RATE_LIMIT_MAX_REQUESTS", raising=False)
        monkeypatch.delenv("INFOBR_PASSWORD_ITERATIONS", raising=False)
        settings = InfoBRSettings()
        assert settings.env == "test"
        assert settings.db_url == "sqlite:///:memory:"
        assert settings.api_rate_limit_max_requests == 9999
        assert settings.password_iterations == 100000

    def test_custom_api_port(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Custom env var should override default port."""
        monkeypatch.setenv("INFOBR_API_PORT", "9999")
        settings = InfoBRSettings()
        assert settings.api_port == 9999

    def test_invalid_api_port_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Non-numeric or out-of-range port should raise validation error."""
        monkeypatch.setenv("INFOBR_API_PORT", "abc")
        with pytest.raises(Exception):  # pydantic.ValidationError
            InfoBRSettings()

    def test_computed_paths(self) -> None:
        """Computed paths must be children of home."""
        settings = InfoBRSettings()
        assert settings.pipelines_path == settings.home / "pipelines"
        assert settings.operations_path == settings.home / "operations"
        assert settings.logs_path == settings.home / "logs"

    def test_home_directory_created(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """Home directory and subdirs should be auto-created on init."""
        custom_home = tmp_path / "custom_infobr"
        monkeypatch.setenv("INFOBR_HOME", str(custom_home))
        settings = InfoBRSettings()
        assert settings.home.exists()
        assert settings.pipelines_path.exists()
        assert settings.operations_path.exists()
        assert settings.logs_path.exists()

    def test_prod_warning_without_redis(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Production without Redis should emit a warning."""
        monkeypatch.setenv("INFOBR_ENV", "prod")
        monkeypatch.delenv("INFOBR_REDIS_URL", raising=False)
        with pytest.warns(RuntimeWarning, match="Redis"):
            InfoBRSettings()

    def test_reload_disabled_in_prod(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Production should warn if reload is enabled."""
        monkeypatch.setenv("INFOBR_ENV", "prod")
        monkeypatch.setenv("INFOBR_API_RELOAD", "true")
        monkeypatch.setenv("INFOBR_REDIS_URL", "redis://localhost:6379")
        with pytest.warns(RuntimeWarning, match="(?i)reload"):
            InfoBRSettings()

    def test_caching(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """get_settings should return the same cached instance."""
        monkeypatch.setenv("INFOBR_API_PORT", "7777")
        # Clear cache between tests if needed
        get_settings.cache_clear()
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2


class TestInfoBRSecrets:
    """Tests for the isolated secrets model."""

    def test_pepper_required(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        """Missing pepper should auto-generate with warning."""
        monkeypatch.delenv("INFOBR_TOKEN_PEPPER", raising=False)
        # Point HOME to a temp dir so no legacy .pepper file exists
        monkeypatch.setenv("INFOBR_HOME", str(tmp_path / "no_pepper_home"))
        with pytest.warns(RuntimeWarning, match="Generated new token pepper"):
            secrets = InfoBRSecrets()
        assert len(secrets.token_pepper) >= 32

    def test_pepper_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Pepper from env var should be accepted."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        secrets = InfoBRSecrets()
        assert secrets.token_pepper == "a" * 64

    def test_short_pepper_rejected(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Pepper shorter than 32 chars should raise ValueError."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "short")
        with pytest.raises(ValueError, match="at least 32 characters"):
            InfoBRSecrets()

    def test_repr_redacted(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """repr and str must not expose values."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        secrets = InfoBRSecrets()
        assert secrets.token_pepper not in repr(secrets)
        assert secrets.token_pepper not in str(secrets)
        assert "redacted" in repr(secrets).lower()

    def test_model_dump_blocked(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """model_dump should raise to prevent accidental serialization."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        secrets = InfoBRSecrets()
        with pytest.raises(RuntimeError, match="serialize"):
            secrets.model_dump()

    def test_provider_keys_optional(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """External API keys are optional and default to empty."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        # Isolate from shell-exported provider keys
        monkeypatch.delenv("INFOBR_ALPHA_VANTAGE_API_KEY", raising=False)
        monkeypatch.delenv("INFOBR_FIRECRAWL_API_KEY", raising=False)
        monkeypatch.delenv("INFOBR_FIRECRAWL_BASE_URL", raising=False)
        monkeypatch.delenv("INFOBR_LMSTUDIO_API_BASE", raising=False)
        monkeypatch.delenv("INFOBR_OLLAMA_API_BASE", raising=False)
        secrets = InfoBRSecrets()
        assert secrets.alpha_vantage_api_key == ""
        assert secrets.firecrawl_api_key == ""
        assert secrets.firecrawl_base_url == ""
        assert secrets.lmstudio_api_base == ""
        assert secrets.ollama_api_base == ""

    def test_caching(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """get_secrets should return the same cached instance."""
        monkeypatch.setenv("INFOBR_TOKEN_PEPPER", "a" * 64)
        get_secrets.cache_clear()
        s1 = get_secrets()
        s2 = get_secrets()
        assert s1 is s2
