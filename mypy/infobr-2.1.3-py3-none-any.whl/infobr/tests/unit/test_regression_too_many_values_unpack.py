"""
Teste de regressão para o bug: too many values to unpack (expected 4)

Quando um scope tem múltiplos providers (ou múltiplos arquivos), o runner
retornava uma lista de resultados ao invés de um único resultado consolidado,
causando ValueError em pipeline.save_results().
"""

import pandas as pd
from unittest.mock import MagicMock, patch

from infobr.data.series import SeriesExtractDataProcessor, SeriesLoadDataProcessor


class TestProcessRunnerConsolidation:
    """Verifica que os runners consolidam múltiplos resultados em um único resultado."""

    def test_process_extractor_runner_consolidates_multiple_providers(self):
        """Simula 3 providers retornando resultados; runner deve retornar 1 resultado."""
        mock_provider = MagicMock()
        mock_provider.EXPECTED_PARAMS = {
            "timeout": (int, False, 30000),
            "storage_folder": (str, True, None),
            "parallelize": (bool, False, True),
            "progress": (bool, False, False),
            "wait": (int, False, 10),
            "llm": (str, False, None),
            "verbose_mode": (bool, False, False),
            "sub_folders": (list, False, []),
            "writer": (callable, False, None),
        }

        scope_params = {
            "params": [
                {
                    "provider": mock_provider,
                    "storage_folder": "/tmp",
                    "sub_folders": ["TEST"],
                    "parallelize": False,
                    "progress": False,
                    "writer": lambda df, path: path,
                    "wait": 0,
                }
            ],
            "series": [{"ticker": "A"}, {"ticker": "B"}, {"ticker": "C"}],
        }

        # Patch process_provider_runner para simular 3 resultados de sucesso
        def fake_runner(*args):
            return True, None, pd.DataFrame([{"records": 1}])

        with patch.object(
            SeriesExtractDataProcessor,
            "process_provider_runner",
            staticmethod(fake_runner),
        ):
            result = SeriesExtractDataProcessor.process_extractor_runner(
                "TestScope", scope_params
            )

        # Deve retornar uma lista com EXATAMENTE 4 elementos (tupla de resultado)
        assert isinstance(result, list)
        assert len(result) == 4, f"Esperado 4 elementos, obtido {len(result)}: {result}"
        scope, success, error, data = result
        assert scope == "TestScope"
        assert success is True
        assert error is None
        assert isinstance(data, pd.DataFrame)
        assert len(data) == 3  # 3 providers consolidados

    def test_process_scope_runner_consolidates_multiple_files(self):
        """Simula 3 arquivos retornando resultados; runner deve retornar 1 resultado."""
        scope_params = {
            "params": [
                {
                    "storage_folder": "/tmp",
                    "sub_folders": ["TEST"],
                    "parallelize": False,
                    "progress": False,
                    "wait": 0,
                    "kind": "csv",
                    "file_mask": "*.csv",
                    "target_table": "test_table",
                    "schema": "public",
                    "dry_run": True,
                    "operation": "upsert",
                }
            ],
        }

        # Patch discover e read para simular 3 arquivos
        with patch.object(
            SeriesLoadDataProcessor,
            "_discover_files",
            staticmethod(lambda *a, **k: ["/tmp/f1.csv", "/tmp/f2.csv", "/tmp/f3.csv"]),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_read_file",
            staticmethod(lambda fp, kind: pd.DataFrame({"col": [1]})),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_validate_against_schema",
            staticmethod(lambda kind, df: []),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_transform_df",
            staticmethod(lambda kind, df, scope, currency: df),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_normalize_df",
            staticmethod(lambda df, **k: df),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_apply_db_schema",
            staticmethod(lambda df, **k: df),
        ), patch.object(
            SeriesLoadDataProcessor,
            "_add_id_column",
            staticmethod(lambda df, **k: df),
        ):
            result = SeriesLoadDataProcessor.process_scope_runner(
                "TestScope", scope_params
            )

        # Deve retornar uma lista com EXATAMENTE 4 elementos
        assert isinstance(result, list)
        assert len(result) == 4, f"Esperado 4 elementos, obtido {len(result)}: {result}"
        scope, success, error, data = result
        assert scope == "TestScope"
        assert success is True
        assert error is None
        assert isinstance(data, pd.DataFrame)
        # 3 arquivos x 1 registro cada = 3 registros consolidados
        assert len(data) == 3

    def test_process_extractor_runner_partial_failure(self):
        """Simula 2 providers sucesso + 1 falha; sucesso geral deve ser False."""
        mock_provider = MagicMock()
        mock_provider.EXPECTED_PARAMS = {
            "timeout": (int, False, 30000),
            "storage_folder": (str, True, None),
            "parallelize": (bool, False, True),
            "progress": (bool, False, False),
            "wait": (int, False, 10),
            "llm": (str, False, None),
            "verbose_mode": (bool, False, False),
            "sub_folders": (list, False, []),
            "writer": (callable, False, None),
        }

        scope_params = {
            "params": [
                {
                    "provider": mock_provider,
                    "storage_folder": "/tmp",
                    "sub_folders": ["TEST"],
                    "parallelize": False,
                    "progress": False,
                    "writer": lambda df, path: path,
                    "wait": 0,
                }
            ],
            "series": [{"ticker": "A"}, {"ticker": "B"}],
        }

        call_count = 0

        def fake_runner(*args):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                return False, "Provider failed", pd.DataFrame()
            return True, None, pd.DataFrame([{"records": 1}])

        with patch.object(
            SeriesExtractDataProcessor,
            "process_provider_runner",
            staticmethod(fake_runner),
        ):
            result = SeriesExtractDataProcessor.process_extractor_runner(
                "TestScope", scope_params
            )

        assert len(result) == 4
        scope, success, error, data = result
        assert success is False
        assert "Provider failed" in error
        assert isinstance(data, pd.DataFrame)
