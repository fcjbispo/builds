"""
Teste de regressão para o bug: dominio_nome fica NaN nas pipelines

Quando pd.DataFrame() vazio recebe uma atribuição escalar seguida de
atribuição de Series, o escalar é perdido (fica NaN) porque o DataFrame
expande com base no índice da Series, mas o escalar não tem índice para
alinhamento.

Esse bug afetou todas as pipelines FX, STOCK e DIVIDEND, causando:
  (psycopg.errors.NotNullViolation) null value in column "dominio_nome"
"""

import pytest
import pandas as pd
import numpy as np

from infobr.data.series import SeriesLoadDataProcessor


class TestTransformDominioNomeNotNull:
    """Verifica que _transform_* retornam dominio_nome preenchido, não NaN."""

    def test_transform_stock_raises_on_missing_currency(self):
        """STOCK sem currency deve levantar ValueError, não retornar NaN."""
        df = pd.DataFrame({
            "Ticker": ["AAPL"],
            "Date": ["2026-05-28"],
            "Open": [100.0],
            "High": [110.0],
            "Low": [90.0],
            "Close": [105.0],
            "Volume": [1000.0],
            "Reference_Date": ["2026-05-28"],
        })
        with pytest.raises(ValueError, match="No DOMAIN_MAP entry"):
            SeriesLoadDataProcessor._transform_stock(df, "Stock Missing Currency")

    def test_transform_dividend_raises_on_missing_currency(self):
        """DIVIDEND sem currency deve levantar ValueError, não retornar NaN."""
        df = pd.DataFrame({
            "Ticker": ["AAPL"],
            "Payout_Frequency": ["Quarterly"],
            "Ex_Dividend_Date": ["2026-05-15"],
            "Record_Date": ["2026-05-16"],
            "Pay_Date": ["2026-05-30"],
            "Cash_Amount": [0.25],
            "Reference_Date": ["2026-05-28"],
        })
        with pytest.raises(ValueError, match="No DOMAIN_MAP entry"):
            SeriesLoadDataProcessor._transform_dividend(df, "Dividend Missing Currency")

    def test_transform_fx_dominio_nome_is_cambio(self):
        """FX deve retornar dominio_nome='CAMBIO' para todas as linhas."""
        df = pd.DataFrame({
            "From": ["EUR", "USD"],
            "To": ["BRL", "BRL"],
            "Date": ["2026-05-28", "2026-05-27"],
            "Open": [5.88, 5.85],
            "High": [5.90, 5.91],
            "Low": [5.85, 5.84],
            "Close": [5.87, 5.88],
        })
        result = SeriesLoadDataProcessor._transform_fx(df, "FX History")

        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "CAMBIO").all()
        assert result["ticker"].tolist() == ["EURBRL", "USDBRL"]

    def test_transform_stock_dominio_nome_is_acao_us(self):
        """STOCK USD deve retornar dominio_nome='ACAO_US'."""
        df = pd.DataFrame({
            "Ticker": ["AAPL"],
            "Date": ["2026-05-28"],
            "Open": [100.0],
            "High": [110.0],
            "Low": [90.0],
            "Close": [105.0],
            "Volume": [1000.0],
            "Reference_Date": ["2026-05-28"],
        })
        result = SeriesLoadDataProcessor._transform_stock(df, "Stock US", "USD")

        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "ACAO_US").all()

    def test_transform_stock_dominio_nome_is_acao_br(self):
        """STOCK BRL deve retornar dominio_nome='ACAO_BR'."""
        df = pd.DataFrame({
            "Ticker": ["PETR4"],
            "Date": ["2026-05-28"],
            "Open": [30.0],
            "High": [31.0],
            "Low": [29.0],
            "Close": [30.5],
            "Volume": [5000.0],
            "Reference_Date": ["2026-05-28"],
        })
        result = SeriesLoadDataProcessor._transform_stock(df, "Stock BR", "BRL")

        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "ACAO_BR").all()

    def test_transform_dividend_dominio_nome_is_dividendo_us(self):
        """DIVIDEND USD deve retornar dominio_nome='DIVIDENDO_US'."""
        df = pd.DataFrame({
            "Ticker": ["AAPL"],
            "Payout_Frequency": ["Quarterly"],
            "Ex_Dividend_Date": ["2026-05-15"],
            "Record_Date": ["2026-05-16"],
            "Pay_Date": ["2026-05-30"],
            "Cash_Amount": [0.25],
            "Reference_Date": ["2026-05-28"],
        })
        result = SeriesLoadDataProcessor._transform_dividend(df, "Dividend US", "USD")

        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "DIVIDENDO_US").all()

    def test_transform_dividend_dominio_nome_is_dividendo_br(self):
        """DIVIDEND BRL deve retornar dominio_nome='DIVIDENDO_BR'."""
        df = pd.DataFrame({
            "Ticker": ["PETR4"],
            "Payout_Frequency": ["Mensal"],
            "Ex_Dividend_Date": ["2026-05-10"],
            "Record_Date": ["2026-05-11"],
            "Pay_Date": ["2026-05-25"],
            "Cash_Amount": [1.50],
            "Reference_Date": ["2026-05-28"],
        })
        result = SeriesLoadDataProcessor._transform_dividend(df, "Dividend BR", "BRL")

        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "DIVIDENDO_BR").all()

    def test_transform_fx_multi_row_dominio_nome_replicated(self):
        """FX com múltiplas linhas deve replicar dominio_nome para todas."""
        df = pd.DataFrame({
            "From": ["EUR"] * 100,
            "To": ["BRL"] * 100,
            "Date": pd.date_range("2026-01-01", periods=100),
            "Open": np.random.rand(100),
            "High": np.random.rand(100),
            "Low": np.random.rand(100),
            "Close": np.random.rand(100),
        })
        result = SeriesLoadDataProcessor._transform_fx(df, "FX History")

        assert len(result) == 100
        assert result["dominio_nome"].notna().all()
        assert (result["dominio_nome"] == "CAMBIO").all()
