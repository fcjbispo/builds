"""CLI entrypoint for InfoBR API server."""

from __future__ import annotations

import uvicorn

from infobr.config import get_settings


def main() -> None:
    settings = get_settings()
    workers = settings.api_workers if not settings.api_reload else 1
    uvicorn.run(
        "infobr.api.main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=settings.api_reload,
        workers=max(1, workers),
    )


if __name__ == "__main__":
    main()
