"""Rate limiting helpers with Redis support."""

from __future__ import annotations

import os
import time
import warnings
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from datetime import datetime, timezone
from threading import Lock
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import redis


def _utc_now_ts() -> float:
    return datetime.now(timezone.utc).timestamp()


class RateLimiter(ABC):
    """Abstract base class for rate limiters."""

    @abstractmethod
    def allow(self, key: str, *, now_ts: float | None = None) -> tuple[bool, int]:
        """Return (allowed, retry_after_seconds). retry_after_seconds is 0 when allowed."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Reset all counters."""
        pass


class InMemoryRateLimiter(RateLimiter):
    """Per-key fixed-window limiter using UTC timestamps."""

    def __init__(self, *, max_requests: int, window_seconds: int):
        if max_requests < 1:
            raise ValueError("max_requests must be >= 1")
        if window_seconds < 1:
            raise ValueError("window_seconds must be >= 1")
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._entries: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def allow(self, key: str, *, now_ts: float | None = None) -> tuple[bool, int]:
        """
        Return (allowed, retry_after_seconds).

        retry_after_seconds is 0 when allowed.
        """
        if not key:
            return True, 0

        now = now_ts if now_ts is not None else _utc_now_ts()
        window_start = now - self.window_seconds

        with self._lock:
            bucket = self._entries[key]
            while bucket and bucket[0] <= window_start:
                bucket.popleft()

            if len(bucket) >= self.max_requests:
                retry_after = max(1, int(bucket[0] + self.window_seconds - now))
                return False, retry_after

            bucket.append(now)
            return True, 0

    def reset(self) -> None:
        """Reset all in-memory counters (test helper)."""
        with self._lock:
            self._entries.clear()


class RedisRateLimiter(RateLimiter):
    """
    VULN-002: Redis-based rate limiter using sorted sets.

    Uses Redis sorted sets (ZADD/ZREMRANGEBYSCORE/ZCARD) for distributed
    rate limiting that persists across workers and restarts.

    Key format: rate_limit:{key}
    Score: timestamp in seconds (float)
    Value: unique request ID (microsecond timestamp + random suffix)
    """

    def __init__(
        self,
        *,
        redis_client: "redis.Redis",
        max_requests: int,
        window_seconds: int,
        key_prefix: str = "rate_limit",
    ):
        if max_requests < 1:
            raise ValueError("max_requests must be >= 1")
        if window_seconds < 1:
            raise ValueError("window_seconds must be >= 1")
        self.redis = redis_client
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.key_prefix = key_prefix

    def _make_key(self, key: str) -> str:
        """Generate Redis key for the given rate limit key."""
        return f"{self.key_prefix}:{key}"

    def allow(self, key: str, *, now_ts: float | None = None) -> tuple[bool, int]:
        """
        Return (allowed, retry_after_seconds).

        Uses Redis sorted set operations for atomic rate limiting.
        """
        if not key:
            return True, 0

        now = now_ts if now_ts is not None else _utc_now_ts()
        window_start = now - self.window_seconds
        redis_key = self._make_key(key)

        # Use Redis pipeline for atomic operations
        pipe = self.redis.pipeline()

        # Remove expired entries
        pipe.zremrangebyscore(redis_key, 0, window_start)

        # Count current entries
        pipe.zcard(redis_key)

        # Get the oldest remaining entry (for retry_after calculation)
        pipe.zrange(redis_key, 0, 0, withscores=True)

        results = pipe.execute()
        count = results[1]
        oldest_entries = results[2]

        if count >= self.max_requests:
            # Rate limit exceeded
            if oldest_entries:
                oldest_ts = oldest_entries[0][1]
                retry_after = max(1, int(oldest_ts + self.window_seconds - now))
            else:
                retry_after = self.window_seconds
            return False, retry_after

        # Add current request
        request_id = f"{now}:{os.urandom(4).hex()}"
        self.redis.zadd(redis_key, {request_id: now})

        # Set expiration on the key to auto-cleanup
        self.redis.expire(redis_key, self.window_seconds + 1)

        return True, 0

    def reset(self) -> None:
        """Reset all rate limit counters by deleting keys with the prefix."""
        cursor = 0
        while True:
            cursor, keys = self.redis.scan(cursor, match=f"{self.key_prefix}:*", count=100)
            if keys:
                self.redis.delete(*keys)
            if cursor == 0:
                break


from infobr.config import get_settings


def build_default_rate_limiter() -> RateLimiter:
    """
    Build rate limiter from environment config.

    VULN-002: Uses RedisRateLimiter if INFOBR_REDIS_URL is set,
    otherwise falls back to InMemoryRateLimiter with a warning.
    """
    settings = get_settings()
    max_requests = settings.api_rate_limit_max_requests
    window_seconds = settings.api_rate_limit_window_seconds

    redis_url = settings.redis_url
    if redis_url:
        try:
            import redis as redis_lib

            redis_client = redis_lib.from_url(redis_url, decode_responses=True)
            # Test connection
            redis_client.ping()
            return RedisRateLimiter(
                redis_client=redis_client,
                max_requests=max_requests,
                window_seconds=window_seconds,
            )
        except Exception as e:
            warnings.warn(
                f"Failed to connect to Redis at {redis_url}: {e}. "
                "Falling back to InMemoryRateLimiter.",
                RuntimeWarning,
            )

    return InMemoryRateLimiter(max_requests=max_requests, window_seconds=window_seconds)

