"""InfoBR REST API package."""

