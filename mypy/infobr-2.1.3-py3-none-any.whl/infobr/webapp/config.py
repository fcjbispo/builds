"""Configuration helpers for Streamlit web app."""

from __future__ import annotations

from infobr.config import get_settings


def api_base_url() -> str:
    """Return API base URL used by the Streamlit client."""
    return str(get_settings().api_base_url).rstrip("/")

