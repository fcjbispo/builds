import os
from dotenv import load_dotenv
from sqlalchemy import create_engine

from fbpyservers_mcp.models import Base

import fbpyutils

_ = load_dotenv()

__version__ = "0.3.0"

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "ERROR")
env.CONFIG = {
    "mcp_db_url": {
        "url": os.environ.get(
            "FBPY_MCP_DB_URL",
            env.CONFIG.get("mcp_db_url", {}).get(
                "url", "postgresql://mcp:mcp@localhost:5432/fbnet"
            ),
        )
    },
}


logger = fbpyutils.get_logger()
logger.configure_from_env(env)

# Lazy initialization - don't connect on import
_engine = None
_engine_initialized = False

def _ensure_engine():
    """Lazy initialization of database engine."""
    global _engine, _engine_initialized
    if not _engine_initialized:
        logger.info(f"Connecting to MCP database at {env.CONFIG['mcp_db_url']['url']}")
        _engine = create_engine(env.CONFIG["mcp_db_url"]["url"], echo=False)
        # Criar todas as tabelas
        logger.info("Creating MCP database tables if they do not exist...")
        try:
            Base.metadata.create_all(_engine)
        except Exception as e:
            logger.warning(f"Could not create tables: {e}")
        _engine_initialized = True
    return _engine


class _EngineProxy:
    """Proxy that initializes engine on first access."""
    def __getattr__(self, name):
        return getattr(_ensure_engine(), name)
    
    def __setattr__(self, name, value):
        setattr(_ensure_engine(), name, value)


# Export proxy - engine is created on first access
engine = _EngineProxy()
