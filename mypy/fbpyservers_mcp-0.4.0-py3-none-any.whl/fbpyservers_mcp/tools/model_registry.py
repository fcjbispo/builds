"""
Model Registry Tools for MCP Server

Tools for querying and managing model registry data in PostgreSQL.
Uses the mcp schema tables: model, model_capability, benchmark_result, etc.
"""

import os
import json
from typing import Dict, List, Optional, Any
from decimal import Decimal

import psycopg2
from psycopg2.extras import RealDictCursor

# Database connection
DB_URL = os.environ.get(
    "FBPY_MCP_DB_URL",
    "postgresql://mcp:mcp@postgres:5432/fbnet"
)


class ModelRegistryEncoder(json.JSONEncoder):
    """Encoder for Decimal and other non-JSON serializable types"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)


def get_db_connection():
    """Create database connection"""
    return psycopg2.connect(DB_URL)


async def list_models(
    model_type: Optional[str] = None,
    provider: Optional[str] = None,
    is_active: Optional[bool] = True,
    limit: int = 50,
) -> str:
    """
    List models from the registry with optional filters.
    
    Args:
        model_type: Filter by type (vision, code, reasoning, etc.)
        provider: Filter by provider (ollama, openai, etc.)
        is_active: Filter by active status
        limit: Maximum results to return
        
    Returns:
        JSON string with model list
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            query = """
                SELECT 
                    id, name, provider, size_parameters,
                    context_length, model_type, version,
                    is_active, created_at
                FROM mcp.model
                WHERE 1=1
            """
            params = []
            
            if model_type:
                query += " AND model_type = %s"
                params.append(model_type)
            if provider:
                query += " AND provider = %s"
                params.append(provider)
            if is_active is not None:
                query += " AND is_active = %s"
                params.append(is_active)
                
            query += " ORDER BY name LIMIT %s"
            params.append(limit)
            
            cur.execute(query, params)
            results = cur.fetchall()
            
            return json.dumps({
                "success": True,
                "count": len(results),
                "models": results
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def get_model(model_name: str) -> str:
    """
    Get detailed information about a specific model.
    
    Args:
        model_name: The model name/ID (e.g., 'kimi-k2.5:cloud')
        
    Returns:
        JSON string with model details including capabilities
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Get model info
            cur.execute("""
                SELECT * FROM mcp.model
                WHERE name = %s
            """, (model_name,))
            model = cur.fetchone()
            
            if not model:
                return json.dumps({
                    "success": False,
                    "error": f"Model '{model_name}' not found"
                })
            
            # Get capabilities
            cur.execute("""
                SELECT capability, declared, tested, score_avg, status
                FROM mcp.model_capability
                WHERE model_id = %s
            """, (model['id'],))
            capabilities = cur.fetchall()
            
            # Get recent benchmark results
            cur.execute("""
                SELECT 
                    test_id, test_name, score, classification,
                    elapsed_seconds, created_at
                FROM mcp.benchmark_result
                WHERE model_id = %s
                ORDER BY created_at DESC
                LIMIT 20
            """, (model['id'],))
            results = cur.fetchall()
            
            return json.dumps({
                "success": True,
                "model": model,
                "capabilities": capabilities,
                "recent_results": results
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def recommend_model(
    task_type: str,
    min_context_length: Optional[int] = None,
    require_tested: bool = True,
) -> str:
    """
    Recommend the best model for a specific task type.
    
    Args:
        task_type: Type of task (code, vision, reasoning, ocr, etc.)
        min_context_length: Minimum required context window
        require_tested: Only consider tested capabilities
        
    Returns:
        JSON string with recommended model
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            query = """
                SELECT 
                    m.id, m.name, m.provider, m.size_parameters,
                    m.context_length, mc.score_avg,
                    COUNT(br.id) as test_count,
                    AVG(br.score) as avg_benchmark_score
                FROM mcp.model m
                JOIN mcp.model_capability mc ON m.id = mc.model_id
                LEFT JOIN mcp.benchmark_result br ON m.id = br.model_id
                WHERE mc.capability = %s
                AND m.is_active = true
            """
            params = [task_type]
            
            if require_tested:
                query += " AND mc.tested = true"
            if min_context_length:
                query += " AND m.context_length >= %s"
                params.append(min_context_length)
                
            query += """
                GROUP BY m.id, m.name, m.provider, m.size_parameters,
                         m.context_length, mc.score_avg
                ORDER BY mc.score_avg DESC NULLS LAST, avg_benchmark_score DESC NULLS LAST
                LIMIT 1
            """
            
            cur.execute(query, params)
            result = cur.fetchone()
            
            if not result:
                return json.dumps({
                    "success": False,
                    "error": f"No suitable model found for task type '{task_type}'"
                })
            
            return json.dumps({
                "success": True,
                "recommendation": result,
                "task_type": task_type
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def compare_models(
    model_names: List[str],
    capability: Optional[str] = None,
) -> str:
    """
    Compare multiple models side by side.
    
    Args:
        model_names: List of model names to compare
        capability: Optional capability to focus comparison
        
    Returns:
        JSON string with comparison data
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Get model info
            cur.execute("""
                SELECT id, name, provider, size_parameters,
                       context_length, model_type, is_active
                FROM mcp.model
                WHERE name = ANY(%s)
                ORDER BY name
            """, (model_names,))
            models = cur.fetchall()
            
            if not models:
                return json.dumps({
                    "success": False,
                    "error": "No models found"
                })
            
            model_ids = [m['id'] for m in models]
            
            # Get average scores
            cur.execute("""
                SELECT 
                    model_id,
                    AVG(score) as avg_score,
                    COUNT(*) as total_tests
                FROM mcp.benchmark_result
                WHERE model_id = ANY(%s)
                GROUP BY model_id
            """, (model_ids,))
            scores = {row['model_id']: row for row in cur.fetchall()}
            
            # Get capabilities if specified
            capabilities_by_model = {}
            if capability:
                cur.execute("""
                    SELECT model_id, score_avg, status
                    FROM mcp.model_capability
                    WHERE model_id = ANY(%s) AND capability = %s
                """, (model_ids, capability))
                capabilities_by_model = {row['model_id']: row for row in cur.fetchall()}
            
            # Build comparison
            comparison = []
            for model in models:
                model_id = model['id']
                comparison.append({
                    "name": model['name'],
                    "provider": model['provider'],
                    "size": model['size_parameters'],
                    "context": model['context_length'],
                    "type": model['model_type'],
                    "avg_score": scores.get(model_id, {}).get('avg_score'),
                    "total_tests": scores.get(model_id, {}).get('total_tests', 0),
                    "capability_score": capabilities_by_model.get(model_id, {}).get('score_avg') if capability else None
                })
            
            return json.dumps({
                "success": True,
                "comparison": comparison,
                "capability_filter": capability
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def query_benchmarks(
    model_name: Optional[str] = None,
    test_id: Optional[str] = None,
    min_score: Optional[float] = None,
    limit: int = 20,
) -> str:
    """
    Query benchmark results with filters.
    
    Args:
        model_name: Filter by model
        test_id: Filter by specific test
        min_score: Minimum score threshold
        limit: Maximum results
        
    Returns:
        JSON string with benchmark results
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            query = """
                SELECT 
                    br.id, m.name as model_name,
                    br.test_id, br.test_name, br.score,
                    br.classification, br.elapsed_seconds,
                    br.created_at
                FROM mcp.benchmark_result br
                JOIN mcp.model m ON br.model_id = m.id
                WHERE 1=1
            """
            params = []
            
            if model_name:
                query += " AND m.name = %s"
                params.append(model_name)
            if test_id:
                query += " AND br.test_id = %s"
                params.append(test_id)
            if min_score is not None:
                query += " AND br.score >= %s"
                params.append(min_score)
                
            query += " ORDER BY br.created_at DESC LIMIT %s"
            params.append(limit)
            
            cur.execute(query, params)
            results = cur.fetchall()
            
            return json.dumps({
                "success": True,
                "count": len(results),
                "results": results
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def get_best_by_capability(capability: str, limit: int = 5) -> str:
    """
    Get the best models for a specific capability.
    
    Args:
        capability: The capability to rank by (code, vision, reasoning, etc.)
        limit: Number of top models to return
        
    Returns:
        JSON string with ranked models
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    m.id, m.name, m.provider, m.size_parameters,
                    mc.score_avg, mc.tested, mc.status
                FROM mcp.model m
                JOIN mcp.model_capability mc ON m.id = mc.model_id
                WHERE mc.capability = %s
                AND m.is_active = true
                ORDER BY mc.score_avg DESC NULLS LAST
                LIMIT %s
            """, (capability, limit))
            
            results = cur.fetchall()
            
            return json.dumps({
                "success": True,
                "capability": capability,
                "count": len(results),
                "models": results
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
    finally:
        conn.close()


async def capability_matrix(model_type: Optional[str] = None) -> str:
    """
    Get complete capability matrix for all models.
    Shows which models have which capabilities and their scores.
    
    Args:
        model_type: Optional filter by model type (vision, code, reasoning)
        
    Returns:
        JSON with model × capability matrix
    """
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            query = """
                SELECT 
                    model_name, model_type, capability,
                    benchmark_score, status, test_date
                FROM mcp.model_capability_matrix
                WHERE 1=1
            """
            params = []
            
            if model_type:
                query += " AND model_type = %s"
                params.append(model_type)
            
            query += " ORDER BY model_name, capability"
            
            cur.execute(query, params)
            results = cur.fetchall()
            
            # Organize by model
            matrix = {}
            for row in results:
                model = row['model_name']
                if model not in matrix:
                    matrix[model] = {
                        "type": row['model_type'],
                        "capabilities": {}
                    }
                matrix[model]["capabilities"][row['capability']] = {
                    "score": float(row['benchmark_score']) if row['benchmark_score'] else None,
                    "status": row['status'],
                    "last_tested": row['test_date'].isoformat() if row['test_date'] else None
                }
            
            return json.dumps({
                "success": True,
                "count": len(matrix),
                "matrix": matrix
            }, cls=ModelRegistryEncoder, indent=2)
            
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)})
    finally:
        conn.close()


async def run_capability_benchmark(
    model_name: str,
    capability: Optional[str] = None
) -> str:
    """
    Run benchmark for model capabilities.
    Tests all declared capabilities or a specific one.
    
    Args:
        model_name: Model to test (e.g., 'gemma3:4b-cloud')
        capability: Optional specific capability to test
        
    Returns:
        JSON with benchmark results
    """
    import subprocess
    import os
    
    try:
        # Check if runner exists
        runner_path = os.path.expanduser(
            "~/.openclaw/workspace/Tests/model-benchmarks-v2/scripts/run_capability_benchmark.py"
        )
        
        if not os.path.exists(runner_path):
            return json.dumps({
                "success": False,
                "error": "Capability runner not found. Please ensure Benchmark V3 is installed."
            })
        
        # Run benchmark
        cmd = ["python3", runner_path, model_name]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600  # 10 minutes
        )
        
        return json.dumps({
            "success": result.returncode == 0,
            "model": model_name,
            "capability_filter": capability,
            "stdout": result.stdout[-2000:] if result.stdout else "",
            "stderr": result.stderr[-500:] if result.stderr else None,
            "return_code": result.returncode
        }, indent=2)
        
    except subprocess.TimeoutExpired:
        return json.dumps({
            "success": False,
            "error": "Benchmark timeout (10 minutes exceeded)"
        })
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": str(e)
        })
