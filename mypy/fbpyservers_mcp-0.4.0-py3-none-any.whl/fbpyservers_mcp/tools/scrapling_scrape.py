"""
Scrapling-based web scraping tools for MCP.

Este módulo fornece ferramentas de scraping avançado usando Scrapling,
complementando o FireCrawl existente para sites com proteção anti-bot.

Características:
- Bypass de Cloudflare e proteções anti-bot
- Extração estruturada via CSS selectors
- Suporte a SPAs e conteúdo dinâmico
- Fallback automático entre métodos
"""

import asyncio
from typing import Dict, List, Optional, Any
from pathlib import Path

# Configurar path do scrapling venv
SCRAPLING_VENV = Path.home() / "workspace/Tests/scrapling-test/.venv"
if SCRAPLING_VENV.exists():
    import site
    site.addsitedir(str(SCRAPLING_VENV / "lib/python3.11/site-packages"))

try:
    from scrapling.fetchers import StealthyFetcher
    SCRAPLING_AVAILABLE = True
except ImportError:
    SCRAPLING_AVAILABLE = False
    StealthyFetcher = None


def _ensure_scrapling() -> None:
    """Verifica se Scrapling está disponível."""
    if not SCRAPLING_AVAILABLE:
        raise ImportError(
            "Scrapling não disponível. "
            "Ative o venv: source ~/workspace/Tests/scrapling-test/.venv/bin/activate"
        )


async def scrapling_scrape(
    url: str,
    headless: bool = True,
    wait_for_network_idle: bool = True,
    timeout: int = 30000
) -> str:
    """
    Extrai conteúdo HTML de sites protegidos usando Scrapling.
    
    Ideal para sites com Cloudflare, anti-bot, SPAs dinâmicos.
    Complementa o FireCrawl quando ele é bloqueado.
    
    Args:
        url: URL do site a ser extraído
        headless: Executar Chrome em modo headless (padrão: True)
        wait_for_network_idle: Aguardar rede ficar ociosa (padrão: True)
        timeout: Timeout em ms (padrão: 30000)
    
    Returns:
        Conteúdo HTML completo da página
    """
    _ensure_scrapling()
    
    try:
        # Executa em thread separada (Scrapling é síncrono)
        loop = asyncio.get_event_loop()
        page = await loop.run_in_executor(
            None,
            lambda: StealthyFetcher.fetch(
                url,
                headless=headless,
                network_idle=wait_for_network_idle
            )
        )
        
        # Verifica se foi redirecionado ou bloqueado
        if page.status >= 400:
            return f"""# Erro ao acessar {url}

**Status**: {page.status}
**URL final**: {page.url}

Possíveis causas:
- Página bloqueada ou requer autenticação
- Rate limiting ativo
- URL inválida ou expirada

Tente novamente com `wait_for_network_idle=False` ou aumente o timeout."""
        
        # Extrai metadados
        title = page.find('title')
        title_text = title.get() if title else "Sem título"
        
        h1 = page.find('h1')
        h1_text = h1.get() if h1 else ""
        
        # Retorna HTML com metadados
        return f"""# Scrapling Result

**URL**: {url}  
**Título**: {title_text}  
**H1**: {h1_text}  
**Status**: {page.status}

---

## Conteúdo HTML

```html
{page.html_content[:50000] if len(page.html_content) > 50000 else page.html_content}
```

{f"... (truncado, total: {len(page.html_content)} chars)" if len(page.html_content) > 50000 else ""}
"""
    
    except Exception as e:
        return f"""# Erro no Scrapling

**URL**: {url}  
**Erro**: {str(e)}

**Soluções possíveis**:
1. Verifique se o venv está ativo: `source ~/workspace/Tests/scrapling-test/.venv/bin/activate`
2. Verifique se a URL é válida e acessível
3. Tente com `headless=False` para debug
4. Aumente o timeout"""


async def scrapling_extract_structured(
    url: str,
    selectors: Dict[str, str],
    headless: bool = True,
    timeout: int = 30000
) -> str:
    """
    Extrai dados estruturados de via CSS selectors usando Scrapling.
    
    Ideal para tabelas, cards de produtos, dados financeiros estruturados,
    ou qualquer padrão repetitivo em páginas.
    
    Args:
        url: URL do site a ser extraído
        selectors: Dicionário {nome_campo: css_selector}
            Ex: {'titulo': 'h1', 'preco': '.price', 'linhas': 'table tr'}
        headless: Executar Chrome em modo headless (padrão: True)
        timeout: Timeout em ms (padrão: 30000)
    
    Returns:
        Dados estruturados extraídos em formato Markdown/JSON
    """
    _ensure_scrapling()
    
    try:
        # Executa em thread separada
        loop = asyncio.get_event_loop()
        page = await loop.run_in_executor(
            None,
            lambda: StealthyFetcher.fetch(url, headless=headless)
        )
        
        # Extrai dados via selectors
        extracted_data = {}
        for field_name, selector in selectors.items():
            try:
                elements = page.find_all(selector)
                if elements:
                    # Se múltiplos elementos, retorna lista
                    values = [elem.get() for elem in elements]
                    extracted_data[field_name] = values if len(values) > 1 else values[0]
                else:
                    # Tenta find simples
                    element = page.find(selector)
                    extracted_data[field_name] = element.get() if element else None
            except Exception as e:
                extracted_data[field_name] = f"Error: {str(e)}"
        
        # Formata resultado como Markdown
        result_lines = [
            f"# Dados Estruturados: {url}",
            "",
            f"**Status**: {page.status}",
            f"**URL final**: {page.url}",
            "",
            "## Resultados por Selector",
            ""
        ]
        
        for field, value in extracted_data.items():
            result_lines.append(f"### `{field}`")
            if isinstance(value, list):
                for i, v in enumerate(value[:50]):  # Limita a 50 itens
                    result_lines.append(f"- {v}")
                if len(value) > 50:
                    result_lines.append(f"- ... (e mais {len(value) - 50} itens)")
            else:
                result_lines.append(f"{value}")
            result_lines.append("")
        
        # Adiciona JSON bruto
        result_lines.extend([
            "## JSON Bruto",
            "```json",
            str(extracted_data),
            "```"
        ])
        
        return "\n".join(result_lines)
    
    except Exception as e:
        return f"""# Erro na Extração Estruturada

**URL**: {url}  
**Erro**: {str(e)}

**Selectors usados**: {selectors}

**Dicas**:
1. Verifique se os CSS selectors estão corretos
2. Use browser DevTools para inspecionar elementos
3. Alguns sites carregam conteúdo dinamicamente - tente aumentar o timeout
4. Frames/iframes podem exigir tratamento especial"""


async def scrapling_get_selectors(
    url: str,
    headless: bool = True
) -> str:
    """
    Analisa uma página e sugere CSS selectors úteis.
    
    Retorna uma lista de selectors comuns (tabelas, listas, cards, etc.)
    para auxiliar na extração estruturada.
    
    Args:
        url: URL do site a ser analisado
        headless: Executar Chrome em modo headless (padrão: True)
    
    Returns:
        Lista de selectors sugeridos com descrição
    """
    _ensure_scrapling()
    
    try:
        loop = asyncio.get_event_loop()
        page = await loop.run_in_executor(
            None,
            lambda: StealthyFetcher.fetch(url, headless=headless)
        )
        
        # Analisa estrutura da página
        selectors_found = []
        
        # Tenta encontrar padrões comuns
        patterns = {
            'table': 'table',
            'table_rows': 'table tr',
            'table_cells': 'table td',
            'lists': 'ul li, ol li',
            'headings': 'h1, h2, h3',
            'links': 'a[href]',
            'images': 'img[src]',
            'articles': 'article',
            'cards': '[class*="card"], [class*="item"]',
            'forms': 'form',
            'inputs': 'input, select, textarea'
        }
        
        for name, selector in patterns.items():
            try:
                elements = page.find_all(selector)
                count = len(elements) if hasattr(elements, '__len__') else 0
                if count > 0:
                    selectors_found.append((name, selector, count))
            except:
                pass
        
        # Formata resultado
        lines = [
            f"# Análise de Selectors: {url}",
            "",
            f"**Título**: {page.find('title').get() if page.find('title') else 'N/A'}",
            f"**Status**: {page.status}",
            "",
            "## Selectors Encontrados",
            "",
            "| Nome | Selector | Quantidade |",
            "|------|----------|------------|"
        ]
        
        for name, selector, count in sorted(selectors_found, key=lambda x: -x[2]):
            lines.append(f"| {name} | `{selector}` | {count} |")
        
        lines.extend([
            "",
            "## Dicas de Uso",
            "",
            "Para extrair dados estruturados, use:",
            "",
            "```json",
            "{"
        ])
        
        # Sugere exemplos baseados no que encontrou
        if any(s[0] == 'table_rows' for s in selectors_found):
            lines.append('    "linhas_tabela": "table tr",')
        if any(s[0] == 'lists' for s in selectors_found):
            lines.append('    "itens_lista": "ul li",')
        if any(s[0] == 'cards' for s in selectors_found):
            lines.append('    "cards": "[class*=card]",')
        
        lines.extend([
            '    "titulo": "h1"',
            "}",
            "```",
            "",
            "Use `scrapling_extract_structured` com estes selectors."
        ])
        
        return "\n".join(lines)
    
    except Exception as e:
        return f"# Erro na Análise de Selectors\n\n**Erro**: {str(e)}"


# Lista de tools para registro no MCP
SCRAPLING_TOOLS = [
    scrapling_scrape,
    scrapling_extract_structured,
    scrapling_get_selectors
]
