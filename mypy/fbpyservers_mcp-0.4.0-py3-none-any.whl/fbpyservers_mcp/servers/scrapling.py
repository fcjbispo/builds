"""
MCP Server for Scrapling - Advanced Web Scraping

Complements FireCrawl by providing advanced scraping for sites with:
- Cloudflare and anti-bot protections
- Dynamic SPAs and JavaScript-heavy content
- Structured data extraction needs
"""

from pathlib import Path
import sys

from mcp.server.fastmcp import FastMCP

# Add scrapling venv to path (AFTER importing project deps)
# This ensures project dependencies take precedence
SCRAPLING_VENV = Path.home() / "workspace/Tests/scrapling-test/.venv"
if SCRAPLING_VENV.exists():
    # Append instead of insert to avoid overriding project deps
    site_packages = str(SCRAPLING_VENV / "lib/python3.11/site-packages")
    if site_packages not in sys.path:
        sys.path.append(site_packages)

from fbpyservers_mcp.tools.scrapling_scrape import (
    scrapling_scrape,
    scrapling_extract_structured,
    scrapling_get_selectors
)


# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_scrapling")


@mcp.tool()
async def scrapling_scrape_tool(
    url: str,
    headless: bool = True,
    wait_for_network_idle: bool = True,
    timeout: int = 30000
) -> str:
    """
    Extract HTML content from protected sites using Scrapling.
    
    Ideal for sites with Cloudflare, anti-bot, dynamic SPAs.
    Complements FireCrawl when it is blocked.
    
    Args:
        url: URL of the site to extract
        headless: Run Chrome in headless mode (default: True)
        wait_for_network_idle: Wait for network to be idle (default: True)
        timeout: Timeout in milliseconds (default: 30000)
    
    Returns:
        Full HTML content of the page
    """
    return await scrapling_scrape(url, headless, wait_for_network_idle, timeout)


@mcp.tool()
async def scrapling_extract_structured_tool(
    url: str,
    selectors: dict,
    headless: bool = True,
    timeout: int = 30000
) -> str:
    """
    Extract structured data via CSS selectors using Scrapling.
    
    Ideal for tables, product cards, financial data, or any repetitive pattern.
    
    Args:
        url: URL of the site to extract
        selectors: Dictionary {field_name: css_selector}
            Example: {"title": "h1", "price": ".price", "rows": "table tr"}
        headless: Run Chrome in headless mode (default: True)
        timeout: Timeout in milliseconds (default: 30000)
    
    Returns:
        Extracted structured data in Markdown/JSON format
    """
    return await scrapling_extract_structured(url, selectors, headless, timeout)


@mcp.tool()
async def scrapling_get_selectors_tool(
    url: str,
    headless: bool = True
) -> str:
    """
    Analyze a page and suggest useful CSS selectors.
    
    Returns a list of common selectors (tables, lists, cards, etc.)
    to assist with structured extraction.
    
    Args:
        url: URL of the site to analyze
        headless: Run Chrome in headless mode (default: True)
    
    Returns:
        List of suggested selectors with description
    """
    return await scrapling_get_selectors(url, headless)


if __name__ == "__main__":
    # Initialize and run the server
    mcp.run(transport="stdio")


def main():
    """Main entry point for CLI."""
    mcp.run(transport="stdio")
