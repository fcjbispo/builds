"""
MCP Model Registry Server

Provides MCP tools for querying model registry data:
- List available models with filters
- Get detailed model information
- Recommend models for specific tasks
- Compare multiple models
- Query benchmark results
- Get best models by capability
"""

from typing import Dict, Any, Optional, List
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.tools.model_registry import (
    list_models as tool_list_models,
    get_model as tool_get_model,
    recommend_model as tool_recommend_model,
    compare_models as tool_compare_models,
    query_benchmarks as tool_query_benchmarks,
    get_best_by_capability as tool_get_best_by_capability,
    capability_matrix as tool_capability_matrix,
    run_capability_benchmark as tool_run_capability_benchmark,
)

# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_model_registry")


@mcp.tool()
async def model_list(
    model_type: Optional[str] = None,
    provider: Optional[str] = None,
    is_active: Optional[bool] = True,
    limit: int = 50,
) -> str:
    """
    List models from the registry with optional filters.
    
    Args:
        model_type: Filter by type (vision, code, reasoning)
        provider: Filter by provider (ollama, openai)
        is_active: Filter by active status (default: True)
        limit: Maximum results (default: 50)
        
    Returns:
        JSON with model list including id, name, provider, size, context_length
    """
    return await tool_list_models(model_type, provider, is_active, limit)


@mcp.tool()
async def model_get(
    model_name: str,
) -> str:
    """
    Get detailed information about a specific model including capabilities and recent results.
    
    Args:
        model_name: The model name (e.g., 'kimi-k2.5:cloud', 'gemma3:4b-cloud')
        
    Returns:
        JSON with model details, capabilities, and recent benchmark results
    """
    return await tool_get_model(model_name)


@mcp.tool()
async def model_recommend(
    task_type: str,
    min_context_length: Optional[int] = None,
    require_tested: bool = True,
) -> str:
    """
    Recommend the best model for a specific task type based on benchmark scores.
    
    Args:
        task_type: Type of task (code, vision, reasoning, ocr)
        min_context_length: Minimum context window required
        require_tested: Only consider tested models (default: True)
        
    Returns:
        JSON with recommended model including score and test count
    """
    return await tool_recommend_model(task_type, min_context_length, require_tested)


@mcp.tool()
async def model_compare(
    model_names: List[str],
    capability: Optional[str] = None,
) -> str:
    """
    Compare multiple models side by side with scores and capabilities.
    
    Args:
        model_names: List of model names to compare
        capability: Optional specific capability to focus comparison
        
    Returns:
        JSON with comparison table including scores and test counts
    """
    return await tool_compare_models(model_names, capability)


@mcp.tool()
async def benchmark_query(
    model_name: Optional[str] = None,
    test_id: Optional[str] = None,
    min_score: Optional[float] = None,
    limit: int = 20,
) -> str:
    """
    Query benchmark results with various filters.
    
    Args:
        model_name: Filter by model name
        test_id: Filter by test ID (e.g., 'CONS-01-code')
        min_score: Minimum score threshold
        limit: Maximum results (default: 20)
        
    Returns:
        JSON with benchmark results including scores and classifications
    """
    return await tool_query_benchmarks(model_name, test_id, min_score, limit)


@mcp.tool()
async def model_best(
    capability: str,
    limit: int = 5,
) -> str:
    """
    Get the top-performing models for a specific capability.
    
    Args:
        capability: The capability to rank by (code, vision, reasoning, ocr)
        limit: Number of top models (default: 5)
        
    Returns:
        JSON with ranked models and their scores
    """
    return await tool_get_best_by_capability(capability, limit)


@mcp.tool()
async def model_capability_matrix(
    model_type: Optional[str] = None,
) -> str:
    """
    Get complete capability matrix showing all models and their capabilities.
    
    Args:
        model_type: Optional filter by model type (vision, code, reasoning)
        
    Returns:
        JSON with model × capability matrix showing scores and status
    """
    return await tool_capability_matrix(model_type)


@mcp.tool()
async def capability_benchmark_run(
    model_name: str,
    capability: Optional[str] = None,
) -> str:
    """
    Run benchmark for a model's capabilities.
    
    Args:
        model_name: Model to test (e.g., 'gemma3:4b-cloud')
        capability: Optional specific capability to test
        
    Returns:
        JSON with benchmark results and scores
    """
    return await tool_run_capability_benchmark(model_name, capability)


if __name__ == "__main__":
    # Run the server
    mcp.run()
