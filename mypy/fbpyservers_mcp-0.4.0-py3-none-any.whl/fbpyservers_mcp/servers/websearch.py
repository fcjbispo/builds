from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.tools.search import search


# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_websearch")


@mcp.tool()
async def web_search(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs a general internet search on internet web using various search mechanisms.
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch,
        categories=["general"],
    )


@mcp.tool()
async def web_search_images(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs an image search on internet web using various search mechanisms.
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch,
        categories=["images"],
    )


@mcp.tool()
async def web_search_videos(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs a video search on internet web using various search mechanisms.
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch,
        categories=["videos"],
    )


@mcp.tool()
async def web_search_music(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs a music search on internet web using various search mechanisms.
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch,
        categories=["music"],
    )


@mcp.tool()
async def web_search_map(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs a map search on internet web using various search mechanisms.
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch,
        categories=["map"],
    )


if __name__ == "__main__":
    # Initialize and run the server
    mcp.run(transport="stdio")


def main():
    """Main entry point for CLI."""
    mcp.run(transport="stdio")
