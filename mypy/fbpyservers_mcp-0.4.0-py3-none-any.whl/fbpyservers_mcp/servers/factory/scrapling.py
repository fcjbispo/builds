"""
Scrapling MCP server using factory pattern for STDIO protocol.

This module provides an advanced web scraping server using Scrapling:
- stdio: Standard input/output (default, Claude Desktop compatible)

Features:
- Bypass Cloudflare and anti-bot protections
- Structured data extraction via CSS selectors
- Support for SPAs and dynamic content
- Complements FireCrawl when blocked

Simple and reliable protocol without authentication or network requirements.
"""

import os
import sys
import logging
from pathlib import Path
from typing import Dict, Any

# Add scrapling venv to path before imports
SCRAPLING_VENV = Path.home() / "workspace/Tests/scrapling-test/.venv"
if SCRAPLING_VENV.exists():
    site_packages = str(SCRAPLING_VENV / "lib/python3.11/site-packages")
    if site_packages not in sys.path:
        sys.path.insert(0, site_packages)

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.scrapling_scrape import (
    scrapling_scrape,
    scrapling_extract_structured,
    scrapling_get_selectors,
    SCRAPLING_AVAILABLE
)


# Configure logging
logger = logging.getLogger(__name__)


def create_scrapling_server():
    """
    Create a Scrapling server with STDIO protocol.
    
    Returns:
        tuple: (server_instance, transport_info)
    """
    try:
        # Check if scrapling is available
        if not SCRAPLING_AVAILABLE:
            logger.warning(
                "Scrapling not available. "
                "Activate venv: source ~/workspace/Tests/scrapling-test/.venv/bin/activate"
            )
        
        server = MCPServerFactory.create_stdio_server(
            name="scrapling",
            tools=[
                scrapling_scrape,
                scrapling_extract_structured,
                scrapling_get_selectors
            ]
        )
        
        logger.info("Scrapling server created with stdio protocol")
        return server, "stdio"
        
    except Exception as e:
        logger.error(f"Failed to create scrapling server: {str(e)}")
        raise


def run_scrapling_server():
    """
    Run the Scrapling server with STDIO protocol.
    
    This is the main entry point for the scrapling server.
    """
    try:
        # Create server
        server, actual_transport = create_scrapling_server()
        
        # Print startup information
        print(f"🚀 Starting FBPyServers-MCP Scrapling Server")
        print(f"   Protocol: {actual_transport}")
        print(f"   Ready for Claude Desktop integration")
        print(f"   Available Tools:")
        print(f"     - scrapling_scrape: Extract HTML from protected sites")
        print(f"     - scrapling_extract_structured: Extract data via CSS selectors")
        print(f"     - scrapling_get_selectors: Analyze page and suggest selectors")
        
        if not SCRAPLING_AVAILABLE:
            print(f"\n⚠️  Warning: Scrapling not available!")
            print(f"   Activate: source ~/workspace/Tests/scrapling-test/.venv/bin/activate")
        
        # Run server with stdio protocol
        server.run(transport="stdio")
            
    except Exception as e:
        logger.error(f"Failed to start scrapling server: {str(e)}")
        print(f"❌ Error starting scrapling server: {str(e)}")
        sys.exit(1)


# Main entry point
if __name__ == "__main__":
    run_scrapling_server()


def main():
    """Main entry point for CLI."""
    run_scrapling_server()
