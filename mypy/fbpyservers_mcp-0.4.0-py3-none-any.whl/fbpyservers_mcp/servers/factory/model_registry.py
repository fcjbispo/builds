"""
Model Registry MCP Server Factory

Factory for creating Model Registry MCP server with STDIO protocol.
Provides tools for querying model registry, benchmarks, and recommendations.
"""

import os
import sys
import logging
from typing import List, Callable

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.model_registry import (
    list_models as registry_list_models,
    get_model as registry_get_model,
    recommend_model as registry_recommend_model,
    compare_models as registry_compare_models,
    query_benchmarks as registry_query_benchmarks,
    get_best_by_capability as registry_get_best_by_capability,
)

# Configure logging
logger = logging.getLogger(__name__)


# Define model registry tool functions
async def model_list(
    model_type: str = None,
    provider: str = None,
    is_active: bool = True,
    limit: int = 50,
) -> str:
    """List models with optional filters."""
    return await registry_list_models(model_type, provider, is_active, limit)


async def model_get(
    model_name: str,
) -> str:
    """Get detailed model information."""
    return await registry_get_model(model_name)


async def model_recommend(
    task_type: str,
    min_context_length: int = None,
    require_tested: bool = True,
) -> str:
    """Recommend best model for a task."""
    return await registry_recommend_model(task_type, min_context_length, require_tested)


async def model_compare(
    model_names: List[str],
    capability: str = None,
) -> str:
    """Compare multiple models."""
    return await registry_compare_models(model_names, capability)


async def benchmark_query(
    model_name: str = None,
    test_id: str = None,
    min_score: float = None,
    limit: int = 20,
) -> str:
    """Query benchmark results."""
    return await registry_query_benchmarks(model_name, test_id, min_score, limit)


async def model_best(
    capability: str,
    limit: int = 5,
) -> str:
    """Get best models by capability."""
    return await registry_get_best_by_capability(capability, limit)


# Tool definitions for factory
TOOLS: List[tuple] = [
    (model_list, "List models from the registry with optional filters"),
    (model_get, "Get detailed information about a specific model"),
    (model_recommend, "Recommend the best model for a specific task"),
    (model_compare, "Compare multiple models side by side"),
    (benchmark_query, "Query benchmark results with filters"),
    (model_best, "Get top models by capability"),
]


def create_server(protocol: str = "stdio"):
    """
    Create and configure the Model Registry MCP server.
    
    Args:
        protocol: Server protocol (stdio)
        
    Returns:
        Configured MCP server instance
    """
    logger.info(f"Creating Model Registry MCP server ({protocol} protocol)")
    
    factory = MCPServerFactory(
        name="fbpyservers-mcp-model-registry",
        protocol=protocol,
    )
    
    # Register all tools
    for tool_func, description in TOOLS:
        factory.add_tool(tool_func, description)
    
    return factory.create_server()


def main():
    """
    Main entry point for Model Registry MCP server.
    Detects protocol from environment or uses stdio default.
    """
    # Set database URL from environment
    db_url = os.environ.get("FBPY_MCP_DB_URL")
    if not db_url:
        logger.warning("FBPY_MCP_DB_URL not set, using default")
    
    # Protocol detection
    protocol = "stdio"
    if len(sys.argv) > 1:
        if sys.argv[1] in ["--stdio", "-s"]:
            protocol = "stdio"
        elif sys.argv[1] in ["--help", "-h"]:
            print(__doc__)
            sys.exit(0)
    
    logger.info(f"Starting Model Registry MCP server ({protocol})")
    
    try:
        server = create_server(protocol)
        server.run()
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
