from sqlalchemy import Integer, String, ForeignKey, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from enum import Enum


# Base class for all models
class Base(DeclarativeBase):
    pass


# Enum para validação do status
class StatusEnum(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    DISABLED = "DISABLED"


# Modelo para a tabela prompt_template -> PromptTemplate
class PromptTemplate(Base):
    __tablename__ = 'prompt_templates'
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    template: Mapped[str] = mapped_column(Text, nullable=False)
    arguments: Mapped[str] = mapped_column(Text)  # JSON string com definição dos argumentos
    status: Mapped[StatusEnum] = mapped_column(
        String(15), default=StatusEnum.PENDING, nullable=False
    )

# Modelo para a tabela prompt -> Prompt
class Prompt(Base):
    __tablename__ = "prompt"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[str] = mapped_column(String(4000), nullable=False)
    status: Mapped[StatusEnum] = mapped_column(
        String(15), default=StatusEnum.PENDING, nullable=False
    )


# Modelo para a tabela prompt_ARGUMENT -> PromptArgument
class PromptArgument(Base):
    __tablename__ = "prompt_argument"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[str] = mapped_column(String(4000), nullable=False)
    prompt_id: Mapped[int] = mapped_column(ForeignKey("prompt.id"), nullable=False)
    required: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    status: Mapped[StatusEnum] = mapped_column(
        String(15), default=StatusEnum.PENDING, nullable=False
    )

    # Relacionamento com Prompt
    prompt: Mapped["Prompt"] = relationship("Prompt", back_populates="arguments")


# Modelo para a tabela prompt_MESSAGE -> PromptMessage
class PromptMessage(Base):
    __tablename__ = "prompt_message"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    role: Mapped[str] = mapped_column(String(256), nullable=False)
    prompt_id: Mapped[int] = mapped_column(ForeignKey("prompt.id"), nullable=False)
    type: Mapped[str] = mapped_column(String(256), nullable=False)
    content: Mapped[str] = mapped_column(String(4000), nullable=False)
    status: Mapped[StatusEnum] = mapped_column(
        String(15), default=StatusEnum.PENDING, nullable=False
    )

    # Relacionamento com Prompt
    prompt: Mapped["Prompt"] = relationship("Prompt", back_populates="messages")


# Modelo para a tabela RESOURCE -> Resource
class Resource(Base):
    __tablename__ = "resource"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(256), nullable=False)
    size_bytes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    description: Mapped[str] = mapped_column(String(4000), nullable=False)
    uri: Mapped[str] = mapped_column(String(4000), nullable=False)
    status: Mapped[StatusEnum] = mapped_column(
        String(15), default=StatusEnum.PENDING, nullable=False
    )


# Adicionando os relacionamentos nas classes
Prompt.arguments = relationship("PromptArgument", back_populates="prompt")
Prompt.messages = relationship("PromptMessage", back_populates="prompt")