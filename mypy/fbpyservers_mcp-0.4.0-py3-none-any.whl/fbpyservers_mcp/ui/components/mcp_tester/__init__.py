"""
MCP Tester Component - Web UI for testing MCP servers

This module provides an interactive MCP testing console within the Streamlit UI.
"""

import streamlit as st
from typing import Optional

from .client import MCPTestClient, get_client
from .server_list import render_server_list_panel
from .config_panel import render_config_panel
from .tools_tab import render_tools_tab
from .resources_tab import render_resources_tab
from .prompts_tab import render_prompts_tab
from .logs_tab import render_logs_tab


def render_mcp_tester_page():
    """
    Render the main MCP Tester page.
    
    This is the entry point for the MCP Tester feature.
    Provides a three-panel layout:
    - Panel 1: Server selector
    - Panel 2: Configuration
    - Panel 3: Tabbed interface (Tools, Resources, Prompts, Logs)
    """
    st.header("🔧 MCP Tester")
    st.caption("Interactive console for testing and debugging MCP servers")
    
    # Initialize client in session state
    if "mcp_client" not in st.session_state:
        st.session_state.mcp_client = get_client()
    
    client = st.session_state.mcp_client
    
    # Three-column layout
    col1, col2, col3 = st.columns([1, 1.2, 2])
    
    # Panel 1: Server List
    with col1:
        render_server_list_panel()
    
    # Panel 2: Configuration
    with col2:
        render_config_panel(client)
    
    # Panel 3: Tabbed Notebook
    with col3:
        # Check connection status
        if not client.is_connected:
            st.info("Connect to a server to access tools, resources, and prompts.")
        
        # Tabs
        tab_tools, tab_resources, tab_prompts, tab_logs = st.tabs([
            "🔧 Tools",
            "📚 Resources",
            "💬 Prompts",
            "📋 Logs"
        ])
        
        with tab_tools:
            render_tools_tab(client)
        
        with tab_resources:
            render_resources_tab(client)
        
        with tab_prompts:
            render_prompts_tab(client)
        
        with tab_logs:
            render_logs_tab(client)


__all__ = [
    "render_mcp_tester_page",
    "MCPTestClient",
    "get_client",
]
