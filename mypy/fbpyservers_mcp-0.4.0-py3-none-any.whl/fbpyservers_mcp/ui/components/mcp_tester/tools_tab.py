"""
Tools Tab - Tab 1 of Panel 3 in MCP Tester

Provides tool listing, parameter editing, and execution.
"""

import json
from typing import Dict, List, Any
import streamlit as st
from .client import MCPTestClient
from .async_utils import run_async_in_thread


def render_tools_tab(client: MCPTestClient):
    """
    Render the Tools tab.
    
    Args:
        client: Connected MCPTestClient
    """
    if not client.is_connected:
        st.info("Connect to a server to view available tools.")
        return
    
    # Load tools if not cached
    if "mcp_tools" not in st.session_state:
        with st.spinner("Loading tools..."):
            try:
                tools = run_async_in_thread(client.list_tools())
                st.session_state.mcp_tools = tools
            except Exception as e:
                st.error(f"Failed to load tools: {str(e)}")
                st.session_state.mcp_tools = []
    
    tools = st.session_state.get("mcp_tools", [])
    
    if not tools:
        st.warning("No tools available from this server.")
        return
    
    st.caption(f"{len(tools)} tools available")
    
    # Tool selection
    selected_tool_name = st.selectbox(
        "Select Tool",
        options=[t["name"] for t in tools],
        format_func=lambda x: f"🛠️ {x}"
    )
    
    # Find selected tool
    selected_tool = next(
        (t for t in tools if t["name"] == selected_tool_name),
        None
    )
    
    if not selected_tool:
        return
    
    # Show tool info
    with st.expander("Tool Info", expanded=True):
        st.markdown(f"**{selected_tool['name']}**")
        st.caption(selected_tool.get("description", "No description"))
        
        st.json(selected_tool.get("input_schema", {}))
    
    # Parameters editor
    st.subheader("Parameters")
    
    schema = selected_tool.get("input_schema", {})
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    
    # Build default params from schema
    default_params = {}
    for prop_name, prop_schema in properties.items():
        if "default" in prop_schema:
            default_params[prop_name] = prop_schema["default"]
        elif prop_name in required:
            default_params[prop_name] = get_default_for_type(prop_schema.get("type"))
    
    # Parameter editor
    params = default_params.copy()
    
    if properties:
        for prop_name, prop_schema in properties.items():
            required_mark = " *" if prop_name in required else ""
            
            prop_type = prop_schema.get("type", "string")
            description = prop_schema.get("description", "")
            
            if prop_type == "string":
                params[prop_name] = st.text_input(
                    f"{prop_name}{required_mark}",
                    value=default_params.get(prop_name, ""),
                    help=description
                )
            elif prop_type == "integer":
                params[prop_name] = st.number_input(
                    f"{prop_name}{required_mark}",
                    value=default_params.get(prop_name, 0),
                    step=1,
                    help=description
                )
            elif prop_type == "number":
                params[prop_name] = st.number_input(
                    f"{prop_name}{required_mark}",
                    value=float(default_params.get(prop_name, 0.0)),
                    help=description
                )
            elif prop_type == "boolean":
                params[prop_name] = st.checkbox(
                    f"{prop_name}{required_mark}",
                    value=default_params.get(prop_name, False),
                    help=description
                )
            elif prop_type == "array":
                # Simple array input as JSON string
                default_str = json.dumps(default_params.get(prop_name, []))
                arr_str = st.text_area(
                    f"{prop_name}{required_mark} (JSON array)",
                    value=default_str,
                    help=description
                )
                try:
                    params[prop_name] = json.loads(arr_str)
                except:
                    params[prop_name] = []
            elif prop_type == "object":
                # Simple object input as JSON string
                default_str = json.dumps(default_params.get(prop_name, {}))
                obj_str = st.text_area(
                    f"{prop_name}{required_mark} (JSON object)",
                    value=default_str,
                    help=description
                )
                try:
                    params[prop_name] = json.loads(obj_str)
                except:
                    params[prop_name] = {}
    else:
        # No schema, use free-form JSON
        params_str = st.text_area(
            "Parameters (JSON)",
            value=json.dumps(params, indent=2),
            height=100
        )
        try:
            params = json.loads(params_str)
        except json.JSONDecodeError:
            st.error("Invalid JSON")
            params = {}
    
    # Execute button
    st.divider()
    
    col1, col2 = st.columns([1, 4])
    with col1:
        execute = st.button("▶️ Execute", type="primary", use_container_width=True)
    
    with col2:
        if st.checkbox("Show raw JSON", value=False):
            st.json(params)
    
    # Execute tool
    if execute:
        with st.spinner(f"Executing {selected_tool_name}..."):
            try:
                result = run_async_in_thread(client.call_tool(selected_tool_name, params))
                st.session_state.last_tool_result = result
            except Exception as e:
                st.error(f"Tool execution failed: {str(e)}")
                st.session_state.last_tool_result = {
                    "isError": True,
                    "content": [{"type": "text", "text": f"Error: {str(e)}"}]
                }
    
    # Display result
    if "last_tool_result" in st.session_state:
        st.divider()
        st.subheader("📤 Response")
        
        result = st.session_state.last_tool_result
        
        if result.get("isError"):
            st.error("Tool execution failed")
        else:
            st.success("Success")
        
        # Display content
        for content in result.get("content", []):
            if content.get("type") == "text":
                text = content.get("text", "")
                # Try to detect JSON
                try:
                    json_data = json.loads(text)
                    st.json(json_data)
                except:
                    st.text(text)
            else:
                st.write(content)
        
        # Raw result
        with st.expander("Raw Result"):
            st.json(result)


def get_default_for_type(json_type: str) -> Any:
    """
    Get default value for JSON schema type.
    
    Args:
        json_type: JSON schema type string
        
    Returns:
        Default value for type
    """
    defaults = {
        "string": "",
        "integer": 0,
        "number": 0.0,
        "boolean": False,
        "array": [],
        "object": {}
    }
    return defaults.get(json_type, None)
