"""
Configuration Panel - Panel 2 of MCP Tester

Provides transport configuration, environment variables, and connection controls.
"""

import os
from typing import Dict
import streamlit as st
from .client import MCPTestClient
from .async_utils import run_async_in_thread


def render_config_panel(client: MCPTestClient):
    """
    Render the configuration panel (Panel 2).
    
    Args:
        client: MCPTestClient instance from session state
    """
    st.subheader("⚙️ Configuration")
    
    # Transport type
    st.selectbox(
        "Transport",
        options=["stdio"],
        index=0,
        disabled=True,
        help="Only stdio transport is supported in this version"
    )
    
    # Command input
    selected_server = st.session_state.get("selected_server", {})
    default_cmd = selected_server.get("command", "")
    
    command = st.text_input(
        "Command",
        value=default_cmd,
        placeholder="e.g., fbpyservers-mcp-memory",
        help="Full command to start the MCP server"
    )
    
    # Working directory
    cwd = st.text_input(
        "Working Directory (optional)",
        placeholder=os.getcwd(),
        help="Directory where server will run"
    )
    if not cwd:
        cwd = None
    
    # Timeout
    timeout = st.number_input(
        "Timeout (seconds)",
        min_value=5,
        max_value=300,
        value=30,
        step=5,
        help="Connection timeout"
    )
    
    st.divider()
    st.subheader("🔐 Environment Variables")
    
    # Common env vars
    env_vars = {}
    
    with st.expander("Common MCP Variables", expanded=True):
        # Database URL
        db_url = st.text_input(
            "FBPY_MCP_DB_URL",
            value=os.environ.get("FBPY_MCP_DB_URL", "postgresql://mcp:mcp@postgres:5432/fbnet"),
            type="password"
        )
        if db_url:
            env_vars["FBPY_MCP_DB_URL"] = db_url
        
        # Memory config
        memory_config = st.text_input(
            "FBPY_MEMORY_CONFIG_FILE",
            value=os.environ.get("FBPY_MEMORY_CONFIG_FILE", "")
        )
        if memory_config:
            env_vars["FBPY_MEMORY_CONFIG_FILE"] = memory_config
        
        # Memory user/agent
        col1, col2 = st.columns(2)
        with col1:
            memory_user = st.text_input(
                "FBPY_MEMORY_USER",
                value=os.environ.get("FBPY_MEMORY_USER", "default_user")
            )
            if memory_user:
                env_vars["FBPY_MEMORY_USER"] = memory_user
        
        with col2:
            memory_agent = st.text_input(
                "FBPY_MEMORY_AGENT",
                value=os.environ.get("FBPY_MEMORY_AGENT", "default_agent")
            )
            if memory_agent:
                env_vars["FBPY_MEMORY_AGENT"] = memory_agent
    
    # Custom env vars
    with st.expander("Custom Variables"):
        custom_env = st.text_area(
            "Additional ENV vars (KEY=value per line)",
            placeholder="MY_VAR=my_value\nOTHER=123",
            help="One KEY=value pair per line"
        )
        if custom_env:
            for line in custom_env.strip().split("\n"):
                if "=" in line:
                    key, value = line.split("=", 1)
                    env_vars[key.strip()] = value.strip()
    
    # Connection status
    st.divider()
    
    status_col, button_col = st.columns([2, 1])
    
    with status_col:
        if client.is_connected:
            st.success("🟢 Connected")
        else:
            st.info("⚪ Disconnected")
    
    with button_col:
        if client.is_connected:
            if st.button("Disconnect", type="secondary", use_container_width=True):
                # Run disconnect in separate thread to avoid event loop conflicts
                try:
                    run_async_in_thread(client.disconnect())
                    st.session_state.mcp_client = MCPTestClient()
                    st.rerun()
                except Exception as e:
                    st.error(f"Disconnect error: {str(e)}")
        else:
            if st.button("Connect", type="primary", use_container_width=True):
                if not command:
                    st.error("Please enter a command")
                else:
                    with st.spinner("Connecting..."):
                        try:
                            success = run_async_in_thread(client.connect(
                                command=command,
                                env=env_vars,
                                cwd=cwd,
                                timeout=timeout
                            ))
                            if success:
                                st.session_state.mcp_client = client
                                st.success("Connected!")
                                st.rerun()
                            else:
                                st.error("Connection failed. Check logs.")
                        except Exception as e:
                            st.error(f"Connection error: {str(e)}")
                            # Try to get logs from client
                            if hasattr(client, 'get_logs'):
                                logs = client.get_logs(5)
                                with st.expander("Recent logs"):
                                    for log in logs[-5:]:
                                        st.text(f"{log['timestamp']} [{log['level']}] {log['event']}")
    
    # Connection info
    if client.is_connected:
        st.caption(f"Command: `{client.command}`")
        st.caption(f"Env: {len(client.env)} variables set")


def get_connection_config() -> Dict:
    """
    Get current connection configuration from session state.
    
    Returns:
        Dict with transport, command, env, cwd
    """
    selected = st.session_state.get("selected_server", {})
    return {
        "transport": "stdio",
        "command": selected.get("command", ""),
        "env": {},  # Populated from form
        "cwd": None
    }
