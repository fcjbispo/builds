"""
MCP Test Client for Web UI

Wrapper around MCP SDK for connecting to and testing MCP servers.
"""

import os
import json
import asyncio
import logging
import subprocess
from typing import Dict, List, Optional, Any
from datetime import datetime
from contextlib import asynccontextmanager

# MCP SDK imports
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False

logger = logging.getLogger(__name__)


class MCPTestClient:
    """
    Client for testing MCP servers via stdio transport.
    
    Usage:
        client = MCPTestClient()
        await client.connect("python -m my_server")
        tools = await client.list_tools()
        result = await client.call_tool("tool_name", {"arg": "value"})
        await client.disconnect()
    """
    
    def __init__(self):
        self.session: Optional[ClientSession] = None
        self.read = None
        self.write = None
        self._connected = False
        self._logs: List[Dict] = []
        self.command: Optional[str] = None
        self.env: Dict[str, str] = {}
        
    def _log(self, event: str, level: str = "info", details: Any = None):
        """Log an event with timestamp."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event": event,
            "level": level,
            "details": details
        }
        self._logs.append(entry)
        
        if level == "error":
            logger.error(f"{event}: {details}")
        elif level == "warning":
            logger.warning(f"{event}: {details}")
        else:
            logger.info(f"{event}: {details}")
    
    async def connect(
        self,
        command: str,
        env: Optional[Dict[str, str]] = None,
        cwd: Optional[str] = None,
        timeout: int = 30
    ) -> bool:
        """
        Connect to MCP server via stdio.
        
        Args:
            command: Command to start server (e.g., "python -m my_server")
            env: Environment variables dict
            cwd: Working directory
            timeout: Connection timeout in seconds
            
        Returns:
            True if connected successfully
        """
        if not MCP_AVAILABLE:
            self._log("MCP SDK not available", "error")
            return False
            
        try:
            self.command = command
            self.env = env or {}
            
            # Merge with existing env
            server_env = os.environ.copy()
            server_env.update(self.env)
            
            self._log("Connecting", "info", {"command": command, "cwd": cwd})
            
            # Create server parameters
            server_params = StdioServerParameters(
                command=command.split()[0],
                args=command.split()[1:] if len(command.split()) > 1 else [],
                env=server_env
            )
            
            # Connect with timeout
            async with asyncio.timeout(timeout):
                self.read, self.write = await stdio_client(server_params).__aenter__()
                self.session = ClientSession(self.read, self.write)
                await self.session.initialize()
                
            self._connected = True
            self._log("Connected", "success")
            return True
            
        except Exception as e:
            self._log("Connection failed", "error", str(e))
            await self.disconnect()
            return False
    
    async def disconnect(self):
        """Disconnect from server and cleanup."""
        try:
            if self.session:
                await self.session.__aexit__(None, None, None)
                self.session = None
            if self.read and self.write:
                await self.read.aclose()
                await self.write.aclose()
                self.read = None
                self.write = None
            self._connected = False
            self._log("Disconnected", "info")
        except Exception as e:
            self._log("Disconnect error", "warning", str(e))
    
    @property
    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._connected and self.session is not None
    
    async def list_tools(self) -> List[Dict]:
        """
        List available tools from server.
        
        Returns:
            List of tool definitions
        """
        if not self.is_connected:
            self._log("Not connected", "error")
            return []
            
        try:
            tools = await self.session.list_tools()
            self._log("Listed tools", "success", {"count": len(tools.tools)})
            
            # Convert to serializable format
            return [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "input_schema": tool.inputSchema
                }
                for tool in tools.tools
            ]
        except Exception as e:
            self._log("Failed to list tools", "error", str(e))
            return []
    
    async def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a tool on the server.
        
        Args:
            name: Tool name
            arguments: Tool arguments dict
            
        Returns:
            Tool result with content and isError
        """
        if not self.is_connected:
            return {"isError": True, "content": [{"type": "text", "text": "Not connected"}]}
            
        try:
            self._log("Calling tool", "info", {"name": name, "args": arguments})
            result = await self.session.call_tool(name, arguments)
            
            self._log("Tool executed", "success" if not result.isError else "error")
            
            # Convert to serializable format
            return {
                "isError": result.isError,
                "content": [
                    {
                        "type": content.type,
                        "text": content.text if hasattr(content, 'text') else str(content)
                    }
                    for content in result.content
                ]
            }
        except Exception as e:
            self._log("Tool call failed", "error", str(e))
            return {
                "isError": True,
                "content": [{"type": "text", "text": f"Error: {str(e)}"}]
            }
    
    async def list_resources(self) -> List[Dict]:
        """
        List available resources.
        
        Returns:
            List of resource definitions
        """
        if not self.is_connected:
            return []
            
        try:
            resources = await self.session.list_resources()
            self._log("Listed resources", "success", {"count": len(resources.resources)})
            
            return [
                {
                    "uri": str(r.uri),
                    "name": r.name,
                    "mime_type": r.mimeType
                }
                for r in resources.resources
            ]
        except Exception as e:
            self._log("Failed to list resources", "error", str(e))
            return []
    
    async def read_resource(self, uri: str) -> Dict[str, Any]:
        """
        Read resource content.
        
        Args:
            uri: Resource URI
            
        Returns:
            Resource content with mime_type
        """
        if not self.is_connected:
            return {"error": "Not connected"}
            
        try:
            result = await self.session.read_resource(uri)
            
            return {
                "mime_type": result.mimeType,
                "content": result.content
            }
        except Exception as e:
            self._log("Failed to read resource", "error", str(e))
            return {"error": str(e)}
    
    async def list_prompts(self) -> List[Dict]:
        """
        List available prompts.
        
        Returns:
            List of prompt definitions
        """
        if not self.is_connected:
            return []
            
        try:
            prompts = await self.session.list_prompts()
            self._log("Listed prompts", "success", {"count": len(prompts.prompts)})
            
            return [
                {
                    "name": p.name,
                    "description": p.description,
                    "arguments": [
                        {"name": arg.name, "required": arg.required, "description": arg.description}
                        for arg in (p.arguments or [])
                    ]
                }
                for p in prompts.prompts
            ]
        except Exception as e:
            self._log("Failed to list prompts", "error", str(e))
            return []
    
    async def get_prompt(self, name: str, arguments: Dict[str, str]) -> Dict[str, Any]:
        """
        Get prompt messages.
        
        Args:
            name: Prompt name
            arguments: Prompt arguments
            
        Returns:
            Generated messages
        """
        if not self.is_connected:
            return {"error": "Not connected"}
            
        try:
            result = await self.session.get_prompt(name, arguments)
            
            return {
                "description": result.description,
                "messages": [
                    {
                        "role": msg.role,
                        "content": {
                            "type": msg.content.type,
                            "text": msg.content.text if hasattr(msg.content, 'text') else str(msg.content)
                        }
                    }
                    for msg in result.messages
                ]
            }
        except Exception as e:
            self._log("Failed to get prompt", "error", str(e))
            return {"error": str(e)}
    
    def get_logs(self, limit: int = 100) -> List[Dict]:
        """
        Get recent logs.
        
        Args:
            limit: Maximum number of logs
            
        Returns:
            List of log entries
        """
        return self._logs[-limit:]
    
    def clear_logs(self):
        """Clear log history."""
        self._logs.clear()


# Singleton for session state
def get_client() -> MCPTestClient:
    """Get or create MCP test client."""
    return MCPTestClient()
