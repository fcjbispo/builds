"""
Resources Tab - Tab 2 of Panel 3 in MCP Tester

Provides resource listing and content reading.
"""

import streamlit as st
from .client import MCPTestClient
from .async_utils import run_async_in_thread


def render_resources_tab(client: MCPTestClient):
    """
    Render the Resources tab.
    
    Args:
        client: Connected MCPTestClient
    """
    if not client.is_connected:
        st.info("Connect to a server to view available resources.")
        return
    
    # Load resources if not cached
    if "mcp_resources" not in st.session_state:
        with st.spinner("Loading resources..."):
            try:
                resources = run_async_in_thread(client.list_resources())
                st.session_state.mcp_resources = resources
            except Exception as e:
                st.error(f"Failed to load resources: {str(e)}")
                st.session_state.mcp_resources = []
    
    resources = st.session_state.get("mcp_resources", [])
    
    if not resources:
        st.warning("No resources available from this server.")
        return
    
    st.caption(f"{len(resources)} resources available")
    
    # Resource selection
    selected_resource = st.selectbox(
        "Select Resource",
        options=resources,
        format_func=lambda x: f"📄 {x.get('name', x['uri'])} ({x.get('mime_type', 'unknown')})"
    )
    
    if not selected_resource:
        return
    
    # Resource info
    with st.expander("Resource Info", expanded=True):
        st.markdown(f"**URI:** `{selected_resource['uri']}`")
        st.caption(f"**Name:** {selected_resource.get('name', 'N/A')}")
        st.caption(f"**MIME Type:** {selected_resource.get('mime_type', 'N/A')}")
    
    # Read button
    col1, col2 = st.columns([1, 4])
    with col1:
        if st.button("📖 Read Resource", type="primary", use_container_width=True):
            with st.spinner("Reading..."):
                try:
                    result = run_async_in_thread(client.read_resource(selected_resource['uri']))
                    st.session_state.last_resource_result = result
                except Exception as e:
                    st.error(f"Failed to read resource: {str(e)}")
                    st.session_state.last_resource_result = {"error": str(e)}
    
    with col2:
        if st.checkbox("Subscribe to updates", value=False):
            st.info("Subscription not implemented in this version")
    
    # Display result
    if "last_resource_result" in st.session_state:
        st.divider()
        st.subheader("📄 Content")
        
        result = st.session_state.last_resource_result
        
        if "error" in result:
            st.error(f"Failed to read resource: {result['error']}")
        else:
            mime_type = result.get("mime_type", "text/plain")
            content = result.get("content", "")
            
            st.caption(f"MIME Type: `{mime_type}`")
            
            # Display based on MIME type
            if mime_type.startswith("text/"):
                st.text(content)
            elif mime_type == "application/json":
                try:
                    import json
                    data = json.loads(content)
                    st.json(data)
                except:
                    st.text(content)
            else:
                st.text(content)
            
            # Download button
            st.download_button(
                "Download",
                data=content,
                file_name=f"resource_{selected_resource['uri'].replace('://', '_')}",
                mime=mime_type
            )
    
    # Refresh button
    if st.button("🔄 Refresh Resource List"):
        st.session_state.pop("mcp_resources", None)
        st.rerun()
