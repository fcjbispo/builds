"""
Logs Tab - Tab 4 of Panel 3 in MCP Tester

Provides protocol event logging and console output.
"""

import streamlit as st
from .client import MCPTestClient


def render_logs_tab(client: MCPTestClient):
    """
    Render the Logs tab.
    
    Args:
        client: MCPTestClient instance
    """
    st.subheader("📋 Protocol Events")
    
    # Get logs from client
    logs = client.get_logs(limit=200) if client else []
    
    # Controls
    col1, col2, col3 = st.columns([1, 1, 3])
    
    with col1:
        if st.button("🗑️ Clear", use_container_width=True):
            client.clear_logs()
            st.rerun()
    
    with col2:
        if st.checkbox("Auto-scroll", value=True):
            st.info("Auto-scroll enabled")
    
    with col3:
        filter_level = st.selectbox(
            "Filter",
            options=["All", "info", "success", "warning", "error"],
            index=0,
            label_visibility="collapsed"
        )
    
    st.divider()
    
    # Filter logs
    if filter_level != "All":
        logs = [log for log in logs if log.get("level") == filter_level]
    
    # Display logs
    if not logs:
        st.info("No events logged yet. Connect to a server and use features to generate logs.")
    else:
        st.caption(f"Showing {len(logs)} events")
        
        for log in logs:
            timestamp = log.get("timestamp", "")[11:19]  # HH:MM:SS
            level = log.get("level", "info")
            event = log.get("event", "")
            details = log.get("details")
            
            # Icon based on level
            icon = {
                "error": "🔴",
                "warning": "🟡",
                "success": "🟢",
                "info": "⚪"
            }.get(level, "⚪")
            
            with st.container():
                cols = st.columns([1, 6])
                with cols[0]:
                    st.code(f"{timestamp} {icon}", language=None)
                
                with cols[1]:
                    st.text(event)
                    if details:
                        with st.expander("Details", expanded=False):
                            if isinstance(details, (dict, list)):
                                import json
                                st.code(json.dumps(details, indent=2), language="json")
                            else:
                                st.code(str(details), language=None)
    
    st.divider()
    
    # Export
    if logs and st.button("📥 Export Logs"):
        import json
        from io import StringIO
        
        log_data = json.dumps(logs, indent=2)
        st.download_button(
            "Download JSON",
            data=log_data,
            file_name="mcp_logs.json",
            mime="application/json"
        )
