"""
Server List Panel - Panel 1 of MCP Tester

Provides auto-discovery and manual add of MCP servers.
"""

import os
import json
import subprocess
from typing import List, Dict, Optional
import streamlit as st


def discover_mcp_servers() -> List[Dict]:
    """
    Auto-discover installed MCP servers from entry points.
    
    Returns:
        List of server entries with name, command, status
    """
    servers = []
    
    # Common patterns for MCP servers
    patterns = [
        "fbpyservers-mcp-*",
        "mcp-*",
    ]
    
    try:
        # Use pip to list installed packages with scripts
        result = subprocess.run(
            ["pip", "list", "--format=json"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            packages = json.loads(result.stdout)
            
            # Check for known MCP servers
            known_servers = [
                "fbpyservers-mcp-memory",
                "fbpyservers-mcp-websearch",
                "fbpyservers-mcp-webscrape",
                "fbpyservers-mcp-scrapling",
                "fbpyservers-mcp-context",
                "fbpyservers-mcp-model-registry",
            ]
            
            for name in known_servers:
                # Check if command exists
                cmd_check = subprocess.run(
                    ["which", name],
                    capture_output=True
                )
                if cmd_check.returncode == 0:
                    servers.append({
                        "name": name,
                        "command": name,
                        "status": "available",
                        "description": get_server_description(name)
                    })
    except Exception as e:
        st.error(f"Failed to discover servers: {e}")
    
    return servers


def get_server_description(name: str) -> str:
    """Get description for known server."""
    descriptions = {
        "fbpyservers-mcp-memory": "Semantic memory storage and retrieval",
        "fbpyservers-mcp-websearch": "Multi-category web search with SearXNG",
        "fbpyservers-mcp-webscrape": "Web scraping with FireCrawl",
        "fbpyservers-mcp-scrapling": "Anti-bot scraping with Scrapling bypass",
        "fbpyservers-mcp-context": "Documentation context management",
        "fbpyservers-mcp-model-registry": "Model registry and benchmark queries",
    }
    return descriptions.get(name, "MCP Server")


def render_server_list_panel():
    """
    Render the server list panel (Panel 1).
    Updates session state with selected server.
    """
    st.subheader("🖥️ Servers")
    
    # Initialize server list in session state
    if "available_servers" not in st.session_state:
        with st.spinner("Discovering servers..."):
            st.session_state.available_servers = discover_mcp_servers()
    
    # Refresh button
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button("🔄 Refresh", use_container_width=True):
            st.session_state.available_servers = discover_mcp_servers()
            st.rerun()
    
    # Server list
    servers = st.session_state.get("available_servers", [])
    
    if not servers:
        st.info("No MCP servers found. Add one manually below.")
    else:
        st.caption(f"Found {len(servers)} servers")
        
        for server in servers:
            status_icon = {
                "available": "⚪",
                "connected": "🟢",
                "error": "🔴"
            }.get(server.get("status", "available"), "⚪")
            
            # Server card
            with st.container():
                cols = st.columns([4, 1])
                with cols[0]:
                    if st.button(
                        f"{status_icon} {server['name']}",
                        key=f"server_{server['name']}",
                        use_container_width=True
                    ):
                        st.session_state.selected_server = server
                        st.rerun()
                
                with cols[1]:
                    st.caption(server.get("status", "unknown"))
    
    # Manual add section
    st.divider()
    st.subheader("➕ Add Custom")
    
    with st.form("add_server_form"):
        custom_name = st.text_input("Name", placeholder="my-server")
        custom_cmd = st.text_input("Command", placeholder="python -m my_server")
        
        submitted = st.form_submit_button("Add Server", use_container_width=True)
        if submitted and custom_name and custom_cmd:
            new_server = {
                "name": custom_name,
                "command": custom_cmd,
                "status": "custom",
                "description": "Custom server"
            }
            servers.append(new_server)
            st.session_state.available_servers = servers
            st.success(f"Added {custom_name}")
            st.rerun()
    
    # Show selected server
    selected = st.session_state.get("selected_server")
    if selected:
        st.divider()
        st.markdown(f"**Selected:** `{selected['name']}`")
        st.caption(selected.get("description", ""))


def get_selected_server() -> Optional[Dict]:
    """Get currently selected server from session state."""
    return st.session_state.get("selected_server")
