"""
Async utilities for MCP Tester Web UI.

Helper functions to run async code safely in Streamlit's threaded environment.
"""

import asyncio
import threading


def run_async_in_thread(coro):
    """
    Run coroutine in a separate thread with its own event loop.
    This avoids conflicts with Streamlit's event loop and anyio.
    
    Args:
        coro: Coroutine to execute
        
    Returns:
        Result of the coroutine
        
    Raises:
        Exception: Any exception raised by the coroutine
    """
    result = None
    exception = None
    
    def thread_target():
        nonlocal result, exception
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(coro)
        except Exception as e:
            exception = e
        finally:
            loop.close()
    
    thread = threading.Thread(target=thread_target)
    thread.start()
    thread.join()
    
    if exception:
        raise exception
    return result
