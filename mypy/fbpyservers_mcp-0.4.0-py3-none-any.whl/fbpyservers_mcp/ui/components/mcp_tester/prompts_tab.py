"""
Prompts Tab - Tab 3 of Panel 3 in MCP Tester

Provides prompt listing and message generation.
"""

import streamlit as st
from .client import MCPTestClient
from .async_utils import run_async_in_thread


def render_prompts_tab(client: MCPTestClient):
    """
    Render the Prompts tab.
    
    Args:
        client: Connected MCPTestClient
    """
    if not client.is_connected:
        st.info("Connect to a server to view available prompts.")
        return
    
    # Load prompts if not cached
    if "mcp_prompts" not in st.session_state:
        with st.spinner("Loading prompts..."):
            try:
                prompts = run_async_in_thread(client.list_prompts())
                st.session_state.mcp_prompts = prompts
            except Exception as e:
                st.error(f"Failed to load prompts: {str(e)}")
                st.session_state.mcp_prompts = []
    
    prompts = st.session_state.get("mcp_prompts", [])
    
    if not prompts:
        st.warning("No prompts available from this server.")
        return
    
    st.caption(f"{len(prompts)} prompts available")
    
    # Prompt selection
    selected_prompt = st.selectbox(
        "Select Prompt",
        options=prompts,
        format_func=lambda x: f"💬 {x['name']}"
    )
    
    if not selected_prompt:
        return
    
    # Prompt info
    with st.expander("Prompt Info", expanded=True):
        st.markdown(f"**{selected_prompt['name']}**")
        st.caption(selected_prompt.get("description", "No description"))
        
        args = selected_prompt.get("arguments", [])
        if args:
            st.markdown("**Arguments:**")
            for arg in args:
                req = " (required)" if arg.get("required") else ""
                desc = arg.get("description", "")
                st.caption(f"- `{arg['name']}`{req}: {desc}")
        else:
            st.caption("No arguments required")
    
    # Argument form
    st.subheader("Arguments")
    
    args = selected_prompt.get("arguments", [])
    arg_values = {}
    missing = []  # Initialize to avoid reference error
    
    if args:
        for arg in args:
            arg_name = arg['name']
            arg_desc = arg.get("description", "")
            is_required = arg.get("required", False)
            
            placeholder = f"{'Required' if is_required else 'Optional'}"
            arg_values[arg_name] = st.text_input(
                f"{arg_name}{' *' if is_required else ''}",
                placeholder=placeholder,
                help=arg_desc
            )
        
        # Validate required args
        missing = [
            arg['name'] for arg in args
            if arg.get('required') and not arg_values.get(arg['name'])
        ]
        if missing:
            st.warning(f"Missing required arguments: {', '.join(missing)}")
    else:
        st.caption("No arguments required for this prompt")
    
    # Generate button
    st.divider()
    
    if st.button("📝 Generate Messages", type="primary", use_container_width=True):
        # Check required args
        if missing:
            st.error(f"Please provide required arguments: {', '.join(missing)}")
        else:
            with st.spinner("Generating..."):
                try:
                    result = run_async_in_thread(client.get_prompt(
                        selected_prompt['name'],
                        arg_values
                    ))
                    st.session_state.last_prompt_result = result
                except Exception as e:
                    st.error(f"Failed to generate prompt: {str(e)}")
                    st.session_state.last_prompt_result = {"error": str(e)}
    
    # Display result
    if "last_prompt_result" in st.session_state:
        st.divider()
        st.subheader("📬 Generated Messages")
        
        result = st.session_state.last_prompt_result
        
        if "error" in result:
            st.error(f"Failed to generate: {result['error']}")
        else:
            if result.get("description"):
                st.caption(f"Description: {result['description']}")
            
            messages = result.get("messages", [])
            
            for i, msg in enumerate(messages):
                with st.container():
                    role = msg.get("role", "unknown")
                    content = msg.get("content", {})
                    
                    if role == "user":
                        with st.chat_message("user"):
                            st.write(content.get("text", ""))
                    elif role == "assistant":
                        with st.chat_message("assistant"):
                            st.write(content.get("text", ""))
                    else:
                        st.markdown(f"**{role}:**")
                        st.write(content.get("text", ""))
            
            # Copy button
            full_text = "\n\n".join(
                f"{msg['role']}: {msg['content'].get('text', '')}"
                for msg in messages
            )
            st.text_area("Full Text (copy)", value=full_text, height=100)
    
    # Refresh button
    if st.button("🔄 Refresh Prompt List"):
        st.session_state.pop("mcp_prompts", None)
        st.rerun()
