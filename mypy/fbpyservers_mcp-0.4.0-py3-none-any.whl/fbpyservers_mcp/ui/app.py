"""
FBPyServers-MCP Web UI

Streamlit-based admin interface for managing MCP servers and testing.
"""

import streamlit as st
import sys
import os

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fbpyservers_mcp.ui.components.mcp_tester import render_mcp_tester_page


st.set_page_config(
    page_title="FBPyServers-MCP Admin",
    page_icon="🦞",
    layout="wide",
    initial_sidebar_state="expanded"
)


def render_home():
    """Render Home page with dashboard stats."""
    st.header("🏠 Home")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Prompts", "0", help="Total prompts in registry")
    with col2:
        st.metric("Resources", "0", help="Total resources")
    with col3:
        st.metric("Arguments", "0", help="Total arguments")
    with col4:
        st.metric("Messages", "0", help="Total messages")
    
    st.divider()
    
    st.subheader("Quick Actions")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📝 Manage Prompts", use_container_width=True):
            st.session_state.page = "Prompts"
            st.rerun()
    
    with col2:
        if st.button("📦 Manage Resources", use_container_width=True):
            st.session_state.page = "Resources"
            st.rerun()
    
    st.divider()
    
    # Model Registry info
    st.subheader("📊 Model Registry")
    st.info("Model Registry MCP Server is available. Use the MCP Tester to query models and benchmarks.")
    
    if st.button("🔧 Open MCP Tester", type="primary", use_container_width=True):
        st.session_state.page = "MCP Tester"
        st.rerun()


def render_prompts():
    """Render Prompts page."""
    st.header("📝 Prompts")
    st.info("Prompt management coming soon in v0.4.x")


def render_resources():
    """Render Resources page."""
    st.header("📦 Resources")
    st.info("Resource management coming soon in v0.4.x")


def render_documentation():
    """Render Documentation page."""
    st.header("📚 Documentation")
    
    st.markdown("""
    # FBPyServers-MCP
    
    ## Overview
    
    FBPyServers-MCP provides MCP (Model Context Protocol) servers for:
    
    - **Memory**: Semantic memory storage and retrieval via Mem0ai
    - **Web Search**: Multi-category search with SearXNG
    - **Web Scrape**: Web scraping with FireCrawl
    - **Context**: Documentation context management
    - **Model Registry**: Model registry and benchmark queries
    
    ## MCP Tester
    
    The **MCP Tester** (new in v0.4.1) provides an interactive console for testing
    MCP servers directly from the web interface.
    
    ## Getting Started
    
    1. Connect to an MCP server using the MCP Tester
    2. Browse available tools, resources, and prompts
    3. Execute tools with custom parameters
    4. View protocol logs in real-time
    
    ## Version
    
    Current: v0.4.1
    """)


def main():
    """Main entry point for Streamlit app."""
    
    # Initialize page in session state
    if "page" not in st.session_state:
        st.session_state.page = "Home"
    
    # Sidebar navigation
    with st.sidebar:
        st.title("🦞 FBPyServers-MCP")
        st.caption("Admin Interface v0.4.1")
        
        st.divider()
        
        # Navigation menu
        page = st.radio(
            "Navigation",
            options=["Home", "Prompts", "Resources", "🔧 MCP Tester", "Documentation"],
            index=["Home", "Prompts", "Resources", "🔧 MCP Tester", "Documentation"].index(st.session_state.page)
            if st.session_state.page in ["Home", "Prompts", "Resources", "🔧 MCP Tester", "Documentation"]
            else 0
        )
        
        # Update page
        if page != st.session_state.page:
            st.session_state.page = page
            st.rerun()
        
        st.divider()
        
        # Theme
        st.caption("Theme")
        st.info("Use Streamlit's theme switcher (⋮ → Settings)")
    
    # Render selected page
    page_map = {
        "Home": render_home,
        "Prompts": render_prompts,
        "Resources": render_resources,
        "🔧 MCP Tester": render_mcp_tester_page,
        "Documentation": render_documentation,
    }
    
    render_func = page_map.get(st.session_state.page, render_home)
    render_func()


if __name__ == "__main__":
    main()
