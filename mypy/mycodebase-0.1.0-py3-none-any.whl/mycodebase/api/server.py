"""MyCodebase REST API Server using FastAPI"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from pathlib import Path
import logging

from mycodebase.db.postgreSQLClient import PostgreSQLClient
from mycodebase.db.Neo4jClient import Neo4jClient
from mycodebase.indexer.codebase_indexer import CodebaseIndexer
from mycodebase.core.config import config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Validate configuration at startup
_config_warnings = config.validate()
if _config_warnings:
    for warning in _config_warnings:
        logger.warning(f"Config warning: {warning}")

app = FastAPI(
    title="MyCodebase API",
    description="REST API for codebase indexing, search, and analysis",
    version="0.1.0"
)

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
# Pydantic Models
# ============================================================================

class HealthStatus(BaseModel):
    component: str
    status: str
    details: str


class HealthResponse(BaseModel):
    status: str
    components: List[HealthStatus]


class SearchRequest(BaseModel):
    query: str
    mode: str = "hybrid"
    limit: int = 20
    threshold: float = 0.5


class SearchResponse(BaseModel):
    results: List[Dict[str, Any]]
    count: int
    mode: str


class RebuildRequest(BaseModel):
    project_name: Optional[str] = None
    force: bool = False
    verbose: bool = False


def _resolve_project_name(project_name: Optional[str] = None) -> str:
    """Resolve project name from parameter or config root directory."""
    if project_name:
        return project_name
    return config.index_root_path.name


class RebuildResponse(BaseModel):
    status: str
    stats: Dict[str, Any]


class InfoResponse(BaseModel):
    type: str  # "file" or "symbol"
    data: Dict[str, Any]


class WatcherStatus(BaseModel):
    status: str
    watching: bool
    project_name: str
    project_root: str


class WatcherHealthResponse(BaseModel):
    status: str
    watcher_running: bool
    project_name: str
    last_index: Optional[str] = None


# ============================================================================
# Health Endpoints
# ============================================================================

@app.get("/health", response_model=HealthResponse)
async def health():
    """
    Check health of all components (PostgreSQL, Neo4j).
    
    This is the main health check endpoint for container orchestration.
    """
    components = []
    
    # PostgreSQL
    pg = PostgreSQLClient()
    try:
        if pg.health_check():
            components.append(HealthStatus(
                component="PostgreSQL",
                status="✅ OK",
                details=pg.connection_string.split("@")[1] if hasattr(pg, 'connection_string') else "Connected"
            ))
        else:
            components.append(HealthStatus(
                component="PostgreSQL",
                status="❌ FAILED",
                details="Connection refused"
            ))
    except Exception as e:
        components.append(HealthStatus(
            component="PostgreSQL",
            status="❌ ERROR",
            details=str(e)
        ))
    
    # Neo4j
    neo4j = Neo4jClient()
    try:
        if neo4j.health_check():
            components.append(HealthStatus(
                component="Neo4j",
                status="✅ OK",
                details=neo4j.uri if hasattr(neo4j, 'uri') else "Connected"
            ))
        else:
            components.append(HealthStatus(
                component="Neo4j",
                status="❌ FAILED",
                details="Connection refused"
            ))
    except Exception as e:
        components.append(HealthStatus(
            component="Neo4j",
            status="❌ ERROR",
            details=str(e)
        ))
    
    all_healthy = all(c.status == "✅ OK" for c in components)
    
    return HealthResponse(
        status="healthy" if all_healthy else "unhealthy",
        components=components
    )


@app.get("/api/v1/status", response_model=HealthResponse)
async def api_status():
    """
    Check status of database connections (same as CLI status command).
    
    This endpoint mirrors the `mycodebase status` CLI command.
    """
    return await health()


# ============================================================================
# Search Endpoints
# ============================================================================

@app.post("/api/v1/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """
    Search the codebase using different modes.
    
    **Modes:**
    - `fulltext`: Traditional full-text search
    - `semantic`: Semantic search using embeddings (requires Ollama)
    - `hybrid`: Combined fulltext + semantic search (default)
    
    **Example:**
    ```bash
    curl -X POST http://localhost:8080/api/v1/search \\
      -H "Content-Type: application/json" \\
      -d '{"query": "authentication", "mode": "hybrid", "limit": 10}'
    ```
    """
    pg_client = PostgreSQLClient()
    
    # Validate mode
    valid_modes = ['fulltext', 'semantic', 'hybrid']
    if request.mode not in valid_modes:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid mode: {request.mode}. Valid modes: {', '.join(valid_modes)}"
        )
    
    try:
        if request.mode == 'fulltext':
            results = pg_client.search_fulltext(request.query, limit=request.limit)
        
        elif request.mode == 'semantic':
            # Need embedding first
            from mycodebase.embeddings.ollama_client import OllamaClient
            embeddings = OllamaClient()
            
            if not embeddings.health_check():
                raise HTTPException(
                    status_code=503,
                    detail="Ollama not available for semantic search"
                )
            
            embedding = embeddings.generate_embedding(request.query)
            results = pg_client.search_semantic(embedding, limit=request.limit, threshold=request.threshold)
        
        elif request.mode == 'hybrid':
            from mycodebase.embeddings.ollama_client import OllamaClient
            embeddings = OllamaClient()
            
            if not embeddings.health_check():
                # Fallback to fulltext if Ollama unavailable
                logger.warning("Ollama unavailable, falling back to fulltext search")
                results = pg_client.search_fulltext(request.query, limit=request.limit)
            else:
                embedding = embeddings.generate_embedding(request.query)
                results = pg_client.search_hybrid(request.query, embedding, limit=request.limit)
        
        return SearchResponse(results=results, count=len(results), mode=request.mode)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Info Endpoints
# ============================================================================

@app.get("/api/v1/info/{target:path}", response_model=InfoResponse)
async def info(target: str):
    """
    Get information about a file or symbol.
    
    **TARGET can be:**
    - A file path (e.g., `mycodebase/cli/main.py`)
    - A function/symbol name (e.g., `search`)
    
    **Examples:**
    ```bash
    # File info
    curl http://localhost:8080/api/v1/info/mycodebase/cli/main.py
    
    # Symbol info
    curl http://localhost:8080/api/v1/info/search
    ```
    """
    pg_client = PostgreSQLClient()
    path = Path(target)
    
    # Check if it's a file path or a symbol name
    is_file = path.exists() or '/' in target or target.endswith('.py')
    
    if is_file:
        # File info from DB
        sql = """
        SELECT f.path, f.language, f.size_bytes, f.line_count, f.created_at,
               COUNT(s.id) as symbol_count
        FROM files f
        LEFT JOIN symbols s ON f.id = s.file_id
        WHERE f.path LIKE %s
        GROUP BY f.id
        LIMIT 1
        """
        
        with pg_client.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (f"%{target}%",))
                result = cur.fetchone()
                
                if not result:
                    raise HTTPException(status_code=404, detail=f"File not found: {target}")
                
                columns = [desc[0] for desc in cur.description]
                file_info = dict(zip(columns, result))
                
                # Get symbols for this file
                cur.execute("""
                SELECT s.id, s.name, s.type, s.signature, s.start_line, s.end_line
                FROM symbols s
                WHERE s.file_id = %s
                ORDER BY s.start_line
                """, (file_info['id'],))
                
                symbols = []
                for row in cur.fetchall():
                    symbols.append({
                        'id': row[0],
                        'name': row[1],
                        'type': row[2],
                        'signature': row[3],
                        'start_line': row[4],
                        'end_line': row[5]
                    })
                
                file_info['symbols'] = symbols
                
                return InfoResponse(type="file", data=file_info)
    
    else:
        # Symbol info
        sql = """
        SELECT s.id, s.name, s.type, s.signature, s.docstring,
               s.start_line, s.end_line, f.path
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE s.name = %s OR s.name ILIKE %s
        LIMIT 5
        """
        
        with pg_client.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (target, f"%{target}%"))
                results = cur.fetchall()
                
                if not results:
                    raise HTTPException(status_code=404, detail=f"Symbol not found: {target}")
                
                columns = [desc[0] for desc in cur.description]
                symbols = [dict(zip(columns, row)) for row in results]
                
                return InfoResponse(type="symbol", data={"symbols": symbols})


# ============================================================================
# Rebuild/Index Endpoints
# ============================================================================

@app.post("/api/v1/rebuild", response_model=RebuildResponse)
async def rebuild(request: RebuildRequest):
    """
    Trigger manual reindex of a project.
    
    **Parameters:**
    - `project_name`: Optional. Index specific project only.
    - `force`: Force rebuild even if files unchanged.
    - `verbose`: Enable verbose logging.
    
    **Example:**
    ```bash
    curl -X POST http://localhost:8080/api/v1/rebuild \\
      -H "Content-Type: application/json" \\
      -d '{"project_name": "MyProject", "force": true}'
    ```
    """
    if request.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    project_name = request.project_name
    project_root = config.index_root_path

    # When project_name is not provided and index_root has multiple subdirectories,
    # rebuild each subdirectory as its own project.
    if not project_name:
        subdirs = [
            d for d in project_root.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        ]
        if len(subdirs) > 1:
            total_stats = {
                "projects": 0,
                "files_scanned": 0,
                "files_indexed": 0,
                "files_skipped_unchanged": 0,
                "files_ignored": 0,
                "symbols_extracted": 0,
                "dependencies_extracted": 0,
                "errors": 0,
            }
            for subdir in subdirs:
                sub_name = subdir.name
                logger.info(f"Rebuilding project: {sub_name} (root: {subdir})")
                try:
                    indexer = CodebaseIndexer(
                        project_name=sub_name,
                        project_root=str(subdir),
                    )
                    stats = indexer.index(force=request.force, show_progress=False)
                    total_stats["projects"] += 1
                    for key in (
                        "files_scanned", "files_indexed", "files_skipped_unchanged",
                        "files_ignored", "symbols_extracted", "dependencies_extracted", "errors",
                    ):
                        total_stats[key] += stats.get(key, 0)
                except Exception as e:
                    logger.error(f"Failed to rebuild project {sub_name}: {e}")
                    total_stats["errors"] += 1

            return RebuildResponse(status="success", stats=total_stats)

    # Single project rebuild (explicit or single subdir fallback)
    project_name = _resolve_project_name(project_name)
    project_root = config.index_root_path / project_name if request.project_name else config.index_root_path

    if not project_root.exists():
        raise HTTPException(status_code=400, detail=f"Project root not found: {project_root}")

    try:
        logger.info(f"Starting index for project: {project_name}")

        indexer = CodebaseIndexer(
            project_name=project_name,
            project_root=str(project_root)
        )

        stats = indexer.index(force=request.force, show_progress=False)

        logger.info(f"Indexing complete: {stats['files_indexed']} files indexed")

        return RebuildResponse(status="success", stats=stats)

    except Exception as e:
        logger.exception(f"Indexing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Watcher Endpoints
# ============================================================================

@app.get("/api/v1/watcher/status", response_model=WatcherStatus)
async def watcher_status():
    """
    Get current watcher status.
    
    Returns whether the watcher is running and what it's watching.
    """
    # This would need integration with the actual watcher process
    # For now, return basic info
    return WatcherStatus(
        status="running",
        watching=True,
        project_name=_resolve_project_name(),
        project_root=str(config.index_root_path)
    )


@app.get("/api/v1/watcher/health", response_model=WatcherHealthResponse)
async def watcher_health():
    """
    Health check endpoint for the watcher service.
    
    This endpoint is used by container orchestration to verify
    the watcher service is operational.
    """
    # Basic health check - API is running, so watcher endpoint is accessible
    # In production, this would check actual watcher process status
    return WatcherHealthResponse(
        status="healthy",
        watcher_running=True,
        project_name=_resolve_project_name(),
        last_index=None  # Would be populated with actual last index timestamp
    )


# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    # Run with: python -m mycodebase.api.server
    uvicorn.run(app, host="0.0.0.0", port=8080)
