"""Main codebase indexer with hash-based change detection"""

import hashlib
import logging
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional, Set
from datetime import datetime
from dataclasses import dataclass

from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from .ignore_parser import IgnoreParser
from .git_blame import GitBlameExtractor
from mycodebase.parser.treesitter_parser import TreeSitterParser, Symbol, Dependency
from mycodebase.db.postgreSQLClient import PostgreSQLClient
from mycodebase.db.Neo4jClient import Neo4jClient
from mycodebase.embeddings.ollama_client import OllamaClient
from mycodebase.core.config import config


logger = logging.getLogger(__name__)


@dataclass
class FileIndex:
    """Represents indexed file information"""
    path: str
    language: str
    hash_value: str
    size_bytes: int
    line_count: int
    symbols: List[Dict[str, Any]]
    dependencies: List[Dict[str, Any]]
    git_blame: Optional[Dict[str, Any]]
    indexed_at: datetime


class CodebaseIndexer:
    """
    Main codebase indexer with hash-based change detection.
    
    Features:
    - Scans project directories recursively
    - Respects .codebaseignore patterns
    - Detects changes via SHA256 hash comparison
    - Extracts git blame for versioned files
    - Batch inserts into PostgreSQL and Neo4j
    - Incremental reindexing (only changed files)
    """
    
    def __init__(self, project_name: str, project_root: str):
        """
        Initialize the codebase indexer.
        
        Args:
            project_name: Name of the project to index
            project_root: Root directory of the project
        """
        self.project_name = project_name
        self.project_root = Path(project_root)
        
        # Initialize components
        self.ignore_parser = IgnoreParser(
            str(self.project_root / '.codebaseignore')
        )
        self.git_blame_extractor = GitBlameExtractor(str(self.project_root))
        self.parser = TreeSitterParser()
        
        # Database clients
        self.pg_client = PostgreSQLClient()
        self.neo4j_client = Neo4jClient()
        
        # Embeddings client
        self.embeddings_client = OllamaClient()
        
        # Statistics
        self.stats = {
            'files_scanned': 0,
            'files_indexed': 0,
            'files_skipped_unchanged': 0,
            'files_ignored': 0,
            'symbols_extracted': 0,
            'dependencies_extracted': 0,
            'embeddings_generated': 0,
            'embeddings_cached': 0,
            'errors': 0
        }
    
    def _compute_file_hash(self, file_path: Path) -> str:
        """
        Compute SHA256 hash of file contents.
        
        Args:
            file_path: Path to file
            
        Returns:
            Hex-encoded SHA256 hash
        """
        hasher = hashlib.sha256()
        content = file_path.read_bytes()
        hasher.update(content)
        return hasher.hexdigest()
    
    def _get_existing_file_hash(self, file_path: str) -> Optional[str]:
        """
        Get the stored hash for a file from PostgreSQL.
        
        Args:
            file_path: Path to file
            
        Returns:
            Stored hash or None if not indexed
        """
        sql = """
        SELECT encode(hash, 'hex') as hash_hex
        FROM files
        WHERE path = %s AND project_name = %s
        """
        
        try:
            with self.pg_client.get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, (file_path, self.project_name))
                    result = cur.fetchone()
                    return result[0] if result else None
        except Exception as e:
            logger.debug(f"Error checking existing hash: {e}")
            return None
    
    def _should_index_file(self, file_path: Path, force: bool = False) -> bool:
        """
        Check if a file should be indexed (not ignored, has changes).
        
        Args:
            file_path: Path to file
            force: If True, skip hash check and always index
            
        Returns:
            True if file should be indexed
        """
        rel_path = str(file_path.relative_to(self.project_root))
        
        # Check ignore patterns
        if self.ignore_parser.should_ignore(rel_path):
            logger.debug(f"Ignoring file (pattern match): {rel_path}")
            self.stats['files_ignored'] += 1
            return False
        
        # Force mode: always index
        if force:
            logger.debug(f"Force mode: indexing {rel_path}")
            return True
        
        # Check if file has changed
        current_hash = self._compute_file_hash(file_path)
        existing_hash = self._get_existing_file_hash(rel_path)
        
        if existing_hash and current_hash == existing_hash:
            logger.debug(f"Skipping unchanged file: {rel_path}")
            self.stats['files_skipped_unchanged'] += 1
            return False
        
        return True
    
    def _scan_files(self, force: bool = False) -> List[Path]:
        """
        Scan project directory for files to index.
        
        Args:
            force: If True, skip hash check and index all files
            
        Returns:
            List of file paths to index
        """
        files_to_index = []
        
        logger.info(f"Scanning project: {self.project_root}")
        
        for root, dirs, files in self._walk_directory():
            # Filter directories in-place to prevent descending
            dirs[:] = [
                d for d in dirs
                if not self.ignore_parser.should_ignore(
                    str(Path(root).relative_to(self.project_root) / d),
                    is_directory=True
                )
            ]
            
            for file in files:
                file_path = Path(root) / file
                
                # Skip non-files
                if not file_path.is_file():
                    continue
                
                self.stats['files_scanned'] += 1
                
                if self._should_index_file(file_path, force=force):
                    files_to_index.append(file_path)
                    self.stats['files_indexed'] += 1
        
        return files_to_index
    
    def _walk_directory(self):
        """
        Walk directory tree, respecting ignore patterns.
        
        Yields:
            Tuples of (root, dirs, files) like os.walk
        """
        for root, dirs, files in self.project_root.walk(top_down=True):
            yield root, dirs, files
    
    def _index_file(self, file_path: Path) -> Optional[FileIndex]:
        """
        Index a single file.
        
        Args:
            file_path: Path to file
            
        Returns:
            FileIndex object or None on error
        """
        rel_path = str(file_path.relative_to(self.project_root))
        logger.info(f"Indexing: {rel_path}")
        
        try:
            # Read file content
            content = file_path.read_bytes()
            
            # Compute hash
            hash_value = hashlib.sha256(content).hexdigest()
            
            # Detect language
            language = self.parser.detect_language(str(file_path)) or 'unknown'
            
            # Parse symbols and dependencies
            parse_result = self.parser.parse_file(str(file_path))
            symbols = parse_result.get('symbols', []) if parse_result else []
            dependencies = parse_result.get('dependencies', []) if parse_result else []
            
            # Extract git blame
            git_blame = self.git_blame_extractor.extract_blame(str(file_path))
            
            # Create FileIndex
            file_index = FileIndex(
                path=rel_path,
                language=language,
                hash_value=hash_value,
                size_bytes=len(content),
                line_count=content.count(b'\n') + 1,
                symbols=[self._symbol_to_dict(s) for s in symbols],
                dependencies=[self._dependency_to_dict(d) for d in dependencies],
                git_blame=git_blame,
                indexed_at=datetime.now()
            )
            
            # Update stats
            self.stats['symbols_extracted'] += len(symbols)
            self.stats['dependencies_extracted'] += len(dependencies)
            
            return file_index
            
        except Exception as e:
            logger.error(f"Error indexing {rel_path}: {e}")
            self.stats['errors'] += 1
            return None
    
    def _symbol_to_dict(self, symbol: Symbol) -> Dict[str, Any]:
        """
        Convert Symbol object to dict.
        
        Args:
            symbol: Symbol dataclass instance
            
        Returns:
            Dict with symbol information
        """
        return {
            'name': symbol.name,
            'type': symbol.type.value if hasattr(symbol.type, 'value') else str(symbol.type),
            'file_path': symbol.file_path,
            'start_line': symbol.start_line,
            'end_line': symbol.end_line,
            'signature': symbol.signature,
            'docstring': symbol.docstring,
        }
    
    def _dependency_to_dict(self, dep: Dependency) -> Dict[str, Any]:
        """
        Convert Dependency object to dict.
        
        Args:
            dep: Dependency dataclass instance
            
        Returns:
            Dict with dependency information
        """
        return {
            'target_module': dep.target_module,
            'target_symbol': dep.target_symbol,
            'import_type': dep.import_type,
            'line_number': dep.line_number,
        }
    
    def _insert_to_postgresql(self, file_index: FileIndex) -> str:
        """
        Insert file index into PostgreSQL with embeddings.
        
        Args:
            file_index: FileIndex object
            
        Returns:
            File ID in database
        """
        import json
        
        # Prepare metadata (serialize to JSON string for psycopg2)
        metadata = {
            'size_bytes': file_index.size_bytes,
            'line_count': file_index.line_count,
        }
        if file_index.git_blame:
            metadata['git_blame'] = file_index.git_blame
        
        # Read actual file content for proper hash
        file_path_full = self.project_root / file_index.path
        try:
            content = file_path_full.read_bytes()
        except Exception as e:
            logger.error(f"Failed to read file {file_path_full}: {e}")
            content = b''
        
        file_id = self.pg_client.insert_file(
            path=file_index.path,
            project_name=self.project_name,
            language=file_index.language,
            content=content,
            metadata=metadata
        )
        
        # Collect symbols for batch embedding
        symbols_to_embed = []
        symbol_ids = []
        
        # Insert symbols and collect for embedding
        for symbol in file_index.symbols:
            symbol_id = self.pg_client.insert_symbol(
                file_id=file_id,
                name=symbol['name'],
                symbol_type=symbol['type'],
                signature=symbol['signature'],
                docstring=symbol.get('docstring'),
                start_line=symbol['start_line'],
                end_line=symbol['end_line'],
            )
            symbol_ids.append(symbol_id)
            symbols_to_embed.append(symbol)
        
        # Generate embeddings in batch
        if symbols_to_embed:
            logger.info(f"Generating embeddings for {len(symbols_to_embed)} symbols")

            texts_to_embed = []
            for symbol in symbols_to_embed:
                # Build rich text for embedding
                text_parts = [symbol['name']]
                if symbol.get('signature'):
                    text_parts.append(symbol['signature'])
                if symbol.get('docstring'):
                    text_parts.append(symbol['docstring'])
                texts_to_embed.append("\n".join(text_parts))

            try:
                # Generate batch embeddings
                embeddings = self.embeddings_client.generate_batch(texts_to_embed, use_cache=True)

                # Update symbols with embeddings
                for symbol_id, embedding in zip(symbol_ids, embeddings):
                    self.pg_client.update_symbol_embedding(symbol_id, embedding)
                    self.stats['embeddings_generated'] += 1

                # Check cache stats
                cache_stats = self.embeddings_client.cache_stats()
                logger.debug(f"Embedding cache: {cache_stats['num_embeddings']} embeddings, {cache_stats['total_size_mb']} MB")
            except Exception as e:
                logger.error(f"Failed to generate embeddings for batch: {e}")
                # Symbols remain indexed with embedding = NULL; backfill will retry later
        
        # Insert dependencies
        for dep in file_index.dependencies:
            self.pg_client.insert_dependency(
                source_file_id=file_id,
                target_module=dep['target_module'],
                target_symbol=dep.get('target_symbol'),
                import_type=dep.get('import_type'),
                line_number=dep.get('line_number'),
            )
        
        return file_id
    
    def _insert_to_neo4j(self, file_index: FileIndex):
        """
        Insert file index into Neo4j graph database.
        
        Args:
            file_index: FileIndex object
        """
        # Create project node (if not exists)
        self.neo4j_client.create_project(
            name=self.project_name,
            root_path=str(self.project_root)
        )
        
        # Create file node
        self.neo4j_client.create_file_node(
            path=file_index.path,
            language=file_index.language,
            project_name=self.project_name,
            hash_value=file_index.hash_value
        )
        
        # Create function/class nodes
        for symbol in file_index.symbols:
            if symbol['type'] == 'function':
                self.neo4j_client.create_function_node(
                    name=symbol['name'],
                    file_path=file_index.path,
                    signature=symbol.get('signature'),
                    start_line=symbol.get('start_line'),
                    end_line=symbol.get('end_line'),
                )
            elif symbol['type'] == 'class':
                self.neo4j_client.create_class_node(
                    name=symbol['name'],
                    file_path=file_index.path,
                )
        
        # Create import relationships
        for dep in file_index.dependencies:
            self.neo4j_client.create_import_relationship(
                source_file_path=file_index.path,
                target_module=dep['target_module'],
                target_symbol=dep.get('target_symbol'),
            )
    
    def _should_show_progress(self) -> bool:
        """
        Auto-detect if progress bar should be shown.
        
        Returns:
            True if progress should be shown, False otherwise
        """
        # Check if running in watcher mode (background)
        import os
        cmdline = ' '.join(os.sys.argv) if hasattr(os, 'sys') else ''
        if 'watch' in cmdline:
            return False
        
        # Check if first run (no files indexed yet)
        try:
            sql = """
            SELECT COUNT(*) FROM files WHERE project_name = %s
            """
            with self.pg_client.get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(sql, (self.project_name,))
                    result = cur.fetchone()
                    file_count = result[0] if result else 0
                    # First run: show progress
                    if file_count == 0:
                        return True
        except Exception:
            pass
        
        # Default: don't show progress (watcher mode)
        return False
    
    def _index_with_progress(self, force: bool = False, force_progress: bool = False) -> Dict[str, Any]:
        """
        Run indexing with progress bar.
        
        Uses Rich progress bar if TTY available, otherwise text-based progress.
        
        Args:
            force: Force reindex all files
            force_progress: If True, show progress even without TTY (uses text mode)
            
        Returns:
            Statistics dict
        """
        logger.info(f"Starting index with progress bar for project: {self.project_name}")
        
        # Initialize database schema
        logger.info("Initializing database schema...")
        try:
            self.pg_client.initialize_schema()
            self.neo4j_client.initialize_constraints()
            logger.info("Database schema initialized")
        except Exception as e:
            logger.warning(f"Schema initialization warning: {e}")
        
        # Scan for files first to get total count
        files_to_index = self._scan_files(force=force)
        logger.info(f"Found {len(files_to_index)} files to index")
        
        # Reset stats after scan (scan increments stats)
        self.stats['files_indexed'] = 0
        
        # Check if TTY is available
        is_tty = sys.stdout.isatty()
        
        # Use Rich for TTY, text-based for non-TTY
        if is_tty:
            return self._index_with_rich_progress(files_to_index, force)
        else:
            return self._index_with_text_progress(files_to_index, force)
            index_task = progress.add_task(
                f"Indexing {self.project_name}",
                total=len(files_to_index)
            )
            
            batch_size = 50
            file_indices = []
            
            for i, file_path in enumerate(files_to_index):
                file_index = self._index_file(file_path)
                if file_index:
                    file_indices.append(file_index)
                    self.stats['files_indexed'] += 1
                
                # Update progress
                progress.update(index_task, advance=1)
                
                # Batch insert
                if len(file_indices) >= batch_size:
                    self._batch_insert(file_indices)
                    file_indices = []
            
            # Insert remaining files
            if file_indices:
                self._batch_insert(file_indices)
        
        logger.info(f"Indexing complete. Stats: {self.stats}")
        return self.stats.copy()
    
    def _index_with_logging(self, force: bool = False) -> Dict[str, Any]:
        """
        Run indexing with traditional logging (no progress bar).
        
        Args:
            force: Force reindex all files
            
        Returns:
            Statistics dict
        """
        logger.info(f"Starting index for project: {self.project_name}")
        logger.info(f"Project root: {self.project_root}")
        
        # Initialize database schema
        logger.info("Initializing database schema...")
        try:
            self.pg_client.initialize_schema()
            self.neo4j_client.initialize_constraints()
            logger.info("Database schema initialized")
        except Exception as e:
            logger.warning(f"Schema initialization warning: {e}")
        
        if force:
            logger.info("Force mode: reindexing all files (ignoring hash check)")
        
        # Scan for files
        files_to_index = self._scan_files(force=force)
        logger.info(f"Found {len(files_to_index)} files to index")
        
        # Index files with batch inserts
        batch_size = 50
        file_indices = []
        
        for i, file_path in enumerate(files_to_index):
            file_index = self._index_file(file_path)
            if file_index:
                file_indices.append(file_index)
            
            # Batch insert
            if len(file_indices) >= batch_size:
                self._batch_insert(file_indices)
                file_indices = []
        
        # Insert remaining files
        if file_indices:
            self._batch_insert(file_indices)
        
        logger.info(f"Indexing complete. Stats: {self.stats}")
        return self.stats.copy()
    
    def index(self, force: bool = False, show_progress: Optional[bool] = None) -> Dict[str, Any]:
        """
        Run the indexing process.
        
        Args:
            force: Force reindex all files (ignore hash check)
            show_progress: If True, show progress bar. If False, use logging.
                          If None, auto-detect based on context.
            
        Returns:
            Statistics dict
        """
        # Auto-detect progress mode if not specified
        if show_progress is None:
            show_progress = self._should_show_progress()
        
        # Check TTY availability
        is_tty = sys.stdout.isatty()
        
        # First run: ALWAYS show progress (even without TTY)
        # Use force_progress=True to bypass TTY check
        if show_progress:
            return self._index_with_progress(force, force_progress=True)
        elif is_tty:
            # TTY available but not first run: show progress
            return self._index_with_progress(force, force_progress=False)
        else:
            # No TTY and not first run: use logging
            return self._index_with_logging(force)
    
    def _index_with_text_progress(self, files_to_index: List[Path], force: bool = False) -> Dict[str, Any]:
        """
        Run indexing with text-based progress (for non-TTY environments like Docker logs).
        
        Shows progress at 0%, 25%, 50%, 75%, 100% milestones.
        
        Args:
            files_to_index: List of files to index
            force: Force reindex all files
            
        Returns:
            Statistics dict
        """
        total = len(files_to_index)
        milestones = [0, total // 4, total // 2, (3 * total) // 4, total]
        current_milestone = 0
        
        logger.info("=" * 60)
        logger.info(f"INDEXING {self.project_name} ({total} files)")
        logger.info("=" * 60)
        
        batch_size = 50
        file_indices = []
        
        for i, file_path in enumerate(files_to_index):
            file_index = self._index_file(file_path)
            if file_index:
                file_indices.append(file_index)
            
            # Check milestone
            if current_milestone < len(milestones) and i >= milestones[current_milestone]:
                pct = (current_milestone * 25) if current_milestone < 4 else 100
                logger.info(f"Progress: [{pct:3d}%] {i + 1}/{total} files")
                current_milestone += 1
            
            # Batch insert
            if len(file_indices) >= batch_size:
                self._batch_insert(file_indices)
                file_indices = []
        
        # Insert remaining files
        if file_indices:
            self._batch_insert(file_indices)
        
        logger.info("=" * 60)
        logger.info(f"INDEXING COMPLETE: {self.stats['files_indexed']}/{total} files indexed")
        logger.info(f"  - Symbols extracted: {self.stats['symbols_extracted']}")
        logger.info(f"  - Embeddings generated: {self.stats['embeddings_generated']}")
        logger.info(f"  - Errors: {self.stats['errors']}")
        logger.info("=" * 60)
        
        return self.stats.copy()
    
    def _index_with_rich_progress(self, files_to_index: List[Path], force: bool = False) -> Dict[str, Any]:
        """
        Run indexing with Rich progress bar (for TTY environments).
        
        Args:
            files_to_index: List of files to index
            force: Force reindex all files
            
        Returns:
            Statistics dict
        """
        from rich.progress import (
            Progress, SpinnerColumn, BarColumn, TextColumn,
            TextColumn, TimeElapsedColumn
        )
        
        total = len(files_to_index)
        logger.info(f"Found {total} files to index")
        
        # Reset stats after scan
        self.stats['files_indexed'] = 0
        
        batch_size = 50
        file_indices = []
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("•"),
            TextColumn("[dim]{task.completed}/{task.total}"),
            TimeElapsedColumn(),
        ) as progress:
            index_task = progress.add_task(
                f"Indexing {self.project_name}",
                total=total
            )
            
            for i, file_path in enumerate(files_to_index):
                file_index = self._index_file(file_path)
                if file_index:
                    file_indices.append(file_index)
                    progress.update(index_task, advance=1)
                
                # Batch insert
                if len(file_indices) >= batch_size:
                    self._batch_insert(file_indices)
                    file_indices = []
            
            # Insert remaining files
            if file_indices:
                self._batch_insert(file_indices)
        
        logger.info(f"Indexing complete. Stats: {self.stats}")
        return self.stats.copy()
    
    def _batch_insert(self, file_indices: List[FileIndex]):
        """
        Insert a batch of file indices to databases.
        
        Args:
            file_indices: List of FileIndex objects
        """
        logger.info(f"Batch inserting {len(file_indices)} files")
        
        for file_index in file_indices:
            try:
                self._insert_to_postgresql(file_index)
                self._insert_to_neo4j(file_index)
            except Exception as e:
                logger.error(f"Error inserting {file_index.path}: {e}")
                self.stats['errors'] += 1

    def backfill_embeddings(self, batch_size: int = 100, max_batches: Optional[int] = None) -> Dict[str, Any]:
        """
        Backfill embeddings for symbols that have embedding = NULL.

        Uses get_symbols_for_embedding to find pending symbols,
        generates embeddings in batches, and updates the database.

        Args:
            batch_size: Number of symbols to process per batch
            max_batches: Maximum number of batches to process (None = all)

        Returns:
            Statistics dict with counts of processed/failed symbols
        """
        stats = {
            'symbols_processed': 0,
            'symbols_failed': 0,
            'batches_processed': 0,
            'embeddings_generated': 0,
        }

        logger.info("Starting embedding backfill for pending symbols")

        while True:
            if max_batches is not None and stats['batches_processed'] >= max_batches:
                logger.info(f"Reached max_batches limit ({max_batches})")
                break

            # Get next batch of symbols needing embeddings
            symbols = self.pg_client.get_symbols_for_embedding(batch_size)
            if not symbols:
                logger.info("No more symbols pending embeddings")
                break

            logger.info(f"Backfill batch {stats['batches_processed'] + 1}: {len(symbols)} symbols")

            # Prepare texts for embedding
            texts_to_embed = []
            symbol_ids = []
            for symbol in symbols:
                text_parts = [symbol['name']]
                if symbol.get('signature'):
                    text_parts.append(symbol['signature'])
                if symbol.get('docstring'):
                    text_parts.append(symbol['docstring'])
                texts_to_embed.append("\n".join(text_parts))
                symbol_ids.append(symbol['id'])

            try:
                # Generate embeddings in batch
                embeddings = self.embeddings_client.generate_batch(texts_to_embed, use_cache=True)

                # Update symbols with embeddings
                for symbol_id, embedding in zip(symbol_ids, embeddings):
                    self.pg_client.update_symbol_embedding(symbol_id, embedding)
                    stats['embeddings_generated'] += 1

                stats['symbols_processed'] += len(symbols)
                logger.info(f"Backfill batch complete: {len(symbols)} symbols updated")

            except Exception as e:
                logger.error(f"Failed to generate embeddings for backfill batch: {e}")
                stats['symbols_failed'] += len(symbols)

            stats['batches_processed'] += 1

        logger.info(
            f"Backfill complete: {stats['symbols_processed']} processed, "
            f"{stats['symbols_failed']} failed, {stats['batches_processed']} batches"
        )
        return stats
