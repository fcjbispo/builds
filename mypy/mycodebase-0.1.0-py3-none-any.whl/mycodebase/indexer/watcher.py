"""File watcher for incremental indexing using watchdog"""

import logging
import time
from pathlib import Path
from typing import Optional, Callable, List
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import (
    FileSystemEventHandler,
    FileModifiedEvent,
    FileCreatedEvent,
    FileDeletedEvent,
    FileMovedEvent,
    DirModifiedEvent,
    DirCreatedEvent,
    DirDeletedEvent,
    DirMovedEvent,
)

from .ignore_parser import IgnoreParser
from mycodebase.core.config import config


logger = logging.getLogger(__name__)


class FileChangeEvent:
    """Represents a file system change event"""
    
    def __init__(self, event_type: str, file_path: str, timestamp: datetime):
        self.event_type = event_type  # 'created', 'modified', 'deleted', 'moved'
        self.file_path = file_path
        self.timestamp = timestamp
    
    def __repr__(self):
        return f"FileChangeEvent({self.event_type}, {self.file_path})"


class CodebaseEventHandler(FileSystemEventHandler):
    """
    Event handler for codebase file changes.
    
    Filters events based on .codebaseignore and triggers
    incremental reindexing.
    """
    
    def __init__(
        self,
        project_root: Path,
        ignore_parser: IgnoreParser,
        on_change_callback: Optional[Callable[[List[FileChangeEvent]], None]] = None
    ):
        """
        Initialize the event handler.
        
        Args:
            project_root: Root directory of the project
            ignore_parser: IgnoreParser instance for filtering
            on_change_callback: Callback to invoke when changes detected
        """
        super().__init__()
        self.project_root = project_root
        self.ignore_parser = ignore_parser
        self.on_change_callback = on_change_callback
        self.pending_changes: List[FileChangeEvent] = []
        self._debounce_timer: Optional[float] = None
    
    def _should_process_event(self, event_path: str, is_directory: bool = False) -> bool:
        """
        Check if an event should be processed (not ignored).
        
        Args:
            event_path: Absolute path from the event
            is_directory: Whether the path is a directory
            
        Returns:
            True if event should be processed
        """
        try:
            # Get relative path
            rel_path = str(Path(event_path).relative_to(self.project_root))
            
            # Check ignore patterns
            if self.ignore_parser.should_ignore(rel_path, is_directory=is_directory):
                logger.debug(f"Ignoring event (pattern match): {rel_path}")
                return False
            
            return True
            
        except ValueError:
            # Path is outside project root
            logger.debug(f"Ignoring event (outside project root): {event_path}")
            return False
    
    def _handle_event(self, event_type: str, src_path: str, is_directory: bool = False):
        """
        Handle a file system event.
        
        Args:
            event_type: Type of event ('created', 'modified', 'deleted', 'moved')
            src_path: Source path of the event
            is_directory: Whether the path is a directory
        """
        if not self._should_process_event(src_path, is_directory):
            return
        
        change_event = FileChangeEvent(
            event_type=event_type,
            file_path=src_path,
            timestamp=datetime.now()
        )
        
        self.pending_changes.append(change_event)
        logger.info(f"Detected change: {event_type} - {src_path}")
        
        # Trigger callback with debounce
        self._trigger_callback()
    
    def _trigger_callback(self):
        """Trigger the callback with pending changes (with debounce)"""
        if self.on_change_callback and self.pending_changes:
            # Debounce: wait 500ms for more changes
            changes_copy = self.pending_changes.copy()
            self.pending_changes.clear()
            self.on_change_callback(changes_copy)
    
    def on_modified(self, event):
        """Handle file modification events"""
        if isinstance(event, FileModifiedEvent):
            self._handle_event('modified', event.src_path, is_directory=False)
    
    def on_created(self, event):
        """Handle file creation events"""
        if isinstance(event, FileCreatedEvent):
            self._handle_event('created', event.src_path, is_directory=False)
        elif isinstance(event, DirCreatedEvent):
            self._handle_event('created', event.src_path, is_directory=True)
    
    def on_deleted(self, event):
        """Handle file deletion events"""
        if isinstance(event, FileDeletedEvent):
            self._handle_event('deleted', event.src_path, is_directory=False)
        elif isinstance(event, DirDeletedEvent):
            self._handle_event('deleted', event.src_path, is_directory=True)
    
    def on_moved(self, event):
        """Handle file move events"""
        if isinstance(event, FileMovedEvent):
            # Treat as delete + create
            if self._should_process_event(event.src_path, False):
                self._handle_event('deleted', event.src_path, is_directory=False)
            if self._should_process_event(event.dest_path, False):
                self._handle_event('created', event.dest_path, is_directory=False)
        elif isinstance(event, DirMovedEvent):
            if self._should_process_event(event.src_path, True):
                self._handle_event('deleted', event.src_path, is_directory=True)
            if self._should_process_event(event.dest_path, True):
                self._handle_event('created', event.dest_path, is_directory=True)


class CodebaseWatcher:
    """
    File watcher for codebase with incremental indexing.
    
    Uses watchdog to monitor file system changes and triggers
    reindexing only for changed files.
    """
    
    def __init__(
        self,
        project_name: str,
        project_root: str,
        indexer_class=None,
        show_progress: bool = False
    ):
        """
        Initialize the codebase watcher.
        
        Args:
            project_name: Name of the project
            project_root: Root directory of the project
            indexer_class: Optional custom indexer class
            show_progress: Whether to show progress bars (default False for background)
        """
        self.project_name = project_name
        self.project_root = Path(project_root)
        self.show_progress = show_progress
        
        # Initialize components
        self.ignore_parser = IgnoreParser(
            str(self.project_root / '.codebaseignore')
        )
        
        # Import indexer here to avoid circular imports
        if indexer_class is None:
            from .codebase_indexer import CodebaseIndexer
            self.indexer_class = CodebaseIndexer
        else:
            self.indexer_class = indexer_class
        
        # Create indexer instance
        self.indexer = self.indexer_class(
            project_name=project_name,
            project_root=str(self.project_root)
        )
        
        # Event handler
        self.event_handler = CodebaseEventHandler(
            project_root=self.project_root,
            ignore_parser=self.ignore_parser,
            on_change_callback=self._on_changes_detected
        )
        
        # Observer
        self.observer: Optional[Observer] = None
        self._running = False
        
        # First run auto-indexing
        self._check_first_run()
    
    def _check_first_run(self):
        """
        Check if this is a first run (empty DB) and trigger auto-indexing.
        
        Checks FBNET_MYCODEBASE_INDEX_ON_FIRST_RUN env var and if DB is empty.
        If both conditions are true, performs full index on startup.
        """
        from mycodebase.core.config import config
        
        if not config.index_on_first_run:
            logger.debug("First run auto-indexing disabled by config")
            return
        
        try:
            if self.indexer.pg_client.is_empty():
                logger.info("First run detected, performing full index...")
                # First run always uses progress (show_progress=True)
                self.indexer.index(force=False, show_progress=True)
                logger.info("First run indexing complete!")
            else:
                logger.debug("Database already has indexed files, skipping first run index")
        except Exception as e:
            logger.error(f"Error during first run auto-indexing: {e}")
            # Don't fail startup, just log the error
    
    def _on_changes_detected(self, changes: List[FileChangeEvent]):
        """
        Callback when changes are detected.
        
        Args:
            changes: List of FileChangeEvent objects
        """
        logger.info(f"Processing {len(changes)} change(s)...")
        
        # Group changes by type
        created = [c for c in changes if c.event_type == 'created']
        modified = [c for c in changes if c.event_type == 'modified']
        deleted = [c for c in changes if c.event_type == 'deleted']
        
        # Reindex created/modified files
        files_to_index = []
        for change in created + modified:
            try:
                rel_path = Path(change.file_path).relative_to(self.project_root)
                files_to_index.append(rel_path)
            except ValueError:
                continue
        
        # Handle deleted files (remove from index)
        deleted_paths = []
        for change in deleted:
            try:
                rel_path = str(Path(change.file_path).relative_to(self.project_root))
                deleted_paths.append(rel_path)
            except ValueError:
                continue
        
        if files_to_index:
            logger.info(f"Reindexing {len(files_to_index)} file(s)...")
            self._incremental_index(files_to_index)
        
        if deleted_paths:
            logger.info(f"Removing {len(deleted_paths)} deleted file(s) from index...")
            self._remove_from_index(deleted_paths)
    
    def _incremental_index(self, file_paths: List[Path]):
        """
        Perform incremental indexing on specific files.
        
        Args:
            file_paths: List of relative file paths to index
        """
        for rel_path in file_paths:
            file_path = self.project_root / rel_path
            
            if not file_path.exists():
                logger.warning(f"File no longer exists: {rel_path}")
                continue
            
            try:
                logger.info(f"Indexing: {rel_path}")
                file_index = self.indexer._index_file(file_path)
                
                if file_index:
                    self.indexer._insert_to_postgresql(file_index)
                    self.indexer._insert_to_neo4j(file_index)
                    logger.info(f"✅ Indexed: {rel_path}")
                else:
                    logger.error(f"❌ Failed to index: {rel_path}")
                    
            except Exception as e:
                logger.error(f"Error indexing {rel_path}: {e}")
                self.indexer.stats['errors'] += 1
    
    def _remove_from_index(self, file_paths: List[str]):
        """
        Remove deleted files from the index.
        
        Args:
            file_paths: List of relative file paths to remove
        """
        for rel_path in file_paths:
            try:
                logger.info(f"Removing from index: {rel_path}")
                self.indexer.pg_client.delete_file(
                    path=rel_path,
                    project_name=self.project_name
                )
                logger.info(f"✅ Removed: {rel_path}")
            except Exception as e:
                logger.error(f"Error removing {rel_path}: {e}")
    
    def start(self):
        """Start the file watcher"""
        if self._running:
            logger.warning("Watcher is already running")
            return
        
        logger.info(f"Starting file watcher for: {self.project_root}")
        logger.info(f"Watching for changes (Ctrl+C to stop)...")
        
        self.observer = Observer()
        self.observer.schedule(
            self.event_handler,
            str(self.project_root),
            recursive=True
        )
        self.observer.start()
        self._running = True
        
        # Keep running until stopped
        try:
            while self._running:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("\nStopping watcher...")
            self.stop()
    
    def stop(self):
        """Stop the file watcher"""
        self._running = False
        
        if self.observer:
            self.observer.stop()
            self.observer.join()
            logger.info("Watcher stopped")
    
    def is_running(self) -> bool:
        """Check if watcher is running"""
        return self._running
