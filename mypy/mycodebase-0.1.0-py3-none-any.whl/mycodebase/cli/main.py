"""CLI for MyCodebase using Typer

This CLI communicates with the MyCodebase REST API running in the watcher container.
All database operations are proxied through the API.
"""

import typer
import logging
import os
from typing import Optional
from pathlib import Path
import sys
import time
import requests
from urllib3.exceptions import ConnectionError as URLLibConnectionError
from importlib.metadata import version as get_version

from mycodebase.core.config import config

__version__ = get_version("mycodebase")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# API Base URL - configurable via environment variable
API_BASE_URL = os.environ.get("FBNET_MYCODEBASE_API_URL", "http://localhost:3001")

def get_api_url(endpoint: str) -> str:
    """Get full API URL for an endpoint"""
    return f"{API_BASE_URL}{endpoint}"

def check_api_connection() -> bool:
    """Check if API is available"""
    try:
        response = requests.get(get_api_url("/health"), timeout=5)
        return response.status_code == 200
    except (requests.exceptions.ConnectionError, URLLibConnectionError, requests.exceptions.Timeout):
        return False


# Validate configuration at import time
_config_warnings = config.validate()
if _config_warnings:
    for warning in _config_warnings:
        logger.warning(f"Config warning: {warning}")

app = typer.Typer(
    name="mycodebase",
    help="Master Blaster Search Engine - MyCodebase",
)


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-V",
        help="Show version and exit",
        is_eager=True
    )
):
    if version:
        print(f"mycodebase {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command()
def status():
    """Check status of database connections"""
    from rich.console import Console
    from rich.table import Table
    
    console = Console()
    
    # Check API connection first
    if not check_api_connection():
        console.print("[red]❌ Cannot connect to MyCodebase API[/red]")
        console.print(f"[yellow]API URL: {API_BASE_URL}[/yellow]")
        console.print("\n[yellow]Is the watcher running?[/yellow]")
        console.print("  [dim]docker ps | grep mycodebase[/dim]")
        console.print("\n[yellow]Or start it with:[/yellow]")
        console.print("  [dim]docker compose -f fbnet-services-mycodebase-watcher.yaml up -d[/dim]")
        raise typer.Exit(code=1)
    
    try:
        # Call REST API
        response = requests.get(get_api_url("/api/v1/status"), timeout=10)
        response.raise_for_status()
        data = response.json()
        
        table = Table(title="Codebase Index Status")
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Details", style="yellow")
        
        for component in data['components']:
            table.add_row(
                component['component'],
                component['status'],
                component['details']
            )
        
        console.print(table)
        
    except requests.exceptions.ConnectionError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def init():
    """Initialize database schemas"""
    from scripts.init_db import main as init_main
    init_main()


@app.command()
def info(target: str):
    """Get information about a file or function
    
    TARGET can be:
    - A file path (e.g., mycodebase/cli/main.py)
    - A function/symbol name (e.g., search)
    """
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    
    console = Console()
    path = Path(target)
    
    # Check API connection first
    if not check_api_connection():
        console.print("[red]❌ Cannot connect to MyCodebase API[/red]")
        console.print(f"[yellow]API URL: {API_BASE_URL}[/yellow]")
        console.print("\n[yellow]Is the watcher running?[/yellow]")
        console.print("  [dim]docker ps | grep mycodebase[/dim]")
        raise typer.Exit(code=1)
    
    # Check if it's a file path or a symbol name
    is_file = path.exists() or '/' in target or target.endswith('.py')
    
    try:
        # Call REST API
        response = requests.get(get_api_url(f"/api/v1/info/{target}"), timeout=10)
        
        if response.status_code == 404:
            console.print(f"[red]Not found:[/red] {target}")
            raise typer.Exit(code=1)
        
        response.raise_for_status()
        data = response.json()
        
        if data['type'] == 'file':
            file_info = data['data']
            
            console.print(f"\n[bold cyan]📄 File:[/bold cyan] {file_info['path']}")
            console.print(f"[bold cyan]Language:[/bold cyan] {file_info['language']}")
            console.print(f"[bold cyan]Size:[/bold cyan] {file_info['size_bytes']} bytes")
            console.print(f"[bold cyan]Lines:[/bold cyan] {file_info['line_count']}")
            console.print(f"[bold cyan]Symbols:[/bold cyan] {file_info['symbol_count']}")
            console.print(f"[bold cyan]Indexed:[/bold cyan] {file_info['created_at']}")
            
            # Show symbols
            symbols = file_info.get('symbols', [])
            if symbols:
                console.print(f"\n[bold cyan]Symbols ({len(symbols)}):[/bold cyan]")
                for sym in symbols:
                    console.print(f"  • [yellow]{sym['type']}[/yellow] [white]{sym['name']}[/white] [dim](lines {sym['start_line']}-{sym['end_line']})[/dim]")
        
        elif data['type'] == 'symbol':
            symbols = data['data']['symbols']
            
            for symbol in symbols:
                emoji = '⚡' if symbol['type'] == 'function' else '📦'
                console.print(f"\n[bold yellow]{emoji} {symbol['type'].upper()}:[/bold yellow] {symbol['name']}")
                console.print(f"  [green]File:[/green] {symbol['path']}")
                console.print(f"  [green]Lines:[/green] {symbol['start_line']}-{symbol['end_line']}")
                
                if symbol.get('signature'):
                    console.print(f"\n  [dim]{symbol['signature']}[/dim]")
                
                if symbol.get('docstring'):
                    console.print(f"\n  [cyan]{symbol['docstring'][:200]}{'...' if len(symbol['docstring']) > 200 else ''}[/cyan]")
    
    except requests.exceptions.ConnectionError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def search(
    query: str,
    mode: str = typer.Option(
        "hybrid",
        "--mode", "-m",
        help="Search mode: fulltext, semantic, hybrid"
    ),
    limit: int = typer.Option(
        20,
        "--limit", "-l",
        help="Maximum number of results"
    ),
    threshold: float = typer.Option(
        0.5,
        "--threshold", "-t",
        help="Minimum similarity threshold (for semantic/hybrid)"
    )
):
    """Search the codebase"""
    from rich.console import Console
    from rich.table import Table
    
    console = Console()
    
    # Check API connection first
    if not check_api_connection():
        console.print("[red]❌ Cannot connect to MyCodebase API[/red]")
        console.print(f"[yellow]API URL: {API_BASE_URL}[/yellow]")
        console.print("\n[yellow]Is the watcher running?[/yellow]")
        console.print("  [dim]docker ps | grep mycodebase[/dim]")
        raise typer.Exit(code=1)
    
    # Validate mode
    valid_modes = ['fulltext', 'semantic', 'hybrid']
    if mode not in valid_modes:
        console.print(f"[red]Invalid mode: {mode}. Valid modes: {', '.join(valid_modes)}[/red]")
        raise typer.Exit(code=1)
    
    try:
        # Call REST API
        response = requests.post(
            get_api_url("/api/v1/search"),
            json={
                "query": query,
                "mode": mode,
                "limit": limit,
                "threshold": threshold
            },
            timeout=30
        )
        
        response.raise_for_status()
        data = response.json()
        
        results = data['results']
        
        # Display results
        if not results:
            console.print(f"\n[yellow]No results found for '{query}'[/yellow]")
            return
        
        console.print(f"\n[bold green]✅ Found {len(results)} results[/bold green]\n")
        
        # Create results table
        table = Table(title=f"Search Results: {query}", show_lines=True)
        table.add_column("Score", style="cyan", justify="right", width=8)
        table.add_column("File", style="green", width=40)
        table.add_column("Symbol", style="yellow", width=25)
        table.add_column("Type", style="magenta", width=12)
        table.add_column("Snippet", style="white", width=60)
        
        for result in results:
            # Format score
            if 'combined_score' in result:
                score = f"{result['combined_score']:.3f}"
            elif 'similarity_score' in result:
                score = f"{result['similarity_score']:.3f}"
            elif 'score' in result:
                score = f"{result['score']:.3f}"
            else:
                score = "N/A"
            
            # Format file path (truncate if long)
            file_path = result['path']
            if len(file_path) > 38:
                file_path = "..." + file_path[-35:]
            
            # Format snippet
            snippet = ""
            if result.get('signature'):
                snippet = result['signature'][:57] + "..." if len(result['signature']) > 60 else result['signature']
            elif result.get('docstring'):
                snippet = result['docstring'][:57] + "..." if len(result['docstring']) > 60 else result['docstring']
            
            table.add_row(
                score,
                file_path,
                result['name'][:23] + "..." if len(result['name']) > 23 else result['name'],
                result['type'],
                snippet
            )
        
        console.print(table)
        
        # Show search info
        console.print(f"\n[dim]Mode: {mode} | Limit: {limit} | Threshold: {threshold}[/dim]")
    
    except requests.exceptions.ConnectionError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        raise typer.Exit(code=1)
    except requests.exceptions.Timeout as e:
        console.print(f"[red]Timeout: Search took too long. Try reducing limit or using fulltext mode.[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def rebuild(
    project_name: Optional[str] = typer.Option(
        None,
        "--project", "-p",
        help="Rebuild specific project only"
    ),
    force: bool = typer.Option(
        False,
        "--force", "-f",
        help="Force rebuild even if unchanged"
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Enable verbose logging and show progress bar"
    )
):
    """Trigger manual reindex"""
    from rich.console import Console
    
    console = Console()
    
    # Check API connection first
    if not check_api_connection():
        console.print("[red]❌ Cannot connect to MyCodebase API[/red]")
        console.print(f"[yellow]API URL: {API_BASE_URL}[/yellow]")
        console.print("\n[yellow]Is the watcher running?[/yellow]")
        console.print("  [dim]docker ps | grep mycodebase[/dim]")
        raise typer.Exit(code=1)
    
    try:
        # Call REST API
        console.print(f"\n[bold cyan]Triggering rebuild via API...[/bold cyan]")
        
        response = requests.post(
            get_api_url("/api/v1/rebuild"),
            json={
                "project_name": project_name,
                "force": force,
                "verbose": verbose
            },
            timeout=300  # 5 minutes timeout for indexing
        )
        
        response.raise_for_status()
        data = response.json()
        
        if data['status'] == 'success':
            stats = data['stats']
            
            console.print(f"\n[green]✅ Indexing complete![/green]")
            console.print(f"\n[bold]Statistics:[/bold]")
            console.print(f"  Files scanned: {stats['files_scanned']}")
            console.print(f"  Files indexed: {stats['files_indexed']}")
            console.print(f"  Files skipped (unchanged): {stats['files_skipped_unchanged']}")
            console.print(f"  Files ignored: {stats['files_ignored']}")
            console.print(f"  Symbols extracted: {stats['symbols_extracted']}")
            console.print(f"  Dependencies extracted: {stats['dependencies_extracted']}")
            console.print(f"  Errors: {stats['errors']}")
        else:
            console.print(f"[red]❌ Rebuild failed:[/red] {data.get('error', 'Unknown error')}")
            raise typer.Exit(code=1)
    
    except requests.exceptions.ConnectionError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        raise typer.Exit(code=1)
    except requests.exceptions.Timeout as e:
        console.print(f"[red]Timeout: Rebuild took too long. Check watcher logs.[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)


@app.command()
def watch(
    path: Optional[str] = typer.Option(
        None,
        "--path", "-p",
        help="Optional path to watch (defaults to project root)"
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Enable verbose logging"
    )
):
    """Start file watcher for incremental indexing"""
    from rich.console import Console
    
    console = Console()
    
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Determine project to watch
    if path:
        project_root = Path(path)
        project_name = project_root.name
    else:
        # Default: use FBNET_MYCODEBASE_INDEX_ROOT env var or fallback to project root
        from mycodebase.core.config import config
        project_root = config.index_root_path
        project_name = project_root.name
    
    if not project_root.exists():
        console.print(f"[red]Project root not found:[/red] {project_root}")
        raise typer.Exit(code=1)
    
    console.print(f"\n[bold cyan]Starting watcher for:[/bold cyan] {project_name}")
    console.print(f"[bold cyan]Project root:[/bold cyan] {project_root}")
    console.print(f"[bold cyan]Ignore file:[/bold cyan] {project_root / '.codebaseignore'}")
    console.print(f"\n[green]👁️  Watching for file changes...[/green]")
    console.print(f"[dim]Press Ctrl+C to stop[/dim]\n")
    
    try:
        from mycodebase.indexer.watcher import CodebaseWatcher

        # When watching index_root with multiple subdirectories, spawn a watcher per project
        if not path and project_root.is_dir():
            subdirs = [
                d for d in project_root.iterdir()
                if d.is_dir() and not d.name.startswith(".")
            ]
            if len(subdirs) > 1:
                console.print(
                    f"[bold cyan]Detected {len(subdirs)} projects under {project_root}[/bold cyan]"
                )
                watchers = []
                for subdir in subdirs:
                    console.print(
                        f"  [dim]→ Starting watcher for:[/dim] {subdir.name}"
                    )
                    watcher = CodebaseWatcher(
                        project_name=subdir.name,
                        project_root=str(subdir),
                        show_progress=False,
                    )
                    watchers.append(watcher)

                # Start all watchers in background threads
                import threading
                threads = []
                for watcher in watchers:
                    t = threading.Thread(target=watcher.start, daemon=True)
                    t.start()
                    threads.append(t)

                console.print(
                    f"\n[green]👁️  Watching {len(watchers)} projects...[/green]"
                )
                console.print("[dim]Press Ctrl+C to stop[/dim]\n")

                # Keep main thread alive
                try:
                    while True:
                        time.sleep(1)
                except KeyboardInterrupt:
                    console.print("\n[yellow]Stopping all watchers...[/yellow]")
                    for watcher in watchers:
                        watcher.stop()
                    for t in threads:
                        t.join(timeout=2)
                    console.print("[yellow]All watchers stopped[/yellow]")
                    return

        # Single project watcher (explicit path or single subdir)
        watcher = CodebaseWatcher(
            project_name=project_name,
            project_root=str(project_root),
            show_progress=False,
        )
        watcher.start()

    except KeyboardInterrupt:
        console.print("\n[yellow]Watcher stopped by user[/yellow]")
    except Exception as e:
        console.print(f"[red]❌ Watcher failed:[/red] {e}")
        logger.exception("Watcher failed")
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
