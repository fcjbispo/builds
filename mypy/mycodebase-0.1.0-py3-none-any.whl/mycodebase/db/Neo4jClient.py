"""Neo4j client for graph relationships"""

import os
import logging
from typing import Optional, Dict, Any, List
from neo4j import GraphDatabase


logger = logging.getLogger(__name__)


class Neo4jClient:
    """
    Client for Neo4j graph database.
    
    Provides methods for creating and querying graph nodes representing
    files, functions, classes, modules, and their relationships.
    """
    
    def __init__(self, uri: Optional[str] = None, 
                 user: Optional[str] = None, 
                 password: Optional[str] = None,
                 database: Optional[str] = None):
        from mycodebase.core.config import config  # type: ignore
        self.uri = uri or config.neo4j_uri
        self.user = user or config.neo4j_user
        self.password = password or config.neo4j_password
        self.database = database or config.neo4j_database
        self._driver = None
    
    def connect(self):
        """Initialize Neo4j driver"""
        if self._driver is None:
            self._driver = GraphDatabase.driver(
                self.uri,
                auth=(self.user, self.password)
            )
        return self._driver
    
    def close(self):
        """Close Neo4j driver"""
        if self._driver:
            self._driver.close()
            self._driver = None
    
    def initialize_constraints(self):
        """Create initial constraints and indexes"""
        
        constraints_and_indexes = """
        -- File uniqueness constraint
        CREATE CONSTRAINT file_path_unique IF NOT EXISTS
        FOR (f:File) REQUIRE f.path IS UNIQUE;
        
        -- Function uniqueness constraint
        CREATE CONSTRAINT function_name_file_unique IF NOT EXISTS
        FOR (func:Function) REQUIRE (func.name, func.file_path) IS UNIQUE;
        
        -- Class uniqueness constraint
        CREATE CONSTRAINT class_name_file_unique IF NOT EXISTS
        FOR (c:Class) REQUIRE (c.name, c.file_path) IS UNIQUE;
        
        -- Project uniqueness constraint
        CREATE CONSTRAINT project_name_unique IF NOT EXISTS
        FOR (p:Project) REQUIRE p.name IS UNIQUE;
        
        -- Indexes for performance
        CREATE INDEX file_language_index IF NOT EXISTS FOR (f:File) ON (f.language);
        CREATE INDEX function_name_index IF NOT EXISTS FOR (func:Function) ON (func.name);
        CREATE INDEX class_name_index IF NOT EXISTS FOR (c:Class) ON (c.name);
        CREATE INDEX module_name_index IF NOT EXISTS FOR (m:Module) ON (m.name);
        """
        
        driver = self.connect()
        with driver.session() as session:
            # Neo4j requires running constraints one at a time
            for statement in constraints_and_indexes.split(';'):
                statement = statement.strip()
                if statement:
                    try:
                        session.run(statement)
                    except Exception as e:
                        # Some constraints might already exist
                        logger.debug(f"Constraint/index warning: {e}")
    
    def create_project(self, name: str, root_path: str) -> Dict[str, Any]:
        """Create or get a project node"""
        
        cypher = """
        MERGE (p:Project {name: $name})
        SET p.root_path = $root_path, p.updated_at = datetime()
        RETURN p
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, name=name, root_path=root_path)
            record = result.single()
            return dict(record['p']) if record else {}
    
    def create_file_node(self, path: str, language: str, project_name: str,
                         hash_value: Optional[str] = None) -> Dict[str, Any]:
        """Create or update a file node"""
        
        cypher = """
        MATCH (p:Project {name: $project_name})
        MERGE (f:File {path: $path})
        SET f.language = $language,
            f.hash = $hash_value,
            f.updated_at = datetime()
        WITH f, p
        MERGE (f)-[:BELONGS_TO]->(p)
        RETURN f
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, path=path, language=language,
                                 project_name=project_name, hash_value=hash_value)
            record = result.single()
            return dict(record['f']) if record else {}
    
    def create_function_node(self, name: str, file_path: str,
                             signature: Optional[str] = None,
                             start_line: Optional[int] = None,
                             end_line: Optional[int] = None) -> Dict[str, Any]:
        """Create a function node"""
        
        cypher = """
        MATCH (f:File {path: $file_path})
        MERGE (func:Function {name: $name, file_path: $file_path})
        SET func.signature = $signature,
            func.start_line = $start_line,
            func.end_line = $end_line,
            func.updated_at = datetime()
        WITH func, f
        MERGE (func)-[:DEFINED_IN]->(f)
        RETURN func
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, name=name, file_path=file_path,
                                 signature=signature, start_line=start_line,
                                 end_line=end_line)
            record = result.single()
            return dict(record['func']) if record else {}
    
    def create_class_node(self, name: str, file_path: str,
                          parents: Optional[List[str]] = None) -> Dict[str, Any]:
        """Create a class node"""
        
        cypher = """
        MATCH (f:File {path: $file_path})
        MERGE (c:Class {name: $name, file_path: $file_path})
        SET c.updated_at = datetime()
        WITH c, f
        MERGE (c)-[:DEFINED_IN]->(f)
        RETURN c
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, name=name, file_path=file_path)
            record = result.single()
            return dict(record['c']) if record else {}
    
    def create_import_relationship(self, source_file_path: str, 
                                   target_module: str,
                                   target_symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Create an IMPORTS relationship between a file and a module.
        
        Module names are normalized to lowercase for consistency.
        
        Args:
            source_file_path: Path to the source file
            target_module: Name of the target module (will be normalized)
            target_symbol: Optional specific symbol being imported
            
        Returns:
            Dict with relationship information
        """
        # Normalize module name to lowercase for consistency
        normalized_module = target_module.lower().replace('/', '.').replace('\\', '.')
        
        cypher = """
        MATCH (source:File {path: $source_file_path})
        MERGE (m:Module {name: $normalized_module})
        WITH source, m
        MERGE (source)-[r:IMPORTS]->(m)
        SET r.target_symbol = $target_symbol, r.updated_at = datetime()
        RETURN r
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, source_file_path=source_file_path,
                                 normalized_module=normalized_module,
                                 target_symbol=target_symbol)
            record = result.single()
            return dict(record['r']) if record else {}
    
    def create_calls_relationship(self, caller_name: str, caller_file: str,
                                  callee_name: str, callee_file: str) -> Dict[str, Any]:
        """Create a CALLS relationship between functions"""
        
        cypher = """
        MATCH (caller:Function {name: $caller_name, file_path: $caller_file})
        MATCH (callee:Function {name: $callee_name, file_path: $callee_file})
        MERGE (caller)-[r:CALLS]->(callee)
        SET r.updated_at = datetime()
        RETURN r
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, caller_name=caller_name,
                                 caller_file=caller_file,
                                 callee_name=callee_name,
                                 callee_file=callee_file)
            record = result.single()
            return dict(record['r']) if record else {}
    
    def find_callers(self, function_name: str) -> List[Dict[str, Any]]:
        """Find all functions that call a given function"""
        
        cypher = """
        MATCH (caller:Function)-[:CALLS]->(callee:Function {name: $function_name})
        RETURN caller.name as name, caller.file_path as file_path, 
               caller.signature as signature
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, function_name=function_name)
            return [dict(record) for record in result]
    
    def find_callees(self, function_name: str, file_path: str) -> List[Dict[str, Any]]:
        """Find all functions called by a given function"""
        
        cypher = """
        MATCH (caller:Function {name: $function_name, file_path: $file_path})-[:CALLS]->(callee:Function)
        RETURN callee.name as name, callee.file_path as file_path,
               callee.signature as signature
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, function_name=function_name, file_path=file_path)
            return [dict(record) for record in result]
    
    def find_dependencies_between_projects(self, project1: str, project2: str) -> List[Dict[str, Any]]:
        """Find dependencies between two projects"""
        
        cypher = """
        MATCH (p1:Project {name: $project1})<-[:BELONGS_TO]-(f1:File)-[:IMPORTS]->(m:Module)<-[:IMPORTS]-(f2:File)-[:BELONGS_TO]->(p2:Project {name: $project2})
        WHERE p1.name <> p2.name
        RETURN p2.name as project, count(DISTINCT f2) as import_count
        """
        
        driver = self.connect()
        with driver.session() as session:
            result = session.run(cypher, project1=project1, project2=project2)
            return [dict(record) for record in result]
    
    def health_check(self) -> bool:
        """Check if Neo4j is accessible"""
        try:
            driver = self.connect()
            with driver.session() as session:
                session.run("RETURN 1")
            return True
        except Exception:
            return False
