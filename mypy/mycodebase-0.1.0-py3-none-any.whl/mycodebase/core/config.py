"""Configuration management for MyCodebase"""

import os
from pathlib import Path
from typing import Optional


class Config:
    """Centralized configuration"""
    
    # Database defaults
    DEFAULT_DB_URI = "postgresql://mycodebase:mycodebase@postgres:5432/fbnet"
    DEFAULT_NEO4J_URI = "bolt://neo4j-mycodebase:7687"
    DEFAULT_NEO4J_USER = "neo4j"
    DEFAULT_NEO4J_PASSWORD = "mycodebase"
    DEFAULT_NEO4J_DATABASE = "neo4j"

    # Embeddings
    DEFAULT_OLLAMA_HOST = "http://ollama:11434"
    DEFAULT_OLLAMA_MODEL = "nomic-embed-text:latest"
    DEFAULT_EMBEDDING_DIMENSION = 768
    
    # Indexing
    DEFAULT_INDEX_ROOT = os.path.expanduser("~/user/workspace/Projects")
    
    # API Configuration
    DEFAULT_API_URL = "http://localhost:3004"
    DEFAULT_API_PORT = 8080
    
    def __init__(self):
        # PostgreSQL
        self.db_uri = os.getenv("FBNET_MYCODEBASE_INDEX_DB_URI", self.DEFAULT_DB_URI)
        
        # Neo4j
        self.neo4j_uri = os.getenv("FBNET_MYCODEBASE_INDEX_NEO4J_URI", self.DEFAULT_NEO4J_URI)
        self.neo4j_user = os.getenv("FBNET_MYCODEBASE_INDEX_NEO4J_USER", self.DEFAULT_NEO4J_USER)
        self.neo4j_password = os.getenv("FBNET_MYCODEBASE_INDEX_NEO4J_PASSWORD", self.DEFAULT_NEO4J_PASSWORD)
        self.neo4j_database = os.getenv("FBNET_MYCODEBASE_INDEX_NEO4J_DATABASE", "neo4j")
        
        # Ollama
        self.ollama_host = os.getenv("FBNET_MYCODEBASE_OLLAMA_HOST", self.DEFAULT_OLLAMA_HOST)
        self.ollama_model = os.getenv("FBNET_MYCODEBASE_INDEX_OLLAMA_MODEL", self.DEFAULT_OLLAMA_MODEL)
        self.embedding_dimension = int(
            os.getenv("FBNET_MYCODEBASE_INDEX_EMBEDDING_DIM", str(self.DEFAULT_EMBEDDING_DIMENSION))
        )
        
        # Index root directory
        self.index_root = os.getenv(
            "FBNET_MYCODEBASE_INDEX_ROOT",
            self.DEFAULT_INDEX_ROOT
        )
        
        # First run auto-indexing
        self.index_on_first_run = os.getenv(
            "FBNET_MYCODEBASE_INDEX_ON_FIRST_RUN",
            "true"
        ).lower() in ("true", "1", "yes")
        
        # Ignore file
        self.ignore_file = ".codebaseignore"
        
        # API Configuration
        api_url_env = os.getenv("FBNET_MYCODEBASE_API_URL", self.DEFAULT_API_URL)
        self.api_url = api_url_env
        # Extract port from URL if present, otherwise use default
        if "://" in api_url_env and ":" in api_url_env.split("://")[1]:
            self.api_port = int(api_url_env.split(":")[-1].split("/")[0])
        else:
            self.api_port = self.DEFAULT_API_PORT
    
    @property
    def index_root_path(self) -> Path:
        return Path(self.index_root)
    
    @property
    def ignore_file_path(self) -> Path:
        return self.index_root_path / self.ignore_file
    
    @property
    def api_base_url(self) -> str:
        """Get API base URL from config"""
        return self.api_url

    def validate(self) -> list[str]:
        """Validate configuration and return list of warnings.

        Returns:
            List of warning messages for invalid or problematic settings.
            Empty list if all settings are valid.
        """
        warnings = []

        # Validate index root directory
        root = self.index_root_path
        if not root.exists():
            warnings.append(
                f"Index root directory does not exist: {root}"
            )
        elif not root.is_dir():
            warnings.append(
                f"Index root path is not a directory: {root}"
            )
        elif not os.access(root, os.R_OK):
            warnings.append(
                f"Index root directory is not readable: {root}"
            )

        return warnings


# Global config instance
config = Config()
