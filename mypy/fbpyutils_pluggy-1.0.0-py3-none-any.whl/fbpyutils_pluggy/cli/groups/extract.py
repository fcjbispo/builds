"""
Extract commands for Pluggy CLI.

Commands for extracting financial data from institutions.
"""

import typer
from typing import Optional
from datetime import datetime
from pathlib import Path

from fbpyutils_pluggy import PluggyClient
from fbpyutils_pluggy.cli.utils.error_handler import handle_error
from fbpyutils_pluggy.cli.utils.output_formatter import format_output, OutputFormat
from fbpyutils_pluggy.cli.utils.export import auto_export, validate_iso_date, create_output_directory

app = typer.Typer(
    name="extract",
    help="Extract financial data from institutions.",
    rich_markup_mode="rich",
)


def get_client() -> PluggyClient:
    """Get configured PluggyClient from environment.
    
    Priority:
    1. FBPY_PLUGGY_CLIENT_ID / FBPY_PLUGGY_CLIENT_SECRET
    2. PLUGGY_CLIENT_ID / PLUGGY_CLIENT_SECRET (fallback)
    """
    import os
    
    # Try new env vars first, then fallback to old ones
    client_id = os.getenv("FBPY_PLUGGY_CLIENT_ID") or os.getenv("PLUGGY_CLIENT_ID")
    client_secret = os.getenv("FBPY_PLUGGY_CLIENT_SECRET") or os.getenv("PLUGGY_CLIENT_SECRET")
    
    if not client_id or not client_secret:
        raise typer.BadParameter(
            "Environment variables not set.\n\n"
            "Please set:\n"
            "  FBPY_PLUGGY_CLIENT_ID (or PLUGGY_CLIENT_ID)\n"
            "  FBPY_PLUGGY_CLIENT_SECRET (or PLUGGY_CLIENT_SECRET)\n\n"
            "Get your credentials at: https://dashboard.pluggy.ai"
        )
    
    return PluggyClient(
        client_id=client_id,
        client_secret=client_secret,
    )


def _institutions_payload(accounts):
    """Accounts as API-shaped dicts (camelCase) for institutions.<fmt> export."""
    return [
        {
            'id': a.id,
            'name': a.name,
            'type': a.type,
            'balance': a.balance,
            'currencyCode': a.currency_code,
        }
        for a in accounts
    ]


@app.command(name="institutions")
def list_institutions(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file (json/csv/xlsx)"),
):
    """List institutions available for an item."""
    try:
        with get_client() as client:
            # GET /items/{id} has no accounts field — use the accounts API
            accounts = client.accounts.list(item_id=item_id)

            if output:
                # Export to file (camelCase, same shape as the other exports)
                auto_export(_institutions_payload(accounts), output)
                typer.echo(f"✅ Institutions exported to {output}")
            else:
                # Display in terminal (models → _format_table dumps by_alias=False)
                if accounts:
                    format_output(
                        accounts,
                        format=OutputFormat.TABLE,
                        title="Institutions",
                        columns=["id", "name", "type", "balance", "currency_code"],
                    )
                else:
                    typer.echo("No institutions found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="transactions")
def extract_transactions(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    account_id: Optional[str] = typer.Option(None, "--account-id", "-a", help="Account ID (optional)"),
    from_date: Optional[str] = typer.Option(None, "--from-date", "-f", help="Start date (YYYY-MM-DD)"),
    to_date: Optional[str] = typer.Option(None, "--to-date", "-t", help="End date (YYYY-MM-DD)"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract transactions from accounts."""
    # Validate dates
    if from_date and not validate_iso_date(from_date):
        raise typer.BadParameter("Invalid from-date format. Use YYYY-MM-DD.")
    if to_date and not validate_iso_date(to_date):
        raise typer.BadParameter("Invalid to-date format. Use YYYY-MM-DD.")
    
    try:
        with get_client() as client:
            transactions = []
            
            if account_id:
                # Extract transactions for specific account
                txs = client.transactions.list(
                    account_id=account_id,
                    from_date=from_date,
                    to_date=to_date
                )
                transactions.extend(txs)
            else:
                # Extract transactions for all accounts in item
                for account in client.accounts.list(item_id=item_id):
                    try:
                        txs = client.transactions.list(
                            account_id=str(account.id),
                            from_date=from_date,
                            to_date=to_date
                        )
                        transactions.extend(txs)
                    except Exception:
                        # Skip accounts that fail to fetch transactions
                        continue
            
            if output:
                # Export to file
                auto_export(transactions, output)
                typer.echo(f"✅ Transactions exported to {output}")
            else:
                # Display in terminal
                if transactions:
                    format_output(
                        transactions,
                        format=OutputFormat.TABLE,
                        title="Transactions",
                        columns=["id", "description", "amount", "date", "category"],
                    )
                else:
                    typer.echo("No transactions found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="credit-cards")
def extract_credit_cards(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    account_id: Optional[str] = typer.Option(None, "--account-id", "-a", help="Credit card account ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract credit card data and bills."""
    try:
        with get_client() as client:
            credit_cards = []
            
            if account_id:
                # Extract credit card for specific account
                try:
                    card = client.accounts.get(account_id)
                    credit_cards.append(card)
                except Exception as e:
                    typer.echo(f"⚠️ Could not fetch credit card {account_id}: {e}")
            else:
                # Extract all credit card accounts from item
                credit_cards = client.accounts.list(item_id=item_id, type="CREDIT")
            
            if output:
                # Export to file
                auto_export(credit_cards, output)
                typer.echo(f"✅ Credit cards exported to {output}")
            else:
                # Display in terminal
                if credit_cards:
                    format_output(
                        credit_cards,
                        format=OutputFormat.TABLE,
                        title="Credit Cards",
                        columns=["id", "name", "brand", "credit_limit", "balance"],
                    )
                else:
                    typer.echo("No credit cards found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="investments")
def extract_investments(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract investment positions (GET /investments)."""
    try:
        with get_client() as client:
            investments = client.investments.list(item_id=item_id)

            if output:
                # Export to file
                auto_export(investments, output)
                typer.echo(f"✅ Investments exported to {output}")
            else:
                # Display in terminal
                if investments:
                    format_output(
                        investments,
                        format=OutputFormat.TABLE,
                        title="Investments",
                        columns=["id", "name", "type", "subtype", "balance", "currency_code"],
                    )
                else:
                    typer.echo("No investments found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="investment-transactions")
def extract_investment_transactions(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract the transactions of every investment of an item."""
    try:
        with get_client() as client:
            transactions = []
            for investment in client.investments.list(item_id=item_id):
                for tx in client.investments.list_transactions(str(investment.id)):
                    # provenance: the endpoint response has no investment id
                    transactions.append(
                        tx.model_copy(update={"investment_id": investment.id})
                    )

            if output:
                # Export to file
                auto_export(transactions, output)
                typer.echo(f"✅ Investment transactions exported to {output}")
            else:
                # Display in terminal
                if transactions:
                    format_output(
                        transactions,
                        format=OutputFormat.TABLE,
                        title="Investment Transactions",
                        columns=["id", "investment_id", "type", "trade_date", "quantity", "amount"],
                    )
                else:
                    typer.echo("No investment transactions found.")

    except Exception as e:
        handle_error(e)


@app.command(name="identity")
def extract_identity(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract identity information."""
    try:
        with get_client() as client:
            # identity lives in its own endpoint, not on the item
            identity = client.identity.get_by_item(item_id)

            if output:
                # Export to file (model → camelCase via export_to_json)
                auto_export(identity if identity else {}, output)
                typer.echo(f"✅ Identity exported to {output}")
            else:
                # Display in terminal (model → _format_table dumps by_alias=False)
                if identity:
                    format_output(
                        identity,
                        format=OutputFormat.TABLE,
                        title="Identity Information"
                    )
                else:
                    typer.echo("No identity information found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="loans")
def extract_loans(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file"),
):
    """Extract loan information."""
    try:
        with get_client() as client:
            # loans are a product (GET /loans), not an account type
            loans = client.loans.list(item_id=item_id)

            if output:
                # Export to file
                auto_export(loans, output)
                typer.echo(f"✅ Loans exported to {output}")
            else:
                # Display in terminal
                if loans:
                    format_output(
                        loans,
                        format=OutputFormat.TABLE,
                        title="Loans",
                        columns=["id", "product_name", "kind", "contract_amount", "currency_code"],
                    )
                else:
                    typer.echo("No loans found.")
                    
    except Exception as e:
        handle_error(e)


@app.command(name="all")
def extract_all(
    item_id: str = typer.Option(..., "--item-id", "-i", help="Item ID"),
    from_date: Optional[str] = typer.Option(None, "--from-date", "-f", help="Start date (YYYY-MM-DD)"),
    to_date: Optional[str] = typer.Option(None, "--to-date", "-t", help="End date (YYYY-MM-DD)"),
    output_dir: Path = typer.Option("./export", "--output-dir", "-d", help="Output directory"),
    format: str = typer.Option("xlsx", "--format", "-f", help="Output format (json/csv/xlsx)"),
):
    """Extract all data from an item (full export)."""
    # Validate dates
    if from_date and not validate_iso_date(from_date):
        raise typer.BadParameter("Invalid from-date format. Use YYYY-MM-DD.")
    if to_date and not validate_iso_date(to_date):
        raise typer.BadParameter("Invalid to-date format. Use YYYY-MM-DD.")
    
    # Validate format
    valid_formats = ['json', 'csv', 'xlsx']
    if format not in valid_formats:
        raise typer.BadParameter(f"Invalid format. Must be one of: {', '.join(valid_formats)}")
    
    try:
        with get_client() as client:
            # Create output directory
            create_output_directory(output_dir)
            
            # 1. Accounts (one API call, reused below)
            accounts = client.accounts.list(item_id=item_id)
            institutions_data = _institutions_payload(accounts)
            
            # Save institutions
            institutions_file = output_dir / f"institutions.{format}"
            auto_export(institutions_data, institutions_file)
            typer.echo(f"✅ Institutions saved to {institutions_file}")
            
            # 2. Extract transactions per account
            transactions_data = []
            for account in accounts:
                try:
                    txs = client.transactions.list(
                        account_id=str(account.id),
                        from_date=from_date,
                        to_date=to_date
                    )
                    transactions_data.extend(txs)
                except Exception:
                    # Skip accounts that fail to fetch transactions
                    continue
            
            # Save transactions
            transactions_file = output_dir / f"transactions.{format}"
            auto_export(transactions_data, transactions_file)
            typer.echo(f"✅ Transactions saved to {transactions_file}")
            
            # 3. Credit card accounts (client-side type filter)
            credit_cards_data = [
                a for a in accounts if a.type and a.type.value == "CREDIT"
            ]
            
            # Save credit cards
            credit_cards_file = output_dir / f"credit_cards.{format}"
            auto_export(credit_cards_data, credit_cards_file)
            typer.echo(f"✅ Credit cards saved to {credit_cards_file}")
            
            # 4. Investment positions + their transactions (GET /investments, not account types)
            investments_data = client.investments.list(item_id=item_id)
            
            investments_file = output_dir / f"investments.{format}"
            auto_export(investments_data, investments_file)
            typer.echo(f"✅ Investments saved to {investments_file}")
            
            investment_transactions_data = []
            for investment in investments_data:
                for tx in client.investments.list_transactions(str(investment.id)):
                    investment_transactions_data.append(
                        tx.model_copy(update={"investment_id": investment.id})
                    )
            
            investment_transactions_file = output_dir / f"investment_transactions.{format}"
            auto_export(investment_transactions_data, investment_transactions_file)
            typer.echo(f"✅ Investment transactions saved to {investment_transactions_file}")
            
            # 5. Identity (own endpoint, not on the item)
            identity = client.identity.get_by_item(item_id)
            
            # Save identity (model → camelCase via export_to_json)
            identity_file = output_dir / f"identity.{format}"
            auto_export(identity if identity else {}, identity_file)
            typer.echo(f"✅ Identity saved to {identity_file}")
            
            # 6. Loans (own product endpoint)
            loans_data = client.loans.list(item_id=item_id)
            
            # Save loans
            loans_file = output_dir / f"loans.{format}"
            auto_export(loans_data, loans_file)
            typer.echo(f"✅ Loans saved to {loans_file}")
            
            typer.echo(f"\n🎉 Full export completed successfully!")
            typer.echo(f"📁 Output directory: {output_dir.absolute()}")
            
    except Exception as e:
        handle_error(e)
