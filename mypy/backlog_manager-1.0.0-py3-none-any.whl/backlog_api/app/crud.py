"""Operações CRUD - lógica extraída do app.py original."""

from __future__ import annotations

import csv
import io

import pandas as pd

from backlog_api.app.database import get_connection


# ============================================================
# CONSTANTES
# ============================================================

STATUS_OPTIONS = ["Backlog", "Em Andamento", "Em Revisão", "Concluído"]

LEGACY_STATUS_MAP = {
    "Aberto": "Backlog",
    "A Fazer": "Backlog",
    "Feito": "Concluído",
}


# ============================================================
# HELPERS
# ============================================================

def _normalize_status(status: str | None) -> str:
    """Normaliza status para valor válido."""
    if status is None:
        return "Backlog"
    if status in LEGACY_STATUS_MAP:
        return LEGACY_STATUS_MAP[status]
    if status in STATUS_OPTIONS:
        return status
    return "Backlog"


# ============================================================
# CRUD BÁSICO
# ============================================================

def get_all_items(
    projeto: str | None = None,
    componente: str | None = None,
    status: str | None = None,
) -> list[dict]:
    """Retorna todos os itens, opcionalmente filtrados."""
    conn = get_connection()
    cursor = conn.cursor()

    query = """
        SELECT id, item, projeto, componente, titulo, detalhamento, status
        FROM backlog
        WHERE 1=1
    """
    params: list = []

    if projeto:
        query += " AND projeto = ?"
        params.append(projeto)
    if componente:
        query += " AND componente = ?"
        params.append(componente)
    if status:
        query += " AND status = ?"
        params.append(status)

    query += " ORDER BY id"

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]


def get_item_by_id(item_id: int) -> dict | None:
    """Retorna um item específico pelo ID."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, item, projeto, componente, titulo, detalhamento, status
        FROM backlog WHERE id = ?
    """, (item_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def create_item(data: dict) -> dict:
    """Cria novo item no backlog."""
    status = _normalize_status(data.get("status"))

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO backlog (item, projeto, componente, titulo, detalhamento, status)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        data["item"], data["projeto"], data["componente"],
        data["titulo"], data.get("detalhamento"), status
    ))
    new_id = cursor.lastrowid
    conn.commit()
    conn.close()

    result = get_item_by_id(new_id)
    assert result is not None
    return result


def update_item(item_id: int, data: dict) -> dict | None:
    """Atualiza item existente (PUT - todos os campos)."""
    existing = get_item_by_id(item_id)
    if existing is None:
        return None

    status = _normalize_status(data.get("status"))

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE backlog 
        SET item=?, projeto=?, componente=?, titulo=?, detalhamento=?, status=?
        WHERE id=?
    """, (
        data["item"], data["projeto"], data["componente"],
        data["titulo"], data.get("detalhamento"), status, item_id
    ))
    conn.commit()
    conn.close()

    return get_item_by_id(item_id)


def patch_item(item_id: int, data: dict) -> dict | None:
    """Atualização parcial (PATCH - apenas campos fornecidos)."""
    existing = get_item_by_id(item_id)
    if existing is None:
        return None

    updates: dict[str, object] = {}
    if "item" in data and data["item"] is not None:
        updates["item"] = data["item"]
    if "projeto" in data and data["projeto"] is not None:
        updates["projeto"] = data["projeto"]
    if "componente" in data and data["componente"] is not None:
        updates["componente"] = data["componente"]
    if "titulo" in data and data["titulo"] is not None:
        updates["titulo"] = data["titulo"]
    if "detalhamento" in data:
        updates["detalhamento"] = data["detalhamento"]
    if "status" in data and data["status"] is not None:
        updates["status"] = _normalize_status(data["status"])

    if not updates:
        return existing

    fields = ", ".join(f"{k}=?" for k in updates.keys())
    values = list(updates.values()) + [item_id]

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"UPDATE backlog SET {fields} WHERE id=?", values)
    conn.commit()
    conn.close()

    return get_item_by_id(item_id)


def delete_item(item_id: int) -> bool:
    """Remove item pelo ID. Retorna True se existia e foi removido."""
    existing = get_item_by_id(item_id)
    if existing is None:
        return False

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM backlog WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    return True


# ============================================================
# OPERAÇÕES AGREGADAS
# ============================================================

def get_projects() -> list[str]:
    """Retorna lista de projetos únicos."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT projeto FROM backlog ORDER BY projeto")
    projects = [row[0] for row in cursor.fetchall()]
    conn.close()
    return projects


def get_components() -> list[str]:
    """Retorna lista de componentes únicos."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT componente FROM backlog ORDER BY componente")
    components = [row[0] for row in cursor.fetchall()]
    conn.close()
    return components


def get_dashboard_stats() -> dict:
    """Retorna estatísticas para o dashboard."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM backlog")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM backlog WHERE status = 'Em Andamento'")
    em_andamento = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM backlog WHERE status = 'Concluído'")
    concluidos = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(DISTINCT projeto) FROM backlog")
    projetos = cursor.fetchone()[0]

    cursor.execute("""
        SELECT status, COUNT(*) as count
        FROM backlog
        GROUP BY status
        ORDER BY status
    """)
    por_status = [dict(row) for row in cursor.fetchall()]

    conn.close()

    return {
        "total": total,
        "em_andamento": em_andamento,
        "concluidos": concluidos,
        "projetos": projetos,
        "por_status": por_status,
    }


# ============================================================
# IMPORTAR / EXPORTAR CSV
# ============================================================

def export_to_csv() -> str:
    """Exporta todos os itens para CSV."""
    items = get_all_items()
    df = pd.DataFrame(items)
    df = df.sort_values(by=["projeto", "item"])
    export_df = df[["item", "projeto", "componente", "titulo", "detalhamento", "status"]].copy()
    export_df.columns = ["Item", "Projeto", "Componente", "Título", "Detalhamento", "Status"]

    output = io.StringIO()
    export_df.to_csv(output, index=False, quoting=csv.QUOTE_ALL)
    return output.getvalue()


def import_from_csv(csv_content: str, append: bool = False) -> tuple[int, list[str]]:
    """Importa itens de CSV. Retorna (importados, erros)."""
    errors: list[str] = []
    imported = 0

    if not append:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM backlog")
        conn.commit()
        conn.close()

    try:
        f = io.StringIO(csv_content)
        reader = csv.DictReader(f)

        if reader.fieldnames is None:
            return 0, ["CSV vazio ou sem cabeçalho"]

        expected = ["Item", "Projeto", "Componente", "Título", "Detalhamento", "Status"]
        expected_lower = [c.lower() for c in expected]
        actual_lower = [c.lower().strip() for c in reader.fieldnames]

        field_map = {}
        if actual_lower != expected_lower:
            for exp in expected:
                for act in reader.fieldnames:
                    if exp.lower() == act.lower().strip():
                        field_map[exp] = act
                        break
            if len(field_map) != len(expected):
                missing = set(expected) - set(field_map.keys())
                return 0, [f"Colunas obrigatórias não encontradas: {missing}"]
        else:
            field_map = {c: c for c in expected}

        for row_num, row in enumerate(reader, start=2):
            try:
                item_str = row.get(field_map["Item"], "").strip()
                if not item_str:
                    errors.append(f"Linha {row_num}: 'Item' vazio")
                    continue

                item = int(item_str)
                projeto = row.get(field_map["Projeto"], "").strip()
                componente = row.get(field_map["Componente"], "").strip()
                titulo = row.get(field_map["Título"], "").strip()
                detalhamento = row.get(field_map["Detalhamento"], "").strip() or None
                status = row.get(field_map["Status"], "Backlog").strip()

                status = _normalize_status(status)

                if not projeto or not componente or not titulo:
                    errors.append(f"Linha {row_num}: campos obrigatórios vazios")
                    continue

                conn = get_connection()
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO backlog (item, projeto, componente, titulo, detalhamento, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (item, projeto, componente, titulo, detalhamento, status))
                conn.commit()
                conn.close()
                imported += 1

            except ValueError as e:
                errors.append(f"Linha {row_num}: erro de conversão - {e}")
            except Exception as e:
                errors.append(f"Linha {row_num}: erro inesperado - {e}")

    except Exception as e:
        errors.append(f"Erro ao processar CSV: {e}")

    return imported, errors


def clear_all_items() -> None:
    """Remove todos os itens do backlog."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM backlog")
    conn.commit()
    conn.close()
