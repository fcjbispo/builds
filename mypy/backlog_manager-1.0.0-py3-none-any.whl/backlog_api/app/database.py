"""Configuração de banco de dados SQLite com WAL para concorrência."""

from __future__ import annotations

import sqlite3
from pathlib import Path

# Banco na raiz do projeto
DB_PATH = Path(__file__).resolve().parents[3] / "backlog.db"


def get_connection() -> sqlite3.Connection:
    """Retorna conexão com SQLite configurado para concorrência."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    
    # WAL mode: permite leitura concorrente com gravação
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    
    return conn


def init_database() -> None:
    """Cria tabela se não existir e migra dados legados."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS backlog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item INTEGER NOT NULL,
            projeto TEXT NOT NULL,
            componente TEXT NOT NULL,
            titulo TEXT NOT NULL,
            detalhamento TEXT,
            status TEXT NOT NULL DEFAULT 'Backlog'
        )
    """)

    # Migrações de status legados
    LEGACY_MAP = {
        "Aberto": "Backlog",
        "A Fazer": "Backlog",
        "Feito": "Concluído",
    }
    for old, new in LEGACY_MAP.items():
        cursor.execute(
            "UPDATE backlog SET status = ? WHERE status = ?",
            (new, old)
        )

    # Corrige status inválidos
    VALID_STATUSES = ["Backlog", "Em Andamento", "Em Revisão", "Concluído"]
    placeholders = ",".join(["?" for _ in VALID_STATUSES])
    cursor.execute(f"""
        UPDATE backlog SET status = 'Backlog'
        WHERE status NOT IN ({placeholders})
    """, VALID_STATUSES)

    conn.commit()
    conn.close()
