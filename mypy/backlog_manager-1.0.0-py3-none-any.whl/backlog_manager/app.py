"""Backlog Manager - Frontend Streamlit consumindo API REST."""

from __future__ import annotations

import csv
import io
from typing import Any

import httpx
import pandas as pd
import plotly.express as px
import streamlit as st

# ============================================================
# CONFIGURAÇÕES
# ============================================================

API_BASE_URL = "http://127.0.0.1:8833"

STATUS_OPTIONS = ["Backlog", "Em Andamento", "Em Revisão", "Concluído"]

STATUS_COLORS = {
    "Backlog": "#9ca3af",
    "Em Andamento": "#f59e0b",
    "Em Revisão": "#8b5cf6",
    "Concluído": "#22c55e",
}

STATUS_EMOJIS = {
    "Backlog": "⚪",
    "Em Andamento": "🟡",
    "Em Revisão": "🟣",
    "Concluído": "🟢",
}

SORTABLE_COLUMNS = {
    "id": "ID",
    "item": "Item",
    "projeto": "Projeto",
    "componente": "Componente",
    "titulo": "Título",
    "status": "Status",
}

CSV_COLUMNS = ["Item", "Projeto", "Componente", "Título", "Detalhamento", "Status"]


# ============================================================
# CLIENTE HTTP
# ============================================================

def api_get(path: str, params: dict | None = None) -> Any:
    """Faz requisição GET para a API."""
    try:
        response = httpx.get(f"{API_BASE_URL}{path}", params=params, timeout=30.0)
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        st.error("🔴 API não está respondendo. Verifique se o servidor está rodando em http://127.0.0.1:8833")
        st.stop()
    except httpx.HTTPStatusError as e:
        st.error(f"🔴 Erro na API: {e.response.status_code} - {e.response.text}")
        raise


def api_post(path: str, json: dict | None = None) -> Any:
    """Faz requisição POST para a API."""
    response = httpx.post(f"{API_BASE_URL}{path}", json=json, timeout=30.0)
    response.raise_for_status()
    return response.json()


def api_put(path: str, json: dict) -> Any:
    """Faz requisição PUT para a API."""
    response = httpx.put(f"{API_BASE_URL}{path}", json=json, timeout=30.0)
    response.raise_for_status()
    return response.json()


def api_delete(path: str) -> None:
    """Faz requisição DELETE para a API."""
    response = httpx.delete(f"{API_BASE_URL}{path}", timeout=30.0)
    response.raise_for_status()


# ============================================================
# INICIALIZAÇÃO DE ESTADO
# ============================================================

def init_session_state() -> None:
    """Inicializa variáveis de estado da sessão."""
    defaults = {
        "editing_id": None,
        "show_form": False,
        "import_success": False,
        "import_count": 0,
        "last_action": None,
        "sort_stack": [("projeto", True), ("item", True)],
        "expanded_details": set(),
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


# ============================================================
# ORDENAÇÃO CUMULATIVA
# ============================================================

def apply_sorting(df: pd.DataFrame) -> pd.DataFrame:
    """Aplica ordenação cumulativa configurada no estado da sessão."""
    if len(df) == 0:
        return df
    
    sort_stack = st.session_state.sort_stack
    
    if not sort_stack:
        return df
    
    sort_cols = [col for col, _ in sort_stack]
    sort_asc = [asc for _, asc in sort_stack]
    
    if "id" not in sort_cols:
        sort_cols.append("id")
        sort_asc.append(True)
    
    return df.sort_values(by=sort_cols, ascending=sort_asc)


def get_column_sort_state(column: str) -> tuple[bool, int] | None:
    """Retorna (ascendente, índice_na_pilha) ou None se não está no stack."""
    for idx, (col, asc) in enumerate(st.session_state.sort_stack):
        if col == column:
            return (asc, idx + 1)
    return None


def toggle_sort(column: str) -> None:
    """Gerencia ordenação cumulativa: add up → toggle down → remove."""
    stack = st.session_state.sort_stack
    
    found_idx = None
    for idx, (col, _) in enumerate(stack):
        if col == column:
            found_idx = idx
            break
    
    if found_idx is None:
        stack.append((column, True))
    else:
        _, current_asc = stack[found_idx]
        if current_asc:
            stack[found_idx] = (column, False)
        else:
            stack.pop(found_idx)
    
    st.session_state.sort_stack = stack


def reset_sort() -> None:
    """Reseta ordenação para o padrão."""
    st.session_state.sort_stack = [("projeto", True), ("item", True)]


def get_sort_icon(column: str) -> str:
    """Retorna ícone de ordenação para a coluna."""
    state = get_column_sort_state(column)
    if state is None:
        return ""
    
    asc, order = state
    arrow = "▲" if asc else "▼"
    return f"{arrow}{order}"


def get_sort_button_type(column: str) -> str:
    """Retorna tipo do botão baseado no estado da coluna."""
    state = get_column_sort_state(column)
    if state is None:
        return "secondary"
    return "primary"


def format_sort_summary() -> str:
    """Formata resumo da ordenação atual para exibição."""
    stack = st.session_state.sort_stack
    
    if not stack:
        return "Nenhuma ordenação ativa"
    
    parts = []
    for col, asc in stack:
        direction = "↑" if asc else "↓"
        parts.append(f"{SORTABLE_COLUMNS.get(col, col)} {direction}")
    
    return " → ".join(parts)


# ============================================================
# EXPANSÃO DE DETALHES
# ============================================================

def toggle_detail(item_id: int) -> None:
    """Alterna visibilidade do detalhamento de um item."""
    expanded = st.session_state.expanded_details
    if item_id in expanded:
        expanded.discard(item_id)
    else:
        expanded.add(item_id)
    st.session_state.expanded_details = expanded


def expand_all_details(item_ids: list[int]) -> None:
    """Expande todos os detalhes visíveis."""
    st.session_state.expanded_details = set(item_ids)


def collapse_all_details() -> None:
    """Colapsa todos os detalhes."""
    st.session_state.expanded_details = set()


def is_detail_expanded(item_id: int) -> bool:
    """Verifica se detalhe de um item está expandido."""
    return item_id in st.session_state.expanded_details


# ============================================================
# CALLBACKS PARA BOTÕES
# ============================================================

def cb_new_item() -> None:
    """Callback: prepara formulário para novo item."""
    st.session_state.editing_id = None
    st.session_state.show_form = True


def cb_edit_item(id_: int) -> None:
    """Callback: prepara formulário para edição."""
    st.session_state.editing_id = id_
    st.session_state.show_form = True


def cb_delete_item(id_: int) -> None:
    """Callback: exclui item via API."""
    try:
        api_delete(f"/items/{id_}")
        st.session_state.last_action = f"Item #{id_} excluído"
    except httpx.HTTPStatusError:
        st.session_state.last_action = f"Erro ao excluir item #{id_}"
    st.session_state.show_form = False
    st.session_state.editing_id = None
    st.session_state.expanded_details.discard(id_)


def cb_cancel_form() -> None:
    """Callback: fecha formulário sem salvar."""
    st.session_state.show_form = False
    st.session_state.editing_id = None


# ============================================================
# INTERFACE: FORMULÁRIO DE EDIÇÃO/NOVO
# ============================================================

def render_form() -> None:
    """Renderiza formulário de edição ou novo item."""
    
    is_new = st.session_state.editing_id is None
    
    if is_new:
        st.subheader("➕ Novo Item")
        item_num_default = 1
        status_default = "Backlog"
        proj_default = ""
        comp_default = ""
        titulo_default = ""
        detalhamento_default = ""
    else:
        st.subheader("✏️ Editar Item")
        try:
            item_row = api_get(f"/items/{st.session_state.editing_id}")
        except httpx.HTTPStatusError:
            st.error("Item não encontrado!")
            st.session_state.show_form = False
            st.session_state.editing_id = None
            st.rerun()
            return
        
        item_num_default = int(item_row["item"])
        status_default = item_row["status"]
        proj_default = item_row["projeto"]
        comp_default = item_row["componente"]
        titulo_default = item_row["titulo"]
        detalhamento_default = item_row["detalhamento"] or ""
    
    # Busca metadados da API
    projects = api_get("/items/meta/projects")
    components = api_get("/items/meta/components")
    
    with st.form("item_form", clear_on_submit=False):
        col1, col2 = st.columns(2)
        with col1:
            item_num = st.number_input("Número do Item", min_value=1, step=1, value=item_num_default)
        with col2:
            status = st.selectbox(
                "Status",
                STATUS_OPTIONS,
                index=STATUS_OPTIONS.index(status_default) if status_default in STATUS_OPTIONS else 0
            )
        
        # Projeto
        st.write("**Projeto**")
        use_new_proj = st.checkbox("Criar novo projeto", value=False, key="form_new_proj")
        if use_new_proj:
            projeto = st.text_input("Nome do novo projeto", value=proj_default or "")
        else:
            try:
                proj_idx = projects.index(proj_default) if proj_default in projects else 0
            except ValueError:
                proj_idx = 0
            projeto = st.selectbox(
                "Selecione o projeto",
                projects if projects else ["(nenhum projeto ainda)"],
                index=proj_idx if projects else 0,
                key="form_proj"
            )
        
        # Componente
        st.write("**Componente**")
        use_new_comp = st.checkbox("Criar novo componente", value=False, key="form_new_comp")
        if use_new_comp:
            componente = st.text_input("Nome do novo componente", value=comp_default or "")
        else:
            try:
                comp_idx = components.index(comp_default) if comp_default in components else 0
            except ValueError:
                comp_idx = 0
            componente = st.selectbox(
                "Selecione o componente",
                components if components else ["(nenhum componente ainda)"],
                index=comp_idx if components else 0,
                key="form_comp"
            )
        
        titulo = st.text_input("Título *", value=titulo_default)
        detalhamento = st.text_area("Detalhamento", value=detalhamento_default)
        
        col_save, col_cancel = st.columns(2)
        with col_save:
            submitted = st.form_submit_button("💾 Salvar", type="primary", use_container_width=True)
        with col_cancel:
            cancelled = st.form_submit_button("❌ Cancelar", use_container_width=True)
        
        if cancelled:
            cb_cancel_form()
            st.rerun()
        
        if submitted:
            if not projeto or not componente or not titulo:
                st.error("Preencha todos os campos obrigatórios (*)!")
                st.stop()
            
            payload = {
                "item": item_num,
                "projeto": projeto,
                "componente": componente,
                "titulo": titulo,
                "detalhamento": detalhamento or None,
                "status": status,
            }
            
            try:
                if is_new:
                    api_post("/items", json=payload)
                    st.session_state.last_action = f"Item #{item_num} criado com sucesso!"
                else:
                    api_put(f"/items/{st.session_state.editing_id}", json=payload)
                    st.session_state.last_action = f"Item #{item_num} atualizado com sucesso!"
            except httpx.HTTPStatusError as e:
                st.error(f"Erro ao salvar: {e.response.text}")
                st.stop()
            
            st.session_state.show_form = False
            st.session_state.editing_id = None
            st.rerun()


# ============================================================
# INTERFACE: TABELA COM ORDENAÇÃO, AÇÕES E EXPANSÃO
# ============================================================

def render_sortable_header() -> None:
    """Renderiza cabeçalho de tabela com botões de ordenação cumulativa."""
    
    col_widths = [0.5, 0.6, 1.0, 0.9, 2.8, 0.8, 1.4]
    cols = st.columns(col_widths)
    
    header_defs = [
        ("id", "ID"),
        ("item", "Item"),
        ("projeto", "Projeto"),
        ("componente", "Componente"),
        ("titulo", "Título"),
        ("status", "Status"),
        (None, "Ações"),
    ]
    
    for col, col_key, label in zip(cols, [d[0] for d in header_defs], [d[1] for d in header_defs]):
        with col:
            if col_key is None:
                st.markdown(f"**{label}**")
            else:
                icon = get_sort_icon(col_key)
                btn_label = f"{label} {icon}".strip()
                btn_type = get_sort_button_type(col_key)
                
                st.button(
                    btn_label,
                    key=f"sort_{col_key}",
                    on_click=toggle_sort,
                    args=(col_key,),
                    use_container_width=True,
                    type=btn_type,
                )


def render_data_table(df: pd.DataFrame) -> None:
    """Renderiza tabela de dados com ordenação, ações e expansão de detalhes."""
    
    if len(df) == 0:
        st.info("Nenhum item encontrado. Clique em ➕ para adicionar.")
        return
    
    df_sorted = apply_sorting(df)
    
    # Botões globais de expandir/colapsar
    all_ids = df_sorted["id"].tolist()
    has_expanded = len(st.session_state.expanded_details) > 0
    
    col_expand, col_collapse, _ = st.columns([0.15, 0.15, 0.7])
    with col_expand:
        st.button("📖 Expandir todos", on_click=expand_all_details, args=(all_ids,),
                  disabled=len(all_ids) == 0, use_container_width=True)
    with col_collapse:
        st.button("📕 Colapsar todos", on_click=collapse_all_details,
                  disabled=not has_expanded, use_container_width=True)
    
    st.divider()
    
    # Cabeçalho ordenável
    render_sortable_header()
    
    st.divider()
    
    # Linhas de dados
    for _, row in df_sorted.iterrows():
        item_id = int(row["id"])
        is_expanded = is_detail_expanded(item_id)
        status = row["status"]
        status_emoji = STATUS_EMOJIS.get(status, "⚪")
        status_color = STATUS_COLORS.get(status, "#9ca3af")
        has_detail = bool(row["detalhamento"] and str(row["detalhamento"]).strip())
        
        # Linha principal de dados
        cols = st.columns([0.5, 0.6, 1.0, 0.9, 2.8, 0.8, 1.4])
        
        cols[0].text(item_id)
        cols[1].text(int(row["item"]))
        cols[2].text(row["projeto"])
        cols[3].text(row["componente"])
        cols[4].text(row["titulo"][:50] + "..." if len(row["titulo"]) > 50 else row["titulo"])
        
        # Status com cor personalizada
        with cols[5]:
            st.markdown(
                f"<span style='color: {status_color}; font-weight: bold;'>{status_emoji} {status}</span>",
                unsafe_allow_html=True
            )
        
        with cols[6]:
            btn_cols = st.columns([1, 1, 1])
            
            with btn_cols[0]:
                detail_icon = "📄" if is_expanded else "📃"
                detail_help = "Colapsar detalhes" if is_expanded else "Expandir detalhes"
                st.button(
                    detail_icon,
                    key=f"detail_{item_id}",
                    help=detail_help,
                    on_click=toggle_detail,
                    args=(item_id,),
                    disabled=not has_detail,
                )
            
            with btn_cols[1]:
                st.button("✏️", key=f"edit_{item_id}", help="Editar",
                         on_click=cb_edit_item, args=(item_id,))
            
            with btn_cols[2]:
                st.button("🗑️", key=f"del_{item_id}", help="Excluir",
                         on_click=cb_delete_item, args=(item_id,))
        
        # Linha expandida com detalhamento em markdown
        if is_expanded and has_detail:
            with st.container():
                st.markdown("---")
                detail_cols = st.columns([0.5, 11.5])
                with detail_cols[1]:
                    st.markdown("#### 📝 Detalhamento")
                    st.markdown(row["detalhamento"])
                st.markdown("---")
        
        st.divider()
    
    # Resumo da ordenação atual
    st.caption(f"**Ordenação:** {format_sort_summary()}")
    
    col_reset, _ = st.columns([0.15, 0.85])
    with col_reset:
        st.button("🔄 Resetar ordenação", on_click=reset_sort, use_container_width=True)


# ============================================================
# STREAMLIT SETUP
# ============================================================

st.set_page_config(page_title="Backlog Manager", layout="wide")
init_session_state()


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("📋 Backlog Manager")
page = st.sidebar.radio("Menu", ["Dashboard", "Gerenciar Itens", "Importar / Exportar"])


# ============================================================
# PÁGINA: DASHBOARD
# ============================================================

if page == "Dashboard":
    st.title("📊 Dashboard")

    # Busca dados da API
    try:
        stats = api_get("/items/dashboard/stats")
    except Exception:
        st.stop()

    # Métricas globais
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total de Itens", stats["total"])
    col2.metric("Em Andamento", stats["em_andamento"])
    col3.metric("Concluídos", stats["concluidos"])
    col4.metric("Projetos", stats["projetos"])

    # Barra de progresso do fluxo
    st.divider()
    st.subheader("Fluxo do Backlog")
    
    status_counts = {s["status"]: s["count"] for s in stats["por_status"]}
    total = stats["total"]
    
    if total > 0:
        progress_cols = st.columns(len(STATUS_OPTIONS))
        for i, status in enumerate(STATUS_OPTIONS):
            count = status_counts.get(status, 0)
            pct = (count / total) * 100
            
            with progress_cols[i]:
                st.metric(
                    label=f"{STATUS_EMOJIS[status]} {status}",
                    value=f"{count}",
                    delta=f"{pct:.1f}%" if count > 0 else None
                )
                st.progress(int(pct) if pct > 0 else 0, text=None)

    st.divider()

    if stats["total"] == 0:
        st.info("Nenhum item cadastrado. Use 'Gerenciar Itens' para adicionar ou 'Importar / Exportar' para carregar dados.")
    else:
        # Busca todos os itens para gráficos
        response = api_get("/items")
        df = pd.DataFrame(response["items"])
        
        # Gráfico: Itens por Projeto
        st.subheader("Itens por Projeto")
        proj_counts = df.groupby(["projeto", "status"]).size().reset_index(name="quantidade")
        fig_proj = px.bar(
            proj_counts,
            x="projeto",
            y="quantidade",
            color="status",
            barmode="group",
            color_discrete_map=STATUS_COLORS,
            category_orders={"status": STATUS_OPTIONS},
            labels={"projeto": "Projeto", "quantidade": "Quantidade", "status": "Status"}
        )
        st.plotly_chart(fig_proj, use_container_width=True)

        # Gráfico: Itens por Componente
        st.subheader("Itens por Componente")
        comp_counts = df.groupby(["componente", "status"]).size().reset_index(name="quantidade")
        fig_comp = px.bar(
            comp_counts,
            x="componente",
            y="quantidade",
            color="status",
            barmode="group",
            color_discrete_map=STATUS_COLORS,
            category_orders={"status": STATUS_OPTIONS},
            labels={"componente": "Componente", "quantidade": "Quantidade", "status": "Status"}
        )
        st.plotly_chart(fig_comp, use_container_width=True)

        # Gráfico: Distribuição por Status (Pizza)
        st.subheader("Distribuição por Status")
        status_counts_df = df["status"].value_counts().reset_index()
        status_counts_df.columns = ["status", "quantidade"]
        for s in STATUS_OPTIONS:
            if s not in status_counts_df["status"].values:
                status_counts_df = pd.concat([
                    status_counts_df,
                    pd.DataFrame({"status": [s], "quantidade": [0]})
                ], ignore_index=True)
        
        fig_pie = px.pie(
            status_counts_df,
            values="quantidade",
            names="status",
            color="status",
            color_discrete_map=STATUS_COLORS,
            category_orders={"status": STATUS_OPTIONS},
        )
        st.plotly_chart(fig_pie, use_container_width=True)


# ============================================================
# PÁGINA: GERENCIAR ITENS
# ============================================================

elif page == "Gerenciar Itens":
    st.title("📋 Gerenciar Itens")

    # Feedback de ação anterior
    if st.session_state.last_action:
        st.success(f"✅ {st.session_state.last_action}")
        st.session_state.last_action = None

    # ── BOTÃO NOVO ──
    st.button("➕ Novo Item", type="primary", on_click=cb_new_item,
              disabled=st.session_state.show_form)

    st.divider()

    # ── FORMULÁRIO DE EDIÇÃO/NOVO ──
    if st.session_state.show_form:
        render_form()
        st.divider()

    # ── FILTROS E TABELA ──
    try:
        response = api_get("/items")
        df = pd.DataFrame(response["items"])
    except Exception:
        st.stop()

    if len(df) > 0:
        st.subheader("Filtros")
        col1, col2, col3 = st.columns(3)
        with col1:
            projects = api_get("/items/meta/projects")
            proj_filter = st.selectbox("Projeto", ["Todos"] + projects, key="filter_proj")
        with col2:
            components = api_get("/items/meta/components")
            comp_filter = st.selectbox("Componente", ["Todos"] + components, key="filter_comp")
        with col3:
            status_filter = st.selectbox("Status", ["Todos"] + STATUS_OPTIONS, key="filter_status")

        # Aplicar filtros localmente (já temos os dados)
        filtered = df.copy()
        if proj_filter != "Todos":
            filtered = filtered[filtered["projeto"] == proj_filter]
        if comp_filter != "Todos":
            filtered = filtered[filtered["componente"] == comp_filter]
        if status_filter != "Todos":
            filtered = filtered[filtered["status"] == status_filter]

        st.write(f"**{len(filtered)}** itens encontrados")
        st.divider()

        # ── TABELA ORDENÁVEL COM AÇÕES E EXPANSÃO ──
        render_data_table(filtered)
    else:
        st.info("Nenhum item cadastrado. Clique em ➕ Novo Item para começar.")


# ============================================================
# PÁGINA: IMPORTAR / EXPORTAR
# ============================================================

elif page == "Importar / Exportar":
    st.title("📁 Importar / Exportar CSV")

    # ── EXPORTAR ──
    st.header("⬇️ Exportar")
    
    try:
        response = api_get("/items")
        total_items = response["total"]
    except Exception:
        st.stop()
    
    if total_items == 0:
        st.info("Nenhum dado para exportar.")
    else:
        col1, col2 = st.columns(2)
        with col1:
            st.write(f"**{total_items}** itens disponíveis")
            
            # Busca CSV da API
            try:
                export_resp = api_get("/items/export/csv")
                csv_data = export_resp["content"]
            except Exception:
                st.stop()
            
            st.download_button(
                label="📥 Baixar Backlog.csv",
                data=csv_data,
                file_name="Backlog.csv",
                mime="text/csv",
                type="primary",
            )
        with col2:
            st.write("Visualização prévia:")
            df = pd.DataFrame(response["items"])
            preview_df = df[["item", "projeto", "componente", "titulo", "status"]].head(5)
            preview_df.columns = ["Item", "Projeto", "Componente", "Título", "Status"]
            st.dataframe(preview_df, hide_index=True)

    st.divider()

    # ── IMPORTAR ──
    st.header("⬆️ Importar")

    # Template para download
    st.write("Não tem um arquivo? Baixe o template:")
    template_lines = [",".join([f'"{c}"' for c in CSV_COLUMNS])]
    template_lines.append('"1","MeuProjeto","core","Exemplo de título","Descrição detalhada","Backlog"')
    template = "\n".join(template_lines) + "\n"
    
    st.download_button(
        label="📄 Baixar template vazio",
        data=template,
        file_name="Backlog_template.csv",
        mime="text/csv",
    )

    st.divider()

    # Feedback de importação anterior
    if st.session_state.import_success:
        st.success(f"✅ Importação concluída! **{st.session_state.import_count}** itens importados.")
        st.session_state.import_success = False
        st.session_state.import_count = 0

    # Upload do arquivo
    uploaded_file = st.file_uploader(
        "Selecione o arquivo CSV",
        type=["csv"],
        help="O arquivo deve conter as colunas: Item, Projeto, Componente, Título, Detalhamento, Status"
    )

    if uploaded_file is not None:
        csv_content = uploaded_file.getvalue().decode("utf-8")
        
        # Mostra prévia
        st.subheader("Pré-visualização do arquivo")
        try:
            preview = pd.read_csv(io.StringIO(csv_content))
            st.dataframe(preview.head(10), hide_index=True)
            st.write(f"Total de linhas no arquivo: **{len(preview)}**")
        except Exception as e:
            st.error(f"Erro ao ler preview: {e}")
            st.stop()

        st.divider()

        # Opções de importação
        st.subheader("Opções de importação")
        
        import_mode = st.radio(
            "Modo de importação",
            ["Substituir tudo (apaga dados atuais)", "Adicionar aos existentes (append)"],
            index=0,
            key="import_mode"
        )
        append = import_mode == "Adicionar aos existentes (append)"

        if not append and total_items > 0:
            st.warning(f"⚠️ Isso irá **apagar {total_items} itens** existentes!")

        # Confirmação e importação
        if st.button("🚀 Executar Importação", type="primary", key="btn_import"):
            with st.spinner("Importando..."):
                try:
                    result = api_post("/items/import/csv", json={
                        "csv_content": csv_content,
                        "append": append,
                    })
                except Exception:
                    st.stop()

            # Armazena resultado no estado
            st.session_state.import_success = result["success"]
            st.session_state.import_count = result["imported"]

            if result["imported"] > 0:
                st.success(f"✅ **{result['imported']}** itens importados com sucesso!")
            
            if result["errors"]:
                st.error(f"⚠️ **{len(result['errors'])}** erro(s) encontrado(s):")
                with st.expander("Ver detalhes dos erros"):
                    for err in result["errors"]:
                        st.write(f"- {err}")
            
            if result["imported"] == 0 and not result["errors"]:
                st.warning("Nenhum item foi importado. Verifique o formato do arquivo.")
            
            st.session_state.pop("file_uploader", None)
            st.rerun()
