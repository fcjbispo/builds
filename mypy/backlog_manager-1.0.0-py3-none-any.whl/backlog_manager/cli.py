"""Backlog Manager CLI — Gerencia build, execução e ciclo de vida do container."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

import typer
from typing_extensions import Annotated


def _get_version() -> str:
    """Lê a versão do pyproject.toml."""
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    if pyproject_path.exists():
        with pyproject_path.open("rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("version", "unknown")
    return "unknown"

# ---------------------------------------------------------------------------
# Constantes
# ---------------------------------------------------------------------------

APP_NAME = "backlog-manager"
IMAGE_NAME = "backlog-manager"
IMAGE_TAG = "latest"
CONTAINER_NAME = "backlog-manager"
API_PORT = 8833
WEB_PORT = 8834
DATA_DIR = Path.cwd()

GREEN = typer.colors.GREEN
YELLOW = typer.colors.YELLOW
BLUE = typer.colors.BLUE
RED = typer.colors.RED

SYSTEMD_USER_DIR = Path.home() / ".config" / "systemd" / "user"
SYSTEMD_SERVICE_NAME = f"{CONTAINER_NAME}.service"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _info(msg: str) -> None:
    typer.secho(f"[INFO] {msg}", fg=BLUE)


def _ok(msg: str) -> None:
    typer.secho(f"[OK] {msg}", fg=GREEN)


def _warn(msg: str) -> None:
    typer.secho(f"[AVISO] {msg}", fg=YELLOW, err=True)


def _err(msg: str) -> None:
    typer.secho(f"[ERRO] {msg}", fg=RED, err=True)


def _run(cmd: list[str], check: bool = True, capture: bool = False) -> str:
    """Executa comando via subprocess."""
    result = subprocess.run(
        cmd,
        check=check,
        capture_output=capture,
        text=True,
    )
    return result.stdout.strip() if capture else ""


def _check_podman() -> None:
    """Verifica se o Podman está instalado."""
    if not shutil.which("podman"):
        _err("Podman não encontrado. Instale com: sudo dnf install podman")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Comandos
# ---------------------------------------------------------------------------

app = typer.Typer(
    name=APP_NAME,
    help="CLI para gerenciar o Backlog Manager via Podman.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"{APP_NAME} {_get_version()}")
        raise typer.Exit()


@app.callback()
def _main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Mostra a versão e sai.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    """Callback para opções globais."""
    pass


@app.command()
def build() -> None:
    """Build da imagem Podman."""
    _check_podman()
    _info(f"Build da imagem {IMAGE_NAME}:{IMAGE_TAG}...")
    try:
        _run(["podman", "build", "-t", f"{IMAGE_NAME}:{IMAGE_TAG}", "."])
        _ok("Build concluído!")
    except subprocess.CalledProcessError as e:
        _err(f"Build falhou: {e}")
        raise typer.Exit(1)


@app.command()
def run(
    api_port: Annotated[int, typer.Option("--api-port", help="Porta da API")] = API_PORT,
    web_port: Annotated[int, typer.Option("--web-port", help="Porta do Streamlit")] = WEB_PORT,
) -> None:
    """Executa container com API + Streamlit."""
    _check_podman()
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    # Remove container anterior se existir
    if _container_exists():
        _warn("Removendo container anterior...")
        _run(["podman", "rm", "-f", CONTAINER_NAME], check=False)

    _info("Iniciando container...")
    _info(f"API: http://localhost:{api_port}")
    _info(f"Web: http://localhost:{web_port}")

    try:
        _run(
            [
                "podman", "run",
                "--detach",
                "--name", CONTAINER_NAME,
                "--publish", f"{api_port}:{api_port}",
                "--publish", f"{web_port}:{web_port}",
                "--volume", f"{DATA_DIR}/backlog.db:/app/backlog.db:Z",
                "--restart", "unless-stopped",
                f"{IMAGE_NAME}:{IMAGE_TAG}",
            ]
        )
        _ok("Container iniciado!")
        # Breve pausa para o container subir
        import time
        time.sleep(2)
        _run(
            [
                "podman", "ps",
                "--filter", f"name={CONTAINER_NAME}",
                "--format", "table {{.Names}}\t{{.Status}}\t{{.Ports}}",
            ]
        )
    except subprocess.CalledProcessError as e:
        _err(f"Falha ao iniciar container: {e}")
        raise typer.Exit(1)


@app.command()
def api(
    port: Annotated[int, typer.Option("--port", "-p", help="Porta da API")] = API_PORT,
    host: Annotated[str, typer.Option("--host", "-h", help="Host para bind")] = "127.0.0.1",
) -> None:
    """Roda só a API localmente (sem container)."""
    _info(f"Iniciando API local em http://{host}:{port}")
    try:
        os.execvp(
            "uv",
            [
                "uv", "run", "uvicorn", "backlog_api.app.main:app",
                "--host", host,
                "--port", str(port),
                "--reload",
                "--log-level", "info",
            ],
        )
    except FileNotFoundError:
        _err("Comando 'uv' não encontrado. Instale o uv.")
        raise typer.Exit(1)


@app.command()
def web(
    port: Annotated[int, typer.Option("--port", "-p", help="Porta do Streamlit")] = WEB_PORT,
    host: Annotated[str, typer.Option("--host", "-h", help="Host para bind")] = "0.0.0.0",
    api_url: Annotated[str, typer.Option("--api-url", help="URL da API")] = "http://127.0.0.1:8833",
) -> None:
    """Roda só o Streamlit localmente (precisa da API)."""
    _warn(f"Certifique-se de que a API está rodando em {api_url}")
    _info(f"Iniciando Streamlit em http://{host}:{port}")
    env = os.environ.copy()
    env["API_BASE_URL"] = api_url
    try:
        os.execvpe(
            "uv",
            [
                "uv", "run", "streamlit", "run", "src/backlog_manager/app.py",
                f"--server.port={port}",
                f"--server.address={host}",
            ],
            env,
        )
    except FileNotFoundError:
        _err("Comando 'uv' não encontrado. Instale o uv.")
        raise typer.Exit(1)


@app.command()
def stop() -> None:
    """Para o container."""
    if _container_exists():
        _run(["podman", "stop", CONTAINER_NAME])
        _ok("Container parado.")
    else:
        _warn("Container não está rodando.")


@app.command()
def logs(
    follow: Annotated[bool, typer.Option("--follow", "-f", help="Acompanhar logs em tempo real")] = False,
    tail: Annotated[int, typer.Option("--tail", "-n", help="Número de linhas no final")] = 100,
) -> None:
    """Mostra logs do container."""
    if not _container_exists():
        _warn("Container não encontrado.")
        return
    cmd = ["podman", "logs", f"--tail={tail}"]
    if follow:
        cmd.append("--follow")
    cmd.append(CONTAINER_NAME)
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        typer.echo()


@app.command()
def clean() -> None:
    """Remove container e imagem."""
    _check_podman()

    if _container_exists():
        _run(["podman", "rm", "-f", CONTAINER_NAME], check=False)
        _ok("Container removido.")
    else:
        _warn("Nenhum container para remover.")

    if _image_exists():
        _run(["podman", "rmi", f"{IMAGE_NAME}:{IMAGE_TAG}"], check=False)
        _ok("Imagem removida.")
    else:
        _warn("Nenhuma imagem para remover.")


@app.command()
def clean_db(
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Confirma sem prompt")] = False,
) -> None:
    """Remove o banco de dados local (backlog.db)."""
    db_path = DATA_DIR / "backlog.db"

    if not db_path.exists():
        _warn("Nenhum banco de dados local encontrado.")
        return

    if not confirm:
        _warn(f"Isso irá apagar permanentemente: {db_path}")
        choice = typer.prompt("Tem certeza? [s/N]", default="N")
        if choice.lower() not in ("s", "sim", "y", "yes"):
            _info("Operação cancelada.")
            return

    try:
        db_path.unlink()
        _ok("Banco de dados local removido.")
    except OSError as e:
        _err(f"Falha ao remover banco de dados: {e}")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Systemd user service
# ---------------------------------------------------------------------------

def _container_exists() -> bool:
    """Verifica se o container existe."""
    result = subprocess.run(
        ["podman", "container", "exists", CONTAINER_NAME],
        capture_output=True,
    )
    return result.returncode == 0


def _image_exists() -> bool:
    """Verifica se a imagem existe."""
    result = subprocess.run(
        ["podman", "image", "exists", f"{IMAGE_NAME}:{IMAGE_TAG}"],
        capture_output=True,
    )
    return result.returncode == 0


SYSTEMD_SERVICE_TEMPLATE = """[Unit]
Description=Backlog Manager (Podman)
After=network-online.target
Wants=network-online.target

[Service]
Restart=always
ExecStartPre=-/usr/bin/podman rm -f {container_name}
ExecStart=/usr/bin/podman run \\
    --name {container_name} \\
    --publish {api_port}:{api_port} \\
    --publish {web_port}:{web_port} \\
    --volume {data_dir}/backlog.db:/app/backlog.db:Z \\
    --restart unless-stopped \\
    {image_name}:{image_tag}
ExecStop=/usr/bin/podman stop -t 10 {container_name}
ExecStopPost=-/usr/bin/podman rm -f {container_name}

[Install]
WantedBy=default.target
"""


@app.command()
def enable() -> None:
    """Configura início automático via systemd user."""
    _check_podman()
    SYSTEMD_USER_DIR.mkdir(parents=True, exist_ok=True)

    service_path = SYSTEMD_USER_DIR / SYSTEMD_SERVICE_NAME
    service_content = SYSTEMD_SERVICE_TEMPLATE.format(
        container_name=CONTAINER_NAME,
        image_name=IMAGE_NAME,
        image_tag=IMAGE_TAG,
        api_port=API_PORT,
        web_port=WEB_PORT,
        data_dir=DATA_DIR,
    )
    service_path.write_text(service_content)
    _ok(f"Serviço criado em {service_path}")

    try:
        _run(["systemctl", "--user", "daemon-reload"])
        _run(["systemctl", "--user", "enable", SYSTEMD_SERVICE_NAME])
        _ok("Serviço habilitado para início automático.")
        _info("Use 'systemctl --user start backlog-manager' para iniciar agora.")
    except subprocess.CalledProcessError as e:
        _err(f"Falha ao habilitar serviço: {e}")
        raise typer.Exit(1)


@app.command()
def disable() -> None:
    """Remove início automático via systemd user."""
    service_path = SYSTEMD_USER_DIR / SYSTEMD_SERVICE_NAME
    if not service_path.exists():
        _warn("Serviço systemd não encontrado.")
        return

    try:
        _run(["systemctl", "--user", "stop", SYSTEMD_SERVICE_NAME], check=False)
        _run(["systemctl", "--user", "disable", SYSTEMD_SERVICE_NAME], check=False)
        service_path.unlink()
        _run(["systemctl", "--user", "daemon-reload"])
        _ok("Serviço desabilitado e removido.")
    except subprocess.CalledProcessError as e:
        _err(f"Falha ao desabilitar serviço: {e}")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    app()


if __name__ == "__main__":
    main()
