"""CLI progress/output helpers.

Adapted from MyMailBoard's ``engine/ui.py``. Progress is drawn on **stderr**
so the A10 envelope printed on stdout stays machine-clean (CL-4). In a TTY the
bar redraws in place; when output is redirected it emits 25/50/75/100%
milestones. ``--no-progress`` turns it off; ``--quiet`` silences the milestones.
"""

from __future__ import annotations

import sys
import time

QUIET = False  # set by --quiet
PROGRESS = True  # set by --no-progress


def say(msg: str = "") -> None:
    """Non-critical chatter on stderr (suppressed by --quiet)."""
    if not QUIET:
        print(msg, file=sys.stderr, flush=True)


class Bar:
    """Native determinate progress bar on stderr. ``total`` is required."""

    def __init__(self, total: int, label: str = "") -> None:
        self.total = max(int(total), 1)
        self.n = 0
        self.t0 = time.time()
        self.label = label
        self.tty = sys.stderr.isatty()
        self.marks: set[int] = set()

    def update(self, k: int = 1, extra: str = "") -> None:
        self.n += k
        if not PROGRESS:
            return
        if self.tty:
            frac = self.n / self.total
            width = 28
            fill = int(width * frac)
            elapsed = max(time.time() - self.t0, 0.001)
            rate = self.n / elapsed
            if rate > 0:
                eta_str = f"{(self.total - self.n) / rate:4.0f}s"
            else:
                eta_str = "   —"
            print(
                f'\r  {self.label}[{"█" * fill}{"░" * (width - fill)}] '
                f"{self.n}/{self.total} ({frac * 100:3.0f}%) "
                f"{rate:5.2f}/s {elapsed:5.0f}s ETA {eta_str} {extra:16s}",
                end="",
                file=sys.stderr,
                flush=True,
            )
        else:
            for mark in (25, 50, 75, 100):
                if self.n * 100 >= self.total * mark and mark not in self.marks:
                    self.marks.add(mark)
                    say(f"  {self.label}{mark}% ({self.n}/{self.total})")

    def done(self) -> None:
        if PROGRESS and self.tty:
            self.update(0)
            print(file=sys.stderr, flush=True)


class Progress:
    """Adapts the scan ``(done, total)`` callback to a lazily-built ``Bar``.

    The total is only known once the directory walk finishes, so the bar is
    created on the first callback. ``finish()`` must be called when the
    operation ends to release the line.
    """

    def __init__(self, label: str = "") -> None:
        self.label = label
        self.bar: Bar | None = None

    def callback(self, done: int, total: int) -> None:
        if self.bar is None:
            self.bar = Bar(total, label=self.label)
        self.bar.update(done - self.bar.n)

    def finish(self) -> None:
        if self.bar is not None:
            self.bar.done()


__all__ = ["PROGRESS", "QUIET", "Bar", "Progress", "say"]
