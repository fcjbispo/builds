"""CLI interface for MyLibraryScanner."""

from __future__ import annotations

import argparse
import sys

from mylibraryscanner import __version__
from mylibraryscanner.cli import ui
from mylibraryscanner.cli.commands import (
    cmd_library_add_source,
    cmd_library_describe_source,
    cmd_library_infer_source,
    cmd_library_ingest_source,
    cmd_library_list_sources,
    cmd_library_remove_source,
    cmd_library_search,
    cmd_library_sync_source,
    cmd_run,
    cmd_scan_target,
    cmd_token_create,
    cmd_token_list,
    cmd_token_revoke,
    cmd_token_rotate,
)
from mylibraryscanner.initialization import setup_system


def build_parser() -> argparse.ArgumentParser:
    """Build argparse parser for the modern CLI commands."""
    parser = argparse.ArgumentParser(
        prog="mylibraryscanner",
        description=f"MyLibraryScanner {__version__} — cliente local de ingestão",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress milestones and non-critical output",
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Disable the progress bar (drawn on stderr)",
    )
    subparsers = parser.add_subparsers(dest="command")

    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a file or folder into a SOURCE and output the A10 envelope",
    )
    scan_parser.add_argument("file_or_folder", help="Path to file or folder")
    scan_parser.add_argument(
        "--source_name", "--source-name",
        required=True,
        help="SOURCE name (unique; created implicitly when missing — A1)",
    )
    scan_parser.add_argument(
        "--mode",
        choices=["sync", "append"],
        default="sync",
        help=(
            "sync mirrors the host into the SOURCE (removed files cascade); "
            "append registers only new files (default: sync — A6)"
        ),
    )
    scan_parser.add_argument(
        "--pattern",
        default="*",
        help="File name pattern used when scanning folders (default: *)",
    )
    scan_parser.add_argument(
        "--source-kind", "--source_kind",
        choices=["LOCAL", "REMOVABLE", "CLOUD", "REMOTEFS"],
        default="LOCAL",
        help="Source kind classification (default: LOCAL)",
    )
    scan_parser.add_argument(
        "--parallel",
        action="store_true",
        help="Use parallel workers when scanning folders",
    )
    scan_parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "Prossegue apesar de degradação provável (LOCAL/REMOVABLE sobre mount "
            "de rede, ou mount de rede aninhado) — ADR-0008"
        ),
    )
    scan_parser.add_argument(
        "--max-workers",
        type=int,
        default=None,
        help=(
            "Number of workers for --parallel "
            "(default: auto by source kind; REMOVABLE uses conservative tuning)"
        ),
    )
    scan_parser.add_argument(
        "--infer",
        action="store_true",
        help="Infer concise content summary and topics for new/changed files (A4/D1-a)",
    )
    scan_parser.add_argument(
        "--ingest",
        action="store_true",
        help=(
            "Ingest new/changed files into the KB (chunks 512/64 + embeddings; "
            "depends on inference — same run with --infer or prior inference)"
        ),
    )

    run_parser = subparsers.add_parser(
        "run",
        help="Cadeia de ingestão scan>describe>infer>ingest (ADR-0008)",
    )
    run_parser.add_argument("--source_name", "--source-name", required=True, help="SOURCE name")
    run_parser.add_argument(
        "--path", default=None, help="Path for the initial scan (opcional)"
    )
    run_parser.add_argument(
        "--source-kind", "--source_kind",
        choices=["LOCAL", "REMOVABLE", "CLOUD", "REMOTEFS"],
        default="LOCAL",
    )
    run_parser.add_argument(
        "--ops",
        default="scan,describe,infer,ingest",
        help="Operações (default: scan,describe,infer,ingest)",
    )
    run_parser.add_argument("--limit", type=int, default=None)
    run_parser.add_argument("--overwrite", action="store_true")
    run_parser.add_argument(
        "--force", action="store_true", help="Prossegue apesar de degradação provável"
    )

    library_parser = subparsers.add_parser("library", help="Library management commands")
    library_sub = library_parser.add_subparsers(dest="library_command", required=True)

    list_parser = library_sub.add_parser("list_sources", help="List sources")
    list_parser.add_argument("--pattern", default="*", help="Source name pattern filter")

    add_parser = library_sub.add_parser(
        "add_source",
        help="Registra uma SOURCE sem varrer (kind fixado na criação — ADR-0008)",
    )
    add_parser.add_argument(
        "--source_name", "--source-name", required=True, help="SOURCE name"
    )
    add_parser.add_argument("--path", required=True, help="Path da pasta no host")
    add_parser.add_argument(
        "--source-kind",
        "--source_kind",
        choices=["LOCAL", "REMOVABLE", "CLOUD", "REMOTEFS"],
        default="LOCAL",
        help="Tipo da fonte (default LOCAL)",
    )
    add_parser.add_argument(
        "--force", action="store_true", help="Prossegue apesar de degradação provável"
    )

    remove_parser = library_sub.add_parser("remove_source", help="Remove a source")
    remove_parser.add_argument("--source_name", "--source-name", required=True, help="Source name to remove")
    remove_parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip interactive confirmation",
    )

    describe_parser = library_sub.add_parser(
        "describe_source",
        help="Describe (metadados especializados) os arquivos pendentes (ADR-0008)",
    )
    describe_parser.add_argument("--source_name", "--source-name", required=True, help="Source name")
    describe_parser.add_argument(
        "--limit", type=int, default=None, help="Lote (default: todos os pendentes)"
    )
    describe_parser.add_argument(
        "--overwrite", action="store_true", help="Refaz mesmo os já descritos"
    )

    infer_parser = library_sub.add_parser(
        "infer_source",
        help="Infer content for pending files of an existing source",
    )
    infer_parser.add_argument("--source_name", "--source-name", required=True, help="Source name to infer")
    infer_parser.add_argument(
        "--limit", type=int, default=None, help="Lote (default: todos os pendentes)"
    )
    infer_parser.add_argument(
        "--overwrite", action="store_true", help="Refaz mesmo os já inferidos"
    )

    sync_source_parser = library_sub.add_parser(
        "sync_source",
        help="Sync an existing SOURCE with the host (same semantics as scan --mode sync)",
    )
    sync_source_parser.add_argument(
        "--source_name", "--source-name",
        required=True,
        help="Source name to sync",
    )
    sync_source_parser.add_argument(
        "--infer",
        action="store_true",
        help="Infer content for new/changed files",
    )
    sync_source_parser.add_argument(
        "--ingest",
        action="store_true",
        help=("Ingest synced files into the KB (512/64 chunks + embeddings)"),
    )
    sync_source_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show the buckets without modifying the database",
    )

    ingest_parser = library_sub.add_parser(
        "ingest_source",
        help="Ingest inferable files of a SOURCE into the KB (A8/D9)",
    )
    ingest_parser.add_argument("--source_name", "--source-name", required=True, help="Source name to ingest")
    ingest_parser.add_argument(
        "--pattern",
        default="*",
        help="File pattern filter (default * — pattern overwrites everything on re-ingestion, A9)",
    )
    ingest_parser.add_argument(
        "--limit", type=int, default=None, help="Lote (default: todos os pendentes)"
    )
    ingest_parser.add_argument(
        "--overwrite", action="store_true", help="Refaz mesmo os já ingeridos"
    )

    search_parser = library_sub.add_parser(
        "search",
        help="[DEPRECATED — ADR-0008] Search the KB (A8); consulta fora de escopo, mantido para referência",
    )
    search_parser.add_argument("query", help="Query text (or topic tag for mode topic)")
    search_parser.add_argument(
        "--mode",
        choices=["hybrid", "content", "keyword", "topic"],
        default="hybrid",
        help="hybrid = RRF fusion (default); content = cosine; keyword = ts_rank; topic = tags",
    )
    search_parser.add_argument(
        "--source_name", "--source-name",
        default=None,
        help="Restrict to one SOURCE (default: all sources)",
    )
    search_parser.add_argument(
        "--file-pattern",
        default="*",
        help="Pre-filter on file_path glob (P5)",
    )
    search_parser.add_argument(
        "--mime",
        default=None,
        help="Pre-filter on MIME code/description (P5)",
    )
    search_parser.add_argument("--limit", type=int, default=10, help="Top-K (default 10)")
    search_parser.add_argument("--offset", type=int, default=0, help="Pagination offset")
    search_parser.add_argument(
        "--min-similarity", type=float, default=0.0, help="Minimum score filter (D5)"
    )
    search_parser.add_argument(
        "--export",
        default=None,
        help="Export results: .json (A10), .csv (tabular) or .md (LLM context) — D7",
    )

    token_parser = subparsers.add_parser(
        "token",
        help="[DEPRECATED — ADR-0008] Manage MCP api keys (AUTH-1..7); contrato p/ agentes",
    )
    token_sub = token_parser.add_subparsers(dest="token_command", required=True)

    token_create_parser = token_sub.add_parser(
        "create", help="Create an api key (plaintext shown ONCE in stdout)"
    )
    token_create_parser.add_argument("--token_name", required=True, help="Token name")
    token_create_parser.add_argument(
        "--expires", default=None, help="Expiry ISO datetime (default: never — AUTH-6)"
    )

    token_sub.add_parser("list", help="List tokens (metadata only — never the secret)")

    token_revoke_parser = token_sub.add_parser(
        "revoke", help="Soft revoke (active=false; audit preserved)"
    )
    token_revoke_parser.add_argument("--token_name", required=True)

    token_rotate_parser = token_sub.add_parser(
        "rotate", help="Rotate: revoke old + create new (same name; shown ONCE)"
    )
    token_rotate_parser.add_argument("--token_name", required=True)

    return parser


def execute_modern_cli(args: list[str]) -> int | None:
    """Execute modern subcommand-based CLI."""
    parser = build_parser()
    if not args:
        parser.print_help()
        return 1

    namespace = parser.parse_args(args)

    ui.QUIET = namespace.quiet
    ui.PROGRESS = not namespace.no_progress

    if namespace.command == "scan":
        return cmd_scan_target(
            namespace.file_or_folder,
            source_name=namespace.source_name,
            mode=namespace.mode,
            source_mask=namespace.pattern,
            source_kind=namespace.source_kind,
            parallel=namespace.parallel,
            max_workers=namespace.max_workers,
            infer=namespace.infer,
            ingest=namespace.ingest,
            force=namespace.force,
        )
    if namespace.command == "run":
        return cmd_run(
            namespace.source_name,
            path=namespace.path,
            source_kind=namespace.source_kind,
            ops=namespace.ops,
            limit=namespace.limit,
            overwrite=namespace.overwrite,
            force=namespace.force,
        )
    if namespace.command == "library":
        if namespace.library_command == "list_sources":
            return cmd_library_list_sources(namespace.pattern)
        if namespace.library_command == "add_source":
            return cmd_library_add_source(
                namespace.source_name,
                namespace.path,
                source_kind=namespace.source_kind,
                force=namespace.force,
            )
        if namespace.library_command == "remove_source":
            return cmd_library_remove_source(namespace.source_name, assume_yes=namespace.yes)
        if namespace.library_command == "describe_source":
            return cmd_library_describe_source(
                namespace.source_name,
                limit=namespace.limit,
                overwrite=namespace.overwrite,
            )
        if namespace.library_command == "infer_source":
            return cmd_library_infer_source(
                namespace.source_name,
                limit=namespace.limit,
                overwrite=namespace.overwrite,
            )
        if namespace.library_command == "ingest_source":
            return cmd_library_ingest_source(
                namespace.source_name,
                pattern=namespace.pattern,
                limit=namespace.limit,
                overwrite=namespace.overwrite,
            )
        if namespace.library_command == "sync_source":
            return cmd_library_sync_source(
                namespace.source_name,
                infer=namespace.infer,
                ingest=namespace.ingest,
                dry_run=namespace.dry_run,
            )
        if namespace.library_command == "search":
            return cmd_library_search(
                namespace.query,
                mode=namespace.mode,
                source_name=namespace.source_name,
                file_pattern=namespace.file_pattern,
                mime=namespace.mime,
                limit=namespace.limit,
                offset=namespace.offset,
                min_similarity=namespace.min_similarity,
                export=namespace.export,
            )
    if namespace.command == "token":
        if namespace.token_command == "create":
            return cmd_token_create(namespace.token_name, expires=namespace.expires)
        if namespace.token_command == "list":
            return cmd_token_list()
        if namespace.token_command == "revoke":
            return cmd_token_revoke(namespace.token_name)
        if namespace.token_command == "rotate":
            return cmd_token_rotate(namespace.token_name)

    parser.print_help()
    return 1


def main() -> int:
    """Main CLI entry point."""
    try:
        setup_system()
    except Exception as e:
        print(f"CRITICAL: Failed to initialize system: {e}")
        return 1

    args = sys.argv[1:]
    return execute_modern_cli(args) or 0


__all__ = ["build_parser", "main"]
