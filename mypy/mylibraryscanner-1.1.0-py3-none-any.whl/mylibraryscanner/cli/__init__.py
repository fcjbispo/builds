"""Command-line interface package for MyLibraryScanner."""

from mylibraryscanner.cli.commands import (
    cmd_library_infer_source,
    cmd_library_list_sources,
    cmd_library_remove_source,
    cmd_library_sync_source,
    cmd_scan_target,
)
from mylibraryscanner.cli.interface import build_parser, main

__all__ = [
    "build_parser",
    "cmd_library_infer_source",
    "cmd_library_list_sources",
    "cmd_library_remove_source",
    "cmd_library_sync_source",
    "cmd_scan_target",
    "main",
]