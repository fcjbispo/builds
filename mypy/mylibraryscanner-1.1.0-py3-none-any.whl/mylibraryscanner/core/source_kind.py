"""Source kind detection and read profile (ADR-0008).

Detection is **textual over `/proc/self/mountinfo`** — it never touches the
mounted filesystem (no ``stat``/``statfs``), so a hung network mount cannot
block it. Longest-prefix match on the already-normalized path; nested network
mounts are reported for the degradation warning.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

MOUNTINFO = "/proc/self/mountinfo"

# fstypes de rede => REMOTEFS (ADR-0008).
NETWORK_FSTYPES = frozenset(
    {
        "fuse.rclone",
        "fuse.gvfsd-fuse",
        "fuse.gvfsd",
        "fuse.sshfs",
        "fuse.s3fs",
        "fuse.gcsfuse",
        "fuse.goofys",
        "fuse.curlftpfs",
        "fuse.davfs2",
        "fuse.davfs",
        "fuse.juicefs",
        "nfs",
        "nfs4",
        "cifs",
        "smb3",
        "ceph",
        "glusterfs",
        "afs",
    }
)
# 9p / virtiofs / vboxsf: fora de escopo nesta versão (ADR-0008).

_ESCAPES = (("\\040", " "), ("\\011", "\t"), ("\\012", "\n"), ("\\134", "\\"))


@dataclass(frozen=True)
class Mount:
    mountpoint: str
    fstype: str
    source: str


def _unescape(value: str) -> str:
    for token, char in _ESCAPES:
        value = value.replace(token, char)
    return value


def _parse_line(line: str) -> Mount | None:
    left, sep, right = line.partition(" - ")
    if not sep:
        return None
    left_fields = left.split()
    right_fields = right.split()
    if len(left_fields) < 5 or len(right_fields) < 2:
        return None
    return Mount(
        mountpoint=_unescape(left_fields[4]),
        fstype=right_fields[0],
        source=_unescape(right_fields[1]),
    )


def read_mounts(path: str = MOUNTINFO) -> list[Mount]:
    """Parse mount entries; returns [] when the file is unreadable (never raises)."""
    mounts: list[Mount] = []
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                mount = _parse_line(line)
                if mount is not None:
                    mounts.append(mount)
    except OSError:
        return []
    return mounts


def _normalize(path: str) -> str:
    return os.path.normpath(os.path.abspath(path))


def is_under(child: str, parent: str) -> bool:
    if parent == "/":
        return True
    return child == parent or child.startswith(parent.rstrip("/") + "/")


def is_network_fstype(fstype: str) -> bool:
    return fstype in NETWORK_FSTYPES


def is_fuse(fstype: str) -> bool:
    return fstype.startswith("fuse.") or fstype == "fuseblk"


def find_mount(path: str, mounts: list[Mount] | None = None) -> Mount | None:
    """Longest mountpoint prefix of ``path`` (textual)."""
    target = _normalize(path)
    candidates = [
        m for m in (mounts if mounts is not None else read_mounts())
        if is_under(target, _normalize(m.mountpoint))
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda m: len(m.mountpoint))


def detect_kind(path: str, mounts: list[Mount] | None = None) -> str:
    """``REMOTEFS`` for a network-backed mount, else ``LOCAL`` (ADR-0008).

    An unknown ``fuse.*`` subtype is treated as ``LOCAL`` (conservative);
    callers may warn.
    """
    mount = find_mount(path, mounts)
    if mount is not None and is_network_fstype(mount.fstype):
        return "REMOTEFS"
    return "LOCAL"


def network_mounts_under(path: str, mounts: list[Mount] | None = None) -> list[Mount]:
    """Network mounts strictly under ``path`` (nested degradation — ADR-0008)."""
    root = _normalize(path)
    result: list[Mount] = []
    for mount in mounts if mounts is not None else read_mounts():
        mp = _normalize(mount.mountpoint)
        if mp != root and is_under(mp, root) and is_network_fstype(mount.fstype):
            result.append(mount)
    return result


def read_profile(kind: str, fstype: str | None = None) -> dict[str, object]:
    """Knobs do motor de leitura por kind (ADR-0008; genérico + gancho por backend)."""
    profile: dict[str, object] = {
        "hash": "full",
        "mime": "file",
        "enrichment": True,
        "workers": 4,
        "file_timeout": 10,
    }
    if kind == "REMOVABLE":
        profile["workers"] = 2
    elif kind == "REMOTEFS":
        profile.update(hash="header", workers=1, file_timeout=2)
        if fstype and "rclone" in fstype:
            profile["hash"] = "provider"
    return profile


__all__ = [
    "MOUNTINFO",
    "NETWORK_FSTYPES",
    "Mount",
    "detect_kind",
    "find_mount",
    "is_fuse",
    "is_network_fstype",
    "is_under",
    "network_mounts_under",
    "read_mounts",
    "read_profile",
]
