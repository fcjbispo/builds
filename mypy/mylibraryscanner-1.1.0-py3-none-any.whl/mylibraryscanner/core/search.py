"""Library search (A8) — four modes over the KB via the search_chunks RPC.

Default = hybrid (RRF). Export (.json/.csv/.md) follows the approved D6/D7
examples byte-for-byte. D8: scope with data → ABORTED friendly.
"""

from __future__ import annotations

import csv
import datetime as _dt
import io
from collections.abc import Callable, Sequence
from typing import Any

from mylibraryscanner.api.envelope import build_envelope
from mylibraryscanner.database.postgrest_client import PostgRESTClient
from mylibraryscanner.database.postgrest_repository import PostgRESTSourceRepository

SEARCH_MODES = ("hybrid", "content", "keyword", "topic")

_EMBEDDING_DIM = 768


def _embed_query(
    embedding_fn: Callable[[str], Sequence[float] | None] | None,
    query: str,
    mode: str,
) -> list[float]:
    """Embed the query for content/hybrid modes; empty list otherwise."""
    if mode not in ("hybrid", "content"):
        return []
    if embedding_fn is None:
        raise RuntimeError("embedding provider not available (Ollama)")
    vector = list(embedding_fn(query) or [])
    if len(vector) != _EMBEDDING_DIM:
        raise RuntimeError(
            f"query embedding dimension {len(vector)} != {_EMBEDDING_DIM}"
        )
    return vector


def run_search(
    client: PostgRESTClient,
    *,
    query: str,
    mode: str = "hybrid",
    source_name: str | None = None,
    file_pattern: str = "*",
    mime: str | None = None,
    limit: int = 10,
    offset: int = 0,
    min_similarity: float = 0.0,
    embedding_fn: Callable[[str], Sequence[float] | None] | None = None,
) -> dict[str, Any]:
    """Run a KB search and return ``{exit_code, envelope}`` (A10 + results)."""
    mode = mode.lower()
    target_label = source_name or "all-sources"
    base_options: dict[str, Any] = {"mode": mode, "query": query, "limit": limit,
                                    "offset": offset,
                                    "min_similarity": min_similarity,
                                    "file_pattern": file_pattern, "mime": mime}

    def stopped(message: str, **extra: Any) -> dict[str, Any]:
        envelope = build_envelope(
            "search",
            source_name=source_name,
            target=target_label,
            options=base_options,
            stats={"kb_chunks": extra.pop("kb_chunks", 0)},
            status="ABORTED",
        )
        envelope["message"] = message
        envelope.update(extra or {})
        return {"exit_code": 1, "envelope": envelope}

    if mode not in SEARCH_MODES:
        return stopped(f"invalid mode: {mode} (use: {', '.join(SEARCH_MODES)})")
    if not str(query).strip():
        return stopped("query required")

    try:
        query_embedding = _embed_query(embedding_fn, query, mode)
    except RuntimeError as exc:
        return stopped(
            f"{exc} — verify the Ollama embedding configuration."
        )

    source_repo = PostgRESTSourceRepository(client)
    payload: dict[str, Any] = {
        "mode": mode,
        "query": query,
        "query_embedding": query_embedding or None,
        "limit": limit,
        "offset": offset,
        "min_similarity": min_similarity,
        "file_pattern": file_pattern,
        "mime": mime,
    }
    if source_name is not None:
        source = source_repo.get_by_name(source_name)
        if source is None:
            return stopped(f"SOURCE not found: {source_name}")
        payload["source_id"] = source.id

    response = client.rpc("search_chunks", payload)
    stats: dict[str, Any] = dict(response.get("stats") or {})
    results: list[dict[str, Any]] = list(response.get("results") or [])

    # D8/R-4: no source in the scope has ingest → ABORTED friendly.
    if int(stats.get("sources_searched", 0) or 0) == 0:
        return stopped(
            "Nenhum source do escopo tem ingest na KB — execute "
            "`library ingest_source` antes de buscar.",
            kb_chunks=int(stats.get("kb_chunks", 0) or 0),
        )

    envelope = build_envelope(
        "search",
        source_name=source_name,
        target=target_label,
        options=base_options,
        stats=stats,
        status="OK",
        results=results,
    )
    return {"exit_code": 0, "envelope": envelope}


# ----------------------------------------------------------------------
# Export (D6/D7) — formatos byte-iguais aos exemplos aprovados da A8
# ----------------------------------------------------------------------

_CSV_HEADER = ["source_name", "file_path", "chunk_index", "score",
               "text", "topics", "mime_type"]


def export_envelope(envelope: dict[str, Any], export_path: str) -> None:
    """Write the search envelope to ``.json`` / ``.csv`` / ``.md`` (D7)."""
    path = export_path.lower()
    if path.endswith(".json"):
        import json

        with open(export_path, "w", encoding="utf-8") as fh:
            json.dump(envelope, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        return
    if path.endswith(".csv"):
        _export_csv(envelope, export_path)
        return
    if path.endswith(".md"):
        _export_markdown(envelope, export_path)
        return
    raise ValueError(f"unsupported export format: {export_path}")


def _export_csv(envelope: dict[str, Any], export_path: str) -> None:
    buffer = io.StringIO()
    writer = csv.writer(buffer, quoting=csv.QUOTE_MINIMAL)
    writer.writerow(_CSV_HEADER)
    for row in envelope.get("results") or []:
        topics = ";".join(row.get("topics") or [])
        writer.writerow(
            [
                row.get("source_name", ""),
                row.get("file_path", ""),
                row.get("chunk_index", 0),
                f"{row.get('score', 0):.2f}",
                row.get("text", ""),
                topics,
                row.get("mime_type", ""),
            ]
        )
    with open(export_path, "w", encoding="utf-8", newline="") as fh:
        fh.write(buffer.getvalue())


def _export_markdown(envelope: dict[str, Any], export_path: str) -> None:
    options = envelope.get("options") or {}
    stats = envelope.get("stats") or {}
    scope = envelope.get("target") or "all-sources"
    searched = int(stats.get("sources_searched", 0) or 0)
    without = int(stats.get("sources_without_kb", 0) or 0)
    chunks = len(envelope.get("results") or [])
    date = _dt.date.today().isoformat()  # noqa: DTZ011 — label local

    lines: list[str] = []
    query = options.get("query", "")
    lines.append(f'# Resultados de busca — "{query}"')
    lines.append(
        f"modo: {options.get('mode', 'hybrid')} · escopo: {scope} "
        f"({searched} com KB, {without} sem ingest) · {chunks} chunks · {date}"
    )
    for index, row in enumerate(envelope.get("results") or [], start=1):
        title = (row.get("file_path") or "").rpartition("/")[2] or row.get("file_path", "")
        lines.append("")
        lines.append(f"## {index}. {title} — score {row.get('score', 0):.2f}")
        topics = ", ".join(row.get("topics") or [])
        lines.append(
            f"source: {row.get('source_name', '')} · "
            f"chunk {row.get('chunk_index', 0)} · tópicos: {topics}"
        )
        text = (row.get("text") or "").strip()
        if text:
            lines.append(f"> {text}")
    with open(export_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


__all__ = ["SEARCH_MODES", "export_envelope", "run_search"]