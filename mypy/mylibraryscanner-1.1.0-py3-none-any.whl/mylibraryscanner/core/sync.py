"""Host↔db reconciliation engine (A6/A5/A7) using the PostgREST adapter.

``scan --mode sync`` mirrors the host into the SOURCE (removed files cascade
to the KB via FK); ``--mode append`` only registers new files. The FS is
read-only (A2); per-file failures never abort the operation (A5) — they land
in ``source_files.status/status_message`` and the A10 counters.
"""

from __future__ import annotations

import fnmatch
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from mylibraryscanner.core.layers import content_key
from mylibraryscanner.database.postgrest_client import PostgRESTClient
from mylibraryscanner.database.postgrest_repository import (
    PostgRESTFileRepository,
    SourceRecord,
)

ProgressCallback = Callable[[int, int], None]


@dataclass
class SyncOutcome:
    """A10 counters for one reconciliation run (zeros are pruned later)."""

    files_read: int = 0
    added: int = 0
    modified: int = 0
    unchanged: int = 0
    removed: int = 0
    moved: int = 0
    duplicates: int = 0
    inferred: int = 0
    skipped: int = 0
    failed: int = 0
    affected_paths: list[str] = field(default_factory=list)

    def stats(self) -> dict[str, int]:
        return {
            "files_read": self.files_read,
            "added": self.added,
            "modified": self.modified,
            "unchanged": self.unchanged,
            "removed": self.removed,
            "moved": self.moved,
            "duplicates": self.duplicates,
            "inferred": self.inferred,
            "skipped": self.skipped,
            "failed": self.failed,
        }


def _md5_of(record: dict[str, Any]) -> str | None:
    details = record.get("details") or {}
    return details.get("md5sum") if isinstance(details, dict) else None


def collect_file_records(
    target: Path,
    mask: str = "*",
    *,
    parallel: bool = False,
    max_workers: int | None = None,
    source_kind: str = "LOCAL",
    progress_callback: ProgressCallback | None = None,
) -> list[dict[str, Any]]:
    """Read the host (RO) and return file records for the target.

    Single-file targets yield exactly one record (PS-4); folders use the
    Scanner (sequential or parallel) and re-use its record schema.
    Returns dicts with ``file_path``/``status``/``status_message``/``details``.
    """
    from mylibraryscanner.core.file_processor import FileProcessor
    from mylibraryscanner.core.scanner import Scanner

    if target.is_file():
        processor = FileProcessor(enrich=False)
        try:
            record = processor.process_file(str(target))
        except Exception as exc:  # noqa: BLE001 — file failure never aborts (A5)
            record = {
                "file_path": str(target),
                "status": "ERROR",
                "status_message": str(exc),
                "details": {},
            }
        record.setdefault("status", "OK")
        record.setdefault("details", {})
        return [record]

    if source_kind == "REMOTEFS":
        from mylibraryscanner.core.rclone_source import (
            collect_records as _rclone_records,
        )

        fast = _rclone_records(str(target), mask)
        if fast is not None:
            if progress_callback and fast:
                progress_callback(len(fast), len(fast))
            return fast

    scanner = Scanner(progress_callback=progress_callback)
    if parallel:
        scan = scanner.scan_parallel(
            str(target),
            source_mask=mask,
            source_name=target.name,
            source_kind=source_kind,
            max_workers=max_workers or 1,
        )
    else:
        scan = scanner.scan(
            str(target),
            source_mask=mask,
            source_name=target.name,
            source_kind=source_kind,
        )
    payload = scan.to_dict()
    records = list(payload.get("files") or [])
    seen_paths = {r.get("file_path") for r in records}
    for record in records:
        record.setdefault("status", "OK")
        record.setdefault("details", {})
    # Scanner reports processing failures in errors — exceptions are NOT in
    # files, ERROR-status rows are (dedupe by path). Register all (A5: never
    # abort; details live in the db rows).
    for error in payload.get("errors") or []:
        path = error.get("file", "")
        if path in seen_paths:
            continue
        seen_paths.add(path)
        records.append(
            {
                "file_path": path,
                "status": "ERROR",
                "status_message": error.get("message", "Unknown error"),
                "details": {},
            }
        )
    return records


def _infer_records(
    candidates: list[tuple[dict[str, Any], Any | None]],
    inference_service: Any,
    outcome: SyncOutcome,
    topic_resolver: Callable[[str, list[str]], list[str]] | None = None,
) -> None:
    """Fill ``inference`` (A4) and topics (D1-a) on new/changed records.

    Failures never abort (A5). ``candidates`` pairs each fresh record with
    its current db row (or None) so curated topics survive upserts that do
    not regenerate them, and are preserved when the fresh classification
    agrees (coseno ≥ threshold, R-3).
    """
    from mylibraryscanner.core.inference import MAX_INFERENCE_CHARS

    for record, current in candidates:
        existing_topics = list(current.topics) if current else []
        if record.get("status") == "OK":
            try:
                inference = inference_service.infer_file(
                    record["file_path"], details=record.get("details") or {}
                )
            except Exception:  # noqa: BLE001 — A5
                inference = None
            if inference:
                record["inference"] = inference[:MAX_INFERENCE_CHARS]
                outcome.inferred += 1
            else:
                record["inference"] = None
                outcome.skipped += 1
            if record.get("inference") and topic_resolver:
                try:
                    record["topics"] = topic_resolver(
                        record.get("inference") or "", existing_topics
                    )
                except Exception:  # noqa: BLE001 — A5 (tópicos são best-effort)
                    record["topics"] = existing_topics or None
        # carry curated topics on upserts that do not regenerate them
        if record.get("topics") is None and existing_topics:
            record["topics"] = existing_topics


def reconcile_source(
    client: PostgRESTClient,
    source: SourceRecord,
    fresh_records: list[dict[str, Any]],
    *,
    mode: str = "sync",
    inference_service: Any | None = None,
    topic_resolver: Callable[[str, list[str]], list[str]] | None = None,
    dry_run: bool = False,
    progress_callback: ProgressCallback | None = None,
) -> SyncOutcome:
    """Diff fresh records against db and reconcile (ADR-0008).

    ``sync`` (operação-mãe): espelha a fonte — upsert de novos/alterados,
    **reaponta** rename/move (mesmo hash), marca ``stale`` + exclui o KB em
    ``modified``, exclui linhas sumidas (cascade no KB). ``append``: só
    registra novos. ``dry_run`` calcula buckets sem escrever.

    ``path`` é a identidade da linha; ``hash`` só detecta duplicata in-source
    e rename/move.
    """
    file_repo = PostgRESTFileRepository(client)  # health check per operation (PS-7)
    outcome = SyncOutcome(files_read=len(fresh_records))

    existing = file_repo.get_by_source(source.id)
    existing_by_path = {f.file_path: f for f in existing}
    fresh_paths = {r["file_path"] for r in fresh_records}

    added_records: list[dict[str, Any]] = []
    modified_pairs: list[tuple[dict[str, Any], Any]] = []

    for record in fresh_records:
        path = record["file_path"]
        status = record.get("status") or "OK"
        if status == "ERROR":
            outcome.failed += 1
        current = existing_by_path.get(path)
        if current is not None and mode == "append":
            outcome.unchanged += 1  # A6: append ignora já registrados
            continue
        if current is None:
            added_records.append(record)
            continue
        changed = (
            content_key(_md5_of(record), record.get("details"))
            != content_key(current.md5sum, current.details)
        ) or status != (current.status or "OK")
        if changed:
            modified_pairs.append((record, current))
        else:
            outcome.unchanged += 1

    # rename/move: path novo com o mesmo hash de um path sumido -> reaponta
    removed_rows = [f for f in existing if f.file_path not in fresh_paths]
    if mode == "sync":
        removed_by_hash: dict[str, list[Any]] = {}
        for row in removed_rows:
            if row.md5sum:
                removed_by_hash.setdefault(row.md5sum, []).append(row)
        still_added: list[dict[str, Any]] = []
        for record in added_records:
            md5 = _md5_of(record)
            bucket = removed_by_hash.get(md5) if md5 else None
            if bucket:
                moved = bucket.pop(0)
                if not dry_run:
                    file_repo.update_path(moved.id, record["file_path"])
                outcome.moved += 1
                outcome.affected_paths.append(record["file_path"])
                removed_rows = [r for r in removed_rows if r.id != moved.id]
            else:
                still_added.append(record)
        added_records = still_added

    # duplicatas in-source (mesmo hash)
    hash_counts: dict[str, int] = {}
    for record in fresh_records:
        md5 = _md5_of(record)
        if md5:
            hash_counts[md5] = hash_counts.get(md5, 0) + 1
    outcome.duplicates = sum(1 for count in hash_counts.values() if count > 1)

    candidates: list[tuple[dict[str, Any], Any | None]] = [
        (record, None) for record in added_records
    ] + list(modified_pairs)

    if inference_service and candidates:
        _infer_records(candidates, inference_service, outcome, topic_resolver)

    outcome.added = len(added_records)
    outcome.modified = len(modified_pairs)

    if dry_run:
        outcome.removed = len(removed_rows) if mode == "sync" else 0
        return outcome

    if candidates:
        payload = []
        for record, current in candidates:
            # modified sem inferência nova → mantém a antiga sob `stale`
            stale = current is not None and not record.get("inference")
            payload.append(
                {
                    "file_path": record["file_path"],
                    "status": record.get("status") or "OK",
                    "status_message": record.get("status_message"),
                    "inference": record.get("inference"),
                    "details": record.get("details") or {},
                    "md5sum": _md5_of(record),
                    "topics": record.get("topics"),
                    "stale": stale,
                }
            )
            outcome.affected_paths.append(record["file_path"])
            if current is not None:
                file_repo.delete_chunks(current.id)  # KB invalidado (rebuild)
        file_repo.create_batch(source.id, payload, upsert=True)

    if mode == "sync":
        for row in removed_rows:
            # Cascade para kb_chunks pelo FK (DDL v1.0.1).
            file_repo.delete_by_path(source.id, row.file_path)
            outcome.removed += 1

    return outcome


def walk_files(source_dir: str, source_mask: str = "*") -> list[str]:
    """Absolute file paths under ``source_dir`` matching ``source_mask``.

    Hidden directories are skipped, matching ``Scanner._find_files``.
    """
    source_path = Path(source_dir).expanduser().resolve()
    if not source_path.is_dir():
        return []

    files: list[str] = []
    for root, dirs, names in os.walk(source_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for name in names:
            if fnmatch.fnmatch(name, source_mask):
                files.append(str(Path(root) / name))
    return sorted(files)


__all__ = ["SyncOutcome", "collect_file_records", "reconcile_source", "walk_files"]