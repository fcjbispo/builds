"""JSON sanitization for Postgres ``jsonb`` (ADR-0008).

``jsonb`` rejeita ``\\u0000`` (NUL) e o ``json.dumps`` do PostgREST rejeita tipos
não-JSON (``IFDRational`` do Pillow, ``Decimal``, ``datetime``, ``bytes``…).
"""

from __future__ import annotations

import math
from typing import Any


def json_safe(value: Any) -> Any:
    """Coage recursivamente ``value`` para algo serializável em ``jsonb``."""
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, str):
        return value.replace("\x00", "")
    if value is None or isinstance(value, (bool, int)):
        return value
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value).replace("\x00", "")
    return number if math.isfinite(number) else str(value)


__all__ = ["json_safe"]
