"""Token management for MyLibraryScanner (AUTH-1..7 — F5).

API keys for the future MCP server (v2+), stored in ``mylibrary.adm_tokens``
as sha256 hashes — the plaintext is shown exactly once and never stored,
logged or versioned. Local clients need no auth (AUTH-4, trusted homelab);
expiry is soft (NULL = no expiration, AUTH-6) and revocation is soft
(``active=false``, audit preserved).
"""

from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from mylibraryscanner.database.postgrest_client import (
    PostgRESTClient,
    PostgRESTError,
    PostgRESTUnavailableError,
)

TOKEN_BYTES = 32


@dataclass
class TokenRecord:
    """Row shape of ``mylibrary.adm_tokens`` (never the plaintext)."""

    id: str
    token_name: str
    active: bool
    created_at: datetime | None = None
    last_used_at: datetime | None = None
    expires_at: datetime | None = None


def token_hash(plaintext: str) -> str:
    """sha256 hex of the api key (UTF-8) — the only DB-side representation."""
    return hashlib.sha256(plaintext.encode("utf-8")).hexdigest()


def token_create(
    client: PostgRESTClient,
    token_name: str,
    *,
    expires_at: datetime | None = None,
    plaintext: str | None = None,
) -> tuple[str, dict[str, Any]]:
    """Create an api key; returns ``(plaintext, row)``.

    The plaintext is generated once (``secrets.token_urlsafe(32)`` — AUTH-1c)
    and returned to the caller for a single display; only the sha256 hash is
    persisted. Pass ``plaintext`` for deterministic flows (tests/rotate uses
    its own generation).
    """
    value = plaintext if plaintext is not None else secrets.token_urlsafe(TOKEN_BYTES)
    rows = client.insert(
        "adm_tokens",
        [
            {
                "token_name": token_name,
                "token_hash": token_hash(value),
                "expires_at": expires_at.isoformat() if expires_at else None,
            }
        ],
        select="*",
    )
    row = rows[0] if rows else {}
    return value, row


def token_list(client: PostgRESTClient) -> list[TokenRecord]:
    """List tokens (metadata only — NEVER the plaintext nor the hash)."""
    rows = client.get("adm_tokens", params={"order": "created_at.desc"}, limit=1000)
    records = []
    for row in rows:
        records.append(
            TokenRecord(
                id=row["id"],
                token_name=row.get("token_name", ""),
                active=bool(row.get("active", False)),
                created_at=_parse(row.get("created_at")),
                last_used_at=_parse(row.get("last_used_at")),
                expires_at=_parse(row.get("expires_at")),
            )
        )
    return records


def token_revoke(client: PostgRESTClient, token_name: str) -> int:
    """Soft revoke: ``active=false`` for ACTIVE rows with the name (AUTH-6)."""
    rows = client.update(
        "adm_tokens",
        {"active": False},
        params={"token_name": token_name, "active": "true"},
    )
    return len(rows)


def token_rotate(
    client: PostgRESTClient, token_name: str
) -> tuple[str | None, dict[str, Any]]:
    """Rotate: revoke the old secret + create a new one with the SAME name.

    Returns ``(new_plaintext, new_row)`` — plaintext shown once by the CLI.
    Returns ``(None, {})`` when nothing ACTIVE was revoked (unknown token).
    """
    revoked = token_revoke(client, token_name)
    if not revoked:
        return None, {}
    return token_create(client, token_name)


def authenticate(client: PostgRESTClient, api_key: str) -> TokenRecord | None:
    """Validate an api key against adm_tokens (AUTH-2 — for the MCP server).

    Match by sha256 + ``active=true`` + ``expires_at`` future/NULL; on
    success registers ``last_used_at``. Failure → None (caller maps to
    envelope ABORTED, AUTH-7).
    """
    digest = token_hash(api_key)
    rows = client.get(
        "adm_tokens",
        params={"token_hash": f"eq.{digest}", "active": "eq.true", "limit": 1},
        limit=1,
    )
    if not rows:
        return None
    row = rows[0]
    expires = _parse(row.get("expires_at"))
    if expires is not None and expires <= datetime.now():
        return None
    client.update(
        "adm_tokens",
        {"last_used_at": datetime.now().isoformat()},
        params={"id": row["id"]},
    )
    return TokenRecord(
        id=row["id"],
        token_name=row.get("token_name", ""),
        active=True,
        created_at=_parse(row.get("created_at")),
        last_used_at=_parse(row.get("last_used_at")),
        expires_at=expires,
    )


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


__all__ = [
    "PostgRESTError",
    "PostgRESTUnavailableError",
    "TokenRecord",
    "authenticate",
    "token_create",
    "token_get_by_name",
    "token_hash",
    "token_list",
    "token_revoke",
    "token_rotate",
]