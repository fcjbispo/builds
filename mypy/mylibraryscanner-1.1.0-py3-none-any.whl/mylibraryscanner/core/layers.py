"""Per-layer freshness tracking (ADR-0008).

Cada camada derivada (describe/infer/ingest) registra, em
``details["<layer>_hash"]``, o hash do arquivo no momento em que foi calculada.
Uma camada está **pendente** quando o hash registrado difere do hash atual (ou
não existe). Isso é por-camada (não usa um único flag), o que evita que uma
operação limpe a pendência de outra.
"""

from __future__ import annotations

from typing import Any

LAYERS = ("described", "inferred", "ingested")


def content_key(md5sum: str | None, details: dict[str, Any] | None) -> str | None:
    """Chave de conteúdo: o md5 se houver; senão ``size+mtime`` (ADR-0008).

    Arquivos sem hash do provedor (ex.: Google Docs nativos) ainda precisam de
    uma chave para não ficarem eternamente "pendentes".
    """
    if md5sum:
        return md5sum
    data = details or {}
    size = data.get("size_bytes")
    mtime = data.get("modification_date")
    if size is None and mtime is None:
        return None
    return f"size={size};mtime={mtime}"


def layer_pending(
    details: dict[str, Any] | None,
    key: str | None,
    layer: str,
    overwrite: bool = False,
) -> bool:
    """True quando a camada precisa (re)executar para a chave atual.

    Sem chave registrada para a camada ⇒ pendente (nunca processada — inclui
    arquivos em ERROR, que assim retentam).
    """
    if overwrite:
        return True
    recorded = (details or {}).get(f"{layer}_hash")
    return recorded is None or recorded != key


def layer_values(
    details: dict[str, Any] | None,
    key: str | None,
    layer: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Campos para atualizar após (re)executar ``layer``; zera ``stale`` se todas as camadas estiverem frescas."""
    merged = dict(details or {})
    merged[f"{layer}_hash"] = key
    values: dict[str, Any] = {"details": merged}
    if all(merged.get(f"{name}_hash") == key for name in LAYERS):
        values["stale"] = False
    if extra:
        values.update(extra)
    return values


__all__ = ["LAYERS", "content_key", "layer_pending", "layer_values"]
