"""rclone fast-path — descoberta + hash do provedor sem varrer o mount FUSE (ADR-0008).

Para uma fonte `REMOTEFS` cujo backend é rclone, descobrimos o `remote:path`
a partir do `/proc/self/mountinfo` e usamos ``rclone lsjson --hash`` (um único
passe, hash nativo do provedor) em vez de ``os.walk`` + MD5 por arquivo.
Fallback: qualquer falha retorna ``None`` e o chamador volta à varredura.
"""

from __future__ import annotations

import fnmatch
import json
import mimetypes
import os
import subprocess

from mylibraryscanner.core import source_kind as sk

RCLONE_BIN = os.getenv("MYLIBRARYSCANNER_RCLONE_BIN", "rclone")
LIST_TIMEOUT = int(os.getenv("MYLIBRARYSCANNER_RCLONE_TIMEOUT", "600"))


def rclone_spec_for(path: str, mounts: list[sk.Mount] | None = None) -> str | None:
    """``remote:path`` do mount rclone que contém ``path`` — ou None se não for rclone."""
    mount = sk.find_mount(path, mounts)
    if mount is None or "rclone" not in mount.fstype:
        return None
    remote_name, _, base = mount.source.partition(":")
    if not remote_name:
        return None
    mountpoint = os.path.normpath(mount.mountpoint)
    target = os.path.normpath(os.path.abspath(path))
    rel = os.path.relpath(target, mountpoint)
    rel = "" if rel == "." else rel
    joined = "/".join(part for part in (base.strip("/"), rel) if part)
    return f"{remote_name}:{joined}"


def list_hashes(spec: str, *, timeout: int = LIST_TIMEOUT) -> list[dict] | None:
    """``rclone lsjson -R --files-only --hash <spec>``; None em qualquer falha."""
    cmd = [RCLONE_BIN, "lsjson", "--files-only", "--hash", "-R", spec]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=True
        )
        return json.loads(proc.stdout or "[]")
    except (OSError, subprocess.SubprocessError, ValueError):
        return None


def _mime_from_name(name: str) -> tuple[str, str]:
    guess, _ = mimetypes.guess_type(name)
    return (guess or "application/octet-stream", guess or "Unknown")


def collect_records(
    target: str, mask: str = "*", *, mounts: list[sk.Mount] | None = None
) -> list[dict] | None:
    """Registros no formato do ``FileProcessor`` via rclone — ou None (fallback)."""
    spec = rclone_spec_for(target, mounts)
    if spec is None:
        return None
    entries = list_hashes(spec)
    if entries is None:
        return None
    base = os.path.normpath(os.path.abspath(target))
    records: list[dict] = []
    seen: set[str] = set()
    for entry in entries:
        if entry.get("IsDir"):
            continue
        rel = entry.get("Path") or entry.get("Name") or ""
        if not rel or not fnmatch.fnmatch(os.path.basename(rel), mask):
            continue
        # `Path` do rclone é relativo ao SPEC (= target) → junta com o target,
        # não com o mountpoint.
        local = os.path.join(base, rel)
        if local in seen:
            # Google Drive permite nomes repetidos na mesma pasta → mesmo Path.
            # O mount não representa os dois e o DB tem UNIQUE(source_id, file_path).
            continue
        seen.add(local)
        name = os.path.basename(rel)
        ext = os.path.splitext(name)[1]
        mime_code, mime_desc = _mime_from_name(name)
        md5 = (entry.get("Hashes") or {}).get("md5")
        records.append(
            {
                "file_path": local,
                "status": "OK",
                "status_message": None,
                "details": {
                    "complete_filename": name,
                    "filename_no_ext": os.path.splitext(name)[0],
                    "extension": ext,
                    "size_bytes": entry.get("Size"),
                    "modification_date": entry.get("ModTime"),
                    "md5sum": md5,
                    "mime_type_code": mime_code,
                    "mime_type_description": mime_desc,
                    "hash_source": "provider" if md5 else "provider-missing",
                },
            }
        )
    return sorted(records, key=lambda r: r["file_path"])


__all__ = ["collect_records", "list_hashes", "rclone_spec_for"]
