# Contrato do Envelope A10 — MyLibraryScanner v1

Fonte: README consolidado InOut `MyLibraryScanner-Redesign/README.md`
(seção "Saída padrão — A10 FECHADO 2026-09-03"). Sintetizado na F2, conforme
design `2026-10-11-implementacao-v1-biblioteca-postgrest.md`.

## Shape (todos os comandos)

```json
{
  "operation": "scan",
  "source_name": "meus-docs",
  "target": "/caminho/ou/arquivo",
  "options": {
    "mode": "sync", "infer": true, "ingest": false,
    "pattern": "*", "source_kind": "LOCAL",
    "parallel": true, "max_workers": 4
  },
  "status": "OK",
  "stats": {
    "files_read": 120, "added": 12, "modified": 3, "unchanged": 100,
    "removed": 2, "inferred": 15, "ingested": 0,
    "skipped": 2, "failed": 2, "warnings": 1
  }
}
```

Regras fechadas:

1. snake_case; **somente contadores** — sem listas de errors/warnings no
   envelope (detalhe por arquivo vive em `source_files.status` +
   `source_files.status_message` no banco, A5).
2. `status`: `OK` | `PARTIAL` (teve skipped/failed) | `FAILED` (nada
   processado) | `ABORTED` (dependência ausente ou conflito de caminho — A3/PS-7).
3. `options`: valores **resolvidos** (defaults aplicados), não flags cruas.
4. `stats`: buckets do sync (`added/modified/unchanged/removed`) +
   inferência/ingestão (`inferred/ingested/skipped/failed/warnings`).
   Comandos omitem chaves irrelevantes (ex.: `list_sources` não traz
   `removed`).
5. `list_sources`/`search` incluem achados em `results` (campo extra do
   envelope; contadores obrigatórios continuam).
6. Saída exclusivamente JSON no stdout da CLI (CL-4), uma vez ao final —
   print é responsabilidade da CLI, nunca do builder.
7. Exit code da CLI: `OK`/`PARTIAL` → 0; `FAILED`/`ABORTED` → 1.

## Envelopes ABORTED (A3 / PS-7 / AUTH-7)

`ABORTED` + mensagem amigável. O README A10 fixa as chaves acima e o AUTH-7
manda "sem campo novo"; a mensagem amigável precisa de um canal — decisão
registrada: **`"message"` aparece SOMENTE em envelopes ABORTED** (nunca em
OK/PARTIAL/FAILED). Desvio mínimo documentado aqui e no relatório do ticket;
reconciliar com P.O. se o A10 for reaberto.

```json
{
  "operation": "scan",
  "source_name": "meus-docs",
  "target": "/outro/caminho",
  "status": "ABORTED",
  "message": "Caminho divergente do registrado na SOURCE ...",
  "stats": {}
}
```

## Casos cobertos (gates F2)

- builder: shape, snake_case, defaults, omissão de chaves irrelevantes;
- resolução de status: `OK` (sem skipped/failed), `PARTIAL` (skipped/failed
  > 0), `FAILED` (nenhum arquivo processado);
- A3: caminho divergente → ABORTED + message;
- PS-7: PostgREST indisponível/config ausente → ABORTED + message;
- PARTIAL: skipped/failed não abortam a operação (A5);
- buckets do sync com upsert idempotente (`on_conflict=source_id,file_path`).