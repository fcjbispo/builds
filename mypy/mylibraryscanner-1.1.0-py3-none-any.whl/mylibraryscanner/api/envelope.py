"""Envelope A10 builder — the single JSON output contract of the v1 CLI.

⚠️ DEPRECATED (ADR-0008): a v1.1.0 é um cliente **local** de ingestão; o contrato
para agentes sai de escopo. Este módulo é mantido apenas para referência até a
reimplementação. Não adicionar novas features aqui.

Shape and rules live in ``mylibraryscanner/api/envelope-a10.md`` (source:
InOut README consolidado, A10 FECHADO 2026-09-03). Counters only — file
details stay in ``source_files`` (A5); no printing here (CLI prints once).
"""

from __future__ import annotations

from typing import Any

STATUS_OK = "OK"
STATUS_PARTIAL = "PARTIAL"
STATUS_FAILED = "FAILED"
STATUS_ABORTED = "ABORTED"
STATUS_NOOP = "NOOP"  # nada a fazer (sem pendências) — ADR-0008

SYNC_BUCKET_KEYS = ("added", "modified", "unchanged", "removed")
WORKFLOW_BUCKET_KEYS = ("inferred", "ingested", "skipped", "failed", "warnings")


def resolve_status(
    processed: int,
    skipped: int = 0,
    failed: int = 0,
) -> str:
    """Resolve the A10 status from processing counters (README rule).

    ``NOOP`` = nada a fazer (nenhum processado/pulado/falho — ex.: target
    vazio, nada pendente). ``ABORTED`` is never produced here — it is explicit
    (path conflict, dependency missing) and carries a friendly ``message``
    (AUTH-7).
    """
    if skipped or failed:
        return STATUS_PARTIAL
    if not processed and not skipped and not failed:
        return STATUS_NOOP
    return STATUS_OK


def build_envelope(
    operation: str,
    *,
    source_name: str | None = None,
    target: str | None = None,
    options: dict[str, Any] | None = None,
    stats: dict[str, int] | None = None,
    status: str = STATUS_OK,
    results: list[Any] | None = None,
) -> dict[str, Any]:
    """Assemble the A10 envelope; omit keys that do not apply."""
    envelope: dict[str, Any] = {
        "operation": operation,
        "source_name": source_name,
        "target": target,
        "options": dict(options or {}),
        "status": status,
        "stats": dict(stats or {}),
    }
    if results is not None:
        envelope["results"] = results
    if status == STATUS_ABORTED:
        # AUTH-7: mensagem amigável em ABORTED (ver envelope-a10.md — nota).
        envelope["message"] = envelope.get("message") or ""
    return envelope


def aborted(
    operation: str,
    message: str,
    *,
    source_name: str | None = None,
    target: str | None = None,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """ABORTED envelope: dependency missing or A3 path conflict (PS-7/AUTH-7)."""
    envelope = build_envelope(
        operation,
        source_name=source_name,
        target=target,
        options=options,
        stats={},
        status=STATUS_ABORTED,
    )
    envelope["message"] = message
    return envelope


def prune_stats(stats: dict[str, int]) -> dict[str, int]:
    """Drop zero-valued counters (omissão de chaves irrelevantes — A10)."""
    return {key: value for key, value in stats.items() if value}


__all__ = [
    "STATUS_ABORTED",
    "STATUS_FAILED",
    "STATUS_NOOP",
    "STATUS_OK",
    "STATUS_PARTIAL",
    "SYNC_BUCKET_KEYS",
    "WORKFLOW_BUCKET_KEYS",
    "aborted",
    "build_envelope",
    "prune_stats",
    "resolve_status",
]