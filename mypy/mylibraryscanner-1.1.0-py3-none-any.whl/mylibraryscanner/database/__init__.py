"""Database operations for MyLibraryScanner using FBNet standard configuration.

This package handles database connections, models, and operations
for PostgreSQL databases supporting the MyLibraryScanner schema.

Modules:
    models: SQLAlchemy models for sources and source_files tables
    connection: Database connection management and session handling
    operations: High-level database operations and repository patterns
    postgrest_client: Minimal PostgREST HTTP client (ADR-0005)
    postgrest_repository: PostgREST-backed repositories (SOLID adapters)
    migrations: Alembic migrations (canonical since v1 — PS-8)
"""

from .models import Base, Source, SourceFile
from .connection import DatabaseManager
from .operations import SourceRepository, SourceFileRepository, ScanRepository
from .postgrest_client import (
    PostgRESTAuthError,
    PostgRESTClient,
    PostgRESTConflictError,
    PostgRESTError,
    PostgRESTNotFoundError,
    PostgRESTUnavailableError,
    build_static_jwt,
)

__all__ = [
    # Models
    "Base",
    "Source",
    "SourceFile",

    # Connection management
    "DatabaseManager",

    # Operations
    "SourceRepository",
    "SourceFileRepository",
    "ScanRepository",

    # PostgREST adapter (ADR-0005)
    "PostgRESTClient",
    "build_static_jwt",
    "PostgRESTError",
    "PostgRESTUnavailableError",
    "PostgRESTNotFoundError",
    "PostgRESTConflictError",
    "PostgRESTAuthError",
]
