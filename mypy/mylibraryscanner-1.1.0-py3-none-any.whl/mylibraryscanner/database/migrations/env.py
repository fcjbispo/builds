"""Alembic environment for the mylibrary schema migrations."""
from __future__ import annotations

import os

from alembic import context
from sqlalchemy import engine_from_config, pool

# alembic.ini sqlalchemy.url is a placeholder; the URL comes from the env.
DB_URL_ENV = "FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL"
SCHEMA_NAME = "mylibrary"

config = context.config

if not config.get_main_option("sqlalchemy.url"):
    config.set_main_option("sqlalchemy.url", os.getenv(DB_URL_ENV, ""))

target_metadata = None  # raw-SQL migrations; no autogenerate


def include_object(obj, name, type_, reflected, compare_to):
    if type_ == "table":
        return getattr(obj, "schema", None) == SCHEMA_NAME
    return True


def run_migrations_offline() -> None:
    context.configure(
        url=config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        version_table_schema=SCHEMA_NAME,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            version_table_schema=SCHEMA_NAME,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()