"""mylibrary v1.0.0 baseline — mirrors sql/ddl_mylibrary_v1.sql (v1.0.1 rev a).

Canonical evolution path starts here (PS-8). Idempotence is intentionally NOT
provided (migrations run once); on a DB already bootstrapped by the reference
DDL, run ``alembic stamp head`` instead of ``upgrade``.

Revision ID: 0001
Revises:
Create Date: 2026-10-11

"""
from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

SCHEMA = "mylibrary"

# Sources (A1 unique name; A3 path is a SOURCE attribute).
TABLE_SOURCES = f"""
CREATE TABLE {SCHEMA}.sources (
    id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_name      varchar NOT NULL UNIQUE,
    source_kind      varchar NOT NULL
                     CHECK (source_kind IN ('LOCAL', 'REMOVABLE', 'REMOTE')),
    source_path      varchar NOT NULL,
    start_extraction timestamp NOT NULL DEFAULT now(),
    end_extraction   timestamp,
    status           varchar NOT NULL DEFAULT 'PENDING'
                     CHECK (status IN ('OK', 'FAIL', 'PENDING')),
    files_total      integer NOT NULL DEFAULT 0,
    created_at       timestamp NOT NULL DEFAULT now(),
    updated_at       timestamp
)"""

TABLE_ADM_TOKENS = f"""
CREATE TABLE {SCHEMA}.adm_tokens (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    token_name  varchar NOT NULL,
    token_hash  varchar NOT NULL UNIQUE,
    active      boolean NOT NULL DEFAULT true,
    created_at  timestamp NOT NULL DEFAULT now(),
    last_used_at timestamp,
    expires_at  timestamp
)"""

TABLE_SOURCE_FILES = f"""
CREATE TABLE {SCHEMA}.source_files (
    id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id      uuid NOT NULL REFERENCES {SCHEMA}.sources (id) ON DELETE CASCADE,
    file_path      text NOT NULL,
    status         varchar NOT NULL DEFAULT 'PENDING'
                   CHECK (status IN ('OK', 'SKIPPED', 'ERROR', 'PENDING')),
    status_message text,
    inference      varchar(5120),
    topics         text[] DEFAULT '{{}}',
    md5sum         varchar(32) CHECK (md5sum IS NULL OR char_length(md5sum) = 32),
    details        jsonb NOT NULL DEFAULT '{{}}',
    processed_at   timestamp NOT NULL DEFAULT now(),
    CONSTRAINT uq_source_files_source_path UNIQUE (source_id, file_path)
)"""

TABLE_KB_CHUNKS = f"""
CREATE TABLE {SCHEMA}.kb_chunks (
    id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_file_id  uuid NOT NULL REFERENCES {SCHEMA}.source_files (id) ON DELETE CASCADE,
    chunk_index     integer NOT NULL,
    text            text NOT NULL,
    tsv             tsvector,
    embedding       vector(768),
    embedding_model varchar NOT NULL DEFAULT 'nomic-embed-text',
    created_at      timestamp NOT NULL DEFAULT now(),
    CONSTRAINT uq_kb_chunks_file_chunk UNIQUE (source_file_id, chunk_index)
)"""

TRIGGER_FUNCTION = f"""
CREATE OR REPLACE FUNCTION {SCHEMA}.kb_chunks_tsv_update()
RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    NEW.tsv := to_tsvector('portuguese', NEW.text);
    RETURN NEW;
END $fn$"""

TRIGGER = f"""
CREATE TRIGGER trg_kb_chunks_tsv
    BEFORE INSERT OR UPDATE OF text ON {SCHEMA}.kb_chunks
    FOR EACH ROW EXECUTE FUNCTION {SCHEMA}.kb_chunks_tsv_update()"""

# Policies loop: every table except adm_tokens (sensitive pattern — rev a).
POLICY_LOOP = f"""
DO $policy$
DECLARE t record;
BEGIN
    FOR t IN SELECT tablename FROM pg_tables
             WHERE schemaname = '{SCHEMA}' AND tablename <> 'adm_tokens' LOOP
        EXECUTE format('DROP POLICY IF EXISTS mls_anon_read  ON {SCHEMA}.%I', t.tablename);
        EXECUTE format('DROP POLICY IF EXISTS mls_web_write  ON {SCHEMA}.%I', t.tablename);
        EXECUTE format('CREATE POLICY mls_anon_read ON {SCHEMA}.%I FOR SELECT TO fbnet_anon USING (true)', t.tablename);
        EXECUTE format('CREATE POLICY mls_web_write ON {SCHEMA}.%I FOR ALL TO fbnet_web_user USING (true) WITH CHECK (true)', t.tablename);
    END LOOP;
END $policy$"""


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.execute(f"CREATE SCHEMA {SCHEMA}")
    op.execute(f"ALTER SCHEMA {SCHEMA} OWNER TO mylibrary")

    op.execute(TABLE_SOURCES)
    op.execute(TABLE_ADM_TOKENS)
    op.execute(TABLE_SOURCE_FILES)
    op.execute(TABLE_KB_CHUNKS)

    op.execute(f"CREATE INDEX idx_sources_source_name ON {SCHEMA}.sources (source_name)")
    op.execute(f"CREATE INDEX idx_sources_status ON {SCHEMA}.sources (status)")
    op.execute(f"CREATE INDEX idx_sources_source_kind ON {SCHEMA}.sources (source_kind)")
    op.execute(f"CREATE INDEX idx_adm_tokens_hash ON {SCHEMA}.adm_tokens (token_hash)")
    op.execute(f"CREATE INDEX idx_source_files_source_id ON {SCHEMA}.source_files (source_id)")
    op.execute(f"CREATE INDEX idx_source_files_md5sum ON {SCHEMA}.source_files (md5sum)")
    op.execute(f"CREATE INDEX idx_source_files_status ON {SCHEMA}.source_files (status)")
    op.execute(
        f"CREATE INDEX idx_source_files_topics ON {SCHEMA}.source_files USING gin (topics)"
    )
    op.execute(f"CREATE INDEX idx_kb_chunks_source_file ON {SCHEMA}.kb_chunks (source_file_id)")
    op.execute(f"CREATE INDEX idx_kb_chunks_tsv ON {SCHEMA}.kb_chunks USING gin (tsv)")
    op.execute(
        f"CREATE INDEX idx_kb_chunks_embedding ON {SCHEMA}.kb_chunks "
        "USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)"
    )

    op.execute(TRIGGER_FUNCTION)
    op.execute(f"ALTER FUNCTION {SCHEMA}.kb_chunks_tsv_update() OWNER TO mylibrary")
    op.execute(TRIGGER)

    # Tables created by fbnet/master; ownership transfers per P.O. directive.
    op.execute(f"ALTER TABLE {SCHEMA}.sources OWNER TO mylibrary")
    op.execute(f"ALTER TABLE {SCHEMA}.adm_tokens OWNER TO mylibrary")
    op.execute(f"ALTER TABLE {SCHEMA}.source_files OWNER TO mylibrary")
    op.execute(f"ALTER TABLE {SCHEMA}.kb_chunks OWNER TO mylibrary")

    # RBAC (PostgREST canonical: authenticator impersonates anon/web_user).
    op.execute(f"GRANT USAGE ON SCHEMA {SCHEMA} TO fbnet_anon, fbnet_web_user")
    op.execute(f"GRANT SELECT ON ALL TABLES IN SCHEMA {SCHEMA} TO fbnet_anon")
    op.execute(
        f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA {SCHEMA} "
        "TO fbnet_web_user"
    )

    for table in ("sources", "adm_tokens", "source_files", "kb_chunks"):
        op.execute(f"ALTER TABLE {SCHEMA}.{table} ENABLE ROW LEVEL SECURITY")

    op.execute(POLICY_LOOP)
    op.execute(f"DROP POLICY IF EXISTS mls_web_write ON {SCHEMA}.adm_tokens")
    op.execute(f"DROP POLICY IF EXISTS mls_anon_read ON {SCHEMA}.adm_tokens")
    op.execute(
        f"CREATE POLICY mls_tokens_deny ON {SCHEMA}.adm_tokens "
        "FOR SELECT TO fbnet_anon USING (false)"
    )
    op.execute(
        f"CREATE POLICY mls_web_write ON {SCHEMA}.adm_tokens "
        "FOR ALL TO fbnet_web_user USING (true) WITH CHECK (true)"
    )
    op.execute(f"REVOKE ALL ON {SCHEMA}.adm_tokens FROM fbnet_anon")


def downgrade() -> None:
    op.execute(f"DROP SCHEMA IF EXISTS {SCHEMA} CASCADE")