"""0003 — Views de análise (BI/dashboards) do schema mylibrary.

Skill: analytics-views. Camada SOMENTE LEITURA sobre as tabelas de negócio:
  mylibrary.sources · mylibrary.source_files · mylibrary.kb_chunks
(Tabelas de apoio — adm_tokens, alembic_version — deliberadamente ignoradas.)

22 views + 2 helpers de normalização do JSONB `details` (mls_size_bytes, mls_ts),
todas com COMMENT ON VIEW (o comentário aparece como descrição da tabela no BI).
Owner dos objetos: role `mylibrary` (igual ao DDL v1.0.1); GRANT SELECT para
fbnet_anon (PostgREST sem JWT) e fbnet_web_user (JWT).

Idempotente: DROP VIEW IF EXISTS + CREATE — reaplicável a qualquer momento.

Canonical: sql/views_analise_v1.sql (mesmo SQL, self-contained aqui —
PS-8 migrations são a fonte de verdade going forward).

Create Date: 2026-10-14
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

VIEWS_SQL = r"""-- ============================================================
-- MyLibraryScanner — Views de análise (BI / dashboards) do schema mylibrary
-- v1.1.0 — 2026-10-14 — skill: analytics-views
--
-- ESCOPO: camada de ANÁLISE sobre as tabelas de NEGÓCIO do schema:
--     mylibrary.sources · mylibrary.source_files · mylibrary.kb_chunks
--   Tabelas de APOIO ignoradas por decisão do P.O.:
--     mylibrary.adm_tokens (api keys) · alembic_version.
--
-- GRÃO DA FATO: 1 linha de source_files = 1 arquivo de 1 source (source_files
--   é espelho do host; UNIQUE (source_id, file_path)).
--
-- CONVENÇÕES:
--   * nome: v_<tema>_<dimensao>   (estáveis — o BI conecta em nomes)
--   * cada view responde UMA pergunta; o grão vai no COMMENT ON VIEW
--   * agregadas e baratas (nunca SELECT * da fato — exceto v_files_maiores,
--     que é intencionalmente "top por tamanho" e tem grão = arquivo)
--   * sem ORDER BY (o BI ordena); percentuais com NULLIF (nunca /0)
--   * datas de arquivo vêm do JSONB details (strings ISO) via helper mls_ts()
--   * tamanhos em bytes (bigint) + mb (numeric) — o BI formata
--   * idempotente: DROP VIEW IF EXISTS + CREATE, reaplicável a cada deploy
--
-- Fonte de verdade: migration Alembic 0003_analytics_views.py (PS-8) —
--   este arquivo é o espelho canônico legível (mesmo SQL).
-- ============================================================

-- ------------------------------------------------------------
-- 0. Helpers de normalização do JSONB details
--    details é JSONB com strings; casts diretos estouram em dado sujo.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION mylibrary.mls_size_bytes(p_details jsonb)
RETURNS bigint
LANGUAGE sql IMMUTABLE
SET search_path = mylibrary, pg_temp
AS $fn$
    SELECT CASE
             WHEN p_details->>'size_bytes' ~ '^[0-9]+$'
             THEN (p_details->>'size_bytes')::bigint
           END
$fn$;

COMMENT ON FUNCTION mylibrary.mls_size_bytes(jsonb) IS
'Tamanho do arquivo em bytes, extraído de details->>size_bytes (NULL se ausente/inválido).';

CREATE OR REPLACE FUNCTION mylibrary.mls_ts(p_details jsonb, p_key text)
RETURNS timestamp
LANGUAGE sql IMMUTABLE
SET search_path = mylibrary, pg_temp
AS $fn$
    SELECT CASE
             WHEN p_details->>p_key ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
             THEN replace(left(p_details->>p_key, 26), 'T', ' ')::timestamp
           END
$fn$;

COMMENT ON FUNCTION mylibrary.mls_ts(jsonb, text) IS
'Data (timestamp) a partir de uma chave ISO de details (creation_date, modification_date, access_date).';

-- ============================================================
-- GRUPO 1 — PANORAMA
-- ============================================================

-- 1.1 Panorama do acervo (1 linha) — cartões de KPI do dashboard.
DROP VIEW IF EXISTS mylibrary.v_files_resumo;
CREATE VIEW mylibrary.v_files_resumo AS
SELECT
    (SELECT count(*) FROM mylibrary.sources)                                  AS sources,
    (SELECT count(*) FROM mylibrary.sources WHERE status = 'OK')             AS sources_ok,
    count(*)                                                                 AS arquivos_total,
    count(*) FILTER (WHERE status = 'OK')                                    AS arquivos_ok,
    count(*) FILTER (WHERE status = 'ERROR')                                 AS arquivos_error,
    count(*) FILTER (WHERE status = 'SKIPPED')                               AS arquivos_skipped,
    coalesce(sum(mylibrary.mls_size_bytes(details)), 0)                      AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(details)), 0) / 1048576.0, 1) AS mb_total,
    max(mylibrary.mls_size_bytes(details))                                   AS bytes_maior_arquivo,
    round(avg(mylibrary.mls_size_bytes(details)))                            AS bytes_medio,
    percentile_cont(0.5) WITHIN GROUP (ORDER BY mylibrary.mls_size_bytes(details)) AS bytes_mediana,
    count(*) FILTER (WHERE mylibrary.mls_size_bytes(details) = 0)           AS arquivos_vazios,
    count(*) FILTER (WHERE details ? 'content_family')                       AS arquivos_com_familia,
    count(*) FILTER (WHERE md5sum IS NOT NULL AND md5sum <> '')              AS arquivos_com_md5,
    count(*) FILTER (WHERE array_length(topics, 1) > 0)                      AS arquivos_com_tags,
    count(*) FILTER (WHERE inference IS NOT NULL AND btrim(inference) <> '') AS arquivos_com_inferencia,
    (SELECT count(*) FROM mylibrary.kb_chunks)                               AS kb_chunks,
    min(mylibrary.mls_ts(details, 'modification_date'))::date                AS arquivo_mais_antigo,
    max(mylibrary.mls_ts(details, 'modification_date'))::date                AS arquivo_mais_recente,
    min(processed_at)::date                                                  AS primeiro_scan,
    max(processed_at)::date                                                  AS ultimo_scan
FROM mylibrary.source_files;

COMMENT ON VIEW mylibrary.v_files_resumo IS
'Panorama do acervo: UMA linha com os KPIs gerais — sources, arquivos (por status), espaço total (bytes/MB), maior arquivo, média/mediana, vazios, cobertura (md5/família/tags/inferência/chunks) e janela de datas. Grão: linha única (agregado global).';

-- 1.2 Acervo por source — qual library concentra o quê.
DROP VIEW IF EXISTS mylibrary.v_sources_resumo;
CREATE VIEW mylibrary.v_sources_resumo AS
SELECT
    s.source_name,
    s.source_kind,
    s.source_path,
    s.status                                                          AS scan_status,
    s.start_extraction::date                                          AS scan_inicio,
    s.end_extraction::date                                            AS scan_fim,
    s.files_total,
    count(f.id)                                                       AS arquivos,
    count(f.id) FILTER (WHERE f.status = 'OK')                        AS arquivos_ok,
    count(f.id) FILTER (WHERE f.status <> 'OK')                       AS arquivos_problema,
    coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0)             AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes,
    round(100.0 * count(f.id)
          / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    max(mylibrary.mls_size_bytes(f.details))                          AS bytes_maior_arquivo,
    count(f.id) FILTER (WHERE f.details ? 'content_family')           AS arquivos_com_familia,
    count(f.id) FILTER (WHERE array_length(f.topics, 1) > 0)          AS arquivos_com_tags
FROM mylibrary.sources s
LEFT JOIN mylibrary.source_files f ON f.source_id = s.id
GROUP BY s.id, s.source_name, s.source_kind, s.source_path, s.status,
         s.start_extraction, s.end_extraction, s.files_total;

COMMENT ON VIEW mylibrary.v_sources_resumo IS
'Acervo de cada source (library): arquivos, problemas, espaço (bytes/MB) e participação (% do acervo em arquivos e em bytes) + cobertura de família/tags. Grão: uma linha por source. Responde: "como está o acervo de cada library e quanto cada uma pesa?".';

-- ============================================================
-- GRUPO 2 — ARMAZENAMENTO POR DIMENSÃO
-- ============================================================

-- 2.1 Por MIME type (facet) — o que ocupa o disco por tipo declarado.
DROP VIEW IF EXISTS mylibrary.v_files_por_mime;
CREATE VIEW mylibrary.v_files_por_mime AS
SELECT
    details->>'mime_type_code'                     AS mime_type_code,
    max(details->>'mime_type_description')        AS mime_type_descricao,
    count(*)                                      AS arquivos,
    coalesce(sum(mylibrary.mls_size_bytes(details)), 0) AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(details)), 0) / 1048576.0, 1) AS mb_total,
    round(avg(mylibrary.mls_size_bytes(details)))  AS bytes_medio,
    max(mylibrary.mls_size_bytes(details))         AS bytes_maior,
    round(100.0 * count(*) / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes,
    count(DISTINCT source_id)                     AS sources
FROM mylibrary.source_files
WHERE details->>'mime_type_code' IS NOT NULL
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_por_mime IS
'Facet de MIME types: arquivos, espaço (bytes/MB), tamanho médio/maior e participação (% de arquivos e % do espaço) por mime_type_code (com a descrição legível). Grão: uma linha por mime type. Responde: "quais tipos de arquivo ocupam o meu disco?".';

-- 2.2 Por extensão (normalizada) — inclui divergência extensão x MIME.
DROP VIEW IF EXISTS mylibrary.v_files_por_extensao;
CREATE VIEW mylibrary.v_files_por_extensao AS
SELECT
    lower(nullif(details->>'extension', ''))      AS extensao,
    count(*)                                      AS arquivos,
    coalesce(sum(mylibrary.mls_size_bytes(details)), 0) AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(details)), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * count(*) / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes,
    count(*) FILTER (WHERE details->>'extension' <> lower(details->>'extension')) AS arquivos_caixa_alta,
    count(*) FILTER (WHERE details ? 'extension_corrected')                        AS extensoes_corrigidas
FROM mylibrary.source_files
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_por_extensao IS
'Facet de extensões (normalizadas em minúsculas — .JPG e .jpg contam juntos): arquivos, espaço e participação, mais o quantitativo de arquivos com caixa alta e de extensões corrigidas. Grão: uma linha por extensão. Responde: "que formatos eu tenho e quanto pesam?".';

-- 2.3 Por família de conteúdo — atenção: arquivos grandes costumam ser "sem família".
DROP VIEW IF EXISTS mylibrary.v_files_por_familia;
CREATE VIEW mylibrary.v_files_por_familia AS
SELECT
    coalesce(details->>'content_family', '(sem familia)') AS content_family,
    count(*)                                      AS arquivos,
    coalesce(sum(mylibrary.mls_size_bytes(details)), 0) AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(details)), 0) / 1048576.0, 1) AS mb_total,
    max(mylibrary.mls_size_bytes(details))        AS bytes_maior,
    round(100.0 * count(*) / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes
FROM mylibrary.source_files
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_por_familia IS
'Facet por família de conteúdo (image/document/archive/audio_video) — a linha "(sem familia)" mostra os arquivos que a inferência não classificou e que normalmente concentram a maior parte do ESPAÇO. Grão: uma linha por família (inclui a linha de ausência).';

-- 2.4 Por faixa de tamanho — revela a concentração do espaço em poucos arquivos.
DROP VIEW IF EXISTS mylibrary.v_files_por_faixa_tamanho;
CREATE VIEW mylibrary.v_files_por_faixa_tamanho AS
SELECT
    CASE
        WHEN b.bytes IS NULL      THEN '0) sem tamanho'
        WHEN b.bytes = 0          THEN '1) 0 bytes (vazio)'
        WHEN b.bytes < 102400     THEN '2) ate 100 KB'
        WHEN b.bytes < 1048576    THEN '3) 100 KB a 1 MB'
        WHEN b.bytes < 10485760   THEN '4) 1 a 10 MB'
        WHEN b.bytes < 104857600  THEN '5) 10 a 100 MB'
        WHEN b.bytes < 1073741824 THEN '6) 100 MB a 1 GB'
        ELSE                           '7) acima de 1 GB'
    END                                           AS faixa_tamanho,
    count(*)                                      AS arquivos,
    coalesce(sum(b.bytes), 0)                     AS bytes_total,
    round(coalesce(sum(b.bytes), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * count(*) / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    round(100.0 * coalesce(sum(b.bytes), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes
FROM (SELECT mylibrary.mls_size_bytes(details) AS bytes FROM mylibrary.source_files) b
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_por_faixa_tamanho IS
'Distribuição por faixa de tamanho (vazio, até 100 KB, 1 MB, 10 MB, 100 MB, 1 GB, acima): quantidade de arquivos vs. espaço ocupado. Grão: uma linha por faixa. Responde: "o meu espaço está concentrado em poucos arquivos gigantes ou espalhado em muitos pequenos?".';

-- 2.5 Por diretório — onde o espaço mora dentro das sources.
DROP VIEW IF EXISTS mylibrary.v_files_por_diretorio;
CREATE VIEW mylibrary.v_files_por_diretorio AS
SELECT
    s.source_name,
    regexp_replace(f.file_path, '/[^/]*$', '')     AS diretorio,
    count(*)                                      AS arquivos,
    coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) / 1048576.0, 1) AS mb_total,
    max(mylibrary.mls_size_bytes(f.details))      AS bytes_maior,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes_acervo
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
WHERE f.status = 'OK'
GROUP BY 1, 2;

COMMENT ON VIEW mylibrary.v_files_por_diretorio IS
'Espaço por diretório imediato (o caminho sem o nome do arquivo), por source: arquivos, bytes/MB, maior arquivo e % do acervo. Grão: uma linha por (source, diretório). Responde: "quais pastas estão pesando?".';

-- 2.6 Os maiores arquivos — o topo que explica o disco.
DROP VIEW IF EXISTS mylibrary.v_files_maiores;
CREATE VIEW mylibrary.v_files_maiores AS
SELECT
    s.source_name,
    f.file_path,
    f.details->>'complete_filename'               AS arquivo,
    lower(nullif(f.details->>'extension', ''))    AS extensao,
    f.details->>'mime_type_code'                  AS mime_type_code,
    f.details->>'content_family'                  AS content_family,
    mylibrary.mls_size_bytes(f.details)           AS bytes,
    round(mylibrary.mls_size_bytes(f.details) / 1048576.0, 1) AS mb,
    round(100.0 * mylibrary.mls_size_bytes(f.details)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 2) AS pct_do_acervo,
    mylibrary.mls_ts(f.details, 'modification_date')::date AS modificado_em,
    mylibrary.mls_ts(f.details, 'access_date')::date      AS acessado_em,
    row_number() OVER (ORDER BY mylibrary.mls_size_bytes(f.details) DESC NULLS LAST) AS posicao,
    f.md5sum
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
WHERE f.status = 'OK';

COMMENT ON VIEW mylibrary.v_files_maiores IS
'Ranking dos arquivos por tamanho (uma linha por arquivo — view de detalhe intencional): caminho, tipo, bytes/MB, % do acervo, datas e md5. Grão: uma linha por arquivo (ordenada por posicao). Responde: "quais arquivos individuais estão consumindo o meu disco?".';

-- 2.7 Matriz source x família — mapa de calor do acervo.
DROP VIEW IF EXISTS mylibrary.v_files_matriz_source_familia;
CREATE VIEW mylibrary.v_files_matriz_source_familia AS
SELECT
    s.source_name,
    coalesce(f.details->>'content_family', '(sem familia)') AS content_family,
    count(*)                                      AS arquivos,
    coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) / 1048576.0, 1) AS mb_total
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
GROUP BY 1, 2;

COMMENT ON VIEW mylibrary.v_files_matriz_source_familia IS
'Matriz source x família de conteúdo (mapa de calor): arquivos e espaço em cada cruzamento. Grão: uma linha por (source, família). Responde: "cada library é feita do quê?".';

-- ============================================================
-- GRUPO 3 — TEMPO (idade e esquecimento dos arquivos)
-- ============================================================

-- 3.1 Por ano de modificação — a linha do tempo do acervo.
DROP VIEW IF EXISTS mylibrary.v_files_por_ano_modificacao;
CREATE VIEW mylibrary.v_files_por_ano_modificacao AS
SELECT
    date_part('year', t.modificado)::int          AS ano,
    count(*)                                      AS arquivos,
    coalesce(sum(t.bytes), 0)                     AS bytes_total,
    round(coalesce(sum(t.bytes), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * count(*) / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    round(100.0 * coalesce(sum(t.bytes), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes
FROM (
    SELECT mylibrary.mls_size_bytes(details) AS bytes,
           mylibrary.mls_ts(details, 'modification_date') AS modificado
    FROM mylibrary.source_files
    WHERE status = 'OK'
) t
WHERE t.modificado IS NOT NULL
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_por_ano_modificacao IS
'Acervo por ano de modificação do arquivo (data do próprio arquivo, não do scan): arquivos, espaço e participação. Grão: uma linha por ano. Responde: "de que época é o meu acervo?".';

-- 3.2 Por faixa de idade (desde a última modificação).
DROP VIEW IF EXISTS mylibrary.v_files_idade_modificacao;
CREATE VIEW mylibrary.v_files_idade_modificacao AS
SELECT
    CASE
        WHEN t.dias IS NULL    THEN '0) sem data'
        WHEN t.dias <= 30      THEN '1) ate 30 dias'
        WHEN t.dias <= 180     THEN '2) 1 a 6 meses'
        WHEN t.dias <= 365     THEN '3) 6 a 12 meses'
        WHEN t.dias <= 1095    THEN '4) 1 a 3 anos'
        ELSE                        '5) mais de 3 anos'
    END                                           AS faixa_idade,
    count(*)                                      AS arquivos,
    coalesce(sum(t.bytes), 0)                     AS bytes_total,
    round(coalesce(sum(t.bytes), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * coalesce(sum(t.bytes), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes
FROM (
    SELECT mylibrary.mls_size_bytes(details) AS bytes,
           (current_date - mylibrary.mls_ts(details, 'modification_date')::date) AS dias
    FROM mylibrary.source_files
    WHERE status = 'OK'
) t
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_idade_modificacao IS
'Idade dos arquivos desde a última modificação, em faixas (até 30 dias … mais de 3 anos): arquivos, espaço e % do acervo. Grão: uma linha por faixa. Responde: "quanto do meu disco é conteúdo velho/estagnado?".';

-- 3.3 Arquivos frios (pelo último acesso) — candidatos naturais a arquivo morto.
DROP VIEW IF EXISTS mylibrary.v_files_frios_por_acesso;
CREATE VIEW mylibrary.v_files_frios_por_acesso AS
SELECT
    CASE
        WHEN t.dias IS NULL    THEN '0) sem data de acesso'
        WHEN t.dias <= 30      THEN '1) acessado nos ultimos 30 dias'
        WHEN t.dias <= 180     THEN '2) 1 a 6 meses sem acesso'
        WHEN t.dias <= 365     THEN '3) 6 a 12 meses sem acesso'
        WHEN t.dias <= 1095    THEN '4) 1 a 3 anos sem acesso'
        ELSE                        '5) mais de 3 anos sem acesso'
    END                                           AS faixa_ultimo_acesso,
    count(*)                                      AS arquivos,
    coalesce(sum(t.bytes), 0)                     AS bytes_total,
    round(coalesce(sum(t.bytes), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * coalesce(sum(t.bytes), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes
FROM (
    SELECT mylibrary.mls_size_bytes(details) AS bytes,
           (current_date - mylibrary.mls_ts(details, 'access_date')::date) AS dias
    FROM mylibrary.source_files
    WHERE status = 'OK'
) t
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_frios_por_acesso IS
'Quanto tempo cada arquivo está sem ser acessado (access_date do metadata), em faixas: arquivos, espaço e % do acervo. Grão: uma linha por faixa. Responde: "quanto do meu disco é dado frio (nunca mais aberto)?" — insumo clássico de política de retenção/backup.';

-- ============================================================
-- GRUPO 4 — DUPLICATAS (exatas e potenciais)
-- ============================================================

-- 4.1 Duplicatas EXATAS por md5sum — e quanto custam.
DROP VIEW IF EXISTS mylibrary.v_dupes_exatas;
CREATE VIEW mylibrary.v_dupes_exatas AS
WITH d AS (
    SELECT md5sum,
           count(*)                                   AS copias,
           count(DISTINCT source_id)                  AS fontes_distintas,
           max(mylibrary.mls_size_bytes(details))     AS bytes,
           min(file_path)                             AS exemplo_path,
           min(processed_at)::date                    AS visto_em
    FROM mylibrary.source_files
    WHERE status = 'OK' AND md5sum IS NOT NULL AND md5sum <> ''
    GROUP BY md5sum
    HAVING count(*) > 1
)
SELECT
    d.md5sum,
    d.copias,
    d.fontes_distintas,
    CASE WHEN d.fontes_distintas > 1 THEN 'INTER-sources' ELSE 'INTRA-source' END AS escopo,
    coalesce(d.bytes, 0)                          AS bytes_cada,
    round(coalesce(d.bytes, 0) * (d.copias - 1) / 1048576.0, 2) AS mb_recuperaveis,
    d.copias - 1                                  AS copias_excedentes,
    d.exemplo_path,
    d.visto_em,
    'Manter 1 copia e remover as ' || (d.copias - 1) || ' excedentes' AS acao_sugerida
FROM d;

COMMENT ON VIEW mylibrary.v_dupes_exatas IS
'Duplicatas EXATAS (mesmo md5sum) agrupadas por conteúdo: nº de cópias, quantas sources envolvidas (INTER-sources = mesmo arquivo em libraries diferentes; INTRA-source = repetido dentro da mesma library), tamanho de cada cópia, MB recuperáveis ((cópias-1) x tamanho), arquivo-exemplo e ação sugerida. Grão: uma linha por md5sum duplicado. Responde: "quais arquivos são cópias idênticas e quanto eu recupero removendo as excedentes?".';

-- 4.2 Detalhe das duplicatas exatas — a lista de trabalho (o que remover).
DROP VIEW IF EXISTS mylibrary.v_dupes_exatas_detalhe;
CREATE VIEW mylibrary.v_dupes_exatas_detalhe AS
WITH g AS (
    SELECT md5sum FROM mylibrary.source_files
    WHERE status = 'OK' AND md5sum IS NOT NULL AND md5sum <> ''
    GROUP BY md5sum HAVING count(*) > 1
)
SELECT
    f.md5sum,
    s.source_name,
    f.file_path,
    f.details->>'complete_filename'                AS arquivo,
    mylibrary.mls_size_bytes(f.details)            AS bytes,
    round(mylibrary.mls_size_bytes(f.details) / 1048576.0, 2) AS mb,
    mylibrary.mls_ts(f.details, 'modification_date')::date AS modificado_em,
    f.processed_at::date                           AS visto_em,
    row_number() OVER (PARTITION BY f.md5sum
                       ORDER BY mylibrary.mls_ts(f.details, 'modification_date') NULLS LAST, f.file_path) AS ordem_por_antiguidade,
    f.id                                           AS source_file_id
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
JOIN g ON g.md5sum = f.md5sum
WHERE f.status = 'OK';

COMMENT ON VIEW mylibrary.v_dupes_exatas_detalhe IS
'Lista arquivo-a-arquivo de todas as cópias de duplicatas exatas (grão: uma linha por arquivo duplicado, com o source_file_id para agir via API). ordem_por_antiguidade = 1 é o candidato natural a ser mantido. Responde: "exatamente quais cópias eu devo revisar/remover?".';

-- 4.3 Duplicatas POTENCIAIS pelo NOME normalizado (sufixos de cópia removidos).
--     Pega "Fatura Claro (3)/(4)/(5).pdf", "arquivo - copia", "relatorio 2" etc.,
--     que a checagem exata de md5 NÃO agrupa porque o nome difere.
DROP VIEW IF EXISTS mylibrary.v_dupes_potenciais_nome;
CREATE VIEW mylibrary.v_dupes_potenciais_nome AS
WITH base AS (
    SELECT f.id,
           f.source_id,
           f.file_path,
           f.md5sum,
           mylibrary.mls_size_bytes(f.details)          AS bytes,
           lower(nullif(f.details->>'extension', ''))   AS extensao,
           regexp_replace(
             regexp_replace(lower(f.details->>'filename_no_ext'),
               '[[:space:]]*[\(\[]([[:space:]]*(c[oó]pia|copia|copy|[0-9]+)[[:space:]]*)[\)\]][[:space:]]*$', '', 'g'),
             '[[:space:]]+[-_]?[[:space:]]*(c[oó]pia|copia|copy)([[:space:]]*[0-9]+)?[[:space:]]*$', '', 'g')  AS nome_normalizado
    FROM mylibrary.source_files f
    WHERE f.status = 'OK'
      AND f.details->>'filename_no_ext' IS NOT NULL
      AND btrim(f.details->>'filename_no_ext') <> ''
),
g AS (
    SELECT b.nome_normalizado,
           b.extensao,
           count(*)                                    AS copias,
           count(DISTINCT b.md5sum)                    AS hashes_distintos,
           count(DISTINCT b.source_id)                 AS fontes_distintas,
           count(DISTINCT b.bytes)                     AS tamanhos_distintos,
           min(b.bytes)                                AS bytes_min,
           max(b.bytes)                                AS bytes_max,
           coalesce(sum(b.bytes), 0)                   AS bytes_total,
           string_agg(DISTINCT b.file_path, ' | ' ORDER BY b.file_path) AS caminhos
    FROM base b
    GROUP BY 1, 2
    HAVING count(*) > 1
)
SELECT
    g.nome_normalizado,
    g.extensao,
    g.copias,
    g.hashes_distintos,
    g.tamanhos_distintos,
    g.fontes_distintas,
    g.bytes_min,
    g.bytes_max,
    round(g.bytes_total / 1048576.0, 2)              AS mb_total,
    CASE
        WHEN g.hashes_distintos = 1
            THEN 'Duplicatas EXATAS (mesmo conteudo) — detalhar em v_dupes_exatas'
        WHEN g.tamanhos_distintos = 1
            THEN 'Mesmo nome e MESMO tamanho, hash diferente — inspecionar (copia alterada)'
        WHEN g.fontes_distintas > 1
            THEN 'Mesmo nome em sources diferentes — provavel duplicata entre libraries'
        ELSE 'Varias versoes do mesmo nome (tamanhos diferentes) — versoes/edicoes'
    END                                              AS suspeita,
    round(100.0 * (g.copias - 1) * (g.bytes_total / NULLIF(g.copias, 0))
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 3) AS pct_acervo_em_risco,
    g.caminhos
FROM g;

COMMENT ON VIEW mylibrary.v_dupes_potenciais_nome IS
'Suspeitas de duplicação pelo NOME, com os sufixos de cópia removidos ("(3)", "- copia", " 2"): agrupa arquivos que compartilham o mesmo nome-base e extensão, com ou sem o mesmo tamanho — é o que a checagem por md5 NÃO pega ("Fatura Claro (3)/(4)/(5).pdf"). Traz nº de cópias, hashes distintos, se os tamanhos coincidem (sinal forte), tamanho mínimo/máximo, MB em risco e a lista de caminhos. Grão: uma linha por (nome-base normalizado, extensão). Responde: "onde há duplicação/versões além das cópias idênticas?".';

-- 4.4 Duplicatas POTENCIAIS pelo cabeçalho (sha256 dos primeiros 256 bytes).
DROP VIEW IF EXISTS mylibrary.v_dupes_potenciais_cabecalho;
CREATE VIEW mylibrary.v_dupes_potenciais_cabecalho AS
WITH d AS (
    SELECT details->>'first_256_bytes_sha256_hex' AS cabecalho_sha256,
           count(*)                               AS arquivos,
           count(DISTINCT md5sum)                 AS hashes_distintos,
           count(DISTINCT lower(details->>'extension')) AS extensoes_distintas,
           coalesce(sum(mylibrary.mls_size_bytes(details)), 0) AS bytes_total,
           min(file_path)                         AS exemplo_path,
           string_agg(DISTINCT lower(details->>'extension'), ', ') AS extensoes
    FROM mylibrary.source_files
    WHERE status = 'OK'
      AND details ? 'first_256_bytes_sha256_hex'
    GROUP BY 1
    HAVING count(*) > 1
)
SELECT
    d.cabecalho_sha256,
    d.arquivos,
    d.hashes_distintos,
    d.extensoes_distintas,
    d.extensoes,
    d.bytes_total,
    round(d.bytes_total / 1048576.0, 2)           AS mb_total,
    CASE
        WHEN d.hashes_distintos = 1 THEN 'Conteudo identico nos primeiros 256 bytes e mesmo md5'
        ELSE 'Comecam igual mas divergem - mesma origem (download repetido, arquivo truncado/parcial)'
    END                                           AS suspeita,
    d.exemplo_path
FROM d;

COMMENT ON VIEW mylibrary.v_dupes_potenciais_cabecalho IS
'Arquivos que compartilham o MESMO cabeçalho (sha256 dos primeiros 256 bytes) mas têm md5 diferentes no grupo — pega download repetido, arquivo parcial/truncado e o mesmo conteúdo salvo em extensões distintas. Grão: uma linha por cabeçalho compartilhado. Responde: "que arquivos começam iguais e merecem inspeção?".';

-- 4.5 Resumo do desperdício — o cartão "espaço recuperável".
DROP VIEW IF EXISTS mylibrary.v_dupes_resumo;
CREATE VIEW mylibrary.v_dupes_resumo AS
WITH exatas AS (
    SELECT md5sum, count(*) AS copias, max(mylibrary.mls_size_bytes(details)) AS bytes
    FROM mylibrary.source_files
    WHERE status = 'OK' AND md5sum IS NOT NULL AND md5sum <> ''
    GROUP BY md5sum HAVING count(*) > 1
)
SELECT
    (SELECT count(*) FROM exatas)                                    AS grupos_exatos,
    (SELECT coalesce(sum(copias), 0) FROM exatas)                    AS arquivos_envolvidos,
    (SELECT coalesce(sum(bytes * (copias - 1)), 0) FROM exatas)      AS bytes_recuperaveis,
    round((SELECT coalesce(sum(bytes * (copias - 1)), 0) FROM exatas) / 1048576.0, 2) AS mb_recuperaveis,
    round(100.0 * (SELECT coalesce(sum(bytes * (copias - 1)), 0) FROM exatas)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 2) AS pct_do_acervo,
    (SELECT count(*) FROM mylibrary.source_files
      WHERE status = 'OK' AND details->>'first_256_bytes_sha256_hex' IN (
            SELECT details->>'first_256_bytes_sha256_hex' FROM mylibrary.source_files
            WHERE status = 'OK' GROUP BY 1 HAVING count(*) > 1))     AS arquivos_mesmo_cabecalho
-- Nota: os grupos de duplicatas POTENCIAIS por nome são contados direto da view
-- mylibrary.v_dupes_potenciais_nome (uma view não referencia outra de propósito:
-- assim cada view pode ser recriada/republicada de forma independente).
;

COMMENT ON VIEW mylibrary.v_dupes_resumo IS
'Cartão de desperdício: grupos de duplicatas exatas, arquivos envolvidos, bytes/MB recuperáveis e o % que isso representa do acervo — mais o total de arquivos que compartilham cabeçalho (mesmos primeiros 256 bytes) e merecem inspeção. Para as suspeitas por nome, consulte a view mylibrary.v_dupes_potenciais_nome. Grão: linha única (agregado global). Responde: "quanto de espaço eu recupero limpando duplicatas?".';

-- ============================================================
-- GRUPO 5 — FACETS DE CONTEÚDO (tags, palavras-chave) E PIPELINE
-- ============================================================

-- 5.1 Facet de TAGS (topics gerados pela inferência).
DROP VIEW IF EXISTS mylibrary.v_files_tags;
CREATE VIEW mylibrary.v_files_tags AS
SELECT
    t.tag                                         AS tag,
    count(DISTINCT f.id)                          AS arquivos,
    count(DISTINCT f.source_id)                   AS sources,
    coalesce(sum(DISTINCT mylibrary.mls_size_bytes(f.details)), 0) AS bytes_total,
    round(100.0 * count(DISTINCT f.id)
          / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos
FROM mylibrary.source_files f
CROSS JOIN LATERAL unnest(f.topics) AS t(tag)
WHERE f.status = 'OK'
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_tags IS
'Facet das TAGS (coluna topics, produzida pela inferência de conteúdo): arquivos e espaço por tag. Grão: uma linha por tag. ATENÇÃO: devolve 0 linhas enquanto a inferência não tiver sido executada (topics vazio) — é a view que se popula sozinha quando o pipeline rodar. Responde: "quais assuntos rotulam o meu acervo?".';

-- 5.2 Facet de PALAVRAS-CHAVE do nome do arquivo (disponível hoje).
DROP VIEW IF EXISTS mylibrary.v_files_palavras_nome;
CREATE VIEW mylibrary.v_files_palavras_nome AS
SELECT
    w.palavra,
    count(DISTINCT f.id)                          AS arquivos,
    count(DISTINCT f.source_id)                   AS sources,
    coalesce(sum(DISTINCT mylibrary.mls_size_bytes(f.details)), 0) AS bytes_total,
    round(100.0 * count(DISTINCT f.id)
          / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos
FROM mylibrary.source_files f
CROSS JOIN LATERAL regexp_split_to_table(
        lower(coalesce(f.details->>'filename_no_ext', '') || ' ' || coalesce(f.details->>'extension', '')),
        '[^[:alnum:]]+') AS w(palavra)
WHERE f.status = 'OK'
  AND length(w.palavra) >= 3
  AND w.palavra !~ '^[0-9]+$'
  AND w.palavra NOT IN ('das','dos','para','com','uma','que','por','the','and','for','pdf','png','jpg','jpeg','txt','doc','docx','xls','xlsx','csv','zip','rar','mp4','mp3','wav','ogg','de','da','do','em','no','na','os','as','e','a','o','um')
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_files_palavras_nome IS
'Facet de PALAVRAS-CHAVE extraídas do nome do arquivo (sem extensões e termos vazios): arquivos, espaço e participação por palavra. Grão: uma linha por palavra. É o facet de "palavras-chave" que funciona HOJE (o texto de conteúdo só existe após a inferência/KB). Responde: "que termos aparecem nos meus nomes de arquivo (fatura, edital, contrato…)?".';

-- 5.3 Funil de processamento por source — o que já foi processado.
DROP VIEW IF EXISTS mylibrary.v_files_pipeline_status;
CREATE VIEW mylibrary.v_files_pipeline_status AS
SELECT
    s.source_name,
    count(f.id)                                              AS arquivos,
    count(f.id) FILTER (WHERE f.md5sum IS NOT NULL AND f.md5sum <> '')  AS com_md5,
    count(f.id) FILTER (WHERE f.details ? 'mime_type_code')  AS com_mime,
    count(f.id) FILTER (WHERE f.details ? 'content_family')   AS com_familia,
    count(f.id) FILTER (WHERE f.inference IS NOT NULL AND btrim(f.inference) <> '') AS com_inferencia,
    count(f.id) FILTER (WHERE array_length(f.topics, 1) > 0) AS com_tags,
    count(DISTINCT k.source_file_id)                          AS com_chunks,
    round(100.0 * count(f.id) FILTER (WHERE f.inference IS NOT NULL AND btrim(f.inference) <> '')
          / NULLIF(count(f.id) FILTER (WHERE f.status = 'OK'), 0), 1) AS pct_inferido,
    round(100.0 * count(DISTINCT k.source_file_id)
          / NULLIF(count(f.id) FILTER (WHERE f.status = 'OK'), 0), 1) AS pct_na_kb
FROM mylibrary.sources s
LEFT JOIN mylibrary.source_files f ON f.source_id = s.id
LEFT JOIN mylibrary.kb_chunks k    ON k.source_file_id = f.id
GROUP BY s.id, s.source_name;

COMMENT ON VIEW mylibrary.v_files_pipeline_status IS
'Funil de processamento por source: quantos arquivos têm metadados (md5, mime, família), inferência de conteúdo, tags e chunks na KB — com os percentuais de conclusão. Grão: uma linha por source. Responde: "o que já foi processado e o que falta em cada library?".';

-- 5.4 Cobertura da KB (RAG) por família — a fila de embedding.
DROP VIEW IF EXISTS mylibrary.v_kb_cobertura;
CREATE VIEW mylibrary.v_kb_cobertura AS
SELECT
    coalesce(f.details->>'content_family', '(sem familia)') AS content_family,
    count(*)                                                  AS arquivos,
    count(DISTINCT f.id) FILTER (WHERE k.source_file_id IS NOT NULL) AS arquivos_na_kb,
    count(*) FILTER (WHERE k.source_file_id IS NULL)          AS arquivos_sem_kb,
    count(k.id)                                               AS chunks,
    round(100.0 * count(DISTINCT f.id) FILTER (WHERE k.source_file_id IS NOT NULL)
          / NULLIF(count(*), 0), 1)                           AS pct_na_kb
FROM mylibrary.source_files f
LEFT JOIN mylibrary.kb_chunks k ON k.source_file_id = f.id
WHERE f.status = 'OK'
GROUP BY 1;

COMMENT ON VIEW mylibrary.v_kb_cobertura IS
'Cobertura da base de conhecimento (kb_chunks) por família de conteúdo: arquivos indexados, arquivos AINDA SEM chunks (a fila do RAG) e total de chunks. Grão: uma linha por família. Responde: "quanto do acervo já está pesquisável por conteúdo?".';

-- ============================================================
-- GRUPO 6 — SAÚDE DO SCAN
-- ============================================================

-- 6.1 Arquivos com problema (SKIPPED/ERROR) e a razão.
DROP VIEW IF EXISTS mylibrary.v_files_problemas;
CREATE VIEW mylibrary.v_files_problemas AS
SELECT
    s.source_name,
    f.file_path,
    f.status,
    f.status_message,
    mylibrary.mls_size_bytes(f.details)           AS bytes,
    f.details->>'mime_type_code'                  AS mime_type_code,
    f.processed_at::date                          AS visto_em
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
WHERE f.status <> 'OK';

COMMENT ON VIEW mylibrary.v_files_problemas IS
'Arquivos que o scan não conseguiu processar (status SKIPPED/ERROR) com a mensagem de erro e o contexto: o que auditar quando o total de arquivos não bate. Grão: uma linha por arquivo com problema. Responde: "o que falhou no scan e por quê?".';

-- ============================================================
-- 7. OWNERSHIP + GRANTS (padrão da casa — igual ao DDL v1.0.1 bloco 5/6)
--    O executor aqui é a role `fbnet` (master); o owner canônico dos
--    objetos do schema é `mylibrary`. Como objetos criados por `fbnet`
--    NÃO pegam as DEFAULT PRIVILEGES da role `mylibrary`, os GRANTs vão
--    explícitos (o anon precisa do SELECT para o PostgREST/webapp).
-- ============================================================
ALTER VIEW mylibrary.v_files_resumo                  OWNER TO mylibrary;
ALTER VIEW mylibrary.v_sources_resumo                OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_mime                OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_extensao            OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_familia             OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_faixa_tamanho       OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_diretorio           OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_maiores                 OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_matriz_source_familia   OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_por_ano_modificacao     OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_idade_modificacao       OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_frios_por_acesso        OWNER TO mylibrary;
ALTER VIEW mylibrary.v_dupes_exatas                   OWNER TO mylibrary;
ALTER VIEW mylibrary.v_dupes_exatas_detalhe          OWNER TO mylibrary;
ALTER VIEW mylibrary.v_dupes_potenciais_nome         OWNER TO mylibrary;
ALTER VIEW mylibrary.v_dupes_potenciais_cabecalho    OWNER TO mylibrary;
ALTER VIEW mylibrary.v_dupes_resumo                   OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_tags                    OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_palavras_nome           OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_pipeline_status         OWNER TO mylibrary;
ALTER VIEW mylibrary.v_kb_cobertura                  OWNER TO mylibrary;
ALTER VIEW mylibrary.v_files_problemas               OWNER TO mylibrary;
ALTER FUNCTION mylibrary.mls_size_bytes(jsonb)          OWNER TO mylibrary;
ALTER FUNCTION mylibrary.mls_ts(jsonb, text)            OWNER TO mylibrary;

-- Leitura: anon (PostgREST sem JWT) e web_user (JWT) — views são read-only.
GRANT SELECT ON ALL TABLES IN SCHEMA mylibrary TO fbnet_anon;
GRANT SELECT ON ALL TABLES IN SCHEMA mylibrary TO fbnet_web_user;

-- ============================================================
-- FIM — 22 views + 2 helpers.
-- Reaplicável (DROP + CREATE). Após CREATE: owners/grants.
-- ============================================================
"""

VIEWS = ['v_files_resumo', 'v_sources_resumo', 'v_files_por_mime', 'v_files_por_extensao', 'v_files_por_familia', 'v_files_por_faixa_tamanho', 'v_files_por_diretorio', 'v_files_maiores', 'v_files_matriz_source_familia', 'v_files_por_ano_modificacao', 'v_files_idade_modificacao', 'v_files_frios_por_acesso', 'v_dupes_exatas', 'v_dupes_exatas_detalhe', 'v_dupes_potenciais_nome', 'v_dupes_potenciais_cabecalho', 'v_dupes_resumo', 'v_files_tags', 'v_files_palavras_nome', 'v_files_pipeline_status', 'v_kb_cobertura', 'v_files_problemas']

HELPERS = ['mls_size_bytes', 'mls_ts']


def upgrade() -> None:
    op.execute(VIEWS_SQL)


def downgrade() -> None:
    for view in VIEWS:
        op.execute(f"DROP VIEW IF EXISTS mylibrary.{view}")
    op.execute("DROP FUNCTION IF EXISTS mylibrary.mls_ts(jsonb, text)")
    op.execute("DROP FUNCTION IF EXISTS mylibrary.mls_size_bytes(jsonb)")
