"""0004 — source kinds CLOUD/REMOTEFS + `stale` em source_files (ADR-0008).

ADR-0008: `REMOTE`→`CLOUD` (objetos via API, reservado) + novo `REMOTEFS`
(FS remoto montado). Sem backfill (nenhum dado usava `REMOTE`).
`stale` marca describe/infer desatualizados quando o conteúdo muda; o KB é
excluído (rebuild). Idempotente.

Revision ID: 0004
Revises: 0003
"""

from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

SCHEMA = "mylibrary"


def upgrade() -> None:
    op.execute(
        f"ALTER TABLE {SCHEMA}.sources DROP CONSTRAINT IF EXISTS sources_source_kind_check"
    )
    op.execute(
        f"ALTER TABLE {SCHEMA}.sources ADD CONSTRAINT sources_source_kind_check "
        "CHECK (source_kind IN ('LOCAL', 'REMOVABLE', 'CLOUD', 'REMOTEFS'))"
    )
    op.execute(
        f"ALTER TABLE {SCHEMA}.source_files "
        "ADD COLUMN IF NOT EXISTS stale boolean NOT NULL DEFAULT false"
    )
    op.execute("NOTIFY pgrst, 'reload schema'")


def downgrade() -> None:
    op.execute(f"ALTER TABLE {SCHEMA}.source_files DROP COLUMN IF EXISTS stale")
    op.execute(
        f"ALTER TABLE {SCHEMA}.sources DROP CONSTRAINT IF EXISTS sources_source_kind_check"
    )
    op.execute(
        f"ALTER TABLE {SCHEMA}.sources ADD CONSTRAINT sources_source_kind_check "
        "CHECK (source_kind IN ('LOCAL', 'REMOVABLE', 'REMOTE'))"
    )
    op.execute("NOTIFY pgrst, 'reload schema'")
