"""0002 — RPC de busca da KB (A8/F4): mylibrary.search_chunks.

Canonical: sql/functions_search_v1.sql (same SQL, self-contained here —
PS-8 migrations are the source of truth going forward).

Create Date: 2026-10-11
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

FUNCTION_SQL = r"""
CREATE OR REPLACE FUNCTION mylibrary.search_chunks(payload jsonb)
RETURNS jsonb
LANGUAGE plpgsql STABLE
SET search_path = mylibrary, public, pg_temp
AS $fn$
DECLARE
    v_mode      text    := lower(coalesce(payload->>'mode', 'hybrid'));
    v_query     text    := coalesce(payload->>'query', '');
    v_emb       jsonb   := payload->'query_embedding';
    v_vec_text  text;
    v_source    uuid    := nullif(payload->>'source_id', '')::uuid;
    v_limit     int     := coalesce((payload->>'limit')::int, 10);
    v_offset    int     := coalesce((payload->>'offset')::int, 0);
    v_min       float8  := coalesce((payload->>'min_similarity')::float8, 0.0);
    v_pattern   text    := coalesce(payload->>'file_pattern', '*');
    v_mime      text    := nullif(payload->>'mime', '');
    v_t0        timestamptz := clock_timestamp();
    v_scope_sources int := 0;
    v_scope_chunks  int := 0;
    v_without_kb    int := 0;
    v_results   jsonb   := '[]'::jsonb;
BEGIN
    IF v_mode NOT IN ('hybrid', 'content', 'keyword', 'topic') THEN
        RAISE EXCEPTION 'invalid search mode: %', v_mode;
    END IF;
    IF btrim(v_query) = '' THEN
        RAISE EXCEPTION 'query required for search mode %', v_mode;
    END IF;
    IF v_mode IN ('hybrid', 'content') THEN
        IF v_emb IS NULL THEN
            RAISE EXCEPTION 'query_embedding required for search mode %', v_mode;
        END IF;
        SELECT '[' || string_agg(e, ',') || ']'
          INTO v_vec_text
          FROM jsonb_array_elements_text(v_emb) AS t(e);
        IF v_vec_text IS NULL THEN
            RAISE EXCEPTION 'query_embedding must be a JSON array of floats';
        END IF;
    END IF;

    SELECT count(*) FILTER (WHERE chunks > 0),
           count(*) FILTER (WHERE chunks = 0),
           coalesce(sum(chunks), 0)::int
      INTO v_scope_sources, v_without_kb, v_scope_chunks
      FROM (
        SELECT s.id, count(k.id) AS chunks
          FROM mylibrary.sources s
          LEFT JOIN mylibrary.source_files f ON f.source_id = s.id
          LEFT JOIN mylibrary.kb_chunks k    ON k.source_file_id = f.id
         WHERE (v_source IS NULL OR s.id = v_source)
         GROUP BY s.id
      ) scope;

    IF v_mode = 'topic' THEN
        WITH matched AS (
            SELECT s.source_name, f.source_id, f.file_path, f.topics, f.details,
                   coalesce(f.inference, '') AS file_text
              FROM mylibrary.source_files f
              JOIN mylibrary.sources s ON s.id = f.source_id
             WHERE (v_source IS NULL OR f.source_id = v_source)
               AND f.file_path LIKE translate(v_pattern, '*', '%')
               AND (v_mime IS NULL
                    OR f.details->>'mime_type_code' ILIKE '%' || v_mime || '%'
                    OR f.details->>'mime_type_description' ILIKE '%' || v_mime || '%')
               AND EXISTS (
                   SELECT 1
                     FROM unnest(f.topics) AS t
                    WHERE t ILIKE '%' || v_query || '%'
                   )
        )
        SELECT coalesce(jsonb_agg(page), '[]'::jsonb)
          INTO v_results
          FROM (
            SELECT jsonb_build_object(
                       'source_name', m.source_name,
                       'file_path',   m.file_path,
                       'chunk_index', 0,
                       'score',       1.0,
                       'text',        m.file_text,
                       'topics',      m.topics,
                       'mime_type',   m.details->>'mime_type_code'
                   ) AS page
              FROM (SELECT * FROM matched ORDER BY file_path
                    LIMIT v_limit OFFSET v_offset) m
          ) paged;
        RETURN mylibrary.build_search_response(v_results, v_scope_sources,
                                               v_without_kb, v_scope_chunks, v_t0);
    END IF;

    WITH base AS (
        SELECT k.id, k.chunk_index, k.text, k.embedding, k.tsv,
               f.file_path, f.topics, f.details, s.source_name,
               f.details->>'mime_type_code' AS mime_type
          FROM mylibrary.kb_chunks k
          JOIN mylibrary.source_files f ON f.id = k.source_file_id
          JOIN mylibrary.sources s      ON s.id = f.source_id
         WHERE (v_source IS NULL OR f.source_id = v_source)
           AND f.file_path LIKE translate(v_pattern, '*', '%')
           AND (v_mime IS NULL
                OR f.details->>'mime_type_code' ILIKE '%' || v_mime || '%'
                OR f.details->>'mime_type_description' ILIKE '%' || v_mime || '%')
    ),
    keyword_ranked AS (
        SELECT b.id,
               row_number() OVER (
                   ORDER BY ts_rank(b.tsv,
                                    websearch_to_tsquery('portuguese', v_query)) DESC,
                        b.id
               ) AS r
          FROM base b
         WHERE b.tsv @@ websearch_to_tsquery('portuguese', v_query)
    ),
    keyword_scores AS (
        SELECT id, raw / NULLIF(max(raw) OVER (), 0.0) AS kw_score
          FROM (
            SELECT b.id,
                   ts_rank(b.tsv, websearch_to_tsquery('portuguese', v_query)) AS raw
              FROM base b
             WHERE b.tsv @@ websearch_to_tsquery('portuguese', v_query)
          ) raws
    ),
    content_scores AS (
        SELECT b.id, (1.0 - (b.embedding <=> v_vec_text::vector)) AS ct_score
          FROM base b
         WHERE b.embedding IS NOT NULL
    ),
    rrf AS (
        SELECT b.id,
               (CASE WHEN c.r IS NOT NULL THEN 1.0 / (60 + c.r::float8) ELSE 0.0 END)
             + (CASE WHEN w.r IS NOT NULL THEN 1.0 / (60 + w.r::float8) ELSE 0.0 END)
               AS raw_rrf
          FROM base b
          LEFT JOIN (
              SELECT id, row_number() OVER (
                         ORDER BY embedding <=> v_vec_text::vector) AS r
                FROM base WHERE embedding IS NOT NULL
          ) c ON c.id = b.id
          LEFT JOIN keyword_ranked w ON w.id = b.id
         WHERE (c.r IS NOT NULL OR w.r IS NOT NULL)
    ),
    rrf_scores AS (
        SELECT id,
               raw_rrf / max(raw_rrf) OVER () AS rrf_score
          FROM rrf
    ),
    scored AS (
        SELECT b.*,
               CASE v_mode
                   WHEN 'content' THEN ct.ct_score
                   WHEN 'keyword' THEN kw.kw_score
                   ELSE rs.rrf_score
               END AS score
          FROM base b
          LEFT JOIN content_scores ct ON ct.id = b.id
          LEFT JOIN keyword_scores kw ON kw.id = b.id
          LEFT JOIN rrf_scores rs     ON rs.id = b.id
         WHERE (v_mode = 'content'  AND ct.ct_score IS NOT NULL)
            OR (v_mode = 'keyword'  AND kw.kw_score IS NOT NULL)
            OR (v_mode = 'hybrid'   AND rs.rrf_score IS NOT NULL)
    ),
    filtered AS (
        SELECT * FROM scored WHERE score >= v_min
    ),
    ranked AS (
        SELECT *, row_number() OVER (
                   ORDER BY score DESC, text, id
               ) AS position
          FROM filtered
    ),
    paged AS (
        SELECT * FROM ranked WHERE position > v_offset LIMIT v_limit
    )
    SELECT coalesce(jsonb_agg(page), '[]'::jsonb)
      INTO v_results
      FROM (
        SELECT jsonb_build_object(
                   'source_name', p.source_name,
                   'file_path',   p.file_path,
                   'chunk_index', p.chunk_index,
                   'score',       round(p.score::numeric, 4),
                   'text',        p.text,
                   'topics',      p.topics,
                   'mime_type',   p.mime_type
               ) AS page
          FROM paged p
      ) pages;

    RETURN mylibrary.build_search_response(v_results, v_scope_sources,
                                           v_without_kb, v_scope_chunks, v_t0);
END $fn$;

CREATE OR REPLACE FUNCTION mylibrary.build_search_response(
    p_results jsonb,
    p_sources_searched int,
    p_without_kb int,
    p_kb_chunks int,
    p_started timestamptz
)
RETURNS jsonb
LANGUAGE plpgsql STABLE
SET search_path = mylibrary, public, pg_temp
AS $resp$
BEGIN
    RETURN jsonb_build_object(
        'results', p_results,
        'stats', jsonb_build_object(
            'results',
            (SELECT count(*) FROM jsonb_array_elements(p_results)),
            'sources_searched', p_sources_searched,
            'sources_without_kb', p_without_kb,
            'kb_chunks', p_kb_chunks,
            'elapsed_ms',
            (SELECT (extract(epoch FROM (clock_timestamp() - p_started)) * 1000)::int)
        )
    );
END $resp$;

ALTER FUNCTION mylibrary.search_chunks(jsonb) OWNER TO mylibrary;
ALTER FUNCTION mylibrary.build_search_response(jsonb, int, int, int, timestamptz)
    OWNER TO mylibrary;
"""


def upgrade() -> None:
    op.execute(FUNCTION_SQL)


def downgrade() -> None:
    op.execute("DROP FUNCTION IF EXISTS mylibrary.search_chunks(jsonb)")
    op.execute("DROP FUNCTION IF EXISTS mylibrary.build_search_response(jsonb, int, int, int, timestamptz)")