"""0005 — Views analíticas: delta `stale` (integra o avulso views_analise_delta_0004_stale).

Integra ao Alembic o delta da camada BI (ADR-0008): `v_files_resumo`/`v_sources_resumo`
ganham `arquivos_stale`/`bytes_stale` e surge a view acionável `v_files_stale`.
Depende da coluna `stale` em `source_files` criada na migration 0004.

Idempotente (DROP VIEW IF EXISTS + CREATE + DROP). Canonical legível:
`sql/views_analise_delta_0004_stale.sql` (mesmo SQL). Owners/grants reaplicados.

Revision ID: 0005
Revises: 0004
"""

from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

READERS = ("fbnet_anon", "fbnet_web_user", "metabase_ro", "fbnet_ro")
VIEWS = ("v_files_resumo", "v_sources_resumo", "v_files_stale")

DELTA_SQL = r"""
-- ---------------------------------------------------------------------------
-- 1.1 Panorama do acervo (1 linha) — +stale (ADR-0008)
-- ---------------------------------------------------------------------------
DROP VIEW IF EXISTS mylibrary.v_files_resumo;
CREATE VIEW mylibrary.v_files_resumo AS
SELECT
    (SELECT count(*) FROM mylibrary.sources)                                  AS sources,
    (SELECT count(*) FROM mylibrary.sources WHERE status = 'OK')             AS sources_ok,
    count(*)                                                                 AS arquivos_total,
    count(*) FILTER (WHERE status = 'OK')                                    AS arquivos_ok,
    count(*) FILTER (WHERE status = 'ERROR')                                 AS arquivos_error,
    count(*) FILTER (WHERE status = 'SKIPPED')                               AS arquivos_skipped,
    coalesce(sum(mylibrary.mls_size_bytes(details)), 0)                      AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(details)), 0) / 1048576.0, 1) AS mb_total,
    max(mylibrary.mls_size_bytes(details))                                   AS bytes_maior_arquivo,
    round(avg(mylibrary.mls_size_bytes(details)))                            AS bytes_medio,
    percentile_cont(0.5) WITHIN GROUP (ORDER BY mylibrary.mls_size_bytes(details)) AS bytes_mediana,
    count(*) FILTER (WHERE mylibrary.mls_size_bytes(details) = 0)           AS arquivos_vazios,
    count(*) FILTER (WHERE details ? 'content_family')                       AS arquivos_com_familia,
    count(*) FILTER (WHERE md5sum IS NOT NULL AND md5sum <> '')              AS arquivos_com_md5,
    count(*) FILTER (WHERE array_length(topics, 1) > 0)                      AS arquivos_com_tags,
    count(*) FILTER (WHERE inference IS NOT NULL AND btrim(inference) <> '') AS arquivos_com_inferencia,
    (SELECT count(*) FROM mylibrary.kb_chunks)                               AS kb_chunks,
    min(mylibrary.mls_ts(details, 'modification_date'))::date                AS arquivo_mais_antigo,
    max(mylibrary.mls_ts(details, 'modification_date'))::date                AS arquivo_mais_recente,
    min(processed_at)::date                                                  AS primeiro_scan,
    max(processed_at)::date                                                  AS ultimo_scan,
    count(*) FILTER (WHERE stale)                                            AS arquivos_stale,
    coalesce(sum(mylibrary.mls_size_bytes(details)) FILTER (WHERE stale), 0) AS bytes_stale
FROM mylibrary.source_files;

COMMENT ON VIEW mylibrary.v_files_resumo IS
'Panorama do acervo: UMA linha com os KPIs gerais — sources, arquivos (por status), espaço total (bytes/MB), maior arquivo, média/mediana, vazios, cobertura (md5/família/tags/inferência/chunks), janela de datas e carga stale do ADR-0008. Grão: linha única (agregado global).';

-- ---------------------------------------------------------------------------
-- 1.2 Acervo por source (uma linha por library) — +stale (ADR-0008)
-- ---------------------------------------------------------------------------
DROP VIEW IF EXISTS mylibrary.v_sources_resumo;
CREATE VIEW mylibrary.v_sources_resumo AS
SELECT
    s.source_name,
    s.source_kind,
    s.source_path,
    s.status                                                          AS scan_status,
    s.start_extraction::date                                          AS scan_inicio,
    s.end_extraction::date                                            AS scan_fim,
    s.files_total,
    count(f.id)                                                       AS arquivos,
    count(f.id) FILTER (WHERE f.status = 'OK')                        AS arquivos_ok,
    count(f.id) FILTER (WHERE f.status <> 'OK')                       AS arquivos_problema,
    coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0)             AS bytes_total,
    round(coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0) / 1048576.0, 1) AS mb_total,
    round(100.0 * coalesce(sum(mylibrary.mls_size_bytes(f.details)), 0)
          / NULLIF((SELECT sum(mylibrary.mls_size_bytes(details)) FROM mylibrary.source_files), 0), 1) AS pct_bytes,
    round(100.0 * count(f.id)
          / NULLIF((SELECT count(*) FROM mylibrary.source_files), 0), 1) AS pct_arquivos,
    max(mylibrary.mls_size_bytes(f.details))                          AS bytes_maior_arquivo,
    count(f.id) FILTER (WHERE f.details ? 'content_family')           AS arquivos_com_familia,
    count(f.id) FILTER (WHERE array_length(f.topics, 1) > 0)          AS arquivos_com_tags,
    count(f.id) FILTER (WHERE f.stale)                                AS arquivos_stale,
    coalesce(sum(mylibrary.mls_size_bytes(f.details)) FILTER (WHERE f.stale), 0) AS bytes_stale
FROM mylibrary.sources s
LEFT JOIN mylibrary.source_files f ON f.source_id = s.id
GROUP BY s.id, s.source_name, s.source_kind, s.source_path, s.status,
         s.start_extraction, s.end_extraction, s.files_total;

COMMENT ON VIEW mylibrary.v_sources_resumo IS
'Acervo de cada source (library): arquivos, problemas, espaço (bytes/MB) e participação (% do acervo em arquivos e em bytes) + cobertura de família/tags + carga stale (ADR-0008). Grão: uma linha por source. Responde: "como está o acervo de cada library, quanto cada uma pesa e o quanto dela está desatualizado?".';

-- ---------------------------------------------------------------------------
-- 6.2 NOVA — Arquivos STALE (describe/inferência desatualizados)
-- ---------------------------------------------------------------------------
DROP VIEW IF EXISTS mylibrary.v_files_stale;
CREATE VIEW mylibrary.v_files_stale AS
SELECT
    s.source_name,
    s.source_kind,
    f.file_path,
    f.status,
    round(coalesce(mylibrary.mls_size_bytes(f.details), 0) / 1048576.0, 2)  AS mb,
    mylibrary.mls_ts(f.details, 'modification_date')::date                   AS modificado_em,
    f.processed_at::date                                                     AS ultimo_scan
FROM mylibrary.source_files f
JOIN mylibrary.sources s ON s.id = f.source_id
WHERE f.stale;

COMMENT ON VIEW mylibrary.v_files_stale IS
'Carga de trabalho pendente (ADR-0008): UMA linha por arquivo marcado stale — describe/inferência desatualizados porque o conteúdo mudou desde o último processamento. Grão: 1 linha = arquivo stale. O que reprocessar: re-scan + inferência + embedding (KB desses arquivos foi excluída).';
"""


def upgrade() -> None:
    op.execute(DELTA_SQL)
    for view in VIEWS:
        op.execute(f"ALTER VIEW mylibrary.{view} OWNER TO mylibrary")
        for role in READERS:
            op.execute(f"GRANT SELECT ON mylibrary.{view} TO {role}")
    op.execute("NOTIFY pgrst, 'reload schema'")


def downgrade() -> None:
    # `v_files_stale` é net-new; as colunas stale das resumo persistem (aditivas).
    op.execute("DROP VIEW IF EXISTS mylibrary.v_files_stale")
    op.execute("NOTIFY pgrst, 'reload schema'")
