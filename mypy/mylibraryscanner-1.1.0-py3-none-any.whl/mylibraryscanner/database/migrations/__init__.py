"""Alembic migrations for the MyLibraryScanner ``mylibrary`` schema.

Canonical evolution path since v1 (PS-8). The initial baseline (0001)
mirrors the reference bootstrap ``sql/ddl_mylibrary_v1.sql`` (v1.0.1 rev a):
4 tables, indexes, tsv trigger, RBAC/RLS/policies.

On a database already bootstrapped by the DDL, stamp instead of migrating:

    alembic -c alembic.ini stamp head
"""