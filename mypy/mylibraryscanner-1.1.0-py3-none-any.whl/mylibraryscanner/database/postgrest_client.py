"""Minimal PostgREST HTTP client for MyLibraryScanner (ADR-0005).

Only this abstraction reaches the ``mylibrary`` schema through PostgREST;
direct PostgreSQL access is forbidden by ADR-0005. The client speaks the
PostgREST table API with ``Accept-Profile``/``Content-Profile`` headers and a
static JWT (AUTH-3, role ``fbnet_web_user``) resolved from the environment.

Secret policy: the JWT is signed from ``FBNET_PGREST_JWT_SECRET`` (or taken
verbatim from ``FBNET_PGREST_JWT_TOKEN``). Neither value is ever versioned.
"""

from __future__ import annotations

import os
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

import httpx
import jwt as pyjwt

from mylibraryscanner.initialization import get_app_config

SCHEMA_NAME = "mylibrary"
WEB_USER_ROLE = "fbnet_web_user"


class PostgRESTError(Exception):
    """Base exception for PostgREST business failures."""


class PostgRESTUnavailableError(PostgRESTError):
    """PostgREST service or the database behind it is unreachable (PS-7)."""


class PostgRESTNotFoundError(PostgRESTError):
    """Requested resource does not exist."""


class PostgRESTConflictError(PostgRESTError):
    """Insert/update violated a uniqueness constraint (HTTP 409)."""


class PostgRESTAuthError(PostgRESTError):
    """Authentication failed (HTTP 401/403)."""


def _default_base_url() -> str:
    """Resolve base URL: explicit env override first, then app.json."""
    env_url = os.getenv("FBNET_MYLIBRARYSCANNER_POSTGREST_URL", "").strip()
    if env_url:
        return env_url.rstrip("/")
    try:
        url = get_app_config().get("config", {}).get("postgrest_url", "") or ""
    except RuntimeError:
        # App config not initialized in this context — env wins only.
        url = ""
    return str(url).rstrip("/")


def build_static_jwt(secret: str, role: str = WEB_USER_ROLE) -> str:
    """Sign the static JWT used by library clients (AUTH-3).

    Static tokens carry only the role claim and the issue time; expiration is
    controlled by rotating the secret, not by expiry checking (AUTH-1/c).
    """
    now = int(datetime.now(UTC).timestamp())
    return pyjwt.encode({"role": role, "iat": now}, secret, algorithm="HS256")


def _resolve_token() -> str:
    """Resolve the bearer token: pre-generated token env first, else sign."""
    token = os.getenv("FBNET_PGREST_JWT_TOKEN", "").strip()
    if token:
        return token
    secret = os.getenv("FBNET_PGREST_JWT_SECRET", "").strip()
    if not secret:
        raise PostgRESTUnavailableError(
            "JWT secret not configured: set FBNET_PGREST_JWT_SECRET "
            "(or FBNET_PGREST_JWT_TOKEN) in the environment."
        )
    return build_static_jwt(secret)


class PostgRESTClient:
    """HTTP client for the PostgREST Table API scoped to schema ``mylibrary``."""

    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        base = (base_url or _default_base_url()).rstrip("/")
        if not base:
            raise PostgRESTUnavailableError(
                "PostgREST URL not configured: set postgrest_url in app.json "
                "or FBNET_MYLIBRARYSCANNER_POSTGREST_URL."
            )
        self.base_url = base
        self._token = token or _resolve_token()
        # Note: JWT is never logged — only status codes/messages are logged.
        self._http = httpx.Client(
            base_url=base,
            timeout=timeout,
            transport=transport,
            headers={"Authorization": f"Bearer {self._token}"},
        )

    def close(self) -> None:
        self._http.close()

    def health_check(self) -> bool:
        """Return True when PostgREST answers (dependency check, PS-7).

        Probes ``/ready`` first; older instances (or hardened ones) that route
        health endpoints off the API are answered by the OpenAPI root at ``/``.
        """
        for path in ("/ready", "/"):
            try:
                if self._http.get(path).status_code == 200:
                    return True
            except (httpx.TransportError, httpx.HTTPStatusError):
                return False
        return False

    def ensure_available(self) -> None:
        """Raise a friendly ABORTED-style error when the service is down."""
        if not self.health_check():
            raise PostgRESTUnavailableError(
                "PostgREST is unreachable — verify the service and connection "
                "settings before retrying (dependency check failed)."
            )

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Any:
        headers: dict[str, str] = {
            "Accept": "application/json",
            "Accept-Profile": SCHEMA_NAME,
            "Content-Profile": SCHEMA_NAME,
        }
        if extra_headers:
            headers.update(extra_headers)
        try:
            response = self._http.request(
                method, path, json=json_body, params=params, headers=headers
            )
        except httpx.TransportError as exc:
            raise PostgRESTUnavailableError(
                f"PostgREST is unreachable ({exc.__class__.__name__}) — "
                "dependency check against the persistence service failed."
            ) from exc

        if response.is_success:
            return response.json() if response.content else None

        self._raise_for_status(response)
        return None

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        detail = ""
        try:
            body = response.json()
            detail = str(body.get("message") or body) if isinstance(body, dict) else str(body)
        except ValueError:
            detail = response.text[:200]
        if response.status_code in (401, 403):
            raise PostgRESTAuthError(f"authentication failed: {detail}")
        if response.status_code == 404:
            raise PostgRESTNotFoundError(f"resource not found: {detail}")
        if response.status_code == 409:
            raise PostgRESTConflictError(f"conflicting record: {detail}")
        raise PostgRESTError(
            f"PostgREST returned HTTP {response.status_code}: {detail}"
        )

    # -- Table API helpers -------------------------------------------------

    def get(
        self,
        table: str,
        *,
        select: str | None = None,
        params: dict[str, Any] | None = None,
        order: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        query: dict[str, Any] = dict(params or {})
        if select:
            query["select"] = select
        if order:
            query["order"] = order
        if limit is not None:
            query["limit"] = limit
        result = self._request("GET", f"/{table}", params=query)
        return result if isinstance(result, list) else [result]

    def get_one(
        self,
        table: str,
        *,
        select: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        query = dict(params or {})
        if select:
            query["select"] = select
        result = self._request("GET", f"/{table}", params={"limit": 1, **query})
        items = result if isinstance(result, list) else [result] if result else []
        return items[0] if items else None

    def insert(
        self,
        table: str,
        rows: Iterable[dict[str, Any]],
        *,
        upsert: bool = False,
        on_conflict: str | None = None,
        select: str | None = None,
    ) -> list[dict[str, Any]]:
        body = list(rows)
        prefer = "return=representation"
        if upsert:
            # ponytail: merge-duplicates upsert; on_conflict names the UNIQUE
            # constraint columns (required by PostgREST for non-PK targets).
            prefer += ",resolution=merge-duplicates"
        params = {}
        if on_conflict:
            params["on_conflict"] = on_conflict
        if select:
            params["select"] = select
        result = self._request(
            "POST",
            f"/{table}",
            json_body=body,
            params=params or None,
            extra_headers={"Prefer": prefer},
        )
        return result if isinstance(result, list) else [result] if result else []

    def update(
        self,
        table: str,
        values: dict[str, Any],
        *,
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        result = self._request(
            "PATCH",
            f"/{table}",
            json_body=values,
            params=_encode_filters(params),
            extra_headers={"Prefer": "return=representation"},
        )
        return result if isinstance(result, list) else [result] if result else []

    def delete(self, table: str, *, params: dict[str, Any]) -> int:
        result = self._request(
            "DELETE",
            f"/{table}",
            params=_encode_filters(params),
            extra_headers={"Prefer": "return=representation"},
        )
        return len(result) if result else 0

    def rpc(self, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Call a PostgREST RPC with a SINGLE jsonb object parameter.

        PostgREST v11+ spreads JSON body keys into named parameters, so the
        library convention is one ``payload jsonb`` argument per RPC: the
        body arrives wrapped as ``{"payload": {...}}``.
        """
        result = self._request("POST", f"/rpc/{name}", json_body={"payload": payload})
        return result if isinstance(result, dict) else {}

    def count(self, table: str, *, params: dict[str, Any] | None = None) -> int:
        query = _encode_filters(params or {})
        query["select"] = "count"
        response = self._http.request(
            "GET",
            f"/{table}",
            params=query,
            headers={
                "Accept-Profile": SCHEMA_NAME,
                "Accept": "text/csv",
            },
        )
        if not response.is_success:
            self._raise_for_status(response)
        lines = [line for line in response.text.strip().splitlines() if line.strip()]
        return int(lines[-1]) if lines else 0  # last CSV line; header absorbed


def _encode_filters(params: dict[str, Any]) -> dict[str, Any]:
    """Encode equality filters into PostgREST query syntax (eq.<value>)."""
    encoded: dict[str, Any] = {}
    for key, value in params.items():
        if isinstance(value, str):
            encoded[key] = f"eq.{quote(value)}"
        else:
            encoded[key] = f"eq.{value}"
    return encoded


__all__ = [
    "SCHEMA_NAME",
    "WEB_USER_ROLE",
    "PostgRESTAuthError",
    "PostgRESTClient",
    "PostgRESTConflictError",
    "PostgRESTError",
    "PostgRESTNotFoundError",
    "PostgRESTUnavailableError",
    "build_static_jwt",
]