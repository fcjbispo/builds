import logging

from dotenv import load_dotenv


_ = load_dotenv()

# Library logger: silent by default until the client application configures logging.
# We follow the FBPyUtils v1.10.0 client-ownership pattern: libraries must NOT
# call fbpyutils.setup() on import. Each module uses stdlib logging.getLogger(__name__)
# with a NullHandler so that importing the package never emits logs or reconfigures
# the singleton logger of the parent application.
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())
