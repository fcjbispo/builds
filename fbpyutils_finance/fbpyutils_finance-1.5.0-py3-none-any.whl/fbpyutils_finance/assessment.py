"""
fbpyutils_finance.assessment - Investment Portfolio Assessment and Rebalancing Utilities

This module provides comprehensive tools for investment portfolio assessment, profit/loss calculation,
and optimal allocation strategies for portfolio rebalancing. The module implements inverse weighting
strategies that favor underperforming assets, helping investors maintain balanced portfolios through
systematic allocation of new investments.

Main Contents
--------------
get_investment_table(df, investment_amount)
    Main function for calculating investment allocation proportions based on adjusted profit/loss.
    Uses inverse weighting strategy to favor underperforming assets for portfolio rebalancing.

forward_fill_averages(df, source_column, output_column)
    Forward-fills missing values in a numeric column using cumulative averages.
    Preserves existing values while filling gaps with running averages for smooth data progression.

Internal Functions
------------------
adjust_profit_loss(row)
    Helper function that normalizes profit/loss values by applying magnitude scaling and row index
    weighting to prevent large values from dominating allocation weights.

Dependencies
------------
- pandas: For DataFrame input/output and compatibility
- polars: High-performance DataFrame engine for internal calculations
- numpy: For mathematical calculations and array operations
- fbpyutils_finance.logger: Centralized logging functionality

High-Level Usage Pattern
-------------------------
The primary workflow involves loading portfolio data into a pandas DataFrame with required columns,
then calling get_investment_table() to generate rebalancing recommendations. The function returns
allocation suggestions that favor underperforming assets to maintain portfolio balance.

Required DataFrame Columns
~~~~~~~~~~~~~~~~~~~~~~~~~~
- 'Ticker' (str): Asset identifier symbol
- 'Price' (float): Current market price per unit
- 'Quantity' (float): Current quantity held of the asset
- 'Average Price' (float): Average purchase price per unit

Return DataFrame Columns
~~~~~~~~~~~~~~~~~~~~~~~
- Original columns plus calculated fields:
  - 'Profit/Loss': Total absolute profit or loss for the asset
  - 'Proportion': Normalized investment weight (0-1)
  - 'Investment Value': Allocated investment amount
  - 'Quantity to Buy': Recommended number of units to purchase

Examples
--------
Basic portfolio rebalancing:

>>> import pandas as pd
>>> from fbpyutils_finance.assessment import get_investment_table
>>>
>>> # Sample portfolio data
>>> data = {
...     'Ticker': ['PETR4', 'VALE3', 'ITUB4'],
...     'Price': [30.0, 60.0, 25.0],
...     'Quantity': [100.0, 50.0, 200.0],
...     'Average Price': [25.0, 70.0, 20.0]
... }
>>> df = pd.DataFrame(data)
>>>
>>> # Calculate allocation for R$10,000 investment
>>> result = get_investment_table(df, 10000.0)
>>> print(result[['Ticker', 'Profit/Loss', 'Proportion', 'Investment Value', 'Quantity to Buy']])
   Ticker  Profit/Loss  Proportion  Investment Value  Quantity to Buy
0  PETR4        500.0    0.428571         4285.714         142.857
1  VALE3       -500.0    0.571429         5714.286          95.238
2  ITUB4       1000.0    0.000000            0.000           0.000

Handle assets with zero or missing data:

>>> # Data with some zero prices
>>> data_with_zeros = {
...     'Ticker': ['AAPL', 'GOOGL'],
...     'Price': [150.0, 0.0],  # GOOGL has zero price
...     'Quantity': [10.0, 5.0],
...     'Average Price': [140.0, 2800.0]
... }
>>> df_zeros = pd.DataFrame(data_with_zeros)
>>> result_zeros = get_investment_table(df_zeros, 5000.0)
>>> print(result_zeros[['Ticker', 'Price', 'Investment Value', 'Quantity to Buy']])
  Ticker  Price  Investment Value  Quantity to Buy
0   AAPL  150.0           5000.0          33.333
1  GOOGL    0.0              0.0           0.000

Notes
-----
- The allocation algorithm uses inverse weighting based on adjusted profit/loss values
- Assets with higher losses receive larger allocation percentages to facilitate rebalancing
- Zero-price assets are handled gracefully with zero allocation and zero quantity recommendations
- The function sorts assets by profit/loss in descending order before calculating proportions
- All calculations assume positive quantities and valid price data
- NaN values in essential columns result in row exclusion with warning logging

Mathematical Foundation
~~~~~~~~~~~~~~~~~~~~~~
The allocation algorithm implements the following steps:
1. Calculate raw profit/loss: (Current Price - Average Price) × Quantity
2. Apply magnitude scaling using log10 normalization to prevent value dominance
3. Add row index weighting to ensure all assets receive some allocation
4. Calculate inverse proportions: assets with lower adjusted values receive higher weights
5. Distribute total investment amount according to calculated proportions
6. Convert allocated values to recommended purchase quantities

See Also
--------
fbpyutils_finance.calculators: Financial rate calculations and stock return analysis
fbpyutils_finance.utils: General utility functions for data manipulation

References
----------
.. [1] Modern Portfolio Theory and Investment Analysis
   https://www.investopedia.com/terms/m/modernportfoliotheory.asp
.. [2] Portfolio Rebalancing Strategies
   https://www.investopedia.com/articles/personal-finance/040713/how-rebalance-your-portfolio.asp
.. [3] Asset Allocation Models for Portfolio Management
   https://www.cfainstitute.org/en/programs/cfa/chartered-financial-analyst-program
"""

import pandas as pd
import polars as pl
import numpy as np

from fbpyutils_finance import logger


def get_investment_table(df: pd.DataFrame, investment_amount: float) -> pd.DataFrame:
    """Calculate investment allocation metrics based on profit/loss weighting.

    This function analyzes a portfolio DataFrame and calculates optimal allocation
    proportions for distributing new investment capital. The allocation strategy
    implements inverse weighting based on adjusted profit/loss, where assets with
    lower performance (higher losses) receive proportionally larger allocations
    to facilitate portfolio rebalancing.

    The algorithm uses a sophisticated weighting mechanism that:
    1. Calculates raw profit/loss for each asset
    2. Applies magnitude scaling to prevent large values from dominating weights
    3. Adds row index weighting to ensure all assets receive some allocation
    4. Computes inverse proportions favoring underperforming assets
    5. Distributes the total investment amount according to calculated weights

    Parameters
    ----------
    df : pd.DataFrame
        Portfolio DataFrame containing asset information. Must include these columns:

        * 'Ticker' (str): Asset identifier symbol (e.g., 'PETR4', 'AAPL')
        * 'Price' (float): Current market price per unit of the asset
        * 'Quantity' (float): Current quantity held of the asset
        * 'Average Price' (float): Average purchase price per unit

    investment_amount : float
        Total amount of new capital to allocate across the portfolio.
        Must be a positive value representing the investment budget.

    Returns
    -------
    pd.DataFrame
        Enhanced DataFrame with original columns plus calculated allocation metrics:

        * Original columns: 'Ticker', 'Price', 'Quantity', 'Average Price'
        * 'Profit/Loss' (float): Total profit or loss for the asset
        * 'Adjusted Profit/Loss' (float): Magnitude-scaled profit/loss for weighting
        * 'Proportion' (float): Normalized investment weight (0.0 to 1.0)
        * 'Investment Value' (float): Allocated investment amount for this asset
        * 'Quantity to Buy' (float): Recommended number of units to purchase

    Raises
    ------
    ValueError
        If the input DataFrame is missing any of the required columns:
        'Ticker', 'Price', 'Quantity', 'Average Price'.
        Also raised if investment_amount is negative or zero.

    Warns
    -----
    UserWarning
        If rows are dropped due to NaN values in essential columns after
        numeric coercion. The warning includes the count of dropped rows.

    See Also
    --------
    adjust_profit_loss : Internal helper function for profit/loss normalization
    fbpyutils_finance.calculators.rate_annual_to_monthly : Rate conversion utilities
    fbpyutils_finance.utils.numberize : String to numeric conversion

    Notes
    -----
    The allocation strategy favors underperforming assets through inverse weighting:

    * Assets with higher losses receive larger allocation percentages
    * Magnitude scaling prevents extreme values from dominating weights
    * Row index weighting ensures all assets receive some allocation
    * Zero-price assets are handled gracefully with zero allocation

    Data preprocessing includes:

    * Automatic numeric conversion of price/quantity columns
    * NaN value handling with row exclusion and warning logging
    * Sorting by profit/loss in descending order before weight calculation
    * Zero-division protection for assets with zero current price

    Examples
    --------
    Basic portfolio rebalancing scenario:

    >>> import pandas as pd
    >>> from fbpyutils_finance.assessment import get_investment_table
    >>>
    >>> # Create sample portfolio with mixed performance
    >>> data = {
    ...     'Ticker': ['PETR4', 'VALE3', 'ITUB4'],
    ...     'Price': [30.0, 60.0, 25.0],
    ...     'Quantity': [100.0, 50.0, 200.0],
    ...     'Average Price': [25.0, 70.0, 20.0]
    ... }
    >>> df = pd.DataFrame(data)
    >>>
    >>> # Calculate allocation for R$10,000 new investment
    >>> result = get_investment_table(df, 10000.0)
    >>> print(result[['Ticker', 'Profit/Loss', 'Proportion', 'Investment Value', 'Quantity to Buy']])
       Ticker  Profit/Loss  Proportion  Investment Value  Quantity to Buy
    0  PETR4        500.0    0.428571         4285.714         142.857
    1  VALE3       -500.0    0.571429         5714.286          95.238
    2  ITUB4       1000.0    0.000000            0.000           0.000

    Handle portfolio with problematic data:

    >>> # Portfolio with zero price and missing data
    >>> problematic_data = {
    ...     'Ticker': ['AAPL', 'GOOGL', 'TSLA'],
    ...     'Price': [150.0, 0.0, np.nan],  # GOOGL zero, TSLA missing
    ...     'Quantity': [10.0, 5.0, 15.0],
    ...     'Average Price': [140.0, 2800.0, 200.0]
    ... }
    >>> df_prob = pd.DataFrame(problematic_data)
    >>> result_prob = get_investment_table(df_prob, 5000.0)
    >>> print(result_prob[['Ticker', 'Price', 'Investment Value', 'Quantity to Buy']])
      Ticker  Price  Investment Value  Quantity to Buy
    0   AAPL  150.0           5000.0          33.333
    1  GOOGL    0.0              0.0           0.000

    References
    ----------
    .. [1] Modern Portfolio Theory - Asset Allocation and Diversification
       https://www.investopedia.com/terms/m/modernportfoliotheory.asp
    .. [2] Portfolio Rebalancing Strategies and Techniques
       https://www.investopedia.com/articles/personal-finance/040713/how-rebalance-your-portfolio.asp
    .. [3] CFA Institute - Asset Allocation Models for Portfolio Management
       https://www.cfainstitute.org/en/programs/cfa/chartered-financial-analyst-program
    """
    logger.info(
        f"get_investment_table entry: df_shape={df.shape}, investment_amount={investment_amount}"
    )

    # Define required columns
    required_columns = {"Ticker", "Price", "Quantity", "Average Price"}

    # Check for missing columns
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        logger.error(
            f"Missing required columns: {', '.join(missing_columns)}", exc_info=True
        )
        raise ValueError(f"Missing required columns: {', '.join(missing_columns)}")

    # Convert pandas DataFrame to polars for internal operations
    pl_df = pl.from_pandas(df)

    # Convert numeric columns to proper types (polars equivalent of pd.to_numeric)
    numeric_columns = ["Price", "Quantity", "Average Price"]
    for col in numeric_columns:
        pl_df = pl_df.with_columns(pl.col(col).cast(pl.Float64).alias(col))

    # Drop rows with null values in essential columns
    initial_rows = len(pl_df)
    pl_df = pl_df.drop_nulls(subset=numeric_columns)
    dropped_rows = initial_rows - len(pl_df)
    if dropped_rows > 0:
        logger.warning(
            f"Dropped {dropped_rows} rows due to NaN values in essential columns. Remaining: {len(pl_df)}"
        )

    if pl_df.is_empty():
        logger.warning(
            "No valid data after cleaning; returning empty DataFrame with expected columns"
        )
        # Return empty pandas DataFrame with expected columns
        final_columns = list(df.columns) + [
            "Profit/Loss",
            "Investment Value",
            "Quantity to Buy",
        ]
        original_cols = ["Ticker", "Price", "Quantity", "Average Price"]
        all_expected_cols = list(dict.fromkeys(original_cols + final_columns))
        return pd.DataFrame(columns=all_expected_cols)

    # Calculate Profit/Loss
    pl_df = pl_df.with_columns(
        ((pl.col("Price") - pl.col("Average Price")) * pl.col("Quantity")).alias(
            "Profit/Loss"
        )
    )

    # Sort dataframe by Profit/Loss in descending order and reset index
    pl_df = pl_df.sort("Profit/Loss", descending=True).with_row_index()

    # Calculate Adjusted Profit/Loss using polars apply
    def adjust_profit_loss_polars(idx, profit_loss):
        """Polars-compatible version of adjust_profit_loss function."""
        if profit_loss is None:
            return None
        abs_pl = abs(profit_loss)

        if abs_pl == 0:
            digits = 0
        elif 0 < abs_pl < 1:
            digits = 0
        else:
            try:
                digits = np.floor(np.log10(abs_pl)) + 1
            except ValueError as e:
                logger.error(
                    f"Error calculating digits for abs_pl={abs_pl}: {e}", exc_info=True
                )
                return None
        digits = int(digits)

        divisor = 10.0**digits
        result = (idx + 1) + (abs_pl / divisor)
        return result

    pl_df = pl_df.with_columns(
        [
            pl.struct(["index", "Profit/Loss"])
            .map_elements(
                lambda x: adjust_profit_loss_polars(x["index"], x["Profit/Loss"]),
                return_dtype=pl.Float64,
            )
            .alias("Adjusted Profit/Loss")
        ]
    )

    # Calculate total profit/loss for proportion calculation
    total_profit_loss = pl_df.select("Adjusted Profit/Loss").sum().item()

    # Calculate Proportion
    pl_df = pl_df.with_columns(
        (pl.col("Adjusted Profit/Loss") / total_profit_loss).alias("Proportion")
    )

    # Calculate Investment Value
    pl_df = pl_df.with_columns(
        (pl.col("Proportion") * investment_amount).alias("Investment Value")
    )
    logger.info(
        f"Investment allocation completed. Total allocated: {pl_df.select('Investment Value').sum().item():.2f}"
    )

    # Calculate Quantity to Buy (handle potential division by zero if Price is 0)
    zero_prices_count = pl_df.filter(pl.col("Price") == 0).shape[0]
    if zero_prices_count > 0:
        logger.warning(
            f"Found {zero_prices_count} assets with zero price; Quantity to Buy set to 0"
        )

    pl_df = pl_df.with_columns(
        pl.when(pl.col("Price") == 0)
        .then(0.0)
        .otherwise(pl.col("Investment Value") / pl.col("Price"))
        .alias("Quantity to Buy")
    )

    logger.info(
        f"get_investment_table exit: returning DataFrame with {len(pl_df)} rows, total investment {investment_amount}"
    )

    # Select final columns and convert back to pandas
    final_columns = [
        "Ticker",
        "Price",
        "Quantity",
        "Average Price",
        "Profit/Loss",
        "Investment Value",
        "Quantity to Buy",
    ]

    result_df = pl_df.select(final_columns).to_pandas()
    return result_df


def forward_fill_averages(
    df: pd.DataFrame, source_column: str, output_column: str
) -> pd.DataFrame:
    """Forward-fill missing values using cumulative averages.

    This function creates a new column by forward-filling missing values in the source column
    using cumulative averages calculated from the first row to the previous row. The algorithm
    ensures that missing values are filled with the running average of previously calculated
    values, providing smooth transitions and preventing data gaps.

    The filling strategy implements:
    1. Preserve existing non-null values from the source column
    2. For missing values, calculate the average of all previously calculated values
    3. Use the first row's value as the initial reference if available
    4. Maintain cumulative averaging throughout the dataset

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing the data to process. Must not be empty.

    source_column : str
        Name of the column containing values to forward-fill. Must exist in the DataFrame
        and contain numeric data (int, float, or numeric strings).

    output_column : str
        Name for the new column to be created. Must not already exist in the DataFrame.

    Returns
    -------
    pd.DataFrame
        Enhanced DataFrame with the original data plus the new output_column containing
        forward-filled values using cumulative averages.

    Raises
    ------
    ValueError
        If source_column doesn't exist in the DataFrame.
        If source_column is not numeric (int, float, or convertible to numeric).
        If output_column already exists in the DataFrame.
        If the DataFrame is empty.
        If no valid numeric values are found in source_column.

    Warns
    -----
    UserWarning
        If source_column contains non-numeric values that cannot be converted.
        If all values in source_column are NaN/null.

    See Also
    --------
    get_investment_table : Portfolio allocation calculations with polars backend
    fbpyutils_finance.utils.numberize : String to numeric conversion utility

    Notes
    -----
    The forward-fill algorithm ensures smooth value progression:

    * Non-null source values are preserved unchanged
    * Missing values are filled with cumulative averages
    * First row uses source value if available, otherwise raises error
    * Subsequent rows use running averages of all previous calculated values
    * Maintains data integrity while filling gaps in time series data

    Examples
    --------
    Basic forward-fill with averages:

    >>> import pandas as pd
    >>> from fbpyutils_finance.assessment import forward_fill_averages
    >>>
    >>> # Sample data with missing values
    >>> data = {
    ...     'Price': [100.0, None, None, 105.0, None, None],
    ...     'Volume': [1000, 1500, 1200, 1100, 1300, 1400]
    ... }
    >>> df = pd.DataFrame(data)
    >>>
    >>> # Forward-fill Price column into new Filled_Price column
    >>> result = forward_fill_averages(df, 'Price', 'Filled_Price')
    >>> print(result[['Price', 'Filled_Price']])
       Price  Filled_Price
    0   100.0         100.0
    1    NaN         100.0
    2    NaN         100.0
    3   105.0         105.0
    4    NaN         102.5
    5    NaN         102.5

    Handle numeric string conversion:

    >>> # Data with numeric strings
    >>> data_strings = {
    ...     'Rate': ['2.5', '3.0', None, '3.5', None],
    ...     'Period': [1, 2, 3, 4, 5]
    ... }
    >>> df_str = pd.DataFrame(data_strings)
    >>> result_str = forward_fill_averages(df_str, 'Rate', 'Filled_Rate')
    >>> print(result_str[['Rate', 'Filled_Rate']])
       Rate Filled_Rate
    0   2.5         2.5
    1   3.0         3.0
    2   None         2.75
    3   3.5         3.5
    4   None         3.0

    References
    ----------
    .. [1] Forward Filling and Time Series Data Imputation
       https://en.wikipedia.org/wiki/Imputation_(statistics)
    .. [2] Cumulative Average Calculation Methods
       https://www.investopedia.com/terms/m/movingaverage.asp
    """
    logger.info(
        f"forward_fill_averages entry: df_shape={df.shape}, source_column='{source_column}', output_column='{output_column}'"
    )

    # Input validation
    if df.empty:
        logger.error("Input DataFrame is empty", exc_info=True)
        raise ValueError("Input DataFrame cannot be empty")

    # Check if source column exists
    if source_column not in df.columns:
        logger.error(
            f"Source column '{source_column}' does not exist in DataFrame",
            exc_info=True,
        )
        raise ValueError(f"Source column '{source_column}' does not exist in DataFrame")

    # Check if output column already exists
    if output_column in df.columns:
        logger.error(
            f"Output column '{output_column}' already exists in DataFrame",
            exc_info=True,
        )
        raise ValueError(f"Output column '{output_column}' already exists in DataFrame")

    # Convert source column to numeric, handling non-numeric values
    try:
        # First convert to numeric using pandas, then to polars
        df_numeric = df.copy()
        df_numeric[source_column] = pd.to_numeric(
            df_numeric[source_column], errors="coerce"
        )

        # Convert pandas DataFrame to polars for internal operations
        pl_df = pl.from_pandas(df_numeric)
        pl_df = pl_df.with_columns(
            pl.col(source_column).cast(pl.Float64).alias(source_column)
        )
    except Exception as e:
        logger.error(
            f"Cannot convert source column '{source_column}' to numeric: {e}",
            exc_info=True,
        )
        raise ValueError(f"Source column '{source_column}' must contain numeric values")

    # Check for non-null values in source column
    non_null_count = pl_df.select(pl.col(source_column).is_not_null().sum()).item()
    if non_null_count == 0:
        logger.warning(f"All values in source column '{source_column}' are null")
        # Create output column with all nulls using pandas method
        result_df = df.copy()
        result_df[output_column] = pd.Series([None] * len(df), dtype="float64")
        logger.info(
            "forward_fill_averages exit: returning DataFrame with null-filled output column"
        )
        return result_df

    # Implement forward-fill with cumulative averages using polars
    def forward_fill_cumulative_avg(group):
        """Apply forward-fill with cumulative averages to a polars group."""
        # Get the source column values
        values = group.select(source_column).to_series()

        # Initialize result list
        result_values = []
        cumulative_sum = 0.0
        cumulative_count = 0

        for value in values:
            if value is not None and not pd.isna(value):
                # Non-null value: use as-is and update cumulative
                result_values.append(value)
                cumulative_sum += value
                cumulative_count += 1
            else:
                # Null value: use cumulative average if available
                if cumulative_count > 0:
                    avg_value = cumulative_sum / cumulative_count
                    result_values.append(avg_value)
                else:
                    # No previous values - this shouldn't happen if we have non-null values
                    result_values.append(None)

        return pl.Series(result_values)

    # Apply forward-fill algorithm using polars operations
    # We'll implement this step by step to ensure proper handling

    # Create a list to store the result values
    result_values = []
    cumulative_sum = 0.0
    cumulative_count = 0

    # Get the source column as a pandas series for easier iteration
    source_values = df[source_column].values

    # Check if the first value is null (indicates we should replace all values with cumulative averages)
    first_value_is_null = pd.isna(source_values[0])

    for i, value in enumerate(source_values):
        if pd.notna(value):
            # Non-null value
            cumulative_sum += float(value)
            cumulative_count += 1

            if first_value_is_null:
                # First value was null: replace all values with cumulative averages
                avg_value = cumulative_sum / cumulative_count
                result_values.append(avg_value)
            else:
                # First value was non-null: preserve original non-null values
                result_values.append(float(value))
        else:
            # Null value: always use cumulative average
            if cumulative_count > 0:
                avg_value = cumulative_sum / cumulative_count
                result_values.append(avg_value)
            else:
                # Leading null before any values: find first non-null
                first_non_null = None
                for j in range(i, len(source_values)):
                    if pd.notna(source_values[j]):
                        first_non_null = float(source_values[j])
                        break

                if first_non_null is not None:
                    result_values.append(first_non_null)
                else:
                    # All values are null
                    result_values.append(None)

    # Create the result DataFrame with the new column
    result_df = df.copy()
    result_df[output_column] = result_values

    logger.info(
        f"forward_fill_averages exit: created output column '{output_column}', "
        f"filled {sum(1 for v in result_values if pd.notna(v))} total values, "
        f"filled {sum(1 for i, v in enumerate(result_values) if v != source_values[i] if pd.notna(v))} missing values"
    )

    return result_df
