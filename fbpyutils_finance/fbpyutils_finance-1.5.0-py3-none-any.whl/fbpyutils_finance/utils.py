"""
fbpyutils_finance.utils - General Utility Functions for Financial Data Processing

This module provides essential utility functions for financial data manipulation, web scraping,
and general-purpose operations commonly used across the fbpyutils_finance package. It includes
functions for data type conversion, safe list operations, HTTP header generation for web requests,
and database connection validation.

Main Contents
-------------
Data Conversion Functions:
    numberize(value)              Convert strings with commas to float values
    first_or_none(items)          Safely get first item from list or return None

Web Scraping Utilities:
    random_header()               Generate random HTTP headers for web requests

Database Utilities:
    is_valid_db_connection(conn)  Validate database connection-like objects

Dependencies
------------
- random: Random selection for header generation
- subprocess: System process utilities (may be used by underlying libraries)
- shutil: File system operations (may be used by underlying libraries)
- typing: Type hint utilities for enhanced IDE support
- fbpyutils_finance.logger: Centralized logging functionality

High-Level Usage Pattern
-------------------------
The module provides foundational utilities that support various financial operations:

1. **Data Processing**: Convert and validate financial data formats
2. **Web Operations**: Generate realistic HTTP headers for data scraping
3. **Error Handling**: Safe operations that prevent common runtime errors
4. **Validation**: Check database connections and similar objects

Common Use Cases
~~~~~~~~~~~~~~~~
- Converting European number format (comma decimal) to Python floats
- Safely extracting first elements from lists without IndexError
- Generating realistic browser headers for financial data scraping
- Validating database connection objects before use

Examples
--------
Data conversion and validation:

>>> from fbpyutils_finance.utils import numberize, first_or_none
>>>
>>> # Convert European number format to float
>>> price = numberize("1.234,56")
>>> print(f"Price: {price}")
Price: 1234.56
>>>
>>> # Handle standard US format
>>> us_price = numberize("1,234.56")
>>> print(f"US Price: {us_price}")
US Price: 1234.56
>>>
>>> # Safely get first item from list
>>> items = [1, 2, 3]
>>> first = first_or_none(items)
>>> print(f"First item: {first}")
First item: 1
>>>
>>> # Handle empty list gracefully
>>> empty_first = first_or_none([])
>>> print(f"Empty list first: {empty_first}")
Empty list first: None

Web scraping with realistic headers:

>>> from fbpyutils_finance.utils import random_header
>>>
>>> # Generate random browser headers
>>> headers = random_header()
>>> print(f"User-Agent: {headers['User-Agent']}")
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36...

>>> # Use headers in requests
>>> import requests
>>> response = requests.get("https://example.com", headers=headers)

Database connection validation:

>>> from fbpyutils_finance.utils import is_valid_db_connection
>>>
>>> # Mock database connection class
>>> class MockDB:
...     def execute(self, query): pass
>>>
>>> # Validate connection object
>>> conn = MockDB()
>>> if is_valid_db_connection(conn):
...     print("Valid database connection")
... else:
...     print("Invalid connection")
Valid database connection
>>>
>>> # Test with invalid object
>>> invalid_conn = "not a connection"
>>> print(f"Is valid: {is_valid_db_connection(invalid_conn)}")
Is valid: False

Notes
-----
- numberize() handles both European (comma decimal) and US (dot decimal) formats
- first_or_none() provides safe list access without IndexError risk
- random_header() generates headers that mimic real web browsers
- is_valid_db_connection() checks for callable 'execute' method presence
- All functions include comprehensive logging for debugging and audit

See Also
--------
fbpyutils_finance.assessment: Portfolio assessment using data processing utilities
fbpyutils_finance.calculators: Financial calculations requiring data validation

References
----------
.. [1] HTTP Header Standards and Best Practices
   https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers
.. [2] Database Connection Patterns and Validation
   https://www.python.org/dev/peps/pep-0249/
.. [3] Data Type Conversion in Financial Applications
   https://www.investopedia.com/terms/n/numberformatting.asp
"""

from typing import Any, Dict, List, Optional



def numberize(value: Any) -> float:
    """Convert strings or numbers containing commas to float values.

    This function handles international number formats by removing commas and converting
    to float. It supports both European format (1.234,56) and US format (1,234.56) by
    removing all commas before conversion.

    Parameters
    ----------
    value : Any
        The value to convert to float. Can be:

        * String containing numbers with commas (e.g., "1,234.56" or "1.234,56")
        * Numeric types (int, float) that will be converted directly
        * Any object that can be stringified and represents a number

    Returns
    -------
    float
        The converted float value with all commas removed.

        Examples:
        * "1,234.56" → 1234.56
        * "1.234,56" → 1234.56
        * 1234 → 1234.0
        * "999" → 999.0

    Examples
    --------
    Convert European number format:

    >>> numberize("1.234,56")
    1234.56

    Convert US number format:

    >>> numberize("1,234.56")
    1234.56

    Handle numeric inputs directly:

    >>> numberize(1234)
    1234.0
    >>> numberize(1234.56)
    1234.56

    Convert mixed formats:

    >>> numberize("1,000,000.50")
    1000000.5

    See Also
    --------
    first_or_none : Safe list access utility
    float : Built-in float conversion function

    Notes
    -----
    The function works by:
    1. Converting input to string representation
    2. Removing all comma characters
    3. Converting the result to float

    This approach handles most international number formats but assumes
    that dots are used as decimal separators when both dots and commas are present.

    Use cases in financial applications:
    - Parsing European financial data
    - Converting string prices to numeric values
    - Data cleaning for financial calculations
    - Handling mixed number formats in scraped data
    """


def first_or_none(items: List[Any]) -> Optional[Any]:
    """Safely return the first item from a list or None if the list is empty.

    This function provides a safe way to access the first element of a list without
    raising an IndexError when the list is empty. It's commonly used when working
    with potentially empty lists in data processing workflows.

    Parameters
    ----------
    items : List[Any]
        The input list from which to retrieve the first item.
        Can contain any type of elements.

    Returns
    -------
    Optional[Any]
        The first item in the list if the list is non-empty, otherwise None.

        Examples:
        * [1, 2, 3] → 1
        * ["a", "b"] → "a"
        * [] → None
        * [None] → None (returns the None element, not empty indicator)

    Examples
    --------
    Basic usage with non-empty list:

    >>> first_or_none([1, 2, 3])
    1

    Handle empty list gracefully:

    >>> first_or_none([])
    None

    Work with string lists:

    >>> first_or_none(["first", "second", "third"])
    'first'

    Handle mixed type lists:

    >>> first_or_none([42, "string", [1, 2], {"key": "value"}])
    42

    Preserve None elements:

    >>> first_or_none([None, "valid"])
    None

    See Also
    --------
    numberize : Data conversion utility often used with list processing
    list : Built-in list type for creating lists

    Notes
    -----
    This function is equivalent to:

    .. code-block:: python

        return items[0] if items else None

    Common use cases:
    - Safe extraction of default values from lists
    - Handling API responses that might return empty arrays
    - Processing CSV rows where first column is important
    - Working with database query results that might be empty
    - Functional programming patterns requiring safe list access

    Performance considerations:
    - Time complexity: O(1) for non-empty lists, O(1) for empty lists
    - Memory usage: No additional memory allocation
    - Thread safety: Safe for concurrent access with immutable lists
    """


def random_header() -> Dict[str, str]:
    """Generate realistic HTTP headers for web scraping and API requests.

    This function returns a randomly selected dictionary of HTTP headers that mimic
    real web browsers. It's designed to help avoid detection when scraping financial
    data from websites that implement basic bot detection mechanisms.

    The function includes a curated collection of realistic browser header combinations
    representing different browsers, operating systems, and versions to provide
    diverse and believable request signatures.

    Returns
    -------
    Dict[str, str]
        A dictionary containing realistic HTTP headers including:

        * User-Agent: Browser identification string
        * Accept: Accepted content types
        * Accept-Language: Preferred languages
        * Accept-Encoding: Supported encoding methods
        * DNT: Do Not Track preference
        * Connection: Connection management
        * Upgrade-Insecure-Requests: HTTPS preference

    Examples
    --------
    Generate and inspect random headers:

    >>> headers = random_header()
    >>> print(f"User-Agent: {headers['User-Agent']}")
    User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0

    Use headers with requests library:

    >>> import requests
    >>> response = requests.get("https://example.com", headers=random_header())

    Generate multiple different headers:

    >>> for i in range(3):
    ...     headers = random_header()
    ...     print(f"Request {i+1}: {headers['User-Agent'][:50]}...")
    Request 1: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit...
    Request 2: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit...
    Request 3: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101...

    See Also
    --------
    requests : Popular Python HTTP library for making requests
    is_valid_db_connection : Another utility function in this module

    Notes
    -----
    The header collection includes:

    * **Firefox headers**: Various versions on Windows and different configurations
    * **Chrome headers**: Modern versions on Windows, Mac, and Edge
    * **Language diversity**: Both Portuguese (pt-BR) and English (en-US) variants
    * **Encoding support**: gzip and deflate compression methods

    Best practices for web scraping:

    1. **Rotate headers**: Use different headers for each request when possible
    2. **Respect robots.txt**: Always check and respect website scraping policies
    3. **Rate limiting**: Add delays between requests to avoid overwhelming servers
    4. **User-Agent rotation**: This function helps with realistic User-Agent rotation
    5. **Session management**: Consider using sessions for maintaining cookies and state

    Legal and ethical considerations:

    * Only scrape publicly available data
    * Respect website terms of service
    * Implement appropriate rate limiting
    * Consider using official APIs when available
    * Be mindful of server resources and load
    """


def is_valid_db_connection(conn: Any) -> bool:
    """Check if an object behaves like a valid database connection.

    This function validates whether a given object has the characteristics of a
    database connection by checking for the presence and callability of an 'execute'
    method. This pattern follows the Python Database API Specification (PEP 249).

    Parameters
    ----------
    conn : Any
        The object to validate as a potential database connection.
        Can be any Python object (connection, mock object, string, etc.).

    Returns
    -------
    bool
        True if the object has a callable 'execute' method, False otherwise.

        Examples:
        * Valid connection object → True
        * Object with non-callable execute → False
        * String or primitive type → False
        * None → False

    Examples
    --------
    Validate a mock database connection:

    >>> class MockConnection:
    ...     def execute(self, query):
    ...         pass
    >>>
    >>> conn = MockConnection()
    >>> is_valid_db_connection(conn)
    True

    Test with invalid objects:

    >>> is_valid_db_connection("not a connection")
    False
    >>> is_valid_db_connection(None)
    False
    >>> is_valid_db_connection(42)
    False

    Handle object with non-callable execute:

    >>> class BadConnection:
    ...     execute = "not a method"
    >>>
    >>> is_valid_db_connection(BadConnection())
    False

    See Also
    --------
    PEP 249 - Python Database API Specification
    random_header : Another utility function for web operations

    Notes
    -----
    This function implements a simple duck-typing approach to database connection
    validation. It checks for:

    1. **Attribute presence**: Does the object have an 'execute' attribute?
    2. **Callable check**: Is the 'execute' attribute callable (a method)?

    The function returns True only if both conditions are met.

    Common use cases:
    - Validating database connections before executing queries
    - Testing database abstraction layers
    - Mock object validation in unit tests
    - Connection pooling validation
    - Safe database operation wrappers

    This approach is compatible with various database connection types:
    - sqlite3.Connection objects
    - psycopg2 connection objects
    - MySQL connection objects
    - Custom connection implementations
    - Mock objects for testing

    Note that this function only checks for the 'execute' method presence and
    callability. It does not test:
    - Whether the connection is actually open
    - Whether the connection can execute queries successfully
    - The specific database API compliance
    - Connection state or validity beyond the execute method
    """
