import os
import fbpyutils

from dotenv import load_dotenv


_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "CRITICAL")

logger = fbpyutils.get_logger()
logger.configure_from_env(env)
