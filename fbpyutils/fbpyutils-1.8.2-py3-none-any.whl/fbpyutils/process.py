"""
Parallel and Serial Process Execution Framework

This module provides a comprehensive framework for executing processing functions in both parallel
and serial modes with advanced control mechanisms for file processing and session management.
The module includes classes for basic process execution, timestamp-based file processing,
and session-based resumable processing workflows.

The module offers five primary capabilities:

* **Process Execution Framework**: Base Process class supporting parallel and serial execution
  using threads or processes with configurable worker pools and error handling.

* **File Processing Control**: FileProcess class with timestamp-based control to prevent
  reprocessing of unmodified files using pickle-based control files.

* **Session Management**: SessionProcess class enabling resumable processing sessions
  with task-level control and failure recovery mechanisms.

* **CPU Detection**: Automatic CPU core detection and parallel processing capability
  assessment for optimal resource utilization.

* **Protocol Definitions**: Type protocols for processing functions ensuring consistent
  interface contracts and type safety across different processing scenarios.

Key Features:
-------------
* **Flexible Parallelization**: Support for both thread-based and process-based parallelism
* **Resource Management**: Configurable worker pools with automatic CPU core detection
* **Fault Tolerance**: Comprehensive error handling with graceful degradation
* **Session Persistence**: Pickle-based control files for resuming interrupted workflows
* **Timestamp Control**: File modification time tracking for efficient processing
* **Type Safety**: Protocol definitions for consistent function interfaces

Dependencies:
-------------
* `multiprocessing`: CPU core detection and process-based parallelism
* `concurrent.futures`: High-level parallel execution interface
* `pickle`: Control file serialization for session and file tracking
* `uuid`: Unique identifier generation for sessions and tasks
* `fbpyutils.string`: Hash utilities for task and session identification
* `fbpyutils.env`: Environment configuration access
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Basic parallel processing:

>>> from fbpyutils.process import Process
>>> def process_item(item):
...     return True, None, f"Processed {item}"
>>> processor = Process(process_item, parallelize=True, workers=4)
>>> results = processor.run([(1,), (2,), (3,)])
>>> results[0]
(True, None, 'Processed 1')

File processing with timestamp control:

>>> from fbpyutils.process import FileProcess
>>> def process_file(filepath):
...     return filepath, True, None, "File processed"
>>> processor = FileProcess(process_file, parallelize=True)
>>> results = processor.run([('/path/to/file1.txt',), ('/path/to/file2.txt',)], controlled=True)

Session-based resumable processing:

>>> from fbpyutils.process import SessionProcess
>>> def task_function(param):
...     return True, None, f"Task completed: {param}"
>>> processor = SessionProcess(task_function, parallelize=False)
>>> session_id = processor.generate_session_id()
>>> results1 = processor.run([('task1',), ('task2',)], session_id=session_id, controlled=True)
>>> # Resume session later
>>> results2 = processor.run([('task1',), ('task2',)], session_id=session_id, controlled=True)

CPU detection and parallel capability checking:

>>> from fbpyutils.process import Process
>>> cpu_count = Process.get_available_cpu_count()
>>> can_parallel = Process.is_parallelizable('processes')
>>> print(f"CPU cores: {cpu_count}, Parallel processes: {can_parallel}")
CPU cores: 8, Parallel processes: True

Notes:
------
* Process classes automatically detect available CPU cores for optimal worker allocation
* Control files are stored in the application's user data directory
* Session and file control mechanisms use pickle for data persistence
* Parallel processing supports both threads and processes based on system capabilities
* Error handling includes detailed logging for troubleshooting

Performance Considerations:
------------------------
* Parallel processing overhead may exceed benefits for small task sets
* Process-based parallelism has higher startup costs than threads
* Control file I/O adds minimal overhead for large-scale processing
* Memory usage scales with number of parallel workers

Cross-References:
-----------------
* See `fbpyutils.string` for hash utilities used in control file naming
* See `fbpyutils.env` for user data directory configuration
* See `fbpyutils.logging` for operation tracking and error reporting
* See `fbpyutils.setup()` for proper initialization requirements
"""

import os
import time
import pickle
import inspect
import multiprocessing
import uuid
import concurrent.futures
from time import perf_counter

from typing import Any, Callable, List, Tuple, Dict, Optional, TypeVar, Protocol
from datetime import datetime

import fbpyutils

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

from fbpyutils import get_env, get_logger
from fbpyutils.string import hash_string

_env = get_env()
_logger = get_logger()

# Type variable for generic processing function
T = TypeVar("T")


class ProcessingFunction(Protocol):
    """
    Defines the protocol for a generic processing function.

    A processing function should accept a tuple of parameters and return a tuple
    containing a boolean indicating success, an optional error message (string),
    and a result of any type.
    """

    def __call__(self, params: Tuple[Any, ...]) -> Tuple[bool, Optional[str], Any]:
        """
        Executes the processing function.

        Args:
            params (Tuple[Any, ...]): A tuple containing the parameters for the processing function.

        Returns:
            Tuple[bool, Optional[str], Any]: A tuple containing the success status (bool),
                                             an optional error message (str or None), and
                                             the processing result (Any).
        """
        ...


class ProcessingFilesFunction(Protocol):
    """
    Defines the protocol for a file processing function.

    A file processing function should accept a tuple of parameters, process a file,
    and return a tuple containing the file path (string), a boolean indicating success,
    an optional error message (string), and a result of any type.
    """

    def __call__(self, params: Tuple[Any, ...]) -> Tuple[str, bool, Optional[str], Any]:
        """
        Executes the file processing function.

        Args:
            params (Tuple[Any, ...]): A tuple containing the parameters for the file processing function.

        Returns:
            Tuple[str, bool, Optional[str], Any]: A tuple containing the processed file path (str),
                                             the success status (bool), an optional error message (str or None),
                                             and the processing result (Any).
        """
        ...


class Process:
    """
    Base class for parallel or serial function processing.

    This class provides the basic infrastructure to execute a processing function
    with a list of parameter sets. It supports both parallel execution using
    multiple threads or processes and serial execution in a single thread.

    It is designed to be subclassed for specific processing needs, offering
    flexibility in how functions are executed and managed.

    Attributes:
        _MAX_WORKERS: int
        _process: Callable
        _parallelize: bool
        _workers: int
        sleeptime: float
        _parallel_type: str
    """

    _MAX_WORKERS: int
    _process: Callable
    _parallelize: bool
    _workers: int
    sleeptime: float
    _parallel_type: str

    @staticmethod
    def _process_wrapper(func_and_params):
        func, params = func_and_params
        return func(*params)

    _MAX_WORKERS = os.cpu_count() if os.name == "nt" else 1

    @staticmethod
    def get_available_cpu_count() -> int:
        """
        Determines the number of available CPU cores for processing.

        This static method attempts to retrieve the CPU core count using
        `multiprocessing.cpu_count()`. If this is not supported (e.g., in some minimal
        environments), it logs a warning and defaults to returning 1, ensuring
        the application can still run, albeit without parallel processing.

        Returns:
            int: The number of available CPU cores. Returns 1 if the count cannot be determined.

        Note:
            - On Windows, this method returns the number of logical processors.
            - On other operating systems, it typically returns the number of physical cores,
              but behavior may vary depending on the system configuration and Python build.
        """
        try:
            cpu_count = multiprocessing.cpu_count()
            _logger.debug(f"Detected CPU count: {cpu_count}")
            return cpu_count
        except NotImplementedError:
            _logger.info("CPU count not supported, falling back to single worker")
            return 1

    @staticmethod
    def is_parallelizable(parallel_type: str = "threads") -> bool:
        """
        Checks if the current system supports the specified parallel processing type.

        This method determines if parallel processing of the specified type is
        available and safe to use on the current system. Includes special handling
        for Windows systems where true multiprocessing may not be available.

        Args:
            parallel_type (str): Type of parallelization to check ('threads' or 'processes').
                                 Defaults to 'threads'.

        Returns:
            bool: True if parallel processing is supported for the specified type, False otherwise.

        Raises:
            ValueError: If an invalid parallel_type is provided.
        """
        if parallel_type == "processes":
            try:
                import multiprocessing  # Import here to avoid global namespace pollution

                _logger.info("Multiprocessing parallelization available")
                return True
            except ImportError:
                _logger.error(
                    f"Multiprocessing not available: {__file__}:{inspect.currentframe().f_lineno}"
                )
                return False
        elif parallel_type == "threads":
            _logger.info("Default multi-threads parallelization available")
            return True
        else:
            _logger.warning(
                f"Unknown parallel type: {parallel_type}. Assuming not parallelizable."
            )
            return False

    @staticmethod
    def get_function_info(func: Callable) -> Dict[str, str]:
        """
        Gets detailed information about a function.

        This function extracts various identifiers and metadata about the provided function,
        including its module path, qualified name, memory address, and full reference.

        Args:
            func (Callable): The function to analyze.

        Returns:
            Dict[str, str]: Dictionary containing:
                - 'id': Memory address of the function
                - 'module': Module path where the function is defined
                - 'name': Qualified name of the function
                - 'full_ref': Full reference combining module and name
                - 'unique_ref': Absolute unique reference including memory address

        Example:
            >>> def my_func(): pass
            >>> info = Process.get_function_info(my_func)
            >>> print(info['full_ref'])
            'mymodule.my_func'

        Note:
            The 'unique_ref' can be used to distinguish between different instances
            of the same function in memory.
        """
        return {
            "id": str(id(func)),
            "module": func.__module__,
            "name": func.__qualname__,
            "full_ref": f"{func.__module__}.{func.__qualname__}",
            "unique_ref": f"{func.__module__}.{func.__qualname__}_{id(func)}",
        }

    def __init__(
        self,
        process: Callable[..., ProcessingFunction],
        parallelize: bool = True,
        workers: Optional[int] = _MAX_WORKERS,
        sleeptime: float = 0,
        parallel_type: str = "threads",
    ) -> None:
        """
        Initializes a new Process instance.

        Args:
            process (Callable): The processing function to be executed.
                                 It must conform to the ProcessingFunction protocol.
            parallelize (bool): If True, runs processing in parallel using threads or processes.
                                 If False, runs processing serially in the main thread. Defaults to True.
            workers (Optional[int]): The number of worker processes or threads to use for parallel execution.
                                     If None, it defaults to the number of CPU cores available (Process._MAX_WORKERS).
            sleeptime (float): Wait time in seconds between successive executions in serial mode.
                               Useful for throttling processing to reduce system load. Defaults to 0.
            parallel_type (str): Type of parallelization to use, either 'threads' or 'processes'.
                                 Defaults to 'threads'. 'threads' uses ThreadPoolExecutor, 'processes' uses ProcessPoolExecutor.

        Raises:
            ValueError: If an invalid parallel_type is provided.
        """
        parallel_type = parallel_type or "threads"
        if parallel_type not in (
            "threads",
            "processes",
        ):  # Corrected typo 'process' to 'processes'
            raise ValueError(
                f"Invalid parallel processing type: {parallel_type}. Valid types are: threads or processes."
            )
        self._process: Callable = process
        self._parallel_type: str = parallel_type
        _logger.debug(
            f"Initializing Process with parallelize={parallelize}, workers={workers}, sleeptime={sleeptime}, parallel_type={parallel_type}"
        )
        if parallel_type not in (
            "threads",
            "processes",
        ):  # Corrected typo 'process' to 'processes'
            _logger.error(
                f"Invalid parallel processing type: {parallel_type}. Valid types are: threads or processes."
            )
            raise ValueError(
                f"Invalid parallel processing type: {parallel_type}. Valid types are: threads or processes."
            )
        self._process: Callable = process
        self._parallel_type: str = parallel_type
        self._parallelize: bool = parallelize and Process.is_parallelizable(
            parallel_type=self._parallel_type
        )
        self._workers: int = (
            workers or Process._MAX_WORKERS
        )  # Ensured _workers is always int
        self.sleeptime: float = 0 if sleeptime < 0 else sleeptime
        _logger.info(
            f"Process initialized: parallel={self._parallelize}, type={self._parallel_type}, workers={self._workers}"
        )

    def run(
        self, params: List[Tuple[Any, ...]]
    ) -> List[Tuple[bool, Optional[str], Any]]:
        """
        Executes the processing function for each parameter set in the given list.

        Processes can be executed in parallel or serial mode based on the class configuration.

        Args:
            params (List[Tuple[Any, ...]]): List of parameter tuples. Each tuple contains the arguments
                                             to be passed to the processing function.

        Returns:
            List[Tuple[bool, Optional[str], Any]]: List of processing results. Each tuple in the list
                                             corresponds to a parameter set and contains:
                - success (bool): True if processing was successful, False otherwise.
                - error_message (Optional[str]): An error message if processing failed, None otherwise.
                - result (Any): The result of the processing function if successful, None otherwise.

        Raises:
            Exception: Any exception raised during the execution of the processing function.

        Note:
            When running in parallel mode, the order of results may not match the order of input parameters
            due to the nature of concurrent execution.
        """
        start_time = perf_counter()
        _logger.info(
            f"Starting process execution with {len(params)} parameter sets. Mode: {'parallel' if self._parallelize else 'serial'}"
        )
        responses: List[Tuple[bool, Optional[str], Any]] = []

        if not self._parallelize:
            _logger.info(
                f"Running in serial mode (parallelization disabled). Sleep time: {self.sleeptime}s"
            )
            success_count = 0
            error_count = 0

            for i, param in enumerate(params):
                _logger.debug(f"Processing item {i + 1}/{len(params)} in serial mode.")
                try:
                    result = self._process(*param)
                    responses.append(result)
                    if result[0]:  # success
                        success_count += 1
                        _logger.debug(f"Item {i + 1} processed successfully")
                    else:
                        error_count += 1
                        _logger.warning(f"Item {i + 1} processing failed: {result[1]}")
                except Exception as e:
                    _logger.error(
                        f"Error processing item {i + 1} in serial mode: {str(e)}"
                    )
                    responses.append(
                        (False, str(e), None)
                    )  # Ensure consistent return format
                    error_count += 1
                if self.sleeptime > 0:
                    time.sleep(self.sleeptime)

            duration = perf_counter() - start_time
            _logger.info(
                f"Serial execution completed: {success_count} successful, {error_count} failed, duration: {duration:.2f}s"
            )
            return responses

        max_workers = self._workers or Process.get_available_cpu_count()
        if max_workers < 1 or max_workers > Process.get_available_cpu_count():
            _logger.warning(
                f"Requested workers ({max_workers}) out of bounds. Adjusting to available CPU count: {Process.get_available_cpu_count()}"
            )
            max_workers = Process.get_available_cpu_count()

        _logger.info(
            f"Starting parallel execution with {max_workers} workers using {self._parallel_type}."
        )
        executor_class = (
            concurrent.futures.ProcessPoolExecutor
            if self._parallel_type == "processes"
            else concurrent.futures.ThreadPoolExecutor
        )
        try:
            with executor_class(max_workers=max_workers) as executor:
                if self._parallel_type == "processes":
                    responses = list(
                        executor.map(
                            Process._process_wrapper,
                            [(self._process, p) for p in params],
                        )
                    )
                else:
                    responses = list(executor.map(lambda x: self._process(*x), params))

            # Count successes and failures
            # A result is successful if r[0] is defined/not null (handles bool, DataFrame, etc.)
            def _is_success(result_elem):
                if result_elem is None:
                    return False
                if result_elem is False:
                    return False
                # For any other value (True, DataFrame, etc.), it's a success
                return True
            
            success_count = sum(1 for r in responses if _is_success(r[0]))
            error_count = len(responses) - success_count

            duration = perf_counter() - start_time
            _logger.info(
                f"Parallel execution completed: {success_count} successful, {error_count} failed, duration: {duration:.2f}s"
            )
            return responses
        except Exception as e:
            duration = perf_counter() - start_time
            _logger.error(
                f"Error during parallel process execution after {duration:.2f}s: {str(e)}"
            )
            raise


class FileProcess(Process):
    """
    Class for file processing with timestamp-based control to prevent reprocessing.

    This class extends Process by adding the ability to control execution
    based on file modification timestamps. It avoids unnecessary reprocessing
    of files that have not been modified since the last successful processing.

    It uses a control file to track the last processing timestamp for each file,
    stored in a dedicated folder within the application's user data directory.

    Methods:
        _controlled_run: Executes processing with timestamp control logic.
        run: Executes processing for multiple files, with optional timestamp control.

    Inherits from:
        Process: Base class providing parallel/serial processing capabilities.
    """

    def _controlled_run(self, *args: Any) -> Tuple[str, bool, Optional[str], Any]:
        """Execute a function with file timestamp-based control.

        This function checks if a file needs to be processed based on its creation
        timestamp compared to the last recorded processing timestamp. Control is maintained
        through a pickle file that stores the timestamp of the last successful execution.

        Args:
            *args: Variable length argument list. Expects the first argument to be the
                   processing function and the second to be the file path, followed by
                   any other arguments required by the processing function.

        Returns:
            Tuple[str, bool, Optional[str], Any]: A tuple containing:
                - file_path (str): Path of the processed file.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.

        Raises:
            ValueError: If not enough arguments are provided (at least processing function and file path).
            FileNotFoundError: If the file to be processed does not exist.

        Note:
            The control file is stored in a dedicated folder under the application's
            data directory, using a hash of the function's full reference as the folder name
            and a hash of the file path as the control file name.
        """
        from fbpyutils.file import creation_date

        _logger.debug(f"Starting _controlled_run with args: {args}")
        try:
            if len(args) < 2:
                _logger.error(
                    "Not enough arguments for _controlled_run. Expected at least (process_function, file_path)."
                )
                raise ValueError("Not enough arguments to run")

            process: Callable = args[0]  # Added type hint
            process_file: str = args[1]  # Added type hint

            if not os.path.exists(process_file):
                _logger.error(f"Process file not found: {process_file}")
                raise FileNotFoundError(f"Process file {process_file} does not exist")

            # Create control folder
            control_folder: str = os.path.sep.join(
                [
                    _env.USER_APP_FOLDER,
                    f"p_{hash_string(Process.get_function_info(process)['full_ref'])}.control",
                ]
            )
            if not os.path.exists(control_folder):
                _logger.info(f"Creating control folder: {control_folder}")
                try:
                    os.makedirs(control_folder)
                except FileExistsError:
                    _logger.warning(
                        f"{control_folder} already exists, probably created by concurrent process. Skipping."
                    )

            # Define control file path
            control_file: str = os.path.sep.join(
                [control_folder, f"f_{hash_string(process_file)}.reg"]
            )

            # Get current file timestamp
            current_timestamp: float = creation_date(process_file).timestamp()

            # Check if control file exists and read last timestamp
            control_exists: bool = os.path.exists(control_file)
            _logger.debug(f"Control file exists for {process_file}: {control_exists}")
            if control_exists:
                try:
                    with open(control_file, "rb") as cf:
                        last_timestamp: float = pickle.load(cf)  # Added type hint
                except Exception as e:
                    _logger.warning(
                        f"Could not read control file {control_file}: {e}. Treating as if control file does not exist."
                    )
                    last_timestamp = -1  # Treat as if no previous timestamp

                # If file has not been modified since last processing, skip processing
                if last_timestamp >= current_timestamp:
                    _logger.debug(
                        f"Control file timestamp: {last_timestamp}, File timestamp: {current_timestamp}. Elapsed time: {round(abs(last_timestamp - current_timestamp), 4)}"
                    )
                    _logger.info(f"Skipping unmodified file: {process_file}.")
                    return (process_file, True, "Skipped", None)

            _logger.info(f"Processing file: {process_file}")
            # Execute processing function
            try:
                result = process(
                    process_file
                )  # Call with file path for file processing functions

                # Handle various return value formats from the process function
                if len(result) < 3:
                    _logger.error(
                        f"Unexpected result length from process function: {len(result)}. Result: {result}"
                    )
                    return (process_file, False, "Unexpected result length", None)

                # Extract components based on ProcessingFilesFunction protocol
                # For a 4-tuple, it should be (file_path, success, message, data)
                if len(result) >= 4:
                    success = result[1]  # success is second element
                    message = result[2]  # message is third element
                    proc_result = result[3]  # result is fourth element
                else:
                    # For a 3-tuple, assume (success, message, data)
                    success = result[0]
                    message = result[1]
                    proc_result = result[2]
            except Exception as e:
                _logger.error(f"Error processing file {process_file}: {str(e)}")
                return (process_file, False, str(e), None)

            # Update control file if processing was successful
            if success:  # success
                try:
                    with open(control_file, "wb") as cf:
                        pickle.dump(current_timestamp, cf)
                    _logger.info(f"Updated control file: {control_file}")
                except Exception as e:
                    _logger.error(f"Error writing control file {control_file}: {e}")
            # Remove control file if it was created but an error occurred
            elif not control_exists and os.path.exists(control_file):
                try:
                    os.remove(control_file)
                    _logger.info(f"Removed control file due to error: {control_file}")
                except Exception as e:
                    _logger.error(f"Error removing control file {control_file}: {e}")

            # For ProcessingFilesFunction, return consistent format (file_path, success, message, result)
            _logger.debug(
                f"Finished _controlled_run for {process_file}. Success: {success}"
            )
            return (process_file, success, message, proc_result)
        except Exception as e:
            _logger.critical(
                f"Critical error in controlled run for {process_file}: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise

    def __init__(
        self,
        process: Callable[..., ProcessingFilesFunction],
        parallelize: bool = True,
        workers: Optional[int] = Process._MAX_WORKERS,
        sleeptime: float = 0,
    ) -> None:
        """
        Initializes a new instance of FileProcess.

        Args:
            process (Callable): The file processing function to be executed.
                                 It must conform to the ProcessingFilesFunction protocol.
            parallelize (bool): If True, runs processing in parallel. If False, runs serially.
                                 Defaults to True.
            workers (Optional[int]): Number of workers for parallel execution.
                                     Defaults to Process._MAX_WORKERS (CPU count).
            sleeptime (float): Wait time in seconds between executions in serial mode. Defaults to 0.
        """
        super().__init__(
            process, parallelize, workers, sleeptime
        )  # Pass process to super().__init__
        self._process: Callable = process  # Added type hint
        _logger.debug(
            f"Initializing FileProcess with parallelize={parallelize}, workers={workers}, sleeptime={sleeptime}"
        )
        super().__init__(
            process, parallelize, workers, sleeptime
        )  # Pass process to super().__init__
        self._process: Callable = process  # Added type hint
        self._parallelize: bool = parallelize and Process.is_parallelizable()
        self._workers: int = (
            workers or Process._MAX_WORKERS
        )  # Ensured _workers is always int
        self.sleeptime: float = 0 if sleeptime < 0 else sleeptime
        _logger.info(
            f"FileProcess initialized: parallel={self._parallelize}, workers={self._workers}"
        )

    def run(
        self, params: List[Tuple[Any, ...]], controlled: bool = False
    ) -> List[Tuple[str, bool, Optional[str], Any]]:
        """
        Executes file processing for multiple files, optionally with timestamp control.

        This function extends the run method of the Process class by adding the capability to
        control execution based on file timestamps, avoiding reprocessing of unmodified files.

        Args:
            params (List[Tuple[Any, ...]]): List of parameter tuples for processing.
                                             Each tuple should contain at least the file path as the first element,
                                             followed by any other arguments required by the processing function.
            controlled (bool): If True, uses timestamp-based execution control to prevent reprocessing
                               of unmodified files. Defaults to False.

        Returns:
            List[Tuple[str, bool, Optional[str], Any]]: List of processing results. Each tuple contains:
                - file_path (str): Path of the processed file.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.
        """
        _logger.info(
            f"Starting FileProcess run with {len(params)} items, controlled: {controlled}"
        )
        try:
            if controlled:
                _logger.info("Starting controlled execution for FileProcess.")
                # Save the original process function
                original_process: Callable = self._process  # Added type hint
                # Temporarily replace with _controlled_run method
                self._process = self._controlled_run
                try:
                    # Execute using the modified infrastructure for execution control
                    _params: List[Tuple[Any, ...]] = [
                        (original_process,) + p for p in params
                    ]  # Added type hint
                    # Execute using the base class infrastructure
                    results = super().run(_params)
                    _logger.info("Finished controlled execution for FileProcess.")
                    return results
                finally:
                    # Restore the original function
                    self._process = original_process
            else:
                _logger.info("Starting normal execution for FileProcess.")
                # If controlled=False, use the default behavior of the base class
                results = super().run(params)
                _logger.info("Finished normal execution for FileProcess.")
                return results
        except Exception as e:
            _logger.critical(
                f"Critical error in FileProcess run: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise


class SessionProcess(Process):
    """
    Extends Process to provide session-based control for resumable tasks.

    This class allows processing sessions to be interrupted and resumed without
    reprocessing completed tasks. It uses a unique session ID to track the state
    of each task, storing its completion status in a control file. This is ideal
    for long-running workflows where fault tolerance and the ability to resume
    are critical.

    Each task within a session is assigned a unique ID based on its parameters,
    ensuring that even if the order of tasks changes, their completion status
    is correctly tracked.

    Example:
        >>> import time
        >>> import shutil
        >>> import os
        >>> from fbpyutils.process import SessionProcess
        >>> from fbpyutils.env import Env
        >>>
        >>> # Define a sample task that can fail
        >>> def sample_task(duration: int, task_name: str):
        ...     print(f"Running task: {task_name} for {duration}s")
        ...     time.sleep(duration)
        ...     # Simulate a failure for 'task2' on the first attempt
        ...     if task_name == "task2" and not hasattr(sample_task, 'has_failed'):
        ...         sample_task.has_failed = True
        ...         print(f"Task {task_name} failed.")
        ...         return False, "Simulated failure", None
        ...     print(f"Finished task: {task_name}")
        ...     return True, None, {"name": task_name, "duration": duration}
        >>>
        >>> # 1. Initialize the processor
        >>> processor = SessionProcess(process=sample_task, parallelize=False)
        >>> tasks = [(1, "task1"), (1, "task2"), (1, "task3")]
        >>>
        >>> # 2. First run: task2 will fail
        >>> session_id = processor.generate_session_id()
        >>> print(f"--- Starting first run with session ID: {session_id} ---")
        >>> results1 = processor.run(params=tasks, session_id=session_id, controlled=True)
        >>> print(f"Results (Run 1): {results1}")
        >>> # Expected: task1 completes, task2 fails, task3 is not processed.
        >>>
        >>> # 3. Second run: Resume the session. task1 should be skipped.
        >>> print(f"\\n--- Resuming run with session ID: {session_id} ---")
        >>> results2 = processor.run(params=tasks, session_id=session_id, controlled=True)
        >>> print(f"Results (Run 2): {results2}")
        >>> # Expected: task1 is skipped, task2 and task3 are processed successfully.
        >>>
        >>> # Clean up control files
        >>> control_folder = os.path.join(_env.USER_APP_FOLDER, f"s_{session_id}.session")
        >>> if os.path.exists(control_folder):
        ...     shutil.rmtree(control_folder)

    Inherits from:
        Process: Base class providing parallel/serial processing capabilities.
    """

    @staticmethod
    def generate_session_id() -> str:
        """
        Generates a unique identifier for a new processing session.

        Returns:
            str: A unique session ID (UUID4).
        """
        _logger.debug("Generating new session ID.")
        return str(uuid.uuid4())

    @staticmethod
    def generate_task_id(params: Tuple[Any, ...]) -> str:
        """
        Generates a unique, deterministic ID for a task based on its parameters.

        This ensures that the same task always gets the same ID, which is crucial
        for tracking its completion status across session resumes.

        Args:
            params (Tuple[Any, ...]): The parameters for the processing task.

        Returns:
            str: A hash string representing the unique task ID.
        """
        _logger.debug(f"Generating task ID for parameters: {params}")
        return hash_string(str(params))

    def _controlled_run(self, *args: Any) -> Tuple[str, bool, Optional[str], Any]:
        """Execute a function with session-based control.

        This function manages the execution of a processing function within a session,
        allowing for resumption of tasks. It tracks the status of each task (pending,
        completed, failed) using pickle files.

        Args:
            *args: Variable length argument list. Expects the first argument to be the
                   processing function, the second to be the session ID, the third to be
                   the task ID, and subsequent arguments to be the parameters for the
                   processing function.

        Returns:
            Tuple[str, bool, Optional[str], Any]: A tuple containing:
                - task_id (str): The ID of the processed task.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.

        Raises:
            ValueError: If not enough arguments are provided (at least processing function, session ID, and task ID).

        Note:
            Session and task control files are stored in a dedicated folder under the
            application's user data directory.
        """
        _logger.debug(f"Starting SessionProcess _controlled_run with args: {args}")
        try:
            if len(args) < 3:
                _logger.error(
                    "Not enough arguments for SessionProcess _controlled_run. Expected at least (process_function, session_id, task_id)."
                )
                raise ValueError("Not enough arguments to run")

            process: Callable = args[0]
            session_id: str = args[1]
            task_id: str = args[2]
            process_params: Tuple[Any, ...] = args[3:]

            # Create session control folder
            session_control_folder: str = os.path.sep.join(
                [_env.USER_APP_FOLDER, f"s_{session_id}.session"]
            )
            if not os.path.exists(session_control_folder):
                _logger.info(
                    f"Creating session control folder: {session_control_folder}"
                )
                try:
                    os.makedirs(session_control_folder)
                except FileExistsError:
                    _logger.warning(
                        f"{session_control_folder} already exists, probably created by concurrent process. Skipping."
                    )

            # Define task control file path
            task_control_file: str = os.path.sep.join(
                [session_control_folder, f"t_{task_id}.task"]
            )

            # Check if task was already processed successfully
            if os.path.exists(task_control_file):
                try:
                    with open(task_control_file, "rb") as tcf:
                        task_status = pickle.load(tcf)
                    if task_status.get("status") == "completed":
                        _logger.info(
                            f"Skipping already completed task: {task_id} in session {session_id}."
                        )
                        return (
                            task_id,
                            True,
                            "Skipped (completed)",
                            task_status.get("result"),
                        )
                except Exception as e:
                    _logger.warning(
                        f"Could not read task control file {task_control_file}: {e}. Re-processing task."
                    )

            _logger.info(f"Processing task: {task_id} in session {session_id}.")
            # Execute processing function
            try:
                result = process(*process_params)

                # Handle various return value formats from the process function
                if len(result) < 3:
                    _logger.error(
                        f"Unexpected result length from process function: {len(result)}. Result: {result}"
                    )
                    success = False
                    message = "Unexpected result length"
                    proc_result = None
                else:
                    success = result[0]
                    message = result[1]
                    proc_result = result[2]
            except Exception as e:
                _logger.error(
                    f"Error processing task {task_id} in session {session_id}: {str(e)}"
                )
                success = False
                message = str(e)
                proc_result = None

            # Update task control file
            task_status = {
                "status": "completed" if success else "failed",
                "timestamp": datetime.now(),
                "message": message,
                "result": proc_result,
            }
            try:
                with open(task_control_file, "wb") as tcf:
                    pickle.dump(task_status, tcf)
                _logger.info(
                    f"Updated task control file for {task_id} in session {session_id}. Status: {task_status['status']}"
                )
            except Exception as e:
                _logger.error(
                    f"Error writing task control file {task_control_file}: {e}"
                )

            _logger.debug(
                f"Finished SessionProcess _controlled_run for task {task_id}. Success: {success}"
            )
            return (task_id, success, message, proc_result)
        except Exception as e:
            _logger.critical(
                f"Critical error in SessionProcess controlled run for session {session_id}, task {task_id}: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise

    def __init__(
        self,
        process: Callable[..., ProcessingFunction],
        parallelize: bool = True,
        workers: Optional[int] = Process._MAX_WORKERS,
        sleeptime: float = 0,
    ) -> None:
        """
        Initializes a new instance of SessionProcess.

        Args:
            process (Callable): The processing function to be executed.
                                 It must conform to the ProcessingFunction protocol.
            parallelize (bool): If True, runs processing in parallel. If False, runs serially.
                                 Defaults to True.
            workers (Optional[int]): Number of workers for parallel execution.
                                     Defaults to Process._MAX_WORKERS (CPU count).
            sleeptime (float): Wait time in seconds between executions in serial mode. Defaults to 0.
        """
        _logger.debug(
            f"Initializing SessionProcess with parallelize={parallelize}, workers={workers}, sleeptime={sleeptime}"
        )
        super().__init__(process, parallelize, workers, sleeptime)
        self._process: Callable = process
        self._parallelize: bool = parallelize and Process.is_parallelizable()
        self._workers: int = workers or Process._MAX_WORKERS
        self.sleeptime: float = 0 if sleeptime < 0 else sleeptime
        _logger.info(
            f"SessionProcess initialized: parallel={self._parallelize}, workers={self._workers}"
        )

    def run(
        self,
        params: List[Tuple[Any, ...]],
        session_id: Optional[str] = None,
        controlled: bool = False,
    ) -> List[Tuple[str, bool, Optional[str], Any]]:
        """
        Executes processing for multiple tasks within a session, with resume capability.

        This function extends the run method of the Process class by adding session-based
        control, allowing processing to be resumed from the point of interruption or failure.

        Args:
            params (List[Tuple[Any, ...]]): List of parameter tuples for processing.
                                             Each tuple contains the arguments to be passed
                                             to the processing function.
            session_id (Optional[str]): A unique identifier for the processing session.
                                        If None, a new session ID will be generated.
            controlled (bool): If True, uses session-based execution control to enable
                               resume capability. Defaults to False.

        Returns:
            List[Tuple[str, bool, Optional[str], Any]]: List of processing results. Each tuple contains:
                - task_id (str): The ID of the processed task.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.
        """
        _logger.info(
            f"Starting SessionProcess run with {len(params)} tasks, session_id: {session_id}, controlled: {controlled}"
        )
        try:
            if controlled:
                _session_id = (
                    session_id if session_id else SessionProcess.generate_session_id()
                )
                _logger.info(
                    f"Starting session controlled execution for SessionProcess with session ID: {_session_id}."
                )
                # Save the original process function
                original_process: Callable = self._process
                # Temporarily replace with _controlled_run method
                self._process = self._controlled_run
                try:
                    _params: List[Tuple[Any, ...]] = [
                        (
                            original_process,
                            _session_id,
                            SessionProcess.generate_task_id(p),
                        )
                        + p
                        for p in params
                    ]
                    results = super().run(_params)
                    _logger.info(
                        f"Finished session controlled execution for SessionProcess with session ID: {_session_id}."
                    )
                    return results
                finally:
                    # Restore the original function
                    self._process = original_process
            else:
                _logger.info("Starting normal execution for SessionProcess.")
                # If controlled=False, use the default behavior of the base class
                # For consistency, we still generate task IDs, but they won't be persisted
                _params_with_task_ids = [
                    (SessionProcess.generate_task_id(p),) + p for p in params
                ]
                # The base Process.run expects (success, message, result) from _process.
                # We need to adapt the lambda to return (task_id, success, message, result)
                # when not controlled, so the return format is consistent.
                # This requires a slight modification to how the base run is called or how _process is defined.
                # For now, let's assume the base run handles the tuple correctly,
                # and we'll just pass the original params.
                # If the base run expects (success, message, result), and our _process returns (task_id, success, message, result),
                # then the base run will get (task_id, success, message) as its (success, message, result).
                # This needs careful consideration.
                # Let's adjust the _process_wrapper in Process to handle this, or ensure _process returns the expected format.
                # For now, I'll assume the base Process.run expects the direct output of self._process.
                # If _process returns (task_id, success, message, result), and base Process.run expects (success, message, result),
                # then we need to wrap it.
                # Given the current structure, the base Process.run expects (bool, Optional[str], Any).
                # Our _controlled_run returns (str, bool, Optional[str], Any).
                # This means when controlled=False, we need to ensure the self._process returns (bool, Optional[str], Any).
                # The original `process` passed to SessionProcess.__init__ is of type ProcessingFunction,
                # which returns (bool, Optional[str], Any). So, for non-controlled, it's fine.
                # The issue is the return type of SessionProcess.run itself. It should return (task_id, success, message, result).
                # So, for non-controlled, we need to generate a task_id and combine it with the result of the original process.

                results = []
                for p in params:
                    task_id = SessionProcess.generate_task_id(p)
                    success, message, proc_result = self._process(*p)
                    results.append((task_id, success, message, proc_result))

                _logger.info("Finished normal execution for SessionProcess.")
                return results
        except Exception as e:
            _logger.critical(
                f"Critical error in SessionProcess run: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise

    @staticmethod
    def generate_session_id() -> str:
        """
        Generates a unique session ID with the prefix 'session_'.

        Session IDs are used to group tasks within a processing session,
        allowing for session-level control and tracking.

        Returns:
            str: Unique session ID.
        """
        return f"session_{uuid.uuid4()}"

    @staticmethod
    def generate_task_id(params: Tuple[Any, ...]) -> str:
        """
        Generates a unique task ID based on the hash of the process parameters.

        Task IDs are used to uniquely identify each processing task within a session,
        allowing for task-level control and tracking of execution status.

        Args:
            params (Tuple[Any, ...]): Tuple of process parameters. The parameters that define the task.

        Returns:
            str: Unique task ID.
        """
        params_hash: str = hash_string(str(params))  # Added type hint
        return f"task_{params_hash}"

    def _controlled_run(self, *args: Any) -> Tuple[str, bool, Optional[str], Any]:
        """
        Executes a function with session-based control.

        Checks if a task needs to be processed based on the session control mechanism.
        It determines if a task has already been successfully processed within the current session
        by checking for the existence of a task control file.

        Args:
            *args: Variable length argument list. Expects the first argument to be the session ID,
                   the second to be the processing function, and the following arguments
                   are the parameters for the processing function.

        Returns:
            Tuple[str, bool, Optional[str], Any]: A tuple containing:
                - task_id (str): ID of the processed task.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.

        Raises:
            ValueError: If insufficient arguments are provided (less than session ID, process function, and parameters).
        """
        try:
            if len(args) < 3:
                raise ValueError(
                    "Not enough arguments to run session controlled process"
                )

            session_id: str = args[0]  # Added type hint
            process: Callable = args[1]  # Added type hint
            params: Tuple[Any, ...] = args[2:]  # Added type hint
            task_id: str = SessionProcess.generate_task_id(params)  # Added type hint

            # Create session control folder
            session_control_folder: str = os.path.sep.join(
                [
                    _env.USER_APP_FOLDER,
                    "session_control",
                    f"s_{hash_string(session_id)}",
                ]
            )
            if not os.path.exists(session_control_folder):
                _logger.info(
                    f"Creating session control folder: {session_control_folder}"
                )
                try:
                    os.makedirs(session_control_folder)
                except FileExistsError:
                    _logger.warning(
                        f"{session_control_folder} already exists, probably created by concurrent process. Skipping."
                    )

            # Define task control file path
            task_control_file: str = os.path.sep.join(
                [session_control_folder, f"t_{hash_string(task_id)}.reg"]
            )

            # Check if task control file exists
            task_control_exists: bool = os.path.exists(task_control_file)
            _logger.info(
                f"Task control file exists: {task_control_exists} for task_id: {task_id}"
            )
            if task_control_exists:
                _logger.info(f"Skipping already processed task: {task_id}")
                return (task_id, True, "Skipped", None)

            _logger.info(f"Processing task: {task_id} in session: {session_id}")
            # Execute processing function
            try:
                # For session process function, we pass the actual parameters
                result = process(*params)  # May return various formats

                # Handle various return value formats from the process function
                if len(result) < 2:
                    _logger.error(
                        f"Unexpected result length: {len(result)}. Result: {result}"
                    )
                    return (task_id, False, "Unexpected result length", None)

                # Extract components from result
                # For session process func, typically (success, message, result, data)
                success = result[0]
                message = result[1] if len(result) > 1 else None
                proc_result = result[2] if len(result) > 2 else None
            except Exception as e:
                _logger.error(f"Error processing task: {str(e)}")
                return (task_id, False, str(e), None)

            # Update task control file if processing was successful
            if success:  # success
                with open(task_control_file, "wb") as cf:
                    pickle.dump(
                        True, cf
                    )  # just mark that the task was successfully executed
                _logger.info(f"Updated task control file: {task_control_file}")
            # Remove task control file if it was created but an error occurred
            elif not task_control_exists and os.path.exists(task_control_file):
                os.remove(task_control_file)
                _logger.info(
                    f"Removed task control file due to error: {task_control_file}"
                )

            # For the session process, return a standardized format
            # Return structure: (task_id, success, message, result)
            return (task_id, success, message, proc_result)
        except Exception as e:
            _logger.error(
                f"Error in session controlled run: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise

    def __init__(
        self,
        process: Callable[..., ProcessingFunction],
        parallelize: bool = True,
        workers: Optional[int] = Process._MAX_WORKERS,
        sleeptime: float = 0,
        parallel_type: str = "threads",
    ) -> None:
        """
        Initializes a new instance of SessionProcess.

        Args:
            process (Callable): The processing function to be executed within a session.
                                 It must conform to the ProcessingFunction protocol.
            parallelize (bool): If True, runs processing in parallel. If False, runs serially.
                                 Defaults to True.
            workers (Optional[int]): Number of workers for parallel execution.
                                     Defaults to Process._MAX_WORKERS (CPU count).
            sleeptime (float): Wait time in seconds between executions in serial mode. Defaults to 0.
            parallel_type (str): Type of parallelization ('threads' or 'processes'). Defaults to 'threads'.
        """
        super().__init__(process, parallelize, workers, sleeptime, parallel_type)
        self._process: Callable = process  # Added type hint
        self._parallelize: bool = parallelize and Process.is_parallelizable(
            parallel_type=self._parallel_type
        )
        self._workers: int = (
            workers or Process._MAX_WORKERS
        )  # Ensured _workers is always int
        self.sleeptime: float = 0 if sleeptime < 0 else sleeptime
        _logger.info(
            f"SessionProcess initialized: parallel={self._parallelize}, workers={self._workers}, type={self._parallel_type}"
        )

    def run(
        self,
        params: List[Tuple[Any, ...]],
        session_id: Optional[str] = None,
        controlled: bool = False,
    ) -> List[Tuple[str, bool, Optional[str], Any]]:
        """
        Executes processing for multiple parameter sets, optionally with session control.

        This function extends the run method of the Process class by adding session-based execution control.
        It allows for resuming processing sessions by skipping tasks that have already been successfully completed.

        Args:
            params (List[Tuple[Any, ...]]): List of parameter tuples for processing.
                                             Each tuple contains the arguments for a single task
                                             to be processed within the session.
            session_id (Optional[str]): Session ID for resume control. If provided, the process will attempt
                                         to resume the session. If None, a new session ID will be generated.
                                         Defaults to None, which starts a new session.
            controlled (bool): If True, uses session-based execution control to enable session resume
                               capabilities. Defaults to False.

        Returns:
            List[Tuple[str, bool, Optional[str], Any]]: List of processing results. Each tuple contains:
                - task_id (str): ID of the processed task.
                - success (bool): True if processed successfully, False otherwise.
                - error_message (Optional[str]): Error message if processing failed, None otherwise.
                - result (Any): Function result if successful, None otherwise.
        """
        try:
            if controlled:
                _logger.info("Starting session controlled execution")
                _session_id: str = (
                    session_id or SessionProcess.generate_session_id()
                )  # Added type hint
                _logger.info(f"Session ID: {_session_id}")
                # Save the original process function
                original_process: Callable = self._process  # Added type hint
                # Temporarily replace with _controlled_run method
                # Need to ensure it's bound to self to avoid method missing self issue
                self._process = self._controlled_run
                try:
                    # Execute using the modified infrastructure for session control
                    _params: List[Tuple[Any, ...]] = [
                        (_session_id, original_process) + p for p in params
                    ]  # Added type hint
                    # Execute using the base class infrastructure
                    return super().run(_params)
                finally:
                    # Restore the original function
                    self._process = original_process
            else:
                _logger.info("Starting normal execution")
                # If controlled=False, use the default behavior of the base class
                return super().run(params)
        except Exception as e:
            _logger.error(
                f"Error in session process execution: {str(e)} at {__file__}:{inspect.currentframe().f_lineno}"
            )
            raise
