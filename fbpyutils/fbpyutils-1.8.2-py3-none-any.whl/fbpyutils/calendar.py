"""
Calendar manipulation and data enrichment utilities.

This module provides comprehensive functionality for calendar manipulation and
temporal data analysis, including date range generation, temporal marker
addition, and DataFrame enrichment with calendar-based attributes.

The module works with pandas DataFrames and datetime objects to provide
calendar intelligence for data analysis and time-based operations. It
generates complete calendar dimensions with year, quarter, month, week, and
day-level attributes, along with business-relevant temporal markers.

Functions
---------
get_calendar
    Generate a complete calendar dimension between two dates.
add_markers
    Add temporal markers and business intelligence to calendar data.
calendarize
    Enrich a DataFrame with comprehensive calendar attributes.

Dependencies
------------
- pandas: Data manipulation and date operations
- numpy: Numerical operations and type checking
- calendar: Standard library calendar functions

Examples
--------
Generate a simple calendar:

>>> from datetime import date
>>> from fbpyutils.calendar import get_calendar
>>> cal = get_calendar(date(2023, 1, 1), date(2023, 1, 5))
>>> len(cal)
5

Enrich DataFrame with calendar data:

>>> import pandas as pd
>>> from fbpyutils.calendar import calendarize
>>> df = pd.DataFrame({'date': pd.date_range('2023-01-01', periods=3)})
>>> result = calendarize(df, 'date')
>>> 'calendar_year' in result.columns
True

Notes
-----
All calendar functions include comprehensive error handling and logging
for debugging purposes. The module is designed to handle large date ranges
efficiently using pandas' vectorized operations.

See Also
--------
fbpyutils.datetime: Date and time utility functions
fbpyutils.logging: Logging configuration and utilities
"""

from datetime import date, datetime
from pandas import DataFrame
import pandas as pd
import numpy as np
import calendar as xcalendar

from typing import List

import fbpyutils

from fbpyutils import get_logger, datetime as dutl

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

_logger = get_logger()


def get_calendar(x: date, y: date) -> List:
    """Generate a complete calendar dimension between two dates.

    This function creates a comprehensive calendar dataset spanning from the
    start date to the end date (inclusive). Each calendar entry contains
    detailed temporal attributes useful for data analysis, reporting, and
    time-based aggregations.

    The generated calendar includes both standard date components (year, month,
    day) and derived attributes (quarter, half, week of year, ISO formats)
    along with formatted strings for different time granularity levels.

    Parameters
    ----------
    x : date
        Start date for the calendar generation. Must be a datetime.date object.
        The calendar will include this date as the first entry.
    y : date
        End date for the calendar generation. Must be a datetime.date object
        and strictly greater than the start date. The calendar will include
        this date as the last entry.

    Returns
    -------
    List[Dict[str, Any]]
        A list of dictionaries, where each dictionary represents a single day
        and contains the following attributes:

        - date (date): The calendar date
        - date_time (datetime): The datetime equivalent with time component
        - year (int): Four-digit year
        - half (int): Half-year indicator (1 or 2)
        - quarter (int): Quarter number (1, 2, 3, or 4)
        - month (int): Month number (1-12)
        - day (int): Day of month (1-31)
        - week_day (int): Day of week (0=Monday, 6=Sunday)
        - week_of_year (int): Week number within the year (01-53)
        - date_iso (str): ISO format date string (YYYY-MM-DD)
        - date_str (str): Formatted date string (YYYY-MM-DD)
        - week_day_name (str): Full weekday name (Monday, Tuesday, etc.)
        - week_day_name_short (str): Short weekday name (Mon, Tue, etc.)
        - week_month_name (str): Full month name (January, February, etc.)
        - week_month_name_short (str): Short month name (Jan, Feb, etc.)
        - year_str (str): Year as string (YYYY)
        - year_half_str (str): Year and half format (YYYY-H1 or YYYY-H2)
        - year_quarter_str (str): Year and quarter format (YYYY-Q1, YYYY-Q2, etc.)
        - year_month_str (str): Year and month format (YYYY-MM)

    Raises
    ------
    ValueError
        If the end date (y) is not strictly greater than the start date (x),
        or if either date is invalid.
    TypeError
        If x or y are not datetime.date objects.

    Examples
    --------
    Generate a 5-day calendar:

    >>> from datetime import date
    >>> from fbpyutils.calendar import get_calendar
    >>> cal = get_calendar(date(2023, 1, 1), date(2023, 1, 5))
    >>> len(cal)
    5
    >>> cal[0]['date']
    datetime.date(2023, 1, 1)
    >>> cal[0]['year']
    2023
    >>> cal[0]['quarter']
    1
    >>> cal[0]['week_day_name']
    'Sunday'

    Generate calendar for a month:

    >>> cal = get_calendar(date(2023, 3, 1), date(2023, 3, 31))
    >>> len(cal)
    31
    >>> cal[0]['year_month_str']
    '2023-03'

    Notes
    -----
    The function uses pandas' date_range internally for efficient date
    generation and handles large date ranges effectively.

    All date calculations are performed using pandas' vectorized operations
    for optimal performance, even with large date ranges.

    See Also
    --------
    add_markers : Add temporal markers to calendar data
    calendarize : Enrich DataFrame with calendar attributes
    pandas.date_range : Pandas date range generation

    """
    _logger.debug(f"Starting get_calendar with start_date: {x}, end_date: {y}")
    start_date, end_date = x, y
    if end_date <= start_date:
        _logger.error(
            f"Invalid end date: {end_date}. Must be greater than start date: {start_date}."
        )
        raise ValueError("Invalid end date. Must be greater than start date.")

    cal = None
    try:
        dates = pd.date_range(start_date, end_date)
        cal = [
            {
                "date": d.date(),
                "date_time": d,
                "year": d.year,
                "half": (d.quarter + 1) // 2,
                "quarter": d.quarter,
                "month": d.month,
                "day": d.day,
                "week_day": d.weekday(),
                "week_of_year": int(d.strftime("%W")),
                "date_iso": d.isoformat(),
                "date_str": d.strftime("%Y-%m-%d"),
                "week_day_name": d.strftime("%A"),
                "week_day_name_short": d.strftime("%a"),
                "week_month_name": d.strftime("%B"),
                "week_month_name_short": d.strftime("%b"),
                "year_str": d.strftime("%Y"),
                "year_half_str": d.strftime("%Y-H") + str((d.quarter + 1) // 2),
                "year_quarter_str": d.strftime("%Y-Q") + str(d.quarter),
                "year_month_str": d.strftime("%Y-%m"),
            }
            for d in dates
        ]
    except ValueError as e:
        _logger.error(f"Error building calendar: {e}")
        raise e
    _logger.debug("Finished get_calendar successfully.")

    return cal


def add_markers(x: List) -> List:
    """Add temporal markers and business intelligence to calendar data.

    This function enhances a calendar list (typically generated by `get_calendar`)
    with boolean markers and business logic indicators for time-based analysis.
    The markers provide insights for common temporal patterns and business rules.

    The function implements sophisticated logic for determining temporal markers:
    - For dates in the current year: uses precise calendar calculations
    - For past years: determines markers based on the latest available date
      in the input for each temporal period (month, quarter, half)

    The added markers enable efficient filtering and analysis based on temporal
    business rules, such as identifying current periods, end-of-period dates,
    and rolling time windows.

    Parameters
    ----------
    x : List[Dict[str, Any]]
        A calendar list as generated by `get_calendar()`. Each dictionary
        in the list should contain standard calendar attributes including
        date-related fields and temporal formatting strings.

    Returns
    -------
    List[Dict[str, Any]]
        The input calendar list with additional boolean marker fields added
        to each calendar entry:

        - today (bool): True if the date is today's date
        - current_year (bool): True if the date is in the current year
        - last_day_of_month (bool): True if the date is the last day of its month
        - last_day_of_quarter (bool): True if the date is the last day of its quarter
        - last_day_of_half (bool): True if the date is the last day of its half-year
        - last_day_of_year (bool): True if the date is December 31st
        - last_24_months (bool): True if the date is within the last 24 months
        - last_12_months (bool): True if the date is within the last 12 months
        - last_6_months (bool): True if the date is within the last 6 months
        - last_3_months (bool): True if the date is within the last 3 months

    Raises
    ------
    TypeError
        If the input is not a list or if list items are not dictionaries.
    KeyError
        If required calendar attributes are missing from the input data.
    ValueError
        If calendar data contains invalid or inconsistent date information.

    Examples
    --------
    Add markers to a monthly calendar:

    >>> from datetime import date
    >>> from fbpyutils.calendar import get_calendar, add_markers
    >>> cal = get_calendar(date(2023, 1, 1), date(2023, 1, 31))
    >>> marked_cal = add_markers(cal)
    >>> marked_cal[-1]['last_day_of_month']
    True
    >>> marked_cal[0]['current_year']
    False  # Assuming current year is not 2023

    Use markers for filtering:

    >>> from datetime import date
    >>> from fbpyutils.calendar import get_calendar, add_markers
    >>> cal = get_calendar(date(2023, 1, 1), date(2023, 12, 31))
    >>> marked_cal = add_markers(cal)
    >>> quarters_end = [c for c in marked_cal if c['last_day_of_quarter']]
    >>> len(quarters_end)
    4

    Analyze recent periods:

    >>> cal = get_calendar(date(2022, 1, 1), date(2023, 12, 31))
    >>> marked_cal = add_markers(cal)
    >>> recent_12m = [c for c in marked_cal if c['last_12_months']]
    >>> len(recent_12m) <= 366  # Account for leap years
    True

    Notes
    -----
    The function uses the current system date for relative time calculations.
    Rolling window markers (last_3_months, last_6_months, etc.) are calculated
    relative to the current date at the time of execution.

    For large calendar datasets, consider processing in chunks to manage
    memory usage effectively.

    See Also
    --------
    get_calendar : Generate calendar data to be marked
    calendarize : Enrich DataFrame with calendar data including markers

    """
    _logger.debug("Starting add_markers.")
    cal = x
    today = datetime.now().date()

    # For past years, compute group markers from the input
    markers = {}
    markers.update(
        {
            m: max(c["date"] for c in cal if c["year_month_str"] == m)
            for m in set(c["year_month_str"] for c in cal)
        }
    )
    markers.update(
        {
            m: max(c["date"] for c in cal if c["year_quarter_str"] == m)
            for m in set(c["year_quarter_str"] for c in cal)
        }
    )
    markers.update(
        {
            m: max(c["date"] for c in cal if c["year_half_str"] == m)
            for m in set(c["year_half_str"] for c in cal)
        }
    )

    for c in cal:
        d = c["date"]
        if d.year == today.year:
            # Use actual calendar calculations for the current year
            last_day_month = date(
                d.year, d.month, xcalendar.monthrange(d.year, d.month)[1]
            )
            quarter = (d.month - 1) // 3 + 1
            last_month = quarter * 3
            last_day_quarter = date(
                d.year, last_month, xcalendar.monthrange(d.year, last_month)[1]
            )
            if d.month <= 6:
                last_day_half = date(d.year, 6, xcalendar.monthrange(d.year, 6)[1])
            else:
                last_day_half = date(d.year, 12, xcalendar.monthrange(d.year, 12)[1])
        else:
            # Use the markers computed from the input for past years
            last_day_month = markers[c["year_month_str"]]
            last_day_quarter = markers[c["year_quarter_str"]]
            last_day_half = markers[c["year_half_str"]]

        # For last_day_of_year we always use the actual calendar last day
        last_day_year = date(d.year, 12, 31)

        c.update(
            {
                "today": d == today,
                "current_year": d.year == today.year,
                "last_day_of_month": d == last_day_month,
                "last_day_of_quarter": d == last_day_quarter,
                "last_day_of_half": d == last_day_half,
                "last_day_of_year": d == last_day_year,
                "last_24_months": d <= today and dutl.delta(today, d, "months") <= 24,
                "last_12_months": d <= today and dutl.delta(today, d, "months") <= 12,
                "last_6_months": d <= today and dutl.delta(today, d, "months") <= 6,
                "last_3_months": d <= today and dutl.delta(today, d, "months") <= 3,
            }
        )
    _logger.debug("Finished add_markers successfully.")
    return cal


def calendarize(
    x: DataFrame, date_column: str, with_markers: bool = False
) -> DataFrame:
    """Enrich a DataFrame with comprehensive calendar attributes.

    This function enhances a pandas DataFrame by adding a complete set of
    calendar-based columns derived from a specified datetime column. It
    generates a comprehensive calendar dimension and merges it with the
    input DataFrame based on the date column.

    The function automatically determines the date range from the input
    DataFrame's datetime column, generates the complete calendar for that
    range, and merges it with the original data. All new calendar columns
    are prefixed with 'calendar_' to avoid naming conflicts.

    Parameters
    ----------
    x : pandas.DataFrame
        The input DataFrame to be enriched with calendar attributes.
        Must contain a datetime column specified by date_column parameter.
    date_column : str
        The name of the datetime column in the input DataFrame to be used
        for calendar generation and merging. This column must exist in the
        DataFrame and contain datetime data (pandas datetime64 or compatible).
    with_markers : bool, optional
        If True, adds temporal markers and business intelligence indicators
        to the calendar before merging. These markers include flags for
        current periods, end-of-period dates, and rolling time windows.
        If False (default), only basic calendar attributes are added.

    Returns
    -------
    pandas.DataFrame
        A new DataFrame containing all original columns plus the calendar
        attributes. The calendar columns are prefixed with 'calendar_' and
        include all attributes from the generated calendar dimension:

        Basic attributes:
        - calendar_date: Date component of the datetime
        - calendar_date_time: Full datetime with time component
        - calendar_year: Four-digit year
        - calendar_half: Half-year indicator (1 or 2)
        - calendar_quarter: Quarter number (1-4)
        - calendar_month: Month number (1-12)
        - calendar_day: Day of month (1-31)
        - calendar_week_day: Day of week (0=Monday, 6=Sunday)
        - calendar_week_of_year: Week number within year (01-53)
        - calendar_date_iso: ISO format date string (YYYY-MM-DD)
        - calendar_date_str: Formatted date string (YYYY-MM-DD)
        - calendar_week_day_name: Full weekday name
        - calendar_week_day_name_short: Short weekday name
        - calendar_week_month_name: Full month name
        - calendar_week_month_name_short: Short month name
        - calendar_year_str: Year as string
        - calendar_year_half_str: Year and half format
        - calendar_year_quarter_str: Year and quarter format
        - calendar_year_month_str: Year and month format

        Marker attributes (when with_markers=True):
        - calendar_today: Boolean flag for current date
        - calendar_current_year: Boolean flag for current year
        - calendar_last_day_of_month: Boolean flag for month end
        - calendar_last_day_of_quarter: Boolean flag for quarter end
        - calendar_last_day_of_half: Boolean flag for half-year end
        - calendar_last_day_of_year: Boolean flag for year end
        - calendar_last_24_months: Boolean flag for 24-month window
        - calendar_last_12_months: Boolean flag for 12-month window
        - calendar_last_6_months: Boolean flag for 6-month window
        - calendar_last_3_months: Boolean flag for 3-month window

    Raises
    ------
    TypeError
        If the input x is not a pandas DataFrame, or if date_column is not a string.
    NameError
        If the specified date_column does not exist in the DataFrame.
    TypeError
        If the date_column is not a datetime type (pandas datetime64 or compatible).
    ValueError
        If the date_column contains only null values or invalid dates.

    Examples
    --------
    Basic calendar enrichment:

    >>> import pandas as pd
    >>> from fbpyutils.calendar import calendarize
    >>> df = pd.DataFrame({
    ...     'date': pd.date_range('2023-01-01', periods=3),
    ...     'value': [100, 200, 300]
    ... })
    >>> result = calendarize(df, 'date')
    >>> 'calendar_year' in result.columns
    True
    >>> len(result)
    3

    Enrich with temporal markers:

    >>> df = pd.DataFrame({
    ...     'date': pd.date_range('2023-01-01', '2023-12-31', freq='D'),
    ...     'sales': range(365)
    ... })
    >>> result = calendarize(df, 'date', with_markers=True)
    >>> quarter_ends = result[result['calendar_last_day_of_quarter']]
    >>> len(quarter_ends)
    4

    Analyze by calendar attributes:

    >>> df = pd.DataFrame({
    ...     'date': pd.date_range('2023-01-01', periods=12, freq='MS'),
    ...     'revenue': range(100, 1200, 100)
    ... })
    >>> result = calendarize(df, 'date')
    >>> by_quarter = result.groupby('calendar_quarter')['revenue'].sum()

    Notes
    -----
    The function automatically determines the date range from the input
    DataFrame's min and max dates in the specified column.

    All calendar columns are prefixed with 'calendar_' to prevent naming
    conflicts with existing columns in the input DataFrame.

    The function preserves the original DataFrame structure and adds the
    calendar attributes without modifying existing data.

    For large DataFrames with many datetime values, consider filtering
    the date range before calling this function to improve performance.

    See Also
    --------
    get_calendar : Generate calendar data
    add_markers : Add temporal markers to calendar data
    pandas.merge : DataFrame merging operation

    """
    _logger.debug(
        f"Starting calendarize with date_column: {date_column}, with_markers: {with_markers}."
    )
    if not isinstance(x, pd.DataFrame):
        _logger.error(
            f"Invalid object type for calendarize. Expected Pandas DataFrame, got {type(x)}."
        )
        raise TypeError("Invalid object type. Expected Pandas DataFrame.")

    df = x.copy()

    if date_column not in df.columns or not np.issubdtype(
        df[date_column], np.datetime64
    ):
        _logger.error(f"DateTime column not found or invalid: {date_column}.")
        raise NameError(f"DateTime column not found or invalid: {date_column}.")

    mind, maxd = min(df[date_column]), max(df[date_column])

    calendar = get_calendar(mind, maxd)
    if with_markers:
        add_markers(calendar)

    calendar = pd.DataFrame.from_dict(calendar)

    columns = ["_".join(["calendar", c]) for c in calendar.columns]
    calendar.columns = columns
    df[date_column] = df[date_column].dt.date

    _logger.debug("Finished calendarize successfully.")
    return df.merge(calendar, left_on=date_column, right_on="calendar_date")
