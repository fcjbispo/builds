"""
Calendar commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error
from datetime import datetime

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for calendar commands
app = typer.Typer(name="calendar", help="Commands for calendar manipulation.", rich_markup_mode="rich")


@app.command("get-range")
def get_range(
    start_date: str = typer.Option(..., "--start-date", help="Start date (YYYY-MM-DD)."),
    end_date: str = typer.Option(..., "--end-date", help="End date (YYYY-MM-DD)."),
    add_markers: bool = typer.Option(False, "--add-markers", help="Add temporal markers to the calendar."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Build a calendar based on a date range."""
    try:
        logger.info(f"Generating calendar from {start_date} to {end_date}")

        # Parse dates
        start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()

        # Import the calendar function
        from fbpyutils.calendar import get_calendar

        # Generate calendar
        result = get_calendar(start_dt, end_dt)

        # Add markers if requested
        if add_markers:
            from fbpyutils.calendar import add_markers

            result = add_markers(result)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Calendar generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate calendar")
