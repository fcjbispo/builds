"""
File commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for file commands
app = typer.Typer(name="file", help="Commands for file manipulation.", rich_markup_mode="rich")


@app.command("find")
def find_files(
    path: str = typer.Option(..., "--path", help="Source folder to find files from."),
    mask: str = typer.Argument(..., help="File mask(s) to search for."),
    recurse: bool = typer.Option(False, "--recurse", help="Search recursively in subdirectories."),
    parallel: bool = typer.Option(False, "--parallel", help="Use parallel search if recurse is enabled."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Find files in a source folder using a specific mask."""
    try:
        if not mask:
            mask = ["*.*"]
        logger.info(f"Finding files in {path} with mask {mask}")

        from fbpyutils.file import find

        result = find(path, mask, recurse, parallel)

        if output_format == "txt":
            for file_path in result:
                typer.echo(file_path)
        else:
            formatted_result = format_output(result, output_format)
            typer.echo(formatted_result)

        logger.debug(f"Found {len(result)} files")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to find files")


@app.command("read-bytes")
def read_bytes(
    path: str = typer.Option(..., "--path", help="Path of the file to read."),
):
    """Read a file and return its contents as bytes."""
    try:
        logger.info(f"Reading bytes from {path}")

        from fbpyutils.file import contents

        result = contents(path)

        # Output as binary data
        typer.echo(result, nl=False)

        logger.debug(f"Read {len(result)} bytes from {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read file bytes")


@app.command("mime-type")
def get_mime_type(
    path: str = typer.Option(..., "--path", help="Path of the file to get MIME type."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Guess the MIME type of a file."""
    try:
        logger.info(f"Getting MIME type for {path}")

        from fbpyutils.file import mime_type

        result = mime_type(path)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"MIME type for {path}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get MIME type")


@app.command("describe")
def describe_file(
    path: str = typer.Option(..., "--path", help="Path of the file to describe."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Describe a file, returning its properties."""
    try:
        logger.info(f"Describing file {path}")

        from fbpyutils.file import describe_file

        result = describe_file(path)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Described file {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to describe file")


@app.command("to-base64")
def to_base64(
    uri: str = typer.Option(..., "--uri", help="URI of the file to process."),
    timeout: int = typer.Option(300, "--timeout", help="Timeout for URL requests."),
):
    """Retrieve data from a URI and return as base64 string."""
    try:
        logger.info(f"Converting {uri} to base64")

        from fbpyutils.file import get_base64_data_from

        result = get_base64_data_from(uri, timeout)

        typer.echo(result)

        logger.debug(f"Converted {uri} to base64")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to convert to base64")
