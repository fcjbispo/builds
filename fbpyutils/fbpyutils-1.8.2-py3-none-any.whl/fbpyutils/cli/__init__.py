"""
CLI module for fbpyutils.
"""

from .main import app


__all__ = ["app"]
