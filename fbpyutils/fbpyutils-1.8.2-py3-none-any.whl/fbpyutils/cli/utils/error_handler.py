"""
Error handling utilities for the fbpyutils CLI.
"""

import click
import fbpyutils
from typing import Optional

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


def handle_error(error: Exception, message: Optional[str] = None) -> None:
    """
    Handle errors in a consistent way across the CLI.

    Args:
        error: The exception that occurred.
        message: Optional custom message to display.
    """

    if message:
        logger.error(f"{message}: {str(error)}")
        click.echo(f"Error: {message}", err=True)
    else:
        logger.error(f"Error occurred: {str(error)}")
        click.echo(f"Error: {str(error)}", err=True)
