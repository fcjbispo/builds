"""
Documentation Generation and Extraction Utilities

This module provides comprehensive utilities for extracting and generating documentation
from Python modules, transforming source code into structured Markdown format suitable
for API documentation, developer guides, and automated documentation systems.

The module offers two primary capabilities:

* **Documentation Extraction**: Extract docstrings, function signatures, and class methods
  from Python source files using AST parsing and introspection techniques.

* **Documentation Generation**: Generate complete Markdown documentation for entire
  module hierarchies with proper formatting, structure, and cross-referencing.

Key Features:
-------------
* **AST-Based Parsing**: Uses Python's inspect module for reliable source code analysis
* **Comprehensive Coverage**: Extracts module docstrings, function signatures, class methods,
  and their documentation in order of appearance
* **Error Handling**: Graceful degradation when modules cannot be loaded or parsed
* **Structured Output**: Generates well-formatted Markdown with proper code blocks
* **Configurable Generation**: Supports filtering, directory traversal, and custom output paths

Dependencies:
-------------
* `inspect`: Python's built-in introspection module for source code analysis
* `importlib.util`: Dynamic module loading and specification handling
* `os`, `re`: File system operations and regular expression processing
* `fbpyutils.file`: File finding and path utilities from the fbpyutils package
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Extract documentation from a single module:

>>> from fbpyutils.doc import extract_doc_and_signature
>>> doc = extract_doc_and_signature('fbpyutils/calendar.py', 'fbpyutils.calendar')
>>> print(doc[:500])  # Print first 500 characters
# Module calendar
```
Module providing utility functions for calendar manipulation...
```
## Function: get_calendar
```
get_calendar(x: date, y: date) -> List
```

Generate documentation for entire module hierarchy:

>>> from fbpyutils.doc import generate_module_docs
>>> generate_module_docs('docs/', source_dir='fbpyutils/')
# Processes 12 modules and generates documentation files

Generate documentation excluding __init__.py files:

>>> generate_module_docs('docs/', exclude_init=True, source_dir='fbpyutils/')
# Skips initialization files during processing

Notes:
------
* Generated documentation preserves original docstring formatting using inspect.cleandoc()
* Function and class ordering maintains source code appearance order
* Method documentation includes constructor handling with self parameter removal
* Error scenarios log detailed information while returning fallback error messages
* Supports Python 3.11+ with full type hint compatibility

Cross-References:
-----------------
* See `fbpyutils.logging` for documentation generation logging configuration
* See `fbpyutils.file` for file finding utilities used in batch processing
* See `fbpyutils.setup()` for proper initialization requirements
"""

import inspect
import importlib.util
import os
import re

import fbpyutils
from fbpyutils import get_logger, file as FU, _ROOT_DIR


fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()


def extract_doc_and_signature(filepath: str, module_name: str) -> str:
    """Extract comprehensive documentation and signatures from a Python source file.

    This function performs deep source code analysis to extract all documentation elements
    from a Python module, including module-level docstrings, function signatures with type
    hints, class definitions with their methods, and individual method documentation.
    The extracted content is formatted into structured Markdown suitable for API documentation
    generation and developer reference materials.

    The extraction process follows Python source code order to maintain logical flow and
    reading sequence. It handles complex scenarios including nested classes, static methods,
    class constructors, and edge cases like modules that fail to load or have missing
    documentation.

    Parameters
    ----------
    filepath : str
        Absolute or relative path to the Python source file to analyze. The file must
        contain valid Python syntax and be accessible for reading. Path resolution
        follows standard os.path conventions with UTF-8 encoding support.
        
        Example paths:
        - 'fbpyutils/calendar.py' (relative to current working directory)
        - '/path/to/project/fbpyutils/calendar.py' (absolute path)
        - './modules/string.py' (relative with directory specification)

    module_name : str
        Fully qualified Python module name corresponding to the source file. This should
        match the module structure for proper introspection and import resolution.
        Used for module validation and qualified name generation in the output.
        
        Example module names:
        - 'fbpyutils.calendar' (package.module format)
        - 'mypackage.utils' (nested package structure)
        - 'standalone_module' (single file module without package)

    Returns
    -------
    str
        Complete Markdown-formatted documentation string containing:
        
        * Module header with name and docstring
        * Function documentation sections with signatures and docstrings
        * Class documentation sections with constructor and method details
        * Proper code block formatting with python syntax highlighting
        * Error messages in structured format if processing fails
        
        The returned string follows this structure:
        ```
        # Module {module_name}
        ```python
        {module_docstring}
        ```
        
        ## Function: {function_name}
        ```python
        {function_signature}
        ```
        ```
        {function_docstring}
        ```
        
        ## Class: {class_name}
        ```python
        {class_docstring}
        ```
        ### Methods
        
        #### Constructor: {ClassName}({constructor_signature})
        ```
        {constructor_docstring}
        ```
        
        #### Method: {method_name}
        ```python
        {method_signature}
        ```
        ```
        {method_docstring}
        ```
        ```

    Raises
    ------
    FileNotFoundError
        When the specified filepath does not exist or cannot be accessed due to
        permissions or path resolution issues.
        
    UnicodeDecodeError
        When the source file contains invalid UTF-8 encoding or character
        sequences that cannot be decoded.
        
    SyntaxError
        When the Python source file contains syntax errors that prevent
        module loading, though the function provides graceful error handling
        and returns formatted error messages rather than raising exceptions.

    Examples
    --------
    Extract documentation from a calendar module:

    >>> from fbpyutils.doc import extract_doc_and_signature
    >>> doc = extract_doc_and_signature('fbpyutils/calendar.py', 'fbpyutils.calendar')
    >>> print(doc[:300])
    # Module calendar
    ```
    Module providing utility functions for calendar manipulation...
    ```
    ## Function: get_calendar
    ```
    get_calendar(x: date, y: date) -> List[Dict[str, Any]]
    ```
    ```
    Builds a calendar to be used as a time dimension table...
    ```

    Extract documentation from a module with classes and methods:

    >>> doc = extract_doc_and_signature('fbpyutils/string.py', 'fbpyutils.string')
    >>> print(doc[:500])
    # Module string
    ```
    String manipulation utilities with comprehensive text processing...
    ```
    ## Class: StringProcessor
    ```python
    String processing class with multiple text manipulation methods...
    ```
    ### Methods
    #### Constructor: StringProcessor(encoding: str = 'utf-8')
    ```
    Initialize string processor with specified encoding...
    ```
    #### Method: clean_text
    ```python
    clean_text(text: str) -> str
    ```
    ```
    Clean and normalize input text by removing extra whitespace...
    ```

    Handle module loading errors gracefully:

    >>> doc = extract_doc_and_signature('nonexistent.py', 'nonexistent')
    >>> print(doc)
    # Error Documenting nonexistent

    Could not load module: No such file or directory: 'nonexistent.py'

    Generate documentation for multiple modules in a batch:

    >>> modules = ['calendar.py', 'datetime.py', 'string.py']
    >>> for module_file in modules:
    ...     filepath = f'fbpyutils/{module_file}'
    ...     module_name = f'fbpyutils.{module_file[:-3]}'
    ...     doc = extract_doc_and_signature(filepath, module_name)
    ...     print(f"Generated {len(doc)} characters for {module_name}")

    Notes
    -----
    * The function maintains source code appearance order for functions and classes
    * Module loading uses importlib.util for dynamic module creation and execution
    * Signature extraction handles complex scenarios including overloaded methods
    * Constructor signatures automatically remove 'self' parameter for cleaner display
    * Missing docstrings are noted with warning logs and placeholder text in output
    * Error scenarios provide detailed logging while returning structured error messages
    * UTF-8 encoding is assumed for all source files with explicit encoding specification

    Performance Considerations
    --------------------------
    * File reading and parsing operations scale with source file size
    * Module loading and introspection may be expensive for large modules
    * Memory usage correlates with documentation content size in returned string
    * Consider caching results for repeated extraction from the same modules

    See Also
    --------
    generate_module_docs : Batch generate documentation for multiple modules
    inspect.signature : Function signature extraction used internally
    importlib.util : Module loading utilities for dynamic import handling
    """
    _logger.debug(
        f"Starting extract_doc_and_signature for module: {module_name} at {filepath}"
    )
    spec = importlib.util.spec_from_file_location(module_name, filepath)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        _logger.info(f"Module {module_name} loaded successfully.")
    except Exception as e:
        _logger.error(f"Could not load module {module_name}: {e}")
        return f"# Error Documenting {module_name}\n\nCould not load module: {e}\n"

    doc_content = []

    doc_content.append(f"# Module {module_name.lower()}\n")
    if module.__doc__:
        doc_content.append(f"```python\n{inspect.cleandoc(module.__doc__)}\n```\n")
        _logger.debug(f"Module docstring found for {module_name}.")
    else:
        doc_content.append("No module docstring found.\n")
        _logger.warning(f"No module docstring found for {module_name}.")

    # Organize functions and classes by their appearance in the file
    items_in_order = []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            file_lines = f.readlines()
    except Exception as e:
        _logger.error(f"Could not read file {filepath}: {e}")
        return f"# Error Documenting {module_name}\n\nCould not read file: {e}\n"

    def get_line_number(obj):
        if hasattr(obj, "__code__"):
            return obj.__code__.co_firstlineno
        if hasattr(obj, "__dict__"):
            init_method = getattr(obj, "__init__", None)
            if init_method and hasattr(init_method, "__code__"):
                return init_method.__code__.co_firstlineno
            try:
                for i, line in enumerate(file_lines):
                    if re.match(rf"^\s*class\s+{obj.__name__}\s*:", line):
                        return i + 1
            except Exception:
                pass
        return float("inf")

    for name, obj in inspect.getmembers(module):
        if inspect.isfunction(obj) and obj.__module__ == module_name:
            items_in_order.append(("function", name, obj, get_line_number(obj)))
        elif (
            inspect.isclass(obj)
            and obj.__module__ == module_name
            and obj.__name__ == name
        ):
            items_in_order.append(("class", name, obj, get_line_number(obj)))

    items_in_order.sort(key=lambda x: x[3])

    for item_type, name, obj, _ in items_in_order:
        if item_type == "function":
            _logger.debug(f"Documenting function: {name}")
            doc_content.append(f"## Function: {name}\n")
            doc_content.append(f"```python\n{name}{inspect.signature(obj)}\n```\n")
            if obj.__doc__:
                doc_content.append(f"```\n{inspect.cleandoc(obj.__doc__)}\n```\n")
            else:
                doc_content.append("No docstring found for this function.\n")
                _logger.warning(f"No docstring found for function: {name}")
            doc_content.append("\n")

        elif item_type == "class":
            _logger.debug(f"Documenting class: {name}")
            if (
                inspect.isclass(obj)
                and obj.__module__ == module_name
                and obj.__name__ == name
            ):
                doc_content.append(f"## Class: {name}\n")
                if obj.__doc__:
                    doc_content.append(
                        f"```python\n{inspect.cleandoc(obj.__doc__)}\n```\n"
                    )
                    _logger.debug(f"Class docstring found for {name}.")
                else:
                    doc_content.append("No docstring found for this class.\n")
                    _logger.warning(f"No docstring found for class: {name}")
                doc_content.append("\n### Methods\n")

                class_methods_in_order = []
                for method_name, method_obj in inspect.getmembers(
                    obj, inspect.isfunction
                ):
                    if method_name.startswith("__") and method_name != "__init__":
                        continue
                    if hasattr(method_obj, "__func__") and hasattr(
                        method_obj.__func__, "__code__"
                    ):
                        class_methods_in_order.append(
                            (
                                method_name,
                                method_obj,
                                method_obj.__func__.__code__.co_firstlineno,
                            )
                        )

                class_methods_in_order.sort(key=lambda x: x[2])

                for method_name, method_obj, _ in class_methods_in_order:
                    _logger.debug(f"Documenting method: {name}.{method_name}")
                    if method_name == "__init__":
                        signature_str = (
                            str(inspect.signature(method_obj)).replace("self, ", "", 1)
                            if "self" in str(inspect.signature(method_obj))
                            else str(inspect.signature(method_obj))
                        )
                        doc_content.append(f"#### Constructor: {name}{signature_str}\n")
                    else:
                        doc_content.append(f"#### Method: {method_name}\n")

                    try:
                        if (
                            inspect.ismethod(method_obj)
                            and method_obj.__self__ is not None
                        ):
                            signature_to_display = inspect.signature(method_obj)
                        elif (
                            inspect.isfunction(method_obj)
                            and "self" in str(inspect.signature(method_obj))
                            and getattr(obj, method_name).__qualname__.startswith(name)
                        ):
                            sig_parts = str(inspect.signature(method_obj)).split(",")
                            if sig_parts and sig_parts[0].strip() == "(self":
                                signature_to_display = (
                                    f"({', '.join(sig_parts[1:])}".replace("))", ")")
                                    if len(sig_parts) > 1
                                    else "()"
                                )
                            else:
                                signature_to_display = inspect.signature(method_obj)
                        else:
                            signature_to_display = inspect.signature(method_obj)

                        if isinstance(signature_to_display, str):
                            doc_content.append(
                                f"```python\n{method_name}{signature_to_display}\n```\n"
                            )
                        else:
                            doc_content.append(
                                f"```python\n{method_name}{str(signature_to_display)}\n```\n"
                            )
                    except ValueError:
                        _logger.warning(
                            f"Could not get signature for {name}.{method_name}. Using fallback."
                        )
                        doc_content.append(
                            f"```python\n{method_name}(\\*args, \\*\\*kwargs)\n```\n"
                        )

                    if method_obj.__doc__:
                        doc_content.append(
                            f"```\n{inspect.cleandoc(method_obj.__doc__)}\n```\n"
                        )
                        _logger.debug(
                            f"Method docstring found for {name}.{method_name}."
                        )
                    else:
                        doc_content.append("No docstring found for this method.\n")
                        _logger.warning(
                            f"No docstring found for method: {name}.{method_name}"
                        )
                    doc_content.append("\n")

    return "\n".join(doc_content)


# %%
def generate_module_docs(
    output_dir: str, exclude_init: bool = False, source_dir: str = None
):
    """Generate comprehensive Markdown documentation for all Python modules in a directory tree.

    This function performs batch documentation generation by traversing a source directory,
    discovering all Python modules, and applying the extract_doc_and_signature process to
    each module. The resulting documentation is saved as individual Markdown files with
    organized structure suitable for API documentation, developer guides, or project
    documentation websites.

    The generation process includes automatic directory creation, file discovery using
    fbpyutils.file utilities, module name resolution for proper namespace handling,
    and comprehensive error logging for troubleshooting. The function supports filtering
    out initialization files and handles both package-based and standalone module structures.

    Parameters
    ----------
    output_dir : str
        Target directory path where generated Markdown documentation files will be saved.
        The directory will be created automatically if it doesn't exist using os.makedirs().
        Files are saved with naming pattern `{module_name}.md` where module names use
        dot notation for package hierarchy.
        
        Example output directories:
        - 'docs/api/' (creates API documentation directory)
        - './documentation' (relative path from current working directory)
        - '/tmp/project_docs' (absolute path for temporary documentation)
        
    exclude_init : bool, optional
        Boolean flag controlling whether '__init__.py' files should be excluded from
        documentation generation. When True, package initialization files are skipped.
        This is useful for generating documentation focused on actual implementation
        modules rather than package structure files.
        
        Default: False (include all Python files including __init__.py)
        
        Examples:
        - exclude_init=False: Generates docs/__init__.md for package initialization
        - exclude_init=True: Skips __init__.py files during traversal

    source_dir : str, optional
        Root directory path containing the Python source modules to document. If None,
        defaults to the fbpyutils._ROOT_DIR configuration value. The function searches
        recursively for all .py files within this directory tree.
        
        Default: None (uses _ROOT_DIR from fbpyutils configuration)
        
        Example source directories:
        - 'fbpyutils/' (package root directory)
        - '/path/to/myproject/src' (external project source directory)
        - './modules' (relative directory containing module files)

    Returns
    -------
    None
        The function operates through side effects, creating files in the output directory
        and logging operations. No direct return value is provided.

    Raises
    ------
    OSError
        When the source directory does not exist, cannot be accessed, or lacks read
        permissions for file discovery operations.
        
    PermissionError
        When write permissions are insufficient for creating the output directory
        or writing documentation files.
        
    FileNotFoundError
        When the specified source directory path resolves to a non-existent location.

    Examples
    --------
    Generate documentation for all modules in the fbpyutils package:

    >>> from fbpyutils.doc import generate_module_docs
    >>> generate_module_docs('docs/', source_dir='fbpyutils/')
    # Output:
    # Processing module: fbpyutils.calendar (fbpyutils/calendar.py)
    # Documentation saved to docs/fbpyutils.calendar.md
    # Processing module: fbpyutils.datetime (fbpyutils/datetime.py)
    # Documentation saved to docs/fbpyutils.datetime.md
    # ... (continues for all 12 modules)

    Generate documentation excluding initialization files:

    >>> generate_module_docs('api_docs/', exclude_init=True, source_dir='fbpyutils/')
    # Skips __init__.py files, processes only implementation modules
    # Creates files: api_docs/calendar.md, api_docs/datetime.md, etc.

    Generate documentation with custom source directory:

    >>> generate_module_docs('myproject_docs/', source_dir='/path/to/myproject/src/')
    # Processes all Python modules in the specified source directory
    # Creates properly named documentation files in output directory

    Generate documentation using default source directory:

    >>> generate_module_docs('documentation/')
    # Uses fbpyutils._ROOT_DIR as source directory
    # Processes all Python files in the configured root directory

    Notes
    -----
    * File discovery uses fbpyutils.file.find() with '*.py' mask pattern
    * Module name resolution handles both package and standalone module structures
    * __init__.py files receive special handling with module name simplification
    * Each module is processed independently with individual error handling
    * Generated files use UTF-8 encoding with explicit encoding specification
    * Logging provides detailed progress information and error reporting
    * Directory creation is idempotent and handles existing output directories gracefully

    File Naming Convention
    ----------------------
    Generated documentation files follow these naming rules:
    
    * Package modules: `{package}.{module}.md` (e.g., `fbpyutils.calendar.md`)
    * Standalone modules: `{module}.md` (e.g., `string.md`)
    * __init__.py files (when included): `{package}.md` (e.g., `fbpyutils.md`)
    
    Error Handling
    --------------
    * Individual module processing failures are logged but don't stop batch generation
    * Module loading errors result in error documentation files with detailed messages
    * File system errors are reported through logging infrastructure
    * Each module is processed independently to prevent cascade failures

    Performance Considerations
    --------------------------
    * Processing time scales with number of modules and complexity of each module
    * Large modules with extensive documentation will take proportionally longer
    * File I/O operations dominate performance for module discovery and file writing
    * Consider running during off-peak hours for large codebases
    * Memory usage primarily depends on largest single module documentation size

    See Also
    --------
    extract_doc_and_signature : Core documentation extraction function used for each module
    fbpyutils.file.find : File discovery utility used for module traversal
    fbpyutils.logging : Logging infrastructure for operation tracking and error reporting
    """
    _logger.info(
        f"Starting documentation generation from {source_dir} to {output_dir}."
    )
    if source_dir is None:
        source_dir = _ROOT_DIR  # Assuming that _ROOT_DIR is defined in the context

    os.makedirs(output_dir, exist_ok=True)
    for filename in FU.find(source_dir, mask="*.py"):
        if filename.endswith(".py"):
            module = os.path.basename(os.path.dirname(filename))
            module_name = os.path.splitext(filename)[0].split(os.sep)[-1]
            if exclude_init and module_name == "__init__":
                continue
            elif module_name == "__init__":
                module_name = module
            else:
                module_name = f"{module}.{module_name}" if module else module_name

            filepath = os.path.join(source_dir, filename)
            output_filepath = os.path.join(output_dir, f"{module_name}.md")

            _logger.info(f"Processing module: {module_name} ({filepath})")
            documentation = extract_doc_and_signature(filepath, module_name)
            with open(output_filepath, "w", encoding="utf-8") as f:
                f.write(documentation)
            _logger.info(f"Documentation saved to {output_filepath}")
