"""
CLI module for fbpyutils.
"""

from .main import cli


__all__ = ["cli"]
