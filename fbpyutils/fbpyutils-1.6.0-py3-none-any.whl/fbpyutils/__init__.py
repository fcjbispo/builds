'''
    Francisco Bispo's Utilities for Python
'''