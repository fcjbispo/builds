"""
Module providing configuration management for the application environment using Pydantic models
for validation and a singleton Env class for global access to configuration settings.
"""

import os
import json
from typing import Dict, Any, Optional

from pydantic import BaseModel, Field


class AppConfig(BaseModel):
    """Pydantic model for application configuration."""

    name: str = Field("fbpyutils", description="Application name")
    version: str = Field("1.6.10", description="Application version")
    environment: str = Field("dev", description="Environment (dev, prod, etc.)")
    appcode: str = Field("FBPYUTILS", description="Application code identifier")
    year: int = Field(2025, description="Base year for the application")

    class Config:
        """Pydantic configuration for AppConfig."""

        extra = "forbid"  # Disallow extra fields


class LoggingConfig(BaseModel):
    """Pydantic model for logging configuration."""

    log_level: str = Field(
        "INFO", alias="log_level", description="Logging level (DEBUG, INFO, etc.)"
    )
    log_format: str = Field(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Log message format",
    )
    log_file_path: Optional[str] = Field(None, description="Path to log file")
    log_text_size: int = Field(256, description="Maximum log text size")
    log_handlers: Optional[list] = Field(
        default_factory=lambda: ["file"], description="List of log handlers"
    )

    class Config:
        """Pydantic configuration for LoggingConfig."""

        extra = "forbid"  # Disallow extra fields


class RootConfig(BaseModel):
    """Pydantic model for root configuration combining app and logging configs."""

    app: AppConfig = Field(
        default_factory=AppConfig, description="Application configuration"
    )
    logging: LoggingConfig = Field(
        default_factory=LoggingConfig, description="Logging configuration"
    )
    config: Dict[str, Any] = Field(
        default_factory=dict, description="Additional configuration dictionary"
    )

    class Config:
        """Pydantic configuration for RootConfig."""

        extra = "forbid"  # Disallow extra fields


class Env:
    """Singleton configuration class for the application environment.

    Manages global configuration settings, loads from JSON files or dictionaries,
    and provides access to app and logging configurations. Immutable after initialization.

    Example:
        >>> from fbpyutils.env import Env
        >>> env = Env()
        >>> env.APP.name
        'fbpyutils'
        >>> env.LOG_LEVEL
        'INFO'
    """

    _instance: Optional["Env"] = None

    APP: AppConfig
    USER_FOLDER: str
    USER_APP_FOLDER: str
    LOG_LEVEL: str
    LOG_FORMAT: str
    LOG_FILE: str
    LOG_TEXT_SIZE: int
    LOG_HANDLERS: Optional[list] = None
    CONFIG: Dict[str, Any]

    def __new__(cls, config: Optional[Dict[str, Any]] = None):
        if cls._instance is None:
            instance = super().__new__(cls)
            cls._instance = instance
            instance._initialize(config)
        return cls._instance

    def _initialize(self, config: Optional[Dict[str, Any]] = None):
        """Initializes the Env instance attributes."""
        if hasattr(self, "_initialized") and self._initialized:
            return

        if config is None:
            # If no config is provided, load from the default app.json
            current_dir = os.path.dirname(__file__)
            default_config_path = os.path.join(current_dir, "app.json")
            try:
                with open(default_config_path, "r", encoding="utf-8") as f:
                    config_data = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                config_data = {}
        else:
            config_data = config

        # Validate and parse the configuration using Pydantic models
        parsed_config = RootConfig.model_validate(config_data)

        self.APP = parsed_config.app
        self.USER_FOLDER = os.path.expanduser("~")
        self.USER_APP_FOLDER = os.path.join(
            self.USER_FOLDER, f".{self.APP.name.lower()}"
        )

        # Configure logging properties with precedence: environment variable -> config file -> default
        self.LOG_LEVEL = os.getenv("FBPY_LOG_LEVEL", parsed_config.logging.log_level)
        self.LOG_FORMAT = parsed_config.logging.log_format
        self.LOG_TEXT_SIZE = int(
            os.getenv("FBPY_LOG_TEXT_SIZE", parsed_config.logging.log_text_size)
        )

        log_file_from_config = parsed_config.logging.log_file_path
        if log_file_from_config:
            self.LOG_FILE = log_file_from_config
        else:
            default_log_path = os.getenv("FBPY_LOG_PATH", self.USER_APP_FOLDER)
            self.LOG_FILE = os.path.join(default_log_path, "fbpyutils.log")

        self.LOG_HANDLERS = parsed_config.logging.log_handlers

        # Set the configuration dictionary
        self.CONFIG = parsed_config.config

        # Ensure USER_APP_FOLDER exists
        if not os.path.exists(self.USER_APP_FOLDER):
            os.makedirs(self.USER_APP_FOLDER)

        self._initialized = True

    @classmethod
    def load_config_from(cls, app_conf_file: str) -> "Env":
        """Loads configuration from a specified JSON file and returns a configured Env instance.

        Resets the singleton and creates a new instance with the loaded configuration.

        Args:
            app_conf_file (str): Path to the JSON configuration file.

        Returns:
            Env: The configured Env singleton instance.

        Raises:
            FileNotFoundError: If the configuration file does not exist.
            json.JSONDecodeError: If the file is not valid JSON.

        Example:
            >>> from fbpyutils.env import Env
            >>> env = Env.load_config_from('custom_config.json')
            # Loads config from custom_config.json and returns Env instance.
            >>> env.APP.name  # Uses value from custom_config.json
            'MyApp'
        """
        try:
            with open(app_conf_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            cls._instance = None  # Reset singleton to allow re-initialization
            return cls(config=config)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Configuration file '{app_conf_file}' not found. Cannot create Env instance."
            )
        except json.JSONDecodeError:
            raise json.JSONDecodeError(f"Error decoding JSON from '{app_conf_file}'.")
