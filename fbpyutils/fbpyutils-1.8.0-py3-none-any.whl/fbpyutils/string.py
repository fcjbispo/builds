"""
Module providing utility functions for string manipulation, including UUID generation,
similarity calculation, random string creation, JSON conversion, hashing, normalization,
and splitting.
"""

import random
import string
import hashlib
import json
import time
import warnings
from threading import Lock

from difflib import SequenceMatcher

import uuid as u

from typing import Dict, List, Optional

import fbpyutils

from fbpyutils.uuid import (
    uuid as _uuid_new,
    hash_string as _hash_string_new,
    hash_json as _hash_json_new,
    SnowflakeIDGenerator as _SnowflakeIDGeneratorNew,
    snowflake_id as _snowflake_id_new
)


from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

_SPECIAL_CHARS = "".join([c + c.upper() for c in "áãâäàéèëêíìîïóòõôöúùûüçñ"])

_NORMALIZED_CHARS = "".join([c + c.upper() for c in "aaaaaeeeeiiiiooooouuuucn"])

_TRANSLATION_TAB = {}
for i in range(len(_SPECIAL_CHARS)):
    _TRANSLATION_TAB[ord(_SPECIAL_CHARS[i])] = _NORMALIZED_CHARS[i]


def uuid() -> str:  # pragma: no cover
    """Generates a random UUID4 string.

    DEPRECATED: Use fbpyutils.uuid.uuid() instead. This function will be removed in v1.8.5.

    Uses uuid.uuid4() for cryptographically secure random UUID.

    Returns:
        str: UUID string like '123e4567-e89b-12d3-a456-426614174000'.

    Example:
        >>> from fbpyutils.string import uuid
        >>> uid = uuid()
        >>> len(uid)
        36
        >>> uid
        '123e4567-e89b-12d3-a456-426614174000'
    """
    warnings.warn(
        "string.uuid() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.uuid() instead.",
        DeprecationWarning,
        stacklevel=2
    )
    return _uuid_new()


def similarity(
    x: str, y: str, ignore_case: bool = True, compress_spaces: bool = True
) -> float:
    """Calculates similarity ratio between two strings using SequenceMatcher.

    Options to ignore case and compress multiple spaces. Ratio 1.0 = identical, 0.0 = no similarity.

    Args:
        x (str): First string.
        y (str): Second string.
        ignore_case (bool): Ignore case differences. Defaults to True.
        compress_spaces (bool): Replace multiple spaces with single. Defaults to True.

    Returns:
        float: Similarity ratio (0.0 to 1.0).

    Example:
        >>> from fbpyutils.string import similarity
        >>> similarity('Hello World', 'Hello world')
        0.8
        >>> similarity('Hello World', 'Hi there', ignore_case=False)
        0.0
        >>> similarity('A  B  C', 'A B C', compress_spaces=True)
        1.0
    """
    _logger.debug(
        f"Calculating similarity between '{x}' and '{y}' (ignore_case: {ignore_case}, compress_spaces: {compress_spaces})"
    )

    def compress(z: str) -> str:
        original_z = z
        while "  " in z:
            z = z.replace("  ", " ")
        if original_z != z:
            _logger.debug(f"Compressed spaces: '{original_z}' -> '{z}'")
        return z

    if ignore_case:
        x = x.lower()
        y = y.lower()
        _logger.debug(f"Strings after lowercasing: x='{x}', y='{y}'")

    if compress_spaces:
        x = compress(x)
        y = compress(y)

    ratio = SequenceMatcher(None, x, y).ratio()
    _logger.debug(f"Similarity ratio: {ratio}")
    return ratio


def random_string(
    x: int = 32, include_digits: bool = True, include_special: bool = False
) -> str:
    """Generates a random string of specified length using letters, digits, special chars.

    Uses random.choice from ascii_letters + optional digits + special.

    Args:
        x (int): Length of string. Defaults to 32.
        include_digits (bool): Include digits 0-9. Defaults to True.
        include_special (bool): Include !@#$%^&*_. Defaults to False.

    Returns:
        str: Random string.

    Example:
        >>> from fbpyutils.string import random_string
        >>> rand = random_string(10, include_digits=True, include_special=False)
        >>> len(rand)
        10
        >>> rand.isalpha()
        True
        >>> rand_special = random_string(5, include_special=True)
        >>> '!' in rand_special or '@' in rand_special
        True
    """
    _logger.debug(
        f"Generating random string of length {x} (include_digits: {include_digits}, include_special: {include_special})"
    )
    letters = (
        string.ascii_letters
        + (string.digits if include_digits else "")
        + ("!@#$%^&*_" if include_special else "")
    )

    if not letters:
        _logger.warning(
            "No character set selected for random string generation. Returning empty string."
        )
        return ""

    generated_string = "".join(random.choice(letters) for i in range(x))
    _logger.debug(f"Generated random string (first 5 chars): {generated_string[:5]}...")
    return generated_string


def json_string(x: Dict) -> str:
    """Converts a dictionary to a JSON string, handling non-serializable types by stringifying.

    Ensures UTF-8 encoding and decoding.

    Args:
        x (Dict): Dictionary to convert.

    Returns:
        str: JSON string representation.

    Raises:
        TypeError: If conversion fails due to unhandled types.
        Exception: Other JSON encoding errors.

    Example:
        >>> from fbpyutils.string import json_string
        >>> data = {'name': 'Alice', 'age': 30, 'obj': object()}
        >>> js = json_string(data)
        >>> js
        '{"name": "Alice", "age": 30, "obj": "<object object at 0x...>"}'
        >>> import json
        >>> json.loads(js)['name']
        'Alice'
    """
    _logger.debug("Converting dictionary to JSON string.")
    _default = lambda obj: str(obj)  # Stringify non-serializable
    try:
        s = json.dumps(x, default=_default, ensure_ascii=False).encode("utf8")
        decoded_string = s.decode()
        _logger.debug("Successfully converted dictionary to JSON string.")
        return decoded_string
    except TypeError as e:
        _logger.error(f"TypeError during JSON string conversion: {e}. Input: {x}")
        raise
    except Exception as e:
        _logger.error(
            f"An unexpected error occurred during JSON string conversion: {e}. Input: {x}"
        )
        raise


def hash_string(x: str) -> str:  # pragma: no cover
    """Generates MD5 hash of a string, encoding as UTF-8.

    DEPRECATED: Use fbpyutils.uuid.hash_string() instead. This function will be removed in v1.8.5.

    Args:
        x (str): Input string.

    Returns:
        str: 32-character hexadecimal MD5 hash.

    Example:
        >>> from fbpyutils.string import hash_string
        >>> hash_string('Hello World')
        '5d41402abc4b2b76b0b6f0c1a6c9c9c9'  # Example hash
        >>> len(hash_string('test'))
        32
    """
    warnings.warn(
        "string.hash_string() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.hash_string() instead.",
        DeprecationWarning,
        stacklevel=2
    )
    return _hash_string_new(x)


def hash_json(x: Dict) -> str:  # pragma: no cover
    """Generates MD5 hash of a dictionary by converting to JSON string first.

    DEPRECATED: Use fbpyutils.uuid.hash_json() instead. This function will be removed in v1.8.5.

    Args:
        x (Dict): Dictionary to hash.

    Returns:
        str: MD5 hex digest of JSON string.

    Example:
        >>> from fbpyutils.string import hash_json
        >>> data = {'key': 'value', 'num': 42}
        >>> hash_json(data)
        'a1b2c3d4e5f6...'  # Example hash
    """
    warnings.warn(
        "string.hash_json() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.hash_json() instead.",
        DeprecationWarning,
        stacklevel=2
    )
    return _hash_json_new(x)


def normalize_value(x: float, size: int = 4, decimal_places: int = 2) -> str:
    """Formats a float as zero-padded string without decimal point.

    Pads to total size, with specified decimal places before removing dot.

    Args:
        x (float): Number to normalize.
        size (int): Total digits (integer + decimal). Defaults to 4.
        decimal_places (int): Decimal places. Defaults to 2.

    Returns:
        str: Padded string, e.g., '00123' for 1.23 with size=5, decimals=2.

    Raises:
        ValueError: Invalid formatting.
        Exception: Other formatting errors.

    Example:
        >>> from fbpyutils.string import normalize_value
        >>> normalize_value(1.23, size=5, decimal_places=2)
        '00123'
        >>> normalize_value(12.34, size=4, decimal_places=1)
        '1234'
    """
    _logger.debug(
        f"Normalizing value {x} to string (size: {size}, decimal_places: {decimal_places})"
    )
    try:
        format_string = "{:0" + str(size) + "." + str(decimal_places) + "f}"
        normalized_string = format_string.format(abs(x)).replace(".", "")
        _logger.debug(f"Normalized string: {normalized_string}")
        return normalized_string
    except ValueError as e:
        _logger.error(
            f"ValueError during value normalization: {e}. Input: {x}, size: {size}, decimal_places: {decimal_places}"
        )
        raise
    except Exception as e:
        _logger.error(
            f"An unexpected error occurred during value normalization: {e}. Input: {x}"
        )
        raise


def translate_special_chars(x: str) -> str:
    """Translates accented/special characters to basic ASCII equivalents.

    Uses a translation table for áãâäàéèëêíìîïóòõôöúùûüçñ to aaaaaeeeeiiiiooooouuuucn.

    Args:
        x (str): Input string. Defaults to empty if None.

    Returns:
        str: String with special chars replaced.

    Example:
        >>> from fbpyutils.string import translate_special_chars
        >>> translate_special_chars('café naïve')
        'cafe naive'
        >>> translate_special_chars('São Paulo')
        'Sao Paulo'
    """
    _logger.debug(f"Translating special characters for string: '{x}'")
    x = x or ""
    translated_string = x.translate(_TRANSLATION_TAB)
    _logger.debug(f"Translated string: '{translated_string}'")
    return translated_string


from typing import List


def normalize_names(names: List[str], normalize_specials: bool = True) -> List[str]:
    """Normalizes list of strings: lowercase, replace spaces/slashes with _, optional special char translation.

    Args:
        names (List[str]): List of strings to normalize.
        normalize_specials (bool): Apply translate_special_chars. Defaults to True.

    Returns:
        List[str]: Normalized strings.

    Example:
        >>> from fbpyutils.string import normalize_names
        >>> names = ['São Paulo', 'New York', 'São_Paulo/Test']
        >>> normalize_names(names)
        ['sao_paulo', 'new_york', 'sao_paulo_test']
        >>> normalize_names(names, normalize_specials=False)
        ['são_paulo', 'new_york', 'são_paulo_test']
    """
    _logger.debug(
        f"Normalizing names (normalize_specials: {normalize_specials}). Input names: {names}"
    )
    normalized_list = [
        str(translate_special_chars(c) if normalize_specials else c)
        .replace(" ", "_")
        .replace("/", "_")
        .lower()
        for c in names
    ]
    _logger.debug(f"Normalized names: {normalized_list}")
    return normalized_list


def split_by_lengths(string: str, lengths: List[int]) -> List[str]:
    """Splits a string into substrings based on cumulative lengths list.

    Only adds non-empty substrings. Logs warnings for empty segments.

    Args:
        string (str): Input string to split.
        lengths (List[int]): List of segment lengths.

    Returns:
        List[str]: List of non-empty substrings.

    Example:
        >>> from fbpyutils.string import split_by_lengths
        >>> split_by_lengths('HelloWorld', [5, 5])
        ['Hello', 'World']
        >>> split_by_lengths('ABC', [1, 1, 1])
        ['A', 'B', 'C']
        >>> split_by_lengths('ABCD', [2, 1, 0, 1])  # Empty segment skipped
        ['AB', 'C', 'D']
    """
    _logger.debug(
        f"Splitting string by lengths. Input string length: {len(string)}, lengths: {lengths}"
    )
    substrings = []
    start_index = 0
    for i, length in enumerate(lengths):
        end_index = start_index + length
        substring = string[start_index:end_index]
        if substring:  # Only add non-empty
            substrings.append(substring)
            _logger.debug(f"Added substring {i + 1}: '{substring}'")
        else:
            _logger.warning(
                f"Substring {i + 1} is empty for length {length} at index {start_index}. Skipping."
            )
        start_index = end_index
    _logger.debug(f"Finished splitting string. Total substrings: {len(substrings)}")
    return substrings

