"""
Main entry point for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils import get_env
from fbpyutils.cli.utils.error_handler import handle_error

# Import command groups
from fbpyutils.cli.groups import (
    calendar,
    datetime,
    file,
    image,
    mailbox,
    ofx,
    process,
    string,
    uuid,
    xlsx,
)

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
@click.version_option(version=get_env().APP.version)
def cli():
    """A CLI client for the fbpyutils library."""
    pass


# Register command groups
cli.add_command(calendar.calendar)
cli.add_command(datetime.datetime)
cli.add_command(file.file)
cli.add_command(image.image)
cli.add_command(mailbox.mailbox)
cli.add_command(ofx.ofx)
cli.add_command(process.process)
cli.add_command(string.string)
cli.add_command(uuid.uuid)
cli.add_command(xlsx.xlsx)


if __name__ == "__main__":
    try:
        cli()
    except Exception as e:
        logger.critical(f"Critical error in CLI: {e}")
        handle_error(e, "Critical error occurred")
