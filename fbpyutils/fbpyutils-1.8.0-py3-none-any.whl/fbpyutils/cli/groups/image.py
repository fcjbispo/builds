"""
Command group for image processing CLI commands.
"""

import click
import os
import fbpyutils
from fbpyutils.image import (
    get_image_info,
    resize_image,
    enhance_image_for_ocr,
)
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

# Initialize logger
fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def image():
    """Commands for image processing and analysis."""
    pass


@image.command()
@click.option(
    "--source",
    required=True,
    help="Path to image file or image bytes (for piped input).",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def info(source: str, output_format: str):
    """Extract detailed information from an image including EXIF metadata and geolocation."""
    try:
        info_data = get_image_info(source)
        if "error" in info_data:
            raise ValueError(info_data["error"])

        formatted_output = format_output(info_data, output_format)
        click.echo(formatted_output)

    except Exception as e:
        handle_error(e, "Failed to extract image information")


@image.command()
@click.option(
    "--source",
    required=True,
    help="Path to image file or image bytes (for piped input).",
)
@click.option("--width", required=True, type=int, help="Target width in pixels.")
@click.option("--height", required=True, type=int, help="Target height in pixels.")
@click.option(
    "--maintain-aspect-ratio",
    is_flag=True,
    default=True,
    help="Maintain aspect ratio during resize.",
)
@click.option(
    "--quality", default=85, type=click.IntRange(1, 100), help="JPEG quality (1-100)."
)
@click.option("--output-file", required=True, help="Path to save the resized image.")
def resize(
    source: str,
    width: int,
    height: int,
    maintain_aspect_ratio: bool,
    quality: int,
    output_file: str,
):
    """Resize an image to specified dimensions and save to file."""
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Resize image
        resized_bytes = resize_image(
            source, width, height, maintain_aspect_ratio, quality
        )

        # Write to file
        with open(output_file, "wb") as f:
            f.write(resized_bytes)

        logger.info(f"Resized image saved to {output_file}")
        click.echo(f"Image successfully resized and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to resize image")


@image.command()
@click.option(
    "--source",
    required=True,
    help="Path to image file or image bytes (for piped input).",
)
@click.option(
    "--contrast-factor",
    default=2.0,
    type=float,
    help="Contrast enhancement factor (default: 2.0).",
)
@click.option(
    "--threshold",
    default=128,
    type=click.IntRange(0, 255),
    help="Binarization threshold (0-255, default: 128).",
)
@click.option("--output-file", required=True, help="Path to save the enhanced image.")
def enhance_ocr(source: str, contrast_factor: float, threshold: int, output_file: str):
    """Enhance image for better OCR accuracy using preprocessing techniques."""
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Enhance image
        enhanced_bytes = enhance_image_for_ocr(source, contrast_factor, threshold)

        # Write to file
        with open(output_file, "wb") as f:
            f.write(enhanced_bytes)

        logger.info(f"Enhanced image saved to {output_file}")
        click.echo(f"Image successfully enhanced and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to enhance image for OCR")
