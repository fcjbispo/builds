"""
String commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def string():
    """Commands for string manipulation."""


@string.command("uuid")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def uuid_cmd(output_format: str):
    """Generate a standard UUID4 string."""
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.string import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@string.command("similarity")
@click.option("--string1", required=True, help="First string to compare.")
@click.option("--string2", required=True, help="Second string to compare.")
@click.option(
    "--ignore-case", is_flag=True, default=True, help="Ignore case during comparison."
)
@click.option(
    "--compress-spaces", is_flag=True, default=True, help="Compress extra spaces."
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def similarity_cmd(
    string1: str,
    string2: str,
    ignore_case: bool,
    compress_spaces: bool,
    output_format: str,
):
    """Calculate similarity ratio between two strings."""
    try:
        logger.info(
            f"Calculating similarity between strings (ignore_case: {ignore_case}, compress_spaces: {compress_spaces})"
        )

        from fbpyutils.string import similarity

        result = similarity(string1, string2, ignore_case, compress_spaces)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Similarity calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate similarity")


@string.command("random")
@click.option("--length", default=32, type=int, help="Length of the random string.")
@click.option("--include-digits", is_flag=True, default=True, help="Include digits.")
@click.option(
    "--include-special", is_flag=True, default=False, help="Include special characters."
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def random_cmd(
    length: int, include_digits: bool, include_special: bool, output_format: str
):
    """Generate a random string."""
    try:
        logger.info(
            f"Generating random string of length {length} (include_digits: {include_digits}, include_special: {include_special})"
        )

        from fbpyutils.string import random_string

        result = random_string(length, include_digits, include_special)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Random string generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate random string")


@string.command("hash")
@click.option("--input", required=True, help="String to hash.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def hash_cmd(input: str, output_format: str):
    """Generate MD5 hash from a string."""
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.string import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@string.command("normalize-float")
@click.option("--value", required=True, type=float, help="Float value to normalize.")
@click.option("--size", default=4, type=int, help="Total length of output string.")
@click.option("--decimal-places", default=2, type=int, help="Number of decimal places.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def normalize_float_cmd(
    value: float, size: int, decimal_places: int, output_format: str
):
    """Convert float to zero-padded string."""
    try:
        logger.info(
            f"Normalizing float {value} to string (size: {size}, decimal_places: {decimal_places})"
        )

        from fbpyutils.string import normalize_value

        result = normalize_value(value, size, decimal_places)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Float normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize float")


@string.command("translate-chars")
@click.option("--input", required=True, help="String to translate.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def translate_chars_cmd(input: str, output_format: str):
    """Translate special characters to basic counterparts."""
    try:
        logger.info("Translating special characters")

        from fbpyutils.string import translate_special_chars

        result = translate_special_chars(input)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Special characters translated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to translate special characters")


@string.command("normalize-list")
@click.option(
    "--names", required=True, help="Comma-separated list of strings to normalize."
)
@click.option(
    "--normalize-specials",
    is_flag=True,
    default=True,
    help="Translate special characters.",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def normalize_list_cmd(names: str, normalize_specials: bool, output_format: str):
    """Normalize a list of strings."""
    try:
        logger.info(
            f"Normalizing list of strings (normalize_specials: {normalize_specials})"
        )

        from fbpyutils.string import normalize_names

        names_list = [name.strip() for name in names.split(",")]
        result = normalize_names(names_list, normalize_specials)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("List normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize list")


@string.command("split-by-lengths")
@click.option("--input", required=True, help="String to split.")
@click.option("--lengths", required=True, help="Comma-separated list of lengths.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def split_by_lengths_cmd(input: str, lengths: str, output_format: str):
    """Split string by specified lengths."""
    try:
        logger.info("Splitting string by lengths")

        from fbpyutils.string import split_by_lengths

        lengths_list = [int(length.strip()) for length in lengths.split(",")]
        result = split_by_lengths(input, lengths_list)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("String split successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to split string")
