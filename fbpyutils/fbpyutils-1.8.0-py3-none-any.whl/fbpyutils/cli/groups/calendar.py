"""
Calendar commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error
from datetime import datetime

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def calendar():
    """Commands for calendar manipulation."""
    pass


@calendar.command("get-range")
@click.option("--start-date", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end-date", required=True, help="End date (YYYY-MM-DD).")
@click.option(
    "--add-markers",
    is_flag=True,
    default=False,
    help="Add temporal markers to the calendar.",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def get_range(start_date: str, end_date: str, add_markers: bool, output_format: str):
    """Build a calendar based on a date range."""
    try:
        logger.info(f"Generating calendar from {start_date} to {end_date}")

        # Parse dates
        start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()

        # Import the calendar function
        from fbpyutils.calendar import get_calendar

        # Generate calendar
        result = get_calendar(start_dt, end_dt)

        # Add markers if requested
        if add_markers:
            from fbpyutils.calendar import add_markers

            result = add_markers(result)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Calendar generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate calendar")
