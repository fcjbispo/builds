"""
XLSX commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def xlsx():
    """Commands for Excel file manipulation."""


@xlsx.command("list-sheets")
@click.option("--file", required=True, help="Path to the Excel file.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def list_sheets_cmd(file: str, output_format: str):
    """Retrieve the names of all sheets from an Excel file."""
    try:
        logger.info(f"Listing sheets from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_names

        result = get_sheet_names(file)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Sheets listed successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to list sheets")


@xlsx.command("read-sheet")
@click.option("--file", required=True, help="Path to the Excel file.")
@click.option("--sheet-name", required=True, help="Name of the sheet to read.")
@click.option("--output-file", help="Path to save the sheet content (optional).")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def read_sheet_cmd(file: str, sheet_name: str, output_file: str, output_format: str):
    """Read the content of a specific sheet from an Excel file."""
    try:
        logger.info(f"Reading sheet '{sheet_name}' from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_by_name

        result = get_sheet_by_name(file, sheet_name)

        if output_file:
            import json

            with open(output_file, "w", encoding="utf-8") as f:
                if output_format == "json":
                    json.dump(result, f, indent=2, default=str)
                elif output_format == "csv":
                    import csv

                    writer = csv.writer(f)
                    for row in result:
                        writer.writerow(row)
                else:  # txt
                    for row in result:
                        f.write("\t".join(str(cell) for cell in row) + "\n")
            logger.info(f"Sheet content saved to {output_file}")
        else:
            formatted_result = format_output(result, output_format)
            click.echo(formatted_result)

        logger.debug("Sheet read successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read sheet")
