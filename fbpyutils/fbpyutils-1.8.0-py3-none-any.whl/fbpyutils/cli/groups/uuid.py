"""
UUID and Snowflake ID generation commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def uuid():
    """Commands for UUID generation and Snowflake ID creation."""


@uuid.command("uuid4")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def uuid4_cmd(output_format: str):
    """Generate a standard UUID4 string."""
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.uuid import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@uuid.command("hash-string")
@click.option("--input", required=True, help="String to hash.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def hash_string_cmd(input: str, output_format: str):
    """Generate MD5 hash from a string."""
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.uuid import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@uuid.command("hash-json")
@click.option("--input", required=True, help="JSON string or path to JSON file.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def hash_json_cmd(input: str, output_format: str):
    """Generate MD5 hash from a JSON dictionary."""
    try:
        logger.info("Generating MD5 hash from JSON")

        import json
        from fbpyutils.uuid import hash_json

        # Try to parse as JSON, if it fails, try reading as file
        try:
            data = json.loads(input)
        except json.JSONDecodeError:
            # Try reading as file path
            try:
                with open(input, 'r') as f:
                    data = json.load(f)
            except FileNotFoundError:
                raise ValueError(f"Input is not valid JSON or file path: {input}")

        result = hash_json(data)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("JSON hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate JSON hash")


@uuid.command("snowflake")
@click.option("--datacenter-id", default=0, type=int, help="Datacenter ID (0-31).")
@click.option("--worker-id", default=0, type=int, help="Worker ID (0-31).")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def snowflake_cmd(datacenter_id: int, worker_id: int, output_format: str):
    """Generate a Snowflake ID using the new implementation."""
    try:
        logger.info(f"Generating Snowflake ID (datacenter_id: {datacenter_id}, worker_id: {worker_id})")

        from fbpyutils.uuid import snowflake_id

        result = snowflake_id(datacenter_id=datacenter_id, worker_id=worker_id)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate Snowflake ID")


@uuid.command("snowflake-classic")
@click.option("--machine-id", default=1, type=int, help="Machine ID (0-1023).")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def snowflake_classic_cmd(machine_id: int, output_format: str):
    """Generate a Snowflake ID using the classic Twitter algorithm (deprecated)."""
    try:
        logger.info(f"Generating classic Snowflake ID (machine_id: {machine_id})")

        from fbpyutils.uuid import SnowflakeIDGenerator

        generator = SnowflakeIDGenerator(machine_id=machine_id)
        result = generator.generate()

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Classic Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate classic Snowflake ID")


@uuid.command("snowflake-decode")
@click.argument("snowflake_id", type=int)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def snowflake_decode_cmd(snowflake_id: int, output_format: str):
    """Decode a Snowflake ID into its components."""
    try:
        logger.info(f"Decoding Snowflake ID: {snowflake_id}")

        from fbpyutils.uuid import Snowflake

        snowflake = Snowflake()
        result = snowflake.get_id_components(snowflake_id)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Snowflake ID decoded successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to decode Snowflake ID")