"""
Mailbox CLI commands for fbpyutils.

This module provides Click-based CLI commands for MBOX file analysis.
"""

import click
from typing import Optional
import fbpyutils
from fbpyutils.cli.utils.error_handler import handle_error
from fbpyutils.mailbox import MboxReader

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def mailbox():
    """MBOX file analysis commands."""
    pass


@mailbox.command()
@click.argument("mbox_file", type=click.Path(exists=True))
@click.option(
    "--format",
    "-f",
    type=click.Choice(["json", "csv", "txt"]),
    default="json",
    help="Output format (default: json)",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def metadata(mbox_file: str, format: str, output: Optional[str]):
    """Extract metadata from all messages in MBOX file."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_all_metadata(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Metadata saved to: {output}")
        else:
            click.echo(result)

    except Exception as e:
        logger.error(f"Error extracting metadata: {e}")
        handle_error(e, "Failed to extract metadata")


@mailbox.command()
@click.argument("mbox_file", type=click.Path(exists=True))
@click.argument("identifier")
@click.option(
    "--search-type",
    type=click.Choice(["auto", "index", "message_id", "search"]),
    default="auto",
    help="Search type (default: auto)",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def message(mbox_file: str, identifier: str, search_type: str, output: Optional[str]):
    """Get details of a specific message."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_message_details(identifier, search_type)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Message details saved to: {output}")
        else:
            click.echo(result)

    except Exception as e:
        logger.error(f"Error getting message details: {e}")
        handle_error(e, "Failed to get message details")


@mailbox.command()
@click.argument("mbox_file", type=click.Path(exists=True))
@click.argument("limit", type=int, required=False)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def list(mbox_file: str, limit: Optional[int], output: Optional[str]):
    """List message summaries."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.list_messages_summary(limit)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Message list saved to: {output}")
        else:
            click.echo(result)

    except Exception as e:
        logger.error(f"Error listing messages: {e}")
        handle_error(e, "Failed to list messages")


@mailbox.command()
@click.argument("mbox_file", type=click.Path(exists=True))
@click.argument("term")
@click.option(
    "--search-fields",
    multiple=True,
    type=click.Choice(["subject", "from", "to", "message_id"]),
    default=["subject", "from", "to"],
    help="Fields to search in",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def search(mbox_file: str, term: str, search_fields: tuple, output: Optional[str]):
    """Search messages by term."""
    try:
        reader = MboxReader(mbox_file)
        results = reader.search_messages(term, list(search_fields))

        # Format results as JSON
        import json

        search_results = {
            "search_term": term,
            "search_fields": list(search_fields),
            "total_found": len(results),
            "messages": [],
        }

        for message, index in results:
            summary = {
                "index": index,
                "message_id": str(message.get("Message-ID", "")),
                "subject": str(message.get("Subject", "")),
                "from": str(message.get("From", "")),
                "date": str(message.get("Date", "")),
                "has_attachments": message.is_multipart(),
            }
            search_results["messages"].append(summary)

        result = json.dumps(search_results, indent=2, ensure_ascii=False)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Search results saved to: {output}")
        else:
            click.echo(result)

    except Exception as e:
        logger.error(f"Error searching messages: {e}")
        handle_error(e, "Failed to search messages")


@mailbox.command()
@click.argument("mbox_file", type=click.Path(exists=True))
@click.option(
    "--format",
    "-f",
    type=click.Choice(["json", "csv", "txt"]),
    default="json",
    help="Output format (default: json)",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def summary(mbox_file: str, format: str, output: Optional[str]):
    """Generate mailbox summary."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_mailbox_summary(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            click.echo(f"Summary saved to: {output}")
        else:
            click.echo(result)

    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        handle_error(e, "Failed to generate summary")
