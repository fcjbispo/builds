"""
OFX CLI group for parsing OFX files.
"""

import click
import fbpyutils
import json
import os
from fbpyutils.ofx import read_from_path
from fbpyutils.cli.utils.error_handler import handle_error
from fbpyutils.cli.utils.output_formatter import JSONEncoder

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


# Define the OFX CLI group
@click.group()
def ofx():
    """Commands for OFX (Open Financial Exchange) processing."""
    pass


# CLI command: parse-file
@ofx.command("parse-file")
@click.option("--path", required=True, help="Path to OFX file.")
@click.option(
    "--native-date",
    is_flag=True,
    default=False,
    help="Return dates as native datetime objects. If not provided, dates will be returned as ISO-formatted strings.",
)
@click.option(
    "--output-file", required=False, help="Optional: write JSON output to a file."
)
def parse_file(path: str, native_date: bool, output_file: str):
    """Parse an OFX file and output its content as JSON or write to a file."""
    try:
        logger.info(
            f"OFX parse-file invoked for path={path}, native_date={native_date}, output_file={output_file}"
        )

        data = read_from_path(path, native_date)

        if output_file:
            # Ensure the output directory exists
            output_dir = os.path.dirname(output_file)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir)

            # Write pretty-printed JSON to the file
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder))

            logger.info(f"OFX data written to {output_file}")
            click.echo(f"OFX data written to {output_file}")
        else:
            # Print to stdout as JSON for CLI usage
            formatted = json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder)
            click.echo(formatted)
            logger.debug("OFX data printed to stdout")

    except Exception as e:
        logger.error(f"Error parsing OFX file: {e}", exc_info=True)
        handle_error(e, "Failed to parse OFX file")
