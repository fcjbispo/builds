"""
Module providing utility functions for string manipulation, including UUID generation,
similarity calculation, random string creation, JSON conversion, hashing, normalization,
and splitting.
"""

import random
import string
import hashlib
import json
import time
from threading import Lock

from difflib import SequenceMatcher

import uuid as u

from typing import Dict, Optional

import fbpyutils


from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

_SPECIAL_CHARS = "".join([c + c.upper() for c in "áãâäàéèëêíìîïóòõôöúùûüçñ"])

_NORMALIZED_CHARS = "".join([c + c.upper() for c in "aaaaaeeeeiiiiooooouuuucn"])

_TRANSLATION_TAB = {}
for i in range(len(_SPECIAL_CHARS)):
    _TRANSLATION_TAB[ord(_SPECIAL_CHARS[i])] = _NORMALIZED_CHARS[i]


def uuid() -> str:
    """Generates a random UUID4 string.

    Uses uuid.uuid4() for cryptographically secure random UUID.

    Returns:
        str: UUID string like '123e4567-e89b-12d3-a456-426614174000'.

    Example:
        >>> from fbpyutils.string import uuid
        >>> uid = uuid()
        >>> len(uid)
        36
        >>> uid
        '123e4567-e89b-12d3-a456-426614174000'
    """
    generated_uuid = str(u.uuid4())
    _logger.debug(f"Generated UUID: {generated_uuid}")
    return generated_uuid


def similarity(
    x: str, y: str, ignore_case: bool = True, compress_spaces: bool = True
) -> float:
    """Calculates similarity ratio between two strings using SequenceMatcher.

    Options to ignore case and compress multiple spaces. Ratio 1.0 = identical, 0.0 = no similarity.

    Args:
        x (str): First string.
        y (str): Second string.
        ignore_case (bool): Ignore case differences. Defaults to True.
        compress_spaces (bool): Replace multiple spaces with single. Defaults to True.

    Returns:
        float: Similarity ratio (0.0 to 1.0).

    Example:
        >>> from fbpyutils.string import similarity
        >>> similarity('Hello World', 'Hello world')
        0.8
        >>> similarity('Hello World', 'Hi there', ignore_case=False)
        0.0
        >>> similarity('A  B  C', 'A B C', compress_spaces=True)
        1.0
    """
    _logger.debug(
        f"Calculating similarity between '{x}' and '{y}' (ignore_case: {ignore_case}, compress_spaces: {compress_spaces})"
    )

    def compress(z: str) -> str:
        original_z = z
        while "  " in z:
            z = z.replace("  ", " ")
        if original_z != z:
            _logger.debug(f"Compressed spaces: '{original_z}' -> '{z}'")
        return z

    if ignore_case:
        x = x.lower()
        y = y.lower()
        _logger.debug(f"Strings after lowercasing: x='{x}', y='{y}'")

    if compress_spaces:
        x = compress(x)
        y = compress(y)

    ratio = SequenceMatcher(None, x, y).ratio()
    _logger.debug(f"Similarity ratio: {ratio}")
    return ratio


def random_string(
    x: int = 32, include_digits: bool = True, include_special: bool = False
) -> str:
    """Generates a random string of specified length using letters, digits, special chars.

    Uses random.choice from ascii_letters + optional digits + special.

    Args:
        x (int): Length of string. Defaults to 32.
        include_digits (bool): Include digits 0-9. Defaults to True.
        include_special (bool): Include !@#$%^&*_. Defaults to False.

    Returns:
        str: Random string.

    Example:
        >>> from fbpyutils.string import random_string
        >>> rand = random_string(10, include_digits=True, include_special=False)
        >>> len(rand)
        10
        >>> rand.isalpha()
        True
        >>> rand_special = random_string(5, include_special=True)
        >>> '!' in rand_special or '@' in rand_special
        True
    """
    _logger.debug(
        f"Generating random string of length {x} (include_digits: {include_digits}, include_special: {include_special})"
    )
    letters = (
        string.ascii_letters
        + (string.digits if include_digits else "")
        + ("!@#$%^&*_" if include_special else "")
    )

    if not letters:
        _logger.warning(
            "No character set selected for random string generation. Returning empty string."
        )
        return ""

    generated_string = "".join(random.choice(letters) for i in range(x))
    _logger.debug(f"Generated random string (first 5 chars): {generated_string[:5]}...")
    return generated_string


def json_string(x: Dict) -> str:
    """Converts a dictionary to a JSON string, handling non-serializable types by stringifying.

    Ensures UTF-8 encoding and decoding.

    Args:
        x (Dict): Dictionary to convert.

    Returns:
        str: JSON string representation.

    Raises:
        TypeError: If conversion fails due to unhandled types.
        Exception: Other JSON encoding errors.

    Example:
        >>> from fbpyutils.string import json_string
        >>> data = {'name': 'Alice', 'age': 30, 'obj': object()}
        >>> js = json_string(data)
        >>> js
        '{"name": "Alice", "age": 30, "obj": "<object object at 0x...>"}'
        >>> import json
        >>> json.loads(js)['name']
        'Alice'
    """
    _logger.debug("Converting dictionary to JSON string.")
    _default = lambda obj: str(obj)  # Stringify non-serializable
    try:
        s = json.dumps(x, default=_default, ensure_ascii=False).encode("utf8")
        decoded_string = s.decode()
        _logger.debug("Successfully converted dictionary to JSON string.")
        return decoded_string
    except TypeError as e:
        _logger.error(f"TypeError during JSON string conversion: {e}. Input: {x}")
        raise
    except Exception as e:
        _logger.error(
            f"An unexpected error occurred during JSON string conversion: {e}. Input: {x}"
        )
        raise


def hash_string(x: str) -> str:
    """Generates MD5 hash of a string, encoding as UTF-8.

    Args:
        x (str): Input string.

    Returns:
        str: 32-character hexadecimal MD5 hash.

    Example:
        >>> from fbpyutils.string import hash_string
        >>> hash_string('Hello World')
        '5d41402abc4b2b76b0b6f0c1a6c9c9c9'  # Example hash
        >>> len(hash_string('test'))
        32
    """
    _logger.debug(f"Hashing string (first 10 chars): '{x[:10]}...'")
    hashed_string = hashlib.md5(x.encode("utf-8")).hexdigest()
    _logger.debug(f"Generated hash: {hashed_string}")
    return hashed_string


def hash_json(x: Dict) -> str:
    """Generates MD5 hash of a dictionary by converting to JSON string first.

    Args:
        x (Dict): Dictionary to hash.

    Returns:
        str: MD5 hex digest of JSON string.

    Example:
        >>> from fbpyutils.string import hash_json
        >>> data = {'key': 'value', 'num': 42}
        >>> hash_json(data)
        'a1b2c3d4e5f6...'  # Example hash
    """
    _logger.debug("Hashing JSON dictionary.")
    hashed_json = hash_string(json_string(x))
    _logger.debug(f"Generated JSON hash: {hashed_json}")
    return hashed_json


def normalize_value(x: float, size: int = 4, decimal_places: int = 2) -> str:
    """Formats a float as zero-padded string without decimal point.

    Pads to total size, with specified decimal places before removing dot.

    Args:
        x (float): Number to normalize.
        size (int): Total digits (integer + decimal). Defaults to 4.
        decimal_places (int): Decimal places. Defaults to 2.

    Returns:
        str: Padded string, e.g., '00123' for 1.23 with size=5, decimals=2.

    Raises:
        ValueError: Invalid formatting.
        Exception: Other formatting errors.

    Example:
        >>> from fbpyutils.string import normalize_value
        >>> normalize_value(1.23, size=5, decimal_places=2)
        '00123'
        >>> normalize_value(12.34, size=4, decimal_places=1)
        '1234'
    """
    _logger.debug(
        f"Normalizing value {x} to string (size: {size}, decimal_places: {decimal_places})"
    )
    try:
        format_string = "{:0" + str(size) + "." + str(decimal_places) + "f}"
        normalized_string = format_string.format(abs(x)).replace(".", "")
        _logger.debug(f"Normalized string: {normalized_string}")
        return normalized_string
    except ValueError as e:
        _logger.error(
            f"ValueError during value normalization: {e}. Input: {x}, size: {size}, decimal_places: {decimal_places}"
        )
        raise
    except Exception as e:
        _logger.error(
            f"An unexpected error occurred during value normalization: {e}. Input: {x}"
        )
        raise


def translate_special_chars(x: str) -> str:
    """Translates accented/special characters to basic ASCII equivalents.

    Uses a translation table for áãâäàéèëêíìîïóòõôöúùûüçñ to aaaaaeeeeiiiiooooouuuucn.

    Args:
        x (str): Input string. Defaults to empty if None.

    Returns:
        str: String with special chars replaced.

    Example:
        >>> from fbpyutils.string import translate_special_chars
        >>> translate_special_chars('café naïve')
        'cafe naive'
        >>> translate_special_chars('São Paulo')
        'Sao Paulo'
    """
    _logger.debug(f"Translating special characters for string: '{x}'")
    x = x or ""
    translated_string = x.translate(_TRANSLATION_TAB)
    _logger.debug(f"Translated string: '{translated_string}'")
    return translated_string


from typing import List


def normalize_names(names: List[str], normalize_specials: bool = True) -> List[str]:
    """Normalizes list of strings: lowercase, replace spaces/slashes with _, optional special char translation.

    Args:
        names (List[str]): List of strings to normalize.
        normalize_specials (bool): Apply translate_special_chars. Defaults to True.

    Returns:
        List[str]: Normalized strings.

    Example:
        >>> from fbpyutils.string import normalize_names
        >>> names = ['São Paulo', 'New York', 'São_Paulo/Test']
        >>> normalize_names(names)
        ['sao_paulo', 'new_york', 'sao_paulo_test']
        >>> normalize_names(names, normalize_specials=False)
        ['são_paulo', 'new_york', 'são_paulo_test']
    """
    _logger.debug(
        f"Normalizing names (normalize_specials: {normalize_specials}). Input names: {names}"
    )
    normalized_list = [
        str(translate_special_chars(c) if normalize_specials else c)
        .replace(" ", "_")
        .replace("/", "_")
        .lower()
        for c in names
    ]
    _logger.debug(f"Normalized names: {normalized_list}")
    return normalized_list


def split_by_lengths(string: str, lengths: List[int]) -> List[str]:
    """Splits a string into substrings based on cumulative lengths list.

    Only adds non-empty substrings. Logs warnings for empty segments.

    Args:
        string (str): Input string to split.
        lengths (List[int]): List of segment lengths.

    Returns:
        List[str]: List of non-empty substrings.

    Example:
        >>> from fbpyutils.string import split_by_lengths
        >>> split_by_lengths('HelloWorld', [5, 5])
        ['Hello', 'World']
        >>> split_by_lengths('ABC', [1, 1, 1])
        ['A', 'B', 'C']
        >>> split_by_lengths('ABCD', [2, 1, 0, 1])  # Empty segment skipped
        ['AB', 'C', 'D']
    """
    _logger.debug(
        f"Splitting string by lengths. Input string length: {len(string)}, lengths: {lengths}"
    )
    substrings = []
    start_index = 0
    for i, length in enumerate(lengths):
        end_index = start_index + length
        substring = string[start_index:end_index]
        if substring:  # Only add non-empty
            substrings.append(substring)
            _logger.debug(f"Added substring {i + 1}: '{substring}'")
        else:
            _logger.warning(
                f"Substring {i + 1} is empty for length {length} at index {start_index}. Skipping."
            )
        start_index = end_index
    _logger.debug(f"Finished splitting string. Total substrings: {len(substrings)}")
    return substrings


class SnowflakeIDGenerator:
    """A simple Snowflake ID generator that produces unique 63-bit integer IDs.

    Inspired by Twitter's Snowflake algorithm, this generates sortable, unique numeric IDs
    consisting of timestamp (41 bits), machine ID (10 bits), and sequence (12 bits).
    Uses a custom epoch of November 4, 2010 (Twitter's epoch) for compatibility.
    Thread-safe using a lock.

    Note: For production use, consider distributed coordination for machine IDs.
    The IDs are 63-bit to fit in signed 64-bit integers, with MSB=0.

    """

    EPOCH = 1288834974657  # Twitter Snowflake epoch in ms
    TIMESTAMP_BITS = 41
    MACHINE_BITS = 10
    SEQUENCE_BITS = 12
    MAX_MACHINE_ID = (1 << MACHINE_BITS) - 1
    MAX_SEQUENCE = (1 << SEQUENCE_BITS) - 1
    TIMESTAMP_LEFT_SHIFT = SEQUENCE_BITS + MACHINE_BITS  # 22 bits shift for 41-bit timestamp
    MACHINE_LEFT_SHIFT = SEQUENCE_BITS  # 12 bits shift for machine ID

    def __init__(self, machine_id: int = 1):
        """
        Initializes the Snowflake ID generator.

        Args:
            machine_id (int): Unique machine ID (0 to 1023). Defaults to 1.

        Raises:
            ValueError: If machine_id is out of range.
        """
        if machine_id < 0 or machine_id > self.MAX_MACHINE_ID:
            raise ValueError(f"Machine ID must be between 0 and {self.MAX_MACHINE_ID}")
        self.machine_id = machine_id
        self.sequence = 0
        self.last_timestamp = -1
        self.lock = Lock()
        _logger.debug(f"SnowflakeIDGenerator initialized with machine_id: {machine_id}")

    def _wait_next_ms(self) -> int:
        """Waits until the next millisecond and returns the new timestamp."""
        timestamp = int(time.time() * 1000)
        while timestamp <= self.last_timestamp:
            timestamp = int(time.time() * 1000)
        return timestamp

    def generate(self) -> int:
        """
        Generates a unique Snowflake ID.

        Returns:
            int: 63-bit integer ID (fits in signed 64-bit).

        Example:
            >>> from fbpyutils.string import SnowflakeIDGenerator
            >>> gen = SnowflakeIDGenerator(machine_id=1)
            >>> id1 = gen.generate()
            >>> id2 = gen.generate()
            >>> id1 != id2  # True
            >>> id1 >> 22 == (int(time.time() * 1000) - SnowflakeIDGenerator.EPOCH)  # Approximate, True
            >>> id1.bit_length() <= 63  # Fits in 63 bits, True
        """
        with self.lock:
            timestamp = int(time.time() * 1000)

            if timestamp < self.last_timestamp:
                _logger.warning("Clock moved backwards. Waiting for system time to catch up.")
                timestamp = self._wait_next_ms()

            if timestamp == self.last_timestamp:
                self.sequence = (self.sequence + 1) & self.MAX_SEQUENCE
                if self.sequence == 0:
                    timestamp = self._wait_next_ms()
            else:
                self.sequence = 0

            self.last_timestamp = timestamp

            snowflake_id = (
                int(((timestamp - self.EPOCH) << self.TIMESTAMP_LEFT_SHIFT))
                | int((self.machine_id << self.SEQUENCE_BITS))
                | self.sequence
            )

            _logger.debug(f"Generated Snowflake ID: {snowflake_id} (timestamp: {timestamp}, machine: {self.machine_id}, seq: {self.sequence})")
            return snowflake_id


def snowflake_id(machine_id: Optional[int] = None) -> int:
    """
    Generates a unique numeric Snowflake ID.

    Uses a default machine ID of 1 if not provided. Thread-safe.

    Args:
        machine_id (Optional[int]): Unique machine ID (0-1023). Defaults to None (uses 1).

    Returns:
        int: Unique 63-bit integer ID.

    Raises:
        ValueError: If machine_id is invalid.

    Example:
        >>> from fbpyutils.string import snowflake_id
        >>> id1 = snowflake_id()
        >>> id2 = snowflake_id(machine_id=2)
        >>> id1 != id2  # True
        >>> isinstance(id1, int)  # True
        >>> id1 > 0  # True
        >>> # IDs are sortable by time
        >>> import time
        >>> time.sleep(0.001)  # Ensure different timestamps
        >>> id3 = snowflake_id()
        >>> id1 < id3  # Likely True
    """
    if machine_id is None:
        machine_id = 1
    if not hasattr(snowflake_id, '_generator'):
        snowflake_id._generator = SnowflakeIDGenerator(machine_id=machine_id)
    elif snowflake_id._generator.machine_id != machine_id:
        snowflake_id._generator = SnowflakeIDGenerator(machine_id=machine_id)
    return snowflake_id._generator.generate()
