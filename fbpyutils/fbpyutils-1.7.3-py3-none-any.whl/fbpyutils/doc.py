"""
Module providing functions to extract and generate documentation from Python modules,
including docstrings and signatures in Markdown format.
"""

import inspect
import importlib.util
import os
import re

import fbpyutils
from fbpyutils import get_logger, file as FU, _ROOT_DIR


fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()


def extract_doc_and_signature(filepath: str, module_name: str) -> str:
    """Extracts documentation and signatures from a Python file.

    Loads the module, extracts module docstring, functions, classes, and their docstrings/signatures,
    and formats them into Markdown.

    Args:
        filepath (str): The path to the Python module file.
        module_name (str): The name of the module.

    Returns:
        str: Formatted Markdown content of the module's documentation.

    Example:
        >>> from fbpyutils.doc import extract_doc_and_signature
        >>> doc = extract_doc_and_signature('fbpyutils/calendar.py', 'fbpyutils.calendar')
        >>> print(doc)
        # Module calendar
        ```
        Module providing utility functions for calendar manipulation...
        ```
        ## Function: get_calendar
        ```
        get_calendar(x: date, y: date) -> List
        ```
        ```
        Builds a calendar to be used as a time dimension...
        ```
    """
    _logger.debug(
        f"Starting extract_doc_and_signature for module: {module_name} at {filepath}"
    )
    spec = importlib.util.spec_from_file_location(module_name, filepath)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        _logger.info(f"Module {module_name} loaded successfully.")
    except Exception as e:
        _logger.error(f"Could not load module {module_name}: {e}")
        return f"# Error Documenting {module_name}\n\nCould not load module: {e}\n"

    doc_content = []

    doc_content.append(f"# Module {module_name.lower()}\n")
    if module.__doc__:
        doc_content.append(f"```python\n{inspect.cleandoc(module.__doc__)}\n```\n")
        _logger.debug(f"Module docstring found for {module_name}.")
    else:
        doc_content.append("No module docstring found.\n")
        _logger.warning(f"No module docstring found for {module_name}.")

    # Organize functions and classes by their appearance in the file
    items_in_order = []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            file_lines = f.readlines()
    except Exception as e:
        _logger.error(f"Could not read file {filepath}: {e}")
        return f"# Error Documenting {module_name}\n\nCould not read file: {e}\n"

    def get_line_number(obj):
        if hasattr(obj, "__code__"):
            return obj.__code__.co_firstlineno
        if hasattr(obj, "__dict__"):
            init_method = getattr(obj, "__init__", None)
            if init_method and hasattr(init_method, "__code__"):
                return init_method.__code__.co_firstlineno
            try:
                for i, line in enumerate(file_lines):
                    if re.match(rf"^\s*class\s+{obj.__name__}\s*:", line):
                        return i + 1
            except Exception:
                pass
        return float("inf")

    for name, obj in inspect.getmembers(module):
        if inspect.isfunction(obj) and obj.__module__ == module_name:
            items_in_order.append(("function", name, obj, get_line_number(obj)))
        elif (
            inspect.isclass(obj)
            and obj.__module__ == module_name
            and obj.__name__ == name
        ):
            items_in_order.append(("class", name, obj, get_line_number(obj)))

    items_in_order.sort(key=lambda x: x[3])

    for item_type, name, obj, _ in items_in_order:
        if item_type == "function":
            _logger.debug(f"Documenting function: {name}")
            doc_content.append(f"## Function: {name}\n")
            doc_content.append(f"```python\n{name}{inspect.signature(obj)}\n```\n")
            if obj.__doc__:
                doc_content.append(f"```\n{inspect.cleandoc(obj.__doc__)}\n```\n")
            else:
                doc_content.append("No docstring found for this function.\n")
                _logger.warning(f"No docstring found for function: {name}")
            doc_content.append("\n")

        elif item_type == "class":
            _logger.debug(f"Documenting class: {name}")
            if (
                inspect.isclass(obj)
                and obj.__module__ == module_name
                and obj.__name__ == name
            ):
                doc_content.append(f"## Class: {name}\n")
                if obj.__doc__:
                    doc_content.append(
                        f"```python\n{inspect.cleandoc(obj.__doc__)}\n```\n"
                    )
                    _logger.debug(f"Class docstring found for {name}.")
                else:
                    doc_content.append("No docstring found for this class.\n")
                    _logger.warning(f"No docstring found for class: {name}")
                doc_content.append("\n### Methods\n")

                class_methods_in_order = []
                for method_name, method_obj in inspect.getmembers(
                    obj, inspect.isfunction
                ):
                    if method_name.startswith("__") and method_name != "__init__":
                        continue
                    if hasattr(method_obj, "__func__") and hasattr(
                        method_obj.__func__, "__code__"
                    ):
                        class_methods_in_order.append(
                            (
                                method_name,
                                method_obj,
                                method_obj.__func__.__code__.co_firstlineno,
                            )
                        )

                class_methods_in_order.sort(key=lambda x: x[2])

                for method_name, method_obj, _ in class_methods_in_order:
                    _logger.debug(f"Documenting method: {name}.{method_name}")
                    if method_name == "__init__":
                        signature_str = (
                            str(inspect.signature(method_obj)).replace("self, ", "", 1)
                            if "self" in str(inspect.signature(method_obj))
                            else str(inspect.signature(method_obj))
                        )
                        doc_content.append(f"#### Constructor: {name}{signature_str}\n")
                    else:
                        doc_content.append(f"#### Method: {method_name}\n")

                    try:
                        if (
                            inspect.ismethod(method_obj)
                            and method_obj.__self__ is not None
                        ):
                            signature_to_display = inspect.signature(method_obj)
                        elif (
                            inspect.isfunction(method_obj)
                            and "self" in str(inspect.signature(method_obj))
                            and getattr(obj, method_name).__qualname__.startswith(name)
                        ):
                            sig_parts = str(inspect.signature(method_obj)).split(",")
                            if sig_parts and sig_parts[0].strip() == "(self":
                                signature_to_display = (
                                    f"({', '.join(sig_parts[1:])}".replace("))", ")")
                                    if len(sig_parts) > 1
                                    else "()"
                                )
                            else:
                                signature_to_display = inspect.signature(method_obj)
                        else:
                            signature_to_display = inspect.signature(method_obj)

                        if isinstance(signature_to_display, str):
                            doc_content.append(
                                f"```python\n{method_name}{signature_to_display}\n```\n"
                            )
                        else:
                            doc_content.append(
                                f"```python\n{method_name}{str(signature_to_display)}\n```\n"
                            )
                    except ValueError:
                        _logger.warning(
                            f"Could not get signature for {name}.{method_name}. Using fallback."
                        )
                        doc_content.append(
                            f"```python\n{method_name}(\\*args, \\*\\*kwargs)\n```\n"
                        )

                    if method_obj.__doc__:
                        doc_content.append(
                            f"```\n{inspect.cleandoc(method_obj.__doc__)}\n```\n"
                        )
                        _logger.debug(
                            f"Method docstring found for {name}.{method_name}."
                        )
                    else:
                        doc_content.append("No docstring found for this method.\n")
                        _logger.warning(
                            f"No docstring found for method: {name}.{method_name}"
                        )
                    doc_content.append("\n")

    return "\n".join(doc_content)


# %%
def generate_module_docs(
    output_dir: str, exclude_init: bool = False, source_dir: str = None
):
    """Generates Markdown documentation for all Python modules in a specified directory.

    Scans the source directory for .py files, extracts documentation using extract_doc_and_signature,
    and saves individual Markdown files for each module.

    Args:
        output_dir (str): Path to the directory where the documentation will be saved.
        exclude_init (bool): If True, excludes '__init__.py' files. Defaults to False.
        source_dir (str): Path to the source directory containing Python modules.
                          If None, uses the root directory (_ROOT_DIR). Defaults to None.

    Example:
        >>> from fbpyutils.doc import generate_module_docs
        >>> generate_module_docs('docs/', source_dir='fbpyutils/')
        # Generates Markdown files like fbpyutils.calendar.md, fbpyutils.datetime.md, etc.
        # Logs: Processing module: fbpyutils.calendar (fbpyutils/calendar.py)
        # Logs: Documentation saved to docs/fbpyutils.calendar.md
    """
    _logger.info(
        f"Starting documentation generation from {source_dir} to {output_dir}."
    )
    if source_dir is None:
        source_dir = _ROOT_DIR  # Assuming that _ROOT_DIR is defined in the context

    os.makedirs(output_dir, exist_ok=True)
    for filename in FU.find(source_dir, mask="*.py"):
        if filename.endswith(".py"):
            module = os.path.basename(os.path.dirname(filename))
            module_name = os.path.splitext(filename)[0].split(os.sep)[-1]
            if exclude_init and module_name == "__init__":
                continue
            elif module_name == "__init__":
                module_name = module
            else:
                module_name = f"{module}.{module_name}" if module else module_name

            filepath = os.path.join(source_dir, filename)
            output_filepath = os.path.join(output_dir, f"{module_name}.md")

            _logger.info(f"Processing module: {module_name} ({filepath})")
            documentation = extract_doc_and_signature(filepath, module_name)
            with open(output_filepath, "w", encoding="utf-8") as f:
                f.write(documentation)
            _logger.info(f"Documentation saved to {output_filepath}")
