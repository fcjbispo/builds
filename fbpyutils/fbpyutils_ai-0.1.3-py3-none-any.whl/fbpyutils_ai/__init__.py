"""
Initialization module for the fbpyutils_ai package.

Sets up logging configuration using RotatingFileHandler and QueueListener
for multiprocessing environments. Loads environment variables using dotenv.
"""

import os
import fbpyutils

from dotenv import load_dotenv

_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "INFO")
env.CONFIG = {
    "llm": {
        "semaphores": os.environ.get(
            "FBPY_SEMAPHORES",
            env.CONFIG.get("llm", {}).get("semaphores", 6),
        ),
    },
}

logger = fbpyutils.get_logger()
logger.configure_from_env(env)
