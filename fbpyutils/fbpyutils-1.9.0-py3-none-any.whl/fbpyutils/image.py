"""
Image Processing and Analysis Utilities

This module provides comprehensive image processing capabilities using the Pillow library
for loading, analyzing, resizing, and enhancing images. The module supports both local
file paths and in-memory byte data with robust error handling and performance monitoring.

The module offers five primary capabilities:

* **Image Loading**: Support for loading images from file paths or byte arrays with
  metadata extraction and format detection.

* **Image Analysis**: Comprehensive image information extraction including EXIF metadata,
  GPS data, camera settings, and technical specifications.

* **Image Processing**: High-quality resizing with aspect ratio preservation and
  LANCZOS resampling algorithm.

* **OCR Enhancement**: Specialized image preprocessing for optical character recognition
  including binarization, contrast enhancement, and noise reduction.

* **Metadata Extraction**: Detailed EXIF data parsing with GPS coordinate conversion
  and camera information extraction.

Key Features:
-------------
* **Dual Input Support**: Handle both file paths and byte arrays seamlessly
* **EXIF Data Processing**: Extract camera settings, dates, GPS coordinates, and technical details
* **High-Quality Resizing**: LANCZOS resampling with aspect ratio preservation
* **OCR Optimization**: Multi-step image enhancement pipeline for text recognition
* **GPS Coordinate Conversion**: DMS to decimal degree conversion for geolocation
* **Performance Monitoring**: Built-in timing and logging for operation tracking

Dependencies:
-------------
* `PIL (Pillow)`: Core image processing library with EXIF support
* `PIL.ExifTags`: EXIF tag mapping and GPS data processing
* `io`: In-memory binary operations for byte array handling
* `datetime`: Timestamp processing for EXIF date extraction
* `time.perf_counter`: High-resolution performance timing
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Load and analyze images:

>>> from fbpyutils.image import load_image_from_source, get_image_info
>>> img, name, size = load_image_from_source('/path/to/photo.jpg')
>>> info = get_image_info('/path/to/photo.jpg')
>>> info['camera EOS 5D_model']
'Canon'
>>> info['latitude']
'37.774900'

Resize images with quality control:

>>> from fbpyutils.image import resize_image
>>> resized = resize_image('/path/to/large.jpg', width=800, height=600, quality=90)
>>> len(resized) > 0
True

Enhance images for OCR:

>>> from fbpyutils.image import enhance_image_for_ocr
>>> enhanced = enhance_image_for_ocr('/path/to/scanned_doc.jpg', contrast_factor=2.0, threshold=140)
>>> enhanced[:10]
b'\x89PNG\r\n\x1a\n'

Process images from bytes:

>>> with open('/path/to/image.png', 'rb') as f:
...     img_bytes = f.read()
>>> img, name, size = load_image_from_source(img_bytes)
>>> name
'image_from_bytes'

Extract GPS coordinates:

>>> info = get_image_info('/path/to/gps_photo.jpg')
>>> f"GPS: {info['latitude']}, {info['longitude']}"
'GPS: 37.774900, -122.419400'

Notes:
------
* All operations include comprehensive error handling with detailed logging
* EXIF data extraction handles malformed or missing metadata gracefully
* GPS coordinates are converted from DMS format to decimal degrees
* Image processing preserves transparency through background conversion
* Performance metrics are logged for operation monitoring
* JPEG output uses optimized compression for file size reduction

Performance Considerations:
---------------------------
* EXIF processing may be slow for images with large metadata blocks
* GPS coordinate extraction requires additional parsing time
* Resizing performance depends on original image dimensions
* OCR enhancement applies multiple filters sequentially
* Memory usage scales with image size during processing

Cross-References:
-----------------
* See `fbpyutils.logging` for operation logging and performance tracking
* See `fbpyutils.file` for file operations and MIME type detection
* See `fbpyutils.setup()` for proper initialization requirements
"""

import os
import io
from typing import Union, Tuple
from PIL import Image, ImageEnhance, ImageFilter
from PIL.ExifTags import TAGS, GPSTAGS
from datetime import datetime
from time import perf_counter

import fbpyutils

from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

_logger = get_logger()


def load_image_from_source(
    image_source: Union[str, bytes],
) -> Tuple[Image.Image, str, int]:
    """Load image from file path or bytes with comprehensive error handling and metadata extraction.

    Provides unified interface for loading images from both local file paths and in-memory
    byte arrays. The function performs validation, file size calculation, and format detection
    while handling various edge cases and error conditions gracefully.

    Parameters
    ----------
    image_source : Union[str, bytes]
        Image data source - either a file path string or byte array containing image data.
        File paths can be absolute or relative and must point to accessible image files.
        Byte arrays must contain valid image data in a supported format (JPEG, PNG, GIF, etc.).

        File path examples:
        - '/home/user/photos/image.jpg' (absolute Unix path)
        - './images/photo.png' (relative path from current directory)
        - 'C:\\Users\\User\\Pictures\\image.bmp' (Windows absolute path)

        Byte array examples:
        - Binary data read from file: `open('image.jpg', 'rb').read()`
        - Downloaded image data: `requests.get(url).content`
        - Base64 decoded data: `base64.b64decode(base64_string)`

    Returns
    -------
    Tuple[Image.Image, str, int]
        A tuple containing the loaded PIL Image object, filename string, and file size in bytes.

        Returns:
        - Image.Image: PIL Image object ready for processing operations
        - str: Filename ('image.jpg' for files, 'image_from_bytes' for byte arrays)
        - int: File size in bytes for size calculations and memory management

    Raises
    ------
    ValueError
        When file is not found (str path), empty byte array provided, or invalid input type.
        Specific error messages indicate the exact cause for debugging.

    FileNotFoundError
        When the specified file path does not exist or cannot be accessed due to
        permissions or path resolution issues.

    OSError
        When system-level errors occur during file operations, including I/O errors
        or file system corruption issues.

    Examples
    --------
    Load image from file path:

    >>> from fbpyutils.image import load_image_from_source
    >>> img, filename, size = load_image_from_source('/home/user/photos/vacation.jpg')
    >>> isinstance(img, Image.Image)
    True
    >>> filename
    'vacation.jpg'
    >>> size > 0
    True
    >>> print(f"Image size: {img.size}")
    Image size: (1920, 1080)

    Load image from byte array:

    >>> with open('/path/to/image.png', 'rb') as f:
    ...     img_bytes = f.read()
    >>> img, name, size = load_image_from_source(img_bytes)
    >>> name
    'image_from_bytes'
    >>> size == len(img_bytes)
    True

    Handle file not found error:

    >>> try:
    ...     load_image_from_source('/nonexistent/image.jpg')
    ... except FileNotFoundError as e:
    ...     print(f"Error: {e}")
    Error: File not found

    Handle empty byte array:

    >>> try:
    ...     load_image_from_source(b'')
    ... except ValueError as e:
    ...     print(f"Error: {e}")
    Error: Empty byte array provided

    Notes
    -----
    * File size calculation includes complete file content for accurate memory management
    * Filename extraction uses os.path.basename for clean, user-friendly naming
    * Byte array sources default to 'image_from_bytes' for clear identification
    * PIL Image object is loaded with minimal processing for performance
    * Error messages provide specific details for troubleshooting
    * Function preserves original image data without modifications

    Performance Considerations
    --------------------------
    * File I/O operations are performed synchronously
    * Large image files may require significant memory during loading
    * Byte array processing avoids additional file system overhead
    * Image format detection is handled efficiently by PIL
    * Suitable for batch processing with proper memory management

    See Also
    --------
    PIL.Image.open : Core image loading functionality used internally
    os.path.exists : File existence validation for string paths
    os.stat : File size calculation for file-based sources
    """
    try:
        if isinstance(image_source, str):
            if not os.path.exists(image_source):
                raise ValueError("File not found")

            file_stats = os.stat(image_source)
            file_size = file_stats.st_size
            filename = os.path.basename(image_source)
            img = Image.open(image_source)
            _logger.info(f"Loaded image from file: {filename} ({file_size} bytes)")

        elif isinstance(image_source, bytes):
            if not image_source:
                raise ValueError("Empty byte array provided")

            file_size = len(image_source)
            filename = "image_from_bytes"
            img = Image.open(io.BytesIO(image_source))
            _logger.info(f"Loaded image from bytes: {filename} ({file_size} bytes)")

        else:
            raise ValueError(
                "Invalid input type. Expected str (file path) or bytes (image data)"
            )

        return img, filename, file_size

    except Exception as e:
        _logger.error(f"Error loading image: {str(e)}")
        raise ValueError(f"Error loading image: {str(e)}")


def get_image_info(image_source: Union[str, bytes]) -> dict:
    """Extract detailed information from an image including EXIF metadata and geolocation.

    Includes basic properties, EXIF tags (camera, date, etc.), and GPS data if available.
    For images, adds file dates if from path.

    Args:
        image_source (Union[str, bytes]): Path to image file (str) or image bytes (bytes).

    Returns:
        dict: Dictionary with image info like dimensions, format, EXIF, GPS.

    Example:
        >>> from fbpyutils.image import get_image_info
        >>> info = get_image_info('/path/to/image.jpg')
        >>> info
        {
            'filename': 'image.jpg',
            'file_size': 123456,
            'file_size_mb': 0.12,
            'format': 'JPEG',
            'mode': 'RGB',
            'width': 1920,
            'height': 1080,
            'resolution': '1920x1080',
            'has_transparency': False,
            'camera_make': 'Canon',
            'camera_model': 'EOS 5D',
            'datetime_taken': '2023:01:01 12:00:00',
            'latitude': '37.7749',
            'longitude': '-122.4194',
            ...
        }
    """
    try:
        # Load image using utility function
        img, filename, file_size = load_image_from_source(image_source)

        with img:
            _logger.info(f"Extracting image info from: {filename}")
            # Basic image information
            info = {
                "filename": filename,
                "file_size": file_size,
                "file_size_mb": round(file_size / (1024 * 1024), 2),
                "format": img.format,
                "mode": img.mode,
                "width": img.size[0],
                "height": img.size[1],
                "resolution": f"{img.size[0]}x{img.size[1]}",
                "has_transparency": img.mode in ("RGBA", "LA")
                or "transparency" in img.info,
                "color_channels": len(img.getbands())
                if hasattr(img, "getbands")
                else None,
                # EXIF information
                "camera_make": "",
                "camera_model": "",
                "datetime_taken": "",
                "orientation": "",
                "flash": "",
                "focal_length": "",
                "aperture": "",
                "shutter_speed": "",
                "iso": "",
                "white_balance": "",
                "metering_mode": "",
                "exposure_mode": "",
                "scene_type": "",
                "lens_model": "",
                "software": "",
                # Geolocation
                "latitude": "",
                "longitude": "",
                "altitude": "",
                "gps_timestamp": "",
                "gps_direction": "",
                "gps_speed": "",
                "location_name": "",
            }

            # Add file dates if from file path
            if isinstance(image_source, str):
                file_stats = os.stat(image_source)
                info["created_date"] = datetime.fromtimestamp(
                    file_stats.st_ctime
                ).strftime("%Y-%m-%d %H:%M:%S")
                info["modified_date"] = datetime.fromtimestamp(
                    file_stats.st_mtime
                ).strftime("%Y-%m-%d %H:%M:%S")
            else:
                info["created_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                info["modified_date"] = info["created_date"]

            # Extract EXIF data
            exif_data = img._getexif()
            if exif_data:
                # Process standard EXIF tags
                for tag_id, value in exif_data.items():
                    tag = TAGS.get(tag_id, tag_id)

                    if tag == "Make":
                        info["camera_make"] = str(value).strip()
                    elif tag == "Model":
                        info["camera_model"] = str(value).strip()
                    elif tag == "DateTime":
                        info["datetime_taken"] = str(value)
                    elif tag == "Orientation":
                        orientations = {
                            1: "Normal",
                            2: "Mirrored horizontal",
                            3: "Rotated 180°",
                            4: "Mirrored vertical",
                            5: "Mirrored horizontal, rotated 90° CCW",
                            6: "Rotated 90° CW",
                            7: "Mirrored horizontal, rotated 90° CW",
                            8: "Rotated 90° CCW",
                        }
                        info["orientation"] = orientations.get(
                            value, f"Unknown ({value})"
                        )
                    elif tag == "Flash":
                        info["flash"] = "Yes" if value & 1 else "No"
                    elif tag == "FocalLength":
                        if isinstance(value, tuple) and len(value) == 2:
                            info["focal_length"] = f"{value[0] / value[1]:.1f}mm"
                        else:
                            info["focal_length"] = f"{value}mm"
                    elif tag == "FNumber":
                        if isinstance(value, tuple) and len(value) == 2:
                            info["aperture"] = f"f/{value[0] / value[1]:.1f}"
                        else:
                            info["aperture"] = f"f/{value}"
                    elif tag == "ExposureTime":
                        if isinstance(value, tuple) and len(value) == 2:
                            if value[0] == 1:
                                info["shutter_speed"] = f"1/{value[1]}s"
                            else:
                                info["shutter_speed"] = f"{value[0] / value[1]:.2f}s"
                        else:
                            info["shutter_speed"] = f"{value}s"
                    elif tag == "ISOSpeedRatings":
                        info["iso"] = str(value)
                    elif tag == "WhiteBalance":
                        wb_modes = {0: "Auto", 1: "Manual"}
                        info["white_balance"] = wb_modes.get(
                            value, f"Unknown ({value})"
                        )
                    elif tag == "MeteringMode":
                        metering_modes = {
                            0: "Unknown",
                            1: "Average",
                            2: "Center-weighted average",
                            3: "Spot",
                            4: "Multi-spot",
                            5: "Pattern",
                            6: "Partial",
                        }
                        info["metering_mode"] = metering_modes.get(
                            value, f"Unknown ({value})"
                        )
                    elif tag == "ExposureMode":
                        exposure_modes = {0: "Auto", 1: "Manual", 2: "Auto bracket"}
                        info["exposure_mode"] = exposure_modes.get(
                            value, f"Unknown ({value})"
                        )
                    elif tag == "SceneType":
                        info["scene_type"] = (
                            "Directly photographed"
                            if value == 1
                            else f"Unknown ({value})"
                        )
                    elif tag == "LensModel":
                        info["lens_model"] = str(value).strip()
                    elif tag == "Software":
                        info["software"] = str(value).strip()
                    elif tag == "GPSInfo":
                        # Process GPS information
                        gps_info = extract_gps_info(value)
                        info.update(gps_info)

            # Remove empty fields for cleaner result
            info = {k: v for k, v in info.items() if v != ""}

            _logger.info(f"Successfully extracted image info from: {filename}")
            return info

    except Exception as e:
        _logger.error(f"Error processing image info: {str(e)}")
        return {"error": f"Error processing image: {str(e)}"}


def extract_gps_info(gps_data):
    """Extract GPS information from EXIF data.

    Converts GPS coordinates to decimal degrees, handles altitude reference, and extracts timestamp, direction, speed.

    Args:
        gps_data (dict): GPS data from EXIF tags.

    Returns:
        dict: Geolocation info with latitude, longitude, altitude, etc.

    Example:
        >>> from fbpyutils.image import extract_gps_info
        >>> gps_data = {'GPSLatitude': ((37, 0, 0), 1), 'GPSLatitudeRef': 'N', ...}
        >>> gps = extract_gps_info(gps_data)
        >>> gps
        {
            'latitude': '37.000000',
            'longitude': '-122.000000',
            'altitude': '10.00m',
            'gps_timestamp': '2023:01:01 12:00:00 UTC',
            ...
        }
    """
    gps_info = {
        "latitude": "",
        "longitude": "",
        "altitude": "",
        "gps_timestamp": "",
        "gps_direction": "",
        "gps_speed": "",
        "location_name": "",
    }

    if not gps_data:
        return gps_info

    try:
        # Convert GPS data to readable format
        gps_dict = {}
        for tag_id, value in gps_data.items():
            tag = GPSTAGS.get(tag_id, tag_id)
            gps_dict[tag] = value

        # Extract latitude
        if "GPSLatitude" in gps_dict and "GPSLatitudeRef" in gps_dict:
            lat = gps_dict["GPSLatitude"]
            lat_ref = gps_dict["GPSLatitudeRef"]
            latitude = convert_to_degrees(lat)
            if lat_ref == "S":
                latitude = -latitude
            gps_info["latitude"] = f"{latitude:.6f}"

        # Extract longitude
        if "GPSLongitude" in gps_dict and "GPSLongitudeRef" in gps_dict:
            lon = gps_dict["GPSLongitude"]
            lon_ref = gps_dict["GPSLongitudeRef"]
            longitude = convert_to_degrees(lon)
            if lon_ref == "W":
                longitude = -longitude
            gps_info["longitude"] = f"{longitude:.6f}"

        # Extract altitude
        if "GPSAltitude" in gps_dict:
            alt = gps_dict["GPSAltitude"]
            if isinstance(alt, tuple) and len(alt) == 2:
                altitude = alt[0] / alt[1]
                alt_ref = gps_dict.get("GPSAltitudeRef", 0)
                if alt_ref == 1:
                    altitude = -altitude
                gps_info["altitude"] = f"{altitude:.2f}m"

        # Extract GPS timestamp
        if "GPSTimeStamp" in gps_dict and "GPSDateStamp" in gps_dict:
            time_stamp = gps_dict["GPSTimeStamp"]
            date_stamp = gps_dict["GPSDateStamp"]
            if len(time_stamp) == 3:
                hours = int(time_stamp[0])
                minutes = int(time_stamp[1])
                seconds = int(time_stamp[2])
                gps_info["gps_timestamp"] = (
                    f"{date_stamp} {hours:02d}:{minutes:02d}:{seconds:02d} UTC"
                )

        # Extract direction
        if "GPSImgDirection" in gps_dict:
            direction = gps_dict["GPSImgDirection"]
            if isinstance(direction, tuple) and len(direction) == 2:
                direction_degrees = direction[0] / direction[1]
                gps_info["gps_direction"] = f"{direction_degrees:.1f}°"

        # Extract speed
        if "GPSSpeed" in gps_dict:
            speed = gps_dict["GPSSpeed"]
            if isinstance(speed, tuple) and len(speed) == 2:
                speed_val = speed[0] / speed[1]
                speed_ref = gps_dict.get("GPSSpeedRef", "K")
                unit = {"K": "km/h", "M": "mph", "N": "knots"}.get(speed_ref, "km/h")
                gps_info["gps_speed"] = f"{speed_val:.1f} {unit}"

        # Extract location name (if available)
        if "GPSAreaInformation" in gps_dict:
            gps_info["location_name"] = str(gps_dict["GPSAreaInformation"])

    except Exception:
        # If there's an error processing GPS, return empty dict
        pass

    return gps_info


def convert_to_degrees(value):
    """Convert GPS coordinates from DMS (degrees, minutes, seconds) to decimal degrees.

    Handles rational fractions in EXIF GPS data.

    Args:
        value (tuple): Tuple of (degrees, minutes, seconds), each possibly a rational tuple.

    Returns:
        float: Decimal degrees value.

    Example:
        >>> from fbpyutils.image import convert_to_degrees
        >>> dms = ((37, 0, 0), (46, 0, 0), (29, 0, 0))  # 37°46'29"
        >>> convert_to_degrees(dms)
        37.774722
    """
    if len(value) != 3:
        return 0.0

    degrees = value[0]
    minutes = value[1]
    seconds = value[2]

    # Convert fractions to decimal
    if isinstance(degrees, tuple):
        degrees = degrees[0] / degrees[1]
    if isinstance(minutes, tuple):
        minutes = minutes[0] / minutes[1]
    if isinstance(seconds, tuple):
        seconds = seconds[0] / seconds[1]

    return degrees + (minutes / 60.0) + (seconds / 3600.0)


def resize_image(
    image_source: Union[str, bytes],
    width: int,
    height: int,
    maintain_aspect_ratio: bool = True,
    quality: int = 85,
) -> bytes:
    """Resize an image to specified dimensions and return as JPEG bytes.

    Uses LANCZOS resampling. Maintains aspect ratio by default, adjusting the larger dimension.
    Converts RGBA/P to RGB with white background for JPEG compatibility.

    Args:
        image_source (Union[str, bytes]): Path to image file or image bytes.
        width (int): Target width in pixels.
        height (int): Target height in pixels.
        maintain_aspect_ratio (bool): If True, preserves aspect ratio. Defaults to True.
        quality (int): JPEG quality (1-100). Defaults to 85.

    Returns:
        bytes: Resized image as JPEG byte array.

    Raises:
        ValueError: If dimensions <=0, quality out of range, or image processing fails.

    Example:
        >>> from fbpyutils.image import resize_image
        >>> resized = resize_image('/path/to/large.jpg', width=800, height=600, maintain_aspect_ratio=True)
        >>> len(resized) > 0
        True
        # Resizes maintaining aspect ratio, outputs JPEG bytes.
    """
    start_time = perf_counter()

    _logger.info(
        f"Image resize initiated: target={width}x{height}, maintain_ratio={maintain_aspect_ratio}, quality={quality}"
    )

    try:
        # Validate dimensions
        if width <= 0 or height <= 0:
            _logger.error(f"Invalid dimensions: width={width}, height={height}")
            raise ValueError("Width and height must be positive integers")

        if quality < 1 or quality > 100:
            _logger.error(f"Invalid quality value: {quality} (must be 1-100)")
            raise ValueError("Quality must be between 1 and 100")

        # Load image using utility function
        img, filename, file_size = load_image_from_source(image_source)

        with img:
            original_width, original_height = img.size
            original_size_mb = file_size / (1024 * 1024)

            _logger.info(
                f"Loaded image '{filename}': original_size={original_width}x{original_height}, "
                f"file_size={original_size_mb:.2f}MB"
            )

            if maintain_aspect_ratio:
                # Calculate aspect ratios
                aspect_ratio = original_width / original_height
                target_ratio = width / height

                if target_ratio > aspect_ratio:
                    # Target is wider, adjust width based on height
                    new_height = height
                    new_width = int(height * aspect_ratio)
                else:
                    # Target is taller, adjust height based on width
                    new_width = width
                    new_height = int(width / aspect_ratio)
            else:
                new_width, new_height = width, height

            # Check if resizing is needed
            if new_width == original_width and new_height == original_height:
                _logger.info("No resizing needed - dimensions match target")
                return img.tobytes() if hasattr(img, "tobytes") else None

            # Resize image using high-quality resampling
            resized_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)

            # Convert to RGB if necessary for JPEG
            mode_changed = False
            if resized_img.mode in ("RGBA", "LA", "P"):
                # Create white background for transparency
                background = Image.new("RGB", resized_img.size, (255, 255, 255))
                if resized_img.mode == "P":
                    resized_img = resized_img.convert("RGBA")
                background.paste(
                    resized_img,
                    mask=resized_img.split()[-1]
                    if resized_img.mode in ("RGBA", "LA")
                    else None,
                )
                resized_img = background
                mode_changed = True

            # Save to bytes
            output_buffer = io.BytesIO()
            resized_img.save(
                output_buffer, format="JPEG", quality=quality, optimize=True
            )
            image_bytes = output_buffer.getvalue()
            output_size_mb = len(image_bytes) / (1024 * 1024)

            duration = perf_counter() - start_time

            _logger.info(
                f"Image resize completed successfully: '{filename}' -> {new_width}x{new_height}, "
                f"compression_ratio={output_size_mb / original_size_mb:.2f}, "
                f"output_size={output_size_mb:.2f}MB, duration={duration:.2f}s"
            )

            return image_bytes

    except ValueError as e:
        _logger.error(f"Invalid parameters for image resize: {str(e)}")
        raise
    except Exception as e:
        _logger.error(
            f"Error resizing image '{filename if 'filename' in locals() else 'unknown'}': {str(e)}"
        )
        raise ValueError(f"Error resizing image: {str(e)}")


def enhance_image_for_ocr(
    image_source: Union[str, bytes], contrast_factor: float = 2.0, threshold: int = 128
) -> bytes:
    """Enhance image for better OCR accuracy using multiple preprocessing techniques.

    Steps: Grayscale conversion, contrast enhancement, sharpening, noise reduction (median filter),
    and binarization (thresholding). Outputs as PNG for binary image preservation.

    Args:
        image_source (Union[str, bytes]): Path to image file or image bytes.
        contrast_factor (float): Multiplier for contrast enhancement. Defaults to 2.0.
        threshold (int): Binarization threshold (0-255). Defaults to 128.

    Returns:
        bytes: Enhanced binary image as PNG byte array.

    Raises:
        ValueError: If threshold out of range (0-255) or contrast_factor <=0, or processing fails.

    Example:
        >>> from fbpyutils.image import enhance_image_for_ocr
        >>> enhanced = enhance_image_for_ocr('/path/to/scanned_doc.jpg', contrast_factor=1.5, threshold=140)
        >>> len(enhanced) > 0
        True
        # Produces binarized PNG suitable for OCR.
    """
    _logger.info("Enhancing image for OCR processing")

    try:
        # Validate parameters
        if threshold < 0 or threshold > 255:
            raise ValueError("Threshold must be between 0 and 255")

        if contrast_factor <= 0:
            raise ValueError("Contrast factor must be positive")

        # Load image using utility function
        img, filename, file_size = load_image_from_source(image_source)

        with img:
            # Convert to RGB if necessary
            if img.mode != "RGB":
                img = img.convert("RGB")

            # Step 1: Convert to grayscale
            grayscale = img.convert("L")

            # Step 2: Enhance contrast
            enhancer = ImageEnhance.Contrast(grayscale)
            enhanced = enhancer.enhance(contrast_factor)

            # Step 3: Sharpen the image
            sharpened = enhanced.filter(ImageFilter.SHARPEN)

            # Step 4: Apply median filter to reduce noise
            denoised = sharpened.filter(ImageFilter.MedianFilter(size=3))

            # Step 5: Apply threshold/binarization
            enhanced = denoised.point(lambda x: 0 if x < threshold else 255, mode="1")

            # Save to bytes
            output_buffer = io.BytesIO()
            enhanced.save(output_buffer, format="PNG", optimize=True)
            image_bytes = output_buffer.getvalue()

            _logger.info(
                f"Image enhanced successfully for OCR. New size: {len(image_bytes)} bytes"
            )
            return image_bytes

    except Exception as e:
        _logger.error(f"Error enhancing image for OCR: {str(e)}")
        raise ValueError(f"Error enhancing image for OCR: {str(e)}")
