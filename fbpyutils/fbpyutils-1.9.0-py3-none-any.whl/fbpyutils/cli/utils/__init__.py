"""
Utility Functions for the FBPyUtils Command-Line Interface

This module provides shared utility functions for the FBPyUtils CLI, offering
consistent output formatting and error handling across all command groups. These
utilities ensure a uniform user experience and proper error reporting throughout
the CLI application.

The module provides two primary utilities:

* **Output Formatting**: The format_output function converts data structures into
  various output formats (text, JSON, CSV) for flexible command output presentation.

* **Error Handling**: The handle_error function provides consistent error message
  formatting and logging across all CLI operations for proper error reporting.

Key Features:
-------------
* **Format Flexibility**: Support for multiple output formats (txt, json, csv)
* **Type Handling**: Automatic conversion of complex data types for output formatting
* **Error Consistency**: Unified error message formatting across all commands
* **Logging Integration**: Automatic error logging with appropriate severity levels
* **Date/Time Support**: Custom JSON encoder for datetime object serialization
* **Stream Output**: CSV output using StringIO for memory efficiency

Dependencies:
-------------
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Import utilities for use in command groups:

>>> from fbpyutils.cli.utils import format_output, handle_error
>>> data = {'name': 'Alice', 'age': 30}
>>> format_output(data, 'json')
'{\n  "name": "Alice",\n  "age": 30\n}'

Format output in different formats:

>>> from fbpyutils.cli.utils import format_output
>>> data = [{'name': 'Alice', 'age': 30}, {'name': 'Bob', 'age': 25}]
>>> format_output(data, 'json')
# Returns JSON formatted string
>>> format_output(data, 'csv')
# Returns CSV formatted string
>>> format_output(data, 'txt')
# Returns text formatted string

Handle errors consistently:

>>> from fbpyutils.cli.utils import handle_error
>>> try:
...     # Some operation that may fail
...     pass
... except Exception as e:
...     handle_error(e, "Operation failed")
# Logs error and displays message to stderr

Notes:
------
* All utilities are imported and made available through this module
* The __all__ list defines the public API for the CLI utilities
* format_output handles complex data types including datetime objects
* handle_error integrates with the logging system for error tracking
* These utilities are used across all command groups for consistency

Cross-References:
-----------------
* See `fbpyutils.cli.utils.output_formatter` for output formatting implementation
* See `fbpyutils.cli.utils.error_handler` for error handling implementation
* See `fbpyutils.cli.main` for the main CLI entry point
* See `fbpyutils.logging` for logging integration details
"""

from .output_formatter import format_output
from .error_handler import handle_error

__all__ = ["format_output", "handle_error"]
