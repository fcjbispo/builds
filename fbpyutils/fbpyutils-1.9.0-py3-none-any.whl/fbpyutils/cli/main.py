"""
Main Entry Point for the FBPyUtils Command-Line Interface

This module provides the primary CLI entry point for the FBPyUtils library, offering
command-line access to all utility modules through a unified interface. The CLI is built
using Typer and provides rich formatting, automatic help generation, and consistent
error handling across all commands.

The module offers three primary capabilities:

* **Command Group Management**: Organizes CLI commands into logical groups (calendar,
  datetime, file, image, mailbox, ofx, process, string, uuid, xlsx) for intuitive
  navigation and usage.

* **Version Information**: Provides version display functionality with automatic
  environment configuration and graceful exit handling.

* **Error Handling**: Centralized error handling with consistent error messages and
  logging integration for troubleshooting and debugging.

Key Features:
-------------
* **Rich Formatting**: Uses Typer's rich markup mode for enhanced help text display
* **Automatic Help Generation**: Command-specific help generated automatically from docstrings
* **Version Display**: Quick access to library version information via --version flag
* **Consistent Error Handling**: Unified error handling across all CLI operations
* **Environment Integration**: Automatic initialization of fbpyutils environment and logging
* **Modular Design**: Each command group is a separate module for maintainability

Dependencies:
-------------
* `typer`: Modern CLI framework with rich formatting and automatic help generation
* `fbpyutils`: Main library for utility functions and configuration management
* `fbpyutils.cli.utils.error_handler`: Error handling utilities for CLI operations
* `fbpyutils.cli.groups`: Command group modules for each utility category

Usage Examples:
---------------
Display version information:

>>> fbpyutils --version
fbpyutils version 1.9.0

Display help for main CLI:

>>> fbpyutils --help
Usage: fbpyutils [OPTIONS] COMMAND [ARGS]...
  A CLI client for the fbpyutils library.

Display help for specific command group:

>>> fbpyutils calendar --help
Usage: fbpyutils calendar [OPTIONS] COMMAND [ARGS]...
  Commands for calendar manipulation.

Use calendar commands:

>>> fbpyutils calendar get-range --start-date 2023-01-01 --end-date 2023-01-31
# Generates calendar for January 2023

Use datetime commands:

>>> fbpyutils datetime delta --start-date 2023-01-01 --end-date 2023-01-31
# Calculates time delta between dates

Use file commands:

>>> fbpyutils file find --pattern "*.py" --path /home/user/project
# Finds all Python files in directory

Notes:
------
* The CLI automatically initializes fbpyutils with default configuration
* All commands support --help flag for detailed usage information
* Error messages are logged and displayed consistently across all commands
* Version information is retrieved from the environment configuration
* The CLI uses rich formatting for enhanced readability in terminal environments

Error Handling:
---------------
* All exceptions are caught and logged with critical severity
* Error messages are displayed to stderr for proper error stream handling
* The handle_error utility ensures consistent error formatting
* Critical errors trigger proper exit codes for shell integration

Cross-References:
-----------------
* See `fbpyutils.cli.groups.calendar` for calendar manipulation commands
* See `fbpyutils.cli.groups.datetime` for date/time manipulation commands
* See `fbpyutils.cli.groups.file` for file system operations
* See `fbpyutils.cli.groups.image` for image processing commands
* See `fbpyutils.cli.groups.mailbox` for MBOX email processing commands
* See `fbpyutils.cli.groups.ofx` for OFX financial data processing commands
* See `fbpyutils.cli.groups.process` for parallel/serial process execution commands
* See `fbpyutils.cli.groups.string` for string manipulation commands
* See `fbpyutils.cli.groups.uuid` for UUID generation commands
* See `fbpyutils.cli.groups.xlsx` for Excel file processing commands
* See `fbpyutils.cli.utils.error_handler` for error handling utilities
* See `typer` for CLI framework documentation
"""

import typer
import fbpyutils
from fbpyutils import get_env
from fbpyutils.cli.utils.error_handler import handle_error

# Import command groups
from fbpyutils.cli.groups import (
    calendar,
    datetime,
    file,
    image,
    mailbox,
    ofx,
    process,
    string,
    uuid,
    xlsx,
)

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app
app = typer.Typer(
    name="fbpyutils",
    help="A CLI client for the fbpyutils library.",
    rich_markup_mode="rich",
)

# Add version
app.add_typer(calendar.app, name="calendar")
app.add_typer(datetime.app, name="datetime")
app.add_typer(file.app, name="file")
app.add_typer(image.app, name="image")
app.add_typer(mailbox.app, name="mailbox")
app.add_typer(ofx.app, name="ofx")
app.add_typer(process.app, name="process")
app.add_typer(string.app, name="string")
app.add_typer(uuid.app, name="uuid")
app.add_typer(xlsx.app, name="xlsx")


def version_callback(value: bool):
    """
    Callback function to display version information and exit.

    This function is called when the --version flag is provided. It retrieves
    the version from the environment configuration, displays it to the user,
    and exits the application with a success status code.

    Parameters
    ----------
    value : bool
        Flag value indicating whether version display was requested.
        True when --version flag is provided, False otherwise.

    Returns
    -------
    None
        This function does not return a value. It displays the version and
        exits the application.

    Raises
    ------
    typer.Exit
        Always raised to exit the application after displaying version.

    Examples
    --------
    Display version from command line:

    >>> fbpyutils --version
    fbpyutils version 1.9.0

    Notes
    -----
    * This function is registered as a callback for the --version option
    * The version is retrieved from the environment configuration
    * The function uses typer.Exit() to ensure clean application termination
    * The callback is marked as eager to execute before other command processing

    See Also
    --------
    get_env : Returns the environment configuration containing version information
    typer.Exit : Typer's exit mechanism for CLI applications
    """
    if value:
        typer.echo(f"fbpyutils version {get_env().APP.version}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """
    Main callback function for the FBPyUtils CLI application.

    This function serves as the entry point callback for the CLI application.
    It handles global options like --version and provides the main application
    context for all command groups. The callback is executed before any
    subcommand processing.

    Parameters
    ----------
    version : bool, default=False
        Flag to display version information and exit. When True, the
        version_callback function is invoked to display the version and
        terminate the application. This option is eager, meaning it is
        processed before any other command-line arguments.

    Returns
    -------
    None
        This function does not return a value. It serves as a callback
        for the Typer application framework.

    Raises
    ------
    typer.Exit
        Raised by version_callback when --version flag is provided.

    Examples
    --------
    Display version:

    >>> fbpyutils --version
    fbpyutils version 1.9.0

    Display help:

    >>> fbpyutils --help
    Usage: fbpyutils [OPTIONS] COMMAND [ARGS]...
      A CLI client for the fbpyutils library.

    Use command groups:

    >>> fbpyutils calendar get-range --start-date 2023-01-01 --end-date 2023-01-31
    >>> fbpyutils file find --pattern "*.py" --path /home/user/project

    Notes
    -----
    * This callback is executed before any subcommand processing
    * The --version flag is eager and takes precedence over other options
    * All command groups are registered with the main Typer app
    * The callback uses pass as it primarily serves as a container for options
    * Error handling is managed at the module level in the __main__ block

    See Also
    --------
    version_callback : Callback function for version display
    typer.Typer : Main Typer application class
    typer.Option : Option decorator for command-line arguments
    """
    pass


if __name__ == "__main__":
    try:
        app()
    except Exception as e:
        logger.critical(f"Critical error in CLI: {e}")
        handle_error(e, "Critical error occurred")
