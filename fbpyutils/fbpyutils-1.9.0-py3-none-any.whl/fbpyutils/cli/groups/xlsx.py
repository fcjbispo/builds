"""
Excel (XLSX) Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for Excel file manipulation
and processing. The XLSX commands allow users to list sheet names and read sheet
content from Excel files with flexible output formatting and file output options.

The module provides two primary commands:

* **list-sheets**: Retrieve the names of all sheets from an Excel file
* **read-sheet**: Read the content of a specific sheet from an Excel file

Key Features:
-------------
* **Sheet Listing**: Retrieve all sheet names from Excel files
* **Sheet Reading**: Read content from specific sheets
* **Multiple Formats**: Support for txt, json, and csv output formats
* **File Output**: Optional output to file for saving sheet content
* **Tabular Data**: Proper handling of tabular data structures
* **Flexible Output**: Support for different output formats for different use cases
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for Excel functionality
* `fbpyutils.xlsx`: Excel file processing functions
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities
* `json`: Standard library JSON encoding and decoding
* `csv`: Standard library CSV writing

Usage Examples:
---------------
List all sheets in Excel file:

>>> fbpyutils xlsx list-sheets --file ./data.xlsx
# Outputs list of sheet names

List sheets in JSON format:

>>> fbpyutils xlsx list-sheets --file ./data.xlsx --output-format json
# Outputs sheet names in JSON format

Read sheet content:

>>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1"
# Outputs sheet content in text format

Read sheet and save to file:

>>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1" --output-file ./output.json
# Saves sheet content to output.json

Read sheet in CSV format:

>>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1" --output-format csv
# Outputs sheet content in CSV format

Command Help:
-------------
Display help for XLSX commands:

>>> fbpyutils xlsx --help
# Shows all available XLSX commands

Display help for list-sheets command:

>>> fbpyutils xlsx list-sheets --help
# Shows detailed help for the list-sheets command

Notes:
------
* Excel files use the .xlsx format (Office Open XML)
* Sheet names are case-sensitive
* Sheet content is returned as a list of lists (rows and cells)
* Text format uses tab-separated values for readability
* JSON format includes all data with proper serialization
* CSV format is suitable for spreadsheet applications
* Output file is created with UTF-8 encoding
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid Excel file: Error message if file is not a valid Excel format
* Sheet not found: Error message if sheet name does not exist
* File not found: Error message if file path does not exist
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.xlsx` for Excel functionality implementation
* See `fbpyutils.xlsx.get_sheet_names` for sheet listing function
* See `fbpyutils.xlsx.get_sheet_by_name` for sheet reading function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for xlsx commands
app = typer.Typer(
    name="xlsx", help="Commands for Excel file manipulation.", rich_markup_mode="rich"
)


@app.command("list-sheets")
def list_sheets_cmd(
    file: str = typer.Option(..., "--file", help="Path to the Excel file."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Retrieve the names of all sheets from an Excel file.

    This command lists all sheet names in the specified Excel file. The sheet
    names can be output in various formats for further processing or display.

    Parameters
    ----------
    file : str
        The path to the Excel file (.xlsx format). This is a required parameter
        and must be a valid Excel file path.

    output_format : str, default="txt"
        The output format for the sheet names. Supported formats:
        * "txt" - Human-readable text format (one sheet name per line)
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the sheet names to
        stdout.

    Raises
    ------
    ValueError
        If the Excel file is invalid or cannot be read.

    Examples
    --------
    List all sheets:

    >>> fbpyutils xlsx list-sheets --file ./data.xlsx
    # Outputs list of sheet names

    List sheets in JSON format:

    >>> fbpyutils xlsx list-sheets --file ./data.xlsx --output-format json
    # Outputs sheet names in JSON format

    List sheets in CSV format:

    >>> fbpyutils xlsx list-sheets --file ./data.xlsx --output-format csv
    # Outputs sheet names in CSV format

    Notes
    -----
    * Excel files use the .xlsx format (Office Open XML)
    * Sheet names are case-sensitive
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.xlsx.get_sheet_names : Sheet listing function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Listing sheets from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_names

        result = get_sheet_names(file)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Sheets listed successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to list sheets")


@app.command("read-sheet")
def read_sheet_cmd(
    file: str = typer.Option(..., "--file", help="Path to the Excel file."),
    sheet_name: str = typer.Option(
        ..., "--sheet-name", help="Name of the sheet to read."
    ),
    output_file: str = typer.Option(
        None, "--output-file", help="Path to save the sheet content (optional)."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Read the content of a specific sheet from an Excel file.

    This command reads the content of the specified sheet from an Excel file.
    The sheet content can be output to stdout or saved to a file in various
    formats including text, JSON, and CSV.

    Parameters
    ----------
    file : str
        The path to the Excel file (.xlsx format). This is a required parameter
        and must be a valid Excel file path.

    sheet_name : str
        The name of the sheet to read. This is a required parameter and must
        match an existing sheet name in the Excel file. Sheet names are
        case-sensitive.

    output_file : Optional[str], default=None
        The output file path to save the sheet content. If not specified, the
        content is output to stdout.

    output_format : str, default="txt"
        The output format for the sheet content. Supported formats:
        * "txt" - Human-readable text format (tab-separated values)
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the sheet content to
        stdout or saves it to the specified output file.

    Raises
    ------
    ValueError
        If the Excel file is invalid, the sheet does not exist, or the output
        file cannot be written.

    Examples
    --------
    Read sheet content:

    >>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1"
    # Outputs sheet content in text format

    Read sheet and save to file:

    >>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1" --output-file ./output.json
    # Saves sheet content to output.json

    Read sheet in CSV format:

    >>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1" --output-format csv
    # Outputs sheet content in CSV format

    Read sheet in JSON format:

    >>> fbpyutils xlsx read-sheet --file ./data.xlsx --sheet-name "Sheet1" --output-format json
    # Outputs sheet content in JSON format

    Notes
    -----
    * Sheet content is returned as a list of lists (rows and cells)
    * Text format uses tab-separated values for readability
    * JSON format includes all data with proper serialization
    * CSV format is suitable for spreadsheet applications
    * Output file is created with UTF-8 encoding
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.xlsx.get_sheet_by_name : Sheet reading function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Reading sheet '{sheet_name}' from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_by_name

        result = get_sheet_by_name(file, sheet_name)

        if output_file:
            import json

            with open(output_file, "w", encoding="utf-8") as f:
                if output_format == "json":
                    json.dump(result, f, indent=2, default=str)
                elif output_format == "csv":
                    import csv

                    writer = csv.writer(f)
                    for row in result:
                        writer.writerow(row)
                else:  # txt
                    for row in result:
                        f.write("\t".join(str(cell) for cell in row) + "\n")
            logger.info(f"Sheet content saved to {output_file}")
        else:
            formatted_result = format_output(result, output_format)
            typer.echo(formatted_result)

        logger.debug("Sheet read successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read sheet")
