"""
Datetime Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for datetime manipulation
and calculation. The datetime commands allow users to calculate time deltas,
apply timezones to naive datetimes, and calculate elapsed time between two
datetimes with flexible output formatting.

The module provides three primary commands:

* **delta**: Calculate time delta between two dates in months or years
* **apply-timezone**: Apply timezone to a naive datetime
* **elapsed**: Calculate elapsed time between two datetimes

Key Features:
-------------
* **Time Delta Calculation**: Calculate differences in months or years
* **Timezone Support**: Apply timezones to naive datetime objects
* **Elapsed Time**: Calculate precise elapsed time between datetimes
* **Flexible Output**: Support for txt, json, and csv output formats
* **Date Validation**: Automatic validation of datetime format
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for datetime functionality
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities
* `datetime`: Standard library date and time handling

Usage Examples:
---------------
Calculate time delta in months:

>>> fbpyutils datetime delta --date1 2024-01-01T00:00:00 --date2 2024-06-01T00:00:00 --unit months
# Outputs: 5

Calculate time delta in years:

>>> fbpyutils datetime delta --date1 2020-01-01T00:00:00 --date2 2024-01-01T00:00:00 --unit years
# Outputs: 4

Apply timezone to naive datetime:

>>> fbpyutils datetime apply-timezone --date-time 2024-01-01T12:00:00 --timezone America/Sao_Paulo
# Outputs: 2024-01-01T12:00:00-03:00

Calculate elapsed time:

>>> fbpyutils datetime elapsed --date1 2024-01-01T00:00:00 --date2 2024-01-01T12:30:45
# Outputs: 12 hours, 30 minutes, 45 seconds

Command Help:
-------------
Display help for datetime commands:

>>> fbpyutils datetime --help
# Shows all available datetime commands

Display help for delta command:

>>> fbpyutils datetime delta --help
# Shows detailed help for the delta command

Notes:
------
* Datetime format must be YYYY-MM-DDTHH:MM:SS (ISO 8601 format)
* Timezone names must be valid IANA timezone identifiers (e.g., 'America/Sao_Paulo')
* Delta calculation automatically orders dates (earlier date first)
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid datetime format: Clear error message indicating expected format
* Invalid timezone: Error message if timezone is not recognized
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.datetime` for datetime functionality implementation
* See `fbpyutils.datetime.delta` for time delta calculation function
* See `fbpyutils.datetime.apply_timezone` for timezone application function
* See `fbpyutils.datetime.elapsed_time` for elapsed time calculation function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error
from datetime import datetime as dt

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for datetime commands
app = typer.Typer(
    name="datetime", help="Commands for datetime manipulation.", rich_markup_mode="rich"
)


@app.command("delta")
def delta_cmd(
    date1: str = typer.Option(
        ..., "--date1", help="First datetime (YYYY-MM-DDTHH:MM:SS)."
    ),
    date2: str = typer.Option(
        ..., "--date2", help="Second datetime (YYYY-MM-DDTHH:MM:SS)."
    ),
    unit: str = typer.Option(
        "months", "--unit", help="Unit for delta calculation.", case_sensitive=False
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Calculate time delta between two dates in months or years.

    This command calculates the time difference between two datetimes in the
    specified unit (months or years). The command automatically orders the dates
    so that the earlier date is used as the start point for the calculation.

    Parameters
    ----------
    date1 : str
        The first datetime in YYYY-MM-DDTHH:MM:SS format. This is a required
        parameter and must be a valid datetime.

    date2 : str
        The second datetime in YYYY-MM-DDTHH:MM:SS format. This is a required
        parameter and must be a valid datetime.

    unit : str, default="months"
        The unit for delta calculation. Supported values:
        * "months" - Calculate delta in months
        * "years" - Calculate delta in years
        The unit is case-insensitive.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the formatted delta
        to stdout.

    Raises
    ------
    ValueError
        If the datetime format is invalid or if the unit is not supported.

    Examples
    --------
    Calculate delta in months:

    >>> fbpyutils datetime delta --date1 2024-01-01T00:00:00 --date2 2024-06-01T00:00:00 --unit months
    # Outputs: 5

    Calculate delta in years:

    >>> fbpyutils datetime delta --date1 2020-01-01T00:00:00 --date2 2024-01-01T00:00:00 --unit years
    # Outputs: 4

    Calculate delta with dates in reverse order:

    >>> fbpyutils datetime delta --date1 2024-06-01T00:00:00 --date2 2024-01-01T00:00:00 --unit months
    # Outputs: 5 (automatically orders dates)

    Notes
    -----
    * Datetime format must be YYYY-MM-DDTHH:MM:SS (ISO 8601 format)
    * The command automatically orders dates (earlier date first)
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.datetime.delta : Time delta calculation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Calculating delta between {date1} and {date2} in {unit}")

        # Parse datetimes
        dt1 = dt.fromisoformat(date1)
        dt2 = dt.fromisoformat(date2)

        # Import the delta function
        from fbpyutils.datetime import delta

        # Ensure dt2 is later than dt1 for delta calculation
        if dt2 < dt1:
            dt1, dt2 = dt2, dt1

        # Calculate delta
        result = delta(dt2, dt1, unit)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Delta calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate delta")


@app.command("apply-timezone")
def apply_timezone_cmd(
    date_time: str = typer.Option(
        ..., "--date-time", help="Naive datetime (YYYY-MM-DDTHH:MM:SS)."
    ),
    timezone: str = typer.Option(
        ..., "--timezone", help="Timezone name (e.g., 'America/Sao_Paulo')."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Apply timezone to a naive datetime.

    This command applies the specified timezone to a naive datetime object,
    converting it to a timezone-aware datetime. The timezone must be a valid
    IANA timezone identifier.

    Parameters
    ----------
    date_time : str
        The naive datetime in YYYY-MM-DDTHH:MM:SS format. This is a required
        parameter and must be a valid datetime.

    timezone : str
        The timezone name as an IANA timezone identifier (e.g., 'America/Sao_Paulo',
        'UTC', 'Europe/London'). This is a required parameter and must be a valid
        timezone.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the formatted timezone-
        aware datetime to stdout.

    Raises
    ------
    ValueError
        If the datetime format is invalid or if the timezone is not recognized.

    Examples
    --------
    Apply Sao Paulo timezone:

    >>> fbpyutils datetime apply-timezone --date-time 2024-01-01T12:00:00 --timezone America/Sao_Paulo
    # Outputs: 2024-01-01T12:00:00-03:00

    Apply UTC timezone:

    >>> fbpyutils datetime apply-timezone --date-time 2024-01-01T12:00:00 --timezone UTC
    # Outputs: 2024-01-01T12:00:00+00:00

    Apply London timezone:

    >>> fbpyutils datetime apply-timezone --date-time 2024-01-01T12:00:00 --timezone Europe/London
    # Outputs: 2024-01-01T12:00:00+00:00 (or +01:00 depending on DST)

    Notes
    -----
    * Datetime format must be YYYY-MM-DDTHH:MM:SS (ISO 8601 format)
    * Timezone names must be valid IANA timezone identifiers
    * The output includes the timezone offset
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.datetime.apply_timezone : Timezone application function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Applying timezone {timezone} to {date_time}")

        # Parse datetime
        dt_obj = dt.fromisoformat(date_time)

        # Import the apply_timezone function
        from fbpyutils.datetime import apply_timezone

        # Apply timezone
        result = apply_timezone(dt_obj, timezone)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Timezone applied successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to apply timezone")


@app.command("elapsed")
def elapsed_cmd(
    date1: str = typer.Option(
        ..., "--date1", help="Start datetime (YYYY-MM-DDTHH:MM:SS)."
    ),
    date2: str = typer.Option(
        ..., "--date2", help="End datetime (YYYY-MM-DDTHH:MM:SS)."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Calculate elapsed time between two datetimes.

    This command calculates the elapsed time between two datetimes, providing
    a human-readable representation of the time difference in hours, minutes,
    and seconds.

    Parameters
    ----------
    date1 : str
        The start datetime in YYYY-MM-DDTHH:MM:SS format. This is a required
        parameter and must be a valid datetime.

    date2 : str
        The end datetime in YYYY-MM-DDTHH:MM:SS format. This is a required
        parameter and must be a valid datetime. The end datetime should be
        after the start datetime.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the formatted elapsed
        time to stdout.

    Raises
    ------
    ValueError
        If the datetime format is invalid.

    Examples
    --------
    Calculate elapsed time:

    >>> fbpyutils datetime elapsed --date1 2024-01-01T00:00:00 --date2 2024-01-01T12:30:45
    # Outputs: 12 hours, 30 minutes, 45 seconds

    Calculate elapsed time for short duration:

    >>> fbpyutils datetime elapsed --date1 2024-01-01T00:00:00 --date2 2024-01-01T00:05:30
    # Outputs: 0 hours, 5 minutes, 30 seconds

    Calculate elapsed time for long duration:

    >>> fbpyutils datetime elapsed --date1 2024-01-01T00:00:00 --date2 2024-01-02T15:45:00
    # Outputs: 39 hours, 45 minutes, 0 seconds

    Notes
    -----
    * Datetime format must be YYYY-MM-DDTHH:MM:SS (ISO 8601 format)
    * The end datetime should be after the start datetime
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.datetime.elapsed_time : Elapsed time calculation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Calculating elapsed time between {date1} and {date2}")

        # Parse datetimes
        dt1 = dt.fromisoformat(date1)
        dt2 = dt.fromisoformat(date2)

        # Import the elapsed_time function
        from fbpyutils.datetime import elapsed_time

        # Calculate elapsed time (dt2 should be later than dt1)
        result = elapsed_time(dt2, dt1)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Elapsed time calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate elapsed time")
