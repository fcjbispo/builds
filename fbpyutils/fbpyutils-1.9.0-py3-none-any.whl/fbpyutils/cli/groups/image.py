"""
Image Processing Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for image processing and
analysis. The image commands allow users to extract image information, resize
images, and enhance images for OCR (Optical Character Recognition) with flexible
output formatting and configuration options.

The module provides three primary commands:

* **info**: Extract detailed information from an image including EXIF metadata
  and geolocation data.

* **resize**: Resize an image to specified dimensions with optional aspect ratio
  maintenance and quality control.

* **enhance-ocr**: Enhance image for better OCR accuracy using preprocessing
  techniques such as contrast enhancement and binarization.

Key Features:
-------------
* **Image Information**: Extract comprehensive metadata including EXIF and GPS data
* **Image Resizing**: Resize images with aspect ratio preservation and quality control
* **OCR Enhancement**: Preprocess images for improved OCR accuracy
* **Flexible Input**: Support for file paths and piped image bytes
* **Multiple Formats**: Support for various image formats (JPEG, PNG, etc.)
* **Quality Control**: Adjustable JPEG quality for resized images
* **Aspect Ratio**: Optional aspect ratio maintenance during resize
* **Flexible Output**: Support for txt, json, and csv output formats
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `os`: Standard library operating system interface
* `fbpyutils`: Main library for image functionality
* `fbpyutils.image`: Image processing functions
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Extract image information:

>>> fbpyutils image info --source ./photo.jpg
# Outputs image information in text format

Extract image information in JSON format:

>>> fbpyutils image info --source ./photo.jpg --output-format json
# Outputs image information in JSON format

Resize image with aspect ratio:

>>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --output-file ./resized.jpg
# Resizes image maintaining aspect ratio

Resize image without aspect ratio:

>>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --maintain-aspect-ratio false --output-file ./resized.jpg
# Resizes image to exact dimensions

Resize image with custom quality:

>>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --quality 95 --output-file ./resized.jpg
# Resizes image with high JPEG quality

Enhance image for OCR:

>>> fbpyutils image enhance-ocr --source ./document.jpg --output-file ./enhanced.jpg
# Enhances image for OCR with default settings

Enhance image with custom parameters:

>>> fbpyutils image enhance-ocr --source ./document.jpg --contrast-factor 2.5 --threshold 140 --output-file ./enhanced.jpg
# Enhances image with custom contrast and threshold

Command Help:
-------------
Display help for image commands:

>>> fbpyutils image --help
# Shows all available image commands

Display help for info command:

>>> fbpyutils image info --help
# Shows detailed help for the info command

Notes:
------
* Image source can be a file path or piped image bytes
* EXIF metadata includes camera settings, date/time, and GPS coordinates
* Aspect ratio maintenance ensures images are not distorted
* JPEG quality ranges from 1 (lowest) to 100 (highest)
* Contrast enhancement factor controls the intensity of contrast adjustment
* Binarization threshold determines the cutoff for black/white conversion
* Output directory is created automatically if it does not exist
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid image file: Error message if file is not a valid image
* Unsupported format: Error message if image format is not supported
* Invalid dimensions: Error message if width or height are invalid
* Invalid quality: Error message if quality is not in range 1-100
* Invalid threshold: Error message if threshold is not in range 0-255
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.image` for image functionality implementation
* See `fbpyutils.image.get_image_info` for image information extraction function
* See `fbpyutils.image.resize_image` for image resizing function
* See `fbpyutils.image.enhance_image_for_ocr` for OCR enhancement function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import os
import fbpyutils
from fbpyutils.image import (
    get_image_info,
    resize_image,
    enhance_image_for_ocr,
)
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

# Initialize logger
fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for image commands
app = typer.Typer(
    name="image",
    help="Commands for image processing and analysis.",
    rich_markup_mode="rich",
)


@app.command()
def info(
    source: str = typer.Option(
        ..., "--source", help="Path to image file or image bytes (for piped input)."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Extract detailed information from an image including EXIF metadata and geolocation.

    This command analyzes an image file and extracts comprehensive information
    including dimensions, format, EXIF metadata (camera settings, date/time),
    and GPS coordinates if available.

    Parameters
    ----------
    source : str
        The path to the image file or image bytes (for piped input). This is a
        required parameter and must be a valid image file path or base64-encoded
        image data.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the image information
        to stdout.

    Raises
    ------
    ValueError
        If the image file is invalid or cannot be processed.

    Examples
    --------
    Extract image information:

    >>> fbpyutils image info --source ./photo.jpg
    # Outputs image information in text format

    Extract image information in JSON format:

    >>> fbpyutils image info --source ./photo.jpg --output-format json
    # Outputs image information in JSON format

    Extract image information from piped input:

    >>> cat photo.jpg | fbpyutils image info --source -
    # Outputs image information from piped input

    Notes
    -----
    * Image source can be a file path or piped image bytes
    * EXIF metadata includes camera settings, date/time, and GPS coordinates
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.image.get_image_info : Image information extraction function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        info_data = get_image_info(source)
        if "error" in info_data:
            raise ValueError(info_data["error"])

        formatted_output = format_output(info_data, output_format)
        typer.echo(formatted_output)

    except Exception as e:
        handle_error(e, "Failed to extract image information")


@app.command()
def resize(
    source: str = typer.Option(
        ..., "--source", help="Path to image file or image bytes (for piped input)."
    ),
    width: int = typer.Option(..., "--width", help="Target width in pixels."),
    height: int = typer.Option(..., "--height", help="Target height in pixels."),
    maintain_aspect_ratio: bool = typer.Option(
        True, "--maintain-aspect-ratio", help="Maintain aspect ratio during resize."
    ),
    quality: int = typer.Option(85, "--quality", help="JPEG quality (1-100)."),
    output_file: str = typer.Option(
        ..., "--output-file", help="Path to save the resized image."
    ),
):
    """
    Resize an image to specified dimensions and save to file.

    This command resizes an image to the specified dimensions with optional
    aspect ratio maintenance and quality control. The resized image is saved
    to the specified output file.

    Parameters
    ----------
    source : str
        The path to the image file or image bytes (for piped input). This is a
        required parameter and must be a valid image file path or base64-encoded
        image data.

    width : int
        The target width in pixels. This is a required parameter and must be a
        positive integer.

    height : int
        The target height in pixels. This is a required parameter and must be a
        positive integer.

    maintain_aspect_ratio : bool, default=True
        If True, maintains the aspect ratio of the original image. The image
        will be scaled to fit within the specified dimensions while preserving
        the original aspect ratio.

    quality : int, default=85
        The JPEG quality for the output image, ranging from 1 (lowest quality)
        to 100 (highest quality). Default is 85.

    output_file : str
        The path to save the resized image. This is a required parameter. The
        output directory will be created if it does not exist.

    Returns
    -------
    None
        This function does not return a value. It saves the resized image to
        the specified output file.

    Raises
    ------
    ValueError
        If the image file is invalid, dimensions are invalid, or quality is
        not in the valid range.

    Examples
    --------
    Resize image with aspect ratio:

    >>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --output-file ./resized.jpg
    # Resizes image maintaining aspect ratio

    Resize image without aspect ratio:

    >>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --maintain-aspect-ratio false --output-file ./resized.jpg
    # Resizes image to exact dimensions

    Resize image with custom quality:

    >>> fbpyutils image resize --source ./photo.jpg --width 800 --height 600 --quality 95 --output-file ./resized.jpg
    # Resizes image with high JPEG quality

    Resize image from piped input:

    >>> cat photo.jpg | fbpyutils image resize --source - --width 800 --height 600 --output-file ./resized.jpg
    # Resizes image from piped input

    Notes
    -----
    * Aspect ratio maintenance ensures images are not distorted
    * JPEG quality ranges from 1 (lowest) to 100 (highest)
    * Output directory is created automatically if it does not exist
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.image.resize_image : Image resizing function
    handle_error : Error handling utility
    """
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Resize image
        resized_bytes = resize_image(
            source, width, height, maintain_aspect_ratio, quality
        )

        # Write to file
        with open(output_file, "wb") as f:
            f.write(resized_bytes)

        logger.info(f"Resized image saved to {output_file}")
        typer.echo(f"Image successfully resized and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to resize image")


@app.command()
def enhance_ocr(
    source: str = typer.Option(
        ..., "--source", help="Path to image file or image bytes (for piped input)."
    ),
    contrast_factor: float = typer.Option(
        2.0, "--contrast-factor", help="Contrast enhancement factor (default: 2.0)."
    ),
    threshold: int = typer.Option(
        128, "--threshold", help="Binarization threshold (0-255, default: 128)."
    ),
    output_file: str = typer.Option(
        ..., "--output-file", help="Path to save the enhanced image."
    ),
):
    """
    Enhance image for better OCR accuracy using preprocessing techniques.

    This command enhances an image for improved OCR (Optical Character Recognition)
    accuracy by applying contrast enhancement and binarization. These preprocessing
    techniques help improve text recognition accuracy.

    Parameters
    ----------
    source : str
        The path to the image file or image bytes (for piped input). This is a
        required parameter and must be a valid image file path or base64-encoded
        image data.

    contrast_factor : float, default=2.0
        The contrast enhancement factor. Higher values increase contrast more
        aggressively. Default is 2.0.

    threshold : int, default=128
        The binarization threshold for converting the image to black and white.
        Pixels with values above this threshold become white, below become black.
        Range is 0-255. Default is 128.

    output_file : str
        The path to save the enhanced image. This is a required parameter. The
        output directory will be created if it does not exist.

    Returns
    -------
    None
        This function does not return a value. It saves the enhanced image to
        the specified output file.

    Raises
    ------
    ValueError
        If the image file is invalid, threshold is not in range 0-255, or
        contrast_factor is invalid.

    Examples
    --------
    Enhance image for OCR with default settings:

    >>> fbpyutils image enhance-ocr --source ./document.jpg --output-file ./enhanced.jpg
    # Enhances image for OCR with default settings

    Enhance image with custom contrast:

    >>> fbpyutils image enhance-ocr --source ./document.jpg --contrast-factor 2.5 --output-file ./enhanced.jpg
    # Enhances image with higher contrast

    Enhance image with custom threshold:

    >>> fbpyutils image enhance-ocr --source ./document.jpg --threshold 140 --output-file ./enhanced.jpg
    # Enhances image with higher binarization threshold

    Enhance image with custom parameters:

    >>> fbpyutils image enhance-ocr --source ./document.jpg --contrast-factor 2.5 --threshold 140 --output-file ./enhanced.jpg
    # Enhances image with custom contrast and threshold

    Enhance image from piped input:

    >>> cat document.jpg | fbpyutils image enhance-ocr --source - --output-file ./enhanced.jpg
    # Enhances image from piped input

    Notes
    -----
    * Contrast enhancement factor controls the intensity of contrast adjustment
    * Binarization threshold determines the cutoff for black/white conversion
    * Threshold range is 0-255 (0 = all black, 255 = all white)
    * Output directory is created automatically if it does not exist
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.image.enhance_image_for_ocr : OCR enhancement function
    handle_error : Error handling utility
    """
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Enhance image
        enhanced_bytes = enhance_image_for_ocr(source, contrast_factor, threshold)

        # Write to file
        with open(output_file, "wb") as f:
            f.write(enhanced_bytes)

        logger.info(f"Enhanced image saved to {output_file}")
        typer.echo(f"Image successfully enhanced and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to enhance image for OCR")
