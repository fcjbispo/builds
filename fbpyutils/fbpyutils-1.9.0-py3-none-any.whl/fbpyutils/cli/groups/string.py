"""
String Manipulation Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for string manipulation
and text processing. The string commands allow users to generate UUIDs, calculate
string similarity, generate random strings, create hashes, normalize values,
translate special characters, normalize lists, and split strings with flexible
output formatting.

The module provides eight primary commands:

* **uuid**: Generate a standard UUID4 string
* **similarity**: Calculate similarity ratio between two strings
* **random**: Generate a random string with configurable options
* **hash**: Generate MD5 hash from a string
* **normalize-float**: Convert float to zero-padded string
* **translate-chars**: Translate special characters to basic counterparts
* **normalize-list**: Normalize a list of strings
* **split-by-lengths**: Split string by specified lengths

Key Features:
-------------
* **UUID Generation**: Generate standard UUID4 strings for unique identifiers
* **String Similarity**: Calculate similarity ratios using difflib
* **Random Strings**: Generate random strings with configurable options
* **Hash Generation**: Create MD5 hashes for string data
* **Float Normalization**: Convert floats to zero-padded strings
* **Character Translation**: Translate special characters to ASCII
* **List Normalization**: Normalize lists of strings with options
* **String Splitting**: Split strings by specified lengths
* **Flexible Output**: Support for txt, json, and csv output formats
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for string functionality
* `fbpyutils.string`: String manipulation functions
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Generate UUID:

>>> fbpyutils string uuid
# Outputs a UUID4 string

Calculate string similarity:

>>> fbpyutils string similarity --string1 "hello" --string2 "hello world"
# Outputs similarity ratio

Generate random string:

>>> fbpyutils string random --length 16 --include-digits --include-special
# Outputs random string with digits and special characters

Generate MD5 hash:

>>> fbpyutils string hash --input "hello world"
# Outputs MD5 hash

Normalize float:

>>> fbpyutils string normalize-float --value 3.14159 --size 6 --decimal-places 2
# Outputs: "003.14"

Translate special characters:

>>> fbpyutils string translate-chars --input "café"
# Outputs: "cafe"

Normalize list of strings:

>>> fbpyutils string normalize-list --names "John Doe,Jane Smith"
# Outputs normalized list

Split string by lengths:

>>> fbpyutils string split-by-lengths --input "abcdefghij" --lengths "3,4,3"
# Outputs: ["abc", "defg", "hij"]

Command Help:
-------------
Display help for string commands:

>>> fbpyutils string --help
# Shows all available string commands

Display help for uuid command:

>>> fbpyutils string uuid --help
# Shows detailed help for the uuid command

Notes:
------
* UUID4 generates random UUIDs suitable for most use cases
* Similarity ratio ranges from 0.0 (no similarity) to 1.0 (identical)
* Random strings can include letters, digits, and special characters
* MD5 is not cryptographically secure, use for non-security purposes
* Float normalization pads with zeros to achieve specified size
* Character translation converts accented and special characters to ASCII
* List normalization strips whitespace and optionally translates special characters
* String splitting uses specified lengths to partition the input string
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid parameters: Error message if parameters are invalid
* String processing errors: Comprehensive error logging with exception details
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.string` for string functionality implementation
* See `fbpyutils.string.uuid` for UUID generation function
* See `fbpyutils.string.similarity` for similarity calculation function
* See `fbpyutils.string.random_string` for random string generation function
* See `fbpyutils.string.hash_string` for hash generation function
* See `fbpyutils.string.normalize_value` for float normalization function
* See `fbpyutils.string.translate_special_chars` for character translation function
* See `fbpyutils.string.normalize_names` for list normalization function
* See `fbpyutils.string.split_by_lengths` for string splitting function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for string commands
app = typer.Typer(
    name="string", help="Commands for string manipulation.", rich_markup_mode="rich"
)


@app.command("uuid")
def uuid_cmd(
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate a standard UUID4 string.

    This command generates a random UUID4 (Universally Unique Identifier) string,
    which is suitable for most use cases requiring unique identifiers. UUID4
    generates random UUIDs with a very low probability of collision.

    Parameters
    ----------
    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the UUID4 string to
        stdout.

    Raises
    ------
    ValueError
        If UUID generation fails.

    Examples
    --------
    Generate UUID:

    >>> fbpyutils string uuid
    # Outputs a UUID4 string (e.g., "550e8400-e29b-41d4-a716-446655440000")

    Generate UUID in JSON format:

    >>> fbpyutils string uuid --output-format json
    # Outputs UUID in JSON format

    Notes
    -----
    * UUID4 generates random UUIDs suitable for most use cases
    * The probability of collision is extremely low
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.uuid : UUID generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.string import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@app.command("similarity")
def similarity_cmd(
    string1: str = typer.Option(..., "--string1", help="First string to compare."),
    string2: str = typer.Option(..., "--string2", help="Second string to compare."),
    ignore_case: bool = typer.Option(
        True, "--ignore-case", help="Ignore case during comparison."
    ),
    compress_spaces: bool = typer.Option(
        True, "--compress-spaces", help="Compress extra spaces."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Calculate similarity ratio between two strings.

    This command calculates the similarity ratio between two strings using the
    difflib SequenceMatcher algorithm. The ratio ranges from 0.0 (no similarity)
    to 1.0 (identical strings).

    Parameters
    ----------
    string1 : str
        The first string to compare. This is a required parameter.

    string2 : str
        The second string to compare. This is a required parameter.

    ignore_case : bool, default=True
        If True, ignores case differences during comparison. If False, case is
        considered in the comparison.

    compress_spaces : bool, default=True
        If True, compresses multiple spaces into a single space before comparison.
        If False, spaces are preserved as-is.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the similarity ratio
        to stdout.

    Raises
    ------
    ValueError
        If string comparison fails.

    Examples
    --------
    Calculate similarity:

    >>> fbpyutils string similarity --string1 "hello" --string2 "hello world"
    # Outputs similarity ratio (e.g., 0.625)

    Calculate similarity with case sensitivity:

    >>> fbpyutils string similarity --string1 "Hello" --string2 "hello" --ignore-case false
    # Outputs similarity ratio considering case

    Calculate similarity without space compression:

    >>> fbpyutils string similarity --string1 "hello  world" --string2 "hello world" --compress-spaces false
    # Outputs similarity ratio preserving spaces

    Notes
    -----
    * Similarity ratio ranges from 0.0 (no similarity) to 1.0 (identical)
    * The algorithm uses difflib SequenceMatcher
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.similarity : Similarity calculation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"Calculating similarity between strings (ignore_case: {ignore_case}, compress_spaces: {compress_spaces})"
        )

        from fbpyutils.string import similarity

        result = similarity(string1, string2, ignore_case, compress_spaces)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Similarity calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate similarity")


@app.command("random")
def random_cmd(
    length: int = typer.Option(32, "--length", help="Length of the random string."),
    include_digits: bool = typer.Option(
        True, "--include-digits", help="Include digits."
    ),
    include_special: bool = typer.Option(
        False, "--include-special", help="Include special characters."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate a random string.

    This command generates a random string of the specified length with
    configurable options for including digits and special characters. The
    string is suitable for use as passwords, tokens, or other random identifiers.

    Parameters
    ----------
    length : int, default=32
        The length of the random string to generate. Must be a positive integer.

    include_digits : bool, default=True
        If True, includes digits (0-9) in the random string. If False, only
        letters are used.

    include_special : bool, default=False
        If True, includes special characters (!@#$%^&* etc.) in the random
        string. If False, only alphanumeric characters are used.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the random string to
        stdout.

    Raises
    ------
    ValueError
        If length is not a positive integer.

    Examples
    --------
    Generate random string with default options:

    >>> fbpyutils string random
    # Outputs 32-character random string with letters and digits

    Generate random string with custom length:

    >>> fbpyutils string random --length 16
    # Outputs 16-character random string

    Generate random string with special characters:

    >>> fbpyutils string random --length 16 --include-digits --include-special
    # Outputs 16-character random string with letters, digits, and special characters

    Generate random string with letters only:

    >>> fbpyutils string random --length 16 --include-digits false
    # Outputs 16-character random string with letters only

    Notes
    -----
    * Random strings can include letters, digits, and special characters
    * The string is generated using cryptographically secure random methods
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.random_string : Random string generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"Generating random string of length {length} (include_digits: {include_digits}, include_special: {include_special})"
        )

        from fbpyutils.string import random_string

        result = random_string(length, include_digits, include_special)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Random string generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate random string")


@app.command("hash")
def hash_cmd(
    input: str = typer.Option(..., "--input", help="String to hash."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate MD5 hash from a string.

    This command generates an MD5 hash of the input string. The hash is a
    32-character hexadecimal string that uniquely represents the input data.
    Note: MD5 is not cryptographically secure and should not be used for
    security-sensitive applications.

    Parameters
    ----------
    input : str
        The string to hash. This is a required parameter.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the MD5 hash to stdout.

    Raises
    ------
    ValueError
        If hash generation fails.

    Examples
    --------
    Generate MD5 hash:

    >>> fbpyutils string hash --input "hello world"
    # Outputs MD5 hash (e.g., "5eb63bbbe01eeed093cb22bb8f5acdc3")

    Generate MD5 hash in JSON format:

    >>> fbpyutils string hash --input "hello world" --output-format json
    # Outputs MD5 hash in JSON format

    Notes
    -----
    * MD5 is not cryptographically secure, use for non-security purposes
    * The hash is a 32-character hexadecimal string
    * The same input always produces the same hash
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.hash_string : Hash generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.string import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@app.command("normalize-float")
def normalize_float_cmd(
    value: float = typer.Option(..., "--value", help="Float value to normalize."),
    size: int = typer.Option(4, "--size", help="Total length of output string."),
    decimal_places: int = typer.Option(
        2, "--decimal-places", help="Number of decimal places."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Convert float to zero-padded string.

    This command converts a float value to a zero-padded string with the
    specified total size and number of decimal places. This is useful for
    formatting numeric values for display or storage in fixed-width fields.

    Parameters
    ----------
    value : float
        The float value to normalize. This is a required parameter.

    size : int, default=4
        The total length of the output string, including the decimal point and
        decimal places. The string will be padded with zeros to achieve this
        length.

    decimal_places : int, default=2
        The number of decimal places to include in the output string.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the normalized string
        to stdout.

    Raises
    ------
    ValueError
        If the value cannot be normalized or parameters are invalid.

    Examples
    --------
    Normalize float:

    >>> fbpyutils string normalize-float --value 3.14159 --size 6 --decimal-places 2
    # Outputs: "003.14"

    Normalize float with custom size:

    >>> fbpyutils string normalize-float --value 12.5 --size 8 --decimal-places 3
    # Outputs: "0012.500"

    Normalize float in JSON format:

    >>> fbpyutils string normalize-float --value 3.14 --size 6 --decimal-places 2 --output-format json
    # Outputs normalized string in JSON format

    Notes
    -----
    * Float normalization pads with zeros to achieve specified size
    * The size includes the decimal point and decimal places
    * If the value is too large for the specified size, it will be truncated
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.normalize_value : Float normalization function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"Normalizing float {value} to string (size: {size}, decimal_places: {decimal_places})"
        )

        from fbpyutils.string import normalize_value

        result = normalize_value(value, size, decimal_places)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Float normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize float")


@app.command("translate-chars")
def translate_chars_cmd(
    input: str = typer.Option(..., "--input", help="String to translate."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Translate special characters to basic counterparts.

    This command translates special characters (accented characters, symbols,
    etc.) to their basic ASCII counterparts. This is useful for normalizing
    text for comparison, storage, or display in systems that only support ASCII.

    Parameters
    ----------
    input : str
        The string to translate. This is a required parameter.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the translated string
        to stdout.

    Raises
    ------
    ValueError
        If translation fails.

    Examples
    --------
    Translate special characters:

    >>> fbpyutils string translate-chars --input "café"
    # Outputs: "cafe"

    Translate multiple special characters:

    >>> fbpyutils string translate-chars --input "naïve résumé"
    # Outputs: "naive resume"

    Translate in JSON format:

    >>> fbpyutils string translate-chars --input "café" --output-format json
    # Outputs translated string in JSON format

    Notes
    -----
    * Character translation converts accented and special characters to ASCII
    * Common translations include: é->e, ñ->n, ü->u, etc.
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.translate_special_chars : Character translation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Translating special characters")

        from fbpyutils.string import translate_special_chars

        result = translate_special_chars(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Special characters translated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to translate special characters")


@app.command("normalize-list")
def normalize_list_cmd(
    names: str = typer.Option(
        ..., "--names", help="Comma-separated list of strings to normalize."
    ),
    normalize_specials: bool = typer.Option(
        True, "--normalize-specials", help="Translate special characters."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Normalize a list of strings.

    This command normalizes a list of strings by stripping whitespace and
    optionally translating special characters to their basic ASCII counterparts.
    This is useful for cleaning and standardizing lists of names or other text
    data.

    Parameters
    ----------
    names : str
        A comma-separated list of strings to normalize. This is a required
        parameter.

    normalize_specials : bool, default=True
        If True, translates special characters to their basic ASCII counterparts.
        If False, only whitespace is stripped.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the normalized list
        to stdout.

    Raises
    ------
    ValueError
        If normalization fails.

    Examples
    --------
    Normalize list of strings:

    >>> fbpyutils string normalize-list --names "John Doe,Jane Smith"
    # Outputs normalized list

    Normalize list with special characters:

    >>> fbpyutils string normalize-list --names "José García,María López"
    # Outputs normalized list with translated special characters

    Normalize list without special character translation:

    >>> fbpyutils string normalize-list --names "John Doe,Jane Smith" --normalize-specials false
    # Outputs normalized list without special character translation

    Notes
    -----
    * List normalization strips whitespace and optionally translates special characters
    * The input is a comma-separated list of strings
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.normalize_names : List normalization function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"Normalizing list of strings (normalize_specials: {normalize_specials})"
        )

        from fbpyutils.string import normalize_names

        names_list = [name.strip() for name in names.split(",")]
        result = normalize_names(names_list, normalize_specials)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("List normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize list")


@app.command("split-by-lengths")
def split_by_lengths_cmd(
    input: str = typer.Option(..., "--input", help="String to split."),
    lengths: str = typer.Option(
        ..., "--lengths", help="Comma-separated list of lengths."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Split string by specified lengths.

    This command splits a string into substrings based on the specified lengths.
    Each substring has the length specified in the corresponding position in the
    lengths list. This is useful for parsing fixed-width data or formatting
    strings for display.

    Parameters
    ----------
    input : str
        The string to split. This is a required parameter.

    lengths : str
        A comma-separated list of lengths for each substring. This is a required
        parameter. Each length must be a positive integer.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the list of substrings
        to stdout.

    Raises
    ------
    ValueError
        If splitting fails or lengths are invalid.

    Examples
    --------
    Split string by lengths:

    >>> fbpyutils string split-by-lengths --input "abcdefghij" --lengths "3,4,3"
    # Outputs: ["abc", "defg", "hij"]

    Split string with different lengths:

    >>> fbpyutils string split-by-lengths --input "1234567890" --lengths "2,3,5"
    # Outputs: ["12", "345", "67890"]

    Split string in JSON format:

    >>> fbpyutils string split-by-lengths --input "abcdefghij" --lengths "3,4,3" --output-format json
    # Outputs list of substrings in JSON format

    Notes
    -----
    * String splitting uses specified lengths to partition the input string
    * If the total length exceeds the input length, the last substring will be shorter
    * The lengths are specified as a comma-separated list of integers
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.string.split_by_lengths : String splitting function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Splitting string by lengths")

        from fbpyutils.string import split_by_lengths

        lengths_list = [int(length.strip()) for length in lengths.split(",")]
        result = split_by_lengths(input, lengths_list)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("String split successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to split string")
