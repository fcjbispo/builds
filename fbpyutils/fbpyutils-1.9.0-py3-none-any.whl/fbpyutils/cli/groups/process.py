"""
Process Management Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for process management and
parallelization support checking. The process commands allow users to query
system CPU information and check parallelization capabilities with flexible
output formatting.

The module provides two primary commands:

* **cpu-count**: Get the number of available CPU cores on the system
* **check-parallel**: Check if parallelization is supported for a given type

Key Features:
-------------
* **CPU Information**: Query the number of available CPU cores
* **Parallelization Check**: Verify support for different parallelization types
* **Flexible Output**: Support for txt, json, and csv output formats
* **Type Support**: Support for threads and processes parallelization types
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for process functionality
* `fbpyutils.process.Process`: Process management class
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Get CPU count:

>>> fbpyutils process cpu-count
# Outputs number of available CPU cores

Get CPU count in JSON format:

>>> fbpyutils process cpu-count --output-format json
# Outputs CPU count in JSON format

Check thread parallelization support:

>>> fbpyutils process check-parallel --parallel-type threads
# Outputs True if thread parallelization is supported

Check process parallelization support:

>>> fbpyutils process check-parallel --parallel-type processes
# Outputs True if process parallelization is supported

Check parallelization in JSON format:

>>> fbpyutils process check-parallel --parallel-type threads --output-format json
# Outputs parallelization support status in JSON format

Command Help:
-------------
Display help for process commands:

>>> fbpyutils process --help
# Shows all available process commands

Display help for cpu-count command:

>>> fbpyutils process cpu-count --help
# Shows detailed help for the cpu-count command

Notes:
------
* CPU count returns the number of available CPU cores for parallel processing
* Parallelization types include "threads" and "processes"
* Thread parallelization uses threading for concurrent execution
* Process parallelization uses multiprocessing for parallel execution
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* System errors: Error message if system information cannot be retrieved
* Invalid parallel type: Error message if parallelization type is not supported
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.process` for process functionality implementation
* See `fbpyutils.process.Process` for process management class
* See `fbpyutils.process.Process.get_available_cpu_count` for CPU count function
* See `fbpyutils.process.Process.is_parallelizable` for parallelization check function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for process commands
app = typer.Typer(
    name="process", help="Commands for process management.", rich_markup_mode="rich"
)


@app.command("cpu-count")
def get_cpu_count(
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Get the number of available CPU cores.

    This command queries the system to determine the number of available CPU
    cores that can be used for parallel processing. This information is useful
    for optimizing parallel operations and determining the optimal number of
    workers for concurrent tasks.

    Parameters
    ----------
    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the CPU count to
        stdout.

    Raises
    ------
    ValueError
        If system information cannot be retrieved.

    Examples
    --------
    Get CPU count:

    >>> fbpyutils process cpu-count
    # Outputs number of available CPU cores

    Get CPU count in JSON format:

    >>> fbpyutils process cpu-count --output-format json
    # Outputs CPU count in JSON format

    Get CPU count in CSV format:

    >>> fbpyutils process cpu-count --output-format csv
    # Outputs CPU count in CSV format

    Notes
    -----
    * CPU count returns the number of available CPU cores for parallel processing
    * The count includes logical cores (hyperthreading)
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.process.Process.get_available_cpu_count : CPU count function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Getting available CPU count")

        from fbpyutils.process import Process

        result = Process.get_available_cpu_count()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Available CPU count: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get CPU count")


@app.command("check-parallel")
def check_parallel(
    parallel_type: str = typer.Option(
        "threads",
        "--parallel-type",
        help="Type of parallelization to check.",
        case_sensitive=False,
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Check if parallelization is supported for the given type.

    This command checks whether the specified type of parallelization is
    supported on the current system. This is useful for determining whether
    to use threading or multiprocessing for concurrent operations.

    Parameters
    ----------
    parallel_type : str, default="threads"
        The type of parallelization to check. Supported types:
        * "threads" - Check if threading is supported
        * "processes" - Check if multiprocessing is supported
        The type is case-insensitive.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the parallelization
        support status to stdout.

    Raises
    ------
    ValueError
        If the parallelization type is not supported.

    Examples
    --------
    Check thread parallelization support:

    >>> fbpyutils process check-parallel --parallel-type threads
    # Outputs True if thread parallelization is supported

    Check process parallelization support:

    >>> fbpyutils process check-parallel --parallel-type processes
    # Outputs True if process parallelization is supported

    Check parallelization in JSON format:

    >>> fbpyutils process check-parallel --parallel-type threads --output-format json
    # Outputs parallelization support status in JSON format

    Notes
    -----
    * Parallelization types include "threads" and "processes"
    * Thread parallelization uses threading for concurrent execution
    * Process parallelization uses multiprocessing for parallel execution
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.process.Process.is_parallelizable : Parallelization check function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Checking parallelization support for {parallel_type}")

        from fbpyutils.process import Process

        result = Process.is_parallelizable(parallel_type)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Parallelization support for {parallel_type}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to check parallelization support")
