"""
Calendar Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for calendar manipulation
and generation. The calendar commands allow users to generate calendars based
on date ranges, add temporal markers, and output results in various formats.

The module provides one primary command:

* **get-range**: Generate a calendar based on a specified date range with optional
  temporal markers and flexible output formatting.

Key Features:
-------------
* **Date Range Generation**: Create calendars for any date range
* **Temporal Markers**: Add visual markers for special dates
* **Flexible Output**: Support for txt, json, and csv output formats
* **Date Validation**: Automatic validation of date format and range
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for calendar functionality
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities
* `datetime`: Standard library date and time handling

Usage Examples:
---------------
Generate calendar for a date range:

>>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31
# Outputs calendar for January 2024 in text format

Generate calendar with temporal markers:

>>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --add-markers
# Outputs calendar with temporal markers

Generate calendar in JSON format:

>>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --output-format json
# Outputs calendar in JSON format

Generate calendar in CSV format:

>>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --output-format csv
# Outputs calendar in CSV format

Command Help:
-------------
Display help for calendar commands:

>>> fbpyutils calendar --help
# Shows all available calendar commands

Display help for get-range command:

>>> fbpyutils calendar get-range --help
# Shows detailed help for the get-range command

Notes:
------
* Date format must be YYYY-MM-DD (ISO 8601 format)
* Start date must be before or equal to end date
* Temporal markers add visual indicators for special dates
* Output format is case-insensitive (txt, json, csv)
* The command integrates with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid date format: Clear error message indicating expected format
* Invalid date range: Error message if start date is after end date
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.calendar` for calendar functionality implementation
* See `fbpyutils.calendar.get_calendar` for calendar generation function
* See `fbpyutils.calendar.add_markers` for temporal markers function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error
from datetime import datetime

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for calendar commands
app = typer.Typer(
    name="calendar", help="Commands for calendar manipulation.", rich_markup_mode="rich"
)


@app.command("get-range")
def get_range(
    start_date: str = typer.Option(
        ..., "--start-date", help="Start date (YYYY-MM-DD)."
    ),
    end_date: str = typer.Option(..., "--end-date", help="End date (YYYY-MM-DD)."),
    add_markers: bool = typer.Option(
        False, "--add-markers", help="Add temporal markers to the calendar."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Build a calendar based on a date range.

    This command generates a calendar for the specified date range, optionally
    adding temporal markers for special dates. The calendar can be output in
    various formats including text, JSON, and CSV.

    Parameters
    ----------
    start_date : str
        The start date for the calendar range in YYYY-MM-DD format. This is a
        required parameter and must be a valid date.

    end_date : str
        The end date for the calendar range in YYYY-MM-DD format. This is a
        required parameter and must be a valid date. The end date must be
        after or equal to the start date.

    add_markers : bool, default=False
        If True, adds temporal markers to the calendar for special dates such
        as weekends, holidays, or other significant dates. Markers provide
        visual indicators for these dates.

    output_format : str, default="txt"
        The output format for the calendar. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the formatted calendar
        to stdout.

    Raises
    ------
    ValueError
        If the date format is invalid or if the start date is after the end date.

    Examples
    --------
    Generate calendar for January 2024:

    >>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31
    # Outputs calendar for January 2024 in text format

    Generate calendar with temporal markers:

    >>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --add-markers
    # Outputs calendar with temporal markers

    Generate calendar in JSON format:

    >>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --output-format json
    # Outputs calendar in JSON format

    Generate calendar in CSV format:

    >>> fbpyutils calendar get-range --start-date 2024-01-01 --end-date 2024-01-31 --output-format csv
    # Outputs calendar in CSV format

    Notes
    -----
    * Date format must be YYYY-MM-DD (ISO 8601 format)
    * Start date must be before or equal to end date
    * Temporal markers add visual indicators for special dates
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.calendar.get_calendar : Calendar generation function
    fbpyutils.calendar.add_markers : Temporal markers function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Generating calendar from {start_date} to {end_date}")

        # Parse dates
        start_dt = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_dt = datetime.strptime(end_date, "%Y-%m-%d").date()

        # Import the calendar function
        from fbpyutils.calendar import get_calendar

        # Generate calendar
        result = get_calendar(start_dt, end_dt)

        # Add markers if requested
        if add_markers:
            from fbpyutils.calendar import add_markers

            result = add_markers(result)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Calendar generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate calendar")
