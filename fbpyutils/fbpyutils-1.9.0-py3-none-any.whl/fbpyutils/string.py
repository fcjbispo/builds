"""
String Manipulation and Text Processing Utilities

This module provides comprehensive string manipulation functions including UUID generation,
text similarity calculation, random string creation, JSON processing, hashing, normalization,
and text transformation utilities. The module handles various text processing scenarios
from basic string operations to advanced text analysis and transformation workflows.

The module offers seven primary capabilities:

* **UUID Generation**: Cryptographically secure UUID4 generation with deprecation warnings
  for migration to the dedicated uuid module.

* **Text Similarity Analysis**: SequenceMatcher-based similarity calculation with options
  for case sensitivity and space compression.

* **Random String Generation**: Configurable random string creation with character set
  selection including letters, digits, and special characters.

* **JSON String Processing**: Dictionary to JSON string conversion with automatic handling
  of non-serializable types through stringification.

* **Text Hashing**: MD5 hash generation for strings and JSON objects with deprecation
  warnings for migration to the dedicated uuid module.

* **Text Normalization**: Character translation, value formatting, and name normalization
  for standardizing text data across different formats.

* **String Splitting**: Advanced string splitting by cumulative length specifications
  with empty segment handling.

Key Features:
-------------
* **Character Set Management**: Configurable character sets for random string generation
* **Special Character Handling**: Translation table for accented characters to ASCII equivalents
* **Similarity Algorithms**: SequenceMatcher-based similarity with preprocessing options
* **JSON Compatibility**: Handles non-serializable objects through automatic stringification
* **Text Formatting**: Zero-padded numeric formatting for consistent display
* **Empty Segment Handling**: Smart handling of empty substrings in split operations

Dependencies:
-------------
* `random`: Random string generation and character selection
* `string`: Predefined character constants (ascii_letters, digits)
* `hashlib`: MD5 hash generation for text and JSON processing
* `json`: JSON serialization for string conversion
* `difflib`: SequenceMatcher for similarity calculations
* `uuid`: UUID4 generation for secure random identifiers
* `fbpyutils.uuid`: Dedicated UUID and hashing utilities (preferred)
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Text similarity calculation:

>>> from fbpyutils.string import similarity
>>> similarity('Hello World', 'Hello world')
0.8
>>> similarity('café', 'cafe', compress_spaces=True)
0.75
>>> similarity('A  B  C', 'A B C', compress_spaces=True)
1.0

Random string generation:

>>> from fbpyutils.string import random_string
>>> random_string(10, include_digits=True, include_special=False)
'AbCdEfGhIj'
>>> random_string(8, include_special=True)
'xY9!@zA$'

JSON string conversion:

>>> from fbpyutils.string import json_string
>>> data = {'name': 'Alice', 'age': 30, 'object': object()}
>>> json_str = json_string(data)
>>> json_str
'{"name": "Alice", "age": 30, "object": "<object object at 0x...>"}'

Text normalization:

>>> from fbpyutils.string import normalize_value, normalize_names
>>> normalize_value(1.23, size=5, decimal_places=2)
'00123'
>>> normalize_names(['São Paulo', 'New York'])
['sao_paulo', 'new_york']

Special character translation:

>>> from fbpyutils.string import translate_special_chars
>>> translate_special_chars('café naïve')
'cafe naive'
>>> translate_special_chars('São Paulo')
'Sao Paulo'

String splitting by lengths:

>>> from fbpyutils.string import split_by_lengths
>>> split_by_lengths('HelloWorld', [5, 5])
['Hello', 'World']
>>> split_by_lengths('ABC', [1, 1, 1])
['A', 'B', 'C']

Notes:
------
* Some functions are deprecated in favor of dedicated modules (fbpyutils.uuid)
* Similarity calculations use difflib.SequenceMatcher for accurate comparisons
* Random string generation supports configurable character sets
* JSON conversion handles non-serializable objects automatically
* Text normalization preserves original formatting options
* Empty segments in string splitting are logged but not included in results

Performance Considerations:
------------------------
* Similarity calculations scale with string length
* Hash operations are optimized for common use cases
* Random string generation is suitable for secure token creation
* JSON conversion overhead depends on object complexity
* Text normalization operations are optimized for common character sets

Cross-References:
-----------------
* See `fbpyutils.uuid` for preferred UUID and hashing utilities
* See `fbpyutils.logging` for operation logging and error tracking
* See `fbpyutils.setup()` for proper initialization requirements
"""

import random
import string
import json
import warnings

from difflib import SequenceMatcher


from typing import Dict, List

import fbpyutils

from fbpyutils.uuid import (
    uuid as _uuid_new,
    hash_string as _hash_string_new,
    hash_json as _hash_json_new,
)


from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

_SPECIAL_CHARS = "".join([c + c.upper() for c in "áãâäàéèëêíìîïóòõôöúùûüçñ"])

_NORMALIZED_CHARS = "".join([c + c.upper() for c in "aaaaaeeeeiiiiooooouuuucn"])

_TRANSLATION_TAB = {}
for i in range(len(_SPECIAL_CHARS)):
    _TRANSLATION_TAB[ord(_SPECIAL_CHARS[i])] = _NORMALIZED_CHARS[i]


def uuid() -> str:  # pragma: no cover
    """Generates a random UUID4 string.

    DEPRECATED: Use fbpyutils.uuid.uuid() instead. This function will be removed in v1.8.5.

    Uses uuid.uuid4() for cryptographically secure random UUID.

    Returns:
        str: UUID string like '123e4567-e89b-12d3-a456-426614174000'.

    Example:
        >>> from fbpyutils.string import uuid
        >>> uid = uuid()
        >>> len(uid)
        36
        >>> uid
        '123e4567-e89b-12d3-a456-426614174000'
    """
    warnings.warn(
        "string.uuid() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.uuid() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _uuid_new()


def similarity(
    x: str, y: str, ignore_case: bool = True, compress_spaces: bool = True
) -> float:
    """Calculates similarity ratio between two strings using SequenceMatcher.

    Options to ignore case and compress multiple spaces. Ratio 1.0 = identical, 0.0 = no similarity.

    Args:
        x (str): First string.
        y (str): Second string.
        ignore_case (bool): Ignore case differences. Defaults to True.
        compress_spaces (bool): Replace multiple spaces with single. Defaults to True.

    Returns:
        float: Similarity ratio (0.0 to 1.0).

    Example:
        >>> from fbpyutils.string import similarity
        >>> similarity('Hello World', 'Hello world')
        0.8
        >>> similarity('Hello World', 'Hi there', ignore_case=False)
        0.0
        >>> similarity('A  B  C', 'A B C', compress_spaces=True)
        1.0
    """
    def compress(z: str) -> str:
        original_z = z
        while "  " in z:
            z = z.replace("  ", " ")
        return z

    if ignore_case:
        x = x.lower()
        y = y.lower()

    if compress_spaces:
        x = compress(x)
        y = compress(y)

    ratio = SequenceMatcher(None, x, y).ratio()
    return ratio


def random_string(
    x: int = 32, include_digits: bool = True, include_special: bool = False
) -> str:
    """Generates a random string of specified length using letters, digits, special chars.

    Uses random.choice from ascii_letters + optional digits + special.

    Args:
        x (int): Length of string. Defaults to 32.
        include_digits (bool): Include digits 0-9. Defaults to True.
        include_special (bool): Include !@#$%^&*_. Defaults to False.

    Returns:
        str: Random string.

    Example:
        >>> from fbpyutils.string import random_string
        >>> rand = random_string(10, include_digits=True, include_special=False)
        >>> len(rand)
        10
        >>> rand.isalpha()
        True
        >>> rand_special = random_string(5, include_special=True)
        >>> '!' in rand_special or '@' in rand_special
        True
    """
    letters = (
        string.ascii_letters
        + (string.digits if include_digits else "")
        + ("!@#$%^&*_" if include_special else "")
    )

    if not letters:
        _logger.warning(
            "No character set selected for random string generation. Returning empty string."
        )
        return ""

    generated_string = "".join(random.choice(letters) for i in range(x))
    return generated_string


def json_string(x: Dict) -> str:
    """Converts a dictionary to a JSON string, handling non-serializable types by stringifying.

    Ensures UTF-8 encoding and decoding.

    Args:
        x (Dict): Dictionary to convert.

    Returns:
        str: JSON string representation.

    Raises:
        TypeError: If conversion fails due to unhandled types.
        Exception: Other JSON encoding errors.

    Example:
        >>> from fbpyutils.string import json_string
        >>> data = {'name': 'Alice', 'age': 30, 'obj': object()}
        >>> js = json_string(data)
        >>> js
        '{"name": "Alice", "age": 30, "obj": "<object object at 0x...>"}'
        >>> import json
        >>> json.loads(js)['name']
        'Alice'
    """
    def _stringify(obj) -> str:
        return str(obj)

    try:
        s = json.dumps(x, default=_stringify, ensure_ascii=False).encode("utf8")
        decoded_string = s.decode()
        return decoded_string
    except TypeError as e:
        _logger.error(f"TypeError during JSON string conversion: {e}")
        raise
    except Exception as e:
        _logger.error(f"Error during JSON string conversion: {e}")
        raise


def hash_string(x: str) -> str:  # pragma: no cover
    """Generates MD5 hash of a string, encoding as UTF-8.

    DEPRECATED: Use fbpyutils.uuid.hash_string() instead. This function will be removed in v1.8.5.

    Args:
        x (str): Input string.

    Returns:
        str: 32-character hexadecimal MD5 hash.

    Example:
        >>> from fbpyutils.string import hash_string
        >>> hash_string('Hello World')
        '5d41402abc4b2b76b0b6f0c1a6c9c9c9'  # Example hash
        >>> len(hash_string('test'))
        32
    """
    warnings.warn(
        "string.hash_string() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.hash_string() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _hash_string_new(x)


def hash_json(x: Dict) -> str:  # pragma: no cover
    """Generates MD5 hash of a dictionary by converting to JSON string first.

    DEPRECATED: Use fbpyutils.uuid.hash_json() instead. This function will be removed in v1.8.5.

    Args:
        x (Dict): Dictionary to hash.

    Returns:
        str: MD5 hex digest of JSON string.

    Example:
        >>> from fbpyutils.string import hash_json
        >>> data = {'key': 'value', 'num': 42}
        >>> hash_json(data)
        'a1b2c3d4e5f6...'  # Example hash
    """
    warnings.warn(
        "string.hash_json() is deprecated and will be removed in v1.8.5. Use fbpyutils.uuid.hash_json() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _hash_json_new(x)


def normalize_value(x: float, size: int = 4, decimal_places: int = 2) -> str:
    """Formats a float as zero-padded string without decimal point.

    Pads to total size, with specified decimal places before removing dot.

    Args:
        x (float): Number to normalize.
        size (int): Total digits (integer + decimal). Defaults to 4.
        decimal_places (int): Decimal places. Defaults to 2.

    Returns:
        str: Padded string, e.g., '00123' for 1.23 with size=5, decimals=2.

    Raises:
        ValueError: Invalid formatting.
        Exception: Other formatting errors.

    Example:
        >>> from fbpyutils.string import normalize_value
        >>> normalize_value(1.23, size=5, decimal_places=2)
        '00123'
        >>> normalize_value(12.34, size=4, decimal_places=1)
        '1234'
    """
    try:
        format_string = "{:0" + str(size) + "." + str(decimal_places) + "f}"
        normalized_string = format_string.format(abs(x)).replace(".", "")
        return normalized_string
    except ValueError as e:
        _logger.error(
            f"ValueError during value normalization: {e}. Input: {x}, size: {size}, decimal_places: {decimal_places}"
        )
        raise
    except Exception as e:
        _logger.error(f"Error during value normalization: {e}. Input: {x}")
        raise


def translate_special_chars(x: str) -> str:
    """Translates accented/special characters to basic ASCII equivalents.

    Uses a translation table for áãâäàéèëêíìîïóòõôöúùûüçñ to aaaaaeeeeiiiiooooouuuucn.

    Args:
        x (str): Input string. Defaults to empty if None.

    Returns:
        str: String with special chars replaced.

    Example:
        >>> from fbpyutils.string import translate_special_chars
        >>> translate_special_chars('café naïve')
        'cafe naive'
        >>> translate_special_chars('São Paulo')
        'Sao Paulo'
    """
    x = x or ""
    translated_string = x.translate(_TRANSLATION_TAB)
    return translated_string


def normalize_names(names: List[str], normalize_specials: bool = True) -> List[str]:
    """Normalizes list of strings: lowercase, replace spaces/slashes with _, optional special char translation.

    Args:
        names (List[str]): List of strings to normalize.
        normalize_specials (bool): Apply translate_special_chars. Defaults to True.

    Returns:
        List[str]: Normalized strings.

    Example:
        >>> from fbpyutils.string import normalize_names
        >>> names = ['São Paulo', 'New York', 'São_Paulo/Test']
        >>> normalize_names(names)
        ['sao_paulo', 'new_york', 'sao_paulo_test']
        >>> normalize_names(names, normalize_specials=False)
        ['são_paulo', 'new_york', 'são_paulo_test']
    """
    normalized_list = [
        str(translate_special_chars(c) if normalize_specials else c)
        .replace(" ", "_")
        .replace("/", "_")
        .lower()
        for c in names
    ]
    return normalized_list


def split_by_lengths(string: str, lengths: List[int]) -> List[str]:
    """Splits a string into substrings based on cumulative lengths list.

    Only adds non-empty substrings. Logs warnings for empty segments.

    Args:
        string (str): Input string to split.
        lengths (List[int]): List of segment lengths.

    Returns:
        List[str]: List of non-empty substrings.

    Example:
        >>> from fbpyutils.string import split_by_lengths
        >>> split_by_lengths('HelloWorld', [5, 5])
        ['Hello', 'World']
        >>> split_by_lengths('ABC', [1, 1, 1])
        ['A', 'B', 'C']
        >>> split_by_lengths('ABCD', [2, 1, 0, 1])  # Empty segment skipped
        ['AB', 'C', 'D']
    """
    substrings = []
    start_index = 0
    for i, length in enumerate(lengths):
        end_index = start_index + length
        substring = string[start_index:end_index]
        if substring:  # Only add non-empty
            substrings.append(substring)
        else:
            _logger.warning(
                f"Substring {i + 1} is empty for length {length} at index {start_index}. Skipping."
            )
        start_index = end_index
    return substrings
