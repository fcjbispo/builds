"""
Date and time manipulation and calculation utilities.

This module provides comprehensive functionality for date and time operations,
including delta calculations, timezone handling, and elapsed time computation.
It serves as a foundation for temporal data processing and analysis within
the FBPyUtils ecosystem.

The module offers precise date arithmetic operations using python-dateutil's
relativedelta for accurate month and year calculations, timezone-aware
datetime operations using pytz, and detailed elapsed time breakdowns.

Functions
---------
delta
    Calculate precise time differences between datetime objects in months or years.
apply_timezone
    Apply timezone information to naive datetime objects with validation.
elapsed_time
    Calculate detailed elapsed time breakdown between two datetime objects.

Dependencies
------------
- pytz: World timezone definitions and conversions
- python-dateutil: Advanced date manipulation and relativedelta functionality
- datetime: Standard library datetime classes

Examples
--------
Calculate time differences:

>>> from datetime import datetime
>>> from fbpyutils.datetime import delta
>>> date1 = datetime(2023, 1, 1)
>>> date2 = datetime(2024, 3, 15)
>>> delta(date2, date1, 'months')
14
>>> delta(date2, date1, 'years')
1

Apply timezone to naive datetime:

>>> from fbpyutils.datetime import apply_timezone
>>> naive_dt = datetime(2024, 7, 19, 12, 0, 0)
>>> tz_aware = apply_timezone(naive_dt, 'America/New_York')
>>> print(tz_aware.hour)
12

Calculate elapsed time:

>>> from fbpyutils.datetime import elapsed_time
>>> start = datetime(2024, 1, 1, 10, 30, 15)
>>> end = datetime(2024, 1, 2, 14, 45, 30)
>>> days, hours, minutes, seconds = elapsed_time(end, start)
>>> print(f"{days}d {hours}h {minutes}m {seconds}s")
1d 4h 15m 15s

Notes
-----
All functions include comprehensive error handling and logging for debugging.
The module handles edge cases like leap years and daylight saving time transitions.
Timezone operations support all valid IANA timezone database entries.

See Also
--------
fbpyutils.calendar: Calendar generation and temporal data enrichment
fbpyutils.logging: Logging configuration and utilities
"""

import pytz

from datetime import datetime
from dateutil import relativedelta

import fbpyutils

from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()


def delta(x: datetime, y: datetime, delta: str = "months") -> int:
    """Calculate precise time difference between two datetime objects.

    This function computes the exact time difference between two datetime objects
    in either months or years using relativedelta for precise calendar-aware
    calculations. It handles leap years, varying month lengths, and other
    calendar complexities automatically.

    The function uses python-dateutil's relativedelta to ensure accurate
    calculations that respect calendar semantics, making it suitable for
    business logic, financial calculations, and temporal analysis.

    Parameters
    ----------
    x : datetime
        The later/end datetime object. Must be a datetime.datetime instance.
        This represents the end point of the time period being measured.
    y : datetime
        The earlier/start datetime object. Must be a datetime.datetime instance.
        This represents the start point of the time period being measured.
    delta : str, optional
        The unit for calculating the time difference. Must be either 'months'
        or 'years'. Defaults to 'months'.

    Returns
    -------
    int
        The total time difference in the specified unit:

        - If delta='months': Total number of months between the dates
          (including both years and months components)
        - If delta='years': Total number of complete years between the dates

    Raises
    ------
    Exception
        If delta parameter is not 'months' or 'years'.
    TypeError
        If x or y are not datetime.datetime objects.

    Examples
    --------
    Calculate monthly difference:

    >>> from datetime import datetime
    >>> from fbpyutils.datetime import delta
    >>> date1 = datetime(2023, 1, 15)
    >>> date2 = datetime(2024, 3, 15)
    >>> delta(date2, date1, 'months')
    14

    Calculate yearly difference:

    >>> delta(date2, date1, 'years')
    1

    Handle partial years:

    >>> date3 = datetime(2022, 6, 1)
    >>> date4 = datetime(2024, 3, 1)
    >>> delta(date4, date3, 'years')
    1
    >>> delta(date4, date3, 'months')
    21

    Account for leap years:

    >>> leap_start = datetime(2020, 2, 29)
    >>> leap_end = datetime(2024, 2, 28)
    >>> delta(leap_end, leap_start, 'years')
    4

    Notes
    -----
    The function uses relativedelta for precise calendar calculations,
    which handles complexities like leap years and varying month lengths.

    For month calculations, the result includes both full years (converted
    to months) and remaining months: (years * 12) + months.

    The function is symmetric: delta(a, b) = -delta(b, a).

    See Also
    --------
    elapsed_time : Calculate detailed time breakdown
    apply_timezone : Handle timezone-aware datetime operations
    dateutil.relativedelta : Underlying calculation engine

    """
    d = relativedelta.relativedelta(x, y)
    if delta == "months":
        result = d.years * 12 + d.months
        _logger.info(f"Calculated time difference: {result} months between {y} and {x}")
        return result
    elif delta == "years":
        result = d.years
        _logger.info(f"Calculated time difference: {result} years between {y} and {x}")
        return result
    else:
        _logger.error(f"Invalid delta unit '{delta}': must be 'months' or 'years'")
        raise Exception("Invalid option. Use months or years")


def apply_timezone(x: datetime, tz: str) -> datetime:
    """Apply timezone information to a naive datetime object.

    This function converts a naive datetime object (one without timezone
    information) into a timezone-aware datetime object by applying the
    specified timezone. It validates the timezone name against the IANA
    timezone database and creates a new datetime object with proper
    timezone information.

    The function handles the conversion by preserving all time components
    (year, month, day, hour, minute, second, microsecond) while adding
    the timezone information, making it suitable for timezone-aware
    operations and comparisons.

    Parameters
    ----------
    x : datetime
        The naive datetime object to which timezone will be applied.
        Must be a datetime.datetime instance without timezone information
        (i.e., x.tzinfo is None or not set).
    tz : str
        The timezone name as a string. Must be a valid IANA timezone
        database name (e.g., 'America/New_York', 'Europe/London',
        'Asia/Tokyo'). The timezone name is case-sensitive.

    Returns
    -------
    datetime
        A new datetime object with the same date and time components
        as the input, but with timezone information set to the
        specified timezone. The returned object is timezone-aware
        and can be used for timezone-sensitive operations.

    Raises
    ------
    pytz.UnknownTimeZoneError
        If the specified timezone name is not found in the IANA
        timezone database or is not a valid timezone identifier.
    TypeError
        If x is not a datetime.datetime object or tz is not a string.

    Examples
    --------
    Apply Eastern Time timezone:

    >>> from datetime import datetime
    >>> from fbpyutils.datetime import apply_timezone
    >>> naive_dt = datetime(2024, 7, 19, 12, 0, 0)
    >>> eastern = apply_timezone(naive_dt, 'America/New_York')
    >>> print(eastern.tzinfo)
    America/New_York
    >>> print(eastern.strftime('%Y-%m-%d %H:%M %Z'))
    2024-07-19 12:00 EDT

    Handle international timezones:

    >>> utc_dt = datetime(2024, 7, 19, 15, 0, 0)
    >>> tokyo = apply_timezone(utc_dt, 'Asia/Tokyo')
    >>> print(tokyo.strftime('%Y-%m-%d %H:%M %Z'))
    2024-07-19 15:00 JST

    Preserve time components:

    >>> precise_dt = datetime(2024, 3, 15, 9, 30, 45, 123456)
    >>> timezone_aware = apply_timezone(precise_dt, 'Europe/London')
    >>> print(timezone_aware.microsecond)
    123456

    Notes
    -----
    The function creates a new datetime object rather than modifying
    the original, ensuring immutability and thread safety.

    Timezone names must be valid IANA timezone identifiers. Common
    examples include:
    - 'UTC' - Coordinated Universal Time
    - 'America/New_York' - Eastern Time
    - 'America/Los_Angeles' - Pacific Time
    - 'Europe/London' - Greenwich Mean Time
    - 'Asia/Tokyo' - Japan Standard Time

    The function handles both standard time and daylight saving time
    transitions automatically based on the date.

    See Also
    --------
    delta : Calculate time differences between timezone-aware datetimes
    elapsed_time : Calculate elapsed time between datetimes
    pytz.timezone : IANA timezone database interface

    """
    try:
        timezone = pytz.timezone(tz)
    except pytz.UnknownTimeZoneError as e:
        _logger.error(f"Unknown timezone '{tz}': {e}. Valid timezone names are available in the IANA timezone database.")
        raise e

    date_time_obj = x

    result = datetime(
        date_time_obj.year,
        date_time_obj.month,
        date_time_obj.day,
        hour=date_time_obj.hour,
        minute=date_time_obj.minute,
        second=date_time_obj.second,
        microsecond=date_time_obj.microsecond,
        tzinfo=timezone,
    )
    _logger.info(f"Applied timezone '{tz}' to datetime: {result}")
    return result


def elapsed_time(x: datetime, y: datetime) -> tuple:
    """Calculate detailed elapsed time breakdown between two datetime objects.

    This function computes the precise elapsed time between two datetime objects
    and returns a detailed breakdown in days, hours, minutes, and seconds.
    It handles both timezone-aware and naive datetime objects, providing
    accurate time difference calculations for performance monitoring,
    duration calculations, and temporal analysis.

    The function performs exact arithmetic using Python's built-in timedelta
    arithmetic, ensuring precision even with microsecond-level granularity.
    The result is returned as a tuple for easy unpacking and use in further
    calculations or formatting.

    Parameters
    ----------
    x : datetime
        The later/end datetime object. Must be a datetime.datetime instance.
        This represents the end point of the time period being measured.
        Can be either timezone-aware or naive.
    y : datetime
        The earlier/start datetime object. Must be a datetime.datetime instance.
        This represents the start point of the time period being measured.
        Can be either timezone-aware or naive.

    Returns
    -------
    tuple[int, int, int, int]
        A tuple containing four integers representing the elapsed time breakdown:

        - days (int): Complete days elapsed
        - hours (int): Remaining hours after days (0-23)
        - minutes (int): Remaining minutes after hours (0-59)
        - seconds (int): Remaining seconds after minutes (0-59)

    Raises
    ------
    ValueError
        If x (end time) is earlier than y (start time), indicating
        negative elapsed time.
    TypeError
        If x or y are not datetime.datetime objects.

    Examples
    --------
    Calculate simple elapsed time:

    >>> from datetime import datetime
    >>> from fbpyutils.datetime import elapsed_time
    >>> start = datetime(2024, 1, 1, 10, 30, 15)
    >>> end = datetime(2024, 1, 2, 14, 45, 30)
    >>> days, hours, minutes, seconds = elapsed_time(end, start)
    >>> print(f"{days}d {hours}h {minutes}m {seconds}s")
    1d 4h 15m 15s

    Handle sub-second precision:

    >>> precise_start = datetime(2024, 1, 1, 12, 0, 0, 500000)
    >>> precise_end = datetime(2024, 1, 1, 12, 0, 1, 750000)
    >>> days, hours, minutes, seconds = elapsed_time(precise_end, precise_start)
    >>> print(f"{seconds}.{seconds % 1}")
    1.25

    Calculate longer durations:

    >>> project_start = datetime(2024, 1, 1, 9, 0, 0)
    >>> project_end = datetime(2024, 3, 15, 17, 30, 0)
    >>> days, hours, minutes, seconds = elapsed_time(project_end, project_start)
    >>> print(f"Project duration: {days} days, {hours} hours, {minutes} minutes")
    Project duration: 74 days, 8 hours, 30 minutes

    Performance monitoring:

    >>> import time
    >>> start_time = datetime.now()
    >>> # ... some operation ...
    >>> end_time = datetime.now()
    >>> days, hours, minutes, seconds = elapsed_time(end_time, start_time)
    >>> if seconds > 0:
    ...     print(f"Operation took {seconds} seconds")

    Notes
    -----
    The function uses Python's built-in timedelta arithmetic for precise
    calculations, handling leap years and daylight saving time automatically.

    For timezone-aware datetime objects, the calculation accounts for
    timezone differences automatically.

    The breakdown is always normalized so that:
    - hours is in range [0, 23]
    - minutes is in range [0, 59]
    - seconds is in range [0, 59]

    Microseconds are included in the seconds calculation but not
    separately returned. For microsecond precision, consider using
    the total_seconds() method on the underlying timedelta.

    See Also
    --------
    delta : Calculate month/year differences between dates
    apply_timezone : Handle timezone-aware datetime operations
    datetime.timedelta : Underlying time difference calculation

    """
    if x < y:
        _logger.error(
            f"Invalid elapsed_time calculation: end time ({x}) is earlier than start time ({y})"
        )
        raise ValueError("x parameter must be greater than or equal to y parameter")

    delta = x - y

    days = delta.days
    hours = delta.seconds // 3600
    minutes = (delta.seconds // 60) % 60
    seconds = delta.seconds % 60

    _logger.info(f"Calculated elapsed time: {days}d {hours}h {minutes}m {seconds}s between {y} and {x}")
    return days, hours, minutes, seconds
