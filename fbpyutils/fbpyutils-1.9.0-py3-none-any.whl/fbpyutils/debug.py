"""
Debugging utilities and decorators for Python applications.

This module provides comprehensive debugging functionality including decorators
for function execution tracing and exception analysis utilities. It is designed
to enhance the debugging and monitoring capabilities of Python applications
within the FBPyUtils ecosystem.

The module offers two main capabilities:
- Function execution tracing via the @debug decorator for monitoring function
  calls, arguments, and return values
- Exception analysis and debug information extraction for comprehensive
  error reporting and logging

Functions
---------
debug
    Decorator for logging function execution with arguments and return values.
debug_info
    Extract comprehensive debug information and traceback from exceptions.

Dependencies
------------
- traceback: Standard library for stack trace formatting
- fbpyutils.logging: Logging configuration and utilities

Examples
--------
Decorate functions for execution tracing:

>>> from fbpyutils.debug import debug
>>> @debug
... def calculate_area(length, width, unit='meters'):
...     area = length * width
...     return f"{area} {unit}²"
>>> result = calculate_area(5, 3)
# Logs: Calling function: calculate_area with args: (5, 3), kwargs: {'unit': 'meters'}
# Logs: Function calculate_area returned: 15 meters²

Extract exception debug information:

>>> from fbpyutils.debug import debug_info
>>> try:
...     result = 10 / 0
... except ZeroDivisionError as e:
...     debug_info = debug_info(e)
...     print(debug_info)
# Output: division by zero: Traceback (most recent call last): ...

Monitor complex function calls:

>>> @debug
... def process_data(data, validate=True, transform=None):
...     if validate:
...         assert len(data) > 0, "Data cannot be empty"
...     if transform:
...         return transform(data)
...     return data
>>> process_data([1, 2, 3], transform=lambda x: sum(x))
# Logs function calls and final result

Notes
-----
All debug functions include comprehensive logging for monitoring and
troubleshooting. The @debug decorator adds minimal overhead and is
suitable for development and testing environments.

Exception debug information includes full traceback formatting for
detailed error analysis and reporting.

See Also
--------
fbpyutils.logging: Logging configuration and utilities
fbpyutils.env: Environment management utilities
"""

import traceback
import os

import fbpyutils

from fbpyutils import get_logger, get_env

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()

# Global flag to enable/disable @debug decorator logging
# Can be controlled via environment variable: FBPYUTILS_DEBUG_ENABLED
# Default: False (disabled to prevent log pollution in production)
_DEBUG_ENABLED = os.getenv("FBPYUTILS_DEBUG_ENABLED", "false").lower() in ("true", "1", "yes", "on")


def debug(func=None, *, enabled=None):
    """Decorator for logging function execution with arguments and return values.

    This decorator provides comprehensive function execution tracing by logging
    the function name, all positional and keyword arguments, and the return
    value at DEBUG level. It is designed for development, testing, and
    monitoring scenarios where detailed function call information is needed.

    The decorator wraps the original function to intercept all calls and
    captures both input parameters and output results. It preserves the
    original function's signature, docstring, and attributes while adding
    debugging capabilities.

    IMPORTANT: The decorator is disabled by default to prevent log pollution
    in production. Enable it by setting the environment variable
    FBPYUTILS_DEBUG_ENABLED=true or by passing enabled=True to the decorator.

    Parameters
    ----------
    func : callable, optional
        The function to be decorated. Can be any callable object including
        regular functions, methods, lambdas, or classes with __call__ method.
        The decorator preserves all original function attributes.
    enabled : bool, optional
        Override the global debug enabled flag for this specific function.
        If None, uses the global FBPYUTILS_DEBUG_ENABLED setting.

    Returns
    -------
    callable
        A wrapped function that provides the same interface as the original
        function but with added debug logging capabilities. The wrapper:

        - Logs function entry with name, args, and kwargs at DEBUG level (if enabled)
        - Executes the original function with the provided arguments
        - Logs function exit with name and return value at DEBUG level (if enabled)
        - Returns the original function's result unchanged

    Examples
    --------
    Simple function decoration (uses global setting):

    >>> from fbpyutils.debug import debug
    >>> @debug
    ... def add(a: int, b: int) -> int:
    ...     return a + b
    >>> result = add(2, 3)
    # Debug logs (if enabled): Calling function: add with args: (2, 3), kwargs: {}
    # Debug logs (if enabled): Function add returned: 5
    >>> result
    5

    Enable debug for specific function:

    >>> @debug(enabled=True)
    ... def multiply(x: float, y: float) -> float:
    ...     return x * y
    >>> multiply(3.5, 2.0)
    # Debug logs: Calling function: multiply with args: (3.5, 2.0), kwargs: {}
    # Debug logs: Function multiply returned: 7.0

    Disable debug for specific function:

    >>> @debug(enabled=False)
    ... def divide(x: float, y: float) -> float:
    ...     return x / y
    >>> divide(10, 2)
    # No debug logs

    Function with keyword arguments:

    >>> @debug(enabled=True)
    ... def greet(name: str, formal: bool = False) -> str:
    ...     return f"Good day, {name}" if formal else f"Hi {name}!"
    >>> greet("Alice", formal=True)
    # Debug logs: Calling function: greet with args: ('Alice',), kwargs: {'formal': True}
    # Debug logs: Function greet returned: 'Good day, Alice'

    Monitor method calls:

    >>> class Calculator:
    ...     @debug(enabled=True)
    ...     def multiply(self, x: float, y: float) -> float:
    ...         return x * y
    >>> calc = Calculator()
    >>> calc.multiply(3.5, 2.0)
    # Debug logs: Calling function: multiply with args: (<Calculator instance>, 3.5, 2.0), kwargs: {}
    # Debug logs: Function multiply returned: 7.0

    Notes
    -----
    The decorator adds minimal performance overhead suitable for development
    and testing environments. For production use, the decorator is disabled
    by default to prevent log pollution.

    The decorator preserves all original function attributes including
    __name__, __doc__, __module__, and type hints through functools.wraps.

    All logging is performed at DEBUG level and requires appropriate
    logger configuration to be visible.

    The decorator handles functions with variable arguments (*args, **kwargs)
    and preserves the original function signature exactly.

    Environment Variables
    ---------------------
    FBPYUTILS_DEBUG_ENABLED : Set to 'true', '1', 'yes', or 'on' to enable
        debug logging globally. Default is 'false' (disabled).

    See Also
    --------
    debug_info : Extract debug information from exceptions
    fbpyutils.logging : Configure logging levels and handlers
    functools.wraps : Function decoration best practices

    """

    def decorator(f):
        # Determine if debug is enabled for this function
        is_enabled = enabled if enabled is not None else _DEBUG_ENABLED

        # Log warning if debug is used in production environment
        if is_enabled:
            try:
                env = get_env()
                if env.APP.environment.lower() == "prod":
                    _logger.warning(
                        f"@debug decorator is enabled for function '{f.__name__}' in production environment. "
                        "This may cause log pollution. Consider disabling it or using FBPYUTILS_DEBUG_ENABLED=false."
                    )
            except Exception:
                # If we can't get the environment, just proceed
                pass

        def _debug(*args, **kwargs):
            if is_enabled:
                _logger.debug(
                    f"Calling function: {f.__name__} with args: {args}, kwargs: {kwargs}"
                )
            result = f(*args, **kwargs)
            if is_enabled:
                _logger.debug(f"Function {f.__name__} returned: {result}")
            return result

        return _debug

    # Support both @debug and @debug() syntax
    if func is None:
        return decorator
    else:
        return decorator(func)


def debug_info(x: Exception, context: str = None) -> str:
    """Extract comprehensive debug information and traceback from exceptions.

    This function provides detailed exception analysis by combining the
    exception message with complete traceback information in a formatted
    string. It is designed for comprehensive error reporting, logging, and
    debugging scenarios where full context about the exception is required.

    The function handles various types of exceptions and provides fallback
    behavior if traceback formatting fails. The output format is optimized
    for both human readability and automated log processing.

    Parameters
    ----------
    x : Exception
        The exception object to analyze. Can be any instance of Exception
        or its subclasses including built-in exceptions (ValueError,
        TypeError, etc.) or custom exception classes. The function extracts
        the exception message and formats the complete traceback.
    context : str, optional
        Additional context information to include in the debug info.
        This helps identify where the exception occurred in the application flow.

    Returns
    -------
    str
        A formatted string containing comprehensive exception information
        in the format: "{exception_message}: {formatted_traceback}."

        The string includes:
        - The original exception message (via x.__str__())
        - Complete traceback formatted by traceback.format_exc()
        - Context information if provided
        - Fallback error message if traceback formatting fails

    Examples
    --------
    Basic exception analysis:

    >>> from fbpyutils.debug import debug_info
    >>> try:
    ...     raise ValueError("Invalid input value")
    ... except ValueError as e:
    ...     info = debug_info(e)
    ...     print(info)
    # Output: Invalid input value: Traceback (most recent call last):
    #         File "<stdin>", line 2, in <module>
    #         ValueError: Invalid input value.

    Exception analysis with context:

    >>> try:
    ...     result = 10 / 0
    ... except ZeroDivisionError as e:
    ...     debug_info_str = debug_info(e, context="Division operation")
    ...     print(debug_info_str)
    # Output: [Division operation] division by zero: Traceback (most recent call last):
    #         File "<stdin>", line 2, in <module>
    #         ZeroDivisionError: division by zero.

    Custom exception with detailed context:

    >>> class DataProcessingError(Exception):
    ...     def __init__(self, data_type, reason):
    ...         self.data_type = data_type
    ...         self.reason = reason
    ...         super().__init__(f"Failed to process {data_type}: {reason}")
    >>> try:
    ...     raise DataProcessingError("CSV file", "Invalid column structure")
    ... except DataProcessingError as e:
    ...     info = debug_info(e, context="Data import process")
    ...     print(info)
    # Output: [Data import process] Failed to process CSV file: Invalid column structure: [traceback...]

    Nested exception handling:

    >>> try:
    ...     try:
    ...         int("not_a_number")
    ...     except ValueError as inner:
    ...         raise RuntimeError("Conversion failed") from inner
    ... except RuntimeError as e:
    ...     info = debug_info(e, context="Type conversion")
    ...     print(info)
    # Output includes both the RuntimeError and the underlying ValueError

    Notes
    -----
    The function includes comprehensive error handling for edge cases
    and logging for debugging purposes.

    The output format is designed to be both human-readable and
    suitable for automated log analysis systems.

    All debug operations are logged at INFO level for better visibility
    in production environments.

    The function handles exceptions during traceback formatting
    gracefully by providing fallback error information.

    The returned string always ends with a period for consistent
    formatting and can be directly used in log messages.

    See Also
    --------
    debug : Decorator for function execution tracing
    traceback.format_exc : Standard library traceback formatting
    logging.Logger.error : Error level logging for production use

    """
    exception_type = type(x).__name__
    exception_msg = x.__str__()
    
    _logger.info(
        f"Extracting debug info for exception: {exception_type} - {exception_msg}",
        extra={"context": context, "exception_type": exception_type}
    )
    
    try:
        traceback_str = traceback.format_exc()
        if context:
            info = f"[{context}] {exception_msg}: {traceback_str}."
        else:
            info = f"{exception_msg}: {traceback_str}."
        _logger.debug(f"Successfully retrieved debug info for {exception_type}")
    except Exception as e:
        error_msg = f"Unable to get debug info: {e}"
        if context:
            info = f"[{context}] {exception_msg}: {error_msg}."
        else:
            info = f"{exception_msg}: {error_msg}."
        _logger.error(
            f"Failed to retrieve debug info for exception {exception_type}: {e}",
            extra={"context": context, "exception_type": exception_type, "original_exception": exception_msg}
        )

    return info
