"""
File System Operations and Management Utilities

This module provides comprehensive utilities for file and directory operations, including
file searching, content extraction, JSON handling, MIME type detection, file description,
and base64 encoding operations. The module supports both local and remote file operations
with robust error handling and performance monitoring.

The module offers six primary capabilities:

* **File Discovery**: Advanced file searching with pattern matching, recursive traversal,
  parallel processing, and performance optimization for large directory structures.

* **File Content Operations**: Read/write operations for text and binary files, JSON
  serialization/deserialization, and content extraction with configurable encoding.

* **File System Metadata**: File creation dates, MIME type detection, platform-specific
  path handling, and comprehensive file property extraction.

* **File Analysis**: Detailed file descriptions including hashes, file types, sizes,
  and specialized image information extraction for image files.

* **Base64 Operations**: Data conversion between local files, remote URLs, and base64
  encoding with validation and error handling.

* **Performance Monitoring**: Built-in performance tracking for file operations with
  detailed logging and error reporting.

Key Features:
-------------
* **Parallel File Search**: Multi-threaded file discovery using Process utilities
* **Pattern Matching**: Support for multiple file masks and glob patterns
* **Cross-Platform Compatibility**: Windows and Unix path handling with automatic
  platform detection
* **Comprehensive Error Handling**: Graceful degradation with detailed error logging
* **Memory-Efficient Operations**: Streaming support and configurable content limits
* **Rich File Metadata**: Detailed file analysis with hashes, MIME types, and properties

Dependencies:
-------------
* `os`, `sys`, `platform`: Operating system interfaces and platform detection
* `json`: JSON file parsing and serialization
* `datetime`: Timestamp handling for file dates
* `pathlib`: Modern path object handling
* `base64`: Base64 encoding and decoding operations
* `mimetypes`: MIME type detection and classification
* `requests`: HTTP operations for remote file downloads
* `glob`: File pattern matching and globbing operations
* `time.perf_counter`: High-resolution performance timing
* `fbpyutils.process`: Parallel processing utilities for file search
* `fbpyutils.image`: Image analysis utilities for file description
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Search for files with pattern matching:

>>> from fbpyutils.file import find
>>> python_files = find('/src', '*.py', recurse=True)
>>> len(python_files) > 0
True

>>> image_files = find('/assets', ['*.jpg', '*.png', '*.gif'])
>>> image_files[:3]
['/assets/photo1.jpg', '/assets/logo.png', '/assets/icon.gif']

>>> parallel_files = find('/data', '*.csv', parallel=True, recurse=True)

Read and write JSON files:

>>> from fbpyutils.file import load_from_json, write_to_json
>>> data = {'name': 'test', 'values': [1, 2, 3]}
>>> write_to_json(data, 'config.json', prettify=True)
>>> loaded = load_from_json('config.json')
>>> loaded == data
True

Extract file content and metadata:

>>> from fbpyutils.file import contents, creation_date, mime_type
>>> content = contents('/path/to/file.txt')
>>> content[:50]
bytearray(b'This is the content of the file...')
>>> mime_type('/path/to/document.pdf')
'application/pdf'
>>> creation_date('/path/to/file.txt')
datetime.datetime(2023, 12, 15, 10, 30, 45)

Get detailed file description:

>>> from fbpyutils.file import describe_file
>>> info = describe_file('/path/to/image.jpg')
>>> info.keys()
dict_keys(['complete_filename', 'filename_no_ext', 'extension', 'size_bytes',
           'creation_date', 'mime_type_code', 'mime_type_description',
           'first_256_bytes_sha256_hex', 'md5sum', 'image_info'])
>>> info['mime_type_description']
'JPEG image'

Base64 operations:

>>> from fbpyutils.file import get_base64_data_from
>>> b64_local = get_base64_data_from('/path/to/image.jpg')
>>> len(b64_local) > 0
True
>>> b64_remote = get_base64_data_from('https://example.com/logo.png')
>>> b64_string = get_base64_data_from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==')

Notes:
------
* File operations include comprehensive error handling with detailed logging
* Performance monitoring tracks operation duration and file counts
* Memory-efficient operations for large files with configurable limits
* Cross-platform compatibility with automatic path handling
* Parallel processing available for large-scale file operations
* Comprehensive MIME type detection with fallback handling

Performance Considerations:
--------------------------
* Large directory searches benefit from parallel processing
* File content reading loads entire files into memory
* Base64 operations handle remote downloads with configurable timeouts
* Pattern matching uses glob which may be slower for very large directories
* Performance metrics are logged for operation monitoring

Cross-References:
-----------------
* See `fbpyutils.process` for parallel processing utilities
* See `fbpyutils.image` for image analysis and metadata extraction
* See `fbpyutils.logging` for operation logging and performance tracking
* See `fbpyutils.setup()` for proper initialization requirements
"""

import os
import sys
import platform
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Union
import base64
import mimetypes
import requests
import glob
from time import perf_counter

import fbpyutils

from fbpyutils import get_logger
from fbpyutils.process import Process
from fbpyutils.image import get_image_info

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

_logger = get_logger()


def find(
    x: str, mask: Union[str, list] = "*.*", recurse: bool = True, parallel: bool = False
) -> list:
    """Find files in a directory tree using pattern matching with advanced search options.

    Performs comprehensive file discovery using glob patterns with support for multiple
    search masks, recursive traversal, parallel processing, and performance optimization.
    The function provides detailed logging and error handling for robust file operations
    across different directory structures and file system types.

    The search implementation uses Python's glob module for pattern matching with
    recursive support through the '**' pattern. When parallel processing is enabled,
    the function leverages fbpyutils.process.Process utilities to distribute search
    work across multiple worker processes for improved performance on large directory trees.

    Parameters
    ----------
    x : str
        Root directory path to search for files. The path can be absolute or relative
        to the current working directory. The directory must exist and be readable
        for the search to proceed.

        Example paths:
        - '/home/user/documents' (absolute path)
        - './src' (relative path from current directory)
        - 'C:\\Users\\User\\Downloads' (Windows absolute path)

    mask : Union[str, list], optional
        File pattern(s) to match during search. Can be a single string or list of strings
        using glob patterns. Multiple masks are combined with OR logic - files matching
        any pattern are included in results.

        Default: "*.*" (matches all files with extensions)

        Pattern examples:
        - '*.py' (all Python files)
        - '*.{txt,md,rst}' (text, markdown, and reStructuredText files)
        - ['*.jpg', '*.png', '*.gif'] (image files)
        - 'test_*.py' (Python files starting with 'test_')
        - '*config*' (files containing 'config' in filename)

    recurse : bool, optional
        Enable recursive directory traversal. When True, searches all subdirectories
        recursively from the starting directory. When False, only searches the
        top-level directory without traversing subdirectories.

        Default: True (recursive search enabled)

        Performance impact:
        - True: Searches entire directory tree, slower but comprehensive
        - False: Searches only immediate directory, faster for shallow structures

    parallel : bool, optional
        Enable parallel processing for recursive searches using multiple worker processes.
        When True and recurse is also True, the search is distributed across available
        CPU cores using fbpyutils.process.Process utilities. Provides significant
        performance improvements for large directory trees but adds process overhead.

        Default: False (sequential processing)

        Performance considerations:
        - Best for large directory trees (>1000 files)
        - Overhead may exceed benefits for small directories
        - Requires fbpyutils.process.Process availability

    Returns
    -------
    list
        Sorted list of unique file paths matching the specified criteria. Each path
        is a complete absolute or relative path as provided in the input parameter.
        The list is sorted alphabetically for consistent results and easy processing.

        Return format:
        ```python
        [
            '/path/to/matched_file1.ext',
            '/path/to/matched_file2.ext',
            '/path/to/subdir/matched_file3.ext'
        ]
        ```

    Raises
    ------
    OSError
        When directory access fails due to permissions, the directory doesn't exist,
        or other system-level I/O errors occur during search operations.

    PermissionError
        When the specified directory cannot be accessed due to insufficient read
        permissions for the current user or process.

    ValueError
        When invalid parameters are provided, though the function typically handles
        edge cases gracefully by returning empty results rather than raising exceptions.

    Examples
    --------
    Basic file search with default patterns:

    >>> from fbpyutils.file import find
    >>> all_files = find('/home/user/documents')
    >>> len(all_files) > 0
    True
    >>> all_files[:3]
    ['/home/user/documents/file1.txt', '/home/user/documents/file2.pdf',
     '/home/user/documents/file3.doc']

    Search for specific file types:

    >>> python_files = find('/project/src', '*.py', recurse=True)
    >>> python_files
    ['/project/src/main.py', '/project/src/utils.py', '/project/src/models/user.py']

    Multiple file patterns:

    >>> media_files = find('/assets', ['*.jpg', '*.png', '*.gif', '*.mp4'])
    >>> media_files
    ['/assets/image1.jpg', '/assets/logo.png', '/assets/video.mp4']

    Non-recursive search:

    >>> config_files = find('/etc', '*.conf', recurse=False)
    >>> config_files
    ['/etc/apache2.conf', '/etc/mysql.conf']

    Parallel processing for large directories:

    >>> large_search = find('/data', '*.csv', parallel=True, recurse=True)
    >>> # Processes thousands of CSV files across directory tree efficiently

    Error handling for missing directories:

    >>> result = find('/nonexistent/path', '*.txt')
    >>> result
    []  # Returns empty list instead of raising exception

    Notes
    -----
    * Uses Python's glob module with recursive '**' pattern support
    * Parallel processing requires fbpyutils.process.Process utilities
    * Empty results are returned for inaccessible or non-existent directories
    * Performance metrics are logged for operation monitoring
    * Memory usage scales with number of matched files
    * Unicode filenames are supported with proper encoding handling

    Performance Considerations
    --------------------------
    * Sequential search is generally faster for directories with <1000 files
    * Parallel processing overhead may exceed benefits for small searches
    * Large directory trees (>10,000 files) benefit significantly from parallel processing
    * Pattern complexity affects search performance
    * File system type and speed impact overall search performance

    Error Handling Strategy
    ------------------------
    * Inaccessible directories return empty results with error logging
    * Pattern matching errors are caught and logged individually
    * Worker process failures in parallel mode are reported but don't stop overall search
    * System-level errors are caught and logged with appropriate error messages

    See Also
    --------
    glob.glob : Core pattern matching functionality used internally
    fbpyutils.process.Process : Parallel processing utilities for enhanced performance
    os.access : Directory accessibility checking
    pathlib.Path : Modern path object handling for directory operations
    """
    start_time = perf_counter()

    if isinstance(mask, str):
        mask_list = [mask]
    else:
        mask_list = mask

    _logger.info(
        f"File search initiated: folder='{x}', masks={mask_list}, recurse={recurse}, parallel={parallel}"
    )

    source_path = Path(x)
    if not source_path.is_dir():
        _logger.error(f"Source folder not found or is not a directory: {x}")
        return []

    # Check if directory is accessible
    try:
        if not os.access(source_path, os.R_OK):
            _logger.error(f"Directory access denied: {x}")
            return []
    except OSError as e:
        _logger.error(f"Error accessing directory {x}: {e}")
        return []

    found_files = set()
    search_errors = []

    if parallel and recurse:
        _logger.info(f"Starting parallel file search with {mask_list} patterns")

        # Parallel search
        subdirectories = [str(d) for d in source_path.iterdir() if d.is_dir()]
        subdirectories.append(str(source_path))  # Include the root directory itself

        def search_worker(directory: str, search_mask: str):
            """Worker function to search for files in a directory."""
            try:
                pattern = os.path.join(directory, "**", search_mask)
                files = {
                    f for f in glob.glob(pattern, recursive=True) if os.path.isfile(f)
                }
                return True, None, list(files)
            except Exception as e:
                return False, str(e), []

        process_runner = Process(process=search_worker, parallelize=True)
        params = [(d, m) for d in subdirectories for m in mask_list]
        results = process_runner.run(params)

        for success, error, files in results:
            if success and files:
                found_files.update(files)
            elif error:
                search_errors.append(error)
                _logger.warning(f"Error in parallel search worker: {error}")

        if search_errors:
            _logger.warning(f"File search completed with {len(search_errors)} errors")
    else:
        _logger.info(f"Starting sequential file search with {mask_list} patterns")

        # Sequential search
        for m in mask_list:
            try:
                if recurse:
                    pattern = os.path.join(str(source_path), "**", m)
                    files = glob.glob(pattern, recursive=True)
                else:
                    pattern = os.path.join(str(source_path), m)
                    files = glob.glob(pattern)
                found_files.update(files)
            except Exception as e:
                search_errors.append(f"Pattern '{m}': {e}")
                _logger.error(f"Error searching pattern '{m}' in directory '{x}': {e}")

    sorted_files = sorted(list(found_files))
    duration = perf_counter() - start_time

    _logger.info(
        f"File search completed: folder='{x}', found={len(sorted_files)} files, "
        f"duration={duration:.2f}s, errors={len(search_errors)}"
    )

    if search_errors:
        _logger.warning(f"Search completed with errors: {search_errors}")

    return sorted_files


def creation_date(x: str) -> datetime:
    """Retrieve file creation or modification datetime with cross-platform compatibility.

    Provides a unified interface for retrieving file creation timestamps across different
    operating systems. On Windows, uses the native creation time (ctime). On Unix-like
    systems, attempts to use birth time (st_birthtime) when available, falling back to
    modification time (st_mtime) for systems that don't support birth time tracking.

    The function handles the differences between operating systems gracefully and
    provides consistent datetime objects regardless of the underlying file system
    capabilities. This is particularly useful for file sorting, synchronization,
    and archival operations where creation time is important.

    Parameters
    ----------
    x : str
        Path to the file for which to retrieve the creation date. The path can be
        absolute or relative to the current working directory. The file must exist
        and be accessible for the operation to succeed.

        Example paths:
        - '/home/user/documents/report.pdf' (absolute Unix path)
        - './data/backup.sql' (relative path)
        - 'C:\\Users\\User\\Documents\\file.docx' (Windows absolute path)

    Returns
    -------
    datetime
        A timezone-naive datetime object representing the file's creation time
        on Windows or the closest available timestamp on Unix systems. The returned
        datetime object has microsecond precision and can be used for comparisons,
        formatting, and arithmetic operations.

        Return format: `datetime.datetime(year, month, day, hour, minute, second, microsecond)`

    Raises
    ------
    FileNotFoundError
        When the specified file path does not exist or cannot be accessed due to
        permissions or path resolution issues.

    OSError
        When system-level errors occur during file stat operations, including
        permission denied, I/O errors, or file system corruption issues.

    ValueError
        When invalid file paths are provided that cannot be processed by the
        underlying operating system interfaces.

    Examples
    --------
    Get creation date on Windows:

    >>> from fbpyutils.file import creation_date
    >>> from datetime import datetime
    >>> dt = creation_date('C:\\Users\\User\\Documents\\file.docx')
    >>> dt
    datetime.datetime(2023, 12, 15, 10, 30, 45, 123456)
    >>> print(f"Created: {dt.strftime('%Y-%m-%d %H:%M:%S')}")
    Created: 2023-12-15 10:30:45

    Get creation date on Unix-like systems:

    >>> dt = creation_date('/home/user/documents/report.pdf')
    >>> dt.year, dt.month, dt.day
    (2023, 12, 15)
    >>> dt.hour, dt.minute, dt.second
    (14, 25, 30)

    Handle file not found:

    >>> try:
    ...     creation_date('nonexistent.txt')
    ... except FileNotFoundError as e:
    ...     print(f"File error: {e}")
    File error: [Errno 2] No such file or directory: 'nonexistent.txt'

    Notes
    -----
    * Windows uses native creation time (ctime) which tracks when file was created
    * Unix systems use birth time (st_birthtime) when available (modern file systems)
    * Falls back to modification time (st_mtime) when birth time is unavailable
    * Returned datetime is timezone-naive (no timezone information)
    * Microsecond precision is included when supported by the file system
    * File system behavior may vary between different Unix implementations

    Platform-Specific Behavior
    ---------------------------
    **Windows**: Uses `os.path.getctime()` which returns the creation time on NTFS
    and FAT file systems. This is the actual creation time of the file.

    **macOS**: Uses `stat.st_birthtime` which returns the file creation time on
    modern macOS file systems (HFS+, APFS).

    **Linux**: Uses `stat.st_birthtime` on newer kernels and file systems that
    support birth time tracking. Falls back to `stat.st_mtime` on older systems.

    **Other Unix**: Generally falls back to modification time as many traditional
    Unix file systems don't track creation time.

    Performance Considerations
    ---------------------------
    * Single system call to retrieve file metadata
    * No file content reading required, minimal I/O overhead
    * Performance is dominated by file system response time
    * Suitable for batch processing with thousands of files

    See Also
    --------
    os.path.getctime : Windows creation time retrieval
    os.stat : File status information retrieval
    datetime.fromtimestamp : Timestamp to datetime conversion
    platform.system : Operating system detection for platform-specific handling
    """
    t = None
    try:
        if platform.system() == "Windows":
            t = os.path.getctime(x)
        else:
            stat = os.stat(x)
            try:
                t = stat.st_birthtime
            except AttributeError:
                _logger.warning(f"st_birthtime not available for file '{x}', falling back to st_mtime")
                t = stat.st_mtime
    except FileNotFoundError:
        _logger.error(f"File not found when getting creation date: {x}")
        raise
    except Exception as e:
        _logger.error(f"Error getting creation date for file '{x}': {e}")
        raise

    result = datetime.fromtimestamp(t)
    return result


def load_from_json(x: str, encoding="utf-8") -> Dict:
    """Loads data from a JSON file and returns it as a dictionary.

    Args:
        x (str): The path of the file to be read.
        encoding (str): The encoding of the file. Default is 'utf-8'.

    Returns:
        Dict: A dictionary containing the data from the JSON file.

    Raises:
        FileNotFoundError: If the file does not exist.
        json.JSONDecodeError: If the file is not valid JSON.
        OSError: If there's an IO error reading the file.

    Example:
        >>> from fbpyutils.file import load_from_json
        >>> data = load_from_json('/path/to/file.json')
        >>> data
        {'key1': 'value1', 'key2': 'value2'}
    """
    try:
        with open(x, "r", encoding=encoding) as f:
            data = json.load(f)
        _logger.info(f"Successfully loaded JSON from file: {x}")
        return data
    except FileNotFoundError:
        _logger.error(f"JSON file not found: {x}")
        raise
    except json.JSONDecodeError as e:
        _logger.error(f"Error decoding JSON from file '{x}': {e}")
        raise
    except Exception as e:
        _logger.error(f"Error loading JSON from file '{x}': {e}")
        raise


def write_to_json(x: Dict, path_to_file: str, prettify=True):
    """Writes data from a dictionary to a JSON file.

    If prettify is True, uses indentation and sorting. Otherwise, compact format.

    Args:
        x (Dict): The dictionary to be written to the file.
        path_to_file (str): The path of the file to be written.
        prettify (bool): If True, formats JSON with indentation and sorted keys. Default is True.

    Raises:
        OSError: If there's an IO error writing the file.

    Example:
        >>> from fbpyutils.file import write_to_json
        >>> data = {'key1': 'value1', 'key2': 'value2'}
        >>> write_to_json(data, '/path/to/file.json', prettify=True)
        # Creates formatted JSON file.
    """
    try:
        with open(path_to_file, "w") as outputfile:
            if prettify:
                json.dump(x, outputfile, indent=4, sort_keys=True, ensure_ascii=False)
            else:
                json.dump(x, outputfile, ensure_ascii=False)
        _logger.info(f"Successfully wrote JSON to file: {path_to_file}")
    except IOError as e:
        _logger.error(f"Error writing JSON to file '{path_to_file}': {e}")
        raise
    except Exception as e:
        _logger.error(f"Error writing JSON to file '{path_to_file}': {e}")
        raise


def contents(x: str) -> bytearray:
    """Reads a file and returns its contents as a byte array.

    Note:
        This function loads the entire file into memory. For very large files,
        consider using a streaming approach to avoid high memory consumption.

    Args:
        x (str): The path of the file to be read.

    Returns:
        bytearray: The contents of the file as a byte array.

    Raises:
        FileNotFoundError: If the file does not exist.
        OSError: If there's an IO error reading the file.

    Example:
        >>> from fbpyutils.file import contents
        >>> content = contents('/path/to/file.txt')
        >>> content
        bytearray(b'This is the file contents.')
    """
    fileName = x
    fileContent = None

    try:
        with open(fileName, mode="rb") as file:
            fileContent = file.read()
        _logger.info(f"Successfully read contents from file: {x} ({len(fileContent)} bytes)")
        return fileContent
    except FileNotFoundError:
        _logger.error(f"File not found when reading contents: {x}")
        raise
    except IOError as e:
        _logger.error(f"Error reading contents from file '{x}': {e}")
        raise
    except Exception as e:
        _logger.error(f"Error reading contents from file '{x}': {e}")
        raise


def mime_type(x: str) -> str:
    """Guesses the MIME type of a file based on its extension using mimetypes.

    Args:
        x (str): The path of the file to get its MIME type.

    Returns:
        str: The guessed MIME type, 'directory' if path is a directory,
             'file_not_found' if path does not exist, or 'application/octet-stream' if undetermined.

    Example:
        >>> from fbpyutils.file import mime_type
        >>> mime_type('/path/to/file.txt')
        'text/plain'
        >>> mime_type('/path/to/unknown.xyz')
        'application/octet-stream'
        >>> mime_type('/path/to/folder/')
        'directory'
    """
    if not os.path.exists(x):
        _logger.error(f"File not found: '{x}'")
        return "file_not_found"

    if os.path.isdir(x):
        return "directory"

    try:
        mime_type_detected, _ = mimetypes.guess_type(x)
        if mime_type_detected:
            return mime_type_detected
        else:
            _logger.warning(f"Could not guess MIME type for file '{x}', defaulting to 'application/octet-stream'")
            return "application/octet-stream"
    except Exception as e:
        _logger.error(f"Error guessing MIME type for file '{x}': {e}")
        raise


def _is_windows() -> bool:
    """Returns whether the code is running on the Windows operating system.

    Internal utility function.

    Returns:
        bool: True if the current operating system is Windows, False otherwise.

    Example:
        >>> from fbpyutils.file import _is_windows
        >>> _is_windows()
        True  # On Windows
    """
    return sys.platform.upper().startswith("WIN")


def build_platform_path(winroot: str, otherroot: str, pathparts: list) -> str:
    """Builds a platform-specific path using the appropriate root for Windows or other OS.

    Uses winroot on Windows, otherroot on other systems, and joins with pathparts.

    Args:
        winroot (str): The root path for Windows operating systems.
        otherroot (str): The root path for other operating systems.
        pathparts (list): The elements to build the path. The last element should be the file.

    Returns:
        str: The platform-specific path.

    Example:
        >>> from fbpyutils.file import build_platform_path
        >>> build_platform_path('C:\\', '/root/', ['folder', 'subfolder', 'file.txt'])
        'C:\\folder\\subfolder\\file.txt'  # On Windows
        '/root/folder/subfolder/file.txt'  # On other OS
    """
    winroot = winroot.rstrip(os.path.sep)  # Remove trailing separator from winroot
    result = os.path.sep.join(
        [(winroot.rstrip(os.path.sep) if _is_windows() else otherroot), *pathparts]
    )
    return result.replace("//", "/")


def absolute_path(x: str):
    """Returns the absolute directory path for a given file path.

    Extracts the directory part from the absolute path of x. If x is empty, uses __file__.

    Args:
        x (str): The file path. If empty, defaults to the current script's directory.

    Returns:
        str: The absolute directory path.

    Example:
        >>> from fbpyutils.file import absolute_path
        >>> absolute_path('/path/to/file.txt')
        '/path/to'
        >>> absolute_path('relative/file.txt')
        '/current/working/dir/relative'
    """
    x = x or __file__
    result = os.path.sep.join(os.path.realpath(x).split(os.path.sep)[:-1])
    return result


def describe_file(file_path: str) -> Dict:
    """Describes a file, returning a dictionary with its properties including hashes and MIME info.

    Note:
        This function reads the entire file into memory to calculate hashes,
        which may cause performance issues with very large files.

    Args:
        file_path (str): The path of the file to describe.

    Returns:
        Dict: A dictionary containing file properties like name, size, dates, MIME type, hashes, and image info if applicable.

    Example:
        >>> from fbpyutils.file import describe_file
        >>> desc = describe_file('/path/to/file.txt')
        >>> desc
        {
            'complete_filename': 'file.txt',
            'filename_no_ext': 'file',
            'extension': '.txt',
            'size_bytes': 1234,
            'creation_date': '2022-01-01T10:30:15',
            'mime_type_code': 'text/plain',
            'mime_type_description': 'Text file',
            'first_256_bytes_sha256_hex': 'abc123...',
            'md5sum': 'def456...'
        }
    """
    # Import hashlib here to avoid circular dependencies if it's used elsewhere
    import hashlib

    complete_filename = os.path.basename(file_path)
    filename_no_ext, extension = os.path.splitext(complete_filename)
    size_bytes = os.path.getsize(file_path)
    # creation_date returns a naive datetime object.
    created_at = creation_date(file_path)
    mime_type_code = mime_type(file_path)

    # Basic MIME type mapping
    mime_type_map = {
        # Text files
        "text/plain": "Text file",
        "text/html": "HTML document",
        "text/css": "CSS stylesheet",
        "text/javascript": "JavaScript file",
        "text/csv": "CSV file",
        "text/xml": "XML document",
        "text/markdown": "Markdown file",
        # Documents
        "application/pdf": "PDF document",
        "application/msword": "Word document",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "Word document (DOCX)",
        "application/vnd.ms-excel": "Excel spreadsheet",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "Excel spreadsheet (XLSX)",
        "application/vnd.ms-powerpoint": "PowerPoint presentation",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": "PowerPoint presentation (PPTX)",
        "application/rtf": "Rich Text Format document",
        "application/vnd.oasis.opendocument.text": "OpenDocument text",
        "application/vnd.oasis.opendocument.spreadsheet": "OpenDocument spreadsheet",
        "application/vnd.oasis.opendocument.presentation": "OpenDocument presentation",
        # Data formats
        "application/json": "JSON file",
        "application/xml": "XML document",
        "application/yaml": "YAML file",
        "application/x-yaml": "YAML file",
        "text/yaml": "YAML file",
        # Images
        "image/jpeg": "JPEG image",
        "image/jpg": "JPEG image",
        "image/png": "PNG image",
        "image/gif": "GIF image",
        "image/bmp": "BMP image",
        "image/tiff": "TIFF image",
        "image/webp": "WebP image",
        "image/svg+xml": "SVG image",
        "image/x-icon": "Icon file",
        # Audio
        "audio/mpeg": "MP3 audio",
        "audio/wav": "WAV audio",
        "audio/ogg": "OGG audio",
        "audio/aac": "AAC audio",
        "audio/flac": "FLAC audio",
        "audio/x-m4a": "M4A audio",
        # Video
        "video/mp4": "MP4 video",
        "video/avi": "AVI video",
        "video/quicktime": "QuickTime video",
        "video/x-msvideo": "AVI video",
        "video/webm": "WebM video",
        "video/x-flv": "FLV video",
        "video/3gpp": "3GP video",
        # Archives
        "application/zip": "ZIP archive",
        "application/x-zip-compressed": "ZIP archive",
        "application/x-rar-compressed": "RAR archive",
        "application/x-7z-compressed": "7Z archive",
        "application/x-tar": "TAR archive",
        "application/gzip": "GZIP archive",
        "application/x-bzip2": "BZIP2 archive",
        # Executables
        "application/x-msdownload": "Windows executable",
        "application/x-executable": "Executable file",
        "application/x-msdos-program": "DOS executable",
        "application/vnd.microsoft.portable-executable": "Windows executable",
        "application/x-apple-diskimage": "Mac disk image",
        "application/vnd.debian.binary-package": "Debian package",
        "application/x-rpm": "RPM package",
        # Fonts
        "font/ttf": "TrueType font",
        "font/otf": "OpenType font",
        "font/woff": "WOFF font",
        "font/woff2": "WOFF2 font",
        "application/font-woff": "WOFF font",
        "application/font-woff2": "WOFF2 font",
        # Web files
        "application/javascript": "JavaScript file",
        "application/x-javascript": "JavaScript file",
        "text/x-php": "PHP file",
        "application/x-httpd-php": "PHP file",
        "application/x-python-code": "Python file",
        "text/x-python": "Python file",
        "text/x-java-source": "Java source file",
        "text/x-c": "C source file",
        "text/x-c++": "C++ source file",
        # Others
        "application/octet-stream": "Binary file",
        "application/x-binary": "Binary file",
        "inode/x-empty": "Empty file",
        "application/x-iso9660-image": "ISO image",
        "application/vnd.sqlite3": "SQLite database",
        "application/x-font-ttf": "TrueType font",
        "application/postscript": "PostScript document",
        "application/eps": "EPS document",
        "application/x-shockwave-flash": "Flash file",
        "application/vnd.adobe.flash.movie": "Flash movie",
        "application/x-bittorrent": "BitTorrent file",
        "message/rfc822": "Email message",
        "application/mbox": "Email mailbox",
        "application/pkcs7-mime": "S/MIME message",
        "application/x-x509-ca-cert": "X.509 certificate",
        "application/x-pkcs12": "PKCS#12 certificate",
        "application/pgp-keys": "PGP key",
        "application/pgp-signature": "PGP signature",
    }
    mime_type_description = mime_type_map.get(mime_type_code, "Other")

    file_content = contents(file_path)

    # SHA256 hash of the first 256 bytes
    sha256_hash = hashlib.sha256()
    sha256_hash.update(file_content[:256])
    first_256_bytes_sha256_hex = sha256_hash.hexdigest()

    # MD5 hash of the entire file
    md5_hash = hashlib.md5()
    md5_hash.update(file_content)
    md5sum = md5_hash.hexdigest()

    result = {
        "complete_filename": complete_filename,
        "filename_no_ext": filename_no_ext,
        "extension": extension,
        "size_bytes": size_bytes,
        "creation_date": created_at.isoformat(),
        "mime_type_code": mime_type_code,
        "mime_type_description": mime_type_description,
        "first_256_bytes_sha256_hex": first_256_bytes_sha256_hex,
        "md5sum": md5sum,
    }

    # Adding image info for image files
    if "image" in mime_type_code:
        result["image_info"] = get_image_info(file_path)

    return result


def get_file_head_content(
    file_path: str,
    num_bytes: int = 256,
    output_format: str = "text",
    encoding: str = "utf-8",
    errors: str = "replace",
) -> Union[str, bytes, None]:
    """Reads the first num_bytes of a file and returns its content in the specified format.

    Memory-efficient for previews, supports text, bytes, or base64 output.

    Args:
        file_path (str): The path to the file.
        num_bytes (int): The number of bytes to read. Defaults to 256.
        output_format (str): 'text', 'bytes', or 'base64'. Defaults to 'text'.
        encoding (str): Encoding for 'text' format. Defaults to 'utf-8'.
        errors (str): Error handling for decoding. Defaults to 'replace'.

    Returns:
        Union[str, bytes, None]: Content in requested format, or None on error/invalid format.

    Example:
        >>> from fbpyutils.file import get_file_head_content
        >>> head = get_file_head_content('/path/to/file.txt', num_bytes=100, output_format='text')
        >>> head
        'First 100 characters of the file...'
        >>> head_bytes = get_file_head_content('/path/to/file.bin', output_format='bytes')
        >>> len(head_bytes)
        256
    """
    if not os.path.exists(file_path):
        _logger.warning(f"File not found: {file_path}, returning None")
        return None

    try:
        with open(file_path, "rb") as f:
            head_bytes = f.read(num_bytes)

        if output_format == "text":
            return head_bytes.decode(encoding, errors=errors)
        elif output_format == "bytes":
            return head_bytes
        elif output_format == "base64":
            return base64.b64encode(head_bytes).decode("ascii")
        else:
            return None  # Invalid output_format
    except IOError as e:
        _logger.error(f"Error reading file head content from '{file_path}': {e}")
        return None
    except Exception as e:
        _logger.error(f"Error reading file head content from '{file_path}': {e}")
        return None


def get_base64_data_from(file_uri: str, timeout: int = 300) -> str:
    """Retrieves data from a file URI (local path, URL, or base64 string) as base64 encoded string.

    Handles local files, HTTP/HTTPS downloads, and validates existing base64 strings.
    Loads entire content into memory; use cautiously for large files.

    Args:
        file_uri (str): Local path, URL starting with 'http://' or 'https://', or base64 string.
        timeout (int): Timeout for URL requests in seconds. Defaults to 300.

    Returns:
        str: Base64 encoded data, or empty string on error/invalid input.

    Example:
        >>> from fbpyutils.file import get_base64_data_from
        >>> b64_local = get_base64_data_from('/path/to/image.jpg')
        >>> len(b64_local) > 0
        True
        >>> b64_url = get_base64_data_from('https://example.com/image.png')
        >>> b64_url.startswith('iVBORw0KGgo')
        True  # Valid base64
        >>> b64_valid = get_base64_data_from('valid_base64_string==')
        'valid_base64_string=='
    """
    # Check if the data file is a local file
    if os.path.exists(file_uri):
        try:
            with open(file_uri, "rb") as f:
                file_bytes = f.read()
            base64_data = base64.b64encode(file_bytes).decode("utf-8")
            _logger.info(f"Successfully encoded local file to base64: {file_uri}")
            return base64_data
        except IOError as e:
            _logger.error(f"Error reading local file '{file_uri}': {e}")
            return ""
        except Exception as e:
            _logger.error(f"Error processing local file '{file_uri}': {e}")
            return ""

    # If the data_file is a remote URL
    elif file_uri.startswith("http://") or file_uri.startswith("https://"):
        try:
            response = requests.get(file_uri, timeout=timeout)
            response.raise_for_status()  # Raise an exception for bad status codes
            image_bytes = response.content
            base64_data = base64.b64encode(image_bytes).decode("utf-8")
            _logger.info(f"Successfully downloaded and encoded remote file to base64: {file_uri}")
            return base64_data
        except requests.exceptions.RequestException as e:
            _logger.error(f"Error downloading file from '{file_uri}': {e}")
            return ""
        except Exception as e:
            _logger.error(f"Error processing remote file '{file_uri}': {e}")
            return ""

    # Assume the content is already in base64 and validate it
    else:
        try:
            # Add padding if it's missing
            missing_padding = len(file_uri) % 4
            if missing_padding:
                file_uri += "=" * (4 - missing_padding)

            # Validate by decoding
            base64.b64decode(file_uri, validate=True)
            return file_uri
        except (base64.binascii.Error, ValueError) as e:
            _logger.error(f"Invalid base64 string provided: {e}")
            return ""
        except Exception as e:
            _logger.error(f"Error during base64 validation: {e}")
            return ""
