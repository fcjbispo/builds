"""
Application Configuration Management and Environment Handling

This module provides comprehensive configuration management for the FBPyUtils application
using Pydantic models for robust data validation and a singleton pattern for global
environment access. The module handles application settings, logging configuration,
environment variable precedence, and file-based configuration loading.

The module offers three primary capabilities:

* **Data Validation**: Pydantic-based configuration models with type validation,
  field constraints, and automatic parsing from JSON files or dictionaries.

* **Singleton Environment**: Global configuration access through the Env singleton
  class with automatic initialization and environment variable precedence handling.

* **Configuration Management**: Support for custom configuration files, environment
  variable overrides, and automatic application folder creation.

Key Features:
-------------
* **Type-Safe Configuration**: Pydantic models ensure configuration data types
  are validated and conform to specified constraints
* **Environment Variable Precedence**: Config values can be overridden by environment
  variables with automatic precedence resolution
* **File-Based Configuration**: JSON configuration files with automatic fallback
  to defaults when files are missing or invalid
* **Singleton Pattern**: Global configuration access without multiple instances
* **Automatic Folder Creation**: User application folders created automatically
* **Alias Support**: Pydantic field aliases for flexible configuration naming

Dependencies:
-------------
* `os`: Operating system interface for environment variables and file operations
* `json`: JSON file parsing and configuration loading
* `pydantic`: Data validation and settings management using BaseModel
* `typing`: Type hints for configuration parameters and return values

Usage Examples:
---------------
Access global configuration through the singleton:

>>> from fbpyutils.env import Env
>>> env = Env()
>>> env.APP.name
'fbpyutils'
>>> env.LOG_LEVEL
'INFO'
>>> env.USER_APP_FOLDER
'/home/user/.fbpyutils'

Load configuration from custom JSON file:

>>> from fbpyutils.env import Env
>>> env = Env.load_config_from('custom_config.json')
>>> env.APP.version
'2.0.0'

Environment variable precedence:

>>> import os
>>> os.environ['FBPY_LOG_LEVEL'] = 'DEBUG'
>>> env = Env()
>>> env.LOG_LEVEL
'DEBUG'  # Uses environment variable, not config file

Access nested configuration values:

>>> env.CONFIG['database']['host']
'localhost'
>>> env.LOG_FILE
'/home/user/.fbpyutils/fbpyutils.log'

Notes:
------
* The singleton pattern ensures consistent configuration across the application
* Configuration is immutable after initialization to prevent runtime changes
* Environment variables take precedence over config file values
* Default configuration is loaded from the application's app.json file
* User application folder is created automatically with proper permissions
* All configuration values are validated through Pydantic models

Cross-References:
-----------------
* See `fbpyutils.logging` for logging configuration integration
* See `fbpyutils.setup()` for proper initialization requirements
* See `fbpyutils._APP_CONFIG_FILE` for default configuration file path
"""

import os
import json
import logging
from typing import Dict, Any, Optional

from pydantic import BaseModel, Field

# Module-level logger - configured later by fbpyutils.setup()
# Uses NullHandler by default to avoid "No handler found" warnings
_logger = logging.getLogger(__name__)
_logger.addHandler(logging.NullHandler())


class AppConfig(BaseModel):
    """Pydantic model for application configuration."""

    name: str = Field("fbpyutils", description="Application name")
    version: str = Field("1.6.10", description="Application version")
    environment: str = Field("dev", description="Environment (dev, prod, etc.)")
    appcode: str = Field("FBPYUTILS", description="Application code identifier")
    year: int = Field(2025, description="Base year for the application")

    class Config:
        """Pydantic configuration for AppConfig."""

        extra = "forbid"  # Disallow extra fields


class LoggingConfig(BaseModel):
    """Pydantic model for logging configuration."""

    log_level: str = Field(
        "INFO", alias="log_level", description="Logging level (DEBUG, INFO, etc.)"
    )
    log_format: str = Field(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Log message format",
    )
    log_file_path: Optional[str] = Field(None, description="Path to log file")
    log_text_size: int = Field(256, description="Maximum log text size")
    log_handlers: Optional[list] = Field(
        default_factory=lambda: ["file"], description="List of log handlers"
    )

    class Config:
        """Pydantic configuration for LoggingConfig."""

        extra = "forbid"  # Disallow extra fields


class RootConfig(BaseModel):
    """Pydantic model for root configuration combining app and logging configs."""

    app: AppConfig = Field(
        default_factory=AppConfig, description="Application configuration"
    )
    logging: LoggingConfig = Field(
        default_factory=LoggingConfig, description="Logging configuration"
    )
    config: Dict[str, Any] = Field(
        default_factory=dict, description="Additional configuration dictionary"
    )

    class Config:
        """Pydantic configuration for RootConfig."""

        extra = "forbid"  # Disallow extra fields


class Env:
    """Singleton configuration class for the application environment.

    Provides global configuration access through a singleton pattern with automatic
    initialization from JSON files or dictionaries. Manages application settings,
    logging configuration, environment variable precedence, and user folder creation.

    The class implements a thread-safe singleton pattern ensuring consistent
    configuration across the entire application. Configuration is immutable after
    initialization to prevent runtime modifications that could cause inconsistencies.

    Attributes
    ----------
    APP : AppConfig
        Application configuration including name, version, environment, appcode, and year
    USER_FOLDER : str
        User's home directory path obtained from os.path.expanduser("~")
    USER_APP_FOLDER : str
        Application-specific user folder path (~/.fbpyutils by default)
    LOG_LEVEL : str
        Effective logging level after applying environment variable precedence
    LOG_FORMAT : str
        Log message format string for logging configuration
    LOG_FILE : str
        Full path to the application log file
    LOG_TEXT_SIZE : int
        Maximum log text size limit for log rotation and management
    LOG_HANDLERS : Optional[list]
        List of configured log handlers (e.g., ["file"], ["console"])
    CONFIG : Dict[str, Any]
        Additional configuration dictionary for custom application settings

    Environment Variable Precedence
    -------------------------------
    The following environment variables override configuration file values:

    * FBPY_LOG_LEVEL: Overrides logging.log_level
    * FBPY_LOG_TEXT_SIZE: Overrides logging.log_text_size
    * FBPY_LOG_PATH: Overrides logging.log_file_path when not explicitly set

    Initialization Behavior
    -----------------------
    * First access creates the singleton instance using default app.json
    * Subsequent accesses return the same instance
    * Configuration can be customized via load_config_from() class method
    * User application folder is created automatically if missing

    Examples
    --------
    Access global configuration:

    >>> from fbpyutils.env import Env
    >>> env = Env()
    >>> print(f"App: {env.APP.name} v{env.APP.version}")
    App: fbpyutils v1.8.1
    >>> print(f"Log level: {env.LOG_LEVEL}")
    Log level: INFO
    >>> print(f"User folder: {env.USER_APP_FOLDER}")
    User folder: /home/user/.fbpyutils

    Load custom configuration:

    >>> env = Env.load_config_from('production.json')
    >>> env.APP.environment
    'production'

    Environment variable override:

    >>> import os
    >>> os.environ['FBPY_LOG_LEVEL'] = 'DEBUG'
    >>> env = Env()
    >>> env.LOG_LEVEL
    'DEBUG'

    Access custom configuration:

    >>> env.CONFIG.get('database', {})
    {'host': 'localhost', 'port': 5432}

    Notes
    -----
    * Thread-safe singleton implementation using __new__ method
    * Configuration validation via Pydantic models ensures data integrity
    * Automatic fallback to empty config if default file is missing
    * Environment variable precedence applies after configuration file parsing
    * Immutable after initialization to maintain configuration consistency

    See Also
    --------
    AppConfig : Application configuration model
    LoggingConfig : Logging configuration model
    RootConfig : Combined configuration model
    load_config_from : Class method for custom configuration loading
    """

    _instance: Optional["Env"] = None

    APP: AppConfig
    USER_FOLDER: str
    USER_APP_FOLDER: str
    LOG_LEVEL: str
    LOG_FORMAT: str
    LOG_FILE: str
    LOG_TEXT_SIZE: int
    LOG_HANDLERS: Optional[list] = None
    CONFIG: Dict[str, Any]

    def __new__(cls, config: Optional[Dict[str, Any]] = None):
        if cls._instance is None:
            instance = super().__new__(cls)
            cls._instance = instance
            instance._initialize(config)
        return cls._instance

    def _initialize(self, config: Optional[Dict[str, Any]] = None):
        """Initializes the Env instance attributes."""
        if hasattr(self, "_initialized") and self._initialized:
            _logger.debug("Env already initialized, skipping re-initialization")
            return

        config_source = "dictionary"
        if config is None:
            # If no config is provided, load from the default app.json
            current_dir = os.path.dirname(__file__)
            default_config_path = os.path.join(current_dir, "app.json")
            config_source = default_config_path
            try:
                with open(default_config_path, "r", encoding="utf-8") as f:
                    config_data = json.load(f)
                _logger.debug(
                    "Configuration loaded from default file: %s", default_config_path
                )
            except FileNotFoundError:
                _logger.warning(
                    "Default configuration file not found: %s. Using default values.",
                    default_config_path,
                )
                config_data = {}
                config_source = "defaults"
            except json.JSONDecodeError as e:
                _logger.warning(
                    "Invalid JSON in configuration file %s: %s. Using default values.",
                    default_config_path,
                    str(e),
                )
                config_data = {}
                config_source = "defaults"
        else:
            config_data = config
            _logger.debug("Configuration provided via dictionary")

        # Validate and parse the configuration using Pydantic models
        try:
            parsed_config = RootConfig.model_validate(config_data)
            _logger.debug("Configuration validated successfully")
        except Exception as e:
            _logger.error("Configuration validation failed: %s", str(e))
            raise

        self.APP = parsed_config.app
        self.USER_FOLDER = os.path.expanduser("~")
        self.USER_APP_FOLDER = os.path.join(
            self.USER_FOLDER, f".{self.APP.name.lower()}"
        )

        # Configure logging properties with precedence: environment variable -> config file -> default
        env_log_level = os.getenv("FBPY_LOG_LEVEL")
        self.LOG_LEVEL = env_log_level or parsed_config.logging.log_level
        if env_log_level:
            _logger.debug(
                "LOG_LEVEL overridden by environment variable: %s", env_log_level
            )

        self.LOG_FORMAT = parsed_config.logging.log_format

        env_log_text_size = os.getenv("FBPY_LOG_TEXT_SIZE")
        self.LOG_TEXT_SIZE = int(
            env_log_text_size or parsed_config.logging.log_text_size
        )
        if env_log_text_size:
            _logger.debug(
                "LOG_TEXT_SIZE overridden by environment variable: %s",
                env_log_text_size,
            )

        log_file_from_config = parsed_config.logging.log_file_path
        if log_file_from_config:
            self.LOG_FILE = log_file_from_config
        else:
            env_log_path = os.getenv("FBPY_LOG_PATH")
            default_log_path = env_log_path or self.USER_APP_FOLDER
            if env_log_path:
                _logger.debug(
                    "LOG_PATH overridden by environment variable: %s", env_log_path
                )
            self.LOG_FILE = os.path.join(default_log_path, "fbpyutils.log")

        self.LOG_HANDLERS = parsed_config.logging.log_handlers

        # Set the configuration dictionary
        self.CONFIG = parsed_config.config

        # Ensure USER_APP_FOLDER exists
        if not os.path.exists(self.USER_APP_FOLDER):
            try:
                os.makedirs(self.USER_APP_FOLDER)
                _logger.debug(
                    "Created user application folder: %s", self.USER_APP_FOLDER
                )
            except OSError as e:
                _logger.error(
                    "Failed to create user application folder %s: %s",
                    self.USER_APP_FOLDER,
                    str(e),
                )
                raise

        self._initialized = True
        _logger.info(
            "Environment initialized: app=%s v%s, env=%s, config_source=%s",
            self.APP.name,
            self.APP.version,
            self.APP.environment,
            config_source,
        )

    @classmethod
    def load_config_from(cls, app_conf_file: str) -> "Env":
        """Load configuration from a specified JSON file and return configured Env instance.

        This class method resets the singleton pattern and creates a new instance with
        configuration loaded from the specified JSON file. The method performs comprehensive
        error handling for missing files, invalid JSON, and validation failures, ensuring
        robust configuration loading for different deployment environments.

        The method resets the singleton instance, allowing for configuration changes
        during application runtime, which is particularly useful for multi-environment
        deployments or testing scenarios where different configurations are needed.

        Parameters
        ----------
        app_conf_file : str
            Absolute or relative path to the JSON configuration file to load.
            The file should contain a valid JSON structure matching the RootConfig
            model with 'app', 'logging', and 'config' sections.

            Example file structure:
            ```json
            {
                "app": {
                    "name": "MyApp",
                    "version": "2.0.0",
                    "environment": "production",
                    "appcode": "MYAPP",
                    "year": 2025
                },
                "logging": {
                    "log_level": "WARNING",
                    "log_format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    "log_handlers": ["console"]
                },
                "config": {
                    "database": {
                        "host": "db.example.com",
                        "port": 5432
                    }
                }
            }
            ```

        Returns
        -------
        Env
            The newly configured Env singleton instance with configuration loaded
            from the specified file. The returned instance will have all attributes
            populated according to the loaded configuration and environment variable
            precedence rules.

        Raises
        ------
        FileNotFoundError
            When the specified configuration file does not exist at the given path
            or cannot be accessed due to permissions issues.

        json.JSONDecodeError
            When the configuration file exists but contains invalid JSON syntax
            that cannot be parsed by the json module.

        OSError
            When file access fails due to system-level errors such as permission
            denied, disk full, or other I/O errors during file reading.

        Examples
        --------
        Load configuration from application-specific file:

        >>> from fbpyutils.env import Env
        >>> env = Env.load_config_from('/etc/myapp/config.json')
        >>> env.APP.name
        'MyApp'
        >>> env.APP.environment
        'production'

        Load configuration with custom logging settings:

        >>> env = Env.load_config_from('debug_config.json')
        >>> env.LOG_LEVEL
        'DEBUG'
        >>> env.LOG_HANDLERS
        ['console', 'file']

        Handle file not found error:

        >>> try:
        ...     env = Env.load_config_from('nonexistent.json')
        ... except FileNotFoundError as e:
        ...     print(f"Config file not found: {e}")
        Config file not found: Configuration file 'nonexistent.json' not found.

        Handle invalid JSON:

        >>> try:
        ...     env = Env.load_config_from('invalid.json')
        ... except json.JSONDecodeError as e:
        ...     print(f"Invalid JSON: {e}")
        Invalid JSON: Error decoding JSON from 'invalid.json'.

        Notes
        -----
        * Resets the singleton instance to allow configuration changes
        * Environment variable precedence still applies after file loading
        * Validation errors from Pydantic models will raise validation exceptions
        * The method creates the user application folder if it doesn't exist
        * Original configuration is completely replaced, not merged

        Performance Considerations
        --------------------------
        * File I/O operations occur synchronously during method execution
        * JSON parsing and validation add overhead for large configuration files
        * Singleton reset involves garbage collection of previous instance
        * Consider caching configuration results for frequently accessed settings

        See Also
        --------
        Env : Main singleton class for configuration access
        RootConfig : Configuration model used for validation
        os.path.expanduser : For user home directory resolution
        """
        _logger.info("Loading configuration from file: %s", app_conf_file)
        try:
            with open(app_conf_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            cls._instance = None  # Reset singleton to allow re-initialization
            return cls(config=config)
        except FileNotFoundError:
            _logger.error("Configuration file not found: %s", app_conf_file)
            raise FileNotFoundError(
                f"Configuration file '{app_conf_file}' not found. Cannot create Env instance."
            )
        except json.JSONDecodeError as e:
            _logger.error(
                "Invalid JSON in configuration file %s: %s", app_conf_file, str(e)
            )
            raise json.JSONDecodeError(
                f"Error decoding JSON from '{app_conf_file}'.",
                e.doc if hasattr(e, "doc") else "",
                e.pos if hasattr(e, "pos") else 0,
            )
