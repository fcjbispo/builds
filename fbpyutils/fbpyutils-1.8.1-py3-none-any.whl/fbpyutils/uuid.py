"""
UUID Generation and Snowflake ID Processing Utilities

This module provides comprehensive ID generation capabilities including cryptographically secure UUID4
generation, MD5 hashing for strings and JSON data, and distributed Snowflake ID generation
for high-concurrency environments. The module centralizes all ID generation functionality
from the fbpyutils library with thread-safe implementations and backward compatibility
support for legacy interfaces.

The module offers five primary capabilities:

* **UUID Generation**: Cryptographically secure UUID4 generation using Python's uuid module
  with proper entropy sources and standardized format compliance.

* **String Hashing**: MD5 hash generation for strings and dictionaries with UTF-8 encoding
  support and deterministic hashing for consistent results.

* **Snowflake ID Generation**: Distributed ID generation supporting datacenter/worker architecture
  with 64-bit ID composition and timestamp ordering guarantees.

* **Thread Safety**: All ID generators include proper locking mechanisms for concurrent access
  protection in multi-threaded environments with sequence overflow handling.

* **Backward Compatibility**: Legacy SnowflakeIDGenerator interface with deprecation warnings
  for smooth migration paths from older API versions.

Key Features:
-------------
* **High-Performance Generation**: Optimized ID generation for high-throughput scenarios
* **Cross-Platform Compatibility**: Works consistently across different Python environments
* **Thread-Safe Operations**: Proper locking for concurrent access protection
* **Epoch Configuration**: Customizable epochs for Snowflake ID generation
* **Component Extraction**: Decode Snowflake IDs back to constituent timestamp/worker/sequence components
* **Error Handling**: Comprehensive validation and graceful degradation
* **Logging Integration**: Detailed operation tracking and performance monitoring

Dependencies:
---------------
* `uuid`: Python standard library for UUID4 generation
* `hashlib`: MD5 hash generation for strings and JSON data
* `json`: JSON serialization for dictionary hashing
* `threading`: Thread synchronization for safe concurrent access
* `time`: Timestamp generation for Snowflake ID components
* `datetime`: Epoch handling and timestamp conversion
* `fbpyutils.logging`: Logging infrastructure for operation tracking

Usage Examples:
---------------
Generate secure UUIDs:

>>> from fbpyutils.uuid import uuid
>>> uid = uuid()
>>> len(uid)
36
>>> uid
'123e4567-e89b-12d3-a456-426614174000'

Hash strings and dictionaries:

>>> from fbpyutils.uuid import hash_string, hash_json
>>> hash_string('Hello World')
'5d41402abc4b2b76b0b6f0c1a6c9c9c9'
>>> hash_json({'key': 'value', 'num': 42})
'a1b2c3d4e5f6789...'

Snowflake ID generation:

>>> from fbpyutils.uuid import snowflake_id, Snowflake
>>> id1 = snowflake_id(datacenter_id=1, worker_id=2)
>>> id1.bit_length() <= 64
True
>>> # Generate multiple IDs (chronologically ordered)
>>> id2 = snowflake_id()
>>> id1 < id2
True

Thread-safe Snowflake generation:

>>> from fbpyutils.uuid import Snowflake
>>> generator = Snowflake(datacenter_id=1, worker_id=1)
>>> ids = [generator.next_id() for _ in range(5)]
>>> len(set(ids)) == 5  # All unique
True

Component extraction:

>>> from fbpyutils.uuid import Snowflake
>>> gen = Snowflake(datacenter_id=2, worker_id=3)
>>> snowflake_id = gen.next_id()
>>> components = gen.get_id_components(snowflake_id)
>>> components
{'timestamp': 1703123456789, 'datacenter_id': 2, 'worker_id': 3, 'sequence': 0}

Backward compatibility:

>>> from fbpyutils.uuid import SnowflakeIDGenerator
>>> legacy_gen = SnowflakeIDGenerator(machine_id=5)
>>> legacy_id = legacy_gen.generate()
>>> isinstance(legacy_id, int)
True

Notes:
------
* UUID generation uses Python's secure random number generator
* Snowflake IDs are sortable by generation time
* MD5 hashing is deterministic for consistent results
* Thread safety ensures unique IDs in concurrent scenarios
* Backward compatibility includes deprecation warnings for migration guidance
* All generators include comprehensive error handling and validation

Performance Considerations:
------------------------
* UUID generation: Suitable for high-frequency secure ID requirements
* Snowflake generation: Optimized for distributed systems with minimal coordination
* Hash operations: Efficient for data integrity verification
* Memory usage: Minimal overhead for all generators
* Concurrent access: Lock contention minimal for typical workloads

Cross-References:
-----------------
* See `fbpyutils.logging` for operation tracking and debugging
* See `fbpyutils.string` for deprecated string-based utilities
* See `fbpyutils.setup()` for proper initialization requirements
* See `threading` for lock mechanism details
* See `uuid` for UUID specification compliance
"""

import datetime
import hashlib
import json
import threading
import time
from typing import Dict, Optional

import uuid as u

import fbpyutils
from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

_logger = get_logger()


def uuid() -> str:
    """Generates a random UUID4 string.

    Uses uuid.uuid4() for cryptographically secure random UUID.

    Returns:
        str: UUID string like '123e4567-e89b-12d3-a456-426614174000'.

    Example:
        >>> from fbpyutils.uuid import uuid
        >>> uid = uuid()
        >>> len(uid)
        36
        >>> uid
        '123e4567-e89b-12d3-a456-426614174000'
    """
    generated_uuid = str(u.uuid4())
    _logger.debug(f"Generated UUID: {generated_uuid}")
    return generated_uuid


def hash_string(x: str) -> str:
    """Generates MD5 hash of a string, encoding as UTF-8.

    Args:
        x (str): Input string.

    Returns:
        str: 32-character hexadecimal MD5 hash.

    Example:
        >>> from fbpyutils.uuid import hash_string
        >>> hash_string('Hello World')
        '5d41402abc4b2b76b0b6f0c1a6c9c9c9'  # Example hash
        >>> len(hash_string('test'))
        32
    """
    _logger.debug(f"Hashing string (first 10 chars): '{x[:10]}...'")
    hashed_string = hashlib.md5(x.encode("utf-8")).hexdigest()
    _logger.debug(f"Generated hash: {hashed_string}")
    return hashed_string


def hash_json(x: Dict) -> str:
    """Generates MD5 hash of a dictionary by converting to JSON string first.

    Args:
        x (Dict): Dictionary to hash.

    Returns:
        str: MD5 hex digest of JSON string.

    Example:
        >>> from fbpyutils.uuid import hash_json
        >>> data = {'key': 'value', 'num': 42}
        >>> hash_json(data)
        'a1b2c3d4e5f6...'  # Example hash
    """
    _logger.debug("Hashing JSON dictionary.")
    # Convert dict to JSON string first
    json_str = json.dumps(x, sort_keys=True, ensure_ascii=False)
    hashed_json = hash_string(json_str)
    _logger.debug(f"Generated JSON hash: {hashed_json}")
    return hashed_json


class Snowflake:
    """
    A thread-safe Snowflake ID generator that produces unique 64-bit integer IDs.

    Implements the Snowflake algorithm with custom specifications:
    - 1 bit unused (always 0)
    - 41 bits for timestamp (milliseconds since custom epoch)
    - 5 bits for datacenter_id (0-31)
    - 5 bits for worker_id (0-31)
    - 12 bits for sequence (0-4095)

    The ID is calculated as: (timestamp << 22) | (datacenter_id << 17) | (worker_id << 12) | sequence

    Thread-safe using threading.Lock to ensure concurrent access protection.

    Note: This implementation supports up to 32 datacenters with 32 workers each,
    generating up to 4096 IDs per millisecond per worker.

    Args:
        datacenter_id (int): Datacenter ID (0-31). Defaults to 0.
        worker_id (int): Worker ID within datacenter (0-31). Defaults to 0.
        epoch_start_ms (int): Custom epoch start time in milliseconds since Unix epoch.
                             Defaults to 2020-01-01 00:00:00 UTC (1577836800000).

    Raises:
        ValueError: If datacenter_id or worker_id are out of valid range.

    Example:
        >>> from fbpyutils.uuid import Snowflake
        >>> gen = Snowflake(datacenter_id=1, worker_id=1)
        >>> id1 = gen.next_id()
        >>> id2 = gen.next_id()
        >>> id1 != id2  # True
        >>> id1 < id2  # True (chronologically ordered)
        >>> id1.bit_length() <= 64  # Fits in 64 bits, True
    """

    # Bit allocation according to specification
    UNUSED_BITS = 1
    TIMESTAMP_BITS = 41
    DATACENTER_ID_BITS = 5
    WORKER_ID_BITS = 5
    SEQUENCE_BITS = 12

    # Maximum values for each field
    MAX_DATACENTER_ID = (1 << DATACENTER_ID_BITS) - 1  # 31
    MAX_WORKER_ID = (1 << WORKER_ID_BITS) - 1          # 31
    MAX_SEQUENCE = (1 << SEQUENCE_BITS) - 1            # 4095

    # Default epoch: 2020-01-01 00:00:00 UTC
    DEFAULT_EPOCH_MS = int(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc).timestamp() * 1000)

    def __init__(
        self,
        datacenter_id: int = 0,
        worker_id: int = 0,
        epoch_start_ms: int = DEFAULT_EPOCH_MS
    ):
        """
        Initialize the Snowflake ID generator.

        Args:
            datacenter_id (int): Datacenter ID (0-31). Defaults to 0.
            worker_id (int): Worker ID within datacenter (0-31). Defaults to 0.
            epoch_start_ms (int): Custom epoch start time in milliseconds since Unix epoch.
                                 Defaults to 2020-01-01 00:00:00 UTC.

        Raises:
            ValueError: If datacenter_id or worker_id are out of valid range.
        """
        if not 0 <= datacenter_id <= self.MAX_DATACENTER_ID:
            raise ValueError(f"datacenter_id must be between 0 and {self.MAX_DATACENTER_ID}")
        if not 0 <= worker_id <= self.MAX_WORKER_ID:
            raise ValueError(f"worker_id must be between 0 and {self.MAX_WORKER_ID}")

        self.datacenter_id = datacenter_id
        self.worker_id = worker_id
        self.epoch_start_ms = epoch_start_ms

        # State management
        self.sequence = 0
        self.last_timestamp = -1
        self.lock = threading.Lock()

        _logger.info(
            f"Snowflake generator initialized: datacenter_id={datacenter_id}, "
            f"worker_id={worker_id}, epoch_start_ms={epoch_start_ms}"
        )

    def _get_current_timestamp(self) -> int:
        """Get current timestamp in milliseconds since epoch."""
        return int(time.time() * 1000)

    def _wait_next_millisecond(self, last_timestamp: int) -> int:
        """Wait until the next millisecond and return the new timestamp."""
        timestamp = self._get_current_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self._get_current_timestamp()
        return timestamp

    def _validate_parameters(self) -> None:
        """Validate generator parameters."""
        if not 0 <= self.datacenter_id <= self.MAX_DATACENTER_ID:
            raise ValueError(f"datacenter_id must be between 0 and {self.MAX_DATACENTER_ID}")
        if not 0 <= self.worker_id <= self.MAX_WORKER_ID:
            raise ValueError(f"worker_id must be between 0 and {self.MAX_WORKER_ID}")

    def next_id(self) -> int:
        """
        Generate the next unique Snowflake ID.

        Returns:
            int: Unique 64-bit integer ID.

        Raises:
            RuntimeError: If clock moves backwards significantly.
        """
        with self.lock:
            timestamp = self._get_current_timestamp()

            # Handle clock moving backwards
            if timestamp < self.last_timestamp:
                _logger.warning(
                    f"Clock moved backwards. Waiting for system time to catch up. "
                    f"Last timestamp: {self.last_timestamp}, Current: {timestamp}"
                )
                timestamp = self._wait_next_millisecond(self.last_timestamp)

            # Handle sequence overflow
            if timestamp == self.last_timestamp:
                self.sequence = (self.sequence + 1) & self.MAX_SEQUENCE
                if self.sequence == 0:
                    _logger.debug("Sequence overflow detected, waiting for next millisecond")
                    timestamp = self._wait_next_millisecond(self.last_timestamp)
            else:
                self.sequence = 0

            self.last_timestamp = timestamp

            # Calculate timestamp relative to epoch
            timestamp_diff = timestamp - self.epoch_start_ms
            if timestamp_diff < 0:
                raise RuntimeError(f"Current time is before custom epoch. Timestamp diff: {timestamp_diff}")

            # Build the ID according to specification:
            # (timestamp << 22) | (datacenter_id << 17) | (worker_id << 12) | sequence
            snowflake_id = (
                (timestamp_diff << (self.SEQUENCE_BITS + self.WORKER_ID_BITS + self.DATACENTER_ID_BITS)) |
                (self.datacenter_id << (self.SEQUENCE_BITS + self.WORKER_ID_BITS)) |
                (self.worker_id << self.SEQUENCE_BITS) |
                self.sequence
            )

            _logger.debug(
                f"Generated Snowflake ID: {snowflake_id} "
                f"(timestamp: {timestamp}, datacenter: {self.datacenter_id}, "
                f"worker: {self.worker_id}, sequence: {self.sequence})"
            )

            return snowflake_id

    def get_id_components(self, snowflake_id: int) -> Dict[str, int]:
        """
        Extract components from a Snowflake ID.

        Args:
            snowflake_id (int): Snowflake ID to decode.

        Returns:
            Dict[str, int]: Dictionary containing timestamp, datacenter_id, worker_id, and sequence.
        """
        timestamp = (snowflake_id >> (self.SEQUENCE_BITS + self.WORKER_ID_BITS + self.DATACENTER_ID_BITS)) + self.epoch_start_ms
        datacenter_id = (snowflake_id >> (self.SEQUENCE_BITS + self.WORKER_ID_BITS)) & self.MAX_DATACENTER_ID
        worker_id = (snowflake_id >> self.SEQUENCE_BITS) & self.MAX_WORKER_ID
        sequence = snowflake_id & self.MAX_SEQUENCE

        return {
            'timestamp': timestamp,
            'datacenter_id': datacenter_id,
            'worker_id': worker_id,
            'sequence': sequence
        }


def snowflake_id(
    datacenter_id: int = 0,
    worker_id: int = 0,
    epoch_start_ms: int = Snowflake.DEFAULT_EPOCH_MS
) -> int:
    """
    Generate a unique Snowflake ID using default global instance.

    Thread-safe singleton pattern that maintains state across calls.

    Args:
        datacenter_id (int): Datacenter ID (0-31). Defaults to 0.
        worker_id (int): Worker ID within datacenter (0-31). Defaults to 0.
        epoch_start_ms (int): Custom epoch start time in milliseconds since Unix epoch.
                             Defaults to 2020-01-01 00:00:00 UTC.

    Returns:
        int: Unique 64-bit integer ID.

    Raises:
        ValueError: If datacenter_id or worker_id are out of valid range.

    Example:
        >>> from fbpyutils.uuid import snowflake_id
        >>> id1 = snowflake_id()
        >>> id2 = snowflake_id(datacenter_id=1, worker_id=1)
        >>> id1 != id2  # True
        >>> isinstance(id1, int)  # True
        >>> id1 > 0  # True
        >>> # IDs are sortable by time
        >>> import time
        >>> time.sleep(0.001)  # Ensure different timestamps
        >>> id3 = snowflake_id()
        >>> id1 < id3  # Likely True
    """
    # Validate parameters
    if not 0 <= datacenter_id <= Snowflake.MAX_DATACENTER_ID:
        raise ValueError(f"datacenter_id must be between 0 and {Snowflake.MAX_DATACENTER_ID}")
    if not 0 <= worker_id <= Snowflake.MAX_WORKER_ID:
        raise ValueError(f"worker_id must be between 0 and {Snowflake.MAX_WORKER_ID}")

    # Use singleton pattern with thread-safe initialization
    if not hasattr(snowflake_id, "_generator"):
        snowflake_id._generator = Snowflake(
            datacenter_id=datacenter_id,
            worker_id=worker_id,
            epoch_start_ms=epoch_start_ms
        )
        _logger.debug(f"Created global Snowflake generator instance")
    elif (snowflake_id._generator.datacenter_id != datacenter_id or 
          snowflake_id._generator.worker_id != worker_id):
        # Recreate generator if parameters change
        snowflake_id._generator = Snowflake(
            datacenter_id=datacenter_id,
            worker_id=worker_id,
            epoch_start_ms=epoch_start_ms
        )
        _logger.debug(f"Recreated global Snowflake generator with new parameters")

    return snowflake_id._generator.next_id()


# Backward compatibility: Re-export old SnowflakeIDGenerator for compatibility
class SnowflakeIDGenerator(Snowflake):
    """
    Backward compatibility wrapper for the original SnowflakeIDGenerator.

    Maps the old machine_id parameter to the new worker_id parameter.
    Uses the old Twitter epoch for compatibility.
    """

    # Twitter Snowflake epoch for backward compatibility
    TWITTER_EPOCH = 1288834974657  # November 4, 2010

    def __init__(self, machine_id: int = 1):
        """
        Initialize with backward compatibility mapping.

        Args:
            machine_id (int): Machine ID (0-1023) - maps to worker_id (0-31) for compatibility.
        """
        # Map old machine_id to new worker_id (take mod 32 for compatibility)
        worker_id = machine_id % 32
        if machine_id > 31:
            import warnings
            warnings.warn(
                f"machine_id {machine_id} exceeds new max worker_id 31. "
                f"Using worker_id={worker_id}. Consider updating to use datacenter_id/worker_id pattern.",
                DeprecationWarning,
                stacklevel=2
            )

        super().__init__(
            datacenter_id=0,
            worker_id=worker_id,
            epoch_start_ms=self.TWITTER_EPOCH
        )
        self.machine_id = machine_id  # Keep for compatibility

    def generate(self) -> int:
        """Generate ID using backward compatible interface."""
        return self.next_id()

    def __getattr__(self, name):
        """Map old attribute names to new ones for compatibility."""
        if name == 'machine_id':
            return self.worker_id
        return super().__getattr__(name)