"""
Debugging utilities and decorators for Python applications.

This module provides comprehensive debugging functionality including decorators
for function execution tracing and exception analysis utilities. It is designed
to enhance the debugging and monitoring capabilities of Python applications
within the FBPyUtils ecosystem.

The module offers two main capabilities:
- Function execution tracing via the @debug decorator for monitoring function
  calls, arguments, and return values
- Exception analysis and debug information extraction for comprehensive
  error reporting and logging

Functions
---------
debug
    Decorator for logging function execution with arguments and return values.
debug_info
    Extract comprehensive debug information and traceback from exceptions.

Dependencies
------------
- traceback: Standard library for stack trace formatting
- fbpyutils.logging: Logging configuration and utilities

Examples
--------
Decorate functions for execution tracing:

>>> from fbpyutils.debug import debug
>>> @debug
... def calculate_area(length, width, unit='meters'):
...     area = length * width
...     return f"{area} {unit}²"
>>> result = calculate_area(5, 3)
# Logs: Calling function: calculate_area with args: (5, 3), kwargs: {'unit': 'meters'}
# Logs: Function calculate_area returned: 15 meters²

Extract exception debug information:

>>> from fbpyutils.debug import debug_info
>>> try:
...     result = 10 / 0
... except ZeroDivisionError as e:
...     debug_info = debug_info(e)
...     print(debug_info)
# Output: division by zero: Traceback (most recent call last): ...

Monitor complex function calls:

>>> @debug
... def process_data(data, validate=True, transform=None):
...     if validate:
...         assert len(data) > 0, "Data cannot be empty"
...     if transform:
...         return transform(data)
...     return data
>>> process_data([1, 2, 3], transform=lambda x: sum(x))
# Logs function calls and final result

Notes
-----
All debug functions include comprehensive logging for monitoring and
troubleshooting. The @debug decorator adds minimal overhead and is
suitable for development and testing environments.

Exception debug information includes full traceback formatting for
detailed error analysis and reporting.

See Also
--------
fbpyutils.logging: Logging configuration and utilities
fbpyutils.env: Environment management utilities
"""

import traceback

import fbpyutils

from fbpyutils import get_logger

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)


_logger = get_logger()


def debug(func):
    """Decorator for logging function execution with arguments and return values.

    This decorator provides comprehensive function execution tracing by logging
    the function name, all positional and keyword arguments, and the return
    value at DEBUG level. It is designed for development, testing, and
    monitoring scenarios where detailed function call information is needed.

    The decorator wraps the original function to intercept all calls and
    captures both input parameters and output results. It preserves the
    original function's signature, docstring, and attributes while adding
    debugging capabilities.

    Parameters
    ----------
    func : callable
        The function to be decorated. Can be any callable object including
        regular functions, methods, lambdas, or classes with __call__ method.
        The decorator preserves all original function attributes.

    Returns
    -------
    callable
        A wrapped function that provides the same interface as the original
        function but with added debug logging capabilities. The wrapper:
        
        - Logs function entry with name, args, and kwargs at DEBUG level
        - Executes the original function with the provided arguments
        - Logs function exit with name and return value at DEBUG level
        - Returns the original function's result unchanged

    Examples
    --------
    Simple function decoration:

    >>> from fbpyutils.debug import debug
    >>> @debug
    ... def add(a: int, b: int) -> int:
    ...     return a + b
    >>> result = add(2, 3)
    # Debug logs: Calling function: add with args: (2, 3), kwargs: {}
    # Debug logs: Function add returned: 5
    >>> result
    5

    Function with keyword arguments:

    >>> @debug
    ... def greet(name: str, formal: bool = False) -> str:
    ...     return f"Good day, {name}" if formal else f"Hi {name}!"
    >>> greet("Alice", formal=True)
    # Debug logs: Calling function: greet with args: ('Alice',), kwargs: {'formal': True}
    # Debug logs: Function greet returned: 'Good day, Alice'

    Monitor method calls:

    >>> class Calculator:
    ...     @debug
    ...     def multiply(self, x: float, y: float) -> float:
    ...         return x * y
    >>> calc = Calculator()
    >>> calc.multiply(3.5, 2.0)
    # Debug logs: Calling function: multiply with args: (<Calculator instance>, 3.5, 2.0), kwargs: {}
    # Debug logs: Function multiply returned: 7.0

    Lambda function decoration:

    >>> @debug
    ... def process_list(items, processor=None):
    ...     return [processor(item) for item in items] if processor else items
    >>> process_list([1, 2, 3], lambda x: x * 2)
    # Debug logs function execution with lambda processor

    Notes
    -----
    The decorator adds minimal performance overhead suitable for development
    and testing environments. For production use, consider conditional
    decoration based on environment settings.

    The decorator preserves all original function attributes including
    __name__, __doc__, __module__, and type hints through functools.wraps.

    All logging is performed at DEBUG level and requires appropriate
    logger configuration to be visible.

    The decorator handles functions with variable arguments (*args, **kwargs)
    and preserves the original function signature exactly.

    See Also
    --------
    debug_info : Extract debug information from exceptions
    fbpyutils.logging : Configure logging levels and handlers
    functools.wraps : Function decoration best practices

    """

    def _debug(*args, **kwargs):
        _logger.debug(
            f"Calling function: {func.__name__} with args: {args}, kwargs: {kwargs}"
        )
        result = func(*args, **kwargs)
        _logger.debug(f"Function {func.__name__} returned: {result}")
        return result

    return _debug


def debug_info(x: Exception) -> str:
    """Extract comprehensive debug information and traceback from exceptions.

    This function provides detailed exception analysis by combining the
    exception message with complete traceback information in a formatted
    string. It is designed for comprehensive error reporting, logging, and
    debugging scenarios where full context about the exception is required.

    The function handles various types of exceptions and provides fallback
    behavior if traceback formatting fails. The output format is optimized
    for both human readability and automated log processing.

    Parameters
    ----------
    x : Exception
        The exception object to analyze. Can be any instance of Exception
        or its subclasses including built-in exceptions (ValueError,
        TypeError, etc.) or custom exception classes. The function extracts
        the exception message and formats the complete traceback.

    Returns
    -------
    str
        A formatted string containing comprehensive exception information
        in the format: "{exception_message}: {formatted_traceback}."
        
        The string includes:
        - The original exception message (via x.__str__())
        - Complete traceback formatted by traceback.format_exc()
        - Fallback error message if traceback formatting fails

    Examples
    --------
    Basic exception analysis:

    >>> from fbpyutils.debug import debug_info
    >>> try:
    ...     raise ValueError("Invalid input value")
    ... except ValueError as e:
    ...     info = debug_info(e)
    ...     print(info)
    # Output: Invalid input value: Traceback (most recent call last):
    #         File "<stdin>", line 2, in <module>
    #         ValueError: Invalid input value.

    Handle division by zero:

    >>> try:
    ...     result = 10 / 0
    ... except ZeroDivisionError as e:
    ...     debug_info_str = debug_info(e)
    ...     print(debug_info_str)
    # Output: division by zero: Traceback (most recent call last):
    #         File "<stdin>", line 2, in <module>
    #         ZeroDivisionError: division by zero.

    Custom exception with detailed context:

    >>> class DataProcessingError(Exception):
    ...     def __init__(self, data_type, reason):
    ...         self.data_type = data_type
    ...         self.reason = reason
    ...         super().__init__(f"Failed to process {data_type}: {reason}")
    >>> try:
    ...     raise DataProcessingError("CSV file", "Invalid column structure")
    ... except DataProcessingError as e:
    ...     info = debug_info(e)
    ...     print(info)
    # Output: Failed to process CSV file: Invalid column structure: [traceback...]

    Nested exception handling:

    >>> try:
    ...     try:
    ...         int("not_a_number")
    ...     except ValueError as inner:
    ...         raise RuntimeError("Conversion failed") from inner
    ... except RuntimeError as e:
    ...     info = debug_info(e)
    ...     print(info)
    # Output includes both the RuntimeError and the underlying ValueError

    Notes
    -----
    The function includes comprehensive error handling for edge cases
    and logging for debugging purposes.

    The output format is designed to be both human-readable and
    suitable for automated log analysis systems.

    All debug operations are logged at DEBUG level for monitoring
    and troubleshooting purposes.

    The function handles exceptions during traceback formatting
    gracefully by providing fallback error information.

    The returned string always ends with a period for consistent
    formatting and can be directly used in log messages.

    See Also
    --------
    debug : Decorator for function execution tracing
    traceback.format_exc : Standard library traceback formatting
    logging.Logger.error : Error level logging for production use

    """
    _logger.debug(f"Getting debug info for exception: {x.__str__()}")
    try:
        info = f"{x.__str__()}: {traceback.format_exc()}."
        _logger.debug(f"Successfully retrieved debug info: {info}")
    except Exception as e:
        info = f"{x.__str__()}: Unable to get debug info: {e}"
        _logger.error(f"Failed to retrieve debug info for exception {x.__str__()}: {e}")

    return info
