"""
HTTP Client Utilities and Request Management

This module provides robust HTTP client implementations with comprehensive support for
both synchronous and asynchronous operations, automatic retry mechanisms, streaming
responses, and detailed error handling. The module is designed for production use
with features like connection pooling, SSL verification, user agent rotation, and
performance monitoring.

The module offers four primary capabilities:

* **HTTP Client Implementation**: Feature-rich HTTPClient class supporting both sync
  and async operations with automatic retry logic using tenacity for resilient
  network communications.

* **Request Management**: RequestsManager utility class for simplified API interactions
  with session management, authentication support, and standardized error handling.

* **Header Management**: Utility functions for generating standardized HTTP headers
  with user agent rotation and content type specification.

* **API Discovery**: Advanced parameter discovery utilities for API exploration and
  testing with systematic payload validation.

Key Features:
-------------
* **Dual Operation Modes**: Support for both synchronous and asynchronous HTTP requests
  with unified interfaces and context manager support
* **Automatic Retry Logic**: Exponential backoff retry mechanisms using tenacity library
  for handling transient network failures and rate limiting
* **Streaming Support**: Large response handling through streaming interfaces for
  memory-efficient data processing
* **Connection Management**: HTTP connection pooling with configurable timeouts and
  SSL verification options
* **User Agent Rotation**: Multiple user agent strings for avoiding detection and
  improving request success rates
* **Performance Monitoring**: Detailed logging of request duration, response sizes,
  and performance metrics for operation analysis
* **Authentication Support**: Built-in support for bearer tokens, basic authentication,
  and custom header injection

Dependencies:
-------------
* `httpx`: Modern async HTTP client with sync/async support and connection pooling
* `requests`: Popular HTTP library for synchronous requests and session management
* `tenacity`: Retry library with exponential backoff and multiple retry strategies
* `random`: User agent selection and randomization
* `time`: Performance timing and retry delay management
* `typing`: Comprehensive type hints for request parameters and responses
* `fbpyutils.logging`: Logging infrastructure for operation tracking and debugging

Usage Examples:
---------------
Basic HTTP client usage:

>>> from fbpyutils.http import HTTPClient
>>> client = HTTPClient("https://api.github.com")
>>> response = client.sync_request("GET", "users/octocat")
>>> print(f"Status: {response.status_code}")
Status: 200

>>> user_data = response.json()
>>> print(f"User: {user_data['name']}")
User: The Octocat

Asynchronous operations:

>>> import asyncio
>>> async def fetch_data():
...     async with HTTPClient("https://api.example.com") as client:
...         response = await client.async_request("GET", "data")
...         return response.json()
>>> data = asyncio.run(fetch_data())

POST requests with JSON data:

>>> response = client.sync_request(
...     "POST", 
...     "users",
...     json={"name": "John Doe", "email": "john@example.com"}
... )
>>> print(f"Created: {response.status_code}")
Created: 201

Request manager with authentication:

>>> from fbpyutils.http import RequestsManager, basic_header
>>> session = RequestsManager.create_session(bearer_token="your-api-token")
>>> response = RequestsManager.make_request(
...     session,
...     "https://api.example.com/secure/data",
...     basic_header(),
...     {"query": "test"}
... )
>>> print(f"Data: {response.json()}")
Data: {'result': 'success'}

Streaming large responses:

>>> response = client.sync_request("GET", "large-file", stream=True)
>>> with open("downloaded_file.bin", "wb") as f:
...     for chunk in response.iter_bytes():
...         f.write(chunk)

API parameter discovery:

>>> from fbpyutils.http import discover_api_params
>>> valid_params = discover_api_params(
...     base_url="https://api.github.com",
...     endpoint="search/repositories",
...     method="GET",
...     headers={"Accept": "application/vnd.github.v3+json"},
...     working_payload={"q": "python"},
...     full_payload={
...         "sort": "stars",
...         "order": "desc", 
...         "per_page": 30
...     }
... )

Notes:
------
* HTTP client supports GET, POST, PUT, and DELETE methods
* All operations include comprehensive error handling and logging
* Performance metrics are automatically logged for monitoring
* Connection pooling improves efficiency for multiple requests
* SSL verification can be disabled for development environments
* User agents are rotated automatically when requested

Performance Considerations:
---------------------------
* Connection pooling reduces overhead for multiple requests
* Streaming responses prevent memory issues with large downloads
* Exponential backoff retry logic handles temporary failures gracefully
* Asynchronous operations provide better performance for concurrent requests
* Session reuse improves performance for multiple API calls

Cross-References:
-----------------
* See `fbpyutils.logging` for request logging and performance tracking
* See `fbpyutils.setup()` for proper initialization requirements
* See `tenacity` for retry strategy customization
* See `httpx` documentation for advanced client configuration options
"""

import random
import time
from time import perf_counter
from typing import Any, Optional, Dict, Union, Tuple

import httpx
import requests
from requests.adapters import HTTPAdapter
import tenacity
from tenacity import wait_random_exponential, stop_after_attempt

import fbpyutils

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

from fbpyutils import get_logger

_logger = get_logger()

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
]


def basic_header(random_user_agent: bool = False) -> Dict[str, str]:
    """
    Returns a basic HTTP header with user agent and JSON content type.

    Args:
        random_user_agent: If True, selects a random user agent from the pool. Defaults to False.

    Returns:
        Dictionary containing User-Agent and Content-Type headers

    Example:
        >>> # Default header
        >>> header = basic_header()
        >>> print(header)
        {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)...', 'Content-Type': 'application/json'}
        >>>
        >>> # Random user agent
        >>> random_header = basic_header(random_user_agent=True)
        >>> print(random_header['User-Agent'][:50])
        Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)...
    """
    user_agent = random.choice(USER_AGENTS) if random_user_agent else USER_AGENTS[0]
    return {"User-Agent": user_agent, "Content-Type": "application/json"}


class HTTPClient:
    """
    HTTP Client for synchronous and asynchronous requests with retry logic.

    Supports GET, POST, PUT, and DELETE methods with streaming response capability.
    Methods return raw httpx.Response objects, allowing callers to handle content
    parsing (response.json(), response.text, response.content) and streaming
    (response.aiter_bytes() for async, response.iter_bytes() for sync).

    Features:
    - Automatic retry with exponential backoff using tenacity
    - Performance logging with request duration
    - SSL verification control
    - Connection timeout configuration
    - Support for both sync and async context managers

    Attributes:
        base_url: Base URL for all requests
        headers: Default HTTP headers
        verify_ssl: SSL certificate verification setting

    Example:
        >>> # Synchronous usage
        >>> client = HTTPClient(base_url="https://api.example.com")
        >>> response = client.sync_request("GET", "users/123")
        >>> data = response.json()
        >>> print(f"User: {data['name']}")
        User: John Doe
        >>>
        >>> # Asynchronous usage
        >>> import asyncio
        >>> async def fetch_data():
        ...     async with HTTPClient("https://api.example.com") as client:
        ...         response = await client.async_request("GET", "data")
        ...         return response.json()
        >>> result = asyncio.run(fetch_data())
    """

    def __init__(
        self, base_url: str, headers: Optional[Dict] = None, verify_ssl: bool = True
    ):
        """
        Initializes the HTTP client with basic configurations.

        Args:
            base_url: Base URL for requests (must include http:// or https:// protocol)
            headers: Default headers for all requests (optional)
            verify_ssl: Verify SSL certificate (default: True)

        Raises:
            ValueError: If base_url is invalid or missing protocol

        Example:
            >>> # Valid initialization
            >>> client = HTTPClient("https://api.github.com")
            >>> print(client.base_url)
            https://api.github.com

            >>> # With custom headers
            >>> client = HTTPClient(
            ...     "https://api.example.com",
            ...     headers={"Authorization": "Bearer token123"},
            ...     verify_ssl=True
            ... )
            >>> print(client.headers)
            {'Authorization': 'Bearer token123'}
            >>>
            >>> # Invalid initialization
            >>> try:
            ...     client = HTTPClient("api.example.com")  # Missing protocol
            ... except ValueError as e:
            ...     print(f"Error: {e}")
            Error: base_url must include protocol (http/https)
        """
        if not base_url.startswith(("http://", "https://")):
            _logger.error(
                f"Invalid base_url, must include protocol (http/https): {base_url}"
            )
            raise ValueError("base_url must include protocol (http/https)")

        self.base_url = base_url.rstrip("/")
        self.headers = headers or {}
        self.verify_ssl = verify_ssl

        # Configura clientes com timeout padrão e reutilização de conexão
        self._sync_client = httpx.Client(
            headers=self.headers, timeout=httpx.Timeout(10.0)
        )
        self._async_client = httpx.AsyncClient(
            headers=self.headers, timeout=httpx.Timeout(10.0)
        )
        _logger.info(f"HTTPClient initialized for {self.base_url}")

    # Removed redundant @retry decorator
    async def async_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        json: Optional[Dict] = None,
        stream: bool = False,
        wait: Any = wait_random_exponential(
            multiplier=1, max=40
        ),  # Pass retry parameters
        stop: Any = stop_after_attempt(3),  # Pass retry parameters
    ) -> httpx.Response:
        """
        Executes an asynchronous HTTP request with automatic retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: Endpoint path relative to base_url
            params: Query parameters as dictionary (optional)
            data: Form data for request body (optional)
            json: JSON data for request body (optional)
            stream: Enable response streaming (default: False)
            wait: Tenacity wait strategy for retries (default: exponential backoff)
            stop: Tenacity stop strategy for retries (default: 3 attempts)

        Returns:
            Raw httpx.Response object for caller to process

        Raises:
            httpx.HTTPStatusError: For 4xx/5xx status codes
            ValueError: For unsupported HTTP methods

        Example:
            >>> # Simple GET request
            >>> response = await client.async_request("GET", "users/123")
            >>> user_data = response.json()
            >>> print(f"User: {user_data['name']}")
            User: Alice

            >>> # POST request with JSON data
            >>> response = await client.async_request(
            ...     "POST",
            ...     "users",
            ...     json={"name": "Bob", "email": "bob@example.com"}
            ... )
            >>> print(f"Status: {response.status_code}")
            Status: 201

            >>> # Streaming response
            >>> response = await client.async_request("GET", "large-file", stream=True)
            >>> async for chunk in response.aiter_bytes():
            ...     process_chunk(chunk)
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        start_time = perf_counter()

        _logger.debug(f"Starting asynchronous request: {method} {url}")
        _logger.info(
            f"Params: {params} | Data: {data} | JSON: {json} | Stream: {stream}"
        )  # Log atualizado para incluir stream

        try:
            # Use métodos específicos (get, post, etc.) que aceitam 'stream'
            method_upper = method.upper()
            response: httpx.Response  # Type hint

            _logger.info(f"HTTP {method_upper} request initiated: {url}")
            
            if method_upper == "GET":
                response = await self._async_client.get(
                    url, params=params
                )  # Não passar stream aqui diretamente, httpx lida com isso
            elif method_upper == "POST":
                response = await self._async_client.post(
                    url, params=params, data=data, json=json
                )  # Não passar stream aqui diretamente
            elif method_upper == "PUT":
                response = await self._async_client.put(
                    url, params=params, data=data, json=json
                )  # Não passar stream aqui diretamente
            elif method_upper == "DELETE":
                response = await self._async_client.delete(
                    url, params=params, data=data, json=json
                )  # Não passar stream aqui diretamente
            else:
                _logger.error(f"Unsupported HTTP method requested: {method}")
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()

            # Log de métricas de desempenho
            duration = perf_counter() - start_time
            # Determinar o tamanho do conteúdo de forma segura
            # Determinar o tamanho do conteúdo de forma segura, evitando acessar .content em streams
            content_length_info = (
                "N/A (streaming)"
                if stream
                else response.headers.get("content-length", "N/A")
            )
            if not stream and response.is_closed and hasattr(response, "_content"):
                content_length_info = f"{len(response._content)} bytes"
            elif not stream and not response.is_closed:
                content_length_info = "N/A (content not read by client method)"

            _logger.info(
                f"HTTP {method_upper} request completed: status={response.status_code}, "
                f"duration={duration:.2f}s, size={content_length_info}"
            )

            if stream:
                # Para stream=True, retorne o objeto de resposta para o chamador iterar
                # O chamador é responsável por ler o stream (ex: response.aiter_bytes())
                return response
            else:
                # For stream=False, return the raw response object
                return response

        except httpx.HTTPStatusError as e:
            _logger.error(
                f"HTTP {method} async request failed: {url} - "
                f"Status: {e.response.status_code}, Error: {e.response.text[:200]}..."
            )
            raise
        except httpx.RequestError as e:
            _logger.error(
                f"HTTP {method} async request network error: {url} - {type(e).__name__}: {str(e)}"
            )
            raise
        except Exception as e:
            _logger.error(
                f"HTTP {method} async request unexpected error: {url} - {type(e).__name__}: {str(e)}"
            )
            raise
        finally:
            _logger.debug(f"Processing of HTTP {method} {url} finished")

    # Removed redundant @retry decorator
    def sync_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        json: Optional[Dict] = None,
        stream: bool = False,
        wait: Any = wait_random_exponential(
            multiplier=1, max=40
        ),  # Pass retry parameters
        stop: Any = stop_after_attempt(3),  # Pass retry parameters
    ) -> httpx.Response:
        """
        Executes a synchronous HTTP request with automatic retry logic.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: Endpoint path relative to base_url
            params: Query parameters as dictionary (optional)
            data: Form data for request body (optional)
            json: JSON data for request body (optional)
            stream: Enable response streaming (default: False)
            wait: Tenacity wait strategy for retries (default: exponential backoff)
            stop: Tenacity stop strategy for retries (default: 3 attempts)

        Returns:
            Raw httpx.Response object for caller to process

        Raises:
            httpx.HTTPStatusError: For 4xx/5xx status codes
            ValueError: For unsupported HTTP methods

        Example:
            >>> # Simple GET request
            >>> response = client.sync_request("GET", "users/123")
            >>> user_data = response.json()
            >>> print(f"User: {user_data['name']}")
            User: Charlie

            >>> # PUT request with JSON data
            >>> response = client.sync_request(
            ...     "PUT",
            ...     "users/123",
            ...     json={"name": "David", "active": True}
            ... )
            >>> print(f"Update status: {response.status_code}")
            Update status: 200
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        start_time = perf_counter()

        _logger.debug(f"Starting synchronous request: {method} {url}")
        _logger.info(
            f"Params: {params} | Data: {data} | JSON: {json} | Stream: {stream}"
        )  # Log atualizado para incluir stream

        try:
            # Usar httpx para requisições síncronas
            method_upper = method.upper()
            
            _logger.info(f"HTTP {method_upper} synchronous request initiated: {url}")
            
            if method_upper == "GET":
                response = self._sync_client.get(url, params=params)
            elif method_upper == "POST":
                response = self._sync_client.post(url, json=json)
            elif method_upper == "PUT":
                response = self._sync_client.put(url, json=json)
            elif method_upper == "DELETE":
                response = self._sync_client.delete(url)
            else:
                _logger.error(f"Unsupported HTTP method requested: {method}")
                raise ValueError(f"Unsupported HTTP method: {method}")
            response.raise_for_status()

            duration = perf_counter() - start_time
            content_size = 'N/A (streaming)' if stream else f'{len(response.content)} bytes'
            
            _logger.info(
                f"HTTP {method_upper} synchronous request completed: status={response.status_code}, "
                f"duration={duration:.2f}s, size={content_size}"
            )

            # Return the raw response object
            return response

        except httpx.HTTPError as e:  # Capturar exceções de httpx
            _logger.error(
                f"HTTP {method} synchronous request failed: {url} - {type(e).__name__}: {str(e)}"
            )
            raise
        except Exception as e:
            _logger.error(
                f"Unexpected error in HTTP {method} synchronous request: {url} - {type(e).__name__}: {str(e)}"
            )
            raise
        finally:
            _logger.debug(f"Processing of HTTP {method} {url} finished")

    def __enter__(self):
        """
        Support for synchronous context management.

        Returns:
            Self reference for use in with statements

        Example:
            >>> with HTTPClient("https://api.example.com") as client:
            ...     response = client.sync_request("GET", "data")
            ...     print(f"Status: {response.status_code}")
            Status: 200
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Ensures proper closing of the synchronous client.

        Args:
            exc_type: Exception type if an exception occurred
            exc_val: Exception value if an exception occurred
            exc_tb: Exception traceback if an exception occurred
        """
        self._sync_client.close()

    async def __aenter__(self):
        """
        Support for asynchronous context management.

        Returns:
            Self reference for use in async with statements

        Example:
            >>> async with HTTPClient("https://api.example.com") as client:
            ...     response = await client.async_request("GET", "data")
            ...     print(f"Status: {response.status_code}")
            Status: 200
        """
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Ensures proper closing of the asynchronous client.

        Args:
            exc_type: Exception type if an exception occurred
            exc_val: Exception value if an exception occurred
            exc_tb: Exception traceback if an exception occurred
        """
        await self._async_client.aclose()


# HTTP Request manager for API calls
class RequestsManager:
    """
    A utility class for making HTTP requests with retry logic and error handling.

    This class provides a common interface for making HTTP requests to external APIs,
    handling common error scenarios, and supporting both streaming and non-streaming responses.

    Features:
    - Support for both GET and POST HTTP methods
    - Streaming response handling (POST only)
    - Automatic retry with exponential backoff
    - JSON response parsing
    - Comprehensive error handling and _logger
    - Centralized HTTP session management

    The class is primarily designed for interacting with LLM APIs like OpenAI but can be
    used for any service that requires HTTP requests with JSON responses.
    """

    @staticmethod
    def create_session(
        max_retries: int = 2,
        auth: Optional[Tuple[str, str]] = None,
        bearer_token: Optional[str] = None,
        verify_ssl: Union[bool, str] = True,
    ) -> requests.Session:
        """
        Creates and configures a requests Session with retry capabilities.

        Args:
            max_retries: Maximum number of retries for the session adapter
            auth: Tuple of (username, password) for basic authentication
            bearer_token: Bearer token for authentication
            verify_ssl: Verify SSL certificate (True/False or path to CA bundle)

        Returns:
            Configured requests.Session object

        Example:
            >>> # Basic session
            >>> session = RequestsManager.create_session()
            >>> print(f"Session created with {session.adapters} adapters")
            Session created with {'http://': <HTTPAdapter>, 'https://': <HTTPAdapter>} adapters
            >>>
            >>> # Session with authentication
            >>> auth_session = RequestsManager.create_session(
            ...     bearer_token="your-api-token",
            ...     verify_ssl=True
            ... )
            >>> print("Authorization" in auth_session.headers)
            True
        """
        session = requests.Session()
        adapter = HTTPAdapter(max_retries=max_retries)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        if auth:
            session.auth = auth
        if bearer_token:
            session.headers.update({"Authorization": f"Bearer {bearer_token}"})

        session.verify = verify_ssl
        return session

    @staticmethod
    def request(
        url: str,
        headers: Dict[str, str],
        json_data: Dict[str, Any],
        timeout: Union[int, Tuple[int, int]] = (30, 30),
        method: str = "GET",
        stream: bool = False,
        max_retries: int = 2,
        auth: Optional[Tuple[str, str]] = None,
        bearer_token: Optional[str] = None,
        verify_ssl: Union[bool, str] = True,
        wait: Any = wait_random_exponential(multiplier=1, max=40),  # Add wait parameter
        stop: Any = stop_after_attempt(3),  # Add stop parameter
    ) -> requests.Response:
        """
        Convenience method that creates a session and makes a request in one call.

        Args:
            url: The URL to make the request to
            headers: The headers to include in the request
            json_data: The JSON data to include in the request body
            timeout: The request timeout in seconds or tuple of (connect, read) timeouts
            method: HTTP method to use ("GET", "POST", "PUT" or "DELETE", defaults to "GET")
            stream: Whether to stream the response
            max_retries: Maximum number of retries for the session adapter
            auth: Tuple of (username, password) for basic authentication
            bearer_token: Bearer token for authentication
            verify_ssl: Verify SSL certificate (True/False or path to CA bundle)

        Returns:
            Raw requests.Response object for caller to process

        Example:
            >>> # Simple GET request
            >>> response = RequestsManager.request(
            ...     "https://api.github.com/users/octocat",
            ...     basic_header(),
            ...     {}
            ... )
            >>> print(f"Status: {response.status_code}")
            Status: 200
            >>>
            >>> # POST request with authentication
            >>> response = RequestsManager.request(
            ...     "https://api.example.com/data",
            ...     basic_header(),
            ...     {"key": "value"},
            ...     method="POST",
            ...     bearer_token="your-token"
            ... )
            >>> print(f"Response: {response.json()}")
            Response: {'status': 'success'}
        """
        session = RequestsManager.create_session(
            max_retries=max_retries,
            auth=auth,
            bearer_token=bearer_token,
            verify_ssl=verify_ssl,
        )
        return RequestsManager.make_request(
            session=session,
            url=url,
            headers=headers,
            json_data=json_data,
            timeout=timeout,
            method=method,
            stream=stream,
            wait=wait,  # Pass wait parameter
            stop=stop,  # Pass stop parameter
        )

    @staticmethod
    # @retry decorator removed from here and moved to the internal method
    def make_request(
        session: requests.Session,
        url: str,
        headers: Dict[str, str],
        json_data: Dict[str, Any],
        timeout: Union[int, Tuple[int, int]],
        method: str = "GET",
        stream: bool = False,
        wait: Any = wait_random_exponential(multiplier=1, max=40),  # Add wait parameter
        stop: Any = stop_after_attempt(3),  # Add stop parameter
    ) -> requests.Response:
        """
        Makes an HTTP request to the specified URL with the given parameters.

        Args:
            session: The requests Session object to use for the request
            url: The URL to make the request to
            headers: The headers to include in the request
            json_data: The JSON data to include in the request body
            timeout: The request timeout in seconds or tuple of (connect, read) timeouts
            method: HTTP method to use ("GET", "POST", "PUT" or "DELETE", defaults to "GET")
            stream: Whether to stream the response
            wait: Tenacity wait strategy for retries (default: exponential backoff)
            stop: Tenacity stop strategy for retries (default: 3 attempts)

        Returns:
            Raw requests.Response object for caller to process

        Raises:
            requests.exceptions.Timeout: If the request times out
            requests.exceptions.RequestException: For other request-related errors
            ValueError: If an unsupported HTTP method is specified

        Example:
            >>> # Create session and make request
            >>> session = RequestsManager.create_session()
            >>> response = RequestsManager.make_request(
            ...     session,
            ...     "https://api.example.com/users",
            ...     basic_header(),
            ...     {"page": 1, "limit": 10},
            ...     method="GET"
            ... )
            >>> users = response.json()
            >>> print(f"Found {len(users)} users")
            Found 25 users
        """
        # Validate HTTP method
        method = method.upper()
        if method not in ["GET", "POST", "PUT", "DELETE"]:
            raise ValueError(
                f"Unsupported HTTP method: {method}. Supported methods are GET, POST, PUT and DELETE."
            )

        if stream and method != "POST":
            raise ValueError(
                "Streaming is only supported for POST requests in RequestsManager."
            )

        # Convert timeout to tuple if necessary
        if isinstance(timeout, int):
            timeout = (timeout, timeout)

        # Call the internal method that handles execution and retries
        return RequestsManager._execute_request_with_retry(
            session=session,
            url=url,
            headers=headers,
            json_data=json_data,
            timeout=timeout,
            method=method,
            stream=stream,
            wait=wait,  # Pass wait parameter
            stop=stop,  # Pass stop parameter
        )

    @staticmethod
    # Remove the decorator from here, it will be applied dynamically or parameters passed
    # @retry(wait=wait_random_exponential(multiplier=1, max=40), stop=stop_after_attempt(3))
    def _execute_request_with_retry(
        session: requests.Session,
        url: str,
        headers: Dict[str, str],
        json_data: Dict[str, Any],
        timeout: Tuple[int, int],
        method: str,
        stream: bool,
        wait: Any = wait_random_exponential(multiplier=1, max=40),  # Add wait parameter
        stop: Any = stop_after_attempt(3),  # Add stop parameter
    ) -> requests.Response:
        """
        Internal method to execute the request with retry logic using tenacity.

        Args:
            session: The requests Session object
            url: The URL to make the request to
            headers: The headers to include in the request
            json_data: The JSON data to include in the request body
            timeout: The request timeout tuple
            method: HTTP method to use
            stream: Whether to stream the response
            wait: Tenacity wait strategy for retries
            stop: Tenacity stop strategy for retries

        Returns:
            requests.Response object from the successful request

        Note:
            This method applies retry logic using tenacity.Retrying and will
            automatically retry failed requests according to the wait and stop strategies.
        """
        # Apply retry dynamically using tenacity.Retrying
        retryer = tenacity.Retrying(wait=wait, stop=stop)
        return retryer(
            RequestsManager._execute_single_request,
            session=session,
            url=url,
            headers=headers,
            json_data=json_data,
            timeout=timeout,
            method=method,
            stream=stream,
        )

    @staticmethod
    def _execute_single_request(
        session: requests.Session,
        url: str,
        headers: Dict[str, str],
        json_data: Dict[str, Any],
        timeout: Tuple[int, int],
        method: str,
        stream: bool,
    ) -> requests.Response:
        """
        Internal method to execute a single request without retry logic.

        Args:
            session: The requests Session object
            url: The URL to make the request to
            headers: The headers to include in the request
            json_data: The JSON data to include in the request body
            timeout: The request timeout tuple
            method: HTTP method to use
            stream: Whether to stream the response

        Returns:
            requests.Response object from the request

        Raises:
            requests.exceptions.Timeout: If the request times out
            requests.exceptions.RequestException: For other request-related errors

        Note:
            This is the core method that actually executes the HTTP request.
            Streaming is only supported for POST requests.
        """
        try:
            if stream:
                # For streaming responses (ensure method is POST as validated in make_request)
                # Note: The check and warning for non-POST stream is now in make_request logic,
                # but we ensure method is POST here if stream is True.
                if method != "POST":
                    # This case might occur if called directly, enforce POST for stream
                    _logger.warning(
                        f"Internal: Streaming requires POST. Overriding method {method} to POST."
                    )
                    method = "POST"

                response = session.post(
                    url, headers=headers, json=json_data, timeout=timeout, stream=True
                )
                response.raise_for_status()

                # For streaming responses, return the raw response object
                # The caller is responsible for iterating over response.iter_lines() or response.iter_content()
                return response
            else:
                # For normal (non-streaming) responses
                if method == "GET":
                    response = session.get(
                        url, headers=headers, params=json_data, timeout=timeout
                    )
                elif method == "POST":
                    response = session.post(
                        url, headers=headers, json=json_data, timeout=timeout
                    )
                elif method == "PUT":
                    response = session.put(
                        url, headers=headers, json=json_data, timeout=timeout
                    )
                elif method == "DELETE":
                    response = session.delete(
                        url, headers=headers, json=json_data, timeout=timeout
                    )
                # No else needed here as method is validated in make_request

                response.raise_for_status()
                # Return the raw response object
                return response
        # Capture a broader range of exceptions for tenacity to retry on
        except (requests.exceptions.Timeout, requests.exceptions.RequestException) as e:
            error_msg = f"{method} request to {url} failed: {str(e)}"
            _logger.error(error_msg)
            # Re-raise the original exception so tenacity can catch it
            raise e


def discover_api_params(
    base_url: str,  # Alterado para receber a URL base
    endpoint: str,  # Alterado para receber o endpoint
    method: str,
    headers: Dict,
    working_payload: Dict,
    full_payload: Dict,
) -> Dict:
    """
    Discovers valid API parameters by systematically testing payload combinations.

    Iteratively tests each parameter from the full_payload against the API endpoint,
    adding parameters that result in successful responses (200-299 status codes) to
    the working payload. Automatically handles 400 Bad Request errors by skipping
    invalid parameters.

    Args:
        base_url: Base URL for the API
        endpoint: Target API endpoint relative to the base_url
        method: HTTP method ('GET' or 'POST')
        headers: Request headers dictionary
        working_payload: Base payload with known valid parameters
        full_payload: Full set of parameters to test

    Returns:
        Dictionary of parameters that resulted in successful responses

    Raises:
        ValueError: If method is not 'GET' or 'POST'
        httpx.HTTPStatusError: For HTTP errors other than 400 Bad Request

    Example:
        >>> # Discover valid parameters for a search API
        >>> valid_params = discover_api_params(
        ...     base_url="https://api.github.com",
        ...     endpoint="search/repositories",
        ...     method="GET",
        ...     headers={"Accept": "application/vnd.github.v3+json"},
        ...     working_payload={"q": "python"},
        ...     full_payload={
        ...         "sort": "stars",
        ...         "order": "desc",
        ...         "per_page": 30,
        ...         "invalid_param": "test"
        ...     }
        ... )
        >>> print(f"Valid parameters: {valid_params}")
        Valid parameters: {'q': 'python', 'sort': 'stars', 'order': 'desc', 'per_page': 30}
        >>> # Note: 'invalid_param' was skipped due to 400 Bad Request
    """
    if method not in ("GET", "POST"):
        raise ValueError("Only GET and POST methods are supported")

    working_params = working_payload.copy()
    client = HTTPClient(base_url, headers=headers)  # Inicializa com a base_url

    for key, value in full_payload.items():
        test_payload = {**working_params, key: value}
        try:  # Adicionado bloco try-except
            if method == "POST":
                response = client.sync_request(
                    method=method,
                    endpoint=endpoint,  # Passa o endpoint
                    json=test_payload,
                )
            else:
                response = client.sync_request(
                    method=method,
                    endpoint=endpoint,  # Passa o endpoint
                    params=test_payload,
                )

            if 200 <= response.status_code < 300:
                working_params[key] = value

            time.sleep(3)  # Movido para dentro do try

        except httpx.HTTPStatusError as e:  # Captura HTTPStatusError
            if e.response.status_code == 400:  # Verifica se é 400 Bad Request
                _logger.warning(
                    f"Received 400 Bad Request for key '{key}'. Skipping parameter."
                )  # Log de aviso
                continue  # Continua para o próximo parâmetro
            else:
                raise e  # Relança outras exceções HTTPStatusError

    return working_params
