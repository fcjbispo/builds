"""
Application Logging Infrastructure and Configuration Management

This module provides a comprehensive logging system for the FBPyUtils application with
singleton pattern implementation, automatic configuration from environment settings,
and support for both traditional text and JSON log formats. The module handles thread-safe
file logging with rotation, console output, and runtime reconfiguration capabilities.

The module offers five primary capabilities:

* **Singleton Logger Management**: Centralized logging instance ensuring consistent
  configuration across the application with automatic environment integration.

* **Multi-Format Support**: Both traditional text formatting and JSON structured logging
  with automatic formatter selection based on configuration preferences.

* **File Logging with Rotation**: Thread-safe file logging using ConcurrentRotatingFileHandler
  with automatic rotation, backup management, and UTF-8 encoding support.

* **Runtime Configuration**: Dynamic reconfiguration capabilities allowing log level,
  format, and handler changes without application restart.

* **Environment Integration**: Automatic configuration from Env singleton with environment
  variable precedence and fallback to sensible defaults.

Key Features:
-------------
* **Thread-Safe Operations**: Concurrent logging support for multi-threaded applications
* **Automatic Rotation**: File-based logging with size-based rotation and backup management
* **JSON Structured Logging**: Support for machine-readable log formats with python-json-logger
* **Environment Precedence**: Configuration values overridden by environment variables
* **NullHandler Fallback**: Safe default behavior when no handlers are configured
* **Configuration Validation**: Comprehensive error handling for invalid configurations

Dependencies:
-------------
* `logging`: Python's core logging functionality
 standard logging module for* `concurrent_log_handler`: Thread-safe file logging with rotation support
* `pythonjsonlogger` (optional): JSON formatting with fallback to text
* `os`: File system operations for log path management and directory creation
* `typing`: Type hints for configuration parameters and return values

Usage Examples:
---------------
Basic logging setup and usage:

>>> from fbpyutils import setup, get_logger
>>> setup()  # Configures logger from environment
>>> logger = get_logger()
>>> logger.info("Application started successfully")
>>> logger.warning("Low memory detected: {usage}%", usage=85)

JSON format logging:

>>> from fbpyutils.logging import Logger
>>> config = {'log_level': 'DEBUG', 'log_format': 'json', 'log_handlers': ['file']}
>>> Logger.configure_from_config_dict(config)
>>> logger = get_logger()
>>> logger.info("Processing request", extra_data={"user_id": 123, "endpoint": "/api/users"})

Runtime reconfiguration:

>>> from fbpyutils import get_logger
>>> logger = get_logger()
>>> # Update environment settings
>>> env.LOG_LEVEL = 'DEBUG'
>>> logger.configure_from_env(env)
>>> logger.debug("Debug logging enabled")

File and console logging:

>>> from fbpyutils.logging import Logger
>>> Logger.configure('MyApp', 'INFO', log_file_path='/var/log/app.log', log_format='json')
>>> logger = get_logger()
>>> logger.info("Application initialized", version="1.0.0")

Notes:
------
* Logger must be configured via fbpyutils.setup() before use
* JSON format requires pythonjsonlogger package installation
* File logging automatically creates directories as needed
* ConcurrentRotatingFileHandler ensures thread-safe file operations
* Environment variables override configuration file values

Cross-References:
-----------------
* See `fbpyutils.env` for environment configuration integration
* See `fbpyutils.setup()` for automatic logger configuration
"""

import logging
import os
from typing import Dict, Any, Optional
from concurrent_log_handler import ConcurrentRotatingFileHandler

try:
    from pythonjsonlogger import jsonlogger
    JSON_LOGGER_AVAILABLE = True
except ImportError:
    JSON_LOGGER_AVAILABLE = False


# Forward declaration of Env to avoid circular import
class Env:
    pass


class Logger:
    """Singleton logging class providing static interface to Python's logging module.

    Ensures single logger instance. Must be configured via fbpyutils.setup() which calls get_from_env().
    Supports reconfiguration at runtime. Uses ConcurrentRotatingFileHandler for thread-safe logging.
    Supports both JSON and traditional text log formats.

    Attributes:
        DEBUG (int): DEBUG log level constant.
        INFO (int): INFO log level constant.
        WARNING (int): WARNING log level constant.
        ERROR (int): ERROR log level constant.
        CRITICAL (int): CRITICAL log level constant.

    Example:
        >>> from fbpyutils import setup, get_logger
        >>> setup()  # Configures logger
        >>> logger = get_logger()
        >>> logger.info("Application started")
        # Logs to console and file if configured.
    """

    _instance: Optional["Logger"] = None

    # Log levels available as class attributes for convenience.
    DEBUG: int = logging.DEBUG
    INFO: int = logging.INFO
    WARNING: int = logging.WARNING
    ERROR: int = logging.ERROR
    CRITICAL: int = logging.CRITICAL

    _logger: logging.Logger = logging.getLogger("fbpyutils")
    _is_configured: bool = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @staticmethod
    def _create_formatter(log_format: str) -> logging.Formatter:
        """Creates appropriate formatter based on log format specification.

        Args:
            log_format (str): Format string or 'json' for JSON formatting.

        Returns:
            logging.Formatter: Configured formatter instance.

        Raises:
            ImportError: If 'json' format requested but python-json-logger not installed.
        """
        if log_format.lower() == "json":
            if not JSON_LOGGER_AVAILABLE:
                raise ImportError(
                    "JSON logging format requires 'python-json-logger' package. "
                    "Install it with: pip install python-json-logger"
                )
            return jsonlogger.JsonFormatter(
                "%(asctime)s %(name)s %(levelname)s %(funcName)s %(lineno)d %(message)s",
                timestamp=True
            )
        else:
            return logging.Formatter(log_format)

    @staticmethod
    def _configure_internal(config_dict: Dict[str, Any]) -> None:
        """Internal method to configure logging from a dictionary.

        Sets level, format, and handlers (console/file). Clears existing handlers to avoid duplicates.
        Supports both JSON and traditional text log formats.

        Args:
            config_dict (Dict[str, Any]): Config with 'app_name', 'log_level', 'log_format', 'log_file_path', 'log_handlers'.

        Raises:
            ValueError: If no valid handlers are configured.
            ImportError: If JSON format requested but python-json-logger not installed.
        """
        app_name = config_dict.get("app_name")
        if app_name and isinstance(app_name, str):
            Logger._logger = logging.getLogger(app_name.lower())

        log_level_str = config_dict.get("log_level", "INFO").upper()
        log_format = config_dict.get(
            "log_format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )

        # Only use file logging if explicitly configured
        if config_dict:
            log_file_path = config_dict.get(
                "log_file_path",
                os.path.sep.join(["~", ".fbpyutils", "logs", "app.log"]),
            )
            log_file_path = os.path.expanduser(log_file_path)
            log_handlers = config_dict.get("log_handlers", ["file", "console"])
        else:
            # When config_dict is empty, use only null handler (no file/console)
            log_file_path = None
            log_handlers = []

        numeric_level = getattr(logging, log_level_str, logging.INFO)
        Logger._logger.setLevel(numeric_level)

        # Clear existing handlers to prevent duplicate logs on re-configuration
        if Logger._logger.handlers:
            for handler in Logger._logger.handlers[:]:
                handler.close()
                Logger._logger.removeHandler(handler)

        formatter = Logger._create_formatter(log_format)

        # File Handler
        if "file" in log_handlers:
            if log_file_path:
                try:
                    log_dir = os.path.dirname(log_file_path)
                    if log_dir and not os.path.exists(log_dir):
                        os.makedirs(log_dir)

                    file_handler = ConcurrentRotatingFileHandler(
                        log_file_path,
                        maxBytes=256 * 1024,  # 256 KB
                        backupCount=5,
                        encoding="utf-8",
                    )
                    file_handler.setFormatter(formatter)
                    Logger._logger.addHandler(file_handler)
                except Exception as e:
                    print(f"Error setting up file logger at {log_file_path}: {e}")

        # Console Handler
        if "console" in log_handlers:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            Logger._logger.addHandler(console_handler)

        # Add NullHandler only if no other handlers are configured
        if not Logger._logger.hasHandlers():
            null_handler = logging.NullHandler()
            Logger._logger.addHandler(null_handler)

        # check if at least one handler is added
        if not Logger._logger.hasHandlers():
            raise ValueError(
                "No valid log handlers configured. Please check 'log_handlers' in the configuration. Valid options are 'none', 'console' and 'file'."
            )

        Logger._is_configured = True

    @classmethod
    def get_from_env(cls, env: "Env") -> "Logger":
        """Gets the singleton Logger instance configured from an Env object.

        Primary method for obtaining configured logger after fbpyutils.setup().

        Args:
            env (Env): Configured Env instance with LOG_LEVEL, LOG_FORMAT, etc.

        Returns:
            Logger: The configured singleton logger instance.

        Example:
            >>> from fbpyutils import setup, get_logger
            >>> setup()
            >>> logger = get_logger()  # Calls get_from_env internally
            >>> logger.info("Test log")
            # Logs according to Env config.
        """
        config = {
            "log_level": env.LOG_LEVEL,
            "log_format": env.LOG_FORMAT,
            "log_file_path": env.LOG_FILE,
            "log_handlers": env.LOG_HANDLERS,
            "app_name": getattr(env.APP, "appcode", None),
        }
        cls._configure_internal(config)
        return cls()

    @staticmethod
    def configure_from_env(env: "Env") -> None:
        """Re-configures the logger at runtime from an Env object.

        Logs a confirmation message after reconfiguration.

        Args:
            env (Env): Env instance with updated logging settings.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> # Update env LOG_LEVEL to 'DEBUG'
            >>> logger.configure_from_env(env)
            # Logs: Logging system re-configured from Env.
        """
        config_dict = {
            "log_level": env.LOG_LEVEL,
            "log_format": env.LOG_FORMAT,
            "log_file_path": env.LOG_FILE,
            "log_handlers": env.LOG_HANDLERS,
            "app_name": getattr(env.APP, "appcode", None),
        }
        Logger._configure_internal(config_dict)
        Logger._logger.info("Logging system re-configured from Env.")

    @staticmethod
    def configure_from_config_dict(config_dict: Dict[str, Any]) -> None:
        """Re-configures the logger from a configuration dictionary.

        Args:
            config_dict (Dict[str, Any]): Dict with 'log_level', 'log_format', etc.

        Example:
            >>> from fbpyutils.logging import Logger
            >>> config = {'log_level': 'DEBUG', 'log_handlers': ['console']}
            >>> Logger.configure_from_config_dict(config)
            # Logs: Logging system re-configured.
        """
        Logger._configure_internal(config_dict)
        Logger._logger.info("Logging system re-configured.")

    @staticmethod
    def configure(
        app_name: str, log_level: str, log_format: str = None, log_file_path=None
    ) -> None:
        """Convenience method to configure logger with basic parameters.

        Uses file handler by default.

        Args:
            app_name (str): Logger name.
            log_level (str): Log level like 'INFO'.
            log_format (str, optional): Log format string or 'json'. Defaults to standard.
            log_file_path (str, optional): Path to log file.

        Example:
            >>> from fbpyutils.logging import Logger
            >>> Logger.configure('MyApp', 'DEBUG', log_format='json', log_file_path='/logs/myapp.log')
            # Configures logger for 'MyApp' at DEBUG level with JSON format.
        """
        Logger.configure_from_config_dict(
            {
                "log_level": log_level,
                "log_format": log_format,
                "log_file_path": log_file_path,
                "log_handlers": ["file"],
                "app_name": app_name,
            }
        )

    @staticmethod
    def _check_configured():
        """Checks if logger is configured, raises RuntimeError if not.

        Internal method called by logging methods.
        """
        if not Logger._is_configured:
            raise RuntimeError(
                "Logger not configured. "
                "Please call fbpyutils.setup() before using the logger."
            )

    @staticmethod
    def debug(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with DEBUG severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.debug("Debugging user %s", "Alice")
            # Logs at DEBUG level if enabled.
        """
        Logger._check_configured()
        Logger._logger.debug(message, *args, **kwargs)

    @staticmethod
    def info(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with INFO severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.info("User %s logged in", "Alice")
            # Logs at INFO level.
        """
        Logger._check_configured()
        Logger._logger.info(message, *args, **kwargs)

    @staticmethod
    def warning(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with WARNING severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.warning("Low disk space for user %s", "Alice")
            # Logs at WARNING level.
        """
        Logger._check_configured()
        Logger._logger.warning(message, *args, **kwargs)

    @staticmethod
    def error(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with ERROR severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.error("Failed to process file for user %s", "Alice")
            # Logs at ERROR level.
        """
        Logger._check_configured()
        Logger._logger.error(message, *args, **kwargs)

    @staticmethod
    def critical(message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with CRITICAL severity on the root logger.

        Args:
            message (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> logger = get_logger()
            >>> logger.critical("System shutdown initiated")
            # Logs at CRITICAL level.
        """
        Logger._check_configured()
        Logger._logger.critical(message, *args, **kwargs)

    @staticmethod
    def log(log_type: int, log_text: str, *args: Any, **kwargs: Any) -> None:
        """Logs a message with a custom log level on the root logger.

        Args:
            log_type (int): Log level constant (e.g., logging.DEBUG).
            log_text (str): Log message.
            *args, **kwargs: Arguments for message formatting.

        Example:
            >>> from fbpyutils import get_logger
            >>> import logging
            >>> logger = get_logger()
            >>> logger.log(logging.WARNING, "Custom warning: %s", "Test")
            # Logs at WARNING level.
        """
        Logger._check_configured()
        Logger._logger.log(log_type, log_text, *args, **kwargs)