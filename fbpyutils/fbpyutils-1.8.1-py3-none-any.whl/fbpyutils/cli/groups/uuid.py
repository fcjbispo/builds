"""
UUID and Snowflake ID generation commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for uuid commands
app = typer.Typer(name="uuid", help="Commands for UUID generation and Snowflake ID creation.", rich_markup_mode="rich")


@app.command("uuid4")
def uuid4_cmd(
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate a standard UUID4 string."""
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.uuid import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@app.command("hash-string")
def hash_string_cmd(
    input: str = typer.Option(..., "--input", help="String to hash."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate MD5 hash from a string."""
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.uuid import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@app.command("hash-json")
def hash_json_cmd(
    input: str = typer.Option(..., "--input", help="JSON string or path to JSON file."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate MD5 hash from a JSON dictionary."""
    try:
        logger.info("Generating MD5 hash from JSON")

        import json
        from fbpyutils.uuid import hash_json

        # Try to parse as JSON, if it fails, try reading as file
        try:
            data = json.loads(input)
        except json.JSONDecodeError:
            # Try reading as file path
            try:
                with open(input, 'r') as f:
                    data = json.load(f)
            except FileNotFoundError:
                raise ValueError(f"Input is not valid JSON or file path: {input}")

        result = hash_json(data)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("JSON hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate JSON hash")


@app.command("snowflake")
def snowflake_cmd(
    datacenter_id: int = typer.Option(0, "--datacenter-id", help="Datacenter ID (0-31)."),
    worker_id: int = typer.Option(0, "--worker-id", help="Worker ID (0-31)."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate a Snowflake ID using the new implementation."""
    try:
        logger.info(f"Generating Snowflake ID (datacenter_id: {datacenter_id}, worker_id: {worker_id})")

        from fbpyutils.uuid import snowflake_id

        result = snowflake_id(datacenter_id=datacenter_id, worker_id=worker_id)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate Snowflake ID")


@app.command("snowflake-classic")
def snowflake_classic_cmd(
    machine_id: int = typer.Option(1, "--machine-id", help="Machine ID (0-1023)."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate a Snowflake ID using the classic Twitter algorithm (deprecated)."""
    try:
        logger.info(f"Generating classic Snowflake ID (machine_id: {machine_id})")

        from fbpyutils.uuid import SnowflakeIDGenerator

        generator = SnowflakeIDGenerator(machine_id=machine_id)
        result = generator.generate()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Classic Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate classic Snowflake ID")


@app.command("snowflake-decode")
def snowflake_decode_cmd(
    snowflake_id: int = typer.Argument(..., help="Snowflake ID to decode."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Decode a Snowflake ID into its components."""
    try:
        logger.info(f"Decoding Snowflake ID: {snowflake_id}")

        from fbpyutils.uuid import Snowflake

        snowflake = Snowflake()
        result = snowflake.get_id_components(snowflake_id)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Snowflake ID decoded successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to decode Snowflake ID")