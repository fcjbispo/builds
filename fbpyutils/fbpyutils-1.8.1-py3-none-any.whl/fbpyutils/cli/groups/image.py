"""
Command group for image processing CLI commands.
"""

import typer
import os
import fbpyutils
from fbpyutils.image import (
    get_image_info,
    resize_image,
    enhance_image_for_ocr,
)
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

# Initialize logger
fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for image commands
app = typer.Typer(name="image", help="Commands for image processing and analysis.", rich_markup_mode="rich")


@app.command()
def info(
    source: str = typer.Option(..., "--source", help="Path to image file or image bytes (for piped input)."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Extract detailed information from an image including EXIF metadata and geolocation."""
    try:
        info_data = get_image_info(source)
        if "error" in info_data:
            raise ValueError(info_data["error"])

        formatted_output = format_output(info_data, output_format)
        typer.echo(formatted_output)

    except Exception as e:
        handle_error(e, "Failed to extract image information")


@app.command()
def resize(
    source: str = typer.Option(..., "--source", help="Path to image file or image bytes (for piped input)."),
    width: int = typer.Option(..., "--width", help="Target width in pixels."),
    height: int = typer.Option(..., "--height", help="Target height in pixels."),
    maintain_aspect_ratio: bool = typer.Option(True, "--maintain-aspect-ratio", help="Maintain aspect ratio during resize."),
    quality: int = typer.Option(85, "--quality", help="JPEG quality (1-100)."),
    output_file: str = typer.Option(..., "--output-file", help="Path to save the resized image."),
):
    """Resize an image to specified dimensions and save to file."""
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Resize image
        resized_bytes = resize_image(
            source, width, height, maintain_aspect_ratio, quality
        )

        # Write to file
        with open(output_file, "wb") as f:
            f.write(resized_bytes)

        logger.info(f"Resized image saved to {output_file}")
        typer.echo(f"Image successfully resized and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to resize image")


@app.command()
def enhance_ocr(
    source: str = typer.Option(..., "--source", help="Path to image file or image bytes (for piped input)."),
    contrast_factor: float = typer.Option(2.0, "--contrast-factor", help="Contrast enhancement factor (default: 2.0)."),
    threshold: int = typer.Option(128, "--threshold", help="Binarization threshold (0-255, default: 128)."),
    output_file: str = typer.Option(..., "--output-file", help="Path to save the enhanced image."),
):
    """Enhance image for better OCR accuracy using preprocessing techniques."""
    try:
        # Validate output directory exists
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Enhance image
        enhanced_bytes = enhance_image_for_ocr(source, contrast_factor, threshold)

        # Write to file
        with open(output_file, "wb") as f:
            f.write(enhanced_bytes)

        logger.info(f"Enhanced image saved to {output_file}")
        typer.echo(f"Image successfully enhanced and saved to {output_file}")

    except Exception as e:
        handle_error(e, "Failed to enhance image for OCR")
