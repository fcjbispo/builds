"""
XLSX commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for xlsx commands
app = typer.Typer(name="xlsx", help="Commands for Excel file manipulation.", rich_markup_mode="rich")


@app.command("list-sheets")
def list_sheets_cmd(
    file: str = typer.Option(..., "--file", help="Path to the Excel file."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Retrieve the names of all sheets from an Excel file."""
    try:
        logger.info(f"Listing sheets from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_names

        result = get_sheet_names(file)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Sheets listed successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to list sheets")


@app.command("read-sheet")
def read_sheet_cmd(
    file: str = typer.Option(..., "--file", help="Path to the Excel file."),
    sheet_name: str = typer.Option(..., "--sheet-name", help="Name of the sheet to read."),
    output_file: str = typer.Option(None, "--output-file", help="Path to save the sheet content (optional)."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Read the content of a specific sheet from an Excel file."""
    try:
        logger.info(f"Reading sheet '{sheet_name}' from Excel file: {file}")

        from fbpyutils.xlsx import get_sheet_by_name

        result = get_sheet_by_name(file, sheet_name)

        if output_file:
            import json

            with open(output_file, "w", encoding="utf-8") as f:
                if output_format == "json":
                    json.dump(result, f, indent=2, default=str)
                elif output_format == "csv":
                    import csv

                    writer = csv.writer(f)
                    for row in result:
                        writer.writerow(row)
                else:  # txt
                    for row in result:
                        f.write("\t".join(str(cell) for cell in row) + "\n")
            logger.info(f"Sheet content saved to {output_file}")
        else:
            formatted_result = format_output(result, output_format)
            typer.echo(formatted_result)

        logger.debug("Sheet read successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read sheet")
