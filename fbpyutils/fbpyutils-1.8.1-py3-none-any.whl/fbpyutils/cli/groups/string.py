"""
String commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for string commands
app = typer.Typer(name="string", help="Commands for string manipulation.", rich_markup_mode="rich")


@app.command("uuid")
def uuid_cmd(
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate a standard UUID4 string."""
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.string import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@app.command("similarity")
def similarity_cmd(
    string1: str = typer.Option(..., "--string1", help="First string to compare."),
    string2: str = typer.Option(..., "--string2", help="Second string to compare."),
    ignore_case: bool = typer.Option(True, "--ignore-case", help="Ignore case during comparison."),
    compress_spaces: bool = typer.Option(True, "--compress-spaces", help="Compress extra spaces."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Calculate similarity ratio between two strings."""
    try:
        logger.info(
            f"Calculating similarity between strings (ignore_case: {ignore_case}, compress_spaces: {compress_spaces})"
        )

        from fbpyutils.string import similarity

        result = similarity(string1, string2, ignore_case, compress_spaces)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Similarity calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate similarity")


@app.command("random")
def random_cmd(
    length: int = typer.Option(32, "--length", help="Length of the random string."),
    include_digits: bool = typer.Option(True, "--include-digits", help="Include digits."),
    include_special: bool = typer.Option(False, "--include-special", help="Include special characters."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate a random string."""
    try:
        logger.info(
            f"Generating random string of length {length} (include_digits: {include_digits}, include_special: {include_special})"
        )

        from fbpyutils.string import random_string

        result = random_string(length, include_digits, include_special)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Random string generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate random string")


@app.command("hash")
def hash_cmd(
    input: str = typer.Option(..., "--input", help="String to hash."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Generate MD5 hash from a string."""
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.string import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@app.command("normalize-float")
def normalize_float_cmd(
    value: float = typer.Option(..., "--value", help="Float value to normalize."),
    size: int = typer.Option(4, "--size", help="Total length of output string."),
    decimal_places: int = typer.Option(2, "--decimal-places", help="Number of decimal places."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Convert float to zero-padded string."""
    try:
        logger.info(
            f"Normalizing float {value} to string (size: {size}, decimal_places: {decimal_places})"
        )

        from fbpyutils.string import normalize_value

        result = normalize_value(value, size, decimal_places)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Float normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize float")


@app.command("translate-chars")
def translate_chars_cmd(
    input: str = typer.Option(..., "--input", help="String to translate."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Translate special characters to basic counterparts."""
    try:
        logger.info("Translating special characters")

        from fbpyutils.string import translate_special_chars

        result = translate_special_chars(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Special characters translated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to translate special characters")


@app.command("normalize-list")
def normalize_list_cmd(
    names: str = typer.Option(..., "--names", help="Comma-separated list of strings to normalize."),
    normalize_specials: bool = typer.Option(True, "--normalize-specials", help="Translate special characters."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Normalize a list of strings."""
    try:
        logger.info(
            f"Normalizing list of strings (normalize_specials: {normalize_specials})"
        )

        from fbpyutils.string import normalize_names

        names_list = [name.strip() for name in names.split(",")]
        result = normalize_names(names_list, normalize_specials)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("List normalized successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to normalize list")


@app.command("split-by-lengths")
def split_by_lengths_cmd(
    input: str = typer.Option(..., "--input", help="String to split."),
    lengths: str = typer.Option(..., "--lengths", help="Comma-separated list of lengths."),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Split string by specified lengths."""
    try:
        logger.info("Splitting string by lengths")

        from fbpyutils.string import split_by_lengths

        lengths_list = [int(length.strip()) for length in lengths.split(",")]
        result = split_by_lengths(input, lengths_list)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("String split successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to split string")
