"""
Process commands for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for process commands
app = typer.Typer(name="process", help="Commands for process management.", rich_markup_mode="rich")


@app.command("cpu-count")
def get_cpu_count(
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Get the number of available CPU cores."""
    try:
        logger.info("Getting available CPU count")

        from fbpyutils.process import Process

        result = Process.get_available_cpu_count()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Available CPU count: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get CPU count")


@app.command("check-parallel")
def check_parallel(
    parallel_type: str = typer.Option("threads", "--parallel-type", help="Type of parallelization to check.", case_sensitive=False),
    output_format: str = typer.Option("txt", "--output-format", help="Output format.", case_sensitive=False),
):
    """Check if parallelization is supported for the given type."""
    try:
        logger.info(f"Checking parallelization support for {parallel_type}")

        from fbpyutils.process import Process

        result = Process.is_parallelizable(parallel_type)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Parallelization support for {parallel_type}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to check parallelization support")
