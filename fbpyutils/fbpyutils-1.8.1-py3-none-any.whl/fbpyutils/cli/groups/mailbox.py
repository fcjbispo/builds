"""
Mailbox CLI commands for fbpyutils.

This module provides Typer-based CLI commands for MBOX file analysis.
"""

import typer
from typing import Optional
import fbpyutils
from fbpyutils.cli.utils.error_handler import handle_error
from fbpyutils.mailbox import MboxReader

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for mailbox commands
app = typer.Typer(name="mailbox", help="MBOX file analysis commands.", rich_markup_mode="rich")


@app.command()
def metadata(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    format: str = typer.Option("json", "--format", "-f", help="Output format (default: json)", case_sensitive=False),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """Extract metadata from all messages in MBOX file."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_all_metadata(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Metadata saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error extracting metadata: {e}")
        handle_error(e, "Failed to extract metadata")


@app.command()
def message(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    identifier: str = typer.Argument(..., help="Message identifier"),
    search_type: str = typer.Option("auto", "--search-type", help="Search type (default: auto)", case_sensitive=False),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """Get details of a specific message."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_message_details(identifier, search_type)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Message details saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error getting message details: {e}")
        handle_error(e, "Failed to get message details")


@app.command()
def list(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    limit: Optional[int] = typer.Argument(None, help="Limit number of messages"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """List message summaries."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.list_messages_summary(limit)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Message list saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error listing messages: {e}")
        handle_error(e, "Failed to list messages")


@app.command()
def search(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    term: str = typer.Argument(..., help="Search term"),
    search_fields: str = typer.Option("subject,from,to", "--search-fields", help="Fields to search in (comma-separated)"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """Search messages by term."""
    try:
        reader = MboxReader(mbox_file)
        fields_list = [field.strip() for field in search_fields.split(",")]
        results = reader.search_messages(term, fields_list)

        # Format results as JSON
        import json

        search_results = {
            "search_term": term,
            "search_fields": fields_list,
            "total_found": len(results),
            "messages": [],
        }

        for message, index in results:
            summary = {
                "index": index,
                "message_id": str(message.get("Message-ID", "")),
                "subject": str(message.get("Subject", "")),
                "from": str(message.get("From", "")),
                "date": str(message.get("Date", "")),
                "has_attachments": message.is_multipart(),
            }
            search_results["messages"].append(summary)

        result = json.dumps(search_results, indent=2, ensure_ascii=False)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Search results saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error searching messages: {e}")
        handle_error(e, "Failed to search messages")


@app.command()
def summary(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    format: str = typer.Option("json", "--format", "-f", help="Output format (default: json)", case_sensitive=False),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
):
    """Generate mailbox summary."""
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_mailbox_summary(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Summary saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        handle_error(e, "Failed to generate summary")
