"""
Main entry point for the fbpyutils CLI.
"""

import typer
import fbpyutils
from fbpyutils import get_env
from fbpyutils.cli.utils.error_handler import handle_error

# Import command groups
from fbpyutils.cli.groups import (
    calendar,
    datetime,
    file,
    image,
    mailbox,
    ofx,
    process,
    string,
    uuid,
    xlsx,
)

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app
app = typer.Typer(
    name="fbpyutils",
    help="A CLI client for the fbpyutils library.",
    rich_markup_mode="rich"
)

# Add version
app.add_typer(calendar.app, name="calendar")
app.add_typer(datetime.app, name="datetime")
app.add_typer(file.app, name="file")
app.add_typer(image.app, name="image")
app.add_typer(mailbox.app, name="mailbox")
app.add_typer(ofx.app, name="ofx")
app.add_typer(process.app, name="process")
app.add_typer(string.app, name="string")
app.add_typer(uuid.app, name="uuid")
app.add_typer(xlsx.app, name="xlsx")


def version_callback(value: bool):
    if value:
        typer.echo(f"fbpyutils version {get_env().APP.version}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(False, "--version", callback=version_callback, is_eager=True, help="Show version and exit.")
):
    """A CLI client for the fbpyutils library."""
    pass


if __name__ == "__main__":
    try:
        app()
    except Exception as e:
        logger.critical(f"Critical error in CLI: {e}")
        handle_error(e, "Critical error occurred")
