"""
File commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def file():
    """Commands for file manipulation."""


@file.command("find")
@click.option("--path", required=True, help="Source folder to find files from.")
@click.argument("mask", nargs=-1)
@click.option(
    "--recurse",
    is_flag=True,
    default=False,  # Changed default to False
    help="Search recursively in subdirectories.",
)
@click.option(
    "--parallel",
    is_flag=True,
    default=False,
    help="Use parallel search if recurse is enabled.",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def find_files(path: str, mask: str, recurse: bool, parallel: bool, output_format: str):
    """Find files in a source folder using a specific mask."""
    try:
        if not mask:
            mask = ["*.*"]
        logger.info(f"Finding files in {path} with mask {mask}")

        from fbpyutils.file import find

        result = find(path, mask, recurse, parallel)

        if output_format == "txt":
            for file_path in result:
                click.echo(file_path)
        else:
            formatted_result = format_output(result, output_format)
            click.echo(formatted_result)

        logger.debug(f"Found {len(result)} files")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to find files")


@file.command("read-bytes")
@click.option("--path", required=True, help="Path of the file to read.")
def read_bytes(path: str):
    """Read a file and return its contents as bytes."""
    try:
        logger.info(f"Reading bytes from {path}")

        from fbpyutils.file import contents

        result = contents(path)

        # Output as binary data
        click.echo(result, nl=False)

        logger.debug(f"Read {len(result)} bytes from {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read file bytes")


@file.command("mime-type")
@click.option("--path", required=True, help="Path of the file to get MIME type.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def get_mime_type(path: str, output_format: str):
    """Guess the MIME type of a file."""
    try:
        logger.info(f"Getting MIME type for {path}")

        from fbpyutils.file import mime_type

        result = mime_type(path)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug(f"MIME type for {path}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get MIME type")


@file.command("describe")
@click.option("--path", required=True, help="Path of the file to describe.")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def describe_file(path: str, output_format: str):
    """Describe a file, returning its properties."""
    try:
        logger.info(f"Describing file {path}")

        from fbpyutils.file import describe_file

        result = describe_file(path)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug(f"Described file {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to describe file")


@file.command("to-base64")
@click.option("--uri", required=True, help="URI of the file to process.")
@click.option("--timeout", default=300, help="Timeout for URL requests.")
def to_base64(uri: str, timeout: int):
    """Retrieve data from a URI and return as base64 string."""
    try:
        logger.info(f"Converting {uri} to base64")

        from fbpyutils.file import get_base64_data_from

        result = get_base64_data_from(uri, timeout)

        click.echo(result)

        logger.debug(f"Converted {uri} to base64")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to convert to base64")
