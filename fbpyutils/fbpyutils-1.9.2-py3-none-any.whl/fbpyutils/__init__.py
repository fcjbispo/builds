"""
Francisco Bispo's Utilities for Python (FBPyUtils)

This module provides the main entry point and initialization infrastructure for the FBPyUtils
library, a comprehensive Python utility library offering helper functions and classes for
common development tasks. The module manages singleton instances for environment configuration
and logging, ensuring consistent behavior across the application.

The module offers three primary capabilities:

* **Library Initialization**: Centralized setup() function for configuring the library
  with support for dictionary, file path, or default configuration sources.

* **Environment Management**: Singleton Env instance providing access to application
  configuration, logging settings, and environment variables with precedence handling.

* **Logging Infrastructure**: Singleton Logger instance with thread-safe file logging,
  JSON format support, and runtime reconfiguration capabilities.

Key Features:
-------------
* **Singleton Pattern**: Ensures single instances of Env and Logger across the application
* **Flexible Configuration**: Support for dict, file path, or default JSON configuration
* **Environment Variable Precedence**: Configuration values overridden by environment variables
* **Thread-Safe Logging**: ConcurrentRotatingFileHandler for multi-threaded applications
* **Automatic Initialization**: Default configuration from app.json with fallback handling
* **Error Handling**: Comprehensive exception handling with detailed logging

Dependencies:
-------------
* `os`: File system operations for configuration file paths
* `json`: JSON configuration file parsing
* `logging`: Temporary logger for initialization phase
* `typing`: Type hints for configuration parameters and return values
* `dotenv`: Environment variable loading from .env files
* `fbpyutils.env`: Env class for configuration management
* `fbpyutils.logging`: Logger class for logging infrastructure

Usage Examples:
---------------
Basic initialization with default configuration:

>>> import fbpyutils
>>> fbpyutils.setup()  # Uses default app.json
>>> from fbpyutils import string, file, datetime
>>> uuid_str = string.uuid()
>>> len(uuid_str)
36

Custom configuration with dictionary:

>>> import fbpyutils
>>> fbpyutils.setup({'log_level': 'DEBUG', 'log_format': 'json'})
>>> logger = fbpyutils.get_logger()
>>> logger.debug("Debug logging enabled")

Custom configuration from file:

>>> import fbpyutils
>>> fbpyutils.setup('/path/to/custom_config.json')
>>> env = fbpyutils.get_env()
>>> env.APP.name
'MyApp'

Accessing environment and logger:

>>> import fbpyutils
>>> fbpyutils.setup()
>>> env = fbpyutils.get_env()
>>> logger = fbpyutils.get_logger()
>>> logger.info(f"App: {env.APP.name}, Version: {env.APP.version}")

Using library modules after initialization:

>>> import fbpyutils
>>> fbpyutils.setup()
>>> from fbpyutils import calendar, datetime, file
>>> cal = calendar.get_calendar(datetime.date(2023, 1, 1), datetime.date(2023, 1, 31))
>>> len(cal)
31

Notes:
------
* setup() must be called before importing or using any fbpyutils modules
* Environment variables loaded from .env file take precedence over configuration files
* The default configuration file is fbpyutils/app.json in the package directory
* Singleton instances are created once and reused across the application
* Calling setup() multiple times will reinitialize the singletons
* All modules require fbpyutils.setup() to be called before use

Error Handling:
---------------
* FileNotFoundError: Configuration file not found at specified path
* json.JSONDecodeError: Invalid JSON format in configuration file
* RuntimeError: get_env() or get_logger() called before setup()

Cross-References:
-----------------
* See `fbpyutils.env.Env` for environment configuration details
* See `fbpyutils.logging.Logger` for logging configuration details
* See `fbpyutils/app.json` for default configuration structure
* See `dotenv.load_dotenv` for environment variable loading
"""

import os
import json
import logging as stdlib_logging
from typing import Dict, Any, Optional, Union

from .env import Env
from .logging import Logger

from dotenv import load_dotenv

_ = load_dotenv()  # take environment variables from .env.

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_APP_CONFIG_FILE = os.path.sep.join([_ROOT_DIR, "app.json"])

# Variáveis globais para armazenar as instâncias singleton
_env_instance: Optional[Env] = None
_logger_instance: Optional[Logger] = None

# Temporary logger for initialization phase (before setup is called)
_init_logger = stdlib_logging.getLogger("fbpyutils.init")
_init_logger.addHandler(stdlib_logging.NullHandler())


def setup(config: Optional[Union[Dict[str, Any], str]] = None) -> None:
    """
    Initializes the global environment and logging system for the fbpyutils library.

    This function should be called once when the application starts. It creates singleton
    instances of Env and Logger, allowing for configuration via a dictionary, a file path,
    or falling back to the default 'app.json' if no configuration is provided. The function
    loads environment variables from .env files and handles configuration precedence.

    Parameters
    ----------
    config : Optional[Union[Dict[str, Any], str]], default=None
        Configuration source for initializing the library. Can be one of:
        
        - None: Loads configuration from the default 'fbpyutils/app.json' file
        - Dict[str, Any]: A dictionary containing configuration values
        - str: A file path to a JSON configuration file
        
        Configuration dictionary structure:
        ```python
        {
            'app': {
                'name': 'MyApp',
                'version': '1.0.0',
                'environment': 'dev',
                'appcode': 'MYAPP',
                'year': 2025
            },
            'logging': {
                'log_level': 'INFO',
                'log_format': 'json',
                'log_file_path': '~/.fbpyutils/logs/app.log',
                'log_handlers': ['file', 'console']
            },
            'config': {
                'custom_key': 'custom_value'
            }
        }
        ```

    Returns
    -------
    None
        This function does not return a value. It initializes global singleton instances
        that can be accessed via get_env() and get_logger().

    Raises
    ------
    FileNotFoundError
        If the specified configuration file path does not exist or cannot be accessed.

    json.JSONDecodeError
        If the configuration file contains invalid JSON syntax.

    RuntimeError
        If there is an error during initialization of the Env or Logger instances.

    Exception
        For any other unexpected errors during the setup process.

    Examples
    --------
    Initialize with default configuration:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> env = fbpyutils.get_env()
    >>> env.APP.name
    'FBPyUtils'

    Initialize with custom dictionary:

    >>> import fbpyutils
    >>> fbpyutils.setup({
    ...     'app': {'name': 'MyApp', 'version': '1.0.0'},
    ...     'logging': {'log_level': 'DEBUG'}
    ... })
    >>> logger = fbpyutils.get_logger()
    >>> logger.debug("Debug message")

    Initialize from custom file:

    >>> import fbpyutils
    >>> fbpyutils.setup('/path/to/custom_config.json')
    >>> env = fbpyutils.get_env()
    >>> env.APP.environment
    'production'

    Initialize and immediately use modules:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> from fbpyutils import string
    >>> uid = string.uuid()
    >>> len(uid)
    36

    Notes
    -----
    * This function must be called before importing or using any fbpyutils modules
    * Environment variables loaded from .env files take precedence over config values
    * Calling setup() multiple times will reinitialize the singleton instances
    * The default configuration file is located at fbpyutils/app.json
    * Configuration values are validated using Pydantic models in the Env class
    * Logging is configured automatically based on the logging section of the config

    See Also
    --------
    get_env : Returns the singleton Env instance after setup
    get_logger : Returns the singleton Logger instance after setup
    fbpyutils.env.Env : Environment configuration class
    fbpyutils.logging.Logger : Logging infrastructure class
    """
    global _env_instance, _logger_instance

    try:
        if isinstance(config, str):
            # Se config é uma string, é um caminho de arquivo
            _init_logger.info(f"Loading configuration from file: {config}")
            _env_instance = Env.load_config_from(config)
            _init_logger.info(f"Configuration loaded successfully from: {config}")
        elif isinstance(config, dict):
            # Se é um dicionário, passa diretamente para o construtor
            _init_logger.info("Loading configuration from provided dictionary")
            _env_instance = Env(config=config)
            _init_logger.info("Configuration loaded successfully from dictionary")
        else:
            # Se for None ou outro tipo, usa o construtor padrão
            config_path = _APP_CONFIG_FILE
            _init_logger.debug(f"Using default configuration file: {config_path}")
            _env_instance = Env()
            _init_logger.info(f"Configuration loaded successfully from default file: {config_path}")

        # Log environment information
        try:
            env_name = _env_instance.APP.environment
            app_name = _env_instance.APP.name
            app_version = _env_instance.APP.version
            _init_logger.info(f"Environment: {env_name}, App: {app_name} v{app_version}")
        except Exception as e:
            _init_logger.warning(f"Could not retrieve environment information: {e}")

        # Configura o logger usando a instância do Env
        _logger_instance = Logger.get_from_env(_env_instance)
        _logger_instance.info("Logger singleton created successfully")
        _logger_instance.info("fbpyutils setup completed successfully")
        
    except FileNotFoundError as e:
        _init_logger.error(f"Configuration file not found: {e}")
        raise
    except json.JSONDecodeError as e:
        _init_logger.error(f"Invalid JSON in configuration file: {e}")
        raise
    except Exception as e:
        _init_logger.error(f"Failed to initialize fbpyutils: {e}")
        raise


def get_env() -> Env:
    """
    Returns the singleton Env instance containing application configuration.

    This function provides access to the global environment configuration singleton
    that was initialized by calling setup(). The Env instance contains application
    metadata, logging configuration, and custom configuration values with environment
    variable precedence handling.

    Returns
    -------
    Env
        The singleton Env instance containing:
        
        - APP: Application configuration (name, version, environment, appcode, year)
        - LOG_LEVEL: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        - LOG_FORMAT: Log format (json or text format string)
        - LOG_FILE: Path to log file
        - LOG_HANDLERS: List of log handlers (file, console, none)
        - USER_APP_FOLDER: User data directory path
        - Custom configuration values from the config section

    Raises
    ------
    RuntimeError
        If fbpyutils.setup() has not been called before accessing the environment.

    Examples
    --------
    Access application configuration:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> env = fbpyutils.get_env()
    >>> env.APP.name
    'FBPyUtils'
    >>> env.APP.version
    '1.9.0'

    Access logging configuration:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> env = fbpyutils.get_env()
    >>> env.LOG_LEVEL
    'CRITICAL'
    >>> env.LOG_FORMAT
    'json'

    Access custom configuration:

    >>> import fbpyutils
    >>> fbpyutils.setup({'config': {'api_key': 'secret'}})
    >>> env = fbpyutils.get_env()
    >>> env.config.api_key
    'secret'

    Access user data folder:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> env = fbpyutils.get_env()
    >>> env.USER_APP_FOLDER
    '/home/user/.fbpyutils'

    Notes
    -----
    * The Env instance is a singleton created once during setup()
    * Environment variables loaded from .env override configuration file values
    * Configuration values are validated using Pydantic models
    * Accessing this function before setup() will raise a RuntimeError
    * The instance is reused across all calls to get_env()

    See Also
    --------
    setup : Initializes the library and creates the Env singleton
    get_logger : Returns the singleton Logger instance
    fbpyutils.env.Env : Environment configuration class with full API documentation
    """
    if _env_instance is None:
        error_msg = "fbpyutils is not initialized. Call fbpyutils.setup() first."
        _init_logger.error(error_msg)
        raise RuntimeError(error_msg)
    return _env_instance


def get_logger() -> Logger:
    """
    Returns the singleton Logger instance for application logging.

    This function provides access to the global logging singleton that was initialized
    by calling setup(). The Logger instance provides thread-safe logging with support
    for file and console handlers, JSON format output, and runtime reconfiguration.

    Returns
    -------
    Logger
        The singleton Logger instance with the following methods:
        
        - debug(message, *args, **kwargs): Log at DEBUG level
        - info(message, *args, **kwargs): Log at INFO level
        - warning(message, *args, **kwargs): Log at WARNING level
        - error(message, *args, **kwargs): Log at ERROR level
        - critical(message, *args, **kwargs): Log at CRITICAL level
        - log(log_type, log_text, *args, **kwargs): Log at custom level
        
        The logger also provides class attributes for log levels:
        - Logger.DEBUG: DEBUG level constant
        - Logger.INFO: INFO level constant
        - Logger.WARNING: WARNING level constant
        - Logger.ERROR: ERROR level constant
        - Logger.CRITICAL: CRITICAL level constant

    Raises
    ------
    RuntimeError
        If fbpyutils.setup() has not been called before accessing the logger.

    Examples
    --------
    Basic logging:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> logger = fbpyutils.get_logger()
    >>> logger.info("Application started")
    >>> logger.warning("Low memory detected")
    >>> logger.error("Failed to process file")

    Logging with parameters:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> logger = fbpyutils.get_logger()
    >>> logger.info("User %s logged in from %s", "alice", "192.168.1.1")
    >>> logger.debug("Processing %d items", 42)

    Using log level constants:

    >>> import fbpyutils
    >>> fbpyutils.setup()
    >>> logger = fbpyutils.get_logger()
    >>> logger.log(logger.WARNING, "Custom warning message")

    JSON structured logging:

    >>> import fbpyutils
    >>> fbpyutils.setup({'log_format': 'json'})
    >>> logger = fbpyutils.get_logger()
    >>> logger.info("Request processed", extra_data={"user_id": 123, "endpoint": "/api/users"})

    Notes
    -----
    * The Logger instance is a singleton created once during setup()
    * Logging configuration is loaded from the logging section of the config
    * File logging uses ConcurrentRotatingFileHandler for thread safety
    * JSON format requires python-json-logger package installation
    * Accessing this function before setup() will raise a RuntimeError
    * The instance is reused across all calls to get_logger()

    See Also
    --------
    setup : Initializes the library and creates the Logger singleton
    get_env : Returns the singleton Env instance
    fbpyutils.logging.Logger : Logging class with full API documentation
    """
    if _logger_instance is None:
        error_msg = "fbpyutils is not initialized. Call fbpyutils.setup() first."
        _init_logger.error(error_msg)
        raise RuntimeError(error_msg)
    return _logger_instance
