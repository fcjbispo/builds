"""
Error Handling Utilities for the FBPyUtils Command-Line Interface

This module provides consistent error handling functionality for the FBPyUtils CLI,
ensuring uniform error message formatting, logging, and user feedback across all
command groups. The error handler integrates with the logging system to provide
comprehensive error tracking and troubleshooting capabilities.

The module provides one primary utility:

* **Error Handling**: The handle_error function formats and displays error messages
  consistently, logs errors with appropriate severity, and ensures proper error
  stream handling for shell integration.

Key Features:
-------------
* **Consistent Formatting**: Uniform error message format across all CLI operations
* **Logging Integration**: Automatic error logging with appropriate severity levels
* **Stream Handling**: Error messages directed to stderr for proper shell integration
* **Custom Messages**: Support for custom error messages with exception details
* **Flexible Input**: Handles any exception type with appropriate formatting
* **User Feedback**: Clear error messages for end-user troubleshooting

Dependencies:
-------------
* `click`: Click library for CLI error output to stderr
* `fbpyutils`: Main library for logging infrastructure
* `typing`: Type hints for function parameters

Usage Examples:
---------------
Handle errors with custom message:

>>> from fbpyutils.cli.utils.error_handler import handle_error
>>> try:
...     # Some operation that may fail
...     raise ValueError("Invalid input")
... except Exception as e:
...     handle_error(e, "Operation failed")
# Logs: "Operation failed: Invalid input"
# Displays: "Error: Operation failed" to stderr

Handle errors without custom message:

>>> from fbpyutils.cli.utils.error_handler import handle_error
>>> try:
...     # Some operation that may fail
...     raise FileNotFoundError("File not found")
... except Exception as e:
...     handle_error(e)
# Logs: "Error occurred: File not found"
# Displays: "Error: File not found" to stderr

Handle errors in command functions:

>>> from fbpyutils.cli.utils.error_handler import handle_error
>>> def my_command():
...     try:
...         # Command logic
...         pass
...     except Exception as e:
...         handle_error(e, "Command execution failed")
...         raise typer.Exit(code=1)

Notes:
------
* Error messages are always logged with ERROR severity level
* Error messages are displayed to stderr for proper error stream handling
* Custom messages are prepended to the exception message for context
* The function does not raise exceptions; it only logs and displays errors
* This utility is used across all command groups for consistency
* The function integrates with the fbpyutils logging system

Error Handling:
---------------
* All exceptions are logged with full error details
* Error messages are formatted consistently for user readability
* Custom messages provide additional context for troubleshooting
* The function handles None values for custom messages gracefully

Cross-References:
-----------------
* See `fbpyutils.logging` for logging infrastructure details
* See `fbpyutils.cli.main` for main CLI error handling
* See `click.echo` for Click's error output functionality
* See `typer.Exit` for CLI exit mechanisms
"""

import click
import fbpyutils
from typing import Optional

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


def handle_error(error: Exception, message: Optional[str] = None) -> None:
    """
    Handle errors in a consistent way across the CLI.

    This function provides uniform error message formatting and logging for all
    CLI operations. It logs the error with appropriate severity and displays
    a user-friendly error message to stderr for proper shell integration.

    Parameters
    ----------
    error : Exception
        The exception that occurred during CLI operation. Can be any exception
        type including ValueError, FileNotFoundError, RuntimeError, etc.

    message : Optional[str], default=None
        Optional custom message to provide additional context for the error.
        If provided, it will be prepended to the exception message in both
        the log entry and the displayed error message.

    Returns
    -------
    None
        This function does not return a value. It logs the error and displays
        a message to stderr.

    Raises
    ------
    None
        This function does not raise exceptions. It handles errors by logging
        and displaying messages.

    Examples
    --------
    Handle error with custom message:

    >>> from fbpyutils.cli.utils.error_handler import handle_error
    >>> try:
    ...     raise ValueError("Invalid input value")
    ... except Exception as e:
    ...     handle_error(e, "Operation failed")
    # Logs: "Operation failed: Invalid input value"
    # Displays: "Error: Operation failed" to stderr

    Handle error without custom message:

    >>> from fbpyutils.cli.utils.error_handler import handle_error
    >>> try:
    ...     raise FileNotFoundError("config.json not found")
    ... except Exception as e:
    ...     handle_error(e)
    # Logs: "Error occurred: config.json not found"
    # Displays: "Error: config.json not found" to stderr

    Handle error in command function:

    >>> import typer
    >>> from fbpyutils.cli.utils.error_handler import handle_error
    >>> def my_command():
    ...     try:
    ...         # Command logic here
    ...         pass
    ...     except Exception as e:
    ...         handle_error(e, "Command execution failed")
    ...         raise typer.Exit(code=1)

    Notes
    -----
    * Error messages are always logged with ERROR severity level
    * Error messages are displayed to stderr using click.echo with err=True
    * Custom messages provide additional context for troubleshooting
    * The function does not re-raise exceptions; it only logs and displays
    * This utility should be used consistently across all command groups
    * The function integrates with the fbpyutils logging system

    See Also
    --------
    fbpyutils.logging.Logger : Logging infrastructure for error tracking
    click.echo : Click's output function for stderr handling
    typer.Exit : Typer's exit mechanism for CLI applications
    """
    if message:
        logger.error(f"{message}: {str(error)}")
        click.echo(f"Error: {message}", err=True)
    else:
        logger.error(f"Error occurred: {str(error)}")
        click.echo(f"Error: {str(error)}", err=True)
