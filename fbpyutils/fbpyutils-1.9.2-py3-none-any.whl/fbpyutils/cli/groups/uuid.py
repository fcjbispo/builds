"""
UUID and Snowflake ID Generation Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for UUID generation and
Snowflake ID creation. The UUID commands allow users to generate standard UUID4
strings, create MD5 hashes from strings and JSON data, generate Snowflake IDs
using modern and classic algorithms, and decode Snowflake IDs into their
components with flexible output formatting.

The module provides six primary commands:

* **uuid4**: Generate a standard UUID4 string
* **hash-string**: Generate MD5 hash from a string
* **hash-json**: Generate MD5 hash from a JSON dictionary
* **snowflake**: Generate a Snowflake ID using the new implementation
* **snowflake-classic**: Generate a Snowflake ID using the classic Twitter algorithm (deprecated)
* **snowflake-decode**: Decode a Snowflake ID into its components

Key Features:
-------------
* **UUID Generation**: Generate standard UUID4 strings for unique identifiers
* **String Hashing**: Create MD5 hashes from string data
* **JSON Hashing**: Create MD5 hashes from JSON dictionaries or files
* **Snowflake IDs**: Generate distributed unique IDs using modern algorithm
* **Classic Snowflake**: Generate Snowflake IDs using Twitter's algorithm (deprecated)
* **ID Decoding**: Decode Snowflake IDs into timestamp, datacenter, worker, and sequence
* **Flexible Input**: Support for JSON strings and file paths
* **Flexible Output**: Support for txt, json, and csv output formats
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for UUID functionality
* `fbpyutils.uuid`: UUID and Snowflake ID functions
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities
* `json`: Standard library JSON encoding and decoding

Usage Examples:
---------------
Generate UUID4:

>>> fbpyutils uuid uuid4
# Outputs a UUID4 string

Generate MD5 hash from string:

>>> fbpyutils uuid hash-string --input "hello world"
# Outputs MD5 hash

Generate MD5 hash from JSON string:

>>> fbpyutils uuid hash-json --input '{"key": "value"}'
# Outputs MD5 hash

Generate MD5 hash from JSON file:

>>> fbpyutils uuid hash-json --input ./data.json
# Outputs MD5 hash

Generate Snowflake ID:

>>> fbpyutils uuid snowflake --datacenter-id 1 --worker-id 2
# Outputs Snowflake ID

Generate classic Snowflake ID:

>>> fbpyutils uuid snowflake-classic --machine-id 123
# Outputs classic Snowflake ID

Decode Snowflake ID:

>>> fbpyutils uuid snowflake-decode 1234567890123456789
# Outputs decoded components

Command Help:
-------------
Display help for UUID commands:

>>> fbpyutils uuid --help
# Shows all available UUID commands

Display help for uuid4 command:

>>> fbpyutils uuid uuid4 --help
# Shows detailed help for the uuid4 command

Notes:
------
* UUID4 generates random UUIDs suitable for most use cases
* MD5 is not cryptographically secure, use for non-security purposes
* Snowflake IDs are distributed unique IDs with timestamp ordering
* Classic Snowflake algorithm is deprecated, use the new implementation
* Snowflake decoding extracts timestamp, datacenter, worker, and sequence
* JSON input can be a JSON string or a file path
* Datacenter ID range is 0-31 (5 bits)
* Worker ID range is 0-31 (5 bits)
* Machine ID range is 0-1023 (10 bits)
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid parameters: Error message if parameters are invalid
* Invalid JSON: Error message if JSON is malformed or file not found
* Invalid Snowflake ID: Error message if ID cannot be decoded
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.uuid` for UUID functionality implementation
* See `fbpyutils.uuid.uuid` for UUID generation function
* See `fbpyutils.uuid.hash_string` for string hashing function
* See `fbpyutils.uuid.hash_json` for JSON hashing function
* See `fbpyutils.uuid.snowflake_id` for Snowflake ID generation function
* See `fbpyutils.uuid.SnowflakeIDGenerator` for classic Snowflake generator
* See `fbpyutils.uuid.Snowflake` for Snowflake decoding class
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for uuid commands
app = typer.Typer(
    name="uuid",
    help="Commands for UUID generation and Snowflake ID creation.",
    rich_markup_mode="rich",
)


@app.command("uuid4")
def uuid4_cmd(
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate a standard UUID4 string.

    This command generates a random UUID4 (Universally Unique Identifier) string,
    which is suitable for most use cases requiring unique identifiers. UUID4
    generates random UUIDs with a very low probability of collision.

    Parameters
    ----------
    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the UUID4 string to
        stdout.

    Raises
    ------
    ValueError
        If UUID generation fails.

    Examples
    --------
    Generate UUID4:

    >>> fbpyutils uuid uuid4
    # Outputs a UUID4 string (e.g., "550e8400-e29b-41d4-a716-446655440000")

    Generate UUID4 in JSON format:

    >>> fbpyutils uuid uuid4 --output-format json
    # Outputs UUID4 in JSON format

    Notes
    -----
    * UUID4 generates random UUIDs suitable for most use cases
    * The probability of collision is extremely low
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.uuid : UUID generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Generating UUID4 string")

        from fbpyutils.uuid import uuid

        result = uuid()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("UUID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate UUID")


@app.command("hash-string")
def hash_string_cmd(
    input: str = typer.Option(..., "--input", help="String to hash."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate MD5 hash from a string.

    This command generates an MD5 hash of the input string. The hash is a
    32-character hexadecimal string that uniquely represents the input data.
    Note: MD5 is not cryptographically secure and should not be used for
    security-sensitive applications.

    Parameters
    ----------
    input : str
        The string to hash. This is a required parameter.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the MD5 hash to stdout.

    Raises
    ------
    ValueError
        If hash generation fails.

    Examples
    --------
    Generate MD5 hash:

    >>> fbpyutils uuid hash-string --input "hello world"
    # Outputs MD5 hash (e.g., "5eb63bbbe01eeed093cb22bb8f5acdc3")

    Generate MD5 hash in JSON format:

    >>> fbpyutils uuid hash-string --input "hello world" --output-format json
    # Outputs MD5 hash in JSON format

    Notes
    -----
    * MD5 is not cryptographically secure, use for non-security purposes
    * The hash is a 32-character hexadecimal string
    * The same input always produces the same hash
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.hash_string : Hash generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Generating MD5 hash from string")

        from fbpyutils.uuid import hash_string

        result = hash_string(input)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate hash")


@app.command("hash-json")
def hash_json_cmd(
    input: str = typer.Option(..., "--input", help="JSON string or path to JSON file."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate MD5 hash from a JSON dictionary.

    This command generates an MD5 hash of JSON data. The input can be either a
    JSON string or a path to a JSON file. The hash is a 32-character hexadecimal
    string that uniquely represents the JSON data. Note: MD5 is not
    cryptographically secure and should not be used for security-sensitive
    applications.

    Parameters
    ----------
    input : str
        The JSON string or path to a JSON file to hash. This is a required
        parameter. If the input is not valid JSON, it will be treated as a file
        path.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the MD5 hash to stdout.

    Raises
    ------
    ValueError
        If the input is not valid JSON or the file cannot be read.

    Examples
    --------
    Generate MD5 hash from JSON string:

    >>> fbpyutils uuid hash-json --input '{"key": "value"}'
    # Outputs MD5 hash

    Generate MD5 hash from JSON file:

    >>> fbpyutils uuid hash-json --input ./data.json
    # Outputs MD5 hash

    Generate MD5 hash in JSON format:

    >>> fbpyutils uuid hash-json --input '{"key": "value"}' --output-format json
    # Outputs MD5 hash in JSON format

    Notes
    -----
    * MD5 is not cryptographically secure, use for non-security purposes
    * The hash is a 32-character hexadecimal string
    * Input can be a JSON string or a file path
    * The same JSON data always produces the same hash
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.hash_json : JSON hashing function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info("Generating MD5 hash from JSON")

        import json
        from fbpyutils.uuid import hash_json

        # Try to parse as JSON, if it fails, try reading as file
        try:
            data = json.loads(input)
        except json.JSONDecodeError:
            # Try reading as file path
            try:
                with open(input, "r") as f:
                    data = json.load(f)
            except FileNotFoundError:
                raise ValueError(f"Input is not valid JSON or file path: {input}")

        result = hash_json(data)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("JSON hash generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate JSON hash")


@app.command("snowflake")
def snowflake_cmd(
    datacenter_id: int = typer.Option(
        0, "--datacenter-id", help="Datacenter ID (0-31)."
    ),
    worker_id: int = typer.Option(0, "--worker-id", help="Worker ID (0-31)."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate a Snowflake ID using the new implementation.

    This command generates a Snowflake ID using the modern implementation.
    Snowflake IDs are distributed unique identifiers that include a timestamp,
    datacenter ID, worker ID, and sequence number. They are sortable by time
    and suitable for use in distributed systems.

    Parameters
    ----------
    datacenter_id : int, default=0
        The datacenter ID for the Snowflake ID. Range is 0-31 (5 bits).

    worker_id : int, default=0
        The worker ID for the Snowflake ID. Range is 0-31 (5 bits).

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the Snowflake ID to
        stdout.

    Raises
    ------
    ValueError
        If datacenter_id or worker_id are out of range.

    Examples
    --------
    Generate Snowflake ID:

    >>> fbpyutils uuid snowflake --datacenter-id 1 --worker-id 2
    # Outputs Snowflake ID

    Generate Snowflake ID with default values:

    >>> fbpyutils uuid snowflake
    # Outputs Snowflake ID with datacenter_id=0, worker_id=0

    Generate Snowflake ID in JSON format:

    >>> fbpyutils uuid snowflake --datacenter-id 1 --worker-id 2 --output-format json
    # Outputs Snowflake ID in JSON format

    Notes
    -----
    * Snowflake IDs are distributed unique IDs with timestamp ordering
    * Datacenter ID range is 0-31 (5 bits)
    * Worker ID range is 0-31 (5 bits)
    * IDs are sortable by generation time
    * Suitable for use in distributed systems
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.snowflake_id : Snowflake ID generation function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"Generating Snowflake ID (datacenter_id: {datacenter_id}, worker_id: {worker_id})"
        )

        from fbpyutils.uuid import snowflake_id

        result = snowflake_id(datacenter_id=datacenter_id, worker_id=worker_id)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate Snowflake ID")


@app.command("snowflake-classic")
def snowflake_classic_cmd(
    machine_id: int = typer.Option(1, "--machine-id", help="Machine ID (0-1023)."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Generate a Snowflake ID using the classic Twitter algorithm (deprecated).

    This command generates a Snowflake ID using the classic Twitter algorithm.
    This implementation is deprecated and should be replaced with the new
    snowflake command. The classic algorithm uses a machine ID instead of
    separate datacenter and worker IDs.

    Parameters
    ----------
    machine_id : int, default=1
        The machine ID for the Snowflake ID. Range is 0-1023 (10 bits).

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the Snowflake ID to
        stdout.

    Raises
    ------
    ValueError
        If machine_id is out of range.

    Examples
    --------
    Generate classic Snowflake ID:

    >>> fbpyutils uuid snowflake-classic --machine-id 123
    # Outputs classic Snowflake ID

    Generate classic Snowflake ID with default value:

    >>> fbpyutils uuid snowflake-classic
    # Outputs classic Snowflake ID with machine_id=1

    Generate classic Snowflake ID in JSON format:

    >>> fbpyutils uuid snowflake-classic --machine-id 123 --output-format json
    # Outputs classic Snowflake ID in JSON format

    Notes
    -----
    * Classic Snowflake algorithm is deprecated, use the new implementation
    * Machine ID range is 0-1023 (10 bits)
    * IDs are sortable by generation time
    * Suitable for use in distributed systems
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.SnowflakeIDGenerator : Classic Snowflake generator class
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Generating classic Snowflake ID (machine_id: {machine_id})")

        from fbpyutils.uuid import SnowflakeIDGenerator

        generator = SnowflakeIDGenerator(machine_id=machine_id)
        result = generator.generate()

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Classic Snowflake ID generated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate classic Snowflake ID")


@app.command("snowflake-decode")
def snowflake_decode_cmd(
    snowflake_id: int = typer.Argument(..., help="Snowflake ID to decode."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Decode a Snowflake ID into its components.

    This command decodes a Snowflake ID into its constituent parts: timestamp,
    datacenter ID, worker ID, and sequence number. This is useful for debugging
    and understanding when and where a Snowflake ID was generated.

    Parameters
    ----------
    snowflake_id : int
        The Snowflake ID to decode. This is a required parameter and must be a
        valid Snowflake ID.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the decoded components
        to stdout.

    Raises
    ------
    ValueError
        If the Snowflake ID is invalid or cannot be decoded.

    Examples
    --------
    Decode Snowflake ID:

    >>> fbpyutils uuid snowflake-decode 1234567890123456789
    # Outputs decoded components

    Decode Snowflake ID in JSON format:

    >>> fbpyutils uuid snowflake-decode 1234567890123456789 --output-format json
    # Outputs decoded components in JSON format

    Notes
    -----
    * Snowflake decoding extracts timestamp, datacenter, worker, and sequence
    * The timestamp is in milliseconds since the epoch
    * Datacenter ID range is 0-31 (5 bits)
    * Worker ID range is 0-31 (5 bits)
    * Sequence number range is 0-4095 (12 bits)
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.uuid.Snowflake : Snowflake decoding class
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Decoding Snowflake ID: {snowflake_id}")

        from fbpyutils.uuid import Snowflake

        snowflake = Snowflake()
        result = snowflake.get_id_components(snowflake_id)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug("Snowflake ID decoded successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to decode Snowflake ID")
