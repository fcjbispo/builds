"""
File Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for file system operations
and management. The file commands allow users to find files, read file contents,
determine MIME types, describe file properties, and convert files to base64
encoding with flexible output formatting.

The module provides five primary commands:

* **find**: Find files in a source folder using specific masks with optional
  recursive and parallel search capabilities.

* **read-bytes**: Read a file and return its contents as raw bytes.

* **mime-type**: Guess the MIME type of a file based on its content or extension.

* **describe**: Describe a file, returning its properties such as size, type,
  and modification time.

* **to-base64**: Retrieve data from a URI and return as base64 encoded string.

Key Features:
-------------
* **File Search**: Find files with pattern matching and recursive search
* **Parallel Processing**: Optional parallel search for improved performance
* **Binary Reading**: Read file contents as raw bytes
* **MIME Detection**: Automatic MIME type detection for files
* **File Description**: Comprehensive file property reporting
* **Base64 Encoding**: Convert files or URIs to base64 format
* **Flexible Output**: Support for txt, json, and csv output formats
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for file functionality
* `fbpyutils.cli.utils.output_formatter`: Output formatting utilities
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Find files with pattern matching:

>>> fbpyutils file find --path ./src --mask "*.py"
# Outputs all Python files in ./src directory

Find files recursively:

>>> fbpyutils file find --path ./src --mask "*.py" --recurse
# Outputs all Python files in ./src directory and subdirectories

Find files with parallel search:

>>> fbpyutils file find --path ./src --mask "*.py" --recurse --parallel
# Outputs all Python files using parallel search

Read file as bytes:

>>> fbpyutils file read-bytes --path ./data.bin
# Outputs file contents as raw bytes

Get MIME type of a file:

>>> fbpyutils file mime-type --path ./image.jpg
# Outputs: image/jpeg

Describe file properties:

>>> fbpyutils file describe --path ./document.pdf
# Outputs file properties in JSON format

Convert file to base64:

>>> fbpyutils file to-base64 --uri file:///path/to/file.pdf
# Outputs base64 encoded content

Command Help:
-------------
Display help for file commands:

>>> fbpyutils file --help
# Shows all available file commands

Display help for find command:

>>> fbpyutils file find --help
# Shows detailed help for the find command

Notes:
------
* File masks support glob patterns (e.g., "*.py", "test_*.py")
* Recursive search can be combined with parallel processing for performance
* Binary output is not formatted and is output directly to stdout
* MIME type detection uses file content and extension
* File description includes size, type, and modification time
* Base64 encoding supports both file URIs and HTTP/HTTPS URLs
* Output format is case-insensitive (txt, json, csv)
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid path: Error message if path does not exist
* Invalid mask: Error message if mask pattern is invalid
* File not found: Error message if file cannot be accessed
* Invalid URI: Error message if URI is malformed or unreachable
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.file` for file functionality implementation
* See `fbpyutils.file.find` for file search function
* See `fbpyutils.file.contents` for file reading function
* See `fbpyutils.file.mime_type` for MIME type detection function
* See `fbpyutils.file.describe_file` for file description function
* See `fbpyutils.file.get_base64_data_from` for base64 encoding function
* See `fbpyutils.cli.utils.output_formatter` for output formatting details
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for file commands
app = typer.Typer(
    name="file", help="Commands for file manipulation.", rich_markup_mode="rich"
)


@app.command("find")
def find_files(
    path: str = typer.Option(..., "--path", help="Source folder to find files from."),
    mask: str = typer.Argument(..., help="File mask(s) to search for."),
    recurse: bool = typer.Option(
        False, "--recurse", help="Search recursively in subdirectories."
    ),
    parallel: bool = typer.Option(
        False, "--parallel", help="Use parallel search if recurse is enabled."
    ),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Find files in a source folder using a specific mask.

    This command searches for files matching the specified mask pattern in the
    given directory. The search can be recursive and optionally use parallel
    processing for improved performance on large directory trees.

    Parameters
    ----------
    path : str
        The source folder to search for files. This is a required parameter and
        must be a valid directory path.

    mask : str
        The file mask pattern to search for. Supports glob patterns such as
        "*.py", "test_*.py", or "*.*". This is a required parameter.

    recurse : bool, default=False
        If True, searches recursively in all subdirectories. If False, only
        searches the specified directory.

    parallel : bool, default=False
        If True and recurse is enabled, uses parallel search for improved
        performance. Only effective when recurse is True.

    output_format : str, default="txt"
        The output format for the results. Supported formats:
        * "txt" - Human-readable text format (one file per line)
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the matching file
        paths to stdout.

    Raises
    ------
    ValueError
        If the path does not exist or is not a directory.

    Examples
    --------
    Find Python files in current directory:

    >>> fbpyutils file find --path ./src --mask "*.py"
    # Outputs all Python files in ./src directory

    Find files recursively:

    >>> fbpyutils file find --path ./src --mask "*.py" --recurse
    # Outputs all Python files in ./src directory and subdirectories

    Find files with parallel search:

    >>> fbpyutils file find --path ./src --mask "*.py" --recurse --parallel
    # Outputs all Python files using parallel search

    Find multiple file types:

    >>> fbpyutils file find --path ./src --mask "*.{py,txt,md}" --recurse
    # Outputs all Python, text, and Markdown files

    Notes
    -----
    * File masks support glob patterns (e.g., "*.py", "test_*.py")
    * Recursive search can be combined with parallel processing for performance
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.file.find : File search function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        if not mask:
            mask = ["*.*"]
        logger.info(f"Finding files in {path} with mask {mask}")

        from fbpyutils.file import find

        result = find(path, mask, recurse, parallel)

        if output_format == "txt":
            for file_path in result:
                typer.echo(file_path)
        else:
            formatted_result = format_output(result, output_format)
            typer.echo(formatted_result)

        logger.debug(f"Found {len(result)} files")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to find files")


@app.command("read-bytes")
def read_bytes(
    path: str = typer.Option(..., "--path", help="Path of the file to read."),
):
    """
    Read a file and return its contents as bytes.

    This command reads the specified file and outputs its contents as raw bytes
    to stdout. This is useful for binary files or when you need the exact byte
    content of a file.

    Parameters
    ----------
    path : str
        The path of the file to read. This is a required parameter and must be
        a valid file path.

    Returns
    -------
    None
        This function does not return a value. It outputs the file contents as
        raw bytes to stdout.

    Raises
    ------
    ValueError
        If the file does not exist or cannot be read.

    Examples
    --------
    Read binary file:

    >>> fbpyutils file read-bytes --path ./data.bin
    # Outputs file contents as raw bytes

    Read image file:

    >>> fbpyutils file read-bytes --path ./image.jpg > output.jpg
    # Outputs file contents and redirects to output file

    Notes
    -----
    * Binary output is not formatted and is output directly to stdout
    * The output does not include a newline at the end (nl=False)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging
    * Use output redirection to save binary data to a file

    See Also
    --------
    fbpyutils.file.contents : File reading function
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Reading bytes from {path}")

        from fbpyutils.file import contents

        result = contents(path)

        # Output as binary data
        typer.echo(result, nl=False)

        logger.debug(f"Read {len(result)} bytes from {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to read file bytes")


@app.command("mime-type")
def get_mime_type(
    path: str = typer.Option(..., "--path", help="Path of the file to get MIME type."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Guess the MIME type of a file.

    This command determines the MIME type of a file based on its content and
    extension. The MIME type is useful for identifying the type of file and
    determining how to handle it.

    Parameters
    ----------
    path : str
        The path of the file to analyze. This is a required parameter and must
        be a valid file path.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the MIME type to stdout.

    Raises
    ------
    ValueError
        If the file does not exist or cannot be read.

    Examples
    --------
    Get MIME type of image file:

    >>> fbpyutils file mime-type --path ./image.jpg
    # Outputs: image/jpeg

    Get MIME type of PDF file:

    >>> fbpyutils file mime-type --path ./document.pdf
    # Outputs: application/pdf

    Get MIME type in JSON format:

    >>> fbpyutils file mime-type --path ./image.jpg --output-format json
    # Outputs: {"mime_type": "image/jpeg"}

    Notes
    -----
    * MIME type detection uses file content and extension
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.file.mime_type : MIME type detection function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Getting MIME type for {path}")

        from fbpyutils.file import mime_type

        result = mime_type(path)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"MIME type for {path}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get MIME type")


@app.command("describe")
def describe_file(
    path: str = typer.Option(..., "--path", help="Path of the file to describe."),
    output_format: str = typer.Option(
        "txt", "--output-format", help="Output format.", case_sensitive=False
    ),
):
    """
    Describe a file, returning its properties.

    This command provides comprehensive information about a file including its
    size, type, modification time, and other properties. The information is
    useful for file management and debugging.

    Parameters
    ----------
    path : str
        The path of the file to describe. This is a required parameter and must
        be a valid file path.

    output_format : str, default="txt"
        The output format for the result. Supported formats:
        * "txt" - Human-readable text format
        * "json" - Structured JSON format
        * "csv" - Comma-separated values format
        The format is case-insensitive.

    Returns
    -------
    None
        This function does not return a value. It outputs the file properties
        to stdout.

    Raises
    ------
    ValueError
        If the file does not exist or cannot be accessed.

    Examples
    --------
    Describe file properties:

    >>> fbpyutils file describe --path ./document.pdf
    # Outputs file properties in text format

    Describe file in JSON format:

    >>> fbpyutils file describe --path ./document.pdf --output-format json
    # Outputs file properties in JSON format

    Notes
    -----
    * File description includes size, type, and modification time
    * Output format is case-insensitive (txt, json, csv)
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.file.describe_file : File description function
    format_output : Output formatting utility
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Describing file {path}")

        from fbpyutils.file import describe_file

        result = describe_file(path)

        formatted_result = format_output(result, output_format)
        typer.echo(formatted_result)

        logger.debug(f"Described file {path}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to describe file")


@app.command("to-base64")
def to_base64(
    uri: str = typer.Option(..., "--uri", help="URI of the file to process."),
    timeout: int = typer.Option(300, "--timeout", help="Timeout for URL requests."),
):
    """
    Retrieve data from a URI and return as base64 string.

    This command retrieves data from a URI (file://, http://, or https://) and
    converts it to a base64 encoded string. This is useful for embedding files
    in data URIs or transmitting binary data as text.

    Parameters
    ----------
    uri : str
        The URI of the file to process. Supports file://, http://, and https://
        schemes. This is a required parameter.

    timeout : int, default=300
        The timeout in seconds for URL requests. Only applies to http:// and
        https:// URIs. Default is 300 seconds (5 minutes).

    Returns
    -------
    None
        This function does not return a value. It outputs the base64 encoded
        data to stdout.

    Raises
    ------
    ValueError
        If the URI is malformed or the resource cannot be accessed.

    Examples
    --------
    Convert local file to base64:

    >>> fbpyutils file to-base64 --uri file:///path/to/file.pdf
    # Outputs base64 encoded content

    Convert remote file to base64:

    >>> fbpyutils file to-base64 --uri https://example.com/file.pdf
    # Outputs base64 encoded content

    Convert with custom timeout:

    >>> fbpyutils file to-base64 --uri https://example.com/large-file.pdf --timeout 600
    # Outputs base64 encoded content with 10 minute timeout

    Notes
    -----
    * Base64 encoding supports both file URIs and HTTP/HTTPS URLs
    * Timeout only applies to HTTP/HTTPS requests
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging
    * Large files may take significant time to encode

    See Also
    --------
    fbpyutils.file.get_base64_data_from : Base64 encoding function
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Converting {uri} to base64")

        from fbpyutils.file import get_base64_data_from

        result = get_base64_data_from(uri, timeout)

        typer.echo(result)

        logger.debug(f"Converted {uri} to base64")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to convert to base64")
