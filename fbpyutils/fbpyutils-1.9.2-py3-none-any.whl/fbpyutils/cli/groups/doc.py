"""
Documentation Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for documentation generation
and management. The doc commands allow users to generate Markdown documentation
for Python modules, with options for excluding initialization files and specifying
custom source directories.

The module provides one primary command:

* **generate-all**: Generate Markdown documentation for all Python modules in a
  directory with flexible configuration options.

Key Features:
-------------
* **Batch Documentation**: Generate documentation for all modules in a directory
* **Markdown Output**: Produces human-readable Markdown documentation
* **Selective Exclusion**: Option to exclude __init__.py files from generation
* **Custom Source**: Support for custom source directory specification
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for documentation functionality
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Generate documentation for all modules:

>>> fbpyutils doc generate-all --output-dir ./docs
# Generates documentation for all modules in the current directory

Generate documentation including __init__.py files:

>>> fbpyutils doc generate-all --output-dir ./docs --exclude-init false
# Generates documentation including __init__.py files

Generate documentation from custom source directory:

>>> fbpyutils doc generate-all --output-dir ./docs --source-dir ./src
# Generates documentation from the ./src directory

Command Help:
-------------
Display help for doc commands:

>>> fbpyutils doc --help
# Shows all available doc commands

Display help for generate-all command:

>>> fbpyutils doc generate-all --help
# Shows detailed help for the generate-all command

Notes:
------
* Output directory will be created if it does not exist
* By default, __init__.py files are excluded from documentation generation
* Source directory defaults to the current working directory if not specified
* The command integrates with the fbpyutils logging system
* All errors are logged with full exception details for debugging
* Generated documentation is in Markdown format for easy reading

Error Handling:
---------------
* Invalid output directory: Error message if directory cannot be created
* Invalid source directory: Error message if source directory does not exist
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.doc` for documentation functionality implementation
* See `fbpyutils.doc.generate_module_docs` for documentation generation function
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for doc commands
app = typer.Typer(
    name="doc", help="Commands for documentation generation.", rich_markup_mode="rich"
)


@app.command("generate-all")
def generate_all_cmd(
    output_dir: str = typer.Option(
        ..., "--output-dir", help="Output directory for generated documentation."
    ),
    exclude_init: bool = typer.Option(
        True, "--exclude-init", help="Exclude __init__.py files."
    ),
    source_dir: str = typer.Option(
        None,
        "--source-dir",
        help="Source directory for generated documentation. Defaults to app root directory.",
    ),
):
    """
    Generate Markdown documentation for all Python modules in a directory.

    This command generates comprehensive Markdown documentation for all Python
    modules found in the specified source directory. The documentation includes
    module-level docstrings, function signatures, and class definitions.

    Parameters
    ----------
    output_dir : str
        The output directory where generated documentation will be saved. This is
        a required parameter. The directory will be created if it does not exist.

    exclude_init : bool, default=True
        If True, __init__.py files are excluded from documentation generation.
        If False, __init__.py files are included in the documentation.

    source_dir : Optional[str], default=None
        The source directory containing Python modules to document. If not
        specified, defaults to the current working directory.

    Returns
    -------
    None
        This function does not return a value. It generates documentation files
        in the specified output directory.

    Raises
    ------
    ValueError
        If the output directory cannot be created or if the source directory
        does not exist.

    Examples
    --------
    Generate documentation for all modules:

    >>> fbpyutils doc generate-all --output-dir ./docs
    # Generates documentation for all modules in the current directory

    Generate documentation including __init__.py files:

    >>> fbpyutils doc generate-all --output-dir ./docs --exclude-init false
    # Generates documentation including __init__.py files

    Generate documentation from custom source directory:

    >>> fbpyutils doc generate-all --output-dir ./docs --source-dir ./src
    # Generates documentation from the ./src directory

    Notes
    -----
    * Output directory will be created if it does not exist
    * By default, __init__.py files are excluded from documentation generation
    * Source directory defaults to the current working directory if not specified
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging
    * Generated documentation is in Markdown format for easy reading

    See Also
    --------
    fbpyutils.doc.generate_module_docs : Documentation generation function
    handle_error : Error handling utility
    """
    try:
        logger.info(f"Generating documentation to {output_dir}")

        # Import the generate_module_docs function
        from fbpyutils.doc import generate_module_docs

        # Generate documentation
        generate_module_docs(output_dir, exclude_init, source_dir=source_dir)

        typer.echo(f"Documentation generated successfully in {output_dir}")

        logger.debug("Documentation generation completed")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate documentation")
