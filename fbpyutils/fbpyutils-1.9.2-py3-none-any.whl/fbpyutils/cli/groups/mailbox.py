"""
Mailbox Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for MBOX file analysis and
processing. The mailbox commands allow users to extract metadata, retrieve message
details, list message summaries, search messages, and generate mailbox summaries
with flexible output formatting and configuration options.

The module provides five primary commands:

* **metadata**: Extract metadata from all messages in MBOX file
* **message**: Get details of a specific message by identifier
* **list**: List message summaries with optional limit
* **search**: Search messages by term in specified fields
* **summary**: Generate comprehensive mailbox summary

Key Features:
-------------
* **Metadata Extraction**: Extract comprehensive metadata from all messages
* **Message Retrieval**: Get detailed information about specific messages
* **Message Listing**: List message summaries with optional limit
* **Message Search**: Search messages by term in multiple fields
* **Mailbox Summary**: Generate comprehensive mailbox statistics
* **Flexible Output**: Support for JSON and text output formats
* **File Output**: Optional output to file for saving results
* **Search Types**: Multiple search types for message identification
* **Field Selection**: Configurable search fields for targeted searches
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `typing`: Type hints for function parameters
* `fbpyutils`: Main library for mailbox functionality
* `fbpyutils.mailbox.MboxReader`: MBOX file reader class
* `fbpyutils.cli.utils.error_handler`: Error handling utilities

Usage Examples:
---------------
Extract metadata from MBOX file:

>>> fbpyutils mailbox metadata ./emails.mbox
# Outputs metadata in JSON format

Extract metadata and save to file:

>>> fbpyutils mailbox metadata ./emails.mbox --output metadata.json
# Saves metadata to metadata.json

Get message details by ID:

>>> fbpyutils mailbox message ./emails.mbox <message-id>
# Outputs message details

List message summaries:

>>> fbpyutils mailbox list ./emails.mbox
# Lists all message summaries

List limited number of messages:

>>> fbpyutils mailbox list ./emails.mbox 10
# Lists first 10 message summaries

Search messages by term:

>>> fbpyutils mailbox search ./emails.mbox "important"
# Searches for "important" in subject, from, and to fields

Search in specific fields:

>>> fbpyutils mailbox search ./emails.mbox "john@example.com" --search-fields from
# Searches for email address in from field only

Generate mailbox summary:

>>> fbpyutils mailbox summary ./emails.mbox
# Outputs mailbox summary in JSON format

Command Help:
-------------
Display help for mailbox commands:

>>> fbpyutils mailbox --help
# Shows all available mailbox commands

Display help for metadata command:

>>> fbpyutils mailbox metadata --help
# Shows detailed help for the metadata command

Notes:
------
* MBOX files are standard email storage format used by many email clients
* Message identifiers can be Message-ID, index, or other identifiers
* Search type determines how messages are identified (auto, index, message-id)
* Search fields are comma-separated (e.g., "subject,from,to")
* Output format is case-insensitive (json, txt)
* Output file is created with UTF-8 encoding
* The commands integrate with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid MBOX file: Error message if file is not a valid MBOX format
* Message not found: Error message if message identifier is not found
* Invalid search type: Error message if search type is not supported
* Invalid search fields: Error message if search fields are invalid
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.mailbox` for mailbox functionality implementation
* See `fbpyutils.mailbox.MboxReader` for MBOX file reader class
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
from typing import Optional
import fbpyutils
from fbpyutils.cli.utils.error_handler import handle_error
from fbpyutils.mailbox import MboxReader

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for mailbox commands
app = typer.Typer(
    name="mailbox", help="MBOX file analysis commands.", rich_markup_mode="rich"
)


@app.command()
def metadata(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format (default: json)",
        case_sensitive=False,
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
):
    """
    Extract metadata from all messages in MBOX file.

    This command extracts comprehensive metadata from all messages in the
    specified MBOX file, including message IDs, subjects, senders, recipients,
    dates, and other header information.

    Parameters
    ----------
    mbox_file : str
        The path to the MBOX file to analyze. This is a required parameter and
        must be a valid MBOX file path.

    format : str, default="json"
        The output format for the metadata. Supported formats:
        * "json" - Structured JSON format
        * "txt" - Human-readable text format
        The format is case-insensitive.

    output : Optional[str], default=None
        The output file path to save the metadata. If not specified, the
        metadata is output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the metadata to
        stdout or saves it to the specified output file.

    Raises
    ------
    ValueError
        If the MBOX file is invalid or cannot be read.

    Examples
    --------
    Extract metadata from MBOX file:

    >>> fbpyutils mailbox metadata ./emails.mbox
    # Outputs metadata in JSON format

    Extract metadata and save to file:

    >>> fbpyutils mailbox metadata ./emails.mbox --output metadata.json
    # Saves metadata to metadata.json

    Extract metadata in text format:

    >>> fbpyutils mailbox metadata ./emails.mbox --format txt
    # Outputs metadata in text format

    Notes
    -----
    * MBOX files are standard email storage format used by many email clients
    * Output format is case-insensitive (json, txt)
    * Output file is created with UTF-8 encoding
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.mailbox.MboxReader.get_all_metadata : Metadata extraction function
    handle_error : Error handling utility
    """
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_all_metadata(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Metadata saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error extracting metadata: {e}")
        handle_error(e, "Failed to extract metadata")


@app.command()
def message(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    identifier: str = typer.Argument(..., help="Message identifier"),
    search_type: str = typer.Option(
        "auto",
        "--search-type",
        help="Search type (default: auto)",
        case_sensitive=False,
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
):
    """
    Get details of a specific message.

    This command retrieves detailed information about a specific message from
    the MBOX file using the specified identifier. The search type determines
    how the message is identified.

    Parameters
    ----------
    mbox_file : str
        The path to the MBOX file to analyze. This is a required parameter and
        must be a valid MBOX file path.

    identifier : str
        The message identifier to search for. This can be a Message-ID, index,
        or other identifier depending on the search type.

    search_type : str, default="auto"
        The search type for identifying the message. Supported types:
        * "auto" - Automatically determine the best search method
        * "index" - Search by message index
        * "message-id" - Search by Message-ID header
        The search type is case-insensitive.

    output : Optional[str], default=None
        The output file path to save the message details. If not specified,
        the details are output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the message details
        to stdout or saves them to the specified output file.

    Raises
    ------
    ValueError
        If the MBOX file is invalid, the message is not found, or the search
        type is not supported.

    Examples
    --------
    Get message by Message-ID:

    >>> fbpyutils mailbox message ./emails.mbox "<message-id@example.com>"
    # Outputs message details

    Get message by index:

    >>> fbpyutils mailbox message ./emails.mbox 0 --search-type index
    # Outputs details of first message

    Get message and save to file:

    >>> fbpyutils mailbox message ./emails.mbox "<message-id@example.com>" --output message.json
    # Saves message details to message.json

    Notes
    -----
    * Message identifiers can be Message-ID, index, or other identifiers
    * Search type determines how messages are identified (auto, index, message-id)
    * Output file is created with UTF-8 encoding
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.mailbox.MboxReader.get_message_details : Message retrieval function
    handle_error : Error handling utility
    """
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_message_details(identifier, search_type)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Message details saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error getting message details: {e}")
        handle_error(e, "Failed to get message details")


@app.command()
def list(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    limit: Optional[int] = typer.Argument(None, help="Limit number of messages"),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
):
    """
    List message summaries.

    This command lists summaries of messages in the MBOX file, optionally
    limiting the number of messages returned. Each summary includes key
    information such as subject, sender, date, and message ID.

    Parameters
    ----------
    mbox_file : str
        The path to the MBOX file to analyze. This is a required parameter and
        must be a valid MBOX file path.

    limit : Optional[int], default=None
        The maximum number of messages to list. If not specified, all messages
        are listed.

    output : Optional[str], default=None
        The output file path to save the message list. If not specified, the
        list is output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the message summaries
        to stdout or saves them to the specified output file.

    Raises
    ------
    ValueError
        If the MBOX file is invalid or cannot be read.

    Examples
    --------
    List all message summaries:

    >>> fbpyutils mailbox list ./emails.mbox
    # Lists all message summaries

    List limited number of messages:

    >>> fbpyutils mailbox list ./emails.mbox 10
    # Lists first 10 message summaries

    List messages and save to file:

    >>> fbpyutils mailbox list ./emails.mbox 10 --output messages.json
    # Saves first 10 message summaries to messages.json

    Notes
    -----
    * Each summary includes subject, sender, date, and message ID
    * Limit parameter controls the maximum number of messages returned
    * Output file is created with UTF-8 encoding
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.mailbox.MboxReader.list_messages_summary : Message listing function
    handle_error : Error handling utility
    """
    try:
        reader = MboxReader(mbox_file)
        result = reader.list_messages_summary(limit)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Message list saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error listing messages: {e}")
        handle_error(e, "Failed to list messages")


@app.command()
def search(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    term: str = typer.Argument(..., help="Search term"),
    search_fields: str = typer.Option(
        "subject,from,to",
        "--search-fields",
        help="Fields to search in (comma-separated)",
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
):
    """
    Search messages by term.

    This command searches for messages in the MBOX file that contain the
    specified search term in the configured fields. The search can be
    customized to search in specific fields such as subject, from, or to.

    Parameters
    ----------
    mbox_file : str
        The path to the MBOX file to analyze. This is a required parameter and
        must be a valid MBOX file path.

    term : str
        The search term to look for in the messages. This is a required
        parameter and can be any string.

    search_fields : str, default="subject,from,to"
        The fields to search in, specified as a comma-separated list. Common
        fields include "subject", "from", "to", "cc", "date", etc.

    output : Optional[str], default=None
        The output file path to save the search results. If not specified, the
        results are output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the search results
        to stdout or saves them to the specified output file.

    Raises
    ------
    ValueError
        If the MBOX file is invalid or the search fields are invalid.

    Examples
    --------
    Search messages by term:

    >>> fbpyutils mailbox search ./emails.mbox "important"
    # Searches for "important" in subject, from, and to fields

    Search in specific fields:

    >>> fbpyutils mailbox search ./emails.mbox "john@example.com" --search-fields from
    # Searches for email address in from field only

    Search in multiple fields:

    >>> fbpyutils mailbox search ./emails.mbox "project" --search-fields subject,body
    # Searches for "project" in subject and body fields

    Search and save results:

    >>> fbpyutils mailbox search ./emails.mbox "urgent" --output results.json
    # Saves search results to results.json

    Notes
    -----
    * Search fields are comma-separated (e.g., "subject,from,to")
    * Search is case-insensitive
    * Results include message index, ID, subject, from, date, and attachment status
    * Output file is created with UTF-8 encoding
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.mailbox.MboxReader.search_messages : Message search function
    handle_error : Error handling utility
    """
    try:
        reader = MboxReader(mbox_file)
        fields_list = [field.strip() for field in search_fields.split(",")]
        results = reader.search_messages(term, fields_list)

        # Format results as JSON
        import json

        search_results = {
            "search_term": term,
            "search_fields": fields_list,
            "total_found": len(results),
            "messages": [],
        }

        for message, index in results:
            summary = {
                "index": index,
                "message_id": str(message.get("Message-ID", "")),
                "subject": str(message.get("Subject", "")),
                "from": str(message.get("From", "")),
                "date": str(message.get("Date", "")),
                "has_attachments": message.is_multipart(),
            }
            search_results["messages"].append(summary)

        result = json.dumps(search_results, indent=2, ensure_ascii=False)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Search results saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error searching messages: {e}")
        handle_error(e, "Failed to search messages")


@app.command()
def summary(
    mbox_file: str = typer.Argument(..., help="Path to MBOX file"),
    format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format (default: json)",
        case_sensitive=False,
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
):
    """
    Generate mailbox summary.

    This command generates a comprehensive summary of the MBOX file, including
    statistics such as total message count, date range, top senders, top
    recipients, and other relevant information.

    Parameters
    ----------
    mbox_file : str
        The path to the MBOX file to analyze. This is a required parameter and
        must be a valid MBOX file path.

    format : str, default="json"
        The output format for the summary. Supported formats:
        * "json" - Structured JSON format
        * "txt" - Human-readable text format
        The format is case-insensitive.

    output : Optional[str], default=None
        The output file path to save the summary. If not specified, the
        summary is output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the summary to
        stdout or saves it to the specified output file.

    Raises
    ------
    ValueError
        If the MBOX file is invalid or cannot be read.

    Examples
    --------
    Generate mailbox summary:

    >>> fbpyutils mailbox summary ./emails.mbox
    # Outputs mailbox summary in JSON format

    Generate summary and save to file:

    >>> fbpyutils mailbox summary ./emails.mbox --output summary.json
    # Saves summary to summary.json

    Generate summary in text format:

    >>> fbpyutils mailbox summary ./emails.mbox --format txt
    # Outputs summary in text format

    Notes
    -----
    * Summary includes total message count, date range, top senders, etc.
    * Output format is case-insensitive (json, txt)
    * Output file is created with UTF-8 encoding
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.mailbox.MboxReader.get_mailbox_summary : Summary generation function
    handle_error : Error handling utility
    """
    try:
        reader = MboxReader(mbox_file)
        result = reader.get_mailbox_summary(format)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(result)
            typer.echo(f"Summary saved to: {output}")
        else:
            typer.echo(result)

    except Exception as e:
        logger.error(f"Error generating summary: {e}")
        handle_error(e, "Failed to generate summary")
