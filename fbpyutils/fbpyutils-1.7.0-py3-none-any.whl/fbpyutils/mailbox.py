"""
MBOX file reader module.

This module provides functionality to read and analyze MBOX files,
extracting metadata and content from email messages.
"""

from typing import Any, Dict, List, Optional, Tuple, Union
import mailbox
import json
import csv
import base64
import os
from datetime import datetime
from email.utils import parsedate_to_datetime, parseaddr
from io import StringIO

import fbpyutils

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)

logger = fbpyutils.get_logger()


class MboxReader:
    """
    Reader class for MBOX files.

    Provides methods to extract metadata and content from email messages
    stored in MBOX format files.
    """

    def __init__(self, mbox_path: str) -> None:
        """
        Initialize the MBOX reader with a file path.

        Args:
            mbox_path: Path to the .mbox file to read

        Raises:
            FileNotFoundError: If the specified file does not exist
        """
        if not os.path.exists(mbox_path):
            logger.error(f"MBOX file not found: {mbox_path}")
            raise FileNotFoundError(f"File not found: {mbox_path}")

        self.mbox_path: str = mbox_path
        self.mbox: mailbox.mbox = mailbox.mbox(mbox_path)
        logger.info(f"Initialized MBOX reader for file: {mbox_path}")

    def close(self) -> None:
        """
        Close the MBOX file handle.
        """
        if hasattr(self.mbox, 'close'):
            self.mbox.close()
        logger.debug(f"Closed MBOX reader for file: {self.mbox_path}")

    def _ensure_json_serializable(self, obj: Any) -> Any:
        """
        Ensure an object is JSON serializable.

        Args:
            obj: Object to convert

        Returns:
            JSON serializable version of the object
        """
        if isinstance(obj, (str, int, float, bool, type(None))):
            return obj
        elif isinstance(obj, (list, tuple)):
            return [self._ensure_json_serializable(item) for item in obj]
        elif isinstance(obj, dict):
            return {
                key: self._ensure_json_serializable(value) for key, value in obj.items()
            }
        else:
            return str(obj)

    def _extract_message_metadata(self, message: mailbox.Message, index: Optional[int] = None) -> Dict[str, Any]:
        """
        Extract metadata from an email message.

        Args:
            message: Email message object
            index: Optional message index

        Returns:
            Dictionary containing message metadata
        """
        metadata: Dict[str, Any] = {}

        # Basic information
        metadata["index"] = index
        metadata["message_id"] = str(message.get("Message-ID", ""))
        metadata["subject"] = str(message.get("Subject", ""))

        # Sender and recipient information
        from_header = str(message.get("From", ""))
        to_header = str(message.get("To", ""))
        cc_header = str(message.get("Cc", ""))
        bcc_header = str(message.get("Bcc", ""))

        metadata["from"] = parseaddr(from_header)[1] if from_header else ""
        metadata["from_name"] = parseaddr(from_header)[0] if from_header else ""
        metadata["to"] = to_header
        metadata["cc"] = cc_header
        metadata["bcc"] = bcc_header

        # Date handling
        date_header = str(message.get("Date", "")) if message.get("Date") else ""
        if date_header:
            try:
                parsed_date = parsedate_to_datetime(date_header)
                metadata["date"] = parsed_date.isoformat()
                metadata["date_raw"] = date_header
            except Exception as e:
                logger.warning(f"Failed to parse date '{date_header}': {e}")
                metadata["date"] = ""
                metadata["date_raw"] = date_header
        else:
            metadata["date"] = ""
            metadata["date_raw"] = ""

        # Additional headers
        metadata["reply_to"] = str(message.get("Reply-To", ""))
        metadata["in_reply_to"] = str(message.get("In-Reply-To", ""))
        metadata["references"] = str(message.get("References", ""))
        metadata["priority"] = str(message.get("Priority", ""))
        metadata["x_priority"] = str(message.get("X-Priority", ""))

        # Technical information
        metadata["content_type"] = message.get_content_type()
        metadata["charset"] = message.get_content_charset()
        metadata["is_multipart"] = message.is_multipart()

        # Attachments
        attachments: List[Dict[str, Any]] = []
        if message.is_multipart():
            for part in message.walk():
                if part.get_content_disposition() == "attachment":
                    filename = part.get_filename()
                    if filename:
                        attachments.append({
                            "filename": filename,
                            "content_type": part.get_content_type(),
                            "size": len(part.get_payload(decode=True) or b""),
                        })

        metadata["attachments_count"] = len(attachments)
        metadata["attachments"] = attachments

        return metadata

    def get_all_metadata(self, format_type: str = "json") -> str:
        """
        Extract metadata from all messages in the MBOX file.

        Args:
            format_type: Output format ('json', 'csv', 'txt')

        Returns:
            Formatted metadata string

        Raises:
            ValueError: If format_type is not supported
        """
        messages_metadata: List[Dict[str, Any]] = []

        logger.info(f"Extracting metadata from {len(self.mbox)} messages")
        for index, message in enumerate(self.mbox):
            metadata = self._extract_message_metadata(message, index)
            messages_metadata.append(metadata)

        if format_type.lower() == "json":
            safe_metadata = self._ensure_json_serializable(messages_metadata)
            return json.dumps(safe_metadata, indent=2, ensure_ascii=False)

        elif format_type.lower() == "csv":
            if not messages_metadata:
                return ""

            fieldnames = messages_metadata[0].keys()
            csvfile = StringIO()
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

            for metadata in messages_metadata:
                row: Dict[str, Any] = {}
                for key, value in metadata.items():
                    if isinstance(value, (list, dict)):
                        row[key] = json.dumps(value, ensure_ascii=False)
                    else:
                        row[key] = str(value)
                writer.writerow(row)

            return csvfile.getvalue()

        elif format_type.lower() == "txt":
            output = []
            output.append(f"METADATA REPORT - {len(messages_metadata)} messages")
            output.append("=" * 60)
            output.append("")

            for metadata in messages_metadata:
                output.append(f"MESSAGE {metadata['index']}")
                output.append("-" * 30)
                output.append(f"Message ID: {metadata['message_id']}")
                output.append(f"Subject: {metadata['subject']}")
                output.append(f"From: {metadata['from_name']} <{metadata['from']}>")
                output.append(f"To: {metadata['to']}")
                output.append(f"Date: {metadata['date']}")
                output.append(f"Content Type: {metadata['content_type']}")
                output.append(f"Attachments: {metadata['attachments_count']}")
                if metadata["attachments"]:
                    for att in metadata["attachments"]:
                        output.append(f"  - {att['filename']} ({att['content_type']}, {att['size']} bytes)")
                output.append("")

            return "\n".join(output)

        else:
            raise ValueError("Format must be 'json', 'csv' or 'txt'")

    def _extract_attachments(self, message: mailbox.Message) -> List[Dict[str, Any]]:
        """
        Extract attachments from a message with base64 encoding.

        Args:
            message: Email message object

        Returns:
            List of attachment dictionaries with metadata and base64 content
        """
        attachments: List[Dict[str, Any]] = []

        if message.is_multipart():
            for part in message.walk():
                if part.get_content_disposition() == "attachment":
                    filename = part.get_filename()
                    if filename:
                        content = part.get_payload(decode=True)
                        if content:
                            attachment_data = {
                                "filename": filename,
                                "content_type": part.get_content_type(),
                                "size": len(content),
                                "content_base64": base64.b64encode(content).decode("utf-8"),
                                "encoding": part.get("Content-Transfer-Encoding", ""),
                                "content_disposition": part.get("Content-Disposition", ""),
                            }
                            attachments.append(attachment_data)

        return attachments

    def _extract_message_content(self, message: mailbox.Message) -> Dict[str, Any]:
        """
        Extract textual content from a message.

        Args:
            message: Email message object

        Returns:
            Dictionary containing different content formats
        """
        content: Dict[str, Any] = {"text_plain": "", "text_html": "", "other_parts": []}

        if message.is_multipart():
            for part in message.walk():
                content_type = part.get_content_type()
                content_disposition = part.get_content_disposition()

                # Skip attachments
                if content_disposition == "attachment":
                    continue

                try:
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or "utf-8"
                        text_content = payload.decode(charset, errors="ignore")

                        if content_type == "text/plain":
                            content["text_plain"] = text_content
                        elif content_type == "text/html":
                            content["text_html"] = text_content
                        else:
                            content["other_parts"].append({
                                "content_type": content_type,
                                "content": text_content[:1000] + "..." if len(text_content) > 1000 else text_content,
                            })
                except Exception as e:
                    logger.warning(f"Failed to decode message part: {e}")
                    pass
        else:
            # Simple message (not multipart)
            try:
                payload = message.get_payload(decode=True)
                if payload:
                    charset = message.get_content_charset() or "utf-8"
                    text_content = payload.decode(charset, errors="ignore")

                    if message.get_content_type() == "text/html":
                        content["text_html"] = text_content
                    else:
                        content["text_plain"] = text_content
            except Exception as e:
                logger.warning(f"Failed to decode simple message: {e}")
                content["text_plain"] = str(message.get_payload())

        return content

    def get_message_by_index(self, index: Union[int, str]) -> Tuple[Optional[mailbox.Message], Optional[int]]:
        """
        Get a specific message by its index.

        Args:
            index: Message index (0-based)

        Returns:
            Tuple of (message_object, index) or (None, None) if not found
        """
        try:
            index_int = int(index)
            if 0 <= index_int < len(self.mbox):
                return self.mbox[index_int], index_int
            else:
                return None, None
        except (ValueError, IndexError):
            return None, None

    def get_message_by_id(self, message_id: str) -> Tuple[Optional[mailbox.Message], Optional[int]]:
        """
        Get a specific message by its Message-ID.

        Args:
            message_id: Message-ID header value

        Returns:
            Tuple of (message_object, index) or (None, None) if not found
        """
        for index, message in enumerate(self.mbox):
            if str(message.get("Message-ID", "")) == message_id:
                return message, index
        return None, None

    def search_messages(self, search_term: str, search_fields: List[str] = None) -> List[Tuple[mailbox.Message, int]]:
        """
        Search messages by term in specified fields.

        Args:
            search_term: Term to search for
            search_fields: Fields to search in ['subject', 'from', 'to', 'message_id']

        Returns:
            List of (message_object, index) tuples for matching messages
        """
        if search_fields is None:
            search_fields = ["subject", "from", "to"]

        results: List[Tuple[mailbox.Message, int]] = []
        search_term_lower = search_term.lower()

        for index, message in enumerate(self.mbox):
            found = False

            for field in search_fields:
                field_value = ""

                if field == "subject":
                    field_value = str(message.get("Subject", ""))
                elif field == "from":
                    field_value = str(message.get("From", ""))
                elif field == "to":
                    field_value = str(message.get("To", ""))
                elif field == "message_id":
                    field_value = str(message.get("Message-ID", ""))

                if search_term_lower in field_value.lower():
                    found = True
                    break

            if found:
                results.append((message, index))

        logger.info(f"Search for '{search_term}' found {len(results)} messages")
        return results

    def get_message_details(self, identifier: Union[str, int], search_type: str = "auto") -> str:
        """
        Get detailed information about a specific message.

        Args:
            identifier: Message index, Message-ID, or search term
            search_type: Search type ('auto', 'index', 'message_id', 'search')

        Returns:
            JSON string with complete message details

        Raises:
            ValueError: If message is not found
        """
        message: Optional[mailbox.Message] = None
        message_index: Optional[int] = None

        # Auto search (backward compatibility)
        if search_type == "auto":
            # First try as numeric index
            message, message_index = self.get_message_by_index(identifier)

            # If not found by index, try by Message-ID
            if message is None:
                message, message_index = self.get_message_by_id(str(identifier))

        # Specific index search
        elif search_type == "index":
            message, message_index = self.get_message_by_index(identifier)

        # Specific Message-ID search
        elif search_type == "message_id":
            message, message_index = self.get_message_by_id(str(identifier))

        # Search by term
        elif search_type == "search":
            results = self.search_messages(str(identifier))
            if results:
                message, message_index = results[0]  # Return first result

        if message is None:
            logger.error(f"Message not found: {identifier} (search type: {search_type})")
            raise ValueError(f"Message not found: {identifier} (search type: {search_type})")

        # Extract all data
        metadata = self._extract_message_metadata(message, message_index)
        content = self._extract_message_content(message)
        attachments = self._extract_attachments(message)

        # All headers
        headers: Dict[str, str] = {}
        for key, value in message.items():
            headers[key] = str(value)

        message_details = {
            "search_info": {
                "identifier": str(identifier),
                "search_type": search_type,
                "found_at_index": message_index,
            },
            "metadata": metadata,
            "headers": headers,
            "content": content,
            "attachments": attachments,
            "extraction_timestamp": datetime.now().isoformat(),
        }

        # Ensure JSON serializable
        safe_details = self._ensure_json_serializable(message_details)
        return json.dumps(safe_details, indent=2, ensure_ascii=False)

    def list_messages_summary(self, limit: Optional[int] = None) -> str:
        """
        List a summary of all messages with indices.

        Args:
            limit: Optional limit on number of messages to list

        Returns:
            JSON string with message summaries
        """
        messages_summary: List[Dict[str, Any]] = []
        count = 0

        for index, message in enumerate(self.mbox):
            if limit and count >= limit:
                break

            summary = {
                "index": index,
                "message_id": str(message.get("Message-ID", "")),
                "subject": str(message.get("Subject", ""))[:100] + ("..." if len(str(message.get("Subject", ""))) > 100 else ""),
                "from": str(message.get("From", "")),
                "date": str(message.get("Date", "")),
                "has_attachments": message.is_multipart(),
            }
            messages_summary.append(summary)
            count += 1

        result = {
            "total_messages": len(self.mbox),
            "listed_messages": len(messages_summary),
            "messages": messages_summary,
        }

        safe_result = self._ensure_json_serializable(result)
        return json.dumps(safe_result, indent=2, ensure_ascii=False)

    def get_mailbox_summary(self, format_type: str = "json") -> str:
        """
        Generate a complete mailbox summary.

        Args:
            format_type: Output format ('json', 'csv', 'txt')

        Returns:
            Formatted summary string

        Raises:
            ValueError: If format_type is not supported
        """
        total_messages = len(self.mbox)

        if total_messages == 0:
            empty_summary = {
                "mailbox_file": os.path.basename(self.mbox_path),
                "mailbox_owner": "N/A",
                "total_messages": 0,
                "first_message_date": None,
                "last_message_date": None,
                "total_attachments": 0,
                "analysis_timestamp": datetime.now().isoformat(),
            }

            if format_type.lower() == "json":
                return json.dumps(empty_summary, indent=2, ensure_ascii=False)
            elif format_type.lower() == "txt":
                return "Empty mailbox - no messages found."
            elif format_type.lower() == "csv":
                csvfile = StringIO()
                writer = csv.DictWriter(csvfile, fieldnames=empty_summary.keys())
                writer.writeheader()
                writer.writerow(empty_summary)
                return csvfile.getvalue()

        # Identify mailbox owner (most frequent email in From)
        from_addresses: Dict[str, int] = {}
        dates: List[datetime] = []
        total_attachments = 0

        logger.info(f"Analyzing {total_messages} messages for summary generation")

        for index, message in enumerate(self.mbox):
            if index % 100 == 0 and index > 0:
                logger.debug(f"Processing message {index + 1}/{total_messages}")

            # Extract sender email
            from_header = str(message.get("From", ""))
            if from_header:
                from_email = parseaddr(from_header)[1]
                if from_email:
                    from_addresses[from_email] = from_addresses.get(from_email, 0) + 1

            # Extract date
            date_header = str(message.get("Date", ""))
            if date_header:
                try:
                    parsed_date = parsedate_to_datetime(date_header)
                    dates.append(parsed_date)
                except Exception as e:
                    logger.warning(f"Failed to parse date '{date_header}': {e}")

            # Count attachments
            if message.is_multipart():
                for part in message.walk():
                    if part.get_content_disposition() == "attachment":
                        filename = part.get_filename()
                        if filename:
                            total_attachments += 1

        # Determine mailbox owner (most frequent sender)
        mailbox_owner = "Unknown"
        if from_addresses:
            mailbox_owner = max(from_addresses, key=from_addresses.get)

        # Determine date range
        first_message_date = None
        last_message_date = None

        if dates:
            dates.sort()
            first_message_date = dates[0].isoformat()
            last_message_date = dates[-1].isoformat()

        summary = {
            "mailbox_file": os.path.basename(self.mbox_path),
            "mailbox_full_path": self.mbox_path,
            "mailbox_owner": mailbox_owner,
            "total_messages": total_messages,
            "first_message_date": first_message_date,
            "last_message_date": last_message_date,
            "total_attachments": total_attachments,
            "date_range_days": None,
            "top_senders": [],
            "file_size_bytes": os.path.getsize(self.mbox_path),
            "analysis_timestamp": datetime.now().isoformat(),
        }

        # Calculate date range in days
        if first_message_date and last_message_date and len(dates) > 1:
            date_range = dates[-1] - dates[0]
            summary["date_range_days"] = date_range.days

        # Top 5 most frequent senders
        if from_addresses:
            sorted_senders = sorted(from_addresses.items(), key=lambda x: x[1], reverse=True)
            summary["top_senders"] = [
                {"email": email, "message_count": count}
                for email, count in sorted_senders[:5]
            ]

        logger.info("Mailbox analysis completed")

        # Format output according to requested type
        if format_type.lower() == "json":
            safe_summary = self._ensure_json_serializable(summary)
            return json.dumps(safe_summary, indent=2, ensure_ascii=False)

        elif format_type.lower() == "csv":
            # Flatten structure for CSV
            csv_data = []

            # Basic data
            base_data = {
                "mailbox_file": summary["mailbox_file"],
                "mailbox_full_path": summary["mailbox_full_path"],
                "mailbox_owner": summary["mailbox_owner"],
                "total_messages": summary["total_messages"],
                "first_message_date": summary["first_message_date"],
                "last_message_date": summary["last_message_date"],
                "total_attachments": summary["total_attachments"],
                "date_range_days": summary["date_range_days"],
                "file_size_bytes": summary["file_size_bytes"],
                "analysis_timestamp": summary["analysis_timestamp"],
            }

            # Add top senders as separate columns
            for i, sender in enumerate(summary["top_senders"][:5]):
                base_data[f"top_sender_{i + 1}_email"] = sender["email"]
                base_data[f"top_sender_{i + 1}_count"] = sender["message_count"]

            csv_data.append(base_data)

            csvfile = StringIO()
            if csv_data:
                writer = csv.DictWriter(csvfile, fieldnames=csv_data[0].keys())
                writer.writeheader()
                writer.writerow(csv_data[0])

            return csvfile.getvalue()

        elif format_type.lower() == "txt":
            output = []
            output.append("=" * 60)
            output.append("MAILBOX SUMMARY")
            output.append("=" * 60)
            output.append("")

            output.append(f"File: {summary['mailbox_file']}")
            output.append(f"Full Path: {summary['mailbox_full_path']}")
            output.append(f"File Size: {summary['file_size_bytes']:,} bytes")
            output.append("")

            output.append("GENERAL INFORMATION:")
            output.append("-" * 30)
            output.append(f"Mailbox Owner: {summary['mailbox_owner']}")
            output.append(f"Total Messages: {summary['total_messages']:,}")
            output.append(f"Total Attachments: {summary['total_attachments']:,}")
            output.append("")

            output.append("MESSAGE PERIOD:")
            output.append("-" * 30)
            if summary["first_message_date"]:
                first_date = datetime.fromisoformat(summary["first_message_date"])
                output.append(f"First Message: {first_date.strftime('%d/%m/%Y %H:%M:%S')}")
            else:
                output.append("First Message: N/A")

            if summary["last_message_date"]:
                last_date = datetime.fromisoformat(summary["last_message_date"])
                output.append(f"Last Message: {last_date.strftime('%d/%m/%Y %H:%M:%S')}")
            else:
                output.append("Last Message: N/A")

            if summary["date_range_days"] is not None:
                output.append(f"Total Period: {summary['date_range_days']:,} days")
            output.append("")

            if summary["top_senders"]:
                output.append("TOP 5 MOST FREQUENT SENDERS:")
                output.append("-" * 30)
                for i, sender in enumerate(summary["top_senders"], 1):
                    percentage = (sender["message_count"] / summary["total_messages"]) * 100
                    output.append(f"{i}. {sender['email']}")
                    output.append(f"   Messages: {sender['message_count']:,} ({percentage:.1f}%)")
                output.append("")

            output.append(f"Analysis Generated: {datetime.fromisoformat(summary['analysis_timestamp']).strftime('%d/%m/%Y %H:%M:%S')}")
            output.append("=" * 60)

            return "\n".join(output)

        else:
            raise ValueError("Format must be 'json', 'csv' or 'txt'")