"""
Doc commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def doc():
    """Commands for documentation generation."""
    pass


@doc.command("generate-all")
@click.option("--source-dir", required=True, help="Source directory containing Python modules.")
@click.option("--output-dir", required=True, help="Output directory for generated documentation.")
@click.option("--exclude-init", is_flag=True, default=True, help="Exclude __init__.py files.")
def generate_all_cmd(source_dir: str, output_dir: str, exclude_init: bool):
    """Generate Markdown documentation for all Python modules in a directory."""
    try:
        logger.info(f"Generating documentation from {source_dir} to {output_dir}")

        # Import the generate_module_docs function
        from fbpyutils.doc import generate_module_docs

        # Generate documentation
        generate_module_docs(source_dir, output_dir, exclude_init)

        click.echo(f"Documentation generated successfully in {output_dir}")

        logger.debug("Documentation generation completed")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to generate documentation")