"""
Command groups for the fbpyutils CLI.
"""

from . import calendar, datetime, doc, file, image, mailbox, ofx, process, string, xlsx

__all__ = ["calendar", "datetime", "doc", "file", "image", "mailbox", "ofx", "process", "string", "xlsx"]
