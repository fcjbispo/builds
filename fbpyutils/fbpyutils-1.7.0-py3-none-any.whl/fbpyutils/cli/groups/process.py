"""
Process commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def process():
    """Commands for process management."""


@process.command("cpu-count")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def get_cpu_count(output_format: str):
    """Get the number of available CPU cores."""
    try:
        logger.info("Getting available CPU count")

        from fbpyutils.process import Process

        result = Process.get_available_cpu_count()

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug(f"Available CPU count: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to get CPU count")


@process.command("check-parallel")
@click.option(
    "--parallel-type",
    default="threads",
    type=click.Choice(["threads", "processes"]),
    help="Type of parallelization to check.",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def check_parallel(parallel_type: str, output_format: str):
    """Check if parallelization is supported for the given type."""
    try:
        logger.info(f"Checking parallelization support for {parallel_type}")

        from fbpyutils.process import Process

        result = Process.is_parallelizable(parallel_type)

        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug(f"Parallelization support for {parallel_type}: {result}")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to check parallelization support")