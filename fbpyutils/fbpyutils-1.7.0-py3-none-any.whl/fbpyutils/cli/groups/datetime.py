"""
Datetime commands for the fbpyutils CLI.
"""

import click
import fbpyutils
from fbpyutils.cli.utils.output_formatter import format_output
from fbpyutils.cli.utils.error_handler import handle_error
from datetime import datetime as dt

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()


@click.group()
def datetime():
    """Commands for datetime manipulation."""
    pass


@datetime.command("delta")
@click.option("--date1", required=True, help="First datetime (YYYY-MM-DDTHH:MM:SS).")
@click.option("--date2", required=True, help="Second datetime (YYYY-MM-DDTHH:MM:SS).")
@click.option(
    "--unit",
    default="months",
    type=click.Choice(["months", "years"]),
    help="Unit for delta calculation.",
)
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def delta_cmd(date1: str, date2: str, unit: str, output_format: str):
    """Calculate time delta between two dates in months or years."""
    try:
        logger.info(f"Calculating delta between {date1} and {date2} in {unit}")

        # Parse datetimes
        dt1 = dt.fromisoformat(date1)
        dt2 = dt.fromisoformat(date2)

        # Import the delta function
        from fbpyutils.datetime import delta

        # Ensure dt2 is later than dt1 for delta calculation
        if dt2 < dt1:
            dt1, dt2 = dt2, dt1

        # Calculate delta
        result = delta(dt2, dt1, unit)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Delta calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate delta")


@datetime.command("apply-timezone")
@click.option("--date-time", required=True, help="Naive datetime (YYYY-MM-DDTHH:MM:SS).")
@click.option("--timezone", required=True, help="Timezone name (e.g., 'America/Sao_Paulo').")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def apply_timezone_cmd(date_time: str, timezone: str, output_format: str):
    """Apply timezone to a naive datetime."""
    try:
        logger.info(f"Applying timezone {timezone} to {date_time}")

        # Parse datetime
        dt_obj = dt.fromisoformat(date_time)

        # Import the apply_timezone function
        from fbpyutils.datetime import apply_timezone

        # Apply timezone
        result = apply_timezone(dt_obj, timezone)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Timezone applied successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to apply timezone")


@datetime.command("elapsed")
@click.option("--date1", required=True, help="Start datetime (YYYY-MM-DDTHH:MM:SS).")
@click.option("--date2", required=True, help="End datetime (YYYY-MM-DDTHH:MM:SS).")
@click.option(
    "--output-format",
    default="txt",
    type=click.Choice(["txt", "json", "csv"]),
    help="Output format.",
)
def elapsed_cmd(date1: str, date2: str, output_format: str):
    """Calculate elapsed time between two datetimes."""
    try:
        logger.info(f"Calculating elapsed time between {date1} and {date2}")

        # Parse datetimes
        dt1 = dt.fromisoformat(date1)
        dt2 = dt.fromisoformat(date2)

        # Import the elapsed_time function
        from fbpyutils.datetime import elapsed_time

        # Calculate elapsed time (dt2 should be later than dt1)
        result = elapsed_time(dt2, dt1)

        # Format and output the result
        formatted_result = format_output(result, output_format)
        click.echo(formatted_result)

        logger.debug("Elapsed time calculated successfully")
    except Exception as e:
        logger.error(f"Exception details: {str(e)}", exc_info=True)
        handle_error(e, "Failed to calculate elapsed time")