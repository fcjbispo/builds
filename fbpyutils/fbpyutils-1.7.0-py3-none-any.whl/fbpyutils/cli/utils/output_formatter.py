"""
Output formatting utilities for the fbpyutils CLI.
"""

import json
import csv
import io
from datetime import date, datetime
from typing import Any


class JSONEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle date and datetime objects."""

    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def format_output(data: Any, output_format: str = "txt") -> str:
    """
    Format output data according to the specified format.

    Args:
        data: The data to format.
        output_format: The output format ('txt', 'json', 'csv').

    Returns:
        The formatted data as a string.
    """
    if output_format == "json":
        if isinstance(data, (dict, list)):
            return json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder)
        else:
            return json.dumps(
                {"result": data}, indent=2, ensure_ascii=False, cls=JSONEncoder
            )

    elif output_format == "csv":
        if isinstance(data, list) and data and isinstance(data[0], dict):
            # Handle list of dictionaries
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
            return output.getvalue()
        elif isinstance(data, dict):
            # Handle single dictionary
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=data.keys())
            writer.writeheader()
            writer.writerow(data)
            return output.getvalue()
        else:
            # Handle simple data
            return str(data)

    else:  # txt format (default)
        if isinstance(data, (list, tuple)):
            # Handle list/tuple of strings (e.g., sheet names)
            if data and all(isinstance(item, str) for item in data):
                return '\n'.join(data)
            # Handle list/tuple of tuples/lists (e.g., sheet data)
            elif data and all(isinstance(item, (list, tuple)) for item in data):
                lines = []
                for row in data:
                    # Convert each cell to string and join with tabs
                    line = '\t'.join(str(cell) for cell in row)
                    lines.append(line)
                return '\n'.join(lines)
            else:
                return str(data)
        elif isinstance(data, dict):
            return str(data)
        else:
            return str(data)
