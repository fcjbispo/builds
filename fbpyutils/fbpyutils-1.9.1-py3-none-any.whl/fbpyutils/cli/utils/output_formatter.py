"""
Output Formatting Utilities for the FBPyUtils Command-Line Interface

This module provides flexible output formatting functionality for the FBPyUtils CLI,
supporting multiple output formats (text, JSON, CSV) for command results. The module
includes a custom JSON encoder for handling datetime objects and intelligent data
structure conversion for different output formats.

The module provides two primary components:

* **Custom JSON Encoder**: The JSONEncoder class extends the standard JSON encoder
  to handle date and datetime objects by converting them to ISO format strings.

* **Output Formatting**: The format_output function converts data structures into
  various output formats (text, JSON, CSV) with intelligent handling of different
  data types including lists, dictionaries, and simple values.

Key Features:
-------------
* **Multiple Formats**: Support for txt, json, and csv output formats
* **Date/Time Handling**: Custom JSON encoder for datetime object serialization
* **Intelligent Conversion**: Automatic handling of different data structures
* **CSV Support**: Proper CSV formatting for list of dictionaries and single dictionaries
* **Text Formatting**: Tab-separated output for tabular data structures
* **Unicode Support**: ensure_ascii=False for proper Unicode character handling
* **Memory Efficient**: Uses StringIO for CSV output to avoid file I/O

Dependencies:
-------------
* `json`: Standard library JSON encoding and decoding
* `csv`: Standard library CSV writing and reading
* `io`: Standard library I/O operations (StringIO)
* `datetime`: Standard library date and datetime types
* `typing`: Type hints for function parameters

Usage Examples:
---------------
Format output as JSON:

>>> from fbpyutils.cli.utils.output_formatter import format_output
>>> data = {'name': 'Alice', 'age': 30, 'created': datetime(2024, 1, 1)}
>>> format_output(data, 'json')
'{\\n  "name": "Alice",\\n  "age": 30,\\n  "created": "2024-01-01T00:00:00"\\n}'

Format output as CSV:

>>> from fbpyutils.cli.utils.output_formatter import format_output
>>> data = [
...     {'name': 'Alice', 'age': 30},
...     {'name': 'Bob', 'age': 25}
... ]
>>> format_output(data, 'csv')
'name,age\\nAlice,30\\nBob,25'

Format output as text:

>>> from fbpyutils.cli.utils.output_formatter import format_output
>>> data = ['Sheet1', 'Sheet2', 'Sheet3']
>>> format_output(data, 'txt')
'Sheet1\\nSheet2\\nSheet3'

Format tabular data as text:

>>> from fbpyutils.cli.utils.output_formatter import format_output
>>> data = [['Name', 'Age'], ['Alice', 30], ['Bob', 25]]
>>> format_output(data, 'txt')
'Name\\tAge\\nAlice\\t30\\nBob\\t25'

Use custom JSON encoder:

>>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
>>> import json
>>> data = {'date': datetime(2024, 1, 1)}
>>> json.dumps(data, cls=JSONEncoder)
'{"date": "2024-01-01T00:00:00"}'

Notes:
------
* JSON format uses 2-space indentation for readability
* CSV format handles both single dictionaries and lists of dictionaries
* Text format intelligently handles different data structures
* Date and datetime objects are converted to ISO format strings in JSON
* Unicode characters are preserved in JSON output (ensure_ascii=False)
* CSV output uses StringIO for memory efficiency
* Tab-separated format is used for tabular data in text output

Output Format Details:
----------------------
* **txt**: Human-readable text format with intelligent structure handling
* **json**: Structured JSON format with proper datetime serialization
* **csv**: Comma-separated values format for tabular data

Cross-References:
-----------------
* See `fbpyutils.cli.utils` for CLI utility functions
* See `fbpyutils.cli.main` for main CLI entry point
* See `json.JSONEncoder` for base JSON encoder class
* See `csv.DictWriter` for CSV writing functionality
"""

import json
import csv
import io
from datetime import date, datetime
from typing import Any


class JSONEncoder(json.JSONEncoder):
    """
    Custom JSON encoder for handling date and datetime objects.

    This class extends the standard JSON encoder to properly serialize date and
    datetime objects by converting them to ISO format strings. This allows
    datetime objects to be included in JSON output without raising TypeError.

    Parameters
    ----------
    *args : tuple
        Positional arguments passed to the parent JSONEncoder class.

    **kwargs : dict
        Keyword arguments passed to the parent JSONEncoder class.

    Attributes
    ----------
    Inherits all attributes from json.JSONEncoder.

    Methods
    -------
    default(obj)
        Override the default method to handle date and datetime objects.

    Examples
    --------
    Encode datetime object to JSON:

    >>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
    >>> import json
    >>> from datetime import datetime
    >>> data = {'created': datetime(2024, 1, 1, 12, 0, 0)}
    >>> json.dumps(data, cls=JSONEncoder)
    '{"created": "2024-01-01T12:00:00"}'

    Encode date object to JSON:

    >>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
    >>> import json
    >>> from datetime import date
    >>> data = {'birth_date': date(1990, 5, 15)}
    >>> json.dumps(data, cls=JSONEncoder)
    '{"birth_date": "1990-05-15"}'

    Encode mixed data types:

    >>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
    >>> import json
    >>> from datetime import datetime
    >>> data = {
    ...     'name': 'Alice',
    ...     'age': 30,
    ...     'created': datetime(2024, 1, 1),
    ...     'active': True
    ... }
    >>> json.dumps(data, cls=JSONEncoder, indent=2)
    '{\\n  "name": "Alice",\\n  "age": 30,\\n  "created": "2024-01-01T00:00:00",\\n  "active": true\\n}'

    Notes
    -----
    * Date and datetime objects are converted to ISO format strings
    * Other data types are handled by the parent JSONEncoder class
    * This encoder is used automatically by format_output for JSON format
    * ISO format ensures interoperability with other systems and languages

    See Also
    --------
    json.JSONEncoder : Base JSON encoder class
    datetime.isoformat : ISO format string conversion
    format_output : Output formatting function using this encoder
    """

    def default(self, obj):
        """
        Override default method to handle date and datetime objects.

        This method is called by the JSON encoder when it encounters an object
        that is not natively JSON serializable. It converts date and datetime
        objects to ISO format strings.

        Parameters
        ----------
        obj : Any
            The object to serialize. If it's a date or datetime object, it will
            be converted to an ISO format string.

        Returns
        -------
        str
            ISO format string representation of date or datetime objects, or
            the result of the parent class's default method for other types.

        Raises
        ------
        TypeError
            If the object is not JSON serializable and is not a date or datetime.

        Examples
        --------
        Convert datetime to ISO format:

        >>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
        >>> from datetime import datetime
        >>> encoder = JSONEncoder()
        >>> encoder.default(datetime(2024, 1, 1, 12, 0, 0))
        '2024-01-01T12:00:00'

        Convert date to ISO format:

        >>> from fbpyutils.cli.utils.output_formatter import JSONEncoder
        >>> from datetime import date
        >>> encoder = JSONEncoder()
        >>> encoder.default(date(2024, 1, 1))
        '2024-01-01'

        Notes
        -----
        * This method is called automatically by the JSON encoder
        * ISO format is the standard for date/time representation in JSON
        * The method delegates to the parent class for non-date/datetime objects
        """
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def format_output(data: Any, output_format: str = "txt") -> str:
    """
    Format output data according to the specified format.

    This function converts data structures into various output formats (text,
    JSON, CSV) with intelligent handling of different data types. It supports
    lists, dictionaries, and simple values, with appropriate formatting for
    each output type.

    Parameters
    ----------
    data : Any
        The data to format. Can be a dictionary, list, tuple, or simple value.
        Lists can contain strings, dictionaries, or nested lists/tuples for
        tabular data.

    output_format : str, default="txt"
        The output format to use. Supported formats:
        * "txt" - Human-readable text format with intelligent structure handling
        * "json" - Structured JSON format with proper datetime serialization
        * "csv" - Comma-separated values format for tabular data

    Returns
    -------
    str
        The formatted data as a string. The format depends on the output_format
        parameter and the structure of the input data.

    Raises
    ------
    None
        This function does not raise exceptions. It handles all data types
        gracefully by converting them to strings.

    Examples
    --------
    Format dictionary as JSON:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> from datetime import datetime
    >>> data = {'name': 'Alice', 'age': 30, 'created': datetime(2024, 1, 1)}
    >>> format_output(data, 'json')
    '{\\n  "name": "Alice",\\n  "age": 30,\\n  "created": "2024-01-01T00:00:00"\\n}'

    Format list of dictionaries as CSV:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> data = [
    ...     {'name': 'Alice', 'age': 30},
    ...     {'name': 'Bob', 'age': 25}
    ... ]
    >>> format_output(data, 'csv')
    'name,age\\nAlice,30\\nBob,25'

    Format list of strings as text:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> data = ['Sheet1', 'Sheet2', 'Sheet3']
    >>> format_output(data, 'txt')
    'Sheet1\\nSheet2\\nSheet3'

    Format tabular data as text:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> data = [['Name', 'Age'], ['Alice', 30], ['Bob', 25]]
    >>> format_output(data, 'txt')
    'Name\\tAge\\nAlice\\t30\\nBob\\t25'

    Format simple value as JSON:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> data = "Success"
    >>> format_output(data, 'json')
    '{\\n  "result": "Success"\\n}'

    Format single dictionary as CSV:

    >>> from fbpyutils.cli.utils.output_formatter import format_output
    >>> data = {'name': 'Alice', 'age': 30}
    >>> format_output(data, 'csv')
    'name,age\\nAlice,30'

    Notes
    -----
    * JSON format uses 2-space indentation and ensure_ascii=False
    * CSV format handles both single dictionaries and lists of dictionaries
    * Text format intelligently handles different data structures
    * Tab-separated format is used for tabular data in text output
    * Date and datetime objects are converted to ISO format in JSON
    * Simple values are wrapped in a "result" key for JSON format
    * CSV output uses StringIO for memory efficiency

    Format-Specific Behavior:
    -------------------------
    * **txt**:
      - Lists of strings are joined with newlines
      - Lists of lists/tuples are formatted as tab-separated rows
      - Other types are converted to string representation

    * **json**:
      - Dictionaries and lists are formatted as JSON
      - Simple values are wrapped in {"result": value}
      - Datetime objects are serialized as ISO format strings

    * **csv**:
      - Lists of dictionaries are formatted as CSV with headers
      - Single dictionaries are formatted as CSV with headers
      - Other types are converted to string representation

    See Also
    --------
    JSONEncoder : Custom JSON encoder for datetime objects
    json.dumps : Standard JSON encoding function
    csv.DictWriter : CSV writer for dictionary data
    io.StringIO : In-memory string buffer for CSV output
    """
    if output_format == "json":
        if isinstance(data, (dict, list)):
            return json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder)
        else:
            return json.dumps(
                {"result": data}, indent=2, ensure_ascii=False, cls=JSONEncoder
            )

    elif output_format == "csv":
        if isinstance(data, list) and data and isinstance(data[0], dict):
            # Handle list of dictionaries
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
            return output.getvalue()
        elif isinstance(data, dict):
            # Handle single dictionary
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=data.keys())
            writer.writeheader()
            writer.writerow(data)
            return output.getvalue()
        else:
            # Handle simple data
            return str(data)

    else:  # txt format (default)
        if isinstance(data, (list, tuple)):
            # Handle list/tuple of strings (e.g., sheet names)
            if data and all(isinstance(item, str) for item in data):
                return "\n".join(data)
            # Handle list/tuple of tuples/lists (e.g., sheet data)
            elif data and all(isinstance(item, (list, tuple)) for item in data):
                lines = []
                for row in data:
                    # Convert each cell to string and join with tabs
                    line = "\t".join(str(cell) for cell in row)
                    lines.append(line)
                return "\n".join(lines)
            else:
                return str(data)
        elif isinstance(data, dict):
            return str(data)
        else:
            return str(data)
