"""
OFX (Open Financial Exchange) Commands for the FBPyUtils Command-Line Interface

This module provides command-line interface commands for OFX file processing and
parsing. The OFX commands allow users to parse OFX financial data files and
convert them to JSON format with flexible output options and date handling.

The module provides one primary command:

* **parse-file**: Parse an OFX file and output its content as JSON or write to
  a file with optional native datetime object handling.

Key Features:
-------------
* **OFX Parsing**: Parse OFX (Open Financial Exchange) financial data files
* **JSON Output**: Convert OFX data to structured JSON format
* **Date Handling**: Optional native datetime objects or ISO-formatted strings
* **File Output**: Optional output to file for saving parsed data
* **Pretty Printing**: Formatted JSON output with proper indentation
* **Unicode Support**: ensure_ascii=False for proper Unicode character handling
* **Error Handling**: Comprehensive error handling with user-friendly messages
* **Logging Integration**: Detailed logging for debugging and troubleshooting

Dependencies:
-------------
* `typer`: Modern Python CLI framework for command definition
* `fbpyutils`: Main library for OFX functionality
* `fbpyutils.ofx.read_from_path`: OFX file parsing function
* `fbpyutils.cli.utils.error_handler`: Error handling utilities
* `fbpyutils.cli.utils.output_formatter.JSONEncoder`: Custom JSON encoder
* `json`: Standard library JSON encoding and decoding
* `os`: Standard library operating system interface

Usage Examples:
---------------
Parse OFX file and output to stdout:

>>> fbpyutils ofx parse-file --path ./transactions.ofx
# Outputs OFX data as JSON to stdout

Parse OFX file with native datetime objects:

>>> fbpyutils ofx parse-file --path ./transactions.ofx --native-date
# Outputs OFX data with datetime objects

Parse OFX file and save to file:

>>> fbpyutils ofx parse-file --path ./transactions.ofx --output-file ./output.json
# Saves OFX data to output.json

Parse OFX file with all options:

>>> fbpyutils ofx parse-file --path ./transactions.ofx --native-date --output-file ./output.json
# Parses OFX with datetime objects and saves to file

Command Help:
-------------
Display help for OFX commands:

>>> fbpyutils ofx --help
# Shows all available OFX commands

Display help for parse-file command:

>>> fbpyutils ofx parse-file --help
# Shows detailed help for the parse-file command

Notes:
------
* OFX (Open Financial Exchange) is a standard format for financial data
* OFX files contain transaction data, account information, and balances
* Native datetime objects are Python datetime objects
* ISO-formatted dates are strings in ISO 8601 format (YYYY-MM-DDTHH:MM:SS)
* Output directory is created automatically if it does not exist
* Output file is created with UTF-8 encoding
* JSON output is pretty-printed with 2-space indentation
* The command integrates with the fbpyutils logging system
* All errors are logged with full exception details for debugging

Error Handling:
---------------
* Invalid OFX file: Error message if file is not a valid OFX format
* File not found: Error message if file path does not exist
* Parse errors: Comprehensive error logging with exception details
* General errors: Comprehensive error logging and user-friendly messages

Cross-References:
-----------------
* See `fbpyutils.ofx` for OFX functionality implementation
* See `fbpyutils.ofx.read_from_path` for OFX file parsing function
* See `fbpyutils.cli.utils.output_formatter.JSONEncoder` for JSON encoder
* See `fbpyutils.cli.utils.error_handler` for error handling details
"""

import typer
import fbpyutils
import json
import os
from fbpyutils.ofx import read_from_path
from fbpyutils.cli.utils.error_handler import handle_error
from fbpyutils.cli.utils.output_formatter import JSONEncoder

fbpyutils.setup(fbpyutils._APP_CONFIG_FILE)
logger = fbpyutils.get_logger()

# Create Typer app for ofx commands
app = typer.Typer(
    name="ofx",
    help="Commands for OFX (Open Financial Exchange) processing.",
    rich_markup_mode="rich",
)


@app.command("parse-file")
def parse_file(
    path: str = typer.Option(..., "--path", help="Path to OFX file."),
    native_date: bool = typer.Option(
        False,
        "--native-date",
        help="Return dates as native datetime objects. If not provided, dates will be returned as ISO-formatted strings.",
    ),
    output_file: str = typer.Option(
        None, "--output-file", help="Optional: write JSON output to a file."
    ),
):
    """
    Parse an OFX file and output its content as JSON or write to a file.

    This command parses an OFX (Open Financial Exchange) file and converts its
    content to JSON format. The parsed data can be output to stdout or saved to
    a file. Dates can be returned as native datetime objects or ISO-formatted
    strings.

    Parameters
    ----------
    path : str
        The path to the OFX file to parse. This is a required parameter and must
        be a valid OFX file path.

    native_date : bool, default=False
        If True, dates are returned as native Python datetime objects. If False,
        dates are returned as ISO-formatted strings (YYYY-MM-DDTHH:MM:SS).

    output_file : Optional[str], default=None
        The output file path to save the parsed JSON data. If not specified, the
        data is output to stdout.

    Returns
    -------
    None
        This function does not return a value. It outputs the parsed OFX data
        to stdout or saves it to the specified output file.

    Raises
    ------
    ValueError
        If the OFX file is invalid or cannot be parsed.

    Examples
    --------
    Parse OFX file and output to stdout:

    >>> fbpyutils ofx parse-file --path ./transactions.ofx
    # Outputs OFX data as JSON to stdout

    Parse OFX file with native datetime objects:

    >>> fbpyutils ofx parse-file --path ./transactions.ofx --native-date
    # Outputs OFX data with datetime objects

    Parse OFX file and save to file:

    >>> fbpyutils ofx parse-file --path ./transactions.ofx --output-file ./output.json
    # Saves OFX data to output.json

    Parse OFX file with all options:

    >>> fbpyutils ofx parse-file --path ./transactions.ofx --native-date --output-file ./output.json
    # Parses OFX with datetime objects and saves to file

    Notes
    -----
    * OFX (Open Financial Exchange) is a standard format for financial data
    * OFX files contain transaction data, account information, and balances
    * Native datetime objects are Python datetime objects
    * ISO-formatted dates are strings in ISO 8601 format (YYYY-MM-DDTHH:MM:SS)
    * Output directory is created automatically if it does not exist
    * Output file is created with UTF-8 encoding
    * JSON output is pretty-printed with 2-space indentation
    * The command integrates with the fbpyutils logging system
    * All errors are logged with full exception details for debugging

    See Also
    --------
    fbpyutils.ofx.read_from_path : OFX file parsing function
    JSONEncoder : Custom JSON encoder for datetime objects
    handle_error : Error handling utility
    """
    try:
        logger.info(
            f"OFX parse-file invoked for path={path}, native_date={native_date}, output_file={output_file}"
        )

        data = read_from_path(path, native_date)

        if output_file:
            # Ensure the output directory exists
            output_dir = os.path.dirname(output_file)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir)

            # Write pretty-printed JSON to the file
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder))

            logger.info(f"OFX data written to {output_file}")
            typer.echo(f"OFX data written to {output_file}")
        else:
            # Print to stdout as JSON for CLI usage
            formatted = json.dumps(data, indent=2, ensure_ascii=False, cls=JSONEncoder)
            typer.echo(formatted)
            logger.debug("OFX data printed to stdout")

    except Exception as e:
        logger.error(f"Error parsing OFX file: {e}", exc_info=True)
        handle_error(e, "Failed to parse OFX file")
