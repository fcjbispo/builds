"""
Command Groups for the FBPyUtils Command-Line Interface

This module provides the command group organization for the FBPyUtils CLI, grouping
related commands into logical categories for intuitive navigation and usage. Each command
group corresponds to a specific utility module in the fbpyutils library, providing
command-line access to the module's functionality.

The module organizes commands into the following groups:

* **calendar**: Calendar manipulation and date range generation commands
* **datetime**: Date and time calculation and manipulation commands
* **doc**: Documentation generation and extraction commands
* **file**: File system operations and management commands
* **image**: Image processing and analysis commands
* **mailbox**: MBOX email file processing and analysis commands
* **ofx**: OFX financial data processing and parsing commands
* **process**: Parallel and serial process execution commands
* **string**: String manipulation and text processing commands
* **xlsx**: Excel file processing and workbook management commands

Key Features:
-------------
* **Logical Organization**: Commands grouped by functionality for easy discovery
* **Modular Design**: Each command group is a separate module for maintainability
* **Consistent Interface**: All groups follow the same Typer-based pattern
* **Automatic Registration**: Groups are automatically registered with the main CLI app
* **Help Integration**: Each group provides automatic help generation

Dependencies:
-------------
* `fbpyutils.cli.groups.calendar`: Calendar manipulation commands
* `fbpyutils.cli.groups.datetime`: Date/time manipulation commands
* `fbpyutils.cli.groups.doc`: Documentation commands
* `fbpyutils.cli.groups.file`: File system commands
* `fbpyutils.cli.groups.image`: Image processing commands
* `fbpyutils.cli.groups.mailbox`: MBOX email processing commands
* `fbpyutils.cli.groups.ofx`: OFX financial data commands
* `fbpyutils.cli.groups.process`: Process execution commands
* `fbpyutils.cli.groups.string`: String manipulation commands
* `fbpyutils.cli.groups.xlsx`: Excel file processing commands

Usage Examples:
---------------
Access command groups programmatically:

>>> from fbpyutils.cli.groups import calendar, datetime, file
>>> calendar.app
<typer.main.Typer object at 0x...>

Display help for specific command group:

>>> fbpyutils calendar --help
Usage: fbpyutils calendar [OPTIONS] COMMAND [ARGS]...
  Commands for calendar manipulation.

Use calendar commands:

>>> fbpyutils calendar get-range --start-date 2023-01-01 --end-date 2023-01-31
# Generates calendar for January 2023

Use datetime commands:

>>> fbpyutils datetime delta --start-date 2023-01-01 --end-date 2023-01-31
# Calculates time delta between dates

Use file commands:

>>> fbpyutils file find --pattern "*.py" --path /home/user/project
# Finds all Python files in directory

Notes:
------
* All command groups are imported and made available through this module
* The __all__ list defines the public API for the command groups
* Each group is a Typer app that can be registered with the main CLI
* Command groups are automatically registered in the main CLI module
* Each group provides its own help text and command documentation

Cross-References:
-----------------
* See `fbpyutils.cli.main` for the main CLI entry point
* See `fbpyutils.cli.groups.calendar` for calendar manipulation commands
* See `fbpyutils.cli.groups.datetime` for date/time manipulation commands
* See `fbpyutils.cli.groups.doc` for documentation commands
* See `fbpyutils.cli.groups.file` for file system commands
* See `fbpyutils.cli.groups.image` for image processing commands
* See `fbpyutils.cli.groups.mailbox` for MBOX email processing commands
* See `fbpyutils.cli.groups.ofx` for OFX financial data commands
* See `fbpyutils.cli.groups.process` for process execution commands
* See `fbpyutils.cli.groups.string` for string manipulation commands
* See `fbpyutils.cli.groups.xlsx` for Excel file processing commands
* See `typer.Typer` for the CLI framework used for command groups
"""

from . import calendar, datetime, doc, file, image, mailbox, ofx, process, string, xlsx

__all__ = [
    "calendar",
    "datetime",
    "doc",
    "file",
    "image",
    "mailbox",
    "ofx",
    "process",
    "string",
    "xlsx",
]
