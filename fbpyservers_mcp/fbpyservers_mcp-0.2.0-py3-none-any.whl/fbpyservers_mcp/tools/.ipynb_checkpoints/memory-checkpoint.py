import os
import yaml
from typing import Dict, Any, Optional
from mem0 import Memory


def _load_memory_config() -> Dict[str, Any]:
    """
    Load Memory configuration from YAML file specified by FBPY_MEMORY_CONFIG_FILE.
    This function requires the user to provide a valid YAML configuration file.

    Returns:
        Configuration dictionary for Mem0 Memory class

    Raises:
        ValueError: If FBPY_MEMORY_CONFIG_FILE is not set or file is not found
        yaml.YAMLError: If YAML file is invalid
    """
    config_file = os.getenv("FBPY_MEMORY_CONFIG_FILE")

    if not config_file:
        raise ValueError("FBPY_MEMORY_CONFIG_FILE environment variable is required")

    # Check if file exists at specified location
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"Memory configuration file not found: {config_file}")

    # Load and validate YAML configuration
    try:
        with open(config_file, "r") as file:
            config = yaml.safe_load(file)

            # Validate that configuration is not empty
            if not config:
                raise ValueError("Configuration file is empty")

            # Validate required configuration sections
            required_sections = ["vector_store", "llm", "embedder"]
            missing_sections = [
                section for section in required_sections if section not in config
            ]

            if missing_sections:
                raise ValueError(
                    f"Configuration missing required sections: {missing_sections}"
                )

            return config

    except yaml.YAMLError:
        raise
    except Exception:
        raise


# Load configuration from YAML file (will raise exception if not configured)
_memory_config_dict = _load_memory_config()

_memory_user = os.getenv("FBPY_MEMORY_USER") or "default_user"
_memory_agent = os.getenv("FBPY_MEMORY_AGENT") or "default_agent"
_memory_last_error = None

# Create Memory instance with user-provided configuration
try:
    _memory = Memory.from_config(_memory_config_dict)
except Exception as e:
    _memory = None
    _memory_last_error = str(e)


async def add_memory(content: str, metadata: Optional[Dict[str, Any]] = None) -> str:
    """
    Add a new memory to the memory store.

    Args:
        content: The memory content to store
        metadata: Optional metadata for the memory

    Returns:
        Success message with memory ID or error message
    """
    if _memory is None:
        return f"❌ Memory system failed to initialize: {_memory_last_error}. Please check your YAML configuration file."

    if not content:
        return "❌ Cannot add empty memory. Please provide content."

    try:
        # Add user to metadata
        memory_metadata = metadata or {}
        memory_metadata["user_id"] = _memory_user
        memory_metadata["agent_id"] = _memory_agent

        # Executar a operação add com infer=False para evitar problemas com Neo4j
        result = _memory.add(
            messages=content,
            user_id=_memory_user,
            agent_id=_memory_agent,
            metadata=memory_metadata,
            infer=False  # Adicionar conteúdo completo sem inferência
        )

        # Extrair memory_id da resposta do Mem0
        memory_id = None
        if result and isinstance(result, dict):
            # Estratégia 1: Tentar extrair de results (formato principal com infer=False)
            if "results" in result and result["results"]:
                if isinstance(result["results"], list) and len(result["results"]) > 0:
                    first_result = result["results"][0]
                    if isinstance(first_result, dict):
                        memory_id = first_result.get("id") or first_result.get("memory_id") or first_result.get("uuid")
            
            # Estratégia 2: Verificar relations.added_entities como fallback
            elif "relations" in result and "added_entities" in result["relations"]:
                added_entities = result["relations"]["added_entities"]
                if isinstance(added_entities, list) and len(added_entities) > 0:
                    first_entity = added_entities[0]
                    if isinstance(first_entity, dict):
                        memory_id = first_entity.get("id") or first_entity.get("memory_id") or first_entity.get("uuid")
            
            # Estratégia 3: Verificar campos diretos no resultado
            elif "id" in result:
                memory_id = result["id"]
            elif "memory_id" in result:
                memory_id = result["memory_id"]
            elif "uuid" in result:
                memory_id = result["uuid"]
        
        # Estratégia 4: Se ainda não temos ID, usar busca como fallback
        if not memory_id:
            try:
                # Buscar a memória recém-adicionada
                search_results = _memory.search(
                    query=content,
                    user_id=_memory_user,
                    agent_id=_memory_agent,
                    limit=3
                )
                
                if isinstance(search_results, dict) and "results" in search_results:
                    results = search_results["results"]
                    if isinstance(results, list) and len(results) > 0:
                        # Encontrar a memória mais recente e com maior score que corresponde ao conteúdo
                        matching_memories = []
                        for mem in results:
                            mem_content = mem.get("memory", "")
                            # Verificar se o conteúdo corresponde (exato ou parcial)
                            if content.strip() in mem_content or mem_content in content.strip():
                                matching_memories.append(mem)
                        
                        if matching_memories:
                            # Usar a memória com maior score
                            latest_memory = max(matching_memories, key=lambda x: x.get("score", 0))
                            memory_id = latest_memory.get("id")
                        elif results:
                            # Se não há correspondência exata, usar a de maior score
                            latest_memory = max(results, key=lambda x: x.get("score", 0))
                            memory_id = latest_memory.get("id")
            except Exception:
                # Se a busca falhar, manter memory_id como None
                pass

        if not memory_id:
            return f"⚠️ Memory added but ID not found in response.\nRaw result: {result}\nContent: {content[:100]}{'...' if len(content) > 100 else ''}"

        return f"✅ Memory added successfully.\nID: {memory_id}\nContent: {content[:100]}{'...' if len(content) > 100 else ''}"

    except Exception as e:
        return f"❌ Error adding memory: {str(e)}"


async def search_memories(query: str, limit: int = 5) -> str:
    """
    Search through stored memories using semantic search.

    Args:
        query: The search query
        limit: Maximum number of results to return (default: 5)

    Returns:
        Formatted search results or error message
    """
    if _memory is None:
        return f"❌ Memory system failed to initialize: {_memory_last_error}. Please check your YAML configuration file."

    if not query:
        return "❌ Cannot search with empty query. Please provide a search term."

    try:
        results = _memory.search(
            query=query, user_id=_memory_user, agent_id=_memory_agent, limit=limit
        )

        memories = results.get("results", [])

        if not memories:
            return f"🔍 No memories found for query: '{query}'"

        output = [f"Found {len(memories)} memories for: '{query}'\n"]

        for i, mem in enumerate(memories, 1):
            memory_text = mem.get("memory", "N/A")
            memory_id = mem.get("id", "N/A")
            score = mem.get("score", 0)

            output.append(f"\n{i}. Relevance Score: {score:.2f} | ID: {memory_id}")
            output.append(
                f"   {memory_text[:200]}{'...' if len(memory_text) > 200 else ''}"
            )

        return "\n".join(output)

    except Exception as e:
        return f"❌ Error searching memories: {str(e)}"


async def get_all_memories(limit: int = 10) -> str:
    """
    Retrieve all memories for the current user.

    Args:
        limit: Maximum number of memories to return (default: 10)

    Returns:
        Formatted list of all memories or error message
    """
    if _memory is None:
        return f"❌ Memory system failed to initialize: {_memory_last_error}. Please check your YAML configuration file."

    try:
        results = _memory.get_all(user_id=_memory_user, agent_id=_memory_agent)
        memories = results.get("results", [])

        if not memories:
            return "📚 No memories stored yet."

        total_memories = len(memories)
        display_count = min(limit, total_memories)

        output = [f"📚 Total memories: {total_memories}\n"]

        for i, mem in enumerate(memories[:display_count], 1):
            memory_text = mem.get("memory", "N/A")
            memory_id = mem.get("id", "N/A")

            output.append(f"\n{i}. ID: {memory_id}")
            output.append(
                f"   {memory_text[:150]}{'...' if len(memory_text) > 150 else ''}"
            )

        if total_memories > display_count:
            output.append(f"\n... and {total_memories - display_count} more memories")

        return "\n".join(output)

    except Exception as e:
        return f"❌ Error retrieving memories: {str(e)}"


async def delete_memory(memory_id: str) -> str:
    """
    Delete a specific memory by ID.

    Args:
        memory_id: The ID of the memory to delete

    Returns:
        Success message or error message
    """
    if _memory is None:
        return f"❌ Memory system failed to initialize: {_memory_last_error}. Please check your YAML configuration file."

    if not memory_id:
        return "❌ Cannot delete memory without ID. Please provide a memory ID."

    try:
        _memory.delete(memory_id=memory_id)
        return f"✅ Memory {memory_id} deleted successfully."

    except Exception as e:
        return f"❌ Error deleting memory: {str(e)}"


async def get_memory(memory_id: str) -> str:
    """
    Get a specific memory by ID from the memory storage.

    Args:
        memory_id: The ID of the memory to retrieve

    Returns:
        Formatted memory details or error message
    """
    if _memory is None:
        return f"❌ Memory system failed to initialize: {_memory_last_error}. Please check your YAML configuration file."

    if not memory_id:
        return "❌ Cannot get memory without ID. Please provide a memory ID."

    try:
        # Try to get specific memory using mem0ai's get method if available
        try:
            # First, try to get all memories with a reasonable limit
            results = _memory.get_all(user_id=_memory_user, agent_id=_memory_agent)
            memories = results.get("results", [])
            
            # Find the memory with the exact ID
            target_memory = None
            for mem in memories:
                if mem.get("id") == memory_id:
                    target_memory = mem
                    break
            
            if not target_memory:
                return f"❌ Memory with ID '{memory_id}' not found."
                
        except Exception:
            # Fallback: if get_all fails, try using search with a generic query
            # Use a very generic search term that should match most content
            search_query = "memory content information data"
            results = _memory.search(
                query=search_query,
                user_id=_memory_user,
                agent_id=_memory_agent,
                limit=1000  # High limit to ensure we can find the specific memory
            )
            
            memories = results.get("results", [])
            
            # Find the memory with the exact ID
            target_memory = None
            for mem in memories:
                if mem.get("id") == memory_id:
                    target_memory = mem
                    break
            
            if not target_memory:
                return f"❌ Memory with ID '{memory_id}' not found."

        # Format the response
        memory_text = target_memory.get("memory", "N/A")
        score = target_memory.get("score", 0)
        metadata = target_memory.get("metadata", {})
        created_at = target_memory.get("created_at", "N/A")

        output = [f"📖 Memory Details"]
        output.append(f"ID: {memory_id}")
        output.append(f"Relevance Score: {score:.2f}")
        output.append(f"Created At: {created_at}")
        
        if metadata:
            output.append(f"Metadata: {metadata}")
        
        output.append(f"\nContent:")
        output.append(f"{memory_text}")

        return "\n".join(output)

    except Exception as e:
        return f"❌ Error retrieving memory: {str(e)}"
