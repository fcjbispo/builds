from typing import Dict, Any, Optional
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.tools.memory import add_memory as memory_tool_add
from fbpyservers_mcp.tools.memory import search_memories as memory_tool_search
from fbpyservers_mcp.tools.memory import get_all_memories as memory_tool_get_all
from fbpyservers_mcp.tools.memory import delete_memory as memory_tool_delete


# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_memory")


@mcp.tool()
async def memory_add(
    content: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Add a new memory to the memory store.

    Args:
        content: The memory content to store
        metadata: Optional metadata for the memory (JSON object)

    Returns:
        Success message with memory ID or error message
    """
    return await memory_tool_add(content, metadata)


@mcp.tool()
async def memory_search(
    query: str,
    limit: int = 5,
) -> str:
    """
    Search through stored memories using semantic search.

    Args:
        query: The search query
        limit: Maximum number of results to return (default: 5)

    Returns:
        Formatted search results or error message
    """
    return await memory_tool_search(query, limit)


@mcp.tool()
async def memory_get_all(
    limit: int = 10,
) -> str:
    """
    Retrieve all memories for the current user.

    Args:
        limit: Maximum number of memories to return (default: 10)

    Returns:
        Formatted list of all memories or error message
    """
    return await memory_tool_get_all(limit)


@mcp.tool()
async def memory_delete(
    memory_id: str,
) -> str:
    """
    Delete a specific memory by ID.

    Args:
        memory_id: The ID of the memory to delete

    Returns:
        Success message or error message
    """
    return await memory_tool_delete(memory_id)


if __name__ == "__main__":
    # Initialize and run the server
    mcp.run(transport="stdio")
