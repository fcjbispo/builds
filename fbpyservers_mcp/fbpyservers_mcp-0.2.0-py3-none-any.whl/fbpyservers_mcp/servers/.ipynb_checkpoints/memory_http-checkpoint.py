"""
Memory MCP server with streaming HTTP protocol (without authentication).

This module provides a memory server that runs with HTTP streaming protocol
without API Key authentication. It's designed for development and internal use
where authentication is not required.

Usage:
    python -m fbpyservers_mcp.servers.memory_http

Environment Variables:
    FBPY_MCP_TRANSPORT: Set to "streamable-http"
    FBPY_MCP_HTTP_HOST: Host to bind (default: "0.0.0.0")
    FBPY_MCP_HTTP_PORT: Port to use (default: 8000)
    FBPY_MCP_HTTP_STATELESS: Use stateless mode (default: "true")
"""

import os
import sys
import logging
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.servers.memory_factory import MEMORY_TOOLS

# Configure logging
logger = logging.getLogger(__name__)


def main():
    """
    Main entry point for the HTTP memory server.
    
    This server provides memory management functionality via HTTP streaming
    protocol without authentication requirements.
    """
    try:
        # Force HTTP protocol without authentication
        os.environ["FBPY_MCP_TRANSPORT"] = "streamable-http"
        os.environ["FBPY_MCP_AUTH_ENABLED"] = "false"
        
        # Create HTTP server without authentication
        server, http_config = MCPServerFactory.create_streaming_http_server(
            name="memory",
            tools=MEMORY_TOOLS,
            auth_enabled=False
        )
        
        # Print startup information
        print("🚀 Starting FBPyServers-MCP Memory Server (HTTP)")
        print("   Protocol: HTTP Streaming API")
        print("   Authentication: DISABLED")
        print("   Host: " + http_config.get("host", "0.0.0.0"))
        print("   Port: " + str(http_config.get("port", 8000)))
        print("   Use Cases: Development, internal testing, local development")
        print()
        print("⚠️  SECURITY WARNING: This server does not require authentication.")
        print("   Do not expose this server to public networks!")
        print()
        
        # Run HTTP server
        server.run(transport="streamable-http", **http_config)
        
    except Exception as e:
        logger.error(f"Failed to start HTTP memory server: {str(e)}")
        print(f"❌ Error starting HTTP memory server: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
