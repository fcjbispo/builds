from typing import List
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.tools.scrape import scrape


# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_webscrape")


@mcp.tool()
async def web_scrape(
    url: str, tags_to_remove: List[str] = [], timeout: int = 30000
) -> str:
    """
    Scrapes a webpage and extracts full content in Markdown format.

    Args:
        url: The URL of the webpage to scrape.
        tags_to_remove: A list of HTML tags to remove. Ex: ['/script', '/ad']. Defaults to an empty list.
        timeout: Maximum time to wait for scraping. Defaults to 30000.
    """
    return await scrape(url, tags_to_remove=tags_to_remove, timeout=timeout)


if __name__ == "__main__":
    # Initialize and run the server
    mcp.run(transport="stdio")
