# Memory Configuration Guide

This guide explains how to configure the Memory MCP tools for the FBPyServers-MCP application.

## 🚫 CRITICAL REQUIREMENT

**The Memory service WILL NOT START without a valid configuration file.**

The Memory MCP tools require the `FBPY_MEMORY_CONFIG_FILE` environment variable to be set to a valid YAML configuration file.

## 📋 Configuration Steps

### 1. Set Environment Variable

Export the environment variable pointing to your configuration file:

```bash
export FBPY_MEMORY_CONFIG_FILE="/path/to/your/memory_config.yaml"
```

### 2. Create Configuration File

Create a YAML file with the Memory service configuration. Use the base configuration provided or create your own.

### 3. Use Base Configuration (Recommended)

Use our recommended base configuration:

```bash
# Copy the base configuration
export FBPY_MEMORY_CONFIG_FILE="/var/data/FBNet/MCPMemory/config/base.yaml"

# Start the MCP server
uv run fbpyservers-mcp
```

## 📄 Base Configuration Template

Create a file with this structure:

```yaml
vector_store:
  provider: qdrant
  config:
    host: localhost
    port: 6333
    collection_name: mem0_mcp_memory
    embedding_model_dims: 512

llm:
  provider: openai
  config:
    model: gpt-4o-mini
    temperature: 0.1
    max_tokens: 1000

embedder:
  provider: openai
  config:
    model: text-embedding-3-small
    api_key: ""  # Uses OPENAI_API_KEY env var if "" or unset

reranker:
  provider: cohere
  config:
    model: rerank-english-v3.0

history:
  enabled: true
  max_history: 10
```

## 🔧 Configuration Sections

### Required Sections
- `vector_store`: Backend database for storing memories
- `llm`: Language model for processing memories
- `embedder`: Embeddings model for semantic search

### Optional Sections
- `reranker`: Re-ranking results for better relevance
- `history`: Memory history and context management

### Vector Store Options
- **qdrant**: Local Qdrant database (recommended for local development)
- **sqlite**: SQLite database (good for small deployments)
- **pgvector**: PostgreSQL with vector extensions
- **chromadb**: ChromaDB vector database

### LLM Provider Options
- **openai**: OpenAI GPT models (requires API key)
- **anthropic**: Claude models (requires API key)
- **cohere**: Cohere models (requires API key)
- **local**: Local/Ollama models (free, self-hosted)

## 🔑 Environment Variables

### Required for Memory Service
- `FBPY_MEMORY_CONFIG_FILE`: Path to your YAML configuration file

### Required by Memory Components
The required variables depend on your configuration:
- `OPENAI_API_KEY`: For OpenAI provider
- `ANTHROPIC_API_KEY`: For Anthropic provider
- `COHERE_API_KEY`: For Cohere provider
- `FBPY_MEMORY_USER`: User identification (default: "default_user")

## 🔍 Error Messages

If the Memory service fails to start, you'll see these error types:

### Configuration Errors
- Environment variable not set
- Configuration file not found
- Invalid YAML format
- Missing required sections

### Service Connection Errors
- Qdrant database connection refused
- OpenAI API quota exceeded
- Cohere API authentication failed

## 🚀 Quick Setup Examples

### Local Development with OpenAI
```bash
export FBPY_MEMORY_CONFIG_FILE="/var/data/FBNet/MCPMemory/config/base.yaml"
export OPENAI_API_KEY="your-openai-api-key-here"
uv run fbpyservers-mcp
```

### Local Development with Local Models
Create `local_config.yaml`:
```yaml
vector_store:
  provider: sqlite
  config:
    db_path: ":memory:"

llm:
  provider: local
  config:
    model: "ollama/llama2"
    base_url: "http://localhost:11434"

embedder:
  provider: local
  config:
    model: "ollama/llama2"
    base_url: "http://localhost:11434"

history:
  enabled: true
  max_history: 10
```

Then run:
```bash
export FBPY_MEMORY_CONFIG_FILE="/path/to/local_config.yaml"
uv run fbpyservers-mcp
```

### Production with Custom Setup
```bash
export FBPY_MEMORY_CONFIG_FILE="/etc/mcp/memory_config.yaml"
export FBPY_MEMORY_USER=custom_user
export OPENAI_API_KEY="your-key"
export COHERE_API_KEY="your-cohere-key"
uv run fbpyservers-mcp
```

## 🧪 Testing Your Configuration

Test if your configuration is valid:

```python
import yaml
with open('/path/to/your/config.yaml', 'r') as f:
    config = yaml.safe_load(f)
    print("✅ Valid YAML")
    print(f"Sections: {list(config.keys())}")
```

Test Memory service specifically:
```bash
export FBPY_MEMORY_CONFIG_FILE="/path/to/config.yaml"
python3 -c "
import sys
sys.path.append('/home/fcjbispo/Dev/Repos/FBPyServers-MCP')
from fbpyservers_mcp.tools.memory import _memory_config_dict
print('Configuration loaded successfully!')
print(f'Sections: {list(_memory_config_dict.keys())}')
"
```

## 📝 Notes

- The memory service is production-ready once configured
- Memory persistence depends on your vector store configuration
- API keys must be set before service startup
- Configuration changes require service restart
- Network connectivity required for cloud-based services

## 🛠️ Debugging

If you encounter issues:

1. **Check environment variable**: `echo $FBPY_MEMORY_CONFIG_FILE`
2. **Verify file exists**: `ls -la $FBPY_MEMORY_CONFIG_FILE`
3. **Validate YAML**: `python3 -c "import yaml; yaml.safe_load(open('$FBPY_MEMORY_CONFIG_FILE'))"`
4. **Check API keys**: Ensure provider API keys are set
5. **Test service connectivity**: Verify database/cloud services are accessible

For detailed error messages, start the MCP server and check the console output for configuration errors.