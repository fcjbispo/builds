# Guia de Extração de Dados - Modelo FBPyServers-MCP

## Análise do Modelo de Dados

### Estrutura Hierárquica

```python
Prompt (1) -----> (N) PromptArgument
Prompt (1) -----> (N) PromptMessage  
Resource (1)
```

### Cardinalidades e Relacionamentos
- **Prompt → PromptArgument**: 1:N (opcional, pode não ter argumentos)
- **Prompt → PromptMessage**: 1:N (obrigatório, pelo menos 1 mensagem)
- **Resource**: Entidade independente

## Validações por Tipo de Dado

### Prompt
- **name**: String(256), NOT NULL, único
- **description**: String(4000), NOT NULL
- **status**: Enum("PENDING", "APPROVED", "DISABLED"), default="PENDING"

### PromptArgument  
- **name**: String(256), NOT NULL
- **description**: String(4000), NOT NULL
- **prompt_id**: ForeignKey("prompt.id"), NOT NULL
- **required**: Integer, default=1, NOT NULL
- **status**: Enum("PENDING", "APPROVED", "DISABLED"), default="PENDING"

### PromptMessage
- **role**: String(256), NOT NULL (valores: "system", "user", "assistant")
- **type**: String(256), NOT NULL
- **content**: String(4000), NOT NULL
- **prompt_id**: ForeignKey("prompt.id"), NOT NULL
- **status**: Enum("PENDING", "APPROVED", "DISABLED"), default="PENDING"

### Resource
- **name**: String(256), NOT NULL
- **mime_type**: String(256), NOT NULL
- **size_bytes**: Integer, default=0, NOT NULL
- **description**: String(4000), NOT NULL
- **uri**: String(4000), NOT NULL
- **status**: Enum("PENDING", "APPROVED", "DISABLED"), default="PENDING"

## Verificações de Integridade

### Validação de Prompt
```python
def validate_prompt(prompt_data):
    errors = []
    warnings = []
    
    # Verificações obrigatórias
    if not prompt_data.get('name'):
        errors.append("Campo 'name' é obrigatório")
    elif len(prompt_data['name']) > 256:
        errors.append("Campo 'name' excede 256 caracteres")
    
    if not prompt_data.get('description'):
        errors.append("Campo 'description' é obrigatório")
    elif len(prompt_data['description']) > 4000:
        errors.append("Campo 'description' excede 4000 caracteres")
    
    # Verificação de mensagens (obrigatório)
    messages = prompt_data.get('messages', [])
    if not messages:
        errors.append("Prompt deve ter pelo menos 1 PromptMessage")
    
    for i, msg in enumerate(messages):
        if not msg.get('role'):
            errors.append(f"Message {i}: campo 'role' é obrigatório")
        elif msg['role'] not in ['system', 'user', 'assistant']:
            errors.append(f"Message {i}: role '{msg['role']}' inválido")
        
        if not msg.get('content'):
            errors.append(f"Message {i}: campo 'content' é obrigatório")
        elif len(msg['content']) > 4000:
            errors.append(f"Message {i}: content excede 4000 caracteres")
    
    # Verificação de argumentos (opcional)
    arguments = prompt_data.get('arguments', [])
    for i, arg in enumerate(arguments):
        if not arg.get('name'):
            errors.append(f"Argument {i}: campo 'name' é obrigatório")
        elif len(arg['name']) > 256:
            errors.append(f"Argument {i}: name excede 256 caracteres")
        
        if not arg.get('description'):
            errors.append(f"Argument {i}: campo 'description' é obrigatório")
        elif len(arg['description']) > 4000:
            errors.append(f"Argument {i}: description excede 4000 caracteres")
    
    return {
        'valid': len(errors) == 0,
        'errors': errors,
        'warnings': warnings
    }
```

### Validação de Resource
```python
def validate_resource(resource_data):
    errors = []
    warnings = []
    
    # Verificações obrigatórias
    if not resource_data.get('name'):
        errors.append("Campo 'name' é obrigatório")
    elif len(resource_data['name']) > 256:
        errors.append("Campo 'name' excede 256 caracteres")
    
    if not resource_data.get('mime_type'):
        errors.append("Campo 'mime_type' é obrigatório")
    elif len(resource_data['mime_type']) > 256:
        errors.append("Campo 'mime_type' excede 256 caracteres")
    
    if not resource_data.get('uri'):
        errors.append("Campo 'uri' é obrigatório")
    elif len(resource_data['uri']) > 4000:
        errors.append("Campo 'uri' excede 4000 caracteres")
    
    if not resource_data.get('description'):
        errors.append("Campo 'description' é obrigatório")
    elif len(resource_data['description']) > 4000:
        errors.append("Campo 'description' excede 4000 caracteres")
    
    # Verificação de tamanho
    size_bytes = resource_data.get('size_bytes', 0)
    if not isinstance(size_bytes, int) or size_bytes < 0:
        errors.append("Campo 'size_bytes' deve ser inteiro não negativo")
    
    return {
        'valid': len(errors) == 0,
        'errors': errors,
        'warnings': warnings
    }
```

## Exemplos Práticos

### Exemplo 1: Prompt Completo

**Entrada (Markdown):**
```markdown
# Sistema de Análise de Código

Este prompt é usado para análise de código Python:

```
system: Você é um especialista em análise de código Python
user: Analise este código: {codigo}
assistant: Vou analisar o código fornecido...
```
```

Parâmetros:
- codigo: Código Python para análise (obrigatório)
- nivel: Nível de detalhamento (opcional, padrão: básico)
```

**Saída Esperada:**
```json
{
  "prompts": [
    {
      "name": "sistema_analise_codigo",
      "description": "Prompt especializado para análise de código Python com parâmetros configuráveis",
      "status": "PENDING",
      "arguments": [
        {
          "name": "codigo",
          "description": "Código Python para análise (obrigatório)",
          "required": 1,
          "status": "PENDING"
        },
        {
          "name": "nivel",
          "description": "Nível de detalhamento (opcional, padrão: básico)",
          "required": 0,
          "status": "PENDING"
        }
      ],
      "messages": [
        {
          "role": "system",
          "type": "instruction",
          "content": "Você é um especialista em análise de código Python",
          "status": "PENDING"
        },
        {
          "role": "user",
          "type": "query",
          "content": "Analise este código: {codigo}",
          "status": "PENDING"
        },
        {
          "role": "assistant",
          "type": "response",
          "content": "Vou analisar o código fornecido...",
          "status": "PENDING"
        }
      ]
    }
  ]
}
```

### Exemplo 2: Resource Completo

**Entrada (Markdown):**
```markdown
## Documentação da API

A documentação completa está disponível em:
- [API Reference](https://api.exemplo.com/docs)
- [OpenAPI Schema](https://api.exemplo.com/openapi.json)
- [Exemplos de Código](https://github.com/exemplo/api-examples)

![Logo da API](https://api.exemplo.com/logo.png)
```

**Saída Esperada:**
```json
{
  "resources": [
    {
      "name": "api_reference_docs",
      "mime_type": "text/html",
      "size_bytes": 50000,
      "description": "Documentação completa da referência da API",
      "uri": "https://api.exemplo.com/docs",
      "status": "PENDING"
    },
    {
      "name": "openapi_schema",
      "mime_type": "application/json",
      "size_bytes": 15000,
      "description": "Schema OpenAPI para documentação da API",
      "uri": "https://api.exemplo.com/openapi.json",
      "status": "PENDING"
    },
    {
      "name": "api_examples_repo",
      "mime_type": "text/html",
      "size_bytes": 30000,
      "description": "Repositório com exemplos de código da API",
      "uri": "https://github.com/exemplo/api-examples",
      "status": "PENDING"
    },
    {
      "name": "api_logo",
      "mime_type": "image/png",
      "size_bytes": 2500,
      "description": "Logo oficial da API",
      "uri": "https://api.exemplo.com/logo.png",
      "status": "PENDING"
    }
  ]
}
```

### Exemplo 3: Prompt Incompleto (com correções)

**Entrada (Markdown):**
```markdown
# Prompt Simples
Mensagem do sistema: Seja útil
```

**Saída com Sugestões de Correção:**
```json
{
  "prompts": [
    {
      "name": "prompt_simples",
      "description": "Prompt básico extraído automaticamente - REQUER REVISÃO MANUAL",
      "status": "PENDING",
      "arguments": [],
      "messages": [
        {
          "role": "system",
          "type": "instruction",
          "content": "Seja útil",
          "status": "PENDING"
        }
      ]
    }
  ],
  "validation": {
    "valid": false,
    "errors": [
      "Description muito genérica - especifique o propósito do prompt",
      "Prompt muito simples - adicione mais contexto e exemplos"
    ],
    "suggestions": [
      "Adicione uma description mais detalhada sobre o uso do prompt",
      "Inclua mais mensagens (user/assistant) para tornar o prompt mais útil",
      "Considere adicionar parâmetros para maior flexibilidade"
    ]
  }
}
```

## Sugestões de Correção Automática

### Para Prompts Incompletos
1. **Description genérica**: Gerar description baseada no conteúdo das mensagens
2. **Falta de argumentos**: Identificar variáveis nas mensagens e criar argumentos
3. **Poucas mensagens**: Sugerir estrutura mínima system → user → assistant
4. **Nomes não descritivos**: Gerar nome baseado no conteúdo das mensagens

### Para Resources Incompletos
1. **MIME type genérico**: Inferir baseado na extensão do arquivo ou URL
2. **Tamanho desconhecido**: Estimar baseado no tipo de recurso
3. **URI inválida**: Validar e sugerir correções
4. **Description vazia**: Gerar description baseada no nome e contexto

## Validação Final

### Checklist de Integridade
- [ ] Todos os campos obrigatórios preenchidos
- [ ] Limites de caracteres respeitados
- [ ] Cardinalidades atendidas (pelo menos 1 PromptMessage)
- [ ] Tipos de dados corretos
- [ ] Relacionamentos válidos (ForeignKeys)
- [ ] Valores de enum válidos
- [ ] Dados estruturalmente consistentes

### Critérios de Qualidade
- **Completo**: Todos os campos preenchidos adequadamente
- **Consistente**: Dados seguem padrões e convenções
- **Útil**: Informações relevantes e descritivas
- **Válido**: Passa em todas as validações de integridade