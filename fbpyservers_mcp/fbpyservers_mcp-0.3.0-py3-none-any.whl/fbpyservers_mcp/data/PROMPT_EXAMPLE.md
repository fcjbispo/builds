Follow the VIBE-CODE GUIDE at https://github.com/fcjbispo/vibe-coding/blob/master/VIBE_GUIDE.md.

Your task is to review and revise **every Python module** (skip non-Python files and anything under a `unittest` or `test` directory) by adding or updating **all documentation**:

1. **Module-level docstring**  
   - Add a top-level docstring to every `.py` file that does not already have one.  
   - Include: purpose, main contents, high-level usage pattern, and a runnable mini-example (`>>> `) that can be pasted into a REPL.

2. **Function / class / method docstrings**  
   - Create or refresh docstrings so they fully comply with the VIBE-CODE guide.  
   - Every docstring must contain an **“Examples”** section that shows:  
     – a minimal usage call, and  
     – the exact expected output / returned value / side-effect.  
   - Do **not** touch the implementation code itself.

3. **DOCSTRINGS_TODO**  
   - Maintain a single `TODO.md` in `{{CODE_FOLDER}}`. Read it first if it already exists.
   - List every touched file and the status of its module + public API docstrings.  
   - Update the checklist as you work.

4. **Observability**  
   - Insert logging calls via `{{LOG_TOOL}}` at these strategic points:  
     – function/method **entry** (`INFO`): name & arguments (concise).  
     – function/method **exit** (`INFO`): name & return value (concise).  
     – **decision branches** (`DEBUG`): variables that steer the branch.  
     – **state mutations** (`DEBUG`): before & after values.  
     – **exception handlers** (`ERROR`): include `exc_info=True`.  
   - Keep noise low: one entry/exit pair per function, no spam inside tight loops.

   **Instructions:**:  {{INSTRUCTIONS}}


Work file-by-file inside `{{CODE_FOLDER}}`, for ALL SUB-MODULES SCRIPTS UNDER THE MAIN MODULE committing each time the docstrings and logging on `TODO.md` file for each script are complete.