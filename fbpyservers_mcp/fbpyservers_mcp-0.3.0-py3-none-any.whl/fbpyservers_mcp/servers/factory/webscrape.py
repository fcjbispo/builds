"""
WebScrape MCP server using factory pattern for STDIO protocol.

This module provides a web scraping server that runs with STDIO protocol:
- stdio: Standard input/output (default, Claude Desktop compatible)

Simple and reliable protocol without authentication or network requirements.
"""

import os
import sys
import logging
from typing import List

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.scrape import scrape


# Configure logging
logger = logging.getLogger(__name__)


# Define web scrape tool function
async def web_scrape(
    url: str,
    tags_to_remove: List[str] = [],
    timeout: int = 30000
) -> str:
    """
    Scrapes a webpage and extracts full content in Markdown format.
    
    Args:
        url: The URL of the webpage to scrape.
        tags_to_remove: A list of HTML tags to remove. Ex: ['/script', '/ad']. Defaults to an empty list.
        timeout: Maximum time to wait for scraping. Defaults to 30000.
        
    Returns:
        Scraped content in Markdown format
    """
    return await scrape(url, tags_to_remove=tags_to_remove, timeout=timeout)


# List of all web scrape tools
WEBSCRAPE_TOOLS = [
    web_scrape
]


def create_webscrape_server():
    """
    Create a web scrape server with STDIO protocol.
    
    Returns:
        tuple: (server_instance, transport_info)
    """
    try:
        server = MCPServerFactory.create_stdio_server(
            name="webscrape",
            tools=WEBSCRAPE_TOOLS
        )
        
        logger.info("WebScrape server created with stdio protocol")
        return server, "stdio"
        
    except Exception as e:
        logger.error(f"Failed to create webscrape server: {str(e)}")
        raise


def run_webscrape_server():
    """
    Run the web scrape server with STDIO protocol.
    
    This is the main entry point for the web scrape server.
    """
    try:
        # Create server
        server, actual_transport = create_webscrape_server()
        
        # Print startup information
        print(f"🚀 Starting FBPyServers-MCP WebScrape Server")
        print(f"   Protocol: {actual_transport}")
        print(f"   Ready for Claude Desktop integration")
        print(f"   Available Features: webpage scraping, markdown conversion")
            
        # Run server with stdio protocol
        server.run(transport="stdio")
            
    except Exception as e:
        logger.error(f"Failed to start webscrape server: {str(e)}")
        print(f"❌ Error starting webscrape server: {str(e)}")
        sys.exit(1)


# Main entry point
if __name__ == "__main__":
    run_webscrape_server()