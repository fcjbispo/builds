"""
Memory MCP server using factory pattern for STDIO protocol.

This module provides a memory server that runs with STDIO protocol:
- stdio: Standard input/output (default, Claude Desktop compatible)

Simple and reliable protocol without authentication or network requirements.
"""

import os
import sys
import logging
from typing import List, Callable

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.memory import add_memory as memory_tool_add
from fbpyservers_mcp.tools.memory import search_memories as memory_tool_search
from fbpyservers_mcp.tools.memory import get_all_memories as memory_tool_get_all
from fbpyservers_mcp.tools.memory import delete_memory as memory_tool_delete
from fbpyservers_mcp.tools.memory import get_memory as memory_tool_get


# Configure logging
logger = logging.getLogger(__name__)


# Define memory tool functions
async def memory_add(
    content: str,
    metadata: dict = None,
) -> str:
    """
    Add a new memory to the memory store.
    
    Args:
        content: The memory content to store
        metadata: Optional metadata for the memory (JSON object)
        
    Returns:
        Success message with memory ID or error message
    """
    return await memory_tool_add(content, metadata)


async def memory_search(
    query: str,
    limit: int = 5,
) -> str:
    """
    Search through stored memories using semantic search.
    
    Args:
        query: The search query
        limit: Maximum number of results to return (default: 5)
        
    Returns:
        Formatted search results or error message
    """
    return await memory_tool_search(query, limit)


async def memory_get_all(
    limit: int = 10,
) -> str:
    """
    Retrieve all memories for the current user.
    
    Args:
        limit: Maximum number of memories to return (default: 10)
        
    Returns:
        Formatted list of all memories or error message
    """
    return await memory_tool_get_all(limit)


async def memory_delete(
    memory_id: str,
) -> str:
    """
    Delete a specific memory by ID.
    
    Args:
        memory_id: The ID of the memory to delete
        
    Returns:
        Success message or error message
    """
    return await memory_tool_delete(memory_id)


async def memory_get(
    memory_id: str,
) -> str:
    """
    Get a specific memory by ID from the memory storage.
    
    Args:
        memory_id: The ID of the memory to retrieve
        
    Returns:
        Formatted memory details or error message
    """
    return await memory_tool_get(memory_id)


# List of all memory tools
MEMORY_TOOLS = [
    memory_add,
    memory_search,
    memory_get_all,
    memory_delete,
    memory_get
]


def create_memory_server():
    """
    Create a memory server with STDIO protocol.
    
    Returns:
        tuple: (server_instance, transport_info)
    """
    try:
        server = MCPServerFactory.create_stdio_server(
            name="memory",
            tools=MEMORY_TOOLS
        )
        
        logger.info("Memory server created with stdio protocol")
        return server, "stdio"
        
    except Exception as e:
        logger.error(f"Failed to create memory server: {str(e)}")
        raise


def run_memory_server():
    """
    Run the memory server with STDIO protocol.
    
    This is the main entry point for the memory server.
    """
    try:
        # Create server
        server, actual_transport = create_memory_server()
        
        # Print startup information
        print(f"🚀 Starting FBPyServers-MCP Memory Server")
        print(f"   Protocol: {actual_transport}")
        print(f"   Ready for Claude Desktop integration")
            
        # Run server with stdio protocol
        server.run(transport="stdio")
            
    except Exception as e:
        logger.error(f"Failed to start memory server: {str(e)}")
        print(f"❌ Error starting memory server: {str(e)}")
        sys.exit(1)


# Main entry point
if __name__ == "__main__":
    run_memory_server()