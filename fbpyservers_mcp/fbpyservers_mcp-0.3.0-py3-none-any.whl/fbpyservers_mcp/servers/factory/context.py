"""
Context MCP server using factory pattern for STDIO protocol.

This module provides a context server that runs with STDIO protocol:
- stdio: Standard input/output (default, Claude Desktop compatible)

Simple and reliable protocol without authentication or network requirements.
"""

import os
import sys
import logging
from typing import Optional, List, Dict, Any
import json

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.context.library import IngestorFactory, IngestorConfig
from fbpyservers_mcp.models import PromptTemplate as Prompt, Resource, StatusEnum
from sqlalchemy.orm import Session
from fbpyservers_mcp import engine


# Configure logging
logger = logging.getLogger(__name__)


def _create_factory(
    config_path: Optional[str] = None,
    user_id: Optional[str] = None,
    project: Optional[str] = None,
) -> IngestorFactory:
    """Create IngestorFactory with proper configuration from environment variables."""
    # Use environment variables as defaults, with optional overrides
    final_config_path = config_path or os.getenv(
        "FBPY_CONTEXT_CONFIG_PATH", "config.yaml"
    )
    final_user_id = user_id or os.getenv("FBPY_CONTEXT_USER_ID", "fbnet_library")
    final_project = project or os.getenv("FBPY_CONTEXT_PROJECT", "Libraries")

    config = IngestorConfig(
        config_path=final_config_path,
        user_id=final_user_id,
        project=final_project,
    )
    return IngestorFactory.from_config(config)


def _get_db_session():
    """Get database session."""
    return Session(engine)


# Define context tool functions
async def resolve_library_id(
    library_name: str,
) -> str:
    """
    Resolve library names to Context7-compatible IDs for locally ingested libraries.

    Searches through the ingested documentation to find libraries matching the given name.
    Similar to mcp_context7_resolve_library_id but operates on local documentation.

    Args:
        library_name: Name of the library to search for

    Returns:
        JSON string containing list of matching libraries with Context7-compatible IDs,
        names, descriptions, and metadata
    """
    try:
        factory = _create_factory()
        search = factory.create_search()

        # Search for the library name in ingested documentation
        results = search.query(library_name, limit=20, project=factory.config.project)

        # Process results to extract library information
        libraries = []
        seen_libraries = set()

        for result in results:
            metadata = result.get("metadata", {})
            # Extract library information from metadata
            library_info = {
                "library_id": f"/{factory.config.project.lower()}/{library_name.lower()}",
                "name": metadata.get("library_name", library_name),
                "description": metadata.get(
                    "description", f"Documentation for {library_name}"
                ),
                "source_reputation": "High",  # Since it's locally ingested
                "benchmark_score": 85.0,  # Default score for local documentation
                "versions": [metadata.get("version", "latest")],
            }

            # Avoid duplicates
            lib_key = f"{library_info['name']}_{library_info['versions'][0]}"
            if lib_key not in seen_libraries:
                seen_libraries.add(lib_key)
                libraries.append(library_info)

        # If no specific library found, create a generic entry
        if not libraries:
            libraries.append(
                {
                    "library_id": f"/{factory.config.project.lower()}/{library_name.lower()}",
                    "name": library_name,
                    "description": f"Documentation for {library_name} (locally ingested)",
                    "source_reputation": "High",
                    "benchmark_score": 85.0,
                    "versions": ["latest"],
                }
            )

        return json.dumps(
            {
                "query": library_name,
                "matches": libraries,
                "total_found": len(libraries),
            },
            indent=2,
        )

    except Exception as e:
        return f"Error resolving library ID: {str(e)}"


async def get_library_docs(
    library_id: str,
    mode: str = "code",
    page: int = 1,
    topic: Optional[str] = None,
) -> str:
    """
    Retrieve documentation and code examples for a specific library.

    Similar to mcp_context7_get_library_docs but operates on locally ingested documentation.
    Searches through the Mem0 store for documentation related to the specified library.

    Args:
        library_id: Context7-compatible library ID (format: /project/library_name)
        mode: Documentation mode - "code" for API references, "info" for conceptual guides (default: "code")
        page: Page number for pagination (default: 1)
        topic: Specific topic to focus on (e.g., "hooks", "routing", "logging")

    Returns:
        Formatted documentation with code examples, source attribution, and proper structure
    """
    try:
        factory = _create_factory()
        search = factory.create_search()

        # Extract library name from library_id
        library_name = library_id.split("/")[-1] if "/" in library_id else library_id

        # Create search query based on mode and topic
        if mode == "code":
            query = f"{library_name} API code examples"
        else:
            query = f"{library_name} documentation guide"

        if topic:
            query += f" {topic}"

        # Search for documentation
        results = search.query(query, limit=15, project=factory.config.project)

        if not results:
            return f"No documentation found for library: {library_name}"

        # Format results as documentation
        doc_sections = []

        for i, result in enumerate(results, 1):
            content = result.get("content", "")
            metadata = result.get("metadata", {})

            source = metadata.get("title", metadata.get("doc_key", f"Document {i}"))
            doc_type = metadata.get(
                "source_type", metadata.get("file_name", "Documentation")
            )

            doc_sections.append(f"### {source}\n\n")
            doc_sections.append(f"**Source:** {source}  \n")
            doc_sections.append(f"**Type:** {doc_type}  \n\n")
            doc_sections.append(content)
            doc_sections.append("\n" + "─" * 50 + "\n")

        # Add pagination info if needed
        if page > 1:
            doc_sections.insert(
                0, f"**Page {page} of documentation for {library_name}**\n\n"
            )

        return "\n".join(doc_sections)

    except Exception as e:
        return f"Error retrieving library documentation: {str(e)}"


async def context_search(
    query: str,
    limit: int = 10,
) -> str:
    """
    Perform semantic search across ingested documentation.

    Searches through all locally ingested documentation using semantic search.
    Returns structured results with scores and metadata.

    Args:
        query: Natural language search query
        limit: Maximum number of results to return (default: 10)

    Returns:
        Formatted search results with scores, sources, and content snippets
    """
    try:
        factory = _create_factory()
        search = factory.create_search()

        results = search.query(query, limit=limit, project=factory.config.project)

        if not results:
            return f"No results found for query: {query}"

        # Format results
        output = [f'## Search Results for: "{query}"\n']

        for i, result in enumerate(results, 1):
            content = result.get("content", "")
            score = result.get("score", 0.0)
            metadata = result.get("metadata", {})

            source = metadata.get("title", metadata.get("doc_key", f"Document {i}"))
            doc_type = metadata.get("source_type", metadata.get("file_name", "Unknown"))

            output.append(f"### {i}. {source}")
            output.append(f"**Score:** {score:.3f} | **Type:** {doc_type}")
            output.append(
                f"**Content:** {content[:500]}{'...' if len(content) > 500 else ''}"
            )
            output.append("")

        return "\n".join(output)

    except Exception as e:
        return f"Error performing search: {str(e)}"


async def context_get_context(
    query: str,
    max_tokens: int = 8000,
    output_format: str = "markdown",
) -> str:
    """
    Generate rich context ready for LLMs from documentation.

    Combines multiple relevant documentation snippets into a cohesive context
    suitable for prompting LLMs. Supports different output formats.

    Args:
        query: Query to generate context for
        max_tokens: Maximum approximate tokens to include (default: 8000)
        output_format: Output format - "markdown", "json", or "csv" (default: "markdown")

    Returns:
        Generated context in the specified format, ready for LLM consumption
    """
    try:
        factory = _create_factory()
        search = factory.create_search()

        context = search.get_context(
            query, project=factory.config.project, max_tokens=max_tokens
        )

        if output_format.lower() == "json":
            data = {
                "query": query,
                "context": context,
                "approx_tokens": len((context or "").split()),
                "format": "json",
            }
            return json.dumps(data, indent=2, ensure_ascii=False)

        elif output_format.lower() == "csv":
            return f'query,context,approx_tokens\n"{query}","{(context or "").replace('"', '""')}",{len((context or "").split())}'

        else:  # markdown (default)
            return f"# Context for: {query}\n\n{context or 'No context found for this query.'}"

    except Exception as e:
        return f"Error generating context: {str(e)}"


async def list_prompts(
    limit: int = 20,
    offset: int = 0,
    output_format: str = "json",
) -> str:
    """
    List approved prompts from the database.

    Only returns prompts with APPROVED status. Returns all approved prompts
    with their metadata and relationships (arguments and messages).

    Args:
        limit: Maximum number of prompts to return (default: 20)
        offset: Offset for pagination (default: 0)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of approved prompts with their metadata
    """
    try:
        with _get_db_session() as session:
            # Only return APPROVED prompts
            prompts = session.query(Prompt).filter(
                Prompt.status == StatusEnum.APPROVED
            ).offset(offset).limit(limit).all()

            if output_format.lower() == "markdown":
                output = ["# Available Prompts\n"]
                for prompt in prompts:
                    output.append(f"## {prompt.name}")
                    output.append(f"**ID:** {prompt.id}")
                    output.append(f"**Status:** {prompt.status.value}")
                    output.append(f"**Description:** {prompt.description}")
                    output.append(f"**Created:** {prompt.created_at}")
                    output.append(f"**Updated:** {prompt.updated_at}")
                    output.append("")
                return "\n".join(output)

            else:  # json
                result = []
                for prompt in prompts:
                    prompt_data = {
                        "id": prompt.id,
                        "name": prompt.name,
                        "description": prompt.description,
                        "status": prompt.status.value,
                        "created_at": prompt.created_at.isoformat() if prompt.created_at else None,
                        "updated_at": prompt.updated_at.isoformat() if prompt.updated_at else None,
                    }
                    result.append(prompt_data)

                return json.dumps({
                    "prompts": result,
                    "limit": limit,
                    "offset": offset,
                    "total": len(result),
                }, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error listing prompts: {str(e)}"


async def get_prompt(
    prompt_id: Optional[int] = None,
    name: Optional[str] = None,
    output_format: str = "json",
) -> str:
    """
    Get detailed information about a specific prompt.

    Args:
        prompt_id: ID of the prompt to retrieve
        name: Name of the prompt to retrieve
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        Detailed information about the prompt including messages and arguments
    """
    try:
        with _get_db_session() as session:
            if prompt_id:
                prompt = session.query(Prompt).filter(Prompt.id == prompt_id).first()
            elif name:
                prompt = session.query(Prompt).filter(Prompt.name == name).first()
            else:
                return "Error: Either prompt_id or name must be provided"

            if not prompt:
                return f"Prompt not found: {'ID ' + str(prompt_id) if prompt_id else 'Name ' + name}"

            if output_format.lower() == "markdown":
                output = [f"# Prompt: {prompt.name}\n"]
                output.append(f"**ID:** {prompt.id}")
                output.append(f"**Status:** {prompt.status.value}")
                output.append(f"**Description:** {prompt.description}")
                output.append(f"**Created:** {prompt.created_at}")
                output.append(f"**Updated:** {prompt.updated_at}")
                output.append("")

                # Add arguments
                if prompt.arguments:
                    output.append("## Arguments")
                    for arg in prompt.arguments:
                        output.append(f"- **{arg.name}** (Required: {'Yes' if arg.required else 'No'})")
                        output.append(f"  {arg.description}")
                        output.append(f"  Status: {arg.status.value}")
                        output.append("")

                # Add messages
                if prompt.messages:
                    output.append("## Messages")
                    for msg in prompt.messages:
                        output.append(f"- **{msg.role}** ({msg.type})")
                        output.append(f"  ```\n{msg.content}\n```")
                        output.append(f"  Status: {msg.status.value}")
                        output.append("")

                return "\n".join(output)

            else:  # json
                result = {
                    "id": prompt.id,
                    "name": prompt.name,
                    "description": prompt.description,
                    "status": prompt.status.value,
                    "created_at": prompt.created_at.isoformat() if prompt.created_at else None,
                    "updated_at": prompt.updated_at.isoformat() if prompt.updated_at else None,
                    "arguments": [],
                    "messages": [],
                }

                for arg in prompt.arguments:
                    result["arguments"].append({
                        "id": arg.id,
                        "name": arg.name,
                        "description": arg.description,
                        "required": arg.required,
                        "status": arg.status.value,
                    })

                for msg in prompt.messages:
                    result["messages"].append({
                        "id": msg.id,
                        "role": msg.role,
                        "type": msg.type,
                        "content": msg.content,
                        "status": msg.status.value,
                    })

                return json.dumps(result, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error getting prompt: {str(e)}"


async def search_prompts(
    query: str,
    limit: int = 10,
    output_format: str = "json",
) -> str:
    """
    Search approved prompts by name or description.

    Only searches within prompts with APPROVED status. Returns matching prompts
    with their metadata.

    Args:
        query: Search query (name or description)
        limit: Maximum number of results to return (default: 10)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of matching approved prompts with their metadata
    """
    try:
        with _get_db_session() as session:
            # Only search within APPROVED prompts
            prompts = session.query(Prompt).filter(
                Prompt.status == StatusEnum.APPROVED
            ).filter(
                (Prompt.name.ilike(f"%{query}%")) | (Prompt.description.ilike(f"%{query}%"))
            ).limit(limit).all()

            if output_format.lower() == "markdown":
                output = [f"# Search Results for: '{query}'\n"]
                for prompt in prompts:
                    output.append(f"## {prompt.name}")
                    output.append(f"**ID:** {prompt.id}")
                    output.append(f"**Status:** {prompt.status.value}")
                    output.append(f"**Description:** {prompt.description}")
                    output.append("")
                return "\n".join(output)

            else:  # json
                result = []
                for prompt in prompts:
                    prompt_data = {
                        "id": prompt.id,
                        "name": prompt.name,
                        "description": prompt.description,
                        "status": prompt.status.value,
                    }
                    result.append(prompt_data)

                return json.dumps({
                    "query": query,
                    "results": result,
                    "limit": limit,
                    "total": len(result),
                }, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error searching prompts: {str(e)}"


async def list_resources(
    limit: int = 20,
    offset: int = 0,
    output_format: str = "json",
) -> str:
    """
    List approved resources from the database.

    Only returns resources with APPROVED status. Returns all approved resources
    with their metadata.

    Args:
        limit: Maximum number of resources to return (default: 20)
        offset: Offset for pagination (default: 0)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of approved resources with their metadata
    """
    try:
        with _get_db_session() as session:
            # Only return APPROVED resources
            resources = session.query(Resource).filter(
                Resource.status == StatusEnum.APPROVED
            ).offset(offset).limit(limit).all()

            if output_format.lower() == "markdown":
                output = ["# Available Resources\n"]
                for resource in resources:
                    output.append(f"## {resource.name}")
                    output.append(f"**ID:** {resource.id}")
                    output.append(f"**Status:** {resource.status.value}")
                    output.append(f"**URI:** {resource.uri}")
                    output.append(f"**MIME Type:** {resource.mime_type}")
                    output.append(f"**Size:** {resource.size_bytes} bytes")
                    output.append(f"**Description:** {resource.description}")
                    output.append(f"**Created:** {resource.created_at}")
                    output.append(f"**Updated:** {resource.updated_at}")
                    output.append("")
                return "\n".join(output)

            else:  # json
                result = []
                for resource in resources:
                    resource_data = {
                        "id": resource.id,
                        "name": resource.name,
                        "uri": resource.uri,
                        "mime_type": resource.mime_type,
                        "size_bytes": resource.size_bytes,
                        "description": resource.description,
                        "status": resource.status.value,
                        "created_at": resource.created_at.isoformat() if resource.created_at else None,
                        "updated_at": resource.updated_at.isoformat() if resource.updated_at else None,
                    }
                    result.append(resource_data)

                return json.dumps({
                    "resources": result,
                    "limit": limit,
                    "offset": offset,
                    "total": len(result),
                }, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error listing resources: {str(e)}"


async def get_resource(
    resource_id: Optional[int] = None,
    name: Optional[str] = None,
    uri: Optional[str] = None,
    output_format: str = "json",
) -> str:
    """
    Get detailed information about a specific resource.

    Args:
        resource_id: ID of the resource to retrieve
        name: Name of the resource to retrieve
        uri: URI of the resource to retrieve
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        Detailed information about the resource
    """
    try:
        with _get_db_session() as session:
            if resource_id:
                resource = session.query(Resource).filter(Resource.id == resource_id).first()
            elif name:
                resource = session.query(Resource).filter(Resource.name == name).first()
            elif uri:
                resource = session.query(Resource).filter(Resource.uri == uri).first()
            else:
                return "Error: At least one of resource_id, name, or uri must be provided"

            if not resource:
                return f"Resource not found: {'ID ' + str(resource_id) if resource_id else 'Name ' + name if name else 'URI ' + uri}"

            if output_format.lower() == "markdown":
                output = [f"# Resource: {resource.name}\n"]
                output.append(f"**ID:** {resource.id}")
                output.append(f"**Status:** {resource.status.value}")
                output.append(f"**URI:** {resource.uri}")
                output.append(f"**MIME Type:** {resource.mime_type}")
                output.append(f"**Size:** {resource.size_bytes} bytes")
                output.append(f"**Description:** {resource.description}")
                output.append(f"**Created:** {resource.created_at}")
                output.append(f"**Updated:** {resource.updated_at}")
                return "\n".join(output)

            else:  # json
                result = {
                    "id": resource.id,
                    "name": resource.name,
                    "uri": resource.uri,
                    "mime_type": resource.mime_type,
                    "size_bytes": resource.size_bytes,
                    "description": resource.description,
                    "status": resource.status.value,
                    "created_at": resource.created_at.isoformat() if resource.created_at else None,
                    "updated_at": resource.updated_at.isoformat() if resource.updated_at else None,
                }
                return json.dumps(result, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error getting resource: {str(e)}"


async def search_resources(
    query: str,
    limit: int = 10,
    output_format: str = "json",
) -> str:
    """
    Search approved resources by name, description, or URI.

    Only searches within resources with APPROVED status. Returns matching resources
    with their metadata.

    Args:
        query: Search query (name, description, or URI)
        limit: Maximum number of results to return (default: 10)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of matching approved resources with their metadata
    """
    try:
        with _get_db_session() as session:
            # Only search within APPROVED resources
            resources = session.query(Resource).filter(
                Resource.status == StatusEnum.APPROVED
            ).filter(
                (Resource.name.ilike(f"%{query}%")) |
                (Resource.description.ilike(f"%{query}%")) |
                (Resource.uri.ilike(f"%{query}%"))
            ).limit(limit).all()

            if output_format.lower() == "markdown":
                output = [f"# Search Results for: '{query}'\n"]
                for resource in resources:
                    output.append(f"## {resource.name}")
                    output.append(f"**ID:** {resource.id}")
                    output.append(f"**Status:** {resource.status.value}")
                    output.append(f"**URI:** {resource.uri}")
                    output.append(f"**Description:** {resource.description}")
                    output.append("")
                return "\n".join(output)

            else:  # json
                result = []
                for resource in resources:
                    resource_data = {
                        "id": resource.id,
                        "name": resource.name,
                        "uri": resource.uri,
                        "description": resource.description,
                        "status": resource.status.value,
                    }
                    result.append(resource_data)

                return json.dumps({
                    "query": query,
                    "results": result,
                    "limit": limit,
                    "total": len(result),
                }, indent=2, ensure_ascii=False)

    except Exception as e:
        return f"Error searching resources: {str(e)}"


# List of all context tools
CONTEXT_TOOLS = [
    resolve_library_id,
    get_library_docs,
    context_search,
    context_get_context,
    list_prompts,
    get_prompt,
    search_prompts,
    list_resources,
    get_resource,
    search_resources
]


def create_context_server():
    """
    Create a context server with STDIO protocol.

    Returns:
        FastMCP: Configured server instance
    """
    try:
        server = MCPServerFactory.create_stdio_server(
            name="context",
            tools=CONTEXT_TOOLS
        )

        logger.info("Context server created with stdio protocol")
        return server

    except Exception as e:
        logger.error(f"Failed to create context server: {str(e)}")
        raise


def run_context_server():
    """
    Run the context server with STDIO protocol.

    This is the main entry point for the context server.
    """
    try:
        # Create server
        server = create_context_server()

        # Print startup information
        print(f"🚀 Starting FBPyServers-MCP Context Server")
        print(f"   Protocol: stdio")
        print(f"   Ready for Claude Desktop integration")

        # Run server with stdio protocol
        server.run(transport="stdio")

    except Exception as e:
        logger.error(f"Failed to start context server: {str(e)}")
        print(f"❌ Error starting context server: {str(e)}")
        sys.exit(1)


# Main entry point
if __name__ == "__main__":
    run_context_server()