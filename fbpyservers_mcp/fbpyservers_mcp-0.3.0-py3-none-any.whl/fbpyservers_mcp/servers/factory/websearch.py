"""
WebSearch MCP server using factory pattern for STDIO protocol.

This module provides a web search server that runs with STDIO protocol:
- stdio: Standard input/output (default, Claude Desktop compatible)

Simple and reliable protocol without authentication or network requirements.
"""

import os
import sys
import logging
from typing import List

from fbpyservers_mcp.servers.factory import MCPServerFactory
from fbpyservers_mcp.tools.search import search


# Configure logging
logger = logging.getLogger(__name__)


# Define web search tool functions
async def web_search(
    query: str,
    language: str = "auto",
    max_results: int = 10,
    sort_by: str = "score",
    safesearch: bool = False,
) -> str:
    """
    Performs a general internet search on internet web using various search mechanisms.
    
    Args:
        query: The search query.
        language: The language of the search query. Ex: 'en'. Default: 'auto'.
        max_results: The maximum number of results to return. Default: 10.
        sort_by: The sorting criterion for the results. Valid values: Any output field except 'other_info'. Default is 'score'.
        safesearch: Indicates whether the search should be safe (without explicit content). Default: False.
        
    Returns:
        Search results in formatted string
    """
    return await search(
        query,
        language=language,
        max_results=max_results,
        sort_by=sort_by,
        safesearch=safesearch
    )


# List of all web search tools
WEBSEARCH_TOOLS = [
    web_search
]


def create_websearch_server():
    """
    Create a web search server with STDIO protocol.
    
    Returns:
        tuple: (server_instance, transport_info)
    """
    try:
        server = MCPServerFactory.create_stdio_server(
            name="websearch",
            tools=WEBSEARCH_TOOLS
        )
        
        logger.info("WebSearch server created with stdio protocol")
        return server, "stdio"
        
    except Exception as e:
        logger.error(f"Failed to create websearch server: {str(e)}")
        raise


def run_websearch_server():
    """
    Run the web search server with STDIO protocol.
    
    This is the main entry point for the web search server.
    """
    try:
        # Create server
        server, actual_transport = create_websearch_server()
        
        # Print startup information
        print(f"🚀 Starting FBPyServers-MCP WebSearch Server")
        print(f"   Protocol: {actual_transport}")
        print(f"   Ready for Claude Desktop integration")
        print(f"   Available Features: web search, image search, video search, music search, map search")
            
        # Run server with stdio protocol
        server.run(transport="stdio")
            
    except Exception as e:
        logger.error(f"Failed to start websearch server: {str(e)}")
        print(f"❌ Error starting websearch server: {str(e)}")
        sys.exit(1)


# Main entry point
if __name__ == "__main__":
    run_websearch_server()