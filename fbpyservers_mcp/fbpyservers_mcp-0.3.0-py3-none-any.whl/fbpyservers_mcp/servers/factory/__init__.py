"""
Factory pattern for creating MCP servers with different protocols.

This module provides a unified factory for creating MCP servers that support
multiple transport protocols:
- stdio: Standard input/output (default)
- sse: Server-Sent Events 
- streamable-http: HTTP streaming API

Supports both authenticated and non-authenticated versions of each protocol.
"""

import os
from typing import List, Callable, Optional, Dict, Any, Type
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.config.protocols import MultipleProtocolsConfig, ProtocolConfig


class MCPServerFactory:
    """
    Factory for creating MCP servers with different protocols.
    
    Provides unified interface for creating servers with:
    - Different transport protocols (stdio, sse, http)
    - Optional authentication middleware
    - Consistent error handling and logging
    - Docker-ready configuration
    
    Example usage:
        # Create memory server with HTTP protocol
        server, transport = MCPServerFactory.create_server(
            "memory", 
            [memory_add, memory_search, memory_get_all],
            protocol="streamable-http",
            auth_enabled=True
        )
    """
    
    @staticmethod
    def create_server(
        name: str,
        tools: List[Callable],
        protocol: Optional[str] = None,
        auth_enabled: Optional[bool] = None,
        **kwargs
    ) -> tuple[FastMCP, str]:
        """
        Create an MCP server with the specified protocol.
        
        Args:
            name: Server name (e.g., "memory", "websearch")
            tools: List of tool functions to register
            protocol: Transport protocol (stdio, sse, streamable-http)
                     If None, uses FBPY_MCP_TRANSPORT environment variable
            auth_enabled: Enable authentication for HTTP protocols
                         If None, uses FBPY_MCP_AUTH_ENABLED
            **kwargs: Additional arguments passed to FastMCP constructor
            
        Returns:
            tuple[FastMCP, str]: (server_instance, transport_protocol)
            
        Raises:
            ValueError: If protocol is not supported or configuration is invalid
        """
        # Get protocol configuration
        if protocol is None:
            protocol = MultipleProtocolsConfig.get_transport()
        
        protocol_config = MultipleProtocolsConfig.get_protocol_config(protocol)
        
        # Determine authentication setting
        if auth_enabled is None:
            auth_enabled = MultipleProtocolsConfig.is_auth_enabled()
        
        # Validate auth requirements
        if protocol_config.requires_auth and not auth_enabled:
            raise ValueError(
                f"Protocol '{protocol}' requires authentication. "
                "Set auth_enabled=True or FBPY_MCP_AUTH_ENABLED=true"
            )
        
        if not protocol_config.requires_auth and auth_enabled:
            # stdio doesn't support authentication
            auth_enabled = False
        
        # Create server name with protocol suffix
        server_name = f"fbpyservers_mcp_{name}"
        if protocol != "stdio":
            server_name += f"_{protocol.replace('-', '_')}"
        if auth_enabled:
            server_name += "_auth"
        
        # Create FastMCP server
        mcp = FastMCP(server_name, **kwargs)
        
        # Register tools
        for tool in tools:
            mcp.tool()(tool)
        
        # Return server and transport info
        transport = protocol
        if auth_enabled:
            transport += "_auth"
        
        return mcp, transport
    
    @staticmethod
    def create_stdio_server(
        name: str,
        tools: List[Callable],
        **kwargs
    ) -> FastMCP:
        """
        Create an stdio MCP server (Claude Desktop compatible).
        
        Args:
            name: Server name
            tools: List of tool functions to register
            **kwargs: Additional arguments passed to FastMCP constructor
            
        Returns:
            FastMCP: Configured server instance
        """
        server, _ = MCPServerFactory.create_server(name, tools, protocol="stdio", auth_enabled=False, **kwargs)
        return server
    
    @staticmethod
    def create_sse_server(
        name: str,
        tools: List[Callable],
        auth_enabled: bool = True,
        **kwargs
    ) -> tuple[FastMCP, Dict[str, Any]]:
        """
        Create an SSE MCP server with optional authentication.
        
        Args:
            name: Server name
            tools: List of tool functions to register
            auth_enabled: Enable API Key authentication
            **kwargs: Additional arguments passed to FastMCP constructor
            
        Returns:
            tuple[FastMCP, Dict[str, Any]]: (server_instance, sse_config)
        """
        server, transport = MCPServerFactory.create_server(
            name, tools, protocol="sse", auth_enabled=auth_enabled, **kwargs
        )
        
        sse_config = MultipleProtocolsConfig.get_sse_config()
        
        return server, sse_config
    
    @staticmethod
    def create_streaming_http_server(
        name: str,
        tools: List[Callable],
        auth_enabled: bool = True,
        **kwargs
    ) -> tuple[FastMCP, Dict[str, Any]]:
        """
        Create a streaming HTTP MCP server with optional authentication.
        
        Args:
            name: Server name
            tools: List of tool functions to register
            auth_enabled: Enable API Key authentication
            **kwargs: Additional arguments passed to FastMCP constructor
            
        Returns:
            tuple[FastMCP, Dict[str, Any]]: (server_instance, http_config)
        """
        server, transport = MCPServerFactory.create_server(
            name, tools, protocol="streamable-http", auth_enabled=auth_enabled, **kwargs
        )
        
        http_config = MultipleProtocolsConfig.get_streaming_config()
        
        return server, http_config
    
    @staticmethod
    def create_authenticated_server(
        name: str,
        tools: List[Callable],
        protocol: str,
        **kwargs
    ) -> tuple[FastMCP, Dict[str, Any]]:
        """
        Create a server with mandatory authentication.
        
        Args:
            name: Server name
            tools: List of tool functions to register
            protocol: Transport protocol (must support auth)
            **kwargs: Additional arguments passed to FastMCP constructor
            
        Returns:
            tuple[FastMCP, Dict[str, Any]]: (server_instance, protocol_config)
            
        Raises:
            ValueError: If protocol doesn't support authentication
        """
        protocol_config = MultipleProtocolsConfig.get_protocol_config(protocol)
        
        if not protocol_config.requires_auth:
            raise ValueError(
                f"Protocol '{protocol}' does not support authentication"
            )
        
        # Force authentication for this method
        server, transport = MCPServerFactory.create_server(
            name, tools, protocol=protocol, auth_enabled=True, **kwargs
        )
        
        # Get protocol-specific configuration
        if protocol == "sse":
            protocol_config_dict = MultipleProtocolsConfig.get_sse_config()
        elif protocol == "streamable-http":
            protocol_config_dict = MultipleProtocolsConfig.get_streaming_config()
        else:
            raise ValueError(f"Unsupported authenticated protocol: {protocol}")
        
        return server, protocol_config_dict
    
    @staticmethod
    def get_server_variants(name: str) -> Dict[str, str]:
        """
        Get all available server variants for a given server name.
        
        Args:
            name: Base server name (e.g., "memory")
            
        Returns:
            Dict[str, str]: Mapping of variant names to server class paths
        """
        variants = {
            "stdio": f"fbpyservers_mcp.servers.{name}",
            "sse": f"fbpyservers_mcp.servers.{name}_sse",
            "http": f"fbpyservers_mcp.servers.{name}_http",
            "sse_auth": f"fbpyservers_mcp.servers.{name}_sse_auth",
            "http_auth": f"fbpyservers_mcp.servers.{name}_http_auth"
        }
        
        return variants
    
    @staticmethod
    def validate_server_config(name: str, protocol: str) -> Dict[str, Any]:
        """
        Validate configuration for a specific server and protocol.
        
        Args:
            name: Server name
            protocol: Transport protocol
            
        Returns:
            Dict[str, Any]: Validation result with config details
        """
        validation_result = {
            "server_name": name,
            "protocol": protocol,
            "valid": True,
            "errors": [],
            "warnings": [],
            "config": {}
        }
        
        try:
            # Validate protocol
            protocol_config = MultipleProtocolsConfig.get_protocol_config(protocol)
            validation_result["config"]["protocol"] = protocol_config
            
            # Get protocol-specific configuration
            if protocol == "stdio":
                config_dict = MultipleProtocolsConfig.get_stdio_config()
            elif protocol == "sse":
                config_dict = MCPServerFactory._get_sse_config_with_defaults()
            elif protocol == "streamable-http":
                config_dict = MCPServerFactory._get_http_config_with_defaults()
            else:
                raise ValueError(f"Unknown protocol: {protocol}")
            
            validation_result["config"]["protocol_specific"] = config_dict
            
            # Check auth requirements
            if protocol_config.requires_auth:
                db_url = MultipleProtocolsConfig.get_database_url()
                if not db_url:
                    validation_result["errors"].append(
                        f"Server '{name}' with protocol '{protocol}' requires database URL. "
                        "Set FBPY_MCP_DB_URL environment variable."
                    )
                    validation_result["valid"] = False
                
                if not MultipleProtocolsConfig.is_auth_enabled():
                    validation_result["warnings"].append(
                        f"Server '{name}' with protocol '{protocol}' has auth disabled. "
                        "Set FBPY_MCP_AUTH_ENABLED=true to enable."
                    )
            
            # Get server variants
            variants = MCPServerFactory.get_server_variants(name)
            validation_result["available_variants"] = variants
            
            # Check if variant exists
            auth_variant = f"{protocol}_auth" if protocol != "stdio" else "stdio"
            if auth_variant not in variants:
                validation_result["warnings"].append(
                    f"Server variant '{auth_variant}' not implemented yet"
                )
                
        except Exception as e:
            validation_result["errors"].append(f"Validation error: {str(e)}")
            validation_result["valid"] = False
        
        return validation_result
    
    @staticmethod
    def _get_sse_config_with_defaults() -> Dict[str, Any]:
        """Get SSE config with environment-specific defaults."""
        config = MultipleProtocolsConfig.get_sse_config()
        
        # Add default port mappings for different servers
        port_mappings = {
            "memory": 8050,
            "websearch": 8051,
            "webscrape": 8052,
            "context": 8053
        }
        
        # You could dynamically determine the server name here
        # For now, return the base config
        return config
    
    @staticmethod
    def _get_http_config_with_defaults() -> Dict[str, Any]:
        """Get HTTP config with environment-specific defaults."""
        config = MultipleProtocolsConfig.get_streaming_config()
        
        # Add default port mappings for different servers
        port_mappings = {
            "memory": 8000,
            "websearch": 8001,
            "webscrape": 8002,
            "context": 8003
        }
        
        # You could dynamically determine the server name here
        # For now, return the base config
        return config
    
    @staticmethod
    def list_supported_protocols() -> List[str]:
        """
        List all supported transport protocols.
        
        Returns:
            List[str]: List of supported protocol names
        """
        return list(MultipleProtocolsConfig.PROTOCOLS.keys())
    
    @staticmethod
    def get_factory_info() -> Dict[str, Any]:
        """
        Get information about the factory capabilities.
        
        Returns:
            Dict[str, Any]: Factory information and capabilities
        """
        protocols = MCPServerFactory.list_supported_protocols()
        
        return {
            "factory_name": "MCPServerFactory",
            "supported_protocols": protocols,
            "authentication_support": {
                protocol: MultipleProtocolsConfig.get_protocol_config(protocol).requires_auth
                for protocol in protocols
            },
            "environment_variables": {
                "FBPY_MCP_TRANSPORT": "Primary transport protocol",
                "FBPY_MCP_AUTH_ENABLED": "Enable authentication",
                "FBPY_MCP_DB_URL": "Database URL for auth",
                "FBPY_MCP_SSE_HOST": "SSE server host",
                "FBPY_MCP_SSE_PORT": "SSE server port",
                "FBPY_MCP_HTTP_HOST": "HTTP server host",
                "FBPY_MCP_HTTP_PORT": "HTTP server port"
            },
            "server_variants_example": {
                "memory": MCPServerFactory.get_server_variants("memory")
            }
        }


# Convenience functions for backward compatibility
def create_server(
    name: str,
    tools: List[Callable],
    protocol: Optional[str] = None,
    auth_enabled: Optional[bool] = None,
    **kwargs
) -> tuple[FastMCP, str]:
    """Create an MCP server with the specified protocol."""
    return MCPServerFactory.create_server(name, tools, protocol, auth_enabled, **kwargs)


def create_stdio_server(name: str, tools: List[Callable], **kwargs) -> FastMCP:
    """Create an stdio MCP server."""
    return MCPServerFactory.create_stdio_server(name, tools, **kwargs)


def create_sse_server(
    name: str,
    tools: List[Callable],
    auth_enabled: bool = True,
    **kwargs
) -> tuple[FastMCP, Dict[str, Any]]:
    """Create an SSE MCP server."""
    return MCPServerFactory.create_sse_server(name, tools, auth_enabled, **kwargs)


def create_streaming_http_server(
    name: str,
    tools: List[Callable],
    auth_enabled: bool = True,
    **kwargs
) -> tuple[FastMCP, Dict[str, Any]]:
    """Create a streaming HTTP MCP server."""
    return MCPServerFactory.create_streaming_http_server(name, tools, auth_enabled, **kwargs)


def validate_server_config(name: str, protocol: str) -> Dict[str, Any]:
    """Validate configuration for a specific server and protocol."""
    return MCPServerFactory.validate_server_config(name, protocol)


def list_supported_protocols() -> List[str]:
    """List all supported transport protocols."""
    return MCPServerFactory.list_supported_protocols()


def get_factory_info() -> Dict[str, Any]:
    """Get information about the factory capabilities."""
    return MCPServerFactory.get_factory_info()
