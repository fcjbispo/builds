from typing import Dict, Any, Optional
from mcp.server.fastmcp import FastMCP

from fbpyservers_mcp.servers.factory.context import (
    resolve_library_id as context_resolve_library_id,
    get_library_docs as context_get_library_docs,
    context_search as context_search_tool,
    context_get_context as context_get_context_tool,
    list_prompts as context_list_prompts,
    get_prompt as context_get_prompt,
    search_prompts as context_search_prompts,
    list_resources as context_list_resources,
    get_resource as context_get_resource,
    search_resources as context_search_resources,
)


# Initialize FastMCP server
mcp = FastMCP("fbpyservers_mcp_context")


@mcp.tool()
async def resolve_library_id(
    library_name: str,
) -> str:
    """
    Resolve library names to Context7-compatible IDs for locally ingested libraries.

    Searches through the ingested documentation to find libraries matching the given name.
    Similar to mcp_context7_resolve_library_id but operates on local documentation.

    Args:
        library_name: Name of the library to search for

    Returns:
        JSON string containing list of matching libraries with Context7-compatible IDs,
        names, descriptions, and metadata
    """
    return await context_resolve_library_id(library_name)


@mcp.tool()
async def get_library_docs(
    library_id: str,
    mode: str = "code",
    page: int = 1,
    topic: Optional[str] = None,
) -> str:
    """
    Retrieve documentation and code examples for a specific library.

    Similar to mcp_context7_get_library_docs but operates on locally ingested documentation.
    Searches through the Mem0 store for documentation related to the specified library.

    Args:
        library_id: Context7-compatible library ID (format: /project/library_name)
        mode: Documentation mode - "code" for API references, "info" for conceptual guides (default: "code")
        page: Page number for pagination (default: 1)
        topic: Specific topic to focus on (e.g., "hooks", "routing", "logging")

    Returns:
        Formatted documentation with code examples, source attribution, and proper structure
    """
    return await context_get_library_docs(library_id, mode, page, topic)


@mcp.tool()
async def context_search(
    query: str,
    limit: int = 10,
) -> str:
    """
    Perform semantic search across ingested documentation.

    Searches through all locally ingested documentation using semantic search.
    Returns structured results with scores and metadata.

    Args:
        query: Natural language search query
        limit: Maximum number of results to return (default: 10)

    Returns:
        Formatted search results with scores, sources, and content snippets
    """
    return await context_search_tool(query, limit)


@mcp.tool()
async def context_get_context(
    query: str,
    max_tokens: int = 8000,
    output_format: str = "markdown",
) -> str:
    """
    Generate rich context ready for LLMs from documentation.

    Combines multiple relevant documentation snippets into a cohesive context
    suitable for prompting LLMs. Supports different output formats.

    Args:
        query: Query to generate context for
        max_tokens: Maximum approximate tokens to include (default: 8000)
        output_format: Output format - "markdown", "json", or "csv" (default: "markdown")

    Returns:
        Generated context in the specified format, ready for LLM consumption
    """
    return await context_get_context_tool(query, max_tokens, output_format)


@mcp.tool()
async def list_prompts(
    limit: int = 20,
    offset: int = 0,
    output_format: str = "json",
) -> str:
    """
    List approved prompts from the database.

    Only returns prompts with APPROVED status. Returns all approved prompts
    with their metadata and relationships (arguments and messages).

    Args:
        limit: Maximum number of prompts to return (default: 20)
        offset: Offset for pagination (default: 0)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of approved prompts with their metadata
    """
    return await context_list_prompts(limit, offset, output_format)


@mcp.tool()
async def get_prompt(
    prompt_id: Optional[int] = None,
    name: Optional[str] = None,
    output_format: str = "json",
) -> str:
    """
    Get detailed information about a specific prompt.

    Args:
        prompt_id: ID of the prompt to retrieve
        name: Name of the prompt to retrieve
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        Detailed information about the prompt including messages and arguments
    """
    return await context_get_prompt(prompt_id, name, output_format)


@mcp.tool()
async def search_prompts(
    query: str,
    limit: int = 10,
    output_format: str = "json",
) -> str:
    """
    Search approved prompts by name or description.

    Only searches within prompts with APPROVED status. Returns matching prompts
    with their metadata.

    Args:
        query: Search query (name or description)
        limit: Maximum number of results to return (default: 10)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of matching approved prompts with their metadata
    """
    return await context_search_prompts(query, limit, output_format)


@mcp.tool()
async def list_resources(
    limit: int = 20,
    offset: int = 0,
    output_format: str = "json",
) -> str:
    """
    List approved resources from the database.

    Only returns resources with APPROVED status. Returns all approved resources
    with their metadata.

    Args:
        limit: Maximum number of resources to return (default: 20)
        offset: Offset for pagination (default: 0)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of approved resources with their metadata
    """
    return await context_list_resources(limit, offset, output_format)


@mcp.tool()
async def get_resource(
    resource_id: Optional[int] = None,
    name: Optional[str] = None,
    uri: Optional[str] = None,
    output_format: str = "json",
) -> str:
    """
    Get detailed information about a specific resource.

    Args:
        resource_id: ID of the resource to retrieve
        name: Name of the resource to retrieve
        uri: URI of the resource to retrieve
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        Detailed information about the resource
    """
    return await context_get_resource(resource_id, name, uri, output_format)


@mcp.tool()
async def search_resources(
    query: str,
    limit: int = 10,
    output_format: str = "json",
) -> str:
    """
    Search approved resources by name, description, or URI.

    Only searches within resources with APPROVED status. Returns matching resources
    with their metadata.

    Args:
        query: Search query (name, description, or URI)
        limit: Maximum number of results to return (default: 10)
        output_format: Output format - "json" or "markdown" (default: "json")

    Returns:
        List of matching approved resources with their metadata
    """
    return await context_search_resources(query, limit, output_format)


if __name__ == "__main__":
    # Initialize and run the server
    mcp.run(transport="stdio")


def main():
    """Main entry point for CLI."""
    mcp.run(transport="stdio")