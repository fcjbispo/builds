#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
FBPyServers CLI - Unified command-line interface for FBPyServers-MCP

Provides 4 main command groups:
    context  → Documentation ingestion and semantic search
    memory   → Memory management operations
    scrape   → Web scraping operations
    search   → Web search operations

Usage:
    fbpyservers-cli context ingest Libraries/fbpyutils/v1.8.0
    fbpyservers-cli memory add "user message" --user-id user1
    fbpyservers-cli scrape "https://example.com"
    fbpyservers-cli search "python tutorials"
"""

from __future__ import annotations

import os
import time
import warnings
from pathlib import Path
from typing import Literal, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TimeElapsedColumn,
)
from rich.table import Table

# Suppress all warnings from external components to keep console clean
warnings.filterwarnings("ignore")

from fbpyservers_mcp import __version__


console = Console()

# Main CLI application
app = typer.Typer(
    name="fbpyservers-cli",
    help="[bold cyan]FBPyServers CLI[/] — Unified MCP tools and utilities",
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode="rich",
)


# Version callback
def version_callback(value: bool):
    if value:
        console.print(f"[bold magenta]fbpyservers-cli v{__version__}[/]")
        console.print("[dim]FBPyServers-MCP ecosystem[/]")
        console.print("[dim]Context • Memory • Scrape • Search[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
):
    """FBPyServers CLI - Unified interface for MCP tools."""
    pass


# ==============================================================================
# CONTEXT GROUP - Documentation ingestion and semantic search
# ==============================================================================
context_app = typer.Typer(
    name="context", help="Documentation ingestion and semantic search operations"
)


def get_progress(verbose: bool = False, quiet: bool = False):
    """Returns Progress object with appropriate style for mode."""
    if quiet:
        return Progress(disable=True)
    if verbose:
        return Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            TimeElapsedColumn(),
            console=console,
        )
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(bar_width=40),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    )


def load_factory(
    config_path: Optional[str] = None,
    user_id: Optional[str] = None,
    project: Optional[str] = None,
):
    """Load config with priority: CLI/ENV > default."""
    final_cfg = config_path or "config.yaml"
    final_uid = user_id or "fbnet_library"
    final_proj = project or "Libraries"

    console.print(
        Panel(
            f"[bold green]Context MCP active[/]\n"
            f"[dim]Config:[/] {final_cfg}\n"
            f"[dim]User ID:[/] {final_uid}\n"
            f"[dim]Project:[/] {final_proj}",
            title="FBPyServers Context",
            border_style="bright_blue",
        )
    )

    from fbpyservers_mcp.tools.context.library import IngestorConfig, IngestorFactory

    config_obj = IngestorConfig(
        config_path=final_cfg,
        user_id=final_uid,
        project=final_proj,
    )
    return IngestorFactory(config_obj)


@context_app.command()
def ingest(
    folder: str = typer.Argument(
        ..., help="Root folder of library (e.g., Libraries/fbpyutils/v1.8.0)"
    ),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detailed logging"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Silent mode"),
):
    """Idempotent ingestion of technical documentation."""
    factory = load_factory(config_path, user_id, project)
    ingestor = factory.create_ingestor()

    files = list(Path(folder).rglob("*.md"))
    if not files:
        console.print("[red]No .md files found[/]")
        raise typer.Exit(1)

    with get_progress(verbose=verbose, quiet=quiet) as progress:
        task = progress.add_task("Starting ingestion...", total=len(files))

        for i, file_path in enumerate(files):
            current = file_path.name
            progress.update(
                task,
                description=f"[bold cyan]Ingesting[/] [yellow]{current}[/] ([green]{i + 1}/{len(files)}[/])",
            )

            try:
                if verbose:
                    progress.console.print(f"\n[bold cyan]→ {current}[/]")

                ingestor.ingest_file(str(file_path))

                if verbose:
                    progress.console.print("  [green]Summary + Full + Relation → OK[/]")

            except Exception as e:
                msg = f"Error in {current}: {e}"
                if not quiet:
                    progress.console.print(f"[bold red]{msg}[/]")

            progress.advance(task)
            time.sleep(factory.config.sleep_seconds)

    console.print("\n[bold green]Ingestion completed successfully![/]")


@context_app.command()
def search(
    query: str = typer.Argument(..., help="Natural language query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
):
    """Semantic search in ingested documents."""
    factory = load_factory(config_path, user_id, project)
    search = factory.create_search()

    console.print(f'[bold cyan]Searching:[/] [yellow]"{query}"[/]')
    results = search.query(query, limit=limit, project=factory.config.project)

    if not results:
        console.print("[dim]No results found[/]")
        return

    table = Table(title=f"Top {len(results)} results")
    table.add_column("Rank", style="cyan")
    table.add_column("Score")
    table.add_column("Source", style="green")
    table.add_column("Type")
    table.add_column("Excerpt")

    for i, r in enumerate(results, 1):
        metadata = r.get("metadata", {})
        source = metadata.get("title", metadata.get("doc_key", "Unknown"))
        doc_type = metadata.get("source_type", metadata.get("file_name", "Unknown"))
        table.add_row(
            str(i),
            f"{r['score']:.3f}",
            source,
            doc_type,
            r["content"][:200] + ("..." if len(r["content"]) > 200 else ""),
        )
    console.print(table)


@context_app.command()
def ingest(
    folder: str = typer.Argument(
        ..., help="Root folder of library (e.g., Libraries/fbpyutils/v1.8.0)"
    ),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detailed logging"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Silent mode"),
):
    """Process technical documentation ingestion."""
    factory = load_factory(config_path, user_id, project)
    ingestor = factory.create_ingestor()

    files = list(Path(folder).rglob("*.md"))
    if not files:
        console.print("[red]No .md files found[/]")
        raise typer.Exit(1)

    with get_progress(verbose=verbose, quiet=quiet) as progress:
        task = progress.add_task("Starting ingestion...", total=len(files))

        for i, file_path in enumerate(files):
            current = file_path.name
            progress.update(
                task,
                description=f"[bold cyan]Ingesting[/] [yellow]{current}[/] ([green]{i + 1}/{len(files)}[/])",
            )

            try:
                if verbose:
                    progress.console.print(f"\n[bold cyan]→ {current}[/]")

                ingestor.ingest_file(str(file_path))

                if verbose:
                    progress.console.print("  [green]Summary + Full + Relation → OK[/]")

            except Exception as e:
                msg = f"Error in {current}: {e}"
                if not quiet:
                    progress.console.print(f"[bold red]{msg}[/]")

            progress.advance(task)
            time.sleep(factory.config.sleep_seconds)

    console.print("\n[bold green]Ingestion completed successfully![/]")


# ==============================================================================
# MEMORY GROUP - Memory management operations
# ==============================================================================
memory_app = typer.Typer(
    name="memory", help="Memory management operations (in development)"
)


@memory_app.command()
def add(
    content: str = typer.Argument(..., help="Content to add to memory"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """Add content to memory system using mem0ai."""
    try:
        import asyncio

        # Set environment variables if provided
        if user_id:
            os.environ["FBPY_MEMORY_USER"] = user_id
        if agent:
            os.environ["FBPY_MEMORY_AGENT"] = agent
        if config_file:
            os.environ["FBPY_MEMORY_CONFIG_FILE"] = config_file

        # Import and reload memory module to pick up new env vars
        import importlib
        import fbpyservers_mcp.tools.memory

        importlib.reload(fbpyservers_mcp.tools.memory)

        from fbpyservers_mcp.tools.memory import add_memory as memory_add

        # Run async function
        result = asyncio.run(memory_add(content))
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error adding memory: {str(e)}[/]")
        raise typer.Exit(1)


@memory_app.command()
def search(
    query: str = typer.Argument(..., help="Search query for memory"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """Search memory system using mem0ai."""
    try:
        import asyncio

        # Set environment variables if provided
        if user_id:
            os.environ["FBPY_MEMORY_USER"] = user_id
        if agent:
            os.environ["FBPY_MEMORY_AGENT"] = agent
        if config_file:
            os.environ["FBPY_MEMORY_CONFIG_FILE"] = config_file

        # Import and reload memory module to pick up new env vars
        import importlib
        import fbpyservers_mcp.tools.memory

        importlib.reload(fbpyservers_mcp.tools.memory)

        from fbpyservers_mcp.tools.memory import search_memories as memory_search

        # Run async function
        result = asyncio.run(memory_search(query, limit))
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error searching memories: {str(e)}[/]")
        raise typer.Exit(1)


@memory_app.command()
def list(
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """List all memories for user using mem0ai."""
    try:
        import asyncio

        # Set environment variables if provided
        if user_id:
            os.environ["FBPY_MEMORY_USER"] = user_id
        if agent:
            os.environ["FBPY_MEMORY_AGENT"] = agent
        if config_file:
            os.environ["FBPY_MEMORY_CONFIG_FILE"] = config_file

        # Import and reload memory module to pick up new env vars
        import importlib
        import fbpyservers_mcp.tools.memory

        importlib.reload(fbpyservers_mcp.tools.memory)

        from fbpyservers_mcp.tools.memory import get_all_memories as memory_list

        # Run async function
        result = asyncio.run(memory_list(limit))
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error listing memories: {str(e)}[/]")
        raise typer.Exit(1)


@memory_app.command()
def get(
    memory_id: str = typer.Argument(..., help="Memory ID to retrieve"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """Get memory by ID using mem0ai."""
    console.print("[yellow]Memory get by ID is not implemented in mem0ai[/]")
    console.print("[dim]Use 'memory list' to see available memories[/]")


@memory_app.command()
def get_all(
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """Get all memories for user using mem0ai."""
    try:
        import asyncio

        # Set environment variables if provided
        if user_id:
            os.environ["FBPY_MEMORY_USER"] = user_id
        if agent:
            os.environ["FBPY_MEMORY_AGENT"] = agent
        if config_file:
            os.environ["FBPY_MEMORY_CONFIG_FILE"] = config_file

        # Import and reload memory module to pick up new env vars
        import importlib
        import fbpyservers_mcp.tools.memory

        importlib.reload(fbpyservers_mcp.tools.memory)

        from fbpyservers_mcp.tools.memory import get_all_memories as memory_get_all

        # Run async function
        result = asyncio.run(memory_get_all(limit))
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error getting all memories: {str(e)}[/]")
        raise typer.Exit(1)


@memory_app.command()
def delete(
    memory_id: str = typer.Argument(..., help="Memory ID to delete"),
    user_id: str = typer.Option(None, "--user", help="User ID"),
    agent: str = typer.Option(None, "--agent", help="Agent ID"),
    config_file: Optional[str] = typer.Option(
        None, "--config", help="Memory configuration YAML file"
    ),
):
    """Delete memory by ID using mem0ai."""
    try:
        import asyncio

        # Set environment variables if provided
        if user_id:
            os.environ["FBPY_MEMORY_USER"] = user_id
        if agent:
            os.environ["FBPY_MEMORY_AGENT"] = agent
        if config_file:
            os.environ["FBPY_MEMORY_CONFIG_FILE"] = config_file

        # Import and reload memory module to pick up new env vars
        import importlib
        import fbpyservers_mcp.tools.memory

        importlib.reload(fbpyservers_mcp.tools.memory)

        from fbpyservers_mcp.tools.memory import delete_memory as memory_delete

        # Run async function
        result = asyncio.run(memory_delete(memory_id))
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error deleting memory: {str(e)}[/]")
        raise typer.Exit(1)


# ==============================================================================
# SCRAPE GROUP - Web scraping operations
# ==============================================================================
scrape_app = typer.Typer(name="scrape", help="Web scraping operations (in development)")


@scrape_app.command()
def url(
    url: str = typer.Argument(..., help="URL to scrape"),
    output: Literal["markdown", "json", "text"] = typer.Option(
        "markdown", "--output", "-o", help="Output format"
    ),
    timeout: int = typer.Option(30, "--timeout", help="Request timeout in seconds"),
    tags_to_remove: Optional[str] = typer.Option(
        None, "--remove-tags", help="Comma-separated list of HTML tags to remove"
    ),
):
    """Scrape web content and convert to markdown using FireCrawl."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.scrape import scrape as firecrawl_scrape

        console.print(f"[bold cyan]Scraping:[/] [yellow]{url}[/]")

        # Parse tags to remove
        tags_list = []
        if tags_to_remove:
            tags_list = [tag.strip() for tag in tags_to_remove.split(",")]

        # Run async scrape function
        result = asyncio.run(
            firecrawl_scrape(
                url=url,
                tags_to_remove=tags_list,
                timeout=timeout * 1000,  # Convert to milliseconds
            )
        )

        if output == "markdown":
            console.print(result)
        elif output == "json":
            import json

            console.print(
                json.dumps(
                    {"url": url, "content": result}, indent=2, ensure_ascii=False
                )
            )
        else:  # text
            console.print(result)

    except Exception as e:
        console.print(f"[red]Error scraping URL: {str(e)}[/]")
        raise typer.Exit(1)


@scrape_app.command()
def batch(
    urls_file: str = typer.Argument(..., help="File containing URLs (one per line)"),
    output_dir: str = typer.Option(
        "scraped_content", "--output-dir", help="Output directory"
    ),
    format: Literal["markdown", "json"] = typer.Option(
        "markdown", "--format", help="Output format"
    ),
    timeout: int = typer.Option(30, "--timeout", help="Request timeout in seconds"),
    tags_to_remove: Optional[str] = typer.Option(
        None, "--remove-tags", help="Comma-separated list of HTML tags to remove"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detailed logging"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Silent mode"),
):
    """Batch scrape multiple URLs using FireCrawl."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.scrape import scrape_n as firecrawl_scrape_batch
        from pathlib import Path

        # Read URLs from file
        if not Path(urls_file).exists():
            console.print(f"[red]URLs file not found: {urls_file}[/]")
            raise typer.Exit(1)

        with open(urls_file, "r", encoding="utf-8") as f:
            urls = [
                line.strip() for line in f if line.strip() and not line.startswith("#")
            ]

        if not urls:
            console.print("[yellow]No URLs found in file[/]")
            return

        console.print(
            f"[bold cyan]Batch scraping[/] [yellow]{len(urls)}[/] [cyan]URLs[/]"
        )

        # Parse tags to remove
        tags_list = []
        if tags_to_remove:
            tags_list = [tag.strip() for tag in tags_to_remove.split(",")]

        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Run async batch scrape
        results = asyncio.run(
            firecrawl_scrape_batch(
                urls=urls,
                tags_to_remove=tags_list,
                timeout=timeout * 1000,  # Convert to milliseconds
                stream=False,
            )
        )

        # Process and save results
        saved_files = 0
        errors = 0

        for i, (url, result) in enumerate(zip(urls, results)):
            try:
                # Generate filename from URL
                from urllib.parse import urlparse

                parsed = urlparse(url)
                filename = parsed.netloc.replace(".", "_")
                if parsed.path and parsed.path != "/":
                    path_part = parsed.path.strip("/").replace("/", "_")
                    filename += f"_{path_part}"

                if format == "json":
                    filename += ".json"
                    file_path = output_path / filename

                    import json

                    content = {"url": url, "content": result}
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(content, f, indent=2, ensure_ascii=False)
                else:
                    filename += ".md"
                    file_path = output_path / filename

                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(f"# Scraped from: {url}\n\n")
                        f.write(result)

                saved_files += 1

                if verbose:
                    console.print(f"[green]✓[/] {filename}")
                elif not quiet:
                    console.print(f"[dim]{i + 1}/{len(urls)}:[/] {filename}")

            except Exception as e:
                errors += 1
                if not quiet:
                    console.print(f"[red]✗[/] Error saving {url}: {str(e)}")

        # Summary
        console.print("\n[bold green]Batch scraping completed![/]")
        console.print(f"[cyan]Saved:[/] {saved_files} files to {output_dir}")
        if errors > 0:
            console.print(f"[bold yellow]Errors:[/] {errors} files")

    except Exception as e:
        console.print(f"[red]Error in batch scraping: {str(e)}[/]")
        import traceback

        if verbose:
            traceback.print_exc()
        raise typer.Exit(1)


# ==============================================================================
# SEARCH GROUP - Web search operations
# ==============================================================================
search_app = typer.Typer(name="search", help="Web search operations (in development)")


@search_app.command()
def web(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    safesearch: bool = typer.Option(False, "--safe", help="Enable safe search"),
    language: str = typer.Option("auto", "--lang", help="Search language"),
    raw: bool = typer.Option(
        False, "--raw", help="Return raw JSON results instead of markdown"
    ),
):
    """Perform general web search using SearXNG."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.search import search as searxng_search

        console.print(f'[bold cyan]Searching:[/] [yellow]"{query}"[/]')

        # Run async search function
        results = asyncio.run(
            searxng_search(
                query=query,
                language=language,
                max_results=limit,
                sort_by="score",
                categories=["general"],
                safesearch=safesearch,
                raw=raw,
            )
        )

        if isinstance(results, str):
            console.print(results)
        else:
            console.print(results)

    except Exception as e:
        console.print(f"[red]Error performing web search: {str(e)}[/]")
        raise typer.Exit(1)


@search_app.command()
def images(
    query: str = typer.Argument(..., help="Image search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    safesearch: bool = typer.Option(True, "--safe", help="Enable safe search"),
    language: str = typer.Option("auto", "--lang", help="Search language"),
    raw: bool = typer.Option(
        False, "--raw", help="Return raw JSON results instead of markdown"
    ),
):
    """Search for images using SearXNG."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.search import search as searxng_search

        console.print(f'[bold cyan]Searching images:[/] [yellow]"{query}"[/]')

        results = asyncio.run(
            searxng_search(
                query=query,
                language=language,
                max_results=limit,
                sort_by="score",
                categories=["images"],
                safesearch=safesearch,
                raw=raw,
            )
        )

        if isinstance(results, str):
            console.print(results)
        else:
            console.print(results)

    except Exception as e:
        console.print(f"[red]Error searching images: {str(e)}[/]")
        raise typer.Exit(1)


@search_app.command()
def videos(
    query: str = typer.Argument(..., help="Video search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    safesearch: bool = typer.Option(True, "--safe", help="Enable safe search"),
    language: str = typer.Option("auto", "--lang", help="Search language"),
    raw: bool = typer.Option(
        False, "--raw", help="Return raw JSON results instead of markdown"
    ),
):
    """Search for videos using SearXNG."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.search import search as searxng_search

        console.print(f'[bold cyan]Searching videos:[/] [yellow]"{query}"[/]')

        results = asyncio.run(
            searxng_search(
                query=query,
                language=language,
                max_results=limit,
                sort_by="score",
                categories=["videos"],
                safesearch=safesearch,
                raw=raw,
            )
        )

        if isinstance(results, str):
            console.print(results)
        else:
            console.print(results)

    except Exception as e:
        console.print(f"[red]Error searching videos: {str(e)}[/]")
        raise typer.Exit(1)


@search_app.command()
def maps(
    query: str = typer.Argument(..., help="Map search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    language: str = typer.Option("auto", "--lang", help="Search language"),
    raw: bool = typer.Option(
        False, "--raw", help="Return raw JSON results instead of markdown"
    ),
):
    """Search for maps/locations using SearXNG."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.search import search as searxng_search

        console.print(f'[bold cyan]Searching maps:[/] [yellow]"{query}"[/]')

        results = asyncio.run(
            searxng_search(
                query=query,
                language=language,
                max_results=limit,
                sort_by="score",
                categories=["map"],
                safesearch=False,
                raw=raw,
            )
        )

        if isinstance(results, str):
            console.print(results)
        else:
            console.print(results)

    except Exception as e:
        console.print(f"[red]Error searching maps: {str(e)}[/]")
        raise typer.Exit(1)


@search_app.command()
def music(
    query: str = typer.Argument(..., help="Music search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    safesearch: bool = typer.Option(True, "--safe", help="Enable safe search"),
    language: str = typer.Option("auto", "--lang", help="Search language"),
    raw: bool = typer.Option(
        False, "--raw", help="Return raw JSON results instead of markdown"
    ),
):
    """Search for music using SearXNG."""
    try:
        import asyncio
        from fbpyservers_mcp.tools.search import search as searxng_search

        console.print(f'[bold cyan]Searching music:[/] [yellow]"{query}"[/]')

        results = asyncio.run(
            searxng_search(
                query=query,
                language=language,
                max_results=limit,
                sort_by="score",
                categories=["music"],
                safesearch=safesearch,
                raw=raw,
            )
        )

        if isinstance(results, str):
            console.print(results)
        else:
            console.print(results)

    except Exception as e:
        console.print(f"[red]Error searching music: {str(e)}[/]")
        raise typer.Exit(1)


# ==============================================================================
# CONTEXT SUBCOMMANDS - Library, Prompts, Resources
# ==============================================================================

# Library subcommand group
library_app = typer.Typer(
    name="library", help="Library discovery and documentation retrieval"
)


@library_app.command()
def resolve_id(
    library_name: str = typer.Argument(..., help="Library name to search for"),
):
    """Resolve library ID for Context7-compatible documentation."""
    console.print("[yellow]Library resolve_id command is under development[/]")
    console.print(f"[dim]Library: {library_name}[/]")


@library_app.command()
def get_docs(
    library_id: str = typer.Argument(..., help="Context7-compatible library ID"),
    mode: Literal["code", "info"] = typer.Option(
        "code", "--mode", help="Documentation mode"
    ),
    topic: Optional[str] = typer.Option(None, "--topic", help="Topic to focus on"),
):
    """Get documentation for a resolved library."""
    console.print("[yellow]Library get_docs command is under development[/]")
    console.print(f"[dim]Library ID: {library_id}[/]")
    console.print(f"[dim]Mode: {mode}[/]")


# Prompts subcommand group
prompts_context_app = typer.Typer(
    name="prompts", help="Prompt extraction and management operations"
)


@prompts_context_app.command()
def extract(
    file_path: str = typer.Argument(
        ..., help="Path to markdown file to extract prompts from"
    ),
    output: Literal["json"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
    store: bool = typer.Option(
        False, "--store", help="Store extracted prompts in database"
    ),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
):
    """Extract prompts from markdown file with JSON output."""
    try:
        from fbpyservers_mcp.tools.context.prompts import (
            extract_prompts_from_file,
            store_prompts_in_db,
        )

        result = extract_prompts_from_file(file_path)

        if store:
            # Store prompts and show statistics only
            prompts_data = result.get("prompts", [])
            if prompts_data:
                store_result = store_prompts_in_db(prompts_data)
                console.print(f"[bold green]Extracted: {len(prompts_data)} prompts[/]")
                console.print(f"[bold blue]Stored: {store_result['stored']} prompts[/]")
                if store_result["errors"] > 0:
                    console.print(
                        f"[bold yellow]Errors: {store_result['errors']} prompts[/]"
                    )
            else:
                console.print("[yellow]No prompts found to store[/]")
        else:
            # Show JSON output
            if output == "json":
                import json

                console.print(json.dumps(result, indent=2, ensure_ascii=False))
            else:
                console.print(
                    "[red]Only JSON output is supported for prompts extraction[/]"
                )

    except Exception as e:
        console.print(f"[red]Error extracting prompts: {str(e)}[/]")
        raise typer.Exit(1)


@prompts_context_app.command()
def batch(
    folder: str = typer.Argument(..., help="Local folder containing markdown files"),
    mask: str = typer.Option(
        "*",
        "--mask",
        "-m",
        help="File pattern to filter files (e.g., *.md, ANALISE_*.md)",
    ),
    output: Literal["json"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
    store: bool = typer.Option(
        False, "--store", help="Store extracted prompts in database"
    ),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", help="Search recursively"
    ),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detailed logging"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Silent mode"),
):
    """Extract prompts from multiple markdown files with JSON output."""
    try:
        # Validate local folder
        path = Path(folder)
        if not path.exists():
            console.print(f"[red]Folder not found: {folder}[/]")
            raise typer.Exit(1)

        if not path.is_dir():
            console.print(f"[red]Path is not a directory: {folder}[/]")
            raise typer.Exit(1)

        # Check if it's a local path (not URL)
        if folder.startswith(("http://", "https://")):
            console.print("[red]Only local folders are supported, not URLs[/]")
            raise typer.Exit(1)

        # Find files using mask pattern
        try:
            from fbpyutils.file import find

            console.print(
                f"[dim]Searching for files with pattern '{mask}' (recursive={recursive})[/]"
            )

            # Use fbpyutils find function
            file_paths = find(folder, mask, recurse=recursive, parallel=False)

            console.print(f"[dim]Found {len(file_paths)} files matching '{mask}'[/]")

            # Convert to Path objects and filter to only files
            files = [Path(p) for p in file_paths]
            files = [f for f in files if f.is_file()]

        except Exception as e:
            console.print(f"[red]Error searching for files: {str(e)}[/]")
            import traceback

            if verbose:
                traceback.print_exc()
            raise typer.Exit(1)

        if not files:
            console.print(f"[yellow]No files matching '{mask}' found in {folder}[/]")
            return

        console.print(f"[cyan]Found {len(files)} files matching '{mask}'[/]")

        if verbose:
            console.print(
                f"[dim]Debug: recursive={recursive}, mask='{mask}', folder='{folder}'[/]"
            )
            console.print(
                f"[dim]Files list: {files[:5]}{'...' if len(files) > 5 else ''}[/]"
            )

        # Use the batch function directly for efficiency
        from fbpyservers_mcp.tools.context.prompts import (
            extract_prompts_batch,
            store_prompts_in_db,
        )

        file_paths = [str(f) for f in files]

        if verbose:
            console.print(f"[dim]Processing {len(file_paths)} files[/]")

        # Process files one by one with simple output
        results = []
        errors = []

        for i, file_path in enumerate(file_paths):
            file_name = Path(file_path).name

            if verbose:
                console.print(
                    f"[bold cyan]Processing {file_name} ({i + 1}/{len(file_paths)})[/]"
                )

            try:
                batch_result = extract_prompts_batch([file_path])

                if batch_result:
                    if "prompts" in batch_result and batch_result["prompts"]:
                        results.extend(batch_result.get("prompts", []))

                    if "errors" in batch_result and batch_result["errors"]:
                        errors.extend(batch_result.get("errors", []))

                    if verbose:
                        console.print(
                            f"  [green]✓ Completed - {len(batch_result.get('prompts', []))} prompts[/]"
                        )
                else:
                    errors.append(
                        {"file": file_path, "error": "Batch processing returned None"}
                    )

            except Exception as e:
                msg = f"Error processing {file_name}: {str(e)}"
                if not quiet:
                    console.print(f"[bold red]✗ {msg}[/]")
                errors.append({"file": file_path, "error": msg})

        # Compile final result
        final_result = {
            "total_files": len(files),
            "successful_files": len(files) - len(errors),
            "failed_files": len(errors),
            "total_prompts": len(results),
            "prompts": results,
            "errors": errors,
        }

        if store:
            # Store prompts and show statistics only
            if results:
                store_result = store_prompts_in_db(results)
                console.print("\n[bold green]Extraction completed![/]")
                console.print(
                    f"[cyan]Read:[/] {final_result['total_prompts']} prompts from {final_result['successful_files']}/{final_result['total_files']} files"
                )
                console.print(f"[bold blue]Stored: {store_result['stored']} prompts[/]")
                if store_result["errors"] > 0:
                    console.print(
                        f"[bold yellow]Errors: {store_result['errors']} prompts[/]"
                    )
            else:
                console.print("[yellow]No prompts found to store[/]")
        else:
            # Show JSON output
            console.print("\n[bold green]Extraction completed![/]")
            console.print(
                f"[cyan]Results:[/] {final_result['successful_files']}/{final_result['total_files']} files | {final_result['total_prompts']} prompts"
            )

            if output == "json":
                import json

                console.print(json.dumps(final_result, indent=2, ensure_ascii=False))
            else:
                console.print(
                    "[red]Only JSON output is supported for batch extraction[/]"
                )

    except Exception as e:
        console.print(f"[red]Error in batch extraction: {str(e)}[/]")
        import traceback

        if verbose:
            traceback.print_exc()
        raise typer.Exit(1)


@prompts_context_app.command()
def search(
    query: str = typer.Argument(..., help="Search query for prompts"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """Search approved prompts in the database."""
    try:
        import asyncio
        
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "search_prompts",
                {
                    "query": query,
                    "limit": limit,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error searching prompts: {str(e)}[/]")
        raise typer.Exit(1)


@prompts_context_app.command()
def list(
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results"),
    offset: int = typer.Option(0, "--offset", help="Pagination offset"),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """List approved prompts in the database."""
    try:
        import asyncio
        from mcp.client import MCPClient
        
        mcp = MCPClient()
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "list_prompts",
                {
                    "limit": limit,
                    "offset": offset,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error listing prompts: {str(e)}[/]")
        raise typer.Exit(1)


# Resources subcommand group
resources_context_app = typer.Typer(
    name="resources", help="Resource extraction and management operations"
)


@resources_context_app.command()
def list(
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results"),
    offset: int = typer.Option(0, "--offset", help="Pagination offset"),
    status: Optional[str] = typer.Option(
        None, "--status", help="Filter by status (PENDING, APPROVED, DISABLED)"
    ),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """List approved resources in the database."""
    try:
        import asyncio
        from mcp.client import MCPClient
        
        mcp = MCPClient()
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "list_resources",
                {
                    "limit": limit,
                    "offset": offset,
                    "status": status,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error listing resources: {str(e)}[/]")
        raise typer.Exit(1)


@resources_context_app.command()
def get(
    resource_id: Optional[int] = typer.Argument(None, help="Resource ID to retrieve"),
    name: Optional[str] = typer.Option(None, "--name", help="Resource name to retrieve"),
    uri: Optional[str] = typer.Option(None, "--uri", help="Resource URI to retrieve"),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """Get resource by ID, name, or URI with detailed information."""
    try:
        import asyncio
        from mcp.client import MCPClient
        
        mcp = MCPClient()
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "get_resource",
                {
                    "resource_id": resource_id,
                    "name": name,
                    "uri": uri,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error getting resource: {str(e)}[/]")
        raise typer.Exit(1)


@resources_context_app.command()
def search(
    query: str = typer.Argument(..., help="Search query for resources"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """Search approved resources in the database."""
    try:
        import asyncio
        from mcp.client import MCPClient
        
        mcp = MCPClient()
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "search_resources",
                {
                    "query": query,
                    "limit": limit,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error searching resources: {str(e)}[/]")
        raise typer.Exit(1)

        if store:
            # Store resources and show statistics only
            resources_data = result.get("resources", [])
            if resources_data:
                store_result = store_resources_in_db(resources_data)
                console.print(
                    f"[bold green]Extracted: {len(resources_data)} resources[/]"
                )
                console.print(
                    f"[bold blue]Stored: {store_result['stored']} resources[/]"
                )
                if store_result["errors"] > 0:
                    console.print(
                        f"[bold yellow]Errors: {store_result['errors']} resources[/]"
                    )
            else:
                console.print("[yellow]No resources found to store[/]")
        else:
            # Show JSON output
            if output == "json":
                import json

                console.print(json.dumps(result, indent=2, ensure_ascii=False))
            else:
                console.print(
                    "[red]Only JSON output is supported for resource extraction[/]"
                )

    except Exception as e:
        console.print(f"[red]Error extracting resource: {str(e)}[/]")
        raise typer.Exit(1)


@resources_context_app.command()
def batch(
    folder: str = typer.Argument(..., help="Local folder containing files"),
    mask: str = typer.Option(
        "*", "--mask", "-m", help="File pattern to filter files (e.g., *.md, VIBE_*.md)"
    ),
    output: Literal["json"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
    store: bool = typer.Option(
        False, "--store", help="Store extracted resources in database"
    ),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", help="Search recursively"
    ),
    include_content: bool = typer.Option(
        False, "--include-content", help="Include file content preview"
    ),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detailed logging"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Silent mode"),
):
    """Extract resources from multiple files with JSON output."""
    try:
        # Validate local folder
        path = Path(folder)
        if not path.exists():
            console.print(f"[red]Folder not found: {folder}[/]")
            raise typer.Exit(1)

        if not path.is_dir():
            console.print(f"[red]Path is not a directory: {folder}[/]")
            raise typer.Exit(1)

        # Check if it's a local path (not URL)
        if folder.startswith(("http://", "https://")):
            console.print("[red]Only local folders are supported, not URLs[/]")
            raise typer.Exit(1)

        # Find files using mask pattern
        try:
            from fbpyutils.file import find

            console.print(
                f"[dim]Searching for files with pattern '{mask}' (recursive={recursive})[/]"
            )

            # Use fbpyutils find function
            file_paths = find(folder, mask, recurse=recursive, parallel=False)

            console.print(f"[dim]Found {len(file_paths)} files matching '{mask}'[/]")

            # Convert to Path objects and filter to only files
            files = [Path(p) for p in file_paths]
            files = [f for f in files if f.is_file()]

        except Exception as e:
            console.print(f"[red]Error searching for files: {str(e)}[/]")
            raise typer.Exit(1)

        if not files:
            console.print(f"[yellow]No files matching '{mask}' found in {folder}[/]")
            return

        console.print(f"[cyan]Found {len(files)} files matching '{mask}'[/]")

        # Use the batch function directly for efficiency
        from fbpyservers_mcp.tools.context.resources import (
            extract_resources_batch,
            store_resources_in_db,
        )

        file_paths = [str(f) for f in files]

        # Process files one by one with simple output
        results = []
        errors = []

        for i, file_path in enumerate(file_paths):
            file_name = Path(file_path).name

            if verbose:
                console.print(
                    f"[bold cyan]Processing {file_name} ({i + 1}/{len(file_paths)})[/]"
                )

            try:
                batch_result = extract_resources_batch([file_path])

                if batch_result and "resources" in batch_result:
                    results.extend(batch_result.get("resources", []))

                if batch_result and "errors" in batch_result:
                    errors.extend(batch_result.get("errors", []))

                if verbose:
                    console.print("  [green]✓ Completed[/]")

            except Exception as e:
                msg = f"Error processing {file_name}: {str(e)}"
                if not quiet:
                    console.print(f"[bold red]✗ {msg}[/]")
                errors.append({"file": file_path, "error": msg})

        # Compile final result
        final_result = {
            "total_files": len(files),
            "successful_files": len(files) - len(errors),
            "failed_files": len(errors),
            "total_resources": len(results),
            "resources": results,
            "errors": errors,
        }

        if store:
            # Store resources and show statistics only
            if results:
                store_result = store_resources_in_db(results)
                console.print("\n[bold green]Extraction completed![/]")
                console.print(
                    f"[cyan]Read:[/] {final_result['total_resources']} resources from {final_result['successful_files']}/{final_result['total_files']} files"
                )
                console.print(
                    f"[bold blue]Stored: {store_result['stored']} resources[/]"
                )
                if store_result["errors"] > 0:
                    console.print(
                        f"[bold yellow]Errors: {store_result['errors']} resources[/]"
                    )
            else:
                console.print("[yellow]No resources found to store[/]")
        else:
            # Show JSON output
            console.print("\n[bold green]Extraction completed![/]")
            console.print(
                f"[cyan]Results:[/] {final_result['successful_files']}/{final_result['total_files']} files | {final_result['total_resources']} resources"
            )

            if output == "json":
                import json

                console.print(json.dumps(final_result, indent=2, ensure_ascii=False))
            else:
                console.print(
                    "[red]Only JSON output is supported for batch extraction[/]"
                )

    except Exception as e:
        console.print(f"[red]Error in batch extraction: {str(e)}[/]")
        import traceback

        if verbose:
            traceback.print_exc()
        raise typer.Exit(1)


@resources_context_app.command()
def search(
    query: str = typer.Argument(..., help="Search query for resources"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    status: Optional[str] = typer.Option(
        None, "--status", help="Filter by status (PENDING, APPROVED, DISABLED)"
    ),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """Search approved resources in the database."""
    try:
        import asyncio
        
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "search_resources",
                {
                    "query": query,
                    "limit": limit,
                    "status": status,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error searching resources: {str(e)}[/]")
        raise typer.Exit(1)


@resources_context_app.command()
def get(
    resource_id: Optional[int] = typer.Argument(None, help="Resource ID to retrieve"),
    name: Optional[str] = typer.Option(None, "--name", help="Resource name to retrieve"),
    uri: Optional[str] = typer.Option(None, "--uri", help="Resource URI to retrieve"),
    output: Literal["json", "markdown"] = typer.Option(
        "json", "--output", "-o", help="Output format"
    ),
):
    """Get resource by ID, name, or URI with detailed information."""
    try:
        import asyncio
        
        result = asyncio.run(
            mcp.run_tool(
                "fbpyservers_mcp_context",
                "get_resource",
                {
                    "resource_id": resource_id,
                    "name": name,
                    "uri": uri,
                    "output_format": output,
                },
            )
        )
        console.print(result)

    except Exception as e:
        console.print(f"[red]Error getting resource: {str(e)}[/]")
        raise typer.Exit(1)


# Add subcommand groups to context_app
context_app.add_typer(library_app, name="library")
context_app.add_typer(prompts_context_app, name="prompt")
context_app.add_typer(resources_context_app, name="resource")


# Rename context command to get
@context_app.command(name="get")
def context_get(
    query: str = typer.Argument(..., help="Query to generate context"),
    output: Literal["markdown", "json", "csv"] = typer.Option(
        "markdown", "--output", "-o", help="Output format"
    ),
    max_tokens: int = typer.Option(8000, "--max-tokens", help="Maximum tokens"),
    config_path: Optional[str] = typer.Option(
        None,
        "--config",
        "-c",
        envvar="FBPY_CONTEXT_CONFIG_PATH",
        help="Configuration file",
    ),
    user_id: Optional[str] = typer.Option(
        None, "--user-id", envvar="FBPY_CONTEXT_USER_ID", help="User ID"
    ),
    project: Optional[str] = typer.Option(
        None, "--project", "-p", envvar="FBPY_CONTEXT_PROJECT", help="Project name"
    ),
):
    """Generate rich context ready for LLMs."""
    factory = load_factory(config_path, user_id, project)
    search = factory.create_search()

    console.print(
        f'[bold cyan]Context for:[/] [yellow]"{query}"[/] → [bold]{output.upper()}[/]'
    )
    ctx = search.get_context(
        query, project=factory.config.project, max_tokens=max_tokens
    )

    if output == "json":
        import json

        data = {
            "query": query,
            "context": ctx or "",
            "approx_tokens": len((ctx or "").split()),
        }
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
    elif output == "csv":
        console.print("query,context,approx_tokens")
        console.print(
            f"{query},{(ctx or '').replace(',', ' ')},{len((ctx or '').split())}"
        )
    else:
        console.print("\n" + (ctx or "No context found."))


# Add command groups to main app
app.add_typer(context_app, name="context")
app.add_typer(memory_app, name="memory")
app.add_typer(scrape_app, name="scrape")
app.add_typer(search_app, name="search")


# ==============================================================================
# Entry point
# ==============================================================================
def main():
    app()


if __name__ == "__main__":
    main()
