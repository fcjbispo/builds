"""
Resource extraction module for extracting resource data from markdown files.

This module provides functionality to extract structured resource data from markdown files
using LLM-based analysis and validation against the database schema.
Supports both local files and remote URLs.
"""

import requests
from pathlib import Path
from typing import Dict, List, Any, Optional
from sqlalchemy.orm import Session

from fbpyservers_mcp.models import Resource, StatusEnum
from fbpyservers_mcp import engine
from fbpyservers_mcp.tools.context.utils.extraction import extract_resources_content


def _fetch_content_from_source(source: str) -> Optional[str]:
    """
    Fetch content from either a local file or remote URL.

    Args:
        source: File path or remote URL

    Returns:
        Content string or None if failed
    """
    try:
        # Check if it's a remote URL
        if source.startswith(("http://", "https://")):
            response = requests.get(source, timeout=30)
            response.raise_for_status()
            return response.text
        else:
            # Handle local file
            path = Path(source)
            if path.exists() and path.is_file():
                with open(path, "r", encoding="utf-8") as f:
                    return f.read()
            else:
                return None
    except Exception:
        return None


def store_resources_in_db(resources_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Store extracted resources in the database (APPEND operation).

    Args:
        resources_data: List of extracted resource data

    Returns:
        Dict with operation statistics
    """
    if not resources_data:
        return {"stored": 0, "errors": 0, "errors_list": []}

    stored_count = 0
    error_count = 0
    errors = []

    with Session(engine) as session:
        for resource_data in resources_data:
            try:
                # Check if resource already exists by URI (more robust than name)
                existing_resource = (
                    session.query(Resource).filter_by(uri=resource_data["uri"]).first()
                )
                if existing_resource:
                    continue  # Skip if already exists

                # Create the resource
                resource = Resource(
                    name=resource_data["name"],
                    mime_type=resource_data["mime_type"],
                    size_bytes=resource_data.get("size_bytes", 0),
                    description=resource_data["description"],
                    uri=resource_data["uri"],
                    status=StatusEnum(resource_data.get("status", "PENDING")),
                )
                session.add(resource)

                stored_count += 1

            except Exception as e:
                error_count += 1
                errors.append(
                    f"Error storing resource '{resource_data.get('name', 'Unknown')}': {str(e)}"
                )

        # Commit changes
        session.commit()

    return {"stored": stored_count, "errors": error_count, "errors_list": errors}


def extract_resources_from_markdown(
    markdown_content: str, file_path: str
) -> Dict[str, Any]:
    """
    Extract resource data from markdown content using LLM analysis.

    Args:
        markdown_content: Raw markdown content
        file_path: Path to the markdown file

    Returns:
        Dictionary containing extracted resource data structured according to database schema
    """
    try:
        # Use the same LLM configuration as context library
        from fbpyservers_mcp.tools.context.library import (
            IngestorFactory,
            IngestorConfig,
        )

        # Load factory with context configuration
        config = IngestorConfig()
        factory = IngestorFactory(config)
        llm = factory.create_llm()

        # Extract data using the utility function (no hardcoded prompts)
        extracted_data = extract_resources_content(markdown_content, llm)

        # Validate against schema and clean data
        validated_data = _validate_and_clean_resource_data(extracted_data, file_path)

        # Add file path for error tracking
        if "error" not in validated_data:
            validated_data["file_path"] = file_path

        return validated_data

    except Exception as e:
        # Return error structure
        error_msg = str(e)
        if "401" in error_msg or "No cookie auth credentials" in error_msg:
            error_msg += " - Please check your Ollama Cloud API configuration"
        return {
            "error": f"Failed to extract resources: {error_msg}",
            "file_path": file_path,
            "resources": [],
        }


def _validate_and_clean_resource_data(
    data: Dict[str, Any], source_path: str
) -> Dict[str, Any]:
    """
    Validate and clean extracted resource data according to schema.

    Args:
        data: Raw extracted data
        source_path: Original source path or URL used for extraction

    Returns:
        Validated and cleaned data with proper URI construction
    """
    if "error" in data:
        return data

    cleaned_data = {"resources": []}

    # Determine the base URI scheme based on source
    if source_path.startswith(("http://", "https://")):
        base_uri = source_path.rsplit("/", 1)[0]  # Remove filename from URL
    else:
        # For local files, use file:// scheme
        import os

        abs_path = os.path.abspath(source_path)
        base_uri = f"file://{abs_path}"

    for resource_data in data.get("resources", []):
        try:
            # Clean resource name (max 256 chars)
            name = resource_data.get("name", "").strip()
            if len(name) > 256:
                name = name[:253] + "..."

            # Clean description (max 4000 chars)
            description = resource_data.get("description", "").strip()
            if len(description) > 4000:
                description = description[:3997] + "..."

            # Clean MIME type (max 256 chars)
            mime_type = resource_data.get("mime_type", "").strip()
            if len(mime_type) > 256:
                mime_type = mime_type[:253] + "..."

            # Clean and construct URI based on source type
            extracted_uri = resource_data.get("uri", "").strip()

            if source_path.startswith(("http://", "https://")):
                # For remote sources, use the extracted URI as-is
                if extracted_uri.startswith(("http://", "https://")):
                    uri = extracted_uri
                else:
                    # Handle relative URLs
                    if extracted_uri.startswith("/"):
                        # Absolute path from domain
                        from urllib.parse import urlparse

                        parsed = urlparse(source_path)
                        uri = f"{parsed.scheme}://{parsed.netloc}{extracted_uri}"
                    else:
                        # Relative path
                        uri = f"{base_uri}/{extracted_uri}"
            else:
                # For local sources, construct file:// URI
                if extracted_uri.startswith(("http://", "https://")):
                    # If extracted URI is remote, use it as-is
                    uri = extracted_uri
                else:
                    # Construct file:// URI
                    if extracted_uri.startswith("/"):
                        # Absolute path
                        uri = f"file://{extracted_uri}"
                    else:
                        # Relative path from source file directory
                        import os

                        source_dir = os.path.dirname(os.path.abspath(source_path))
                        full_path = os.path.join(source_dir, extracted_uri)
                        uri = f"file://{full_path}"

            if len(uri) > 4000:
                uri = uri[:3997] + "..."

            # Validate status
            status = resource_data.get("status", "PENDING")
            if status not in [s.value for s in StatusEnum]:
                status = "PENDING"

            # Clean size_bytes (must be non-negative integer)
            size_bytes = resource_data.get("size_bytes", 0)
            try:
                size_bytes = int(size_bytes)
                if size_bytes < 0:
                    size_bytes = 0
            except (ValueError, TypeError):
                size_bytes = 0

            cleaned_resource = {
                "name": name,
                "mime_type": mime_type,
                "size_bytes": size_bytes,
                "description": description,
                "uri": uri,
                "status": status,
            }

            # Only add if name and uri are not empty
            if name and uri:
                cleaned_data["resources"].append(cleaned_resource)

        except Exception:
            # Skip invalid resource data
            continue

    return cleaned_data


def extract_resources_from_file(source: str) -> Dict[str, Any]:
    """
    Extract resource data from a markdown file or remote URL.

    Args:
        source: Path to the markdown file or remote URL

    Returns:
        Dictionary containing extracted resource data
    """
    try:
        # Fetch content using the unified function
        content = _fetch_content_from_source(source)

        if content is None:
            return {
                "error": f"Failed to fetch content from: {source}",
                "file_path": source,
                "resources": [],
            }

        # Check if it's text content for remote URLs
        if source.startswith(("http://", "https://")):
            # Try to detect content type
            try:
                response = requests.get(source, timeout=10)
                content_type = response.headers.get("content-type", "").lower()
                if not any(
                    marker in content_type
                    for marker in ["text/", "application/json", "application/xml"]
                ):
                    return {
                        "error": f"Unsupported content type for URL: {content_type}",
                        "file_path": source,
                        "resources": [],
                    }
            except Exception:
                # Continue anyway, might still be text
                pass

        return extract_resources_from_markdown(content, source)

    except Exception as e:
        return {
            "error": f"Failed to process {source}: {str(e)}",
            "file_path": source,
            "resources": [],
        }


def extract_resources_batch(file_paths: List[str]) -> Dict[str, Any]:
    """
    Extract resource data from multiple markdown files.

    Args:
        file_paths: List of file paths to process

    Returns:
        Dictionary containing extracted resource data from all files
    """
    all_resources = []
    errors = []

    for file_path in file_paths:
        result = extract_resources_from_file(file_path)

        if "error" in result:
            errors.append({"file_path": file_path, "error": result["error"]})
        else:
            all_resources.extend(result.get("resources", []))

    return {
        "total_files": len(file_paths),
        "successful_files": len(file_paths) - len(errors),
        "failed_files": len(errors),
        "total_resources": len(all_resources),
        "resources": all_resources,
        "errors": errors,
    }
