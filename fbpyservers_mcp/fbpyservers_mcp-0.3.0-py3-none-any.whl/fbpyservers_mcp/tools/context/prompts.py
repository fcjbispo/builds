"""
Prompt extraction module for extracting prompt data from markdown files.

This module provides functionality to extract structured prompt data from markdown files
using LLM-based analysis and validation against the database schema.
Supports both local files and remote URLs.
"""

import re
import requests
from pathlib import Path
from typing import Dict, List, Any, Optional
from sqlalchemy.orm import Session

from fbpyservers_mcp.models import Prompt, PromptArgument, PromptMessage, StatusEnum
from fbpyservers_mcp import engine
from fbpyservers_mcp.tools.context.utils.extraction import extract_prompts_content


def _fetch_content_from_source(source: str) -> Optional[str]:
    """
    Fetch content from either a local file or remote URL.

    Args:
        source: File path or remote URL

    Returns:
        Content string or None if failed
    """
    try:
        # Check if it's a remote URL
        if source.startswith(("http://", "https://")):
            response = requests.get(source, timeout=30)
            response.raise_for_status()
            return response.text
        else:
            # Handle local file
            path = Path(source)
            if path.exists() and path.is_file():
                with open(path, "r", encoding="utf-8") as f:
                    return f.read()
            else:
                return None
    except Exception:
        return None


def store_prompts_in_db(prompts_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Store extracted prompts in the database (APPEND operation).

    Args:
        prompts_data: List of extracted prompt data

    Returns:
        Dict with operation statistics
    """
    if not prompts_data:
        return {"stored": 0, "errors": 0, "errors_list": []}

    stored_count = 0
    error_count = 0
    errors = []

    with Session(engine) as session:
        for prompt_data in prompts_data:
            try:
                # Check if prompt already exists by name
                existing_prompt = (
                    session.query(Prompt).filter_by(name=prompt_data["name"]).first()
                )
                if existing_prompt:
                    continue  # Skip if already exists

                # Create the prompt
                prompt = Prompt(
                    name=prompt_data["name"],
                    description=prompt_data["description"],
                    status=StatusEnum(prompt_data.get("status", "PENDING")),
                )
                session.add(prompt)
                session.flush()  # Get the prompt ID

                # Create arguments if they exist
                if "arguments" in prompt_data and prompt_data["arguments"]:
                    for arg_data in prompt_data["arguments"]:
                        argument = PromptArgument(
                            name=arg_data["name"],
                            description=arg_data["description"],
                            prompt_id=prompt.id,
                            required=arg_data.get("required", 1),
                            status=StatusEnum(arg_data.get("status", "PENDING")),
                        )
                        session.add(argument)

                # Create messages (required)
                if "messages" in prompt_data and prompt_data["messages"]:
                    for msg_data in prompt_data["messages"]:
                        message = PromptMessage(
                            role=msg_data["role"],
                            prompt_id=prompt.id,
                            type=msg_data.get("type", "text"),
                            content=msg_data["content"],
                            status=StatusEnum(msg_data.get("status", "PENDING")),
                        )
                        session.add(message)
                else:
                    raise ValueError("Prompt must have at least one message")

                stored_count += 1

            except Exception as e:
                error_count += 1
                errors.append(
                    f"Error storing prompt '{prompt_data.get('name', 'Unknown')}': {str(e)}"
                )

        # Commit changes
        session.commit()

    return {"stored": stored_count, "errors": error_count, "errors_list": errors}


def extract_prompts_from_markdown(
    markdown_content: str, file_path: str
) -> Dict[str, Any]:
    """
    Extract prompt data from markdown content using LLM analysis.

    Args:
        markdown_content: Raw markdown content
        file_path: Path to the markdown file

    Returns:
        Dictionary containing extracted prompt data structured according to database schema
    """
    try:
        # Use the same LLM configuration as context library
        from fbpyservers_mcp.tools.context.library import (
            IngestorFactory,
            IngestorConfig,
        )

        # Load factory with context configuration
        config = IngestorConfig()
        factory = IngestorFactory(config)
        llm = factory.create_llm()

        # Extract data using the utility function (no hardcoded prompts)
        extracted_data = extract_prompts_content(markdown_content, llm)

        # Validate against schema and clean data
        validated_data = _validate_and_clean_prompt_data(extracted_data)

        # Add file path for error tracking
        if "error" not in validated_data:
            if len(validated_data['prompts']) > 0:
                validated_data['prompts'][0]["description"] = \
                    f"`{validated_data['prompts'][0]['name']}`: {validated_data['prompts'][0]["description"]}"
                validated_data['prompts'][0]["name"] = Path(file_path).stem.replace(" ", "_").upper()
                validated_data['prompts'][0]["messages"] = [
                    {
                        "role": "user",
                        "type": "instruction",
                        "content": markdown_content.strip(),
                        "status": "PENDING",
                    }
                ]
            validated_data["file_path"] = file_path

        return validated_data

    except Exception as e:
        # Return error structure
        error_msg = str(e)
        if "401" in error_msg or "No cookie auth credentials" in error_msg:
            error_msg += " - Please check your Ollama Cloud API configuration"
        return {
            "error": f"Failed to extract prompts: {error_msg}",
            "file_path": file_path,
            "prompts": [],
        }


def _validate_and_clean_prompt_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate and clean extracted prompt data according to schema.

    Args:
        data: Raw extracted data

    Returns:
        Validated and cleaned data
    """
    if "error" in data:
        return data

    cleaned_data = {"prompts": []}

    for prompt_data in data.get("prompts", []):
        try:
            # Clean prompt name (snake_case, uppercase, max 5 words)
            name = prompt_data.get("name", "").strip()
            name = re.sub(r"[^A-Z0-9_]", "_", name.upper())
            name = re.sub(r"_+", "_", name).strip("_")
            words = name.split("_")[:5]  # Max 5 words
            name = "_".join(words)

            # Clean description (max 4000 chars)
            description = prompt_data.get("description", "").strip()
            if len(description) > 4000:
                description = description[:3997] + "..."

            # Validate status
            status = prompt_data.get("status", "PENDING")
            if status not in [s.value for s in StatusEnum]:
                status = "PENDING"

            # Clean arguments
            cleaned_arguments = []
            for arg in prompt_data.get("arguments", []):
                arg_name = arg.get("name", "").strip().upper()
                arg_name = re.sub(r"[^A-Z0-9_]", "_", arg_name)
                arg_name = re.sub(r"_+", "_", arg_name).strip("_")

                arg_desc = arg.get("description", "").strip()
                if len(arg_desc) > 4000:
                    arg_desc = arg_desc[:3997] + "..."

                required = 1 if arg.get("required", True) else 0
                arg_status = arg.get("status", "PENDING")
                if arg_status not in [s.value for s in StatusEnum]:
                    arg_status = "PENDING"

                cleaned_arguments.append(
                    {
                        "name": arg_name,
                        "description": arg_desc,
                        "required": required,
                        "status": arg_status,
                    }
                )

            # Clean messages
            cleaned_messages = []
            for msg in prompt_data.get("messages", []):
                role = msg.get("role", "user")
                if role not in ["system", "user", "assistant"]:
                    role = "user"

                msg_type = msg.get("type", "instruction")
                if msg_type not in ["instruction", "example", "template", "constraint"]:
                    msg_type = "instruction"

                content = msg.get("content", "").strip()
                if len(content) > 4000:
                    content = content[:3997] + "..."

                msg_status = msg.get("status", "PENDING")
                if msg_status not in [s.value for s in StatusEnum]:
                    msg_status = "PENDING"

                cleaned_messages.append(
                    {
                        "role": role,
                        "type": msg_type,
                        "content": content,
                        "status": msg_status,
                    }
                )

            cleaned_prompt = {
                "name": name,
                "description": description,
                "status": status,
                "arguments": cleaned_arguments,
                "messages": cleaned_messages,
            }

            # Only add if name is not empty
            if name:
                cleaned_data["prompts"].append(cleaned_prompt)

        except Exception:
            # Skip invalid prompt data
            continue

    return cleaned_data


def extract_prompts_from_file(source: str) -> Dict[str, Any]:
    """
    Extract prompt data from a markdown file or remote URL.

    Args:
        source: Path to the markdown file or remote URL

    Returns:
        Dictionary containing extracted prompt data
    """
    try:
        # Fetch content using the unified function
        content = _fetch_content_from_source(source)

        if content is None:
            return {
                "error": f"Failed to fetch content from: {source}",
                "file_path": source,
                "prompts": [],
            }

        # Check if it's text content for remote URLs
        if source.startswith(("http://", "https://")):
            # Try to detect content type
            try:
                response = requests.get(source, timeout=10)
                content_type = response.headers.get("content-type", "").lower()
                if not any(
                    marker in content_type
                    for marker in ["text/", "application/json", "application/xml"]
                ):
                    return {
                        "error": f"Unsupported content type for URL: {content_type}",
                        "file_path": source,
                        "prompts": [],
                    }
            except Exception:
                # Continue anyway, might still be text
                pass

        return extract_prompts_from_markdown(content, source)

    except Exception as e:
        return {
            "error": f"Failed to process {source}: {str(e)}",
            "file_path": source,
            "prompts": [],
        }


def extract_prompts_batch(file_paths: List[str]) -> Dict[str, Any]:
    """
    Extract prompt data from multiple markdown files.

    Args:
        file_paths: List of file paths to process

    Returns:
        Dictionary containing extracted prompt data from all files
    """
    all_prompts = []
    errors = []

    for file_path in file_paths:
        result = extract_prompts_from_file(file_path)

        if "error" in result:
            errors.append({"file_path": file_path, "error": result["error"]})
        else:
            all_prompts.extend(result.get("prompts", []))

    return {
        "total_files": len(file_paths),
        "successful_files": len(file_paths) - len(errors),
        "failed_files": len(errors),
        "total_prompts": len(all_prompts),
        "prompts": all_prompts,
        "errors": errors,
    }
