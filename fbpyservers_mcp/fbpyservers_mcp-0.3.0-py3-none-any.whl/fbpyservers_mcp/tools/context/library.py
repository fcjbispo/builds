#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
FBPY_CONTEXT_ingest
==========

Biblioteca profissional para ingestão idempotente, segura e performática de documentação técnica no Mem0.

Funcionalidades principais:
    • Extração automática de metadados a partir de caminhos de arquivos
    • Geração de resumos estruturados em JSON via LLM
    • Inserção no Mem0 com limpeza total (vector + graph store)
    • Busca semântica e geração de contexto estilo Context7/MCP
    • Totalmente idempotente, testável e extensível

Princípios aplicados:
    • SOLID completo
    • Dependency Inversion via fábrica central
    • Zero prints — tudo via logging ou retorno
    • Configuração via arquivo YAML ou variáveis de ambiente

Exemplo de uso:
    >>> from FBPY_CONTEXT_ingest import IngestorFactory
    >>> factory = IngestorFactory.from_config()
    >>> ingestor = factory.create_ingestor()
    >>> ingestor.ingest_folder("Libraries/fbpyutils/v1.8.0")
    >>> search = factory.create_search()
    >>> print(search.get_context("como usar get_logger"))
"""

from __future__ import annotations

import os
import time
import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import yaml
from mem0 import Memory
from neo4j import GraphDatabase

from fbpyservers_mcp.tools.utils import LLMClient, OpenAILLM
from fbpyservers_mcp.tools.context.utils.extraction import summarize_content


# Suppress all warnings from external components
warnings.filterwarnings("ignore")


# --------------------------------------------------------------------------- #
# Configuração
# --------------------------------------------------------------------------- #
@dataclass
class IngestorConfig:
    """
    Configuração centralizada do ingestor.

    Pode ser carregada de arquivo YAML ou sobrescrita via variáveis de ambiente.

    Attributes:
        config_path: Caminho para o arquivo de configuração (padrão: config.yaml)
        user_id: ID do usuário no Mem0 (padrão: fbnet_library)
        project: Nome do projeto para filtro de busca (padrão: Libraries)
        sleep_seconds: Pausa entre inserções para evitar rate-limit (padrão: 1.0s)
    """

    config_path: str = os.getenv("FBPY_CONTEXT_CONFIG_PATH", "config.yaml")
    user_id: str = os.getenv("FBPY_CONTEXT_USER_ID", "fbnet_library")
    project: str = os.getenv("FBPY_CONTEXT_PROJECT", "Libraries")
    sleep_seconds: float = float(os.getenv("FBPY_CONTEXT_INGEST_SLEEP", "1.0"))

    def load(self) -> Dict[str, Any]:
        """Carrega e retorna o conteúdo do arquivo de configuração YAML."""
        with open(self.config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)


class DocumentCleaner(ABC):
    """Interface para limpeza de documentos no Mem0 (vector + graph)."""

    @abstractmethod
    def clean_document(self, doc_key: str) -> None:
        """
        Remove completamente um documento do Mem0.

        Remove:
          • Memórias do vector store (Qdrant)
          • Nós e relações do graph store (Neo4j)

        Args:
            doc_key: Chave única no formato "lib/version/arquivo.md"
        """
        pass


class Mem0GraphCleaner(DocumentCleaner):
    """Limpeza completa de documentos no Mem0 (vector + Neo4j)."""

    def __init__(self, memory: Memory, driver):
        self.memory = memory
        self.driver = driver

    def clean_document(self, doc_key: str) -> None:
        """Implementa DocumentCleaner.clean_document."""
        # Vector store
        for src in ["summary", "full"]:
            try:
                hits = self.memory.search(
                    query="*",
                    user_id=self.memory.config.user_id or "default",
                    filters={"doc_key": doc_key, "source_type": src},
                    limit=200,
                )
                for hit in hits.get("results", []):
                    if hit_id := hit.get("id"):
                        self.memory.delete(hit_id)
            except Exception:
                pass

        # Graph store
        with self.driver.session() as session:
            session.run(
                """
                OPTIONAL MATCH (m:Memory {doc_key: $doc_key})
                DETACH DELETE m
                """,
                doc_key=doc_key,
            )


# --------------------------------------------------------------------------- #
# Fábrica central
# --------------------------------------------------------------------------- #
class IngestorFactory:
    """Fábrica única para todas as dependências do ingestor."""

    @staticmethod
    def from_config(config: Optional[IngestorConfig] = None) -> "IngestorFactory":
        """Cria fábrica a partir de configuração."""
        return IngestorFactory(config or IngestorConfig())

    def __init__(self, config: IngestorConfig):
        self.config = config
        self._full_config = None
        self._memory = None
        self._driver = None

    @property
    def full_config(self) -> Dict[str, Any]:
        if self._full_config is None:
            self._full_config = self.config.load()
        return self._full_config

    @property
    def memory(self) -> Memory:
        if self._memory is None:
            cfg = self.full_config
            self._memory = Memory.from_config(cfg)
        return self._memory

    @property
    def neo4j_driver(self):
        if self._driver is None:
            gcfg = self.full_config["graph_store"]["config"]
            uri = gcfg["url"].replace("neo4j://", "bolt://")
            self._driver = GraphDatabase.driver(
                uri,
                auth=(gcfg["username"], gcfg["password"]),
                database=gcfg.get("database", "neo4j"),
            )
        return self._driver

    def create_llm(self) -> LLMClient:
        llm_cfg = self.full_config["llm"]["config"]
        provider = self.full_config["llm"]["provider"]
        base = llm_cfg.get(f"{provider}_base_url", "")
        base = base if base.endswith("/v1") else f"{base}/v1"
        return OpenAILLM(
            base_url=base, api_key=llm_cfg["api_key"], model=llm_cfg["model"]
        )

    def create_cleaner(self) -> DocumentCleaner:
        return Mem0GraphCleaner(self.memory, self.neo4j_driver)

    def create_ingestor(self) -> "DocumentationIngestor":
        return DocumentationIngestor(
            config=self.config,
            llm_client=self.create_llm(),
            cleaner=self.create_cleaner(),
            memory=self.memory,
        )

    def create_search(self) -> "Mem0Search":
        return Mem0Search(self.memory, self.config.user_id)


# --------------------------------------------------------------------------- #
# Ingestor e busca (com docstrings completas)
# --------------------------------------------------------------------------- #
class DocumentationIngestor:
    """
    Orquestra a ingestão completa de documentação no Mem0.

    Responsabilidade única: coordenar limpeza, resumo e inserção.
    """

    def __init__(
        self,
        config: IngestorConfig,
        llm_client: LLMClient,
        cleaner: DocumentCleaner,
        memory: Memory,
    ):
        self.config = config
        self.llm = llm_client
        self.cleaner = cleaner
        self.memory = memory

    def ingest_file(self, file_path: str) -> Dict[str, Any]:
        """
        Ingestão completa e idempotente de um único arquivo .md.

        Args:
            file_path: Caminho absoluto do arquivo Markdown

        Returns:
            Dict com resultados da ingestão
        """
        import logging

        logger = logging.getLogger("DocumentationIngestor")
        if not logger.handlers:
            logger.setLevel(logging.INFO)
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s %(message)s"
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        try:
            # Carregar conteúdo do arquivo
            with open(file_path, "r", encoding="utf-8") as f:
                context = f.read()

            if not context.strip():
                raise ValueError("Arquivo markdown vazio")

            # Extrair metadados
            metadata = self.extract_metadata_from_path(file_path)
            doc_key = f"{metadata['library_name']}/{metadata['version_clean']}/{metadata['file_name']}"

            # Limpar documento existente se overwrite=True
            self.cleaner.clean_document(doc_key)

            # Gerar resumo via LLM usando função utilitária
            summary_data = summarize_content(context, self.llm)

            # Criar texto do resumo
            summary_text = (
                f"# {summary_data['title']}\n\n"
                f"{summary_data.get('summary', summary_data.get('one_sentence_summary', ''))}\n\n"
                f"## Características principais\n"
                f"{chr(10).join('- ' + f for f in summary_data.get('key_features', []))}\n\n"
                f"## Funções/Classes principais\n"
                f"{', '.join(summary_data.get('main_classes_functions', []) or ['N/A'])}\n\n"
                f"## Tags\n"
                f"{', '.join(summary_data.get('tags', []))}\n"
            ).strip()

            # Adicionar resumo ao Mem0
            sum_resp = self.memory.add(
                summary_text,
                user_id=self.config.user_id,
                metadata={
                    **metadata,
                    "source_type": "summary",
                    "doc_key": doc_key,
                    **summary_data,
                },
                infer=False,
            )
            summary_id = sum_resp["results"][0]["id"]
            logger.info(f"Resumo inserido → {summary_id}")

            # Adicionar conteúdo completo ao Mem0
            full_resp = self.memory.add(
                context,
                user_id=self.config.user_id,
                metadata={
                    **metadata,
                    "source_type": "full",
                    "doc_key": doc_key,
                    "summary_id": summary_id,
                },
                infer=False,
            )
            full_id = full_resp["results"][0]["id"]
            logger.info(f"Conteúdo completo inserido → {full_id}")

            # Adicionar relação de resumo
            self.memory.add(
                f"SUMMARY_OF: {summary_id} resume o documento completo {full_id}",
                user_id=self.config.user_id,
                metadata={
                    "relationship": "SUMMARY_OF",
                    "from_entity_id": summary_id,
                    "to_entity_id": full_id,
                    "project": self.config.project,
                    "doc_key": doc_key,
                },
                infer=False,
            )
            logger.info("Relação SUMMARY_OF criada")

            # Pausa entre operações
            time.sleep(self.config.sleep_seconds)

            return {
                "doc_key": doc_key,
                "summary_id": summary_id,
                "full_id": full_id,
                "metadata": metadata,
            }

        except Exception as e:
            logger.error(f"Erro na ingestão de {file_path}: {str(e)}")
            raise

    def ingest_folder(self, folder: str, pattern: str = "*.md") -> List[Dict[str, Any]]:
        """
        Ingestão recursiva de todos os arquivos Markdown em uma pasta.

        Args:
            folder: Pasta raiz (ex: Libraries/fbpyutils/v1.8.0)
            pattern: Máscara glob (padrão: *.md)

        Returns:
            Lista de resultados da ingestão
        """
        import glob
        import logging

        logger = logging.getLogger("DocumentationIngestor")
        if not logger.handlers:
            logger.setLevel(logging.INFO)
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s %(message)s"
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        # Buscar arquivos .md na pasta
        files = glob.glob(f"{folder}/**/{pattern}", recursive=True)
        results = []

        for file_path in files:
            try:
                result = self.ingest_file(file_path)
                results.append(result)
            except Exception as e:
                logger.error(f"Erro ao processar {file_path}: {e}")

        logger.info(
            f"Ingestão concluída: {len(results)} arquivos processados com sucesso"
        )
        return results


class Mem0Search:
    """
    Cliente de busca semântica no Mem0 — estilo Context7/MCP.

    Fornece:
        • query(): busca estruturada com score
        • get_context(): contexto concatenado pronto pro LLM
    """

    def __init__(self, memory: Memory, user_id: str):
        self.memory = memory
        self.user_id = user_id

    def query(
        self, query: str, limit: int = 10, project: str = "Libraries"
    ) -> List[Dict[str, Any]]:
        """
        Realiza busca semântica no Mem0.

        Returns:
            Lista de resultados com conteúdo, score e metadados
        """
        try:
            search_results = self.memory.search(
                query=query, user_id=self.user_id, limit=limit
            )

            formatted_results = []
            results = search_results.get("results", [])

            for result in results:
                if isinstance(result, dict):
                    formatted_results.append(
                        {
                            "content": result.get("memory", ""),
                            "score": result.get("score", 0.0),
                            "metadata": result.get("metadata", {}),
                        }
                    )
                elif isinstance(result, str):
                    formatted_results.append(
                        {"content": result, "score": 0.0, "metadata": {}}
                    )

            return formatted_results
        except Exception as e:
            print(f"Erro na busca: {str(e)}")
            return []

    def get_context(
        self, query: str, project: str = "Libraries", max_tokens: int = 8000
    ) -> str:
        """
        Gera contexto rico para prompt do LLM.

        Args:
            query: Consulta em linguagem natural
            project: Filtro por projeto
            max_tokens: Limite aproximado de tokens

        Returns:
            String formatada com separadores e fontes
        """
        try:
            results = self.query(query, limit=10, project=project)

            if not results:
                return "Nenhum contexto encontrado para esta consulta."

            context_parts = []
            total_tokens = 0

            for i, result in enumerate(results, 1):
                content = result.get("content", "")
                if content:
                    # Rough token estimation (1 token ≈ 4 characters)
                    estimated_tokens = len(content) // 4
                    if total_tokens + estimated_tokens > max_tokens:
                        break

                    context_parts.append(f"=== Resultado {i} ===")
                    context_parts.append(content)
                    context_parts.append("")
                    total_tokens += estimated_tokens

            return "\n".join(context_parts)
        except Exception as e:
            return f"Erro ao gerar contexto: {str(e)}"


# --------------------------------------------------------------------------- #
# Extração de metadados
# --------------------------------------------------------------------------- #
class MetadataExtractor:
    """Extrai metadados estruturados a partir do caminho do arquivo."""

    @staticmethod
    def from_path(file_path: str) -> Dict[str, Any]:
        """
        Extrai metadados ricos do caminho do arquivo.

        Exemplo:
            /home/user/Dev/Contextspyutils/v1/Libraries/fb.8.0/fbpyutils/calendar.md
            → {"library_name": "fbpyutils", "version_clean": "1.8.0", ...}

        Args:
            file_path: Caminho absoluto do arquivo

        Returns:
            Dicionário com metadados padronizados
        """
        from pathlib import Path
        from datetime import datetime, timezone

        path = Path(file_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")

        try:
            libraries_idx = path.parts.index("Libraries")
        except ValueError:
            raise ValueError("O caminho não contém a pasta 'Libraries'")

        rel_parts = path.parts[libraries_idx + 1 :]
        library_name = rel_parts[0]
        version = (
            rel_parts[1]
            if len(rel_parts) > 1 and rel_parts[1].startswith("v")
            else None
        )

        if len(rel_parts) > 2:
            inner = list(rel_parts[2:])
            relative_inside = "/".join(inner)
        else:
            inner = []
            relative_inside = ""

        file_stem = path.stem
        if file_stem == library_name:
            title = f"{library_name} - Documentação Principal"
        else:
            pretty = file_stem.replace("_", " ").replace("-", " ")
            title = " ".join(w.capitalize() for w in pretty.split())

        return {
            "project": "Libraries",
            "library_name": library_name,
            "version": version,
            "version_clean": version[1:]
            if version and version.startswith("v")
            else version,
            "file_path": str(path),
            "file_name": path.name,
            "file_stem": file_stem,
            "relative_path": f"Libraries/{library_name}/{version}/{relative_inside}".rstrip(
                "/"
            ),
            "relative_path_inside_version": relative_inside,
            "suggested_title": title,
            "file_size_bytes": path.stat().st_size,
            "last_modified_iso": datetime.fromtimestamp(
                path.stat().st_mtime, tz=timezone.utc
            ).isoformat(),
        }
