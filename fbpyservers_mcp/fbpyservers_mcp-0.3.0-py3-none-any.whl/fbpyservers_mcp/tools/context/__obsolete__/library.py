import os
import json
import yaml
import time
import random
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from mem0 import Memory
from openai import OpenAI
from neo4j import GraphDatabase

try:
    from fbpyutils.file import find
except Exception:
    find = None


class Config:
    def __init__(
        self,
        config_path: Optional[str] = None,
        vector_store: Optional[Dict[str, Any]] = None,
        graph_store: Optional[Dict[str, Any]] = None,
        embedder: Optional[Dict[str, Any]] = None,
        llm: Optional[Dict[str, Any]] = None,
        default_sleep_time: float = 2.0,
        user_id: str = "fbnet_library",
        project: str = "Libraries",
    ):
        self.config_path = config_path
        self.vector_store = vector_store or {}
        self.graph_store = graph_store or {}
        self.embedder = embedder or {}
        self.llm = llm or {}
        self.default_sleep_time = default_sleep_time
        self.user_id = user_id
        self.project = project

    @staticmethod
    def from_path(
        config_path: str,
        default_sleep_time: float = 2.0,
        user_id: str = "fbnet_library",
        project: str = "Libraries",
    ) -> "Config":
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return Config(
            config_path=config_path,
            vector_store=data.get("vector_store", {}),
            graph_store=data.get("graph_store", {}),
            embedder=data.get("embedder", {}),
            llm=data.get("llm", {}),
            default_sleep_time=default_sleep_time,
            user_id=user_id,
            project=project,
        )

    @staticmethod
    def from_env(
        default_sleep_time: float = 2.0,
        user_id: str = "fbnet_library",
        project: str = "Libraries",
    ) -> "Config":
        def _dict_from_env(prefix: str) -> Dict[str, Any]:
            result: Dict[str, Any] = {}
            for k, v in os.environ.items():
                if k.startswith(prefix + "__"):
                    key = k[len(prefix) + 2 :]
                    try:
                        if v.lower() in ("true", "false"):
                            result[key] = v.lower() == "true"
                        elif v.isdigit():
                            result[key] = int(v)
                        elif _is_float(v):
                            result[key] = float(v)
                        else:
                            result[key] = v
                    except Exception:
                        result[key] = v
            return result

        def _is_float(x: str) -> bool:
            try:
                float(x)
                return True
            except Exception:
                return False

        provider = os.getenv("LLM__PROVIDER", "openai")
        base_url = os.getenv(f"LLM__{provider.upper()}__BASE_URL") or os.getenv(
            "OPENAI_BASE_URL"
        )
        api_key = os.getenv("LLM__CONFIG__API_KEY") or os.getenv("OPENAI_API_KEY")
        model = os.getenv("LLM__CONFIG__MODEL") or os.getenv(
            "OPENAI_MODEL", "gpt-4o-mini"
        )
        vector_store = _dict_from_env("VECTOR_STORE")
        graph_store = _dict_from_env("GRAPH_STORE")
        embedder = _dict_from_env("EMBEDDER")

        neo4j_url = (
            os.getenv("NEO4J_URL") or os.getenv("GRAPH_STORE__CONFIG__URL") or ""
        )
        neo4j_user = (
            os.getenv("NEO4J_USER") or os.getenv("GRAPH_STORE__CONFIG__USERNAME") or ""
        )
        neo4j_password = (
            os.getenv("NEO4J_PASSWORD")
            or os.getenv("GRAPH_STORE__CONFIG__PASSWORD")
            or ""
        )
        neo4j_database = (
            os.getenv("NEO4J_DATABASE")
            or os.getenv("GRAPH_STORE__CONFIG__DATABASE")
            or "neo4j"
        )
        if neo4j_url and "neo4j://" in neo4j_url:
            graph_store.setdefault("config", {})
            graph_store["config"]["url"] = neo4j_url
            graph_store["config"]["username"] = neo4j_user
            graph_store["config"]["password"] = neo4j_password
            graph_store["config"]["database"] = neo4j_database

        llm_config = {"provider": provider, "config": {"model": model}}
        if base_url:
            llm_config["config"][f"{provider}_base_url"] = base_url
        if api_key:
            llm_config["config"]["api_key"] = api_key

        return Config(
            vector_store=vector_store,
            graph_store=graph_store,
            embedder=embedder,
            llm=llm_config,
            default_sleep_time=default_sleep_time,
            user_id=user_id,
            project=project,
        )


class IngestionEngine:
    SUMMARY_PROMPT_TEMPLATE = """Você é um especialista em documentação de bibliotecas de software.

Sua tarefa é gerar um resumo estruturado em JSON da documentação Markdown abaixo.

REGRAS OBRIGATÓRIAS:
- Responda SOMENTE com JSON válido
- Comece diretamente com { e termine com }
- NUNCA use ```json, texto antes/depois, <think>, quebras de linha no início
- Se não souber um campo → use "" ou []

Estrutura exata obrigatória:

{
  "title": "Título curto e descritivo (máx 80 caracteres)",
  "one_sentence_summary": "Uma única frase resumindo o propósito principal",
  "purpose": "Para que serve essa biblioteca/módulo (1-2 frases)",
  "key_features": ["feature 1", "feature 2", "feature 3"],
  "main_classes_functions": ["ClassePrincipal", "função_importante()"],
  "important_parameters_or_configs": ["param: descrição curta"],
  "usage_example_summary": "Como tipicamente se usa (curto)",
  "supported_languages_or_backends": ["Python", "Async"],
  "dependencies": ["pacote>=1.0", "outro"],
  "tags": ["python", "utils", "cli", "datetime"],
  "complexity_level": "iniciante | intermediário | avançado",
  "last_updated_hint": "2025" ou vazio se não houver
}

Documento Markdown para resumir:

<<<CONTENT>>>
"""

    def __init__(self, config: Config):
        self.config = config
        self.logger = self._setup_logger()
        self.memory = self._init_memory()
        self.openai_client = self._init_openai_client()
        self.driver = self._init_neo4j_driver()

    def _setup_logger(self) -> logging.Logger:
        logger = logging.getLogger("mem0_ingestion")
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.FileHandler("mem0_ingestion.log", encoding="utf-8")
            formatter = logging.Formatter(
                fmt="%(asctime)s %(levelname)s %(name)s %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    def _init_memory(self) -> Memory:
        mem0_config = {
            "vector_store": self.config.vector_store,
            "graph_store": self.config.graph_store,
            "embedder": self.config.embedder,
            "llm": self.config.llm,
        }
        memory = Memory.from_config(mem0_config)
        self.logger.info("Mem0 initialized")
        return memory

    def _init_openai_client(self) -> Optional[OpenAI]:
        provider = self.config.llm.get("provider", "openai")
        cfg = self.config.llm.get("config", {})
        base_url = cfg.get(f"{provider}_base_url")
        api_key = cfg.get("api_key")
        model_name = cfg.get("model", "gpt-4o-mini")
        if not base_url or not api_key:
            self.logger.warning(
                "OpenAI base_url or api_key missing; LLM calls will fail."
            )
            return None
        openai_base_url = f"{base_url}/v1" if not base_url.endswith("/v1") else base_url
        client = OpenAI(base_url=openai_base_url, api_key=api_key)
        self.logger.info(f"OpenAI client ready → {model_name}")
        return client

    def _init_neo4j_driver(self) -> Optional[GraphDatabase.driver]:
        gcfg = self.config.graph_store.get("config", {})
        uri = gcfg.get("url")
        user = gcfg.get("username")
        password = gcfg.get("password")
        database = gcfg.get("database", "neo4j")
        if not uri or not user or not password:
            self.logger.warning(
                "Neo4j configuration incomplete; graph cleanup disabled."
            )
            return None
        driver = GraphDatabase.driver(
            uri.replace("neo4j://", "bolt://"),
            auth=(user, password),
            database=database,
            user_agent="mem0-cleanup-script/1.0",
        )
        self.logger.info(f"Neo4j connection ready → {uri} (DB: {database})")
        return driver

    @staticmethod
    def load_markdown_file(path: str) -> str:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    @staticmethod
    def now_iso() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds") + "Z"

    @staticmethod
    def extract_metadata_from_path(file_path: str) -> Dict[str, Any]:
        path = Path(file_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        try:
            libraries_idx = path.parts.index("Libraries")
        except ValueError:
            raise ValueError("O caminho não contém a pasta 'Libraries'")
        rel_parts = path.parts[libraries_idx + 1 :]
        library_name = rel_parts[0]
        version = (
            rel_parts[1]
            if len(rel_parts) > 1 and rel_parts[1].startswith("v")
            else None
        )
        if len(rel_parts) > 2:
            inner = list(rel_parts[2:])
            relative_inside = "/".join(inner)
        else:
            inner = []
            relative_inside = ""
        file_stem = path.stem
        if file_stem == library_name:
            title = f"{library_name} - Documentação Principal"
        else:
            pretty = file_stem.replace("_", " ").replace("-", " ")
            title = " ".join(w.capitalize() for w in pretty.split())
        return {
            "project": "Libraries",
            "library_name": library_name,
            "version": version,
            "version_clean": version[1:]
            if version and version.startswith("v")
            else version,
            "file_path": str(path),
            "file_name": path.name,
            "file_stem": file_stem,
            "relative_path": f"Libraries/{library_name}/{version}/{relative_inside}".rstrip(
                "/"
            ),
            "relative_path_inside_version": relative_inside,
            "suggested_title": title,
            "file_size_bytes": path.stat().st_size,
            "last_modified_iso": datetime.fromtimestamp(
                path.stat().st_mtime, tz=timezone.utc
            ).isoformat(),
        }

    def call_openai_for_summary(
        self,
        content: str,
        model: Optional[str] = None,
        max_retries: int = 3,
        base_delay: float = 0.75,
    ) -> Dict[str, Any]:
        if self.openai_client is None:
            raise RuntimeError("OpenAI client not initialized")
        model_name = model or self.config.llm.get("config", {}).get(
            "model", "gpt-4o-mini"
        )
        user_prompt = self.SUMMARY_PROMPT_TEMPLATE.replace(
            "<<<CONTENT>>>", content.strip()
        )
        messages = []
        for attempt in range(1, max_retries + 1):
            try:
                response = self.openai_client.chat.completions.create(
                    model=model_name,
                    temperature=0.0,
                    max_tokens=1400,
                    messages=messages
                    + [
                        {
                            "role": "system",
                            "content": "Você responde EXCLUSIVAMENTE com JSON válido. Sem texto adicional, sem ```, sem quebras de linha antes do {.",
                        },
                        {"role": "user", "content": user_prompt},
                    ],
                )
                raw = response.choices[0].message.content.strip()
                start = raw.find("{")
                end = raw.rfind("}") + 1
                if start == -1 or end <= 1:
                    raise ValueError("Bloco JSON não encontrado")
                json_str = raw[start:end]
                data = json.loads(json_str)
                if not isinstance(data, dict) or "title" not in data:
                    raise ValueError("JSON inválido ou sem campo 'title'")
                self.logger.info(f"JSON válido na tentativa {attempt}")
                return data
            except Exception as e:
                if attempt == max_retries:
                    self.logger.error(f"Falha definitiva após {max_retries} tentativas")
                    raise
                else:
                    messages.append(
                        {
                            "role": "user",
                            "content": f"Tentativa {attempt}/{max_retries}. Erro ao processar JSON: {e}. Por favor, tente novamente e responda apenas com JSON válido.",
                        }
                    )
                    delay = base_delay * (2 ** (attempt - 1)) + random.uniform(0, 1)
                    self.logger.warning(
                        f"Tentativa {attempt}/{max_retries} falhou → retry em {delay:.1f}s... Erro: {e}"
                    )
                    time.sleep(delay)
        raise RuntimeError("Impossível chegar aqui")

    def cleanup_document(self, doc_key: str) -> Tuple[int, int]:
        deleted_vector = 0
        deleted_graph = 0
        for source_type in ["summary", "full"]:
            try:
                existing = self.memory.search(
                    query="*",
                    user_id=self.config.user_id,
                    filters={"doc_key": doc_key, "source_type": source_type},
                    limit=100,
                )
                for mem in existing.get("results", []):
                    mem_id = mem.get("id")
                    if mem_id:
                        self.memory.delete(mem_id)
                        deleted_vector += 1
            except Exception as e:
                self.logger.error(
                    f"Erro ao deletar do vector store → {doc_key} ({source_type}): {e}"
                )
        if self.driver:
            with self.driver.session() as session:
                try:
                    result = session.run(
                        "OPTIONAL MATCH (m:Memory {doc_key: $doc_key}) WITH m, count(m) AS total DETACH DELETE m RETURN total",
                        doc_key=doc_key,
                    )
                    deleted_graph = result.single()["total"]
                except Exception as e:
                    self.logger.error(
                        f"Erro ao deletar do graph store → {doc_key}: {e}"
                    )
        total = deleted_vector + deleted_graph
        if total > 0:
            self.logger.info(
                f"Limpeza total: {deleted_vector} vector(s) + {deleted_graph} graph node(s) removidos → {doc_key}"
            )
        else:
            self.logger.info(f"Nada para limpar → {doc_key}")
        return deleted_vector, deleted_graph

    def ingest_document(self, file_path: str, overwrite: bool = True) -> Dict[str, Any]:
        context = self.load_markdown_file(file_path)
        if not context.strip():
            raise ValueError("Arquivo markdown vazio")
        base_meta = self.extract_metadata_from_path(file_path)
        doc_key = f"{base_meta['library_name']}/{base_meta['version_clean']}/{base_meta['file_name']}"
        if overwrite:
            self.cleanup_document(doc_key)
        summary_data = self.call_openai_for_summary(context)
        summary_text = (
            f"# {summary_data['title']}\n\n"
            f"{summary_data['one_sentence_summary']}\n\n"
            f"## Características principais\n"
            f"{chr(10).join('- ' + f for f in summary_data['key_features'])}\n\n"
            f"## Funções/Classe principais\n"
            f"{', '.join(summary_data.get('main_classes_functions', []) or ['N/A'])}\n\n"
            f"## Tags\n"
            f"{', '.join(summary_data['tags'])}\n"
        ).strip()
        sum_resp = self.memory.add(
            summary_text,
            user_id=self.config.user_id,
            metadata={
                **base_meta,
                "source_type": "summary",
                "doc_key": doc_key,
                **summary_data,
            },
            infer=False,
        )
        summary_id = sum_resp["results"][0]["id"]
        self.logger.info(f"Resumo → {summary_id}")
        full_resp = self.memory.add(
            context,
            user_id=self.config.user_id,
            metadata={
                **base_meta,
                "source_type": "full",
                "doc_key": doc_key,
                "summary_id": summary_id,
            },
            infer=False,
        )
        full_id = full_resp["results"][0]["id"]
        self.logger.info(f"Full → {full_id}")
        self.memory.add(
            f"SUMMARY_OF: {summary_id} resume o documento completo {full_id}",
            user_id=self.config.user_id,
            metadata={
                "relationship": "SUMMARY_OF",
                "from_entity_id": summary_id,
                "to_entity_id": full_id,
                "project": "Libraries",
                "doc_key": doc_key,
            },
            infer=False,
        )
        self.logger.info("Relação SUMMARY_OF criada")
        time.sleep(self.config.default_sleep_time)
        return {
            "doc_key": doc_key,
            "summary_id": summary_id,
            "full_id": full_id,
            "metadata": base_meta,
        }

    def scan_library(self, context_source_folder: str) -> List[Dict[str, Any]]:
        if find is None:
            raise RuntimeError("fbpyutils.file.find is not available")
        context_source_files = find(context_source_folder, mask="*.md")
        results: List[Dict[str, Any]] = []
        for path in context_source_files:
            try:
                res = self.ingest_document(path)
                results.append(res)
            except Exception as e:
                self.logger.error(f"Erro ao processar {path}: {e}")
        self.logger.info("INGESTÃO CONCLUÍDA COM SUCESSO — 0 ERROS 503")
        return results

    def search(
        self, query: str, limit: int = 10, project: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        resp = self.memory.search(
            query=query,
            user_id=self.config.user_id,
            filters={"project": project or self.config.project},
            limit=limit,
        )
        return [
            {
                "id": item["id"],
                "content": item["memory"],
                "score": item.get("score", 0.0),
                "metadata": item.get("metadata", {}),
                "source": item["metadata"].get("file_name", "unknown"),
                "type": item["metadata"].get("source_type", "unknown"),
            }
            for item in resp.get("results", [])
        ]

    def get_context(
        self, query: str, project: Optional[str] = None, max_tokens: int = 8000
    ) -> str:
        results = self.search(query, limit=15, project=project or self.config.project)
        context_parts: List[str] = []
        total_tokens = 0
        for item in results:
            content = item["content"]
            if total_tokens + len(content) // 4 > max_tokens:
                break
            context_parts.append(f"--- {item['source']} ---\n{content}\n")
            total_tokens += len(content) // 4
        return "\n".join(context_parts)

    def close(self):
        try:
            if self.driver:
                self.driver.close()
        except Exception:
            pass


def create_engine(config_path: Optional[str] = None) -> IngestionEngine:
    if config_path and os.path.exists(config_path):
        cfg = Config.from_path(config_path)
    else:
        cfg = Config.from_env()
    return IngestionEngine(cfg)


def ingest_file(
    file_path: str, config_path: Optional[str] = None, overwrite: bool = True
) -> Dict[str, Any]:
    engine = create_engine(config_path)
    try:
        return engine.ingest_document(file_path, overwrite=overwrite)
    finally:
        engine.close()


def cleanup_file(file_path: str, config_path: Optional[str] = None) -> Tuple[int, int]:
    engine = create_engine(config_path)
    try:
        base_meta = IngestionEngine.extract_metadata_from_path(file_path)
        doc_key = f"{base_meta['library_name']}/{base_meta['version_clean']}/{base_meta['file_name']}"
        return engine.cleanup_document(doc_key)
    finally:
        engine.close()


def search_memory(
    query: str, config_path: Optional[str] = None, limit: int = 10
) -> List[Dict[str, Any]]:
    engine = create_engine(config_path)
    try:
        return engine.search(query, limit=limit)
    finally:
        engine.close()


def get_memory_context(
    query: str, config_path: Optional[str] = None, max_tokens: int = 8000
) -> str:
    engine = create_engine(config_path)
    try:
        return engine.get_context(query, max_tokens=max_tokens)
    finally:
        engine.close()


def scan_directory(
    directory: str, config_path: Optional[str] = None
) -> List[Dict[str, Any]]:
    engine = create_engine(config_path)
    try:
        return engine.scan_library(directory)
    finally:
        engine.close()
