#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Context Module
=============

Módulo para gerenciamento de contexto e documentação com ferramentas MCP.

Este módulo contém ferramentas para ingestão de documentação, busca semântica,
e gerenciamento de prompts e recursos através do sistema Context7.
"""

from __future__ import annotations

import os
import json
import random
import time
from pathlib import Path
from typing import Any, Dict

from fbpyservers_mcp import _ROOT_DIR
from fbpyservers_mcp.tools.utils import LLMClient


def summarize_content(
    markdown: str, llm_client: LLMClient, max_retries: int = 3
) -> Dict[str, Any]:
    """
    Gera um resumo estruturado em JSON a partir de documentação Markdown.

    Esta função substitui o método summarize da classe OpenAILLM,
    movendo a lógica para uma função utilitária reutilizável.

    Args:
        markdown: Conteúdo completo em Markdown
        llm_client: Cliente LLM configurado
        max_retries: Número máximo de tentativas em caso de falha

    Returns:
        Dict com campos: title, key_features, tags, summary, usage_examples

    Raises:
        RuntimeError: Se todas as tentativas falharem
    """
    # Carregar prompt do arquivo
    prompt_path = os.path.sep.join([
        _ROOT_DIR,
        "data",
        "prompts",
        "SUMMARIZE_CONTEXT.md"
    ])

    print()
    try:
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_template = f.read()
    except FileNotFoundError:
        # Fallback para caso o arquivo não exista
        raise RuntimeError(f"SUMMARIZE_CONTEXT.md not found at {prompt_path}")

    prompt = prompt_template.replace("{{CONTENT}}", markdown.strip())

    for attempt in range(1, max_retries + 1):
        try:
            response = llm_client.chat_completion(
                [
                    {
                        "role": "system",
                        "content": "Responda EXCLUSIVAMENTE com JSON válido.",
                    },
                    {"role": "user", "content": prompt},
                ]
            )

            raw = response.strip()
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])

        except Exception as e:
            if attempt == max_retries:
                raise RuntimeError(
                    f"Failed to summarize after {max_retries} attempts: {str(e)}"
                ) from e
            # Exponential backoff with jitter
            delay = 0.75 * (2 ** (attempt - 1)) + random.uniform(0, 1)
            time.sleep(delay)


def extract_prompts_content(
    markdown: str, llm_client: LLMClient, max_retries: int = 3
) -> Dict[str, Any]:
    """
    Extrai dados estruturados de prompts a partir de conteúdo Markdown.

    Esta função carrega o prompt de extração do arquivo EXTRACT_SINGLE_PROMPT.md
    e usa LLM para extrair dados de prompts conforme o schema do banco.

    Args:
        markdown: Conteúdo completo em Markdown
        llm_client: Cliente LLM configurado
        max_retries: Número máximo de tentativas em caso de falha

    Returns:
        Dict com estrutura de dados para inserção no banco

    Raises:
        RuntimeError: Se todas as tentativas falharem
    """
    # Carregar prompt do arquivo
    prompt_path = os.path.sep.join([
        _ROOT_DIR,
        "data",
        "prompts",
        "EXTRACT_SINGLE_PROMPT.md"
    ])

    try:
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_template = f.read()
    except FileNotFoundError:
        # Fallback para caso o arquivo não exista
        raise RuntimeError(f"EXTRACT_SINGLE_PROMPT.md not found at {prompt_path}")

    prompt = prompt_template.replace("{{CONTENT}}", markdown.strip())

    for attempt in range(1, max_retries + 1):
        try:
            response = llm_client.chat_completion(
                [
                    {
                        "role": "system",
                        "content": "Answer ONLY with a valid JSON.",
                    },
                    {"role": "user", "content": prompt},
                ]
            )

            raw = response.strip()
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])

        except Exception as e:
            if attempt == max_retries:
                return {"error": f"Failed to extract prompts: {str(e)}", "prompts": []}
            # Exponential backoff with jitter
            delay = 0.75 * (2 ** (attempt - 1)) + random.uniform(0, 1)
            time.sleep(delay)


def extract_resources_content(
    markdown: str, llm_client: LLMClient, max_retries: int = 3
) -> Dict[str, Any]:
    """
    Extrai dados estruturados de resources a partir de conteúdo Markdown.

    Esta função carrega o prompt de extração do arquivo EXTRACT_RESOURCE.md
    e usa LLM para extrair dados de resources conforme o schema do banco.

    Args:
        markdown: Conteúdo completo em Markdown
        llm_client: Cliente LLM configurado
        max_retries: Número máximo de tentativas em caso de falha

    Returns:
        Dict com estrutura de dados para inserção no banco

    Raises:
        RuntimeError: Se todas as tentativas falharem
    """
    # Carregar prompt do arquivo
    prompt_path = os.path.sep.join([
        _ROOT_DIR,
        "data",
        "prompts",
        "EXTRACT_RESOURCE.md"
    ])

    try:
        with open(prompt_path, "r", encoding="utf-8") as f:
            prompt_template = f.read()
    except FileNotFoundError:
        # Fallback para caso o arquivo não exista
        raise RuntimeError(f"EXTRACT_RESOURCE.md not found at {prompt_path}")

    prompt = prompt_template.replace("{{CONTENT}}", markdown.strip())

    for attempt in range(1, max_retries + 1):
        try:
            response = llm_client.chat_completion(
                [
                    {
                        "role": "system",
                        "content": "Responda EXCLUSIVAMENTE com JSON válido.",
                    },
                    {"role": "user", "content": prompt},
                ]
            )

            raw = response.strip()
            start = raw.find("{")
            end = raw.rfind("}") + 1
            return json.loads(raw[start:end])

        except Exception as e:
            if attempt == max_retries:
                return {
                    "error": f"Failed to extract resources: {str(e)}",
                    "resources": [],
                }
            # Exponential backoff with jitter
            delay = 0.75 * (2 ** (attempt - 1)) + random.uniform(0, 1)
            time.sleep(delay)
