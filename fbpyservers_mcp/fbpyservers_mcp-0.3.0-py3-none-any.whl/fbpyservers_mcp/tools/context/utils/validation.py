#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Data Validation Module
======================

Módulo de validação e verificação de integridade para dados extraídos
de prompts e recursos conforme o modelo de dados fbpyservers_mcp.model.

Fornece validações robustas, sugestões de correção e verificações de
conformidade com o schema do banco de dados.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple
from fbpyservers_mcp.models import StatusEnum


class DataValidationError(Exception):
    """Exceção para erros de validação de dados."""

    pass


class PromptValidator:
    """Validador para dados de Prompt, PromptArgument e PromptMessage."""

    @staticmethod
    def validate_prompt_data(
        prompt_data: Dict[str, Any],
    ) -> Tuple[bool, List[str], List[str]]:
        """
        Valida dados de um prompt completo.

        Args:
            prompt_data: Dicionário com dados do prompt

        Returns:
            Tuple: (is_valid, errors, warnings)
        """
        errors = []
        warnings = []

        # Validar campos obrigatórios do Prompt
        if not prompt_data.get("name"):
            errors.append("Campo 'name' é obrigatório")
        else:
            name = prompt_data["name"]
            if len(name) > 256:
                errors.append(
                    f"Campo 'name' excede 256 caracteres (atual: {len(name)})"
                )
            if not re.match(r"^[a-z0-9_]+$", name):
                warnings.append(f"Nome '{name}' deve usar apenas snake_case minúsculo")

        if not prompt_data.get("description"):
            errors.append("Campo 'description' é obrigatório")
        elif len(prompt_data["description"]) > 4000:
            errors.append(
                f"Campo 'description' excede 4000 caracteres (atual: {len(prompt_data['description'])})"
            )

        # Validar status
        status = prompt_data.get("status", "PENDING")
        if status not in [s.value for s in StatusEnum]:
            errors.append(f"Status '{status}' inválido")

        # Validar mensagens (obrigatório pelo menos 1)
        messages = prompt_data.get("messages", [])
        if not messages:
            errors.append("Prompt deve ter pelo menos 1 PromptMessage")
        else:
            message_errors = PromptValidator._validate_messages(messages)
            errors.extend(message_errors)

        # Validar argumentos (opcional)
        arguments = prompt_data.get("arguments", [])
        for i, arg in enumerate(arguments):
            arg_errors = PromptValidator._validate_argument(arg, i)
            errors.extend(arg_errors)

        return len(errors) == 0, errors, warnings

    @staticmethod
    def _validate_messages(messages: List[Dict[str, Any]]) -> List[str]:
        """Valida lista de mensagens."""
        errors = []

        for i, msg in enumerate(messages):
            if not msg.get("role"):
                errors.append(f"Message {i}: campo 'role' é obrigatório")
            elif msg["role"] not in ["system", "user", "assistant"]:
                errors.append(
                    f"Message {i}: role '{msg['role']}' inválido (deve ser: system, user, assistant)"
                )

            if not msg.get("content"):
                errors.append(f"Message {i}: campo 'content' é obrigatório")
            elif len(msg["content"]) > 4000:
                errors.append(
                    f"Message {i}: content excede 4000 caracteres (atual: {len(msg['content'])})"
                )

            if not msg.get("type"):
                warnings.append(
                    f"Message {i}: campo 'type' recomendado para melhor organização"
                )

            status = msg.get("status", "PENDING")
            if status not in [s.value for s in StatusEnum]:
                errors.append(f"Message {i}: status '{status}' inválido")

        return errors

    @staticmethod
    def _validate_argument(arg: Dict[str, Any], index: int) -> List[str]:
        """Valida um argumento."""
        errors = []

        if not arg.get("name"):
            errors.append(f"Argument {index}: campo 'name' é obrigatório")
        else:
            name = arg["name"]
            if len(name) > 256:
                errors.append(
                    f"Argument {index}: name excede 256 caracteres (atual: {len(name)})"
                )
            if not re.match(r"^[a-z0-9_]+$", name):
                errors.append(
                    f"Argument {index}: name deve usar apenas snake_case minúsculo"
                )

        if not arg.get("description"):
            errors.append(f"Argument {index}: campo 'description' é obrigatório")
        elif len(arg["description"]) > 4000:
            errors.append(
                f"Argument {index}: description excede 4000 caracteres (atual: {len(arg['description'])})"
            )

        required = arg.get("required", 1)
        if not isinstance(required, int) or required not in [0, 1]:
            errors.append(
                f"Argument {index}: required deve ser 0 ou 1 (atual: {required})"
            )

        status = arg.get("status", "PENDING")
        if status not in [s.value for s in StatusEnum]:
            errors.append(f"Argument {index}: status '{status}' inválido")

        return errors

    @staticmethod
    def suggest_corrections(prompt_data: Dict[str, Any]) -> List[str]:
        """Sugere correções para dados incompletos."""
        suggestions = []

        # Sugestões baseadas no conteúdo das mensagens
        messages = prompt_data.get("messages", [])
        if messages:
            content_text = " ".join(msg.get("content", "") for msg in messages)

            if (
                not prompt_data.get("description")
                or len(prompt_data["description"]) < 50
            ):
                # Gerar description baseado no conteúdo
                suggestions.append(
                    "Adicione uma description mais detalhada explicando o propósito e uso do prompt"
                )

            # Identificar variáveis nas mensagens
            variables = re.findall(r"\{(\w+)\}", content_text)
            if variables and not prompt_data.get("arguments"):
                suggestions.append(
                    f"Considere adicionar argumentos para as variáveis identificadas: {', '.join(variables)}"
                )

        # Sugestões para estrutura
        if len(messages) < 2:
            suggestions.append(
                "Adicione mais mensagens (system → user → assistant) para tornar o prompt mais completo"
            )

        # Sugestões para nome
        name = prompt_data.get("name", "")
        if not name or len(name) < 5:
            suggestions.append(
                "Use um nome mais descritivo que reflita o propósito do prompt"
            )

        return suggestions


class ResourceValidator:
    """Validador para dados de Resource."""

    @staticmethod
    def validate_resource_data(
        resource_data: Dict[str, Any],
    ) -> Tuple[bool, List[str], List[str]]:
        """
        Valida dados de um recurso.

        Args:
            resource_data: Dicionário com dados do recurso

        Returns:
            Tuple: (is_valid, errors, warnings)
        """
        errors = []
        warnings = []

        # Validar campos obrigatórios
        if not resource_data.get("name"):
            errors.append("Campo 'name' é obrigatório")
        else:
            name = resource_data["name"]
            if len(name) > 256:
                errors.append(
                    f"Campo 'name' excede 256 caracteres (atual: {len(name)})"
                )

        if not resource_data.get("mime_type"):
            errors.append("Campo 'mime_type' é obrigatório")
        elif len(resource_data["mime_type"]) > 256:
            errors.append(
                f"Campo 'mime_type' excede 256 caracteres (atual: {len(resource_data['mime_type'])})"
            )
        elif not ResourceValidator._is_valid_mime_type(resource_data["mime_type"]):
            warnings.append(
                f"MIME type '{resource_data['mime_type']}' pode ser inválido"
            )

        if not resource_data.get("uri"):
            errors.append("Campo 'uri' é obrigatório")
        elif len(resource_data["uri"]) > 4000:
            errors.append(
                f"Campo 'uri' excede 4000 caracteres (atual: {len(resource_data['uri'])})"
            )
        elif not ResourceValidator._is_valid_uri(resource_data["uri"]):
            warnings.append(f"URI '{resource_data['uri']}' pode ser inválida")

        if not resource_data.get("description"):
            errors.append("Campo 'description' é obrigatório")
        elif len(resource_data["description"]) > 4000:
            errors.append(
                f"Campo 'description' excede 4000 caracteres (atual: {len(resource_data['description'])})"
            )

        # Validar tamanho
        size_bytes = resource_data.get("size_bytes", 0)
        if not isinstance(size_bytes, int) or size_bytes < 0:
            errors.append("Campo 'size_bytes' deve ser inteiro não negativo")
        elif size_bytes == 0:
            warnings.append(
                "size_bytes é 0 - considere estimar um tamanho mais realista"
            )

        # Validar status
        status = resource_data.get("status", "PENDING")
        if status not in [s.value for s in StatusEnum]:
            errors.append(f"Status '{status}' inválido")

        return len(errors) == 0, errors, warnings

    @staticmethod
    def _is_valid_mime_type(mime_type: str) -> bool:
        """Verifica se MIME type é válido."""
        pattern = r"^[a-zA-Z0-9.-]+/[a-zA-Z0-9.-]+$"
        return bool(re.match(pattern, mime_type))

    @staticmethod
    def _is_valid_uri(uri: str) -> bool:
        """Verifica se URI é válida."""
        # URL patterns
        url_pattern = r"^https?://[^\s/$.?#].[^\s]*$"
        if re.match(url_pattern, uri):
            return True

        # File path patterns
        path_pattern = r"^[/\\]?[a-zA-Z0-9._/\\-]+$"
        if re.match(path_pattern, uri):
            return True

        # Relative path patterns
        rel_path_pattern = r"^[a-zA-Z0-9._/\\-]+$"
        if re.match(rel_path_pattern, uri):
            return True

        return False

    @staticmethod
    def suggest_corrections(resource_data: Dict[str, Any]) -> List[str]:
        """Sugere correções para dados incompletos."""
        suggestions = []

        name = resource_data.get("name", "")
        mime_type = resource_data.get("mime_type", "")
        uri = resource_data.get("uri", "")

        # Sugestões baseadas no URI
        if uri:
            if uri.startswith("http"):
                if mime_type == "text/plain" or not mime_type:
                    suggestions.append(
                        "Para URLs HTTP, especifique o MIME type correto baseado no tipo de conteúdo"
                    )
            elif "." in uri:
                extension = uri.split(".")[-1].lower()
                mime_mapping = {
                    "md": "text/markdown",
                    "txt": "text/plain",
                    "json": "application/json",
                    "html": "text/html",
                    "png": "image/png",
                    "jpg": "image/jpeg",
                    "pdf": "application/pdf",
                    "xml": "application/xml",
                    "css": "text/css",
                    "js": "text/javascript",
                }
                if extension in mime_mapping:
                    suggestions.append(
                        f"Para arquivos .{extension}, considere usar MIME type '{mime_mapping[extension]}'"
                    )

        # Sugestões para tamanho
        size_bytes = resource_data.get("size_bytes", 0)
        if size_bytes == 0:
            if uri.startswith("http"):
                suggestions.append(
                    "Para recursos HTTP, considere estimar um tamanho típico baseado no tipo de conteúdo"
                )
            else:
                suggestions.append(
                    "Considere estimar o tamanho do arquivo ou usar 0 se desconhecido"
                )

        # Sugestões para nome
        if not name or len(name) < 5:
            suggestions.append(
                "Use um nome mais descritivo que reflita claramente o tipo e propósito do recurso"
            )

        return suggestions


class DataIntegrityChecker:
    """Verificador de integridade geral dos dados."""

    @staticmethod
    def validate_extraction_result(extraction_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Valida resultado completo de extração.

        Args:
            extraction_data: Dados extraídos com estrutura de prompts e resources

        Returns:
            Dict com resultados de validação
        """
        result = {
            "valid": True,
            "prompt_count": 0,
            "resource_count": 0,
            "prompts": [],
            "resources": [],
            "total_errors": 0,
            "total_warnings": 0,
            "suggestions": [],
        }

        # Validar prompts
        prompts = extraction_data.get("prompts", [])
        result["prompt_count"] = len(prompts)

        for i, prompt_data in enumerate(prompts):
            is_valid, errors, warnings = PromptValidator.validate_prompt_data(
                prompt_data
            )

            prompt_result = {
                "index": i,
                "name": prompt_data.get("name", f"prompt_{i}"),
                "valid": is_valid,
                "errors": errors,
                "warnings": warnings,
                "suggestions": PromptValidator.suggest_corrections(prompt_data)
                if not is_valid
                else [],
            }

            result["prompts"].append(prompt_result)
            result["total_errors"] += len(errors)
            result["total_warnings"] += len(warnings)

            if not is_valid:
                result["valid"] = False

        # Validar resources
        resources = extraction_data.get("resources", [])
        result["resource_count"] = len(resources)

        for i, resource_data in enumerate(resources):
            is_valid, errors, warnings = ResourceValidator.validate_resource_data(
                resource_data
            )

            resource_result = {
                "index": i,
                "name": resource_data.get("name", f"resource_{i}"),
                "valid": is_valid,
                "errors": errors,
                "warnings": warnings,
                "suggestions": ResourceValidator.suggest_corrections(resource_data)
                if not is_valid
                else [],
            }

            result["resources"].append(resource_result)
            result["total_errors"] += len(errors)
            result["total_warnings"] += len(warnings)

            if not is_valid:
                result["valid"] = False

        # Sugestões gerais
        if result["prompt_count"] == 0:
            result["suggestions"].append(
                "Nenhum prompt foi identificado - verifique se o conteúdo contém exemplos de prompts"
            )

        if result["resource_count"] == 0:
            result["suggestions"].append(
                "Nenhum recurso foi identificado - verifique se o conteúdo contém links, arquivos ou referências"
            )

        if result["total_errors"] == 0 and result["total_warnings"] == 0:
            result["suggestions"].append("Extração válida - dados prontos para uso")

        return result


# Funções utilitárias para uso direto
def validate_prompts(prompts_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Valida lista de prompts."""
    results = []
    for i, prompt_data in enumerate(prompts_data):
        is_valid, errors, warnings = PromptValidator.validate_prompt_data(prompt_data)
        results.append(
            {
                "index": i,
                "valid": is_valid,
                "errors": errors,
                "warnings": warnings,
                "suggestions": PromptValidator.suggest_corrections(prompt_data)
                if not is_valid
                else [],
            }
        )
    return {"results": results, "valid": all(r["valid"] for r in results)}


def validate_resources(resources_data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Valida lista de recursos."""
    results = []
    for i, resource_data in enumerate(resources_data):
        is_valid, errors, warnings = ResourceValidator.validate_resource_data(
            resource_data
        )
        results.append(
            {
                "index": i,
                "valid": is_valid,
                "errors": errors,
                "warnings": warnings,
                "suggestions": ResourceValidator.suggest_corrections(resource_data)
                if not is_valid
                else [],
            }
        )
    return {"results": results, "valid": all(r["valid"] for r in results)}
