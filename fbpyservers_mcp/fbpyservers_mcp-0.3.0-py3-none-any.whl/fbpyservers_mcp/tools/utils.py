#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utils Module
============

Módulo profissional para utilitários compartilhados entre as ferramentas do FBPyServers-MCP.

Funcionalidades principais:
    • Interface abstrata LLMClient para injeção de dependências
    • Implementação OpenAILLM compatível com OpenRouter, Ollama Cloud, Groq, Anthropic, Azure, etc.
    • Geração de resumos estruturados em JSON via LLM (REMOVIDO - movido para módulo context)
    • Tratamento robusto de falhas com retry exponencial

Princípios aplicados:
    • SOLID completo
    • Dependency Inversion via interface abstrata
    • Zero prints — tudo via logging ou retorno
    • Configuração flexível via parâmetros

Exemplo de uso:
    >>> from fbpyservers_mcp.tools.utils import OpenAILLM
    >>> client = OpenAILLM(
    ...     base_url="https://openrouter.ai/api/v1",
    ...     api_key="sk-...",
    ...     model="deepseek/deepseek-coder-v2-lite-instruct:16b"
    ... )
    >>> response = client.chat_completion([{"role": "user", "content": "Olá!"}])
"""

from __future__ import annotations

import random
import time
from abc import ABC, abstractmethod

from openai import OpenAI


class LLMClient(ABC):
    """
    Interface para clientes LLM compatíveis com API OpenAI.

    Permite injeção de dependências e substituição de implementações
    sem alterar o código cliente.

    Nota: O método summarize foi movido para uma função utilitária
    no módulo context.tools.context para melhor separação de responsabilidades.
    """

    @abstractmethod
    def chat_completion(self, messages: list, max_retries: int = 3) -> str:
        """
        Gera uma resposta de chat usando LLM.

        Args:
            messages: Lista de mensagens no formato [{"role": "user", "content": "..."}]
            max_retries: Número máximo de tentativas em caso de falha

        Returns:
            String com a resposta do LLM

        Raises:
            RuntimeError: Se todas as tentativas falharem
        """
        pass


class OpenAILLM(LLMClient):
    """
    Cliente LLM compatível com qualquer endpoint OpenAI-style.

    Suporta:
        • OpenRouter (free tier)
        • Ollama Cloud
        • Groq, Anthropic, Azure, etc.

    Attributes:
        client: Cliente OpenAI configurado
        model: Nome do modelo a ser utilizado

    Nota: O método summarize foi removido - use a função utilitária
    summarize_content() do módulo context.tools.context em seu lugar.
    """

    def __init__(self, base_url: str, api_key: str, model: str):
        """
        Inicializa o cliente LLM.

        Args:
            base_url: URL base do serviço (ex: https://openrouter.ai/api/v1)
            api_key: Chave de API
            model: Nome do modelo (ex: deepseek/deepseek-coder-v2-lite-instruct:16b)
        """
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.model = model

    def chat_completion(self, messages: list, max_retries: int = 3) -> str:
        """
        Implementa LLMClient.chat_completion.

        Gera uma resposta de chat usando o modelo configurado.

        Args:
            messages: Lista de mensagens no formato [{"role": "user", "content": "..."}]
            max_retries: Número máximo de tentativas em caso de falha

        Returns:
            String com a resposta do LLM

        Raises:
            RuntimeError: Se todas as tentativas falharem
        """
        for attempt in range(1, max_retries + 1):
            try:
                resp = self.client.chat.completions.create(
                    model=self.model,
                    temperature=0.0,
                    max_tokens=4000,
                    messages=messages,
                )
                return resp.choices[0].message.content.strip()
            except Exception as e:
                if attempt == max_retries:
                    raise RuntimeError(
                        f"Failed to get chat completion after {max_retries} attempts: {str(e)}"
                    ) from e
                # Exponential backoff with jitter
                delay = 0.75 * (2 ** (attempt - 1)) + random.uniform(0, 1)
                time.sleep(delay)
