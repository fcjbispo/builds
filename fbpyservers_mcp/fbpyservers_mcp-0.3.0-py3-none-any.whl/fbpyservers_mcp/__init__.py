import os
from dotenv import load_dotenv
from sqlalchemy import create_engine

from fbpyservers_mcp.models import Base

import fbpyutils

_ = load_dotenv()

__version__ = "0.3.0"

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# Setup logger and environment first
fbpyutils.setup(os.path.join(_ROOT_DIR, "app.json"))

env = fbpyutils.get_env()
env.LOG_LEVEL = os.environ.get("FBPY_LOG_LEVEL", "ERROR")
env.CONFIG = {
    "mcp_db_url": {
        "url": os.environ.get(
            "FBPY_MCP_DB_URL",
            env.CONFIG.get("mcp_db_url", {}).get(
                "url", "postgresql://mcp:mcp@localhost:5432/fbnet"
            ),
        )
    },
}


logger = fbpyutils.get_logger()
logger.configure_from_env(env)

# Inicia a conexão com o banco de dados
logger.info(f"Connecting to MCP database at {env.CONFIG['mcp_db_url']['url']}")
engine = create_engine(env.CONFIG["mcp_db_url"]["url"], echo=False)

# Criar todas as tabelas
logger.info("Creating MCP database tables if they do not exist...")
Base.metadata.create_all(engine)
