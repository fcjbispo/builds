"""
Database connection management for API Key authorization.

This module provides database connection management specifically for the API Key
authorization system. It's separate from the main MCP database to ensure security
and performance isolation.
"""

import os
import logging
from contextlib import contextmanager
from typing import Optional, Generator
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from sqlalchemy.exc import SQLAlchemyError, DisconnectionError

from fbpyservers_mcp.models import Base

logger = logging.getLogger(__name__)

# Global engine and session factory for authorization database
_auth_engine = None
_AuthSessionLocal = None
_db_initialized = False


def init_auth_db(
    db_url: Optional[str] = None,
    pool_size: int = 5,
    max_overflow: int = 10,
    pool_timeout: int = 30,
    pool_recycle: int = 3600,
    echo: bool = False
) -> None:
    """
    Initialize the authorization database connection.
    
    Args:
        db_url: Database connection URL. If None, uses FBPY_MCP_DB_URL environment variable
        pool_size: Size of the connection pool
        max_overflow: Maximum overflow connections
        pool_timeout: Pool timeout in seconds
        pool_recycle: Connection recycle time in seconds
        echo: Enable SQL query logging
        
    Raises:
        ValueError: If db_url is not provided and FBPY_MCP_DB_URL is not set
        SQLAlchemyError: If database connection fails
    """
    global _auth_engine, _AuthSessionLocal, _db_initialized
    
    # Get database URL
    if db_url is None:
        db_url = os.getenv("FBPY_MCP_DB_URL")
    
    if not db_url:
        raise ValueError(
            "Database URL required for authorization. "
            "Set FBPY_MCP_DB_URL environment variable or pass db_url parameter."
        )
    
    try:
        # Create optimized engine for authorization database
        _auth_engine = create_engine(
            db_url,
            # Connection pool settings
            poolclass=StaticPool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_recycle=pool_recycle,
            pool_pre_ping=True,  # Test connections before use
            # Performance settings
            echo=echo,
            # PostgreSQL specific settings
            connect_args={"connect_timeout": 10} if "postgresql" in db_url else {},
            # UTF-8 encoding
            encoding="utf-8"
        )
        
        # Test connection
        with _auth_engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        
        # Create session factory
        _AuthSessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=_auth_engine,
            expire_on_commit=False
        )
        
        # Create tables if they don't exist
        logger.info("Creating API Key authorization tables if they don't exist...")
        Base.metadata.create_all(bind=_auth_engine)
        
        _db_initialized = True
        logger.info(f"Authorization database initialized successfully: {db_url}")
        
    except SQLAlchemyError as e:
        logger.error(f"Failed to initialize authorization database: {str(e)}")
        _auth_engine = None
        _AuthSessionLocal = None
        _db_initialized = False
        raise
    except Exception as e:
        logger.error(f"Unexpected error initializing authorization database: {str(e)}")
        _auth_engine = None
        _AuthSessionLocal = None
        _db_initialized = False
        raise


def get_auth_engine():
    """
    Get the authorization database engine.
    
    Returns:
        sqlalchemy.engine.Engine: The database engine
        
    Raises:
        RuntimeError: If database hasn't been initialized
    """
    if _auth_engine is None:
        raise RuntimeError(
            "Authorization database not initialized. Call init_auth_db() first."
        )
    return _auth_engine


@contextmanager
def get_auth_db_session() -> Generator[Session, None, None]:
    """
    Context manager for authorization database sessions.
    
    Yields:
        Session: SQLAlchemy database session
        
    Example:
        with get_auth_db_session() as session:
            api_key = session.query(APIKey).first()
    
    Raises:
        RuntimeError: If database hasn't been initialized
        SQLAlchemyError: If session operations fail
    """
    if _AuthSessionLocal is None:
        raise RuntimeError(
            "Authorization database not initialized. Call init_auth_db() first."
        )
    
    session = _AuthSessionLocal()
    try:
        yield session
        session.commit()
    except Exception as e:
        session.rollback()
        logger.error(f"Database session error: {str(e)}")
        raise
    finally:
        session.close()


def create_auth_db_session() -> Session:
    """
    Create a new authorization database session.
    
    Returns:
        Session: SQLAlchemy database session
        
    Note:
        Remember to close the session when done. Prefer using get_auth_db_session()
        context manager for automatic cleanup.
        
    Raises:
        RuntimeError: If database hasn't been initialized
    """
    if _AuthSessionLocal is None:
        raise RuntimeError(
            "Authorization database not initialized. Call init_auth_db() first."
        )
    
    return _AuthSessionLocal()


def test_auth_db_connection() -> bool:
    """
    Test the authorization database connection.
    
    Returns:
        bool: True if connection is working, False otherwise
    """
    try:
        if _auth_engine is None:
            return False
        
        with _auth_engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
        
    except Exception as e:
        logger.error(f"Authorization database connection test failed: {str(e)}")
        return False


def get_auth_db_info() -> dict:
    """
    Get information about the authorization database.
    
    Returns:
        dict: Database information including status, URL, and stats
    """
    info = {
        "initialized": _db_initialized,
        "engine": None,
        "session_factory": None,
        "connection_status": "unknown"
    }
    
    if _auth_engine:
        info["engine"] = str(_auth_engine)
        info["connection_status"] = "connected" if test_auth_db_connection() else "disconnected"
    
    if _AuthSessionLocal:
        info["session_factory"] = "configured"
    
    return info


def close_auth_db() -> None:
    """
    Close the authorization database connection and cleanup resources.
    
    This should be called during application shutdown.
    """
    global _auth_engine, _AuthSessionLocal, _db_initialized
    
    try:
        if _auth_engine:
            _auth_engine.dispose()
            logger.info("Authorization database connection closed")
        
        _auth_engine = None
        _AuthSessionLocal = None
        _db_initialized = False
        
    except Exception as e:
        logger.error(f"Error closing authorization database: {str(e)}")


def ensure_auth_db_initialized() -> None:
    """
    Ensure the authorization database is initialized.
    
    This function will attempt to initialize the database if not already done.
    
    Raises:
        ValueError: If database URL is not available
        SQLAlchemyError: If initialization fails
    """
    global _db_initialized
    
    if not _db_initialized:
        if not os.getenv("FBPY_MCP_DB_URL"):
            raise ValueError(
                "FBPY_MCP_DB_URL environment variable is required for authorization"
            )
        init_auth_db()


# Auto-initialization helper for when this module is imported
def _auto_init():
    """
    Auto-initialize authorization database if FBPY_MCP_DB_URL is set.
    
    This is called automatically when the module is imported.
    """
    try:
        if os.getenv("FBPY_MCP_DB_URL"):
            init_auth_db()
    except Exception as e:
        logger.warning(f"Failed to auto-initialize authorization database: {str(e)}")


# Database health check functions
def get_auth_db_stats() -> dict:
    """
    Get statistics about the authorization database.
    
    Returns:
        dict: Database statistics including connection count and query stats
    """
    stats = {
        "initialized": _db_initialized,
        "connection_pool": None,
        "total_connections": 0,
        "checked_out_connections": 0,
        "overflow_connections": 0,
        "invalid_connections": 0
    }
    
    try:
        if _auth_engine and hasattr(_auth_engine, 'pool'):
            pool = _auth_engine.pool
            stats["connection_pool"] = str(pool.__class__.__name__)
            stats["total_connections"] = getattr(pool, 'size', 0)
            stats["checked_out_connections"] = getattr(pool, 'checkedout', 0)
            stats["overflow_connections"] = getattr(pool, 'overflow', 0)
            stats["invalid_connections"] = getattr(pool, 'invalid', 0)
    except Exception as e:
        logger.debug(f"Error getting database stats: {str(e)}")
    
    return stats


def cleanup_auth_db_connections() -> int:
    """
    Cleanup invalid or expired database connections.
    
    Returns:
        int: Number of connections cleaned up
    """
    try:
        if _auth_engine and hasattr(_auth_engine, 'pool'):
            pool = _auth_engine.pool
            if hasattr(pool, 'cleanup'):
                pool.cleanup()
                return 1
    except Exception as e:
        logger.debug(f"Error cleaning up database connections: {str(e)}")
    
    return 0


# Environment and configuration helpers
def get_auth_db_config() -> dict:
    """
    Get the authorization database configuration.
    
    Returns:
        dict: Database configuration settings
    """
    return {
        "db_url": os.getenv("FBPY_MCP_DB_URL"),
        "pool_size": int(os.getenv("FBPY_MCP_AUTH_POOL_SIZE", "5")),
        "max_overflow": int(os.getenv("FBPY_MCP_AUTH_MAX_OVERFLOW", "10")),
        "pool_timeout": int(os.getenv("FBPY_MCP_AUTH_POOL_TIMEOUT", "30")),
        "pool_recycle": int(os.getenv("FBPY_MCP_AUTH_POOL_RECYCLE", "3600")),
        "echo": os.getenv("FBPY_MCP_AUTH_ECHO", "false").lower() == "true"
    }


def validate_auth_db_config() -> dict:
    """
    Validate the authorization database configuration.
    
    Returns:
        dict: Validation results with errors and warnings
    """
    config = get_auth_db_config()
    result = {
        "valid": True,
        "errors": [],
        "warnings": [],
        "config": config
    }
    
    # Check required settings
    if not config["db_url"]:
        result["errors"].append("FBPY_MCP_DB_URL environment variable is required")
        result["valid"] = False
    
    # Check pool settings
    if config["pool_size"] <= 0:
        result["errors"].append("FBPY_MCP_AUTH_POOL_SIZE must be positive")
        result["valid"] = False
    
    if config["max_overflow"] < 0:
        result["errors"].append("FBPY_MCP_AUTH_MAX_OVERFLOW cannot be negative")
        result["valid"] = False
    
    if config["pool_timeout"] <= 0:
        result["errors"].append("FBPY_MCP_AUTH_POOL_TIMEOUT must be positive")
        result["valid"] = False
    
    if config["pool_recycle"] <= 0:
        result["warnings"].append("FBPY_MCP_AUTH_POOL_RECYCLE should be positive for production")
    
    return result


# Call auto-initialization when module is imported
_auto_init()


# Convenience functions for common operations
@contextmanager
def auth_session():
    """Convenience alias for get_auth_db_session."""
    with get_auth_db_session() as session:
        yield session


def auth_db_initialized() -> bool:
    """Check if authorization database is initialized."""
    return _db_initialized


def init_auth_database(db_url: Optional[str] = None, **kwargs) -> None:
    """Convenience alias for init_auth_db."""
    return init_auth_db(db_url, **kwargs)


def get_auth_session() -> Session:
    """Convenience alias for create_auth_db_session."""
    return create_auth_db_session()
