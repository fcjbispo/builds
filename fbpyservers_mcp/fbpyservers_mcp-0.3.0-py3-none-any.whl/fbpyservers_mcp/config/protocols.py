"""
Configuration module for MCP protocol support.

This module provides unified configuration management for the supported protocol:
- stdio: Standard input/output (default, no network)

Supports environment-based configuration with sensible defaults.
"""

import os
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class ProtocolConfig:
    """Configuration for the stdio protocol."""
    name: str
    host: str
    port: int
    stateless: bool
    requires_auth: bool
    requires_db: bool


class MultipleProtocolsConfig:
    """
    Unified configuration manager for MCP protocols.
    
    Currently supports:
    - stdio: Claude Desktop integration, no network required
    
    Simple and reliable protocol without authentication requirements.
    """
    
    # Protocol definitions
    PROTOCOLS = {
        "stdio": ProtocolConfig(
            name="stdio",
            host="localhost",
            port=0,  # Not used for stdio
            stateless=True,
            requires_auth=False,
            requires_db=False
        )
    }
    
    @staticmethod
    def get_transport() -> str:
        """
        Get the configured transport protocol.
        
        Returns:
            str: Protocol name (stdio only)
            
        Environment Variable:
            FBPY_MCP_TRANSPORT: Protocol to use (default: "stdio")
        """
        return os.getenv("FBPY_MCP_TRANSPORT", "stdio")
    
    @staticmethod
    def get_protocol_config(protocol: Optional[str] = None) -> ProtocolConfig:
        """
        Get configuration for a specific protocol.
        
        Args:
            protocol: Protocol name. If None, uses FBPY_MCP_TRANSPORT
            
        Returns:
            ProtocolConfig: Configuration for the specified protocol
            
        Raises:
            ValueError: If protocol is not supported
        """
        if protocol is None:
            protocol = MultipleProtocolsConfig.get_transport()
        
        if protocol not in MultipleProtocolsConfig.PROTOCOLS:
            supported = ", ".join(MultipleProtocolsConfig.PROTOCOLS.keys())
            raise ValueError(f"Unsupported protocol '{protocol}'. Supported: {supported}")
        
        return MultipleProtocolsConfig.PROTOCOLS[protocol]
    
    @staticmethod
    def get_stdio_config() -> Dict[str, Any]:
        """
        Get stdio-specific configuration.
        
        Returns:
            Dict[str, Any]: Configuration dictionary for stdio protocol
        """
        return {
            "host": "localhost",
            "port": 0,  # Not used for stdio
            "stateless": True
        }
    
    @staticmethod
    def get_log_level() -> str:
        """
        Get configured log level.
        
        Returns:
            str: Log level (DEBUG, INFO, WARNING, ERROR)
            
        Environment Variable:
            FBPY_LOG_LEVEL: Log level (default: "ERROR")
        """
        return os.getenv("FBPY_LOG_LEVEL", "ERROR")
    
    @staticmethod
    def validate_config(protocol: Optional[str] = None) -> Dict[str, Any]:
        """
        Validate and return complete configuration for a protocol.
        
        Args:
            protocol: Protocol to validate. If None, uses FBPY_MCP_TRANSPORT
            
        Returns:
            Dict[str, Any]: Complete configuration with validation results
            
        Raises:
            ValueError: If configuration is invalid
        """
        config = MultipleProtocolsConfig.get_protocol_config(protocol)
        validation_result = {
            "protocol": config.name,
            "valid": True,
            "errors": [],
            "warnings": [],
            "config": {}
        }
        
        try:
            # Get protocol-specific config
            if config.name == "stdio":
                protocol_config = MultipleProtocolsConfig.get_stdio_config()
            else:
                raise ValueError(f"Unknown protocol: {config.name}")
            
            validation_result["config"] = protocol_config
            
            # stdio doesn't require authentication or database
            # No additional validation needed
            
        except Exception as e:
            validation_result["errors"].append(f"Configuration error: {str(e)}")
            validation_result["valid"] = False
        
        return validation_result
    
    @staticmethod
    def get_environment_info() -> Dict[str, Any]:
        """
        Get information about the current environment configuration.
        
        Returns:
            Dict[str, Any]: Environment information
        """
        transport = MultipleProtocolsConfig.get_transport()
        config = MultipleProtocolsConfig.get_protocol_config(transport)
        
        return {
            "transport": transport,
            "protocol_config": {
                "name": config.name,
                "requires_auth": config.requires_auth,
                "requires_db": config.requires_db,
                "port": config.port,
                "host": config.host
            },
            "log_level": MultipleProtocolsConfig.get_log_level()
        }


# Convenience aliases for backward compatibility
ProtocolConfig = MultipleProtocolsConfig


def get_transport() -> str:
    """Get the configured transport protocol."""
    return MultipleProtocolsConfig.get_transport()


def get_protocol_config(protocol: Optional[str] = None) -> ProtocolConfig:
    """Get configuration for a specific protocol."""
    return MultipleProtocolsConfig.get_protocol_config(protocol)


def get_stdio_config() -> Dict[str, Any]:
    """Get stdio-specific configuration."""
    return MultipleProtocolsConfig.get_stdio_config()


def get_log_level() -> str:
    """Get configured log level."""
    return MultipleProtocolsConfig.get_log_level()


def validate_config(protocol: Optional[str] = None) -> Dict[str, Any]:
    """Validate and return complete configuration for a protocol."""
    return MultipleProtocolsConfig.validate_config(protocol)


def get_environment_info() -> Dict[str, Any]:
    """Get information about the current environment configuration."""
    return MultipleProtocolsConfig.get_environment_info()