"""MyLibraryScanner - A Python library for file scanning and analysis using FBNet standard configuration.

This package provides functionality to:
- Scan directories and gather file information using FBNet configuration system
- Store and manage file metadata in PostgreSQL database with JSONB support
- Search files by content and metadata
- Analyze files with AI on-demand
- Provide both CLI and GUI interfaces

Modules:
    core: Core scanning and file processing functionality
    database: Database operations and models with PostgreSQL JSONB support
    storage: Data persistence and serialization
    cli: Command-line interface
    gui: Desktop GUI placeholders
    webapp: Streamlit web interface
    search: File search and indexing
    reorganizer: File reorganization suggestions
    utils: Utility functions and helpers
    initialization: FBNet standard configuration and logging setup

Key Features:
- FBNet standard configuration system (app.json + environment variables)
- PostgreSQL JSONB storage for flexible file metadata
- Master/detail relational schema for scan management
- AI-ready architecture with extensible metadata
- Full compatibility with existing duplicate detection views
- Comprehensive repository pattern for database operations
"""

__version__ = "0.1.0"
__author__ = "Francisco C J Bispo"
__email__ = "fcjbispo@franciscobispo.net"

# Import initialization module first (sets up configuration and logging)
from . import initialization

# Re-export main components for easy access
from . import core
from . import database
from . import storage
from . import cli
from . import gui
from . import webapp
from . import search
from . import reorganizer
from . import utils

from .database import Base, Source, SourceFile, DatabaseManager
from .initialization import (
    setup_system, 
    get_env_instance, 
    get_logger_instance, 
    get_app_config)

__all__ = [
    # Initialization (must be called first)
    "setup_system",
    "get_env_instance", 
    "get_logger_instance", 
    "get_app_config",
    
    # Package modules
    "core",
    "database", 
    "storage",
    "cli",
    "gui",
    "webapp",
    "search",
    "reorganizer",
    "utils",
    "initialization",
    
    # Database models and managers
    "Base",
    "Source",
    "SourceFile",
    "DatabaseManager",
]
