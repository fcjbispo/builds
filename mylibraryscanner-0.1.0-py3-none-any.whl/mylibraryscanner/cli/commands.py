"""CLI commands for MyLibraryScanner."""

from __future__ import annotations

import fnmatch
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional

from sqlalchemy import delete

from mylibraryscanner.core.file_processor import FileProcessor
from mylibraryscanner.core.inference import ContentInferenceService, MAX_INFERENCE_CHARS
from mylibraryscanner.core.scanner import Scanner
from mylibraryscanner.database.connection import DatabaseManager
from mylibraryscanner.database.models import Source, SourceFile
from mylibraryscanner.database.operations import ScanRepository, SourceRepository
from mylibraryscanner.initialization import get_logger_instance


def load_params(params_file: str = "params.json") -> Dict[str, Any]:
    """Load scan parameters from JSON file."""
    if not os.path.exists(params_file):
        raise FileNotFoundError(f"Parameters file not found: {params_file}")
    with open(params_file, "r", encoding="utf-8") as f:
        return json.load(f)


def _print_json(payload: Dict[str, Any]) -> None:
    print(json.dumps(payload, indent=2, ensure_ascii=False))


def _get_env_first(*names: str) -> str:
    """Return first non-empty environment value from ordered names."""
    for name in names:
        value = os.getenv(name)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _resolve_db_env_overrides() -> tuple[Optional[str], Optional[str]]:
    """Resolve DB connection overrides prioritizing FBNET convention."""
    db_url = _get_env_first(
        "FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL",
        "MYLIBRARYSCANNER_SYSTEM_DB_URL",
        "SYSTEM_DB_URL",
    )
    db_schema = _get_env_first(
        "FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA",
        "MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA",
        "DB_SCHEMA",
        "SYSTEM_DB_SCHEMA",
    )
    return (db_url or None, db_schema or None)


def cmd_init() -> int:
    """Initialize database tables and validate connection."""
    logger = get_logger_instance()
    try:
        db_manager = DatabaseManager()
        db_manager.create_tables(drop_existing=False)
        health = db_manager.health_check()
        _print_json({"status": "OK", "action": "init", "database": health})
        logger.info("Initialization command completed")
        return 0
    except Exception as e:
        logger.error(f"Init command failed: {e}")
        print(f"ERROR: init failed: {e}")
        return 1


def _build_single_file_scan_result(
    target: Path,
    source_name: Optional[str],
    source_kind: str,
) -> Dict[str, Any]:
    """Build scan payload for a single file target using the common scan schema."""
    started = datetime.now()
    processor = FileProcessor()
    file_result = processor.process_file(str(target))
    file_result.setdefault("inference", None)
    ended = datetime.now()

    status = "OK" if file_result.get("status") == "OK" else "FAIL"
    errors: list[Dict[str, str]] = []
    if status != "OK":
        errors.append(
            {
                "file": str(target),
                "message": file_result.get("status_message", "Unknown error"),
            }
        )

    return {
        "source_name": source_name or target.name,
        "source_dir": str(target.parent),
        "source_mask": target.name,
        "source_kind": source_kind,
        "start_extraction": started.isoformat(),
        "end_extraction": ended.isoformat(),
        "status": status,
        "status_message": file_result.get("status_message"),
        "files_total": 1,
        "files": [file_result],
        "errors": errors,
    }


def _ensure_inference_field(scan_payload: Dict[str, Any]) -> None:
    """Ensure every file result has an inference field."""
    for file_info in scan_payload.get("files", []):
        file_info.setdefault("inference", None)


def _infer_scan_payload(
    scan_payload: Dict[str, Any],
    force: bool = False,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> Dict[str, int]:
    """Infer content for scan payload files in-place."""
    service = ContentInferenceService(max_inference_chars=MAX_INFERENCE_CHARS)
    files = scan_payload.get("files", [])

    total = len(files)
    inferred = 0
    skipped_existing = 0
    skipped_status = 0
    skipped_unsupported = 0

    for index, file_info in enumerate(files, start=1):
        if file_info.get("status") != "OK":
            skipped_status += 1
            if progress_callback:
                progress_callback(index, total)
            continue

        if file_info.get("inference") and not force:
            skipped_existing += 1
            if progress_callback:
                progress_callback(index, total)
            continue

        file_path = file_info.get("file_path", "")
        details = file_info.get("details", {})
        inference = service.infer_file(file_path, details=details)
        if inference:
            file_info["inference"] = inference[:MAX_INFERENCE_CHARS]
            inferred += 1
        else:
            file_info["inference"] = None
            skipped_unsupported += 1
        if progress_callback:
            progress_callback(index, total)

    return {
        "total_files": total,
        "inferred": inferred,
        "skipped_existing": skipped_existing,
        "skipped_status": skipped_status,
        "skipped_unsupported_or_failed": skipped_unsupported,
    }


def run_scan_target(
    file_or_folder: str,
    source_mask: str = "*",
    source_name: Optional[str] = None,
    source_kind: str = "LOCAL",
    parallel: bool = False,
    max_workers: int = 4,
    infer: bool = False,
    store: bool = False,
    overwrite: bool = False,
    scan_progress_callback: Optional[Callable[[int, int], None]] = None,
    infer_progress_callback: Optional[Callable[[int, int], None]] = None,
) -> Dict[str, Any]:
    """Run scan target and return structured response without printing."""
    logger = get_logger_instance()
    try:
        target = Path(file_or_folder).expanduser().resolve()
        if not target.exists():
            return {"exit_code": 1, "error": f"path does not exist: {target}"}

        if parallel and max_workers < 1:
            return {"exit_code": 1, "error": "--max-workers must be >= 1"}

        mode = "single_file"
        if target.is_file():
            scan_payload = _build_single_file_scan_result(target, source_name, source_kind)
            if scan_progress_callback:
                scan_progress_callback(1, 1)
        else:
            scanner = Scanner(progress_callback=scan_progress_callback)
            resolved_source_name = source_name or target.name or "unnamed"
            if parallel:
                scan_result = scanner.scan_parallel(
                    str(target),
                    source_mask=source_mask,
                    source_name=resolved_source_name,
                    source_kind=source_kind,
                    max_workers=max_workers,
                )
                mode = "folder_parallel"
            else:
                scan_result = scanner.scan(
                    str(target),
                    source_mask=source_mask,
                    source_name=resolved_source_name,
                    source_kind=source_kind,
                )
                mode = "folder"
            scan_payload = scan_result.to_dict()

        _ensure_inference_field(scan_payload)

        inference_summary: Optional[Dict[str, int]] = None
        if infer:
            inference_summary = _infer_scan_payload(
                scan_payload,
                progress_callback=infer_progress_callback,
            )

        store_payload: Optional[Dict[str, Any]] = None
        if store:
            db_url, db_schema = _resolve_db_env_overrides()
            db_manager = DatabaseManager(
                schema=db_schema or None,
                database_url=db_url or None,
            )
            if not overwrite:
                source_repo = SourceRepository(db_manager)
                existing_source = source_repo.get_by_name(scan_payload.get("source_name", ""))
                if existing_source:
                    return {
                        "exit_code": 1,
                        "error": (
                            "source already exists. This would partially overwrite data. "
                            "Run again with --overwrite to replace all source information."
                        ),
                    }
            scan_repo = ScanRepository(db_manager)
            source = scan_repo.store_scan_result(scan_payload, overwrite=overwrite)
            store_payload = {
                "source_id": str(source.id),
                "source_name": source.source_name,
                "files_total": source.files_total,
            }

        response_payload = {
            "status": scan_payload.get("status", "OK"),
            "target": str(target),
            "mode": mode,
            "inference_enabled": infer,
            "inference_summary": inference_summary,
            "stored": store,
            "overwrite": overwrite,
            "store_result": store_payload,
            "scan": scan_payload,
        }

        if scan_payload.get("status") != "OK":
            logger.warning(f"scan completed with failures for target: {target}")
            return {"exit_code": 1, "payload": response_payload}

        logger.info(
            (
                f"scan completed for target={target} mode={mode} "
                f"files_total={scan_payload.get('files_total', 0)} store={store}"
            )
        )
        return {"exit_code": 0, "payload": response_payload}
    except Exception as e:
        logger.error(f"scan command failed: {e}")
        return {"exit_code": 1, "error": f"scan failed: {e}"}


def cmd_scan_target(
    file_or_folder: str,
    source_mask: str = "*",
    source_name: Optional[str] = None,
    source_kind: str = "LOCAL",
    parallel: bool = False,
    max_workers: int = 4,
    infer: bool = False,
    store: bool = False,
    overwrite: bool = False,
) -> int:
    """Scan file or folder and output JSON to stdout."""
    result = run_scan_target(
        file_or_folder=file_or_folder,
        source_mask=source_mask,
        source_name=source_name,
        source_kind=source_kind,
        parallel=parallel,
        max_workers=max_workers,
        infer=infer,
        store=store,
        overwrite=overwrite,
    )
    if result["exit_code"] != 0:
        print(f"ERROR: {result.get('error', 'scan failed')}")
        if result.get("payload"):
            _print_json(result["payload"])
        return 1

    _print_json(result["payload"])
    return 0


def cmd_scan_path(file_or_folder: str) -> int:
    """Backward-compatible wrapper for modern scan target command."""
    return cmd_scan_target(file_or_folder)


def cmd_library_list_sources(pattern: str = "*") -> int:
    """List sources with created/updated timestamps and total files count."""
    logger = get_logger_instance()
    try:
        db_manager = DatabaseManager()
        repo = SourceRepository(db_manager)
        sources = repo.get_all()
        filtered = [s for s in sources if fnmatch.fnmatch(s.source_name, pattern)]

        payload = []
        for source in filtered:
            payload.append(
                {
                    "source_name": source.source_name,
                    "source_kind": source.source_kind,
                    "status": source.status,
                    "files_total": source.files_total,
                    "created_at": source.created_at.isoformat()
                    if source.created_at
                    else None,
                    "updated_at": source.updated_at.isoformat()
                    if source.updated_at
                    else None,
                }
            )

        _print_json({"status": "OK", "pattern": pattern, "total": len(payload), "items": payload})
        return 0
    except Exception as e:
        logger.error(f"library list_sources failed: {e}")
        print(f"ERROR: library list_sources failed: {e}")
        return 1


def _confirm_remove_source(source_name: str) -> bool:
    answer = input(
        f"Confirm deletion of source '{source_name}' and all related files? [y/N]: "
    ).strip()
    return answer.lower() in {"y", "yes"}


def cmd_library_remove_source(source_name: str, assume_yes: bool = False) -> int:
    """Remove a source and all related files (confirmation required by default)."""
    logger = get_logger_instance()
    try:
        db_manager = DatabaseManager()

        with db_manager.get_session() as session:
            source = session.query(Source).filter(Source.source_name == source_name).first()
            if not source:
                print(f"ERROR: source not found: {source_name}")
                return 1

            if not assume_yes and not _confirm_remove_source(source_name):
                print("Aborted.")
                return 1

            session.delete(source)

        _print_json({"status": "OK", "removed_source": source_name})
        logger.info(f"Removed source and files for {source_name}")
        return 0
    except Exception as e:
        logger.error(f"library remove_source failed: {e}")
        print(f"ERROR: library remove_source failed: {e}")
        return 1


def cmd_library_infer_source(source_name: str) -> int:
    """Infer file content summaries for an existing source in database."""
    result = run_library_infer_source(source_name)
    if result["exit_code"] != 0:
        print(f"ERROR: {result.get('error', 'library infer_source failed')}")
        return 1
    _print_json(result["payload"])
    return 0


def run_library_infer_source(
    source_name: str,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> Dict[str, Any]:
    """Infer file content summaries for an existing source and return structured response."""
    logger = get_logger_instance()
    try:
        db_url, db_schema = _resolve_db_env_overrides()
        db_manager = DatabaseManager(
            schema=db_schema or None,
            database_url=db_url or None,
        )
        service = ContentInferenceService(max_inference_chars=MAX_INFERENCE_CHARS)

        with db_manager.get_session() as session:
            source = session.query(Source).filter(Source.source_name == source_name).first()
            if not source:
                return {"exit_code": 1, "error": f"source not found: {source_name}"}

            files = (
                session.query(SourceFile)
                .filter(SourceFile.source_id == source.id)
                .order_by(SourceFile.file_path)
                .all()
            )

            total = len(files)
            inferred = 0
            overwritten = 0
            skipped_status = 0
            skipped_unsupported = 0

            for index, file_row in enumerate(files, start=1):
                if file_row.status != "OK":
                    skipped_status += 1
                    if progress_callback:
                        progress_callback(index, total)
                    continue

                had_inference = bool((file_row.inference or "").strip())

                details = file_row.details if isinstance(file_row.details, dict) else {}
                inference = service.infer_file(file_row.file_path, details=details)
                if inference:
                    file_row.inference = inference[:MAX_INFERENCE_CHARS]
                    if had_inference:
                        overwritten += 1
                    else:
                        inferred += 1
                else:
                    skipped_unsupported += 1
                if progress_callback:
                    progress_callback(index, total)

            source.updated_at = datetime.now()

        payload = {
            "status": "OK",
            "action": "library_infer_source",
            "source_name": source_name,
            "overwrite_existing": True,
            "summary": {
                "total_files": total,
                "inferred_new": inferred,
                "overwritten_existing": overwritten,
                "skipped_status": skipped_status,
                "skipped_unsupported_or_failed": skipped_unsupported,
            },
        }
        logger.info(
            "library infer_source completed for "
            f"{source_name}: inferred={inferred}/{total}"
        )
        return {"exit_code": 0, "payload": payload}
    except Exception as e:
        logger.error(f"library infer_source failed: {e}")
        return {"exit_code": 1, "error": f"library infer_source failed: {e}"}


# Legacy flow preserved for compatibility while new CLI commands are introduced.
def cmd_scan(params: Dict[str, Any]) -> int:
    logger = get_logger_instance()

    source_dir = params.get("source_dir")
    source_mask = params.get("source_mask", "*")
    source_name = params.get("source_name")
    output_folder = params.get("output_folder", "data/scans")

    if not source_dir:
        print("ERROR: source_dir is required")
        return 1

    if not os.path.exists(source_dir):
        print(f"ERROR: Source directory does not exist: {source_dir}")
        return 1

    if not source_name:
        source_name = Path(source_dir).name

    print(f"Scanning: {source_name}")
    print(f"Directory: {source_dir}")
    print(f"Mask: {source_mask}")

    try:
        scanner = Scanner()
        result = scanner.scan(source_dir, source_mask, source_name)

        os.makedirs(output_folder, exist_ok=True)
        output_file = os.path.join(output_folder, f"SCAN_{source_name}.json")

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result.to_dict(), f, indent=2)

        print(f"\nScan complete!")
        print(f"Files processed: {result.files_total}")
        print(f"Errors: {len(result.errors)}")
        print(f"Output: {output_file}")

        logger.info(f"Scan completed: {source_name} - {result.files_total} files")
        return 0

    except Exception as e:
        print(f"ERROR: Scan failed: {e}")
        logger.error(f"Scan failed: {e}")
        return 1


def cmd_store(params: Dict[str, Any]) -> int:
    logger = get_logger_instance()

    source_name = params.get("source_name")
    scan_file = params.get("scan_file")

    if not scan_file:
        print("ERROR: scan_file is required")
        return 1

    if not os.path.exists(scan_file):
        print(f"ERROR: Scan file not found: {scan_file}")
        return 1

    print(f"Loading scan from: {scan_file}")

    try:
        with open(scan_file, "r", encoding="utf-8") as f:
            scan_data = json.load(f)

        if source_name:
            scan_data["source_name"] = source_name

        print(f"Source: {scan_data.get('source_name')}")
        print(f"Files: {len(scan_data.get('files', []))}")

        print("\nStoring to database...")
        db_manager = DatabaseManager()
        scan_repo = ScanRepository(db_manager)
        source = scan_repo.store_scan_result(scan_data)

        print(f"\nStore complete!")
        print(f"Source ID: {source.id}")
        print(f"Total files: {source.files_total}")

        logger.info(f"Stored scan result: {scan_data.get('source_name')}")
        return 0
    except Exception as e:
        print(f"ERROR: Store failed: {e}")
        logger.error(f"Store failed: {e}")
        return 1


def cmd_truncate(params: Dict[str, Any]) -> int:
    logger = get_logger_instance()
    source_name = params.get("source_name")

    try:
        db_manager = DatabaseManager()
        print("Truncating database tables...")

        with db_manager.get_session() as session:
            if source_name:
                source = session.query(Source).filter(Source.source_name == source_name).first()
                if not source:
                    print(f"Source not found: {source_name}")
                    return 1
                session.delete(source)
                print(f"Deleted source: {source_name}")
                logger.info(f"Truncated source: {source_name}")
            else:
                session.execute(delete(SourceFile))
                session.execute(delete(Source))
                print("Deleted all sources and files")
                logger.info("Truncated all sources")

        return 0
    except Exception as e:
        print(f"ERROR: Truncate failed: {e}")
        logger.error(f"Truncate failed: {e}")
        return 1


def cmd_status(params: Dict[str, Any]) -> int:
    logger = get_logger_instance()
    try:
        db_manager = DatabaseManager()
        scan_repo = ScanRepository(db_manager)
        summary = scan_repo.get_scan_summary()

        print("\n=== MyLibraryScanner Status ===\n")
        print(f"Total Sources: {summary['total_sources']}")
        print(f"Total Files: {summary['total_files']}")

        if summary["sources_by_status"]:
            print("\nSources by Status:")
            for status, count in summary["sources_by_status"].items():
                print(f"  {status}: {count}")

        if summary["files_by_status"]:
            print("\nFiles by Status:")
            for status, count in summary["files_by_status"].items():
                print(f"  {status}: {count}")

        print()
        return 0
    except Exception as e:
        print(f"ERROR: Status check failed: {e}")
        logger.error(f"Status check failed: {e}")
        return 1


COMMANDS = {
    "SCAN": cmd_scan,
    "STORE": cmd_store,
    "TRUNCATE": cmd_truncate,
    "STATUS": cmd_status,
}


def execute_command(operation: str, params: Dict[str, Any]) -> int:
    if operation not in COMMANDS:
        print(f"ERROR: Unknown command: {operation}")
        print(f"Available commands: {', '.join(COMMANDS.keys())}")
        return 1
    return COMMANDS[operation](params)


__all__ = [
    "load_params",
    "cmd_init",
    "cmd_scan_target",
    "cmd_scan_path",
    "cmd_library_list_sources",
    "cmd_library_remove_source",
    "cmd_library_infer_source",
    "run_scan_target",
    "run_library_infer_source",
    "execute_command",
]
