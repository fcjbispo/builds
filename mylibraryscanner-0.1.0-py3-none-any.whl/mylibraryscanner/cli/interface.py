"""CLI interface for MyLibraryScanner."""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional

from mylibraryscanner.cli.commands import (
    cmd_init,
    cmd_library_infer_source,
    cmd_library_list_sources,
    cmd_library_remove_source,
    cmd_scan_target,
    execute_command,
    load_params,
)
from mylibraryscanner.initialization import get_logger_instance, setup_system


def build_parser() -> argparse.ArgumentParser:
    """Build argparse parser for the modern CLI commands."""
    parser = argparse.ArgumentParser(prog="mylibraryscanner")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("init", help="Initialize database/core resources")

    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan a file or folder and output JSON",
    )
    scan_parser.add_argument("file_or_folder", help="Path to file or folder")
    scan_parser.add_argument(
        "--pattern",
        default="*",
        help="File name pattern used when scanning folders (default: *)",
    )
    scan_parser.add_argument(
        "--source-name",
        default=None,
        help="Optional source name for scan payload",
    )
    scan_parser.add_argument(
        "--source-kind",
        choices=["LOCAL", "REMOVABLE", "REMOTE"],
        default="LOCAL",
        help="Source kind classification (default: LOCAL)",
    )
    scan_parser.add_argument(
        "--parallel",
        action="store_true",
        help="Use parallel workers when scanning folders",
    )
    scan_parser.add_argument(
        "--max-workers",
        type=int,
        default=4,
        help="Number of workers for --parallel (default: 4)",
    )
    scan_parser.add_argument(
        "--store",
        action="store_true",
        help="Store scan result directly in the database",
    )
    scan_parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacing all data for an existing source name when used with --store",
    )
    scan_parser.add_argument(
        "--infer",
        action="store_true",
        help="Infer concise content summary for supported files",
    )

    library_parser = subparsers.add_parser("library", help="Library management commands")
    library_sub = library_parser.add_subparsers(dest="library_command", required=True)

    list_parser = library_sub.add_parser("list_sources", help="List sources")
    list_parser.add_argument("--pattern", default="*", help="Source name pattern filter")

    remove_parser = library_sub.add_parser("remove_source", help="Remove a source")
    remove_parser.add_argument("--source_name", required=True, help="Source name to remove")
    remove_parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip interactive confirmation",
    )

    infer_parser = library_sub.add_parser(
        "infer_source",
        help="Infer content for files of an existing source",
    )
    infer_parser.add_argument("--source_name", required=True, help="Source name to infer")

    return parser


def execute_modern_cli(args: list[str]) -> Optional[int]:
    """Execute modern subcommand-based CLI if command is detected."""
    parser = build_parser()
    if not args:
        return None

    known_commands = {"init", "scan", "library", "-h", "--help"}
    if args[0] not in known_commands:
        return None

    namespace = parser.parse_args(args)

    if namespace.command == "init":
        return cmd_init()
    if namespace.command == "scan":
        return cmd_scan_target(
            namespace.file_or_folder,
            source_mask=namespace.pattern,
            source_name=namespace.source_name,
            source_kind=namespace.source_kind,
            parallel=namespace.parallel,
            max_workers=namespace.max_workers,
            infer=namespace.infer,
            store=namespace.store,
            overwrite=namespace.overwrite,
        )
    if namespace.command == "library":
        if namespace.library_command == "list_sources":
            return cmd_library_list_sources(namespace.pattern)
        if namespace.library_command == "remove_source":
            return cmd_library_remove_source(namespace.source_name, assume_yes=namespace.yes)
        if namespace.library_command == "infer_source":
            return cmd_library_infer_source(namespace.source_name)

    parser.print_help()
    return 1


def execute_legacy_cli(args: list[str]) -> int:
    """Execute legacy operation-based CLI (`SCAN_OPERATION` and `-o/-p`)."""
    logger = get_logger_instance()
    operation = os.environ.get("SCAN_OPERATION", "").strip()
    params = {}

    i = 0
    while i < len(args):
        arg = args[i]
        if arg in {"-o", "--operation"}:
            if i + 1 >= len(args):
                print(f"ERROR: {arg} requires an argument")
                return 1
            operation = args[i + 1]
            i += 2
            continue
        if arg in {"-p", "--params"}:
            if i + 1 >= len(args):
                print(f"ERROR: {arg} requires an argument")
                return 1
            param_arg = args[i + 1]
            if param_arg.startswith("{"):
                import json

                try:
                    params = json.loads(param_arg)
                except json.JSONDecodeError:
                    print(f"ERROR: Invalid JSON: {param_arg}")
                    return 1
            else:
                try:
                    params = load_params(param_arg)
                except Exception as e:
                    print(f"ERROR: {e}")
                    return 1
            i += 2
            continue
        i += 1

    if not operation:
        print("ERROR: no command provided")
        print("Use one of: init, scan, library ...")
        print("Or legacy mode: -o SCAN|STORE|TRUNCATE|STATUS")
        return 1

    if not params:
        params_file = os.environ.get("SCAN_PARAMS_FILE", "params.json")
        if os.path.exists(params_file):
            try:
                params = load_params(params_file)
            except Exception as e:
                logger.warning(f"Could not load params file: {e}")

    logger.info(f"Executing legacy operation: {operation}")
    return execute_command(operation, params)


def main() -> int:
    """Main CLI entry point."""
    try:
        setup_system()
    except Exception as e:
        print(f"CRITICAL: Failed to initialize system: {e}")
        return 1

    args = sys.argv[1:]
    modern_result = execute_modern_cli(args)
    if modern_result is not None:
        return modern_result
    return execute_legacy_cli(args)


__all__ = ["main", "build_parser"]
