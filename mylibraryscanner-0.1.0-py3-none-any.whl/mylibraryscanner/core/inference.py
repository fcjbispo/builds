"""Content inference utilities for MyLibraryScanner.

This module provides concise content inference for text/data and image files.
Binary files are ignored.
"""

from __future__ import annotations

import base64
import json
import mimetypes
import os
import re
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Any, Dict, Optional
from urllib import request as urlrequest

from mylibraryscanner.initialization import get_app_config, get_logger_instance


MAX_INFERENCE_CHARS = 5 * 1024
MAX_TEXT_INPUT_CHARS = 16_000
MAX_IMAGE_BYTES = 6 * 1024 * 1024

_TEXT_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".rst",
    ".csv",
    ".tsv",
    ".json",
    ".jsonl",
    ".yaml",
    ".yml",
    ".xml",
    ".html",
    ".htm",
    ".css",
    ".js",
    ".ts",
    ".py",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".go",
    ".rs",
    ".php",
    ".sql",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".env",
    ".log",
    ".sh",
    ".bat",
    ".cmd",
    ".ps1",
}

_DOC_EXTENSIONS = {".pdf", ".docx", ".odt", ".xlsx", ".xlsm"}
_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}


def _truncate(text: str, max_chars: int = MAX_INFERENCE_CHARS) -> str:
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."


def _strip_xml_tags(raw_xml: str) -> str:
    no_tags = re.sub(r"<[^>]+>", " ", raw_xml)
    compact = re.sub(r"\s+", " ", no_tags).strip()
    return compact


def _is_probably_binary(data: bytes) -> bool:
    if not data:
        return False
    if b"\x00" in data:
        return True
    non_text = sum(
        1
        for b in data
        if b not in b"\t\n\r\f\b" and (b < 32 or b > 126)
    )
    return (non_text / len(data)) > 0.30


class ContentInferenceService:
    """Run concise LLM inference for supported files."""

    def __init__(self, max_inference_chars: int = MAX_INFERENCE_CHARS):
        cfg = get_app_config().get("config", {})
        app_code = get_app_config().get("app", {}).get("appcode", "MYLIBRARYSCANNER")

        self.logger = get_logger_instance()
        self.max_inference_chars = max_inference_chars
        self.base_url = str(cfg.get("llm_chat_base_url", "")).strip()
        self.model = str(cfg.get("llm_chat_model", "")).strip()
        self.temperature = float(cfg.get("llm_chat_temperature", 0.2))
        self.max_tokens = int(cfg.get("llm_chat_max_tokens", 300))

        # Optional auth key for compatible gateways.
        self.api_key = (
            str(cfg.get("llm_chat_api_key", "")).strip()
            or os.getenv(f"FBNET_{app_code}_LLM_CHAT_API_KEY", "").strip()
            or os.getenv("LLM_CHAT_API_KEY", "").strip()
            or os.getenv("OPENAI_API_KEY", "").strip()
        )

    def _chat_url(self) -> str:
        base = self.base_url.rstrip("/")
        if base.endswith("/chat/completions"):
            return base
        return f"{base}/chat/completions"

    def _is_image(self, file_path: str, mime_type: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return mime_type.startswith("image/") or ext in _IMAGE_EXTENSIONS

    def _is_data_file(self, file_path: str, mime_type: str) -> bool:
        ext = Path(file_path).suffix.lower()
        if ext in _TEXT_EXTENSIONS or ext in _DOC_EXTENSIONS:
            return True
        if mime_type.startswith("text/"):
            return True
        if mime_type in {
            "application/json",
            "application/xml",
            "application/yaml",
            "application/x-yaml",
            "application/toml",
            "application/javascript",
        }:
            return True
        return False

    def _extract_text_for_inference(self, file_path: str) -> Optional[str]:
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext == ".pdf":
            if not shutil.which("pdftotext"):
                return None
            try:
                completed = subprocess.run(
                    ["pdftotext", "-q", "-nopgbrk", str(path), "-"],
                    check=True,
                    capture_output=True,
                )
                text = completed.stdout.decode("utf-8", errors="ignore")
                return text[:MAX_TEXT_INPUT_CHARS].strip() or None
            except Exception:
                return None

        if ext in {".docx", ".odt", ".xlsx", ".xlsm"}:
            try:
                with zipfile.ZipFile(path, "r") as zf:
                    names = [n for n in zf.namelist() if n.endswith(".xml")]
                    chunks = []
                    for name in names[:30]:
                        raw_xml = zf.read(name).decode("utf-8", errors="ignore")
                        chunks.append(_strip_xml_tags(raw_xml))
                    merged = " ".join(chunk for chunk in chunks if chunk)
                    return merged[:MAX_TEXT_INPUT_CHARS].strip() or None
            except Exception:
                return None

        try:
            raw = path.read_bytes()
            if _is_probably_binary(raw[:4096]):
                return None
            decoded = raw.decode("utf-8", errors="ignore")
            return decoded[:MAX_TEXT_INPUT_CHARS].strip() or None
        except Exception:
            return None

    def _post_chat(self, payload: Dict[str, Any]) -> Optional[str]:
        if not self.base_url or not self.model:
            self.logger.warning("LLM inference skipped: base URL or model not configured")
            return None

        body = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        req = urlrequest.Request(
            self._chat_url(),
            data=body,
            headers=headers,
            method="POST",
        )

        try:
            with urlrequest.urlopen(req, timeout=60) as resp:
                content = resp.read().decode("utf-8", errors="ignore")
                result = json.loads(content)
        except Exception as exc:
            self.logger.warning(f"LLM inference request failed: {exc}")
            return None

        try:
            message = result["choices"][0]["message"]["content"]
            if isinstance(message, list):
                texts = []
                for item in message:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(item.get("text", ""))
                message = " ".join(texts)
            if not isinstance(message, str):
                return None
            return _truncate(message.strip(), self.max_inference_chars)
        except Exception:
            return None

    def _infer_text(self, file_path: str, text: str) -> Optional[str]:
        prompt = (
            "Resuma o conteúdo do arquivo em português, de forma clara e sucinta. "
            "Inclua finalidade provável, principais tópicos e possível destinação. "
            f"Resposta máxima: {self.max_inference_chars} caracteres."
        )
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "messages": [
                {"role": "system", "content": "Você resume arquivos para gestão documental."},
                {
                    "role": "user",
                    "content": f"Arquivo: {file_path}\n\nConteúdo:\n{text}\n\n{prompt}",
                },
            ],
        }
        return self._post_chat(payload)

    def _infer_image(self, file_path: str, mime_type: str) -> Optional[str]:
        path = Path(file_path)
        try:
            raw = path.read_bytes()
        except Exception:
            return None
        if len(raw) > MAX_IMAGE_BYTES:
            self.logger.warning(f"Image too large for inference: {file_path}")
            return None

        image_b64 = base64.b64encode(raw).decode("ascii")
        prompt = (
            "Descreva a imagem em português de forma clara e sucinta, "
            "indicando tema, elementos principais e provável contexto de uso."
        )
        payload = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "messages": [
                {"role": "system", "content": "Você descreve imagens para catalogação."},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{image_b64}"},
                        },
                    ],
                },
            ],
        }
        return self._post_chat(payload)

    def infer_file(self, file_path: str, details: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Infer concise content description for a file.

        Returns None when file should be ignored (binary/unsupported) or inference fails.
        """
        details = details or {}
        mime_type = str(details.get("mime_type_code") or "").strip()
        if not mime_type:
            mime_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

        if self._is_image(file_path, mime_type):
            return self._infer_image(file_path, mime_type)

        if self._is_data_file(file_path, mime_type):
            extracted = self._extract_text_for_inference(file_path)
            if not extracted:
                return None
            return self._infer_text(file_path, extracted)

        # Ignore binary/unsupported files.
        return None

