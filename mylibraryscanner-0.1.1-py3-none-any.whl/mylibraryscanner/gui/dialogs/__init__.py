"""GUI dialogs for MyLibraryScanner.

This module contains dialog windows for settings, about dialog,
and other modal interactions.
"""

from . import settings_dialog
from . import about_dialog

__all__ = [
    "settings_dialog",
    "about_dialog",
]