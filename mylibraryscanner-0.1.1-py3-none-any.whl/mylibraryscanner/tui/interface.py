"""TUI interface entry point for MyLibraryScanner.

This interface delegates command execution to the CLI layer but adds a
TUI-friendly shortcut where passing a direct path implies `scan <path>`.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Optional

from mylibraryscanner.cli.commands import run_library_infer_source, run_scan_target
from mylibraryscanner.cli.interface import build_parser, main as cli_main
from mylibraryscanner.initialization import setup_system


def _run_cli_with_args(args: list[str]) -> int:
    """Invoke CLI main with a temporary argv."""
    original_argv = sys.argv[:]
    try:
        sys.argv = [original_argv[0], *args]
        return cli_main()
    finally:
        sys.argv = original_argv


class _SimpleProgressBar:
    """Minimal progress bar renderer for TUI operations."""

    def __init__(self, label: str, width: int = 30):
        self.label = label
        self.width = width
        self.stream = sys.stderr
        self.interactive = bool(getattr(self.stream, "isatty", lambda: False)())
        self.finished = False

    def update(self, current: int, total: int) -> None:
        if self.finished or total <= 0:
            return

        current = min(max(current, 0), total)
        ratio = current / total if total else 0.0
        filled = int(self.width * ratio)
        bar = "#" * filled + "." * (self.width - filled)

        if self.interactive:
            self.stream.write(
                f"\r{self.label}: [{bar}] {current}/{total} ({ratio * 100:5.1f}%)"
            )
            self.stream.flush()
            if current >= total:
                self.finish()
            return

        step = max(1, total // 10)
        if current in {1, total} or current % step == 0:
            self.stream.write(f"{self.label}: {current}/{total} ({ratio * 100:5.1f}%)\n")
            self.stream.flush()
        if current >= total:
            self.finish()

    def finish(self) -> None:
        if self.finished:
            return
        if self.interactive:
            self.stream.write("\n")
            self.stream.flush()
        self.finished = True


def _print_json(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, indent=2, ensure_ascii=False))


def _looks_like_existing_path(value: str) -> bool:
    """Return True when value points to an existing file/folder path."""
    try:
        return Path(value).expanduser().exists()
    except Exception:
        return False


def _setup_system() -> bool:
    try:
        setup_system()
        return True
    except Exception as exc:
        print(f"CRITICAL: Failed to initialize system: {exc}")
        return False


def _execute_tui_scan(namespace: Any) -> int:
    if not _setup_system():
        return 1

    scan_progress = _SimpleProgressBar("Scan")
    infer_progress = _SimpleProgressBar("Infer") if namespace.infer else None

    result = run_scan_target(
        namespace.file_or_folder,
        source_mask=namespace.pattern,
        source_name=namespace.source_name,
        source_kind=namespace.source_kind,
        parallel=namespace.parallel,
        max_workers=namespace.max_workers,
        infer=namespace.infer,
        store=namespace.store,
        overwrite=namespace.overwrite,
        scan_progress_callback=scan_progress.update,
        infer_progress_callback=infer_progress.update if infer_progress else None,
    )

    scan_progress.finish()
    if infer_progress:
        infer_progress.finish()

    payload = result.get("payload") if isinstance(result, dict) else None
    tuning = payload.get("execution_tuning") if isinstance(payload, dict) else None
    if isinstance(tuning, dict) and tuning.get("parallel"):
        effective_workers = tuning.get("effective_max_workers")
        if tuning.get("tuning_applied"):
            print(
                (
                    "INFO: scan tuning applied: "
                    f"source_kind={tuning.get('source_kind')} "
                    f"requested={tuning.get('requested_max_workers')} "
                    f"effective={effective_workers} "
                    f"reason={tuning.get('tuning_reason')}"
                ),
                file=sys.stderr,
            )
        elif effective_workers is not None:
            print(
                f"INFO: parallel scan workers in use: {effective_workers}",
                file=sys.stderr,
            )

    if result["exit_code"] != 0:
        print(f"ERROR: {result.get('error', 'scan failed')}")
        if result.get("payload"):
            _print_json(result["payload"])
        return 1

    _print_json(result["payload"])
    return 0


def _execute_tui_infer_source(namespace: Any) -> int:
    if not _setup_system():
        return 1

    infer_progress = _SimpleProgressBar("Infer source")
    result = run_library_infer_source(
        namespace.source_name,
        progress_callback=infer_progress.update,
    )
    infer_progress.finish()

    if result["exit_code"] != 0:
        print(f"ERROR: {result.get('error', 'library infer_source failed')}")
        return 1

    _print_json(result["payload"])
    return 0


def _run_tui_with_progress(args: list[str]) -> Optional[int]:
    """Intercept selected modern commands and render progress in TUI."""
    if not args:
        return None

    known_commands = {"init", "scan", "library", "-h", "--help"}
    if args[0] not in known_commands:
        return None

    parser = build_parser()
    try:
        namespace = parser.parse_args(args)
    except SystemExit as exc:
        return int(exc.code)

    if namespace.command == "scan":
        return _execute_tui_scan(namespace)

    if namespace.command == "library" and namespace.library_command == "infer_source":
        return _execute_tui_infer_source(namespace)

    return None


def main() -> int:
    """Run the TUI entry point."""
    args = sys.argv[1:]
    if not args:
        return _run_cli_with_args(["--help"])

    # TUI shortcut: `mylibraryscanner-tui <path> [scan options]`
    if _looks_like_existing_path(args[0]):
        args = ["scan", *args]

    tui_result = _run_tui_with_progress(args)
    if tui_result is not None:
        return tui_result

    return _run_cli_with_args(args)


__all__ = ["main"]
