"""Text user interface entry points for MyLibraryScanner."""

from .interface import main

__all__ = ["main"]
