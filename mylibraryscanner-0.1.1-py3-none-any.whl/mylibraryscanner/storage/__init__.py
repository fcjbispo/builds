"""Storage and serialization for MyLibraryScanner.

This module provides data persistence capabilities including
JSON storage, pickle serialization, and report generation.
"""

# Storage modules will be implemented in Phase 3: Core Module Development