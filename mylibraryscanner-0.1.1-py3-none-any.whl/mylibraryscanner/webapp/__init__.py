"""Streamlit web interface for MyLibraryScanner."""

