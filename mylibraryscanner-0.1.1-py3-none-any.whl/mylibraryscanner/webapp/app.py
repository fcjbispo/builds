"""Streamlit web app for MyLibraryScanner."""

from __future__ import annotations

import argparse
import hashlib
import html
import io
import json
import os
import sys
import threading
import time
import traceback
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import pandas as pd
import streamlit as st
from sqlalchemy import func
from streamlit.web import cli as stcli

from mylibraryscanner.cli.commands import (
    cmd_init,
    cmd_library_update_source_kind,
    cmd_library_list_sources,
    cmd_library_remove_source,
    run_library_infer_source,
    run_scan_target,
)
from mylibraryscanner.core.llm_client import LLMClient
from mylibraryscanner.database.connection import DatabaseManager
from mylibraryscanner.database.models import Source, SourceFile
from mylibraryscanner.initialization import get_app_config, load_dotenv_defaults, setup_system


@dataclass
class BackgroundJob:
    job_id: str
    kind: str
    title: str
    status: str
    submitted_at: str
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


_JOB_EXECUTOR = ThreadPoolExecutor(max_workers=4, thread_name_prefix="mls-web")
_JOB_LOCK = threading.Lock()
_JOB_STORE: dict[str, BackgroundJob] = {}
_JOB_FUTURES: dict[str, Future] = {}
_THEME_LABELS = ("Claro suave", "Escuro suave")
_THEME_ENV_ALIASES = {
    "claro suave": "Claro suave",
    "light": "Claro suave",
    "light soft": "Claro suave",
    "claro": "Claro suave",
    "escuro suave": "Escuro suave",
    "dark": "Escuro suave",
    "dark soft": "Escuro suave",
    "escuro": "Escuro suave",
}


def _setup_once() -> None:
    signature = _config_runtime_signature()
    if (
        st.session_state.get("_mls_setup_done")
        and st.session_state.get("_mls_setup_signature") == signature
    ):
        return
    setup_system()
    st.session_state["_mls_setup_done"] = True
    st.session_state["_mls_setup_signature"] = signature


def _config_runtime_signature() -> str:
    """Build a lightweight signature for runtime config inputs."""
    project_root = Path(__file__).resolve().parent.parent.parent
    app_json_path = Path(__file__).resolve().parent.parent / "app.json"
    dotenv_paths = [Path.cwd() / ".env", project_root / ".env"]
    watched_paths = [app_json_path] + dotenv_paths

    path_state = []
    for path in watched_paths:
        if path.exists():
            stat = path.stat()
            path_state.append((str(path), stat.st_mtime_ns, stat.st_size))
        else:
            path_state.append((str(path), None, None))

    env_keys = (
        "FBNET_MYLIBRARYSCANNER_LLM_CHAT_MODEL",
        "FBNET_MYLIBRARYSCANNER_LLM_VISION_MODEL",
        "FBNET_MYLIBRARYSCANNER_LLM_EMBEDDING_MODEL",
        "FBNET_MYLIBRARYSCANNER_LLM_CHAT_BASE_URL",
        "FBNET_MYLIBRARYSCANNER_LLM_VISION_BASE_URL",
        "FBNET_MYLIBRARYSCANNER_LLM_EMBEDDING_BASE_URL",
    )
    env_state = {key: os.getenv(key, "") for key in env_keys}

    payload = {"paths": path_state, "env": env_state}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


def _resolve_dashboard_models(config: dict[str, Any]) -> tuple[str, str, str]:
    """Return effective CHAT/VISION/EMBEDDING model names for dashboard chips."""
    try:
        client = LLMClient()
        chat_model = client.resolve_profile("chat").model.strip() or "n/a"
        vision_model = client.resolve_profile("vision").model.strip() or chat_model
        embedding_model = client.resolve_profile("embedding").model.strip() or "n/a"
        return chat_model, vision_model, embedding_model
    except Exception:
        llm_model = str(config.get("llm_chat_model", "")).strip() or "n/a"
        vision_model = str(config.get("llm_vision_model", "")).strip() or llm_model
        embedding_model = str(config.get("llm_embedding_model", "")).strip() or "n/a"
        return llm_model, vision_model, embedding_model


def _theme_tokens(theme_label: str) -> dict[str, str]:
    """Return CSS tokens for supported UI themes."""
    if theme_label == "Escuro suave":
        return {
            "bg_1": "#182024",
            "bg_2": "#223038",
            "bg_3": "#141a1d",
            "surface": "#1e272c",
            "surface_alpha": "rgba(30, 39, 44, 0.92)",
            "text": "#ebf0ec",
            "muted": "#b5c1ba",
            "border": "rgba(223, 232, 227, 0.26)",
            "accent": "#7cc2ad",
            "accent_soft": "#2a4b42",
            "chip_text": "#daf3ea",
            "button_bg": "#7cc2ad",
            "button_text": "#10241d",
            "button_border": "#5ca18d",
            "button_hover": "#91d1bd",
            "field_bg": "#263136",
            "field_text": "#ecf3ef",
            "field_border": "#4d5d66",
        }

    return {
        "bg_1": "#f4efe7",
        "bg_2": "#dce7df",
        "bg_3": "#f8f5ef",
        "surface": "#fcfaf6",
        "surface_alpha": "rgba(252, 250, 246, 0.92)",
        "text": "#18221f",
        "muted": "#5f6f68",
        "border": "rgba(24, 34, 31, 0.18)",
        "accent": "#2f8f78",
        "accent_soft": "#d7eee6",
        "chip_text": "#17473c",
        "button_bg": "#2f8f78",
        "button_text": "#f7fffc",
        "button_border": "#257360",
        "button_hover": "#2a7f6a",
        "field_bg": "#ffffff",
        "field_text": "#18221f",
        "field_border": "#9baea6",
    }


def _default_theme_from_env() -> str:
    """Resolve initial theme from environment variables."""
    raw_theme = _get_env_first(
        "FBNET_MYLIBRARYSCANNER_WEB_THEME",
        "MYLIBRARYSCANNER_WEB_THEME",
        default="",
    )
    if not raw_theme:
        return _THEME_LABELS[0]

    cleaned = raw_theme.strip()
    if cleaned in _THEME_LABELS:
        return cleaned

    normalized = cleaned.lower().replace("-", " ").replace("_", " ")
    normalized = " ".join(normalized.split())
    return _THEME_ENV_ALIASES.get(normalized, _THEME_LABELS[0])


def _style(theme_label: str) -> None:
    tokens = _theme_tokens(theme_label)
    css = "\n".join(
        [
            "<style>",
            ":root {",
            f'    --mls-bg-1: {tokens["bg_1"]};',
            f'    --mls-bg-2: {tokens["bg_2"]};',
            f'    --mls-bg-3: {tokens["bg_3"]};',
            f'    --mls-surface: {tokens["surface"]};',
            f'    --mls-surface-alpha: {tokens["surface_alpha"]};',
            f'    --mls-text: {tokens["text"]};',
            f'    --mls-muted: {tokens["muted"]};',
            f'    --mls-border: {tokens["border"]};',
            f'    --mls-accent: {tokens["accent"]};',
            f'    --mls-accent-soft: {tokens["accent_soft"]};',
            f'    --mls-chip-text: {tokens["chip_text"]};',
            f'    --mls-button-bg: {tokens["button_bg"]};',
            f'    --mls-button-text: {tokens["button_text"]};',
            f'    --mls-button-border: {tokens["button_border"]};',
            f'    --mls-button-hover: {tokens["button_hover"]};',
            f'    --mls-field-bg: {tokens["field_bg"]};',
            f'    --mls-field-text: {tokens["field_text"]};',
            f'    --mls-field-border: {tokens["field_border"]};',
            "}",
            ".stApp {",
            "    background: radial-gradient(90rem 50rem at -10% -10%, var(--mls-bg-2), transparent),",
            "                radial-gradient(90rem 50rem at 110% 110%, var(--mls-bg-3), transparent),",
            "                linear-gradient(135deg, var(--mls-bg-1), var(--mls-bg-3));",
            "    color: var(--mls-text);",
            "}",
            ".stApp, .stApp p, .stApp label, .stApp span, .stApp li {",
            "    color: var(--mls-text);",
            "}",
            ".block-container { padding-top: 1.5rem; padding-bottom: 1.2rem; }",
            "[data-testid=\"stSidebar\"] {",
            "    border-right: 1px solid var(--mls-border);",
            "    background: var(--mls-surface-alpha);",
            "    backdrop-filter: blur(4px);",
            "}",
            ".mls-card {",
            "    border: 1px solid var(--mls-border);",
            "    border-radius: 14px;",
            "    padding: 14px 16px;",
            "    background: var(--mls-surface);",
            "}",
            ".mls-chip {",
            "    display: inline-block;",
            "    border: 1px solid var(--mls-border);",
            "    border-radius: 999px;",
            "    padding: 2px 10px;",
            "    background: var(--mls-accent-soft);",
            "    color: var(--mls-chip-text);",
            "    font-size: .82rem;",
            "    font-weight: 600;",
            "    margin-right: 8px;",
            "}",
            "[data-testid=\"stWidgetLabel\"], [data-testid=\"stWidgetLabel\"] * {",
            "    color: var(--mls-text) !important;",
            "    font-weight: 600;",
            "}",
            ".stButton > button, [data-testid=\"stFormSubmitButton\"] > button {",
            "    background: var(--mls-button-bg) !important;",
            "    color: var(--mls-button-text) !important;",
            "    border: 1px solid var(--mls-button-border) !important;",
            "    border-radius: 10px;",
            "}",
            ".stButton > button:hover, [data-testid=\"stFormSubmitButton\"] > button:hover {",
            "    background: var(--mls-button-hover) !important;",
            "}",
            "[data-baseweb=\"input\"] input,",
            "[data-baseweb=\"textarea\"] textarea,",
            "[data-baseweb=\"select\"] > div,",
            ".stTextInput input,",
            ".stTextArea textarea {",
            "    background: var(--mls-field-bg) !important;",
            "    color: var(--mls-field-text) !important;",
            "    border-color: var(--mls-field-border) !important;",
            "}",
            ".stRadio label, .stCheckbox label {",
            "    color: var(--mls-text) !important;",
            "}",
            ".stMarkdown, .stText, .stCaption, .stMetric {",
            '    font-family: "IBM Plex Sans", "Source Sans 3", "Segoe UI", sans-serif;',
            "}",
            "h1, h2, h3 {",
            '    font-family: "Space Grotesk", "Avenir Next", "Segoe UI", sans-serif;',
            "    letter-spacing: .2px;",
            "}",
            "</style>",
        ]
    )
    st.markdown(css, unsafe_allow_html=True)


def _run_action(fn: Callable[..., int], *args: Any, **kwargs: Any) -> dict[str, Any]:
    out = io.StringIO()
    err = io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        code = fn(*args, **kwargs)
    stdout = out.getvalue().strip()
    stderr = err.getvalue().strip()
    payload = _extract_json_payload(stdout)
    return {
        "exit_code": code,
        "stdout": stdout,
        "stderr": stderr,
        "json": payload,
    }


def _extract_json_payload(text: str) -> Optional[dict[str, Any]]:
    if not text:
        return None
    try:
        loaded = json.loads(text)
        return loaded if isinstance(loaded, dict) else None
    except Exception:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < 0 or end <= start:
        return None
    chunk = text[start : end + 1]
    try:
        loaded = json.loads(chunk)
        return loaded if isinstance(loaded, dict) else None
    except Exception:
        return None


def _show_action_result(result: dict[str, Any], success_msg: str) -> None:
    if result["exit_code"] == 0:
        st.success(success_msg)
    else:
        st.error(f"Falha (exit_code={result['exit_code']}).")

    if result["json"] is not None:
        st.json(result["json"])
    else:
        if result["stdout"]:
            st.code(result["stdout"], language="text")
    if result["stderr"]:
        st.caption("stderr")
        st.code(result["stderr"], language="text")


def _get_env_first(*names: str, default: str = "") -> str:
    """Return first non-empty environment value from ordered names."""
    for name in names:
        value = os.getenv(name)
        if value is not None and str(value).strip():
            return str(value).strip()
    return default


def _get_env_int(*names: str, default: int) -> int:
    """Return first valid integer environment value from ordered names."""
    raw = _get_env_first(*names, default="")
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _enqueue_job(kind: str, title: str, fn: Callable[..., Dict[str, Any]], **kwargs: Any) -> str:
    job_id = uuid.uuid4().hex[:12]
    now = datetime.now().isoformat()
    job = BackgroundJob(
        job_id=job_id,
        kind=kind,
        title=title,
        status="queued",
        submitted_at=now,
    )
    with _JOB_LOCK:
        _JOB_STORE[job_id] = job

    def runner() -> None:
        with _JOB_LOCK:
            entry = _JOB_STORE[job_id]
            entry.status = "running"
            entry.started_at = datetime.now().isoformat()
        try:
            result = fn(**kwargs)
            with _JOB_LOCK:
                entry = _JOB_STORE[job_id]
                entry.result = result
                entry.status = "success" if result.get("exit_code", 1) == 0 else "failed"
                entry.ended_at = datetime.now().isoformat()
                if result.get("error"):
                    entry.error = str(result["error"])
        except Exception as exc:
            with _JOB_LOCK:
                entry = _JOB_STORE[job_id]
                entry.status = "failed"
                entry.error = f"{exc}\n{traceback.format_exc()}"
                entry.ended_at = datetime.now().isoformat()

    future = _JOB_EXECUTOR.submit(runner)
    with _JOB_LOCK:
        _JOB_FUTURES[job_id] = future
    return job_id


def _list_jobs() -> list[BackgroundJob]:
    with _JOB_LOCK:
        return list(_JOB_STORE.values())


def _active_jobs_count() -> int:
    with _JOB_LOCK:
        return sum(1 for job in _JOB_STORE.values() if job.status in {"queued", "running"})


def _clear_finished_jobs() -> None:
    with _JOB_LOCK:
        to_remove = [job_id for job_id, job in _JOB_STORE.items() if job.status in {"success", "failed"}]
        for job_id in to_remove:
            _JOB_STORE.pop(job_id, None)
            _JOB_FUTURES.pop(job_id, None)


def _render_jobs_panel(context_key: str) -> None:
    st.markdown("---")
    st.caption("Background jobs")
    col1, col2, col3 = st.columns([0.45, 0.30, 0.25], vertical_alignment="center")
    with col1:
        st.write(f"Active jobs: **{_active_jobs_count()}**")
    with col2:
        auto_refresh = st.checkbox(
            "Auto refresh",
            value=st.session_state.get(f"{context_key}_auto_refresh", True),
            key=f"{context_key}_auto_refresh",
        )
    with col3:
        if st.button("Clear finished", key=f"{context_key}_clear_jobs"):
            _clear_finished_jobs()
            st.rerun()

    if st.button("Refresh now", key=f"{context_key}_refresh_jobs"):
        st.rerun()

    jobs = sorted(_list_jobs(), key=lambda x: x.submitted_at, reverse=True)
    if not jobs:
        st.info("No jobs in queue.")
    else:
        table = [
            {
                "job_id": j.job_id,
                "kind": j.kind,
                "title": j.title,
                "status": j.status,
                "submitted_at": j.submitted_at,
                "started_at": j.started_at,
                "ended_at": j.ended_at,
            }
            for j in jobs
        ]
        st.dataframe(table, use_container_width=True, hide_index=True)

        for job in jobs[:5]:
            with st.expander(f"{job.job_id} · {job.title} · {job.status}", expanded=False):
                if job.error:
                    st.error(job.error)
                if job.result:
                    if job.result.get("payload") is not None:
                        st.json(job.result["payload"])
                    else:
                        st.json(job.result)

    if auto_refresh and _active_jobs_count() > 0:
        time.sleep(2)
        st.rerun()


def _render_dashboard() -> None:
    st.subheader("Overview")
    cfg = get_app_config()
    app_cfg = cfg.get("app", {})
    config = cfg.get("config", {})
    c1, c2, c3 = st.columns(3)
    c1.metric("App", app_cfg.get("name", "MyLibraryScanner"))
    c2.metric("Version", str(app_cfg.get("version", "0.1.0")))
    c3.metric("Schema", str(config.get("system_db_schema", "")))
    llm_model, vision_model, embedding_model = _resolve_dashboard_models(config)
    chips = (
        '<div class="mls-card"><span class="mls-chip">Streamlit UI</span>'
        '<span class="mls-chip">CLI/TUI parity</span>'
        '<span class="mls-chip">Inference-ready</span>'
        f'<span class="mls-chip">Chat: {html.escape(llm_model)}</span>'
        f'<span class="mls-chip">Vision: {html.escape(vision_model)}</span>'
        f'<span class="mls-chip">Embeddings: {html.escape(embedding_model)}</span>'
        "</div>"
    )
    st.markdown(chips, unsafe_allow_html=True)
    st.caption(
        "Modelos exibidos sao os valores efetivos de runtime "
        "(precedencia: variaveis exportadas > .env > app.json)."
    )

    st.markdown("---")
    st.markdown("### Library Metrics")

    try:
        stats = _load_overview_stats()
    except Exception as exc:
        st.warning(f"Não foi possível carregar métricas do banco: {exc}")
        return

    by_kind = stats["sources_by_kind"]
    total_files = stats["total_files"]
    inferred_files = stats["inferred_files"]
    inference_ratio = (inferred_files / total_files * 100.0) if total_files else 0.0

    metrics_cols = st.columns(5)
    metrics_cols[0].metric("Total sources", str(stats["total_sources"]))
    metrics_cols[1].metric("LOCAL", str(by_kind.get("LOCAL", 0)))
    metrics_cols[2].metric("REMOVABLE", str(by_kind.get("REMOVABLE", 0)))
    metrics_cols[3].metric("REMOTE", str(by_kind.get("REMOTE", 0)))
    metrics_cols[4].metric(
        "Inference files",
        f"{inferred_files}/{total_files}",
        delta=f"{inference_ratio:.1f}%",
    )

    st.markdown("#### Arquivos por Source")
    files_by_source = stats["files_by_source"]
    if not files_by_source:
        st.info("Sem dados de arquivos por source.")
    else:
        df_source = pd.DataFrame(files_by_source)
        st.bar_chart(df_source.set_index("source_name")["files_total"], use_container_width=True)

    st.markdown("#### Arquivos por Source Type")
    files_by_source_type = stats["files_by_source_type"]
    if not files_by_source_type:
        st.info("Sem dados de arquivos por source type.")
    else:
        df_source_type = pd.DataFrame(files_by_source_type)
        st.bar_chart(
            df_source_type.set_index("source_kind")["files_total"],
            use_container_width=True,
        )

    st.markdown("#### Arquivos por Mimetype")
    files_by_type = stats["files_by_type"]
    if not files_by_type:
        st.info("Sem dados de arquivos por mimetype.")
    else:
        df_type = pd.DataFrame(files_by_type)
        st.bar_chart(df_type.set_index("file_type")["files_total"], use_container_width=True)


def _build_db_manager() -> DatabaseManager:
    """Create database manager honoring FBNET and compatibility env overrides."""
    db_url = _get_env_first(
        "FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL",
        "MYLIBRARYSCANNER_SYSTEM_DB_URL",
        "SYSTEM_DB_URL",
    )
    db_schema = _get_env_first(
        "FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA",
        "MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA",
        "DB_SCHEMA",
        "SYSTEM_DB_SCHEMA",
    )
    return DatabaseManager(
        schema=db_schema or None,
        database_url=db_url or None,
    )


def _load_source_names() -> list[str]:
    """Load source names ordered alphabetically for UI selectors."""
    db_manager = _build_db_manager()
    with db_manager.get_session() as session:
        rows = session.query(Source.source_name).order_by(Source.source_name.asc()).all()
    return [str(name) for (name,) in rows if name]


def _load_source_files_for_source(source_name: str) -> list[Dict[str, Any]]:
    """Load all source files for a given source name with display and full JSON payload."""
    db_manager = _build_db_manager()
    with db_manager.get_session() as session:
        source = session.query(Source).filter(Source.source_name == source_name).first()
        if not source:
            return []

        files = (
            session.query(SourceFile)
            .filter(SourceFile.source_id == source.id)
            .order_by(SourceFile.file_path.asc())
            .all()
        )

    rows: list[Dict[str, Any]] = []
    for file_row in files:
        details = file_row.details if isinstance(file_row.details, dict) else {}
        inference_value = file_row.inference or ""
        has_inference = bool(inference_value.strip())
        processed_at = (
            file_row.processed_at.isoformat()
            if getattr(file_row, "processed_at", None)
            else None
        )
        size_raw = details.get("size_bytes")
        size_bytes = int(size_raw) if isinstance(size_raw, (int, float)) else None

        full_json = {
            "id": str(file_row.id),
            "source_id": str(file_row.source_id),
            "source_name": source_name,
            "file_path": file_row.file_path,
            "status": file_row.status,
            "status_message": file_row.status_message,
            "inference": file_row.inference,
            "md5sum": file_row.md5sum,
            "processed_at": processed_at,
            "details": details,
        }

        rows.append(
            {
                "id": str(file_row.id),
                "file_path": file_row.file_path,
                "status": file_row.status,
                "status_message": file_row.status_message or "",
                "mime_type": str(details.get("mime_type_code", "") or ""),
                "extension": str(details.get("extension", "") or ""),
                "size_bytes": size_bytes,
                "md5sum": file_row.md5sum or "",
                "has_inference": has_inference,
                "processed_at": processed_at or "",
                "_full_json": full_json,
            }
        )

    return rows


def _extract_selected_row_indexes(table_state: Any) -> list[int]:
    """Extract selected row indexes from Streamlit dataframe selection state."""
    if table_state is None:
        return []
    if isinstance(table_state, dict):
        selection = table_state.get("selection", {})
        rows = selection.get("rows", [])
        return [int(i) for i in rows] if isinstance(rows, list) else []

    selection = getattr(table_state, "selection", None)
    if selection is None:
        return []
    if isinstance(selection, dict):
        rows = selection.get("rows", [])
        return [int(i) for i in rows] if isinstance(rows, list) else []
    rows = getattr(selection, "rows", [])
    return [int(i) for i in rows] if isinstance(rows, list) else []


def _source_state_prefix(source_name: str) -> str:
    """Build deterministic per-source widget key prefix."""
    normalized = "".join(ch if ch.isalnum() else "_" for ch in source_name.lower()).strip("_")
    digest = hashlib.sha1(source_name.encode("utf-8")).hexdigest()[:8]
    if not normalized:
        normalized = "source"
    return f"source_files_{normalized[:48]}_{digest}"


def _load_overview_stats() -> Dict[str, Any]:
    """Load aggregated metrics for Overview dashboard from database."""
    db_manager = _build_db_manager()

    with db_manager.get_session() as session:
        total_sources = session.query(func.count(Source.id)).scalar() or 0
        total_files = session.query(func.count(SourceFile.id)).scalar() or 0

        inferred_expr = func.length(func.btrim(func.coalesce(SourceFile.inference, ""))) > 0
        inferred_files = (
            session.query(func.count(SourceFile.id))
            .filter(inferred_expr)
            .scalar()
            or 0
        )

        sources_by_kind_rows = (
            session.query(Source.source_kind, func.count(Source.id).label("count"))
            .group_by(Source.source_kind)
            .all()
        )
        sources_by_kind = {str(kind): int(count) for kind, count in sources_by_kind_rows if kind}

        files_by_source_rows = (
            session.query(
                Source.source_name.label("source_name"),
                func.count(SourceFile.id).label("files_total"),
            )
            .outerjoin(SourceFile, SourceFile.source_id == Source.id)
            .group_by(Source.id, Source.source_name)
            .order_by(func.count(SourceFile.id).desc(), Source.source_name.asc())
            .all()
        )
        files_by_source = [
            {
                "source_name": str(source_name),
                "files_total": int(files_total_count),
            }
            for source_name, files_total_count in files_by_source_rows[:25]
        ]

        files_by_source_type_rows = (
            session.query(
                Source.source_kind.label("source_kind"),
                func.count(SourceFile.id).label("files_total"),
            )
            .outerjoin(SourceFile, SourceFile.source_id == Source.id)
            .group_by(Source.source_kind)
            .order_by(func.count(SourceFile.id).desc(), Source.source_kind.asc())
            .all()
        )
        files_by_source_type = [
            {
                "source_kind": str(source_kind),
                "files_total": int(files_total_count),
            }
            for source_kind, files_total_count in files_by_source_type_rows
            if source_kind
        ]

        file_type_expr = func.coalesce(
            func.nullif(SourceFile.details["mime_type_code"].astext, ""),
            func.nullif(SourceFile.details["extension"].astext, ""),
            "UNKNOWN",
        )
        files_by_type_rows = (
            session.query(
                file_type_expr.label("file_type"),
                func.count(SourceFile.id).label("files_total"),
            )
            .group_by(file_type_expr)
            .order_by(func.count(SourceFile.id).desc())
            .all()
        )
        files_by_type = [
            {
                "file_type": str(file_type),
                "files_total": int(files_total_count),
            }
            for file_type, files_total_count in files_by_type_rows[:25]
        ]

    return {
        "total_sources": int(total_sources),
        "total_files": int(total_files),
        "inferred_files": int(inferred_files),
        "sources_by_kind": sources_by_kind,
        "files_by_source": files_by_source,
        "files_by_source_type": files_by_source_type,
        "files_by_type": files_by_type,
    }


def _render_init() -> None:
    st.subheader("Initialize")
    if st.button("Run init", type="primary"):
        result = _run_action(cmd_init)
        _show_action_result(result, "Init executado com sucesso.")


def _recommended_scan_workers(source_kind: str) -> int:
    """Return conservative worker recommendation by source kind."""
    return 2 if str(source_kind).strip().upper() == "REMOVABLE" else 4


def _render_scan() -> None:
    st.subheader("Scan")
    with st.form("scan_form"):
        file_or_folder = st.text_input("Path (arquivo ou pasta)", value=".")
        col1, col2 = st.columns(2)
        with col1:
            source_mask = st.text_input("Pattern", value="*")
            source_name = st.text_input("Source name (opcional)", value="")
            source_kind = st.selectbox(
                "Source kind",
                options=["LOCAL", "REMOVABLE", "REMOTE"],
                index=0,
                key="scan_source_kind",
            )
        with col2:
            parallel = st.checkbox("Parallel scan", value=False)
            recommended_workers = _recommended_scan_workers(source_kind)
            if st.session_state.get("_scan_workers_kind") != source_kind:
                st.session_state["scan_max_workers"] = recommended_workers
                st.session_state["_scan_workers_kind"] = source_kind
            max_workers = st.number_input(
                "Max workers",
                min_value=1,
                max_value=64,
                value=int(st.session_state.get("scan_max_workers", recommended_workers)),
                step=1,
                key="scan_max_workers",
            )
            infer = st.checkbox("Infer content", value=False)
            store = st.checkbox("Store in database", value=False)
            overwrite = st.checkbox("Overwrite existing source", value=False)
            if source_kind == "REMOVABLE":
                st.caption("Removable profile: recommended max workers is 2 for HDD/USB stability.")
        submitted = st.form_submit_button("Run scan", type="primary")

    if submitted:
        job_id = _enqueue_job(
            kind="scan",
            title=f"scan:{source_name.strip() or file_or_folder}",
            fn=run_scan_target,
            file_or_folder=file_or_folder,
            source_mask=source_mask or "*",
            source_name=source_name.strip() or None,
            source_kind=source_kind,
            parallel=parallel,
            max_workers=int(max_workers),
            infer=infer,
            store=store,
            overwrite=overwrite,
        )
        st.success(f"Scan enfileirado (job_id={job_id}).")

    _render_jobs_panel("scan")


def _render_library() -> None:
    st.subheader("Library")
    try:
        source_names = _load_source_names()
    except Exception as exc:
        st.warning(f"Não foi possível carregar a lista de sources: {exc}")
        source_names = []

    tabs = st.tabs(["List Sources", "Remove Source", "Update Source Kind", "Infer Source", "Source Files"])

    with tabs[0]:
        pattern = st.text_input("Pattern", value="*", key="lib_pattern")
        if st.button("Load sources", key="btn_list_sources", type="primary"):
            result = _run_action(cmd_library_list_sources, pattern=pattern)
            if result["exit_code"] == 0:
                payload = result.get("json") or {}
                items = payload.get("items") or []
                st.success(f"Total: {len(items)}")
                if items:
                    st.dataframe(items, use_container_width=True, hide_index=True)
                st.json(payload)
            else:
                _show_action_result(result, "Listagem executada.")

    with tabs[1]:
        source_name = st.selectbox(
            "Source name",
            options=source_names,
            index=None,
            placeholder="Selecione um source",
            key="remove_source_name_select",
        )
        if not source_names:
            st.info("Nenhum source disponível para remoção.")
        confirm = st.checkbox("Confirmar remoção", key="remove_confirm")
        if st.button(
            "Remove source",
            key="btn_remove_source",
            type="secondary",
            disabled=not source_names,
        ):
            if not source_name:
                st.warning("Informe o source name.")
            elif not confirm:
                st.warning("Marque a confirmação para remover.")
            else:
                result = _run_action(
                    cmd_library_remove_source,
                    source_name=source_name,
                    assume_yes=True,
                )
                _show_action_result(result, "Source removido com sucesso.")

    with tabs[2]:
        source_name = st.selectbox(
            "Source name",
            options=source_names,
            index=None,
            placeholder="Selecione um source",
            key="update_kind_source_name_select",
        )
        source_kind = st.selectbox(
            "New source kind",
            options=["LOCAL", "REMOVABLE", "REMOTE"],
            index=0,
            key="update_kind_target_kind_select",
        )
        if not source_names:
            st.info("Nenhum source disponível para atualização de tipo.")
        if st.button(
            "Update source kind",
            key="btn_update_source_kind",
            type="primary",
            disabled=not source_names,
        ):
            if not source_name:
                st.warning("Informe o source name.")
            else:
                result = _run_action(
                    cmd_library_update_source_kind,
                    source_name=source_name,
                    source_kind=source_kind,
                )
                _show_action_result(result, "Tipo do source atualizado com sucesso.")

    with tabs[3]:
        source_name = st.selectbox(
            "Source name",
            options=source_names,
            index=None,
            placeholder="Selecione um source",
            key="infer_source_name_select",
        )
        if not source_names:
            st.info("Nenhum source disponível para inferência.")
        if st.button(
            "Infer source",
            key="btn_infer_source",
            type="primary",
            disabled=not source_names,
        ):
            if not source_name:
                st.warning("Informe o source name.")
            else:
                job_id = _enqueue_job(
                    kind="infer_source",
                    title=f"infer:{source_name}",
                    fn=run_library_infer_source,
                    source_name=source_name,
                )
                st.success(f"Inferência enfileirada (job_id={job_id}).")

    with tabs[4]:
        source_name = st.selectbox(
            "Source name",
            options=source_names,
            index=None,
            placeholder="Selecione um source",
            key="source_files_source_select",
        )
        if not source_names:
            st.info("Nenhum source disponível para exibir arquivos.")
        elif not source_name:
            st.info("Selecione um source para carregar os arquivos escaneados.")
        else:
            state_prefix = _source_state_prefix(source_name)
            try:
                rows = _load_source_files_for_source(source_name)
            except Exception as exc:
                st.error(f"Falha ao carregar arquivos do source: {exc}")
                rows = []

            if not rows:
                st.info("Este source não possui arquivos.")
            else:
                df = pd.DataFrame(rows)

                st.markdown("##### Pesquisa e filtros")
                fcol1, fcol2, fcol3, fcol4 = st.columns(4)
                with fcol1:
                    search_term = st.text_input(
                        "Pesquisa (texto)",
                        value="",
                        key=f"{state_prefix}_search_term",
                    ).strip()
                with fcol2:
                    search_fields = st.multiselect(
                        "Campos para pesquisa",
                        options=[
                            "file_path",
                            "status",
                            "status_message",
                            "mime_type",
                            "extension",
                            "md5sum",
                        ],
                        default=["file_path", "mime_type", "extension", "status"],
                        key=f"{state_prefix}_search_fields",
                    )
                with fcol3:
                    status_options = sorted(v for v in df["status"].dropna().unique().tolist() if v)
                    status_filter = st.multiselect(
                        "Filtro status",
                        options=status_options,
                        default=[],
                        key=f"{state_prefix}_status_filter",
                    )
                with fcol4:
                    inference_filter = st.selectbox(
                        "Filtro inference",
                        options=["Todos", "Com inference", "Sem inference"],
                        index=0,
                        key=f"{state_prefix}_inference_filter",
                    )

                fcol5, fcol6, fcol7, fcol8 = st.columns(4)
                with fcol5:
                    mime_options = sorted(v for v in df["mime_type"].dropna().unique().tolist() if v)
                    mime_filter = st.multiselect(
                        "Filtro MIME",
                        options=mime_options,
                        default=[],
                        key=f"{state_prefix}_mime_filter",
                    )
                with fcol6:
                    ext_options = sorted(v for v in df["extension"].dropna().unique().tolist() if v)
                    ext_filter = st.multiselect(
                        "Filtro extensão",
                        options=ext_options,
                        default=[],
                        key=f"{state_prefix}_ext_filter",
                    )
                with fcol7:
                    sort_column = st.selectbox(
                        "Ordenar por",
                        options=[
                            "file_path",
                            "status",
                            "mime_type",
                            "extension",
                            "size_bytes",
                            "processed_at",
                            "has_inference",
                        ],
                        index=0,
                        key=f"{state_prefix}_sort_column",
                    )
                with fcol8:
                    sort_desc = st.checkbox(
                        "Descendente",
                        value=False,
                        key=f"{state_prefix}_sort_desc",
                    )

                filtered_df = df.copy()
                if search_term and search_fields:
                    search_mask = pd.Series(False, index=filtered_df.index)
                    for field in search_fields:
                        search_mask = search_mask | filtered_df[field].astype(str).str.contains(
                            search_term,
                            case=False,
                            na=False,
                        )
                    filtered_df = filtered_df[search_mask]

                if status_filter:
                    filtered_df = filtered_df[filtered_df["status"].isin(status_filter)]
                if mime_filter:
                    filtered_df = filtered_df[filtered_df["mime_type"].isin(mime_filter)]
                if ext_filter:
                    filtered_df = filtered_df[filtered_df["extension"].isin(ext_filter)]
                if inference_filter == "Com inference":
                    filtered_df = filtered_df[filtered_df["has_inference"]]
                elif inference_filter == "Sem inference":
                    filtered_df = filtered_df[~filtered_df["has_inference"]]

                filtered_df = filtered_df.sort_values(
                    by=sort_column,
                    ascending=not sort_desc,
                    kind="stable",
                )

                total_items = int(len(filtered_df))
                pcol1, pcol2, pcol3 = st.columns(3)
                with pcol1:
                    page_size = st.selectbox(
                        "Itens por página",
                        options=[10, 25, 50, 100, 200],
                        index=1,
                        key=f"{state_prefix}_page_size",
                    )
                total_pages = max(1, (total_items + int(page_size) - 1) // int(page_size))
                page_key = f"{state_prefix}_page"
                current_page = int(st.session_state.get(page_key, 1))
                if current_page < 1:
                    st.session_state[page_key] = 1
                elif current_page > total_pages:
                    st.session_state[page_key] = total_pages
                with pcol2:
                    page = st.number_input(
                        "Página",
                        min_value=1,
                        max_value=total_pages,
                        value=int(st.session_state.get(page_key, 1)),
                        step=1,
                        key=page_key,
                    )
                with pcol3:
                    st.metric("Resultados", str(total_items))

                start = (int(page) - 1) * int(page_size)
                end = start + int(page_size)
                page_df = filtered_df.iloc[start:end].copy()
                page_display_df = page_df[
                    [
                        "file_path",
                        "status",
                        "mime_type",
                        "extension",
                        "size_bytes",
                        "has_inference",
                        "processed_at",
                    ]
                ]

                table_state = st.dataframe(
                    page_display_df,
                    use_container_width=True,
                    hide_index=True,
                    on_select="rerun",
                    selection_mode="single-row",
                    key=f"{state_prefix}_table",
                )
                st.caption(f"Página {int(page)} de {total_pages}")

                selected_rows = _extract_selected_row_indexes(table_state)
                if selected_rows:
                    selected_index = selected_rows[0]
                    if 0 <= selected_index < len(page_df):
                        selected_json = page_df.iloc[selected_index]["_full_json"]
                        st.markdown("##### Arquivo selecionado (JSON completo)")
                        st.json(selected_json)
                else:
                    st.info("Clique em uma linha da tabela para exibir o JSON completo do arquivo.")

    _render_jobs_panel("library")


def render_app() -> None:
    st.set_page_config(
        page_title="MyLibraryScanner Web",
        page_icon="🗂️",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    initial_theme = _default_theme_from_env()
    active_theme = str(st.session_state.get("_mls_active_theme", initial_theme))
    if active_theme not in _THEME_LABELS:
        active_theme = initial_theme
    _style(active_theme)
    try:
        _setup_once()
    except Exception as exc:
        st.error(f"Falha ao inicializar sistema: {exc}")
        st.stop()

    st.sidebar.title("MyLibraryScanner")
    st.sidebar.caption("Streamlit Web UI")
    selected_theme = st.sidebar.selectbox(
        "Tema",
        list(_THEME_LABELS),
        index=_THEME_LABELS.index(active_theme),
        help="Altere o contraste visual para melhorar legibilidade em desktop e mobile.",
    )
    if selected_theme != active_theme:
        st.session_state["_mls_active_theme"] = selected_theme
        st.rerun()

    page = st.sidebar.radio(
        "Menu",
        ["Overview", "Initialize", "Scan", "Library"],
        index=0,
    )

    if page == "Overview":
        _render_dashboard()
    elif page == "Initialize":
        _render_init()
    elif page == "Scan":
        _render_scan()
    elif page == "Library":
        _render_library()


def _build_webapp_parser() -> argparse.ArgumentParser:
    """Build argument parser for web app launcher options."""
    parser = argparse.ArgumentParser(
        prog="mylibraryscanner-webapp",
        description="Start MyLibraryScanner Streamlit web UI.",
    )
    parser.add_argument(
        "--host",
        default=_get_env_first(
            "FBNET_MYLIBRARYSCANNER_WEB_HOST",
            "MYLIBRARYSCANNER_WEB_HOST",
            default="127.0.0.1",
        ),
        help="Host address for Streamlit server (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=_get_env_int(
            "FBNET_MYLIBRARYSCANNER_WEB_PORT",
            "MYLIBRARYSCANNER_WEB_PORT",
            default=8501,
        ),
        help="Port for Streamlit server (default: 8501).",
    )
    return parser


def _parse_webapp_args(args: Optional[list[str]] = None) -> argparse.Namespace:
    """Parse and validate launcher args for web app."""
    namespace = _build_webapp_parser().parse_args(args)
    if namespace.port < 1 or namespace.port > 65535:
        raise SystemExit("ERROR: --port must be between 1 and 65535")
    return namespace


def main() -> None:
    """Console entrypoint for `mylibraryscanner-webapp`."""
    load_dotenv_defaults()
    args = _parse_webapp_args(sys.argv[1:])
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    sys.argv = [
        "streamlit",
        "run",
        __file__,
        "--server.address",
        str(args.host),
        "--server.port",
        str(args.port),
    ]
    raise SystemExit(stcli.main())


if __name__ == "__main__":
    render_app()
