"""Metadata enrichment orchestration service."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from mylibraryscanner.core.metadata_enrichment.archives import extract_archive_metadata
from mylibraryscanner.core.metadata_enrichment.audio_video import extract_audio_video_metadata
from mylibraryscanner.core.metadata_enrichment.documents import extract_document_metadata
from mylibraryscanner.core.metadata_enrichment.image import extract_image_metadata
from mylibraryscanner.initialization import get_logger_instance


_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}
_AUDIO_VIDEO_EXTENSIONS = {
    ".mp3",
    ".wav",
    ".flac",
    ".ogg",
    ".m4a",
    ".aac",
    ".mp4",
    ".mkv",
    ".mov",
    ".avi",
    ".webm",
}
_DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".doc",
    ".docx",
    ".docm",
    ".xls",
    ".xlsx",
    ".xlsm",
    ".ppt",
    ".pptx",
    ".pptm",
    ".odt",
    ".ods",
    ".odp",
}
_ARCHIVE_EXTENSIONS = {".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".7z", ".rar"}


class MetadataEnrichmentService:
    """Apply specialized metadata extraction based on MIME/extension."""

    def __init__(self) -> None:
        self.logger = get_logger_instance()

    def enrich_file(self, file_path: str, mime_type: Optional[str]) -> Dict[str, Any]:
        ext = Path(file_path).suffix.lower()
        mime = (mime_type or "").strip().lower()
        category = self._resolve_category(ext, mime)
        if not category:
            return {}

        try:
            if category == "image":
                data = extract_image_metadata(file_path)
            elif category == "audio_video":
                data = extract_audio_video_metadata(file_path)
            elif category == "document":
                data = extract_document_metadata(file_path, mime)
            else:
                data = extract_archive_metadata(file_path)
        except Exception as exc:
            self.logger.warning(
                "Metadata enrichment failed for %s (%s): %s",
                file_path,
                category,
                exc,
            )
            return {}

        if not data:
            return {}
        return {
            "category": category,
            category: data,
        }

    def _resolve_category(self, ext: str, mime: str) -> Optional[str]:
        if mime.startswith("image/") or ext in _IMAGE_EXTENSIONS:
            return "image"
        if mime.startswith("audio/") or mime.startswith("video/") or ext in _AUDIO_VIDEO_EXTENSIONS:
            return "audio_video"
        if ext in _DOCUMENT_EXTENSIONS:
            return "document"
        if ext in _ARCHIVE_EXTENSIONS:
            return "archive"
        return None

