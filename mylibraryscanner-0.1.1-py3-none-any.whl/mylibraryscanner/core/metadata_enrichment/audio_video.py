"""Audio and video metadata enrichment."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List


def _safe_int(value: Any) -> Any:
    try:
        if value is None or value == "":
            return None
        return int(value)
    except Exception:
        return None


def _safe_float(value: Any) -> Any:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except Exception:
        return None


def _extract_with_ffprobe(file_path: str) -> Dict[str, Any]:
    if not shutil.which("ffprobe"):
        return {}

    command = [
        "ffprobe",
        "-v",
        "error",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        file_path,
    ]
    try:
        completed = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(completed.stdout or "{}")
    except Exception:
        return {}

    format_info = payload.get("format", {})
    streams: List[Dict[str, Any]] = payload.get("streams", [])
    metadata: Dict[str, Any] = {
        "duration_seconds": _safe_float(format_info.get("duration")),
        "bitrate": _safe_int(format_info.get("bit_rate")),
        "container_format": format_info.get("format_name"),
        "probe_tags": format_info.get("tags", {}),
        "stream_count": len(streams),
    }

    video_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
    if video_stream:
        metadata["video"] = {
            "codec_name": video_stream.get("codec_name"),
            "width": _safe_int(video_stream.get("width")),
            "height": _safe_int(video_stream.get("height")),
            "fps": video_stream.get("r_frame_rate"),
            "pixel_format": video_stream.get("pix_fmt"),
            "language": (video_stream.get("tags") or {}).get("language"),
        }

    audio_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)
    if audio_stream:
        metadata["audio"] = {
            "codec_name": audio_stream.get("codec_name"),
            "sample_rate": _safe_int(audio_stream.get("sample_rate")),
            "channels": _safe_int(audio_stream.get("channels")),
            "channel_layout": audio_stream.get("channel_layout"),
            "bitrate": _safe_int(audio_stream.get("bit_rate")),
            "language": (audio_stream.get("tags") or {}).get("language"),
        }

    return metadata


def _extract_with_mutagen(file_path: str) -> Dict[str, Any]:
    try:
        from mutagen import File as MutagenFile  # type: ignore
    except Exception:
        return {}

    try:
        media = MutagenFile(file_path, easy=True)
    except Exception:
        return {}

    if media is None:
        return {}

    info = getattr(media, "info", None)
    metadata: Dict[str, Any] = {}
    if info is not None:
        metadata["duration_seconds"] = _safe_float(getattr(info, "length", None))
        metadata["bitrate"] = _safe_int(getattr(info, "bitrate", None))
        metadata["sample_rate"] = _safe_int(getattr(info, "sample_rate", None))
        metadata["channels"] = _safe_int(getattr(info, "channels", None))

    def _pick(key: str) -> Any:
        value = media.get(key) if hasattr(media, "get") else None
        if isinstance(value, list):
            return value[0] if value else None
        return value

    metadata["title"] = _pick("title")
    metadata["artist"] = _pick("artist")
    metadata["album"] = _pick("album")
    metadata["genre"] = _pick("genre")
    metadata["track"] = _pick("tracknumber")
    return metadata


def extract_audio_video_metadata(file_path: str) -> Dict[str, Any]:
    """Extract specialized metadata for audio/video files."""
    metadata: Dict[str, Any] = {"extension": Path(file_path).suffix.lower()}
    ffprobe_data = _extract_with_ffprobe(file_path)
    if ffprobe_data:
        metadata["ffprobe"] = ffprobe_data
        metadata.update({
            "duration_seconds": ffprobe_data.get("duration_seconds"),
            "bitrate": ffprobe_data.get("bitrate"),
            "container_format": ffprobe_data.get("container_format"),
        })

    mutagen_data = _extract_with_mutagen(file_path)
    if mutagen_data:
        metadata["mutagen"] = mutagen_data
        for key in ("title", "artist", "album", "genre", "track"):
            if mutagen_data.get(key) and not metadata.get(key):
                metadata[key] = mutagen_data.get(key)

    return metadata

