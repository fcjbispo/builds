"""Document metadata enrichment."""

from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Any, Dict, Optional
from xml.etree import ElementTree


def _strip_ns(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _parse_xml_properties(xml_data: bytes) -> Dict[str, Any]:
    try:
        root = ElementTree.fromstring(xml_data)
    except Exception:
        return {}

    properties: Dict[str, Any] = {}
    for child in root:
        key = _strip_ns(child.tag)
        value = child.text
        if value is not None:
            properties[key] = value
    return properties


def _extract_pdf_metadata(file_path: str) -> Dict[str, Any]:
    try:
        from pypdf import PdfReader  # type: ignore
    except Exception:
        return {}

    try:
        reader = PdfReader(file_path)
        raw = reader.metadata or {}
    except Exception:
        return {}

    return {
        "title": raw.get("/Title"),
        "author": raw.get("/Author"),
        "subject": raw.get("/Subject"),
        "keywords": raw.get("/Keywords"),
        "creator": raw.get("/Creator"),
        "producer": raw.get("/Producer"),
        "created": raw.get("/CreationDate"),
        "modified": raw.get("/ModDate"),
        "page_count": len(reader.pages),
        "encrypted": bool(reader.is_encrypted),
    }


def _extract_ooxml_or_odf_metadata(file_path: str) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {}
    try:
        with zipfile.ZipFile(file_path, "r") as archive:
            names = set(archive.namelist())
            core_names = [
                "docProps/core.xml",
                "meta.xml",
            ]
            app_names = [
                "docProps/app.xml",
            ]

            for candidate in core_names:
                if candidate in names:
                    metadata["core_properties"] = _parse_xml_properties(archive.read(candidate))
                    break

            for candidate in app_names:
                if candidate in names:
                    metadata["app_properties"] = _parse_xml_properties(archive.read(candidate))
                    break
    except Exception:
        return {}

    core = metadata.get("core_properties", {})
    app = metadata.get("app_properties", {})
    flat = {
        "title": core.get("title"),
        "author": core.get("creator") or core.get("initial-creator"),
        "subject": core.get("subject") or core.get("description"),
        "keywords": core.get("keywords"),
        "creator": core.get("creator"),
        "created": core.get("created") or core.get("creation-date"),
        "modified": core.get("modified") or core.get("date"),
        "application": app.get("Application"),
        "page_count": app.get("Pages"),
        "sheet_count": app.get("Sheets"),
        "slide_count": app.get("Slides"),
    }
    metadata["normalized"] = {k: v for k, v in flat.items() if v is not None}
    return metadata


def _extract_ole_metadata(file_path: str) -> Dict[str, Any]:
    try:
        import olefile  # type: ignore
    except Exception:
        return {}

    if not olefile.isOleFile(file_path):
        return {}

    try:
        with olefile.OleFileIO(file_path) as ole:
            raw = ole.get_metadata()
    except Exception:
        return {}

    return {
        "title": raw.title,
        "author": raw.author,
        "subject": raw.subject,
        "keywords": raw.keywords,
        "creator": raw.appname,
        "created": raw.create_time,
        "modified": raw.last_saved_time,
        "page_count": raw.num_pages,
    }


def extract_document_metadata(file_path: str, mime_type: Optional[str] = None) -> Dict[str, Any]:
    """Extract specialized metadata for PDF/Office/ODF documents."""
    path = Path(file_path)
    ext = path.suffix.lower()
    metadata: Dict[str, Any] = {"extension": ext}
    if mime_type:
        metadata["mime_type"] = mime_type

    if ext == ".pdf":
        pdf_data = _extract_pdf_metadata(file_path)
        if pdf_data:
            metadata["pdf"] = {k: v for k, v in pdf_data.items() if v is not None}
        return metadata

    if ext in {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm", ".odt", ".ods", ".odp"}:
        ooxml_data = _extract_ooxml_or_odf_metadata(file_path)
        if ooxml_data:
            metadata["package"] = ooxml_data
        return metadata

    if ext in {".doc", ".xls", ".ppt"}:
        ole_data = _extract_ole_metadata(file_path)
        if ole_data:
            metadata["ole"] = {k: v for k, v in ole_data.items() if v is not None}
        return metadata

    return metadata

