"""Archive metadata enrichment."""

from __future__ import annotations

import bz2
import gzip
import lzma
import os
import tarfile
import zipfile
from pathlib import Path
from typing import Any, Dict, List


def _extract_zip_metadata(file_path: str) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {}
    try:
        with zipfile.ZipFile(file_path, "r") as archive:
            entries = archive.infolist()
            metadata["entry_count"] = len(entries)
            metadata["total_compressed_size"] = sum(e.compress_size for e in entries)
            metadata["total_uncompressed_size"] = sum(e.file_size for e in entries)
            metadata["entries"] = [
                {
                    "filename": e.filename,
                    "compressed_size": e.compress_size,
                    "uncompressed_size": e.file_size,
                    "compression_method": e.compress_type,
                    "is_encrypted": bool(e.flag_bits & 0x1),
                }
                for e in entries[:100]
            ]
    except Exception:
        return {}
    return metadata


def _extract_tar_metadata(file_path: str) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {}
    try:
        with tarfile.open(file_path, "r:*") as archive:
            entries = archive.getmembers()
            metadata["entry_count"] = len(entries)
            metadata["total_uncompressed_size"] = sum(e.size for e in entries if e.isfile())
            metadata["entries"] = [
                {
                    "filename": e.name,
                    "size": e.size,
                    "type": str(e.type),
                    "mtime": e.mtime,
                }
                for e in entries[:100]
            ]
    except Exception:
        return {}
    return metadata


def _extract_gzip_like_metadata(file_path: str, kind: str) -> Dict[str, Any]:
    path = Path(file_path)
    try:
        stat = path.stat()
    except Exception:
        return {}

    metadata: Dict[str, Any] = {
        "compressed_size": stat.st_size,
        "compression_kind": kind,
    }

    open_fn: Any = None
    if kind == "gzip":
        open_fn = gzip.open
    elif kind == "bzip2":
        open_fn = bz2.open
    elif kind == "xz":
        open_fn = lzma.open

    if open_fn is None:
        return metadata

    try:
        with open_fn(file_path, "rb") as stream:
            content = stream.read()
            metadata["uncompressed_size"] = len(content)
    except Exception:
        pass
    return metadata


def _extract_7z_metadata(file_path: str) -> Dict[str, Any]:
    try:
        import py7zr  # type: ignore
    except Exception:
        return {}

    metadata: Dict[str, Any] = {}
    try:
        with py7zr.SevenZipFile(file_path, "r") as archive:
            entries = archive.list()
            metadata["entry_count"] = len(entries)
            metadata["entries"] = [
                {
                    "filename": e.filename,
                    "compressed_size": getattr(e, "compressed", None),
                    "uncompressed_size": getattr(e, "uncompressed", None),
                    "is_directory": bool(getattr(e, "is_directory", False)),
                    "is_encrypted": bool(getattr(e, "is_encrypted", False)),
                }
                for e in entries[:100]
            ]
    except Exception:
        return {}
    return metadata


def _extract_rar_metadata(file_path: str) -> Dict[str, Any]:
    try:
        import rarfile  # type: ignore
    except Exception:
        return {}

    metadata: Dict[str, Any] = {}
    try:
        with rarfile.RarFile(file_path, "r") as archive:
            entries = archive.infolist()
            metadata["entry_count"] = len(entries)
            metadata["entries"] = [
                {
                    "filename": e.filename,
                    "compressed_size": e.compress_size,
                    "uncompressed_size": e.file_size,
                    "is_directory": e.isdir(),
                    "is_encrypted": bool(e.needs_password()),
                }
                for e in entries[:100]
            ]
    except Exception:
        return {}
    return metadata


def extract_archive_metadata(file_path: str) -> Dict[str, Any]:
    """Extract specialized metadata for archives and compressed files."""
    ext = Path(file_path).suffix.lower()
    metadata: Dict[str, Any] = {
        "extension": ext,
        "compressed_size": os.path.getsize(file_path),
    }

    if ext == ".zip":
        metadata["zip"] = _extract_zip_metadata(file_path)
        return metadata
    if ext in {".tar", ".tgz"} or file_path.lower().endswith(".tar.gz"):
        metadata["tar"] = _extract_tar_metadata(file_path)
        return metadata
    if ext == ".gz":
        metadata["gzip"] = _extract_gzip_like_metadata(file_path, "gzip")
        return metadata
    if ext == ".bz2":
        metadata["bzip2"] = _extract_gzip_like_metadata(file_path, "bzip2")
        return metadata
    if ext == ".xz":
        metadata["xz"] = _extract_gzip_like_metadata(file_path, "xz")
        return metadata
    if ext == ".7z":
        metadata["7z"] = _extract_7z_metadata(file_path)
        return metadata
    if ext == ".rar":
        metadata["rar"] = _extract_rar_metadata(file_path)
        return metadata

    return metadata

