"""Image metadata enrichment."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def extract_image_metadata(file_path: str) -> Dict[str, Any]:
    """Extract specialized image metadata.

    Uses Pillow when available. Returns partial metadata when dependencies are absent.
    """
    metadata: Dict[str, Any] = {}
    path = Path(file_path)
    metadata["extension"] = path.suffix.lower()

    try:
        from PIL import ExifTags, Image  # type: ignore
    except Exception:
        return metadata

    try:
        with Image.open(path) as image:
            metadata["width"] = int(image.width)
            metadata["height"] = int(image.height)
            metadata["format"] = image.format
            metadata["mime_type"] = image.get_format_mimetype()
            metadata["color_mode"] = image.mode
            metadata["bands"] = list(image.getbands())

            try:
                metadata["bits_per_channel"] = image.bits
            except Exception:
                # Pillow does not provide this attribute for all formats.
                pass

            exif_data: Dict[str, Any] = {}
            exif_raw = image.getexif()
            if exif_raw:
                for tag_id, value in exif_raw.items():
                    key = ExifTags.TAGS.get(tag_id, str(tag_id))
                    exif_data[key] = value

            if exif_data:
                metadata["camera_make"] = exif_data.get("Make")
                metadata["camera_model"] = exif_data.get("Model")
                metadata["capture_datetime"] = exif_data.get("DateTimeOriginal")
                metadata["software"] = exif_data.get("Software")
                metadata["copyright"] = exif_data.get("Copyright")
                metadata["iso"] = exif_data.get("ISOSpeedRatings")
                metadata["exposure_time"] = exif_data.get("ExposureTime")
                metadata["aperture"] = exif_data.get("FNumber")
                metadata["orientation"] = exif_data.get("Orientation")
                metadata["exif"] = {
                    k: v for k, v in exif_data.items() if v is not None
                }
    except Exception:
        return metadata

    return metadata

