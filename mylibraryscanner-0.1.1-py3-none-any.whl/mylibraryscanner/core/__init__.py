"""Core functionality for MyLibraryScanner.

This module contains the core scanning and file processing functionality,
including file detection, metadata extraction, hash generation, and ISO handling.
"""

from mylibraryscanner.core.scanner import Scanner, ScanResult
from mylibraryscanner.core.file_processor import FileProcessor, FileReport
from mylibraryscanner.core.mime_detector import (
    get_file_mime_type,
    get_mime_from_extension,
    is_text_file,
    is_image_file,
    is_audio_file,
    is_video_file,
    is_archive_file,
)
from mylibraryscanner.core.hash_generator import (
    compute_md5,
    compute_sha256,
    compute_sha256_first_256,
    compute_multiple_hashes,
    verify_md5,
    verify_sha256,
    HashGenerator,
)
from mylibraryscanner.core.llm_client import LLMClient, LLMProfile
from mylibraryscanner.core.embedding import EmbeddingService
from mylibraryscanner.core.inference import ContentInferenceService, MAX_INFERENCE_CHARS
from mylibraryscanner.core.metadata_enrichment import MetadataEnrichmentService

__all__ = [
    # Scanner
    "Scanner",
    "ScanResult",
    # File Processor
    "FileProcessor",
    "FileReport",
    # MIME Detection
    "get_file_mime_type",
    "get_mime_from_extension",
    "is_text_file",
    "is_image_file",
    "is_audio_file",
    "is_video_file",
    "is_archive_file",
    # Hash Generation
    "compute_md5",
    "compute_sha256",
    "compute_sha256_first_256",
    "compute_multiple_hashes",
    "verify_md5",
    "verify_sha256",
    "HashGenerator",
    # LLM
    "LLMClient",
    "LLMProfile",
    "EmbeddingService",
    # Inference
    "ContentInferenceService",
    "MAX_INFERENCE_CHARS",
    # Metadata enrichment
    "MetadataEnrichmentService",
]
