"""LLM client helpers for CHAT, VISION and EMBEDDING profiles."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Union
from urllib import request as urlrequest

from mylibraryscanner.initialization import get_app_config, get_logger_instance


@dataclass(frozen=True)
class LLMProfile:
    """Resolved profile configuration."""

    name: str
    base_url: str
    model: str
    api_key: str


class LLMClient:
    """Small OpenAI-compatible client with profile-based routing."""

    def __init__(self) -> None:
        app_cfg = get_app_config()
        self._cfg = app_cfg.get("config", {})
        app_code = app_cfg.get("app", {}).get("appcode", "MYLIBRARYSCANNER")
        self._app_code = str(app_code).strip() or "MYLIBRARYSCANNER"
        self.logger = get_logger_instance()

    def resolve_profile(self, profile: str) -> LLMProfile:
        """Resolve effective model credentials for a given profile."""
        profile_name = profile.strip().lower()
        if profile_name not in {"chat", "vision", "embedding"}:
            raise ValueError(f"Unsupported LLM profile: {profile}")

        if profile_name == "chat":
            base_url = str(self._cfg.get("llm_chat_base_url", "")).strip()
            model = str(self._cfg.get("llm_chat_model", "")).strip()
            api_key = self._resolve_api_key(
                config_key="llm_chat_api_key",
                env_key=f"FBNET_{self._app_code}_LLM_CHAT_API_KEY",
                fallback_env_keys=("LLM_CHAT_API_KEY", "OPENAI_API_KEY"),
            )
            return LLMProfile(name="chat", base_url=base_url, model=model, api_key=api_key)

        if profile_name == "vision":
            chat_profile = self.resolve_profile("chat")
            base_url = str(self._cfg.get("llm_vision_base_url", "")).strip() or chat_profile.base_url
            model = str(self._cfg.get("llm_vision_model", "")).strip() or chat_profile.model
            api_key = self._resolve_api_key(
                config_key="llm_vision_api_key",
                env_key=f"FBNET_{self._app_code}_LLM_VISION_API_KEY",
                fallback_env_keys=("LLM_VISION_API_KEY",),
            ) or chat_profile.api_key
            return LLMProfile(name="vision", base_url=base_url, model=model, api_key=api_key)

        chat_profile = self.resolve_profile("chat")
        base_url = str(self._cfg.get("llm_embedding_base_url", "")).strip() or chat_profile.base_url
        model = str(self._cfg.get("llm_embedding_model", "")).strip()
        api_key = self._resolve_api_key(
            config_key="llm_embedding_api_key",
            env_key=f"FBNET_{self._app_code}_LLM_EMBEDDING_API_KEY",
            fallback_env_keys=("LLM_EMBEDDING_API_KEY",),
        ) or chat_profile.api_key
        return LLMProfile(name="embedding", base_url=base_url, model=model, api_key=api_key)

    def create_chat_completion(
        self,
        profile: str,
        messages: Sequence[Dict[str, Any]],
        temperature: float = 0.2,
        max_tokens: int = 300,
        timeout: int = 60,
    ) -> Optional[Dict[str, Any]]:
        """Call OpenAI-style chat completion endpoint for chat/vision profiles."""
        cfg = self.resolve_profile(profile)
        if not cfg.base_url or not cfg.model:
            self.logger.warning(
                "LLM %s skipped: base URL or model not configured",
                cfg.name.upper(),
            )
            return None

        payload = {
            "model": cfg.model,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": list(messages),
        }
        return self._post_json(
            url=self._chat_url(cfg.base_url),
            payload=payload,
            api_key=cfg.api_key,
            timeout=timeout,
            profile=cfg.name,
        )

    def create_embedding(
        self,
        text: Union[str, List[str]],
        timeout: int = 60,
    ) -> Optional[List[float]]:
        """Call OpenAI-style embedding endpoint and return first vector."""
        cfg = self.resolve_profile("embedding")
        if not cfg.base_url or not cfg.model:
            self.logger.warning("LLM EMBEDDING skipped: base URL or model not configured")
            return None

        payload: Dict[str, Any] = {"model": cfg.model, "input": text}
        response = self._post_json(
            url=self._embedding_url(cfg.base_url),
            payload=payload,
            api_key=cfg.api_key,
            timeout=timeout,
            profile=cfg.name,
        )
        if not response:
            return None

        try:
            data = response.get("data", [])
            if not data:
                return None
            embedding = data[0].get("embedding")
            if not isinstance(embedding, list):
                return None
            return embedding
        except Exception:
            return None

    def extract_message_text(self, response: Dict[str, Any]) -> Optional[str]:
        """Extract text content from OpenAI-style chat response."""
        try:
            message = response["choices"][0]["message"]["content"]
            if isinstance(message, list):
                texts = []
                for item in message:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(str(item.get("text", "")))
                return " ".join(t for t in texts if t).strip() or None
            if isinstance(message, str):
                return message.strip() or None
            return None
        except Exception:
            return None

    def _resolve_api_key(
        self,
        config_key: str,
        env_key: str,
        fallback_env_keys: Sequence[str] = (),
    ) -> str:
        value = str(self._cfg.get(config_key, "")).strip()
        if value:
            return value
        value = os.getenv(env_key, "").strip()
        if value:
            return value
        for key in fallback_env_keys:
            value = os.getenv(key, "").strip()
            if value:
                return value
        return ""

    def _chat_url(self, base_url: str) -> str:
        return self._join_endpoint(base_url, "/chat/completions")

    def _embedding_url(self, base_url: str) -> str:
        return self._join_endpoint(base_url, "/embeddings")

    def _join_endpoint(self, base_url: str, endpoint: str) -> str:
        normalized_base = base_url.rstrip("/")
        normalized_endpoint = endpoint.strip()
        if normalized_base.endswith(normalized_endpoint):
            return normalized_base
        return f"{normalized_base}{normalized_endpoint}"

    def _post_json(
        self,
        url: str,
        payload: Dict[str, Any],
        api_key: str,
        timeout: int,
        profile: str,
    ) -> Optional[Dict[str, Any]]:
        body = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        req = urlrequest.Request(url, data=body, headers=headers, method="POST")
        try:
            with urlrequest.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", errors="ignore")
            return json.loads(raw)
        except Exception as exc:
            self.logger.warning("LLM %s request failed: %s", profile.upper(), exc)
            return None
