"""Content inference utilities for MyLibraryScanner.

This module provides concise content inference for text/data and image files.
Binary files are ignored.
"""

from __future__ import annotations

import base64
import mimetypes
import re
import shutil
import subprocess
import zipfile
from pathlib import Path
from typing import Any, Dict, Optional

from mylibraryscanner.core.llm_client import LLMClient
from mylibraryscanner.initialization import get_app_config, get_logger_instance


MAX_INFERENCE_CHARS = 5 * 1024
MAX_TEXT_INPUT_CHARS = 16_000
MAX_IMAGE_BYTES = 6 * 1024 * 1024

_TEXT_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".rst",
    ".csv",
    ".tsv",
    ".json",
    ".jsonl",
    ".yaml",
    ".yml",
    ".xml",
    ".html",
    ".htm",
    ".css",
    ".js",
    ".ts",
    ".py",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".go",
    ".rs",
    ".php",
    ".sql",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".env",
    ".log",
    ".sh",
    ".bat",
    ".cmd",
    ".ps1",
}

_DOC_EXTENSIONS = {".pdf", ".docx", ".odt", ".xlsx", ".xlsm"}
_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}


def _truncate(text: str, max_chars: int = MAX_INFERENCE_CHARS) -> str:
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."


def _strip_xml_tags(raw_xml: str) -> str:
    no_tags = re.sub(r"<[^>]+>", " ", raw_xml)
    compact = re.sub(r"\s+", " ", no_tags).strip()
    return compact


def _is_probably_binary(data: bytes) -> bool:
    if not data:
        return False
    if b"\x00" in data:
        return True
    non_text = sum(
        1
        for b in data
        if b not in b"\t\n\r\f\b" and (b < 32 or b > 126)
    )
    return (non_text / len(data)) > 0.30


class ContentInferenceService:
    """Run concise LLM inference for supported files."""

    def __init__(self, max_inference_chars: int = MAX_INFERENCE_CHARS):
        cfg = get_app_config().get("config", {})

        self.logger = get_logger_instance()
        self.client = LLMClient()
        self.max_inference_chars = max_inference_chars
        self.temperature = float(cfg.get("llm_chat_temperature", 0.2))
        self.max_tokens = int(cfg.get("llm_chat_max_tokens", 300))

    def _is_image(self, file_path: str, mime_type: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return mime_type.startswith("image/") or ext in _IMAGE_EXTENSIONS

    def _is_data_file(self, file_path: str, mime_type: str) -> bool:
        ext = Path(file_path).suffix.lower()
        if ext in _TEXT_EXTENSIONS or ext in _DOC_EXTENSIONS:
            return True
        if mime_type.startswith("text/"):
            return True
        if mime_type in {
            "application/json",
            "application/xml",
            "application/yaml",
            "application/x-yaml",
            "application/toml",
            "application/javascript",
        }:
            return True
        return False

    def _extract_text_for_inference(self, file_path: str) -> Optional[str]:
        path = Path(file_path)
        ext = path.suffix.lower()

        if ext == ".pdf":
            if not shutil.which("pdftotext"):
                return None
            try:
                completed = subprocess.run(
                    ["pdftotext", "-q", "-nopgbrk", str(path), "-"],
                    check=True,
                    capture_output=True,
                )
                text = completed.stdout.decode("utf-8", errors="ignore")
                return text[:MAX_TEXT_INPUT_CHARS].strip() or None
            except Exception:
                return None

        if ext in {".docx", ".odt", ".xlsx", ".xlsm"}:
            try:
                with zipfile.ZipFile(path, "r") as zf:
                    names = [n for n in zf.namelist() if n.endswith(".xml")]
                    chunks = []
                    for name in names[:30]:
                        raw_xml = zf.read(name).decode("utf-8", errors="ignore")
                        chunks.append(_strip_xml_tags(raw_xml))
                    merged = " ".join(chunk for chunk in chunks if chunk)
                    return merged[:MAX_TEXT_INPUT_CHARS].strip() or None
            except Exception:
                return None

        try:
            raw = path.read_bytes()
            if _is_probably_binary(raw[:4096]):
                return None
            decoded = raw.decode("utf-8", errors="ignore")
            return decoded[:MAX_TEXT_INPUT_CHARS].strip() or None
        except Exception:
            return None

    def _post_completion(self, profile: str, messages: list[dict[str, Any]]) -> Optional[str]:
        response = self.client.create_chat_completion(
            profile=profile,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            timeout=60,
        )
        if not response:
            return None

        message = self.client.extract_message_text(response)
        if not message:
            return None
        return _truncate(message, self.max_inference_chars)

    def _infer_text(self, file_path: str, text: str) -> Optional[str]:
        prompt = (
            "Resuma o conteúdo do arquivo em português, de forma clara e sucinta. "
            "Inclua finalidade provável, principais tópicos e possível destinação. "
            f"Resposta máxima: {self.max_inference_chars} caracteres."
        )
        messages = [
            {"role": "system", "content": "Você resume arquivos para gestão documental."},
            {
                "role": "user",
                "content": f"Arquivo: {file_path}\n\nConteúdo:\n{text}\n\n{prompt}",
            },
        ]
        return self._post_completion("chat", messages)

    def _infer_image(self, file_path: str, mime_type: str) -> Optional[str]:
        path = Path(file_path)
        try:
            raw = path.read_bytes()
        except Exception:
            return None
        if len(raw) > MAX_IMAGE_BYTES:
            self.logger.warning(f"Image too large for inference: {file_path}")
            return None

        image_b64 = base64.b64encode(raw).decode("ascii")
        prompt = (
            "Descreva a imagem em português de forma clara e sucinta, "
            "indicando tema, elementos principais e provável contexto de uso."
        )
        messages = [
            {"role": "system", "content": "Você descreve imagens para catalogação."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime_type};base64,{image_b64}"},
                    },
                ],
            },
        ]
        return self._post_completion("vision", messages)

    def infer_file(self, file_path: str, details: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Infer concise content description for a file.

        Returns None when file should be ignored (binary/unsupported) or inference fails.
        """
        details = details or {}
        mime_type = str(details.get("mime_type_code") or "").strip()
        if not mime_type:
            mime_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

        if self._is_image(file_path, mime_type):
            return self._infer_image(file_path, mime_type)

        if self._is_data_file(file_path, mime_type):
            extracted = self._extract_text_for_inference(file_path)
            if not extracted:
                return None
            return self._infer_text(file_path, extracted)

        # Ignore binary/unsupported files.
        return None
