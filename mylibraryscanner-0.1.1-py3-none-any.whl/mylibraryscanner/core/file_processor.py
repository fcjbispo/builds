"""File processor module for MyLibraryScanner."""

from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass

from mylibraryscanner.core.hash_generator import compute_md5, compute_sha256_first_256
from mylibraryscanner.core.metadata_enrichment import MetadataEnrichmentService
from mylibraryscanner.core.mime_detector import get_file_mime_type
from mylibraryscanner.initialization import get_logger_instance


@dataclass
class FileReport:
    """Data class representing processed file information."""

    file_path: str
    status: str = "OK"
    status_message: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


class FileProcessor:
    """Processes individual files to extract metadata and compute checksums.

    This class handles:
    - File metadata extraction (size, dates, extension)
    - MIME type detection
    - MD5 checksum computation
    - SHA256 of first 256 bytes for quick comparison
    """

    def __init__(self):
        """Initialize the file processor."""
        self.logger = get_logger_instance()
        self.metadata_enrichment = MetadataEnrichmentService()

    def process_file(self, file_path: str) -> Dict[str, Any]:
        """Process a single file to extract metadata.

        Args:
            file_path: Absolute path to the file

        Returns:
            Dictionary containing file metadata and processing status

        Raises:
            FileNotFoundError: If the file does not exist
        """
        file_report = {
            "file_path": file_path,
            "status": "OK",
            "status_message": None,
        }

        try:
            path = Path(file_path)

            if not path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")

            if not path.is_file():
                raise ValueError(f"Not a file: {file_path}")

            # Get basic file info
            details = self._extract_file_info(path)

            # Get MIME type (with fallback for unknown types)
            mime_code, mime_desc = self._detect_mime_type(file_path, details)
            details["mime_type_code"] = mime_code
            details["mime_type_description"] = mime_desc

            # Compute checksums
            details["md5sum"] = compute_md5(file_path)
            details["first_256_bytes_sha256_hex"] = compute_sha256_first_256(file_path)

            enriched = self.metadata_enrichment.enrich_file(file_path, mime_code)
            if enriched:
                details["specialized_metadata"] = enriched
                details["content_family"] = enriched.get("category")

            file_report["details"] = details
            file_report["status"] = "OK"

            self.logger.debug(f"Successfully processed: {file_path}")

        except Exception as e:
            file_report["details"] = None
            file_report["status"] = "ERROR"
            file_report["status_message"] = str(e)
            self.logger.error(f"Error processing {file_path}: {e}")

        return file_report

    def _extract_file_info(self, path: Path) -> Dict[str, Any]:
        """Extract basic file information.

        Args:
            path: Path object for the file

        Returns:
            Dictionary containing file metadata
        """
        stat = path.stat()

        # Get file name components
        filename = path.name
        stem = path.stem
        suffix = path.suffix

        # Build details dictionary
        details = {
            "complete_filename": filename,
            "filename_no_ext": stem,
            "extension": suffix,
            "size_bytes": stat.st_size,
            "creation_date": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modification_date": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "access_date": datetime.fromtimestamp(stat.st_atime).isoformat(),
        }

        return details

    def _detect_mime_type(
        self, file_path: str, details: Dict[str, Any]
    ) -> Tuple[str, str]:
        """Detect MIME type of a file.

        Args:
            file_path: Path to the file
            details: File details dictionary (may be updated)

        Returns:
            Tuple of (mime_type_code, mime_type_description)
        """
        # Use the mime detector module
        mime_code, mime_desc = get_file_mime_type(file_path)

        # Handle special cases
        if mime_code == "application/octet-stream":
            # Try to determine more specific type based on extension
            path = Path(file_path)
            ext = path.suffix.lower()

            # Common extensions that might be misidentified
            extension_map = {
                ".txt": ("text/plain", "Plain Text"),
                ".log": ("text/plain", "Log File"),
                ".csv": ("text/csv", "Comma-Separated Values"),
                ".json": ("application/json", "JavaScript Object Notation"),
                ".xml": ("application/xml", "XML Document"),
                ".html": ("text/html", "HTML Document"),
                ".htm": ("text/html", "HTML Document"),
                ".css": ("text/css", "Cascading Style Sheet"),
                ".js": ("application/javascript", "JavaScript"),
                ".py": ("text/x-python", "Python Source"),
                ".sh": ("application/x-sh", "Shell Script"),
                ".bat": ("application/x-batch", "Batch File"),
                ".ps1": ("application/x-powershell", "PowerShell Script"),
                ".md": ("text/markdown", "Markdown Document"),
                ".rst": ("text/x-rst", "reStructuredText"),
                ".yml": ("application/x-yaml", "YAML Document"),
                ".yaml": ("application/x-yaml", "YAML Document"),
                ".toml": ("application/toml", "TOML Configuration"),
                ".ini": ("text/plain", "INI Configuration"),
                ".conf": ("text/plain", "Configuration File"),
                ".cfg": ("text/plain", "Configuration File"),
            }

            if ext in extension_map:
                mime_code, mime_desc = extension_map[ext]
                details["extension_corrected"] = True

        elif mime_code == "application/x-iso9660-image":
            # Remove ISO image info from details if present
            if "image_info" in details:
                details.pop("image_info", None)

        return mime_code, mime_desc

    def is_processable(self, file_path: str) -> bool:
        """Check if a file can be processed.

        Args:
            file_path: Path to check

        Returns:
            True if the file exists and is a regular file
        """
        try:
            path = Path(file_path)
            return path.exists() and path.is_file()
        except Exception:
            return False

    def get_file_size_category(self, file_path: str) -> str:
        """Get the size category of a file.

        Args:
            file_path: Path to the file

        Returns:
            Size category: "tiny", "small", "medium", "large", or "huge"
        """
        try:
            size = Path(file_path).stat().st_size
            if size < 1024:
                return "tiny"  # < 1KB
            elif size < 1024 * 1024:
                return "small"  # < 1MB
            elif size < 100 * 1024 * 1024:
                return "medium"  # < 100MB
            elif size < 1024 * 1024 * 1024:
                return "large"  # < 1GB
            else:
                return "huge"  # >= 1GB
        except Exception:
            return "unknown"


__all__ = ["FileProcessor", "FileReport"]
