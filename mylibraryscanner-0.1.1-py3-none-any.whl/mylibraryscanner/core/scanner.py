"""Core scanner module for MyLibraryScanner.

This module provides the main file scanning functionality with recursive directory
traversal, file pattern matching, and progress tracking.
"""

import os
import fnmatch
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Any, Callable, Set
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed

from mylibraryscanner.initialization import get_logger_instance
from mylibraryscanner.config import ScanningConfig


@dataclass
class ScanResult:
    """Result of a scan operation containing metadata and processed files."""

    source_name: str
    source_dir: str
    source_mask: str
    source_kind: str = "LOCAL"
    start_extraction: Optional[datetime] = None
    end_extraction: Optional[datetime] = None
    status: str = "OK"
    status_message: Optional[str] = None
    files_total: int = 0
    files: List[Dict[str, Any]] = field(default_factory=list)
    errors: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert scan result to dictionary for JSON storage."""
        return {
            "source_name": self.source_name,
            "source_dir": self.source_dir,
            "source_mask": self.source_mask,
            "source_kind": self.source_kind,
            "start_extraction": self.start_extraction.isoformat() if self.start_extraction else None,
            "end_extraction": self.end_extraction.isoformat() if self.end_extraction else None,
            "status": self.status,
            "status_message": self.status_message,
            "files_total": self.files_total,
            "files": self.files,
            "errors": self.errors,
        }


class Scanner:
    """Main scanner class for scanning directories and processing files.

    This class handles recursive directory traversal, file filtering,
    and orchestrates the file processing pipeline.
    """

    DEFAULT_EXCLUDE_PATTERNS = [
        "*.tmp",
        "*.temp",
        "*.swp",
        "*.bak",
        "__pycache__",
        ".git",
        ".svn",
        ".hg",
        "node_modules",
        ".DS_Store",
        "Thumbs.db",
        "desktop.ini",
    ]

    def __init__(
        self,
        config: Optional[ScanningConfig] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ):
        """Initialize the scanner.

        Args:
            config: Scanning configuration (uses defaults if not provided)
            progress_callback: Optional callback function for progress updates
        """
        self.config = config or ScanningConfig()
        self.progress_callback = progress_callback
        self.logger = get_logger_instance()
        self._exclude_patterns: Set[str] = set()

        # Load exclude patterns from config
        if self.config.exclude_patterns:
            self._exclude_patterns.update(self.config.exclude_patterns)

    def scan(
        self,
        source_dir: str,
        source_mask: str = "*",
        source_name: Optional[str] = None,
        source_kind: str = "LOCAL",
    ) -> ScanResult:
        """Scan a directory and process all matching files.

        Args:
            source_dir: Directory path to scan
            source_mask: File pattern to match (default: "*")
            source_name: Optional name for the source (defaults to directory name)
            source_kind: Type of source (LOCAL, REMOVABLE, REMOTE)

        Returns:
            ScanResult containing all processed files and metadata

        Raises:
            ValueError: If source_dir does not exist or is not a directory
        """
        # Validate source directory
        source_path = Path(source_dir)
        if not source_path.exists():
            raise ValueError(f"Source directory does not exist: {source_dir}")
        if not source_path.is_dir():
            raise ValueError(f"Source path is not a directory: {source_dir}")

        # Set default source name
        if not source_name:
            source_name = source_path.name or "unnamed"

        # Initialize result
        result = ScanResult(
            source_name=source_name,
            source_dir=str(source_path.absolute()),
            source_mask=source_mask,
            source_kind=source_kind,
            start_extraction=datetime.now(),
        )

        try:
            # Find all files matching the mask
            self.logger.info(f"Starting scan of {source_name} ({source_dir})")
            files = self._find_files(source_path, source_mask)

            # Filter excluded files
            files = self._filter_excluded(files)
            self.logger.info(f"Found {len(files)} files to process in {source_name}")

            # Process files
            from mylibraryscanner.core.file_processor import FileProcessor

            processor = FileProcessor()

            processed_count = 0
            for file_path in files:
                try:
                    file_report = processor.process_file(file_path)
                    result.files.append(file_report)

                    if file_report.get("status") == "ERROR":
                        result.errors.append({
                            "file": file_path,
                            "message": file_report.get("status_message", "Unknown error"),
                        })

                    processed_count += 1

                    # Progress callback
                    if self.progress_callback:
                        self.progress_callback(processed_count, len(files))

                except Exception as e:
                    self.logger.error(f"Error processing {file_path}: {e}")
                    result.errors.append({
                        "file": file_path,
                        "message": str(e),
                    })

            result.files_total = len(result.files)
            result.end_extraction = datetime.now()

            self.logger.info(
                f"Scan complete for {source_name}: {result.files_total} files processed, "
                f"{len(result.errors)} errors"
            )

        except Exception as e:
            result.status = "FAIL"
            result.status_message = str(e)
            result.end_extraction = datetime.now()
            self.logger.error(f"Scan failed for {source_name}: {e}")

        return result

    def scan_parallel(
        self,
        source_dir: str,
        source_mask: str = "*",
        source_name: Optional[str] = None,
        source_kind: str = "LOCAL",
        max_workers: int = 4,
    ) -> ScanResult:
        """Scan a directory using parallel processing.

        Args:
            source_dir: Directory path to scan
            source_mask: File pattern to match
            source_name: Optional name for the source
            source_kind: Type of source
            max_workers: Maximum number of worker threads

        Returns:
            ScanResult containing processed files
        """
        # Validate source directory
        source_path = Path(source_dir)
        if not source_path.exists() or not source_path.is_dir():
            raise ValueError(f"Invalid source directory: {source_dir}")

        # Set default source name
        if not source_name:
            source_name = source_path.name or "unnamed"

        result = ScanResult(
            source_name=source_name,
            source_dir=str(source_path.absolute()),
            source_mask=source_mask,
            source_kind=source_kind,
            start_extraction=datetime.now(),
        )

        try:
            files = self._find_files(source_path, source_mask)
            files = self._filter_excluded(files)
            total_files = len(files)

            self.logger.info(f"Starting parallel scan of {source_name} with {max_workers} workers")

            from mylibraryscanner.core.file_processor import FileProcessor
            processor = FileProcessor()

            processed_count = 0

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_file = {
                    executor.submit(processor.process_file, file_path): file_path
                    for file_path in files
                }

                for future in as_completed(future_to_file):
                    file_path = future_to_file[future]
                    try:
                        file_report = future.result()
                        result.files.append(file_report)

                        if file_report.get("status") == "ERROR":
                            result.errors.append({
                                "file": file_path,
                                "message": file_report.get("status_message", "Unknown error"),
                            })

                    except Exception as e:
                        self.logger.error(f"Error processing {file_path}: {e}")
                        result.errors.append({
                            "file": file_path,
                            "message": str(e),
                        })

                    processed_count += 1
                    if self.progress_callback:
                        self.progress_callback(processed_count, total_files)

            result.files_total = len(result.files)
            result.end_extraction = datetime.now()

            self.logger.info(
                f"Parallel scan complete for {source_name}: {result.files_total} files"
            )

        except Exception as e:
            result.status = "FAIL"
            result.status_message = str(e)
            result.end_extraction = datetime.now()
            self.logger.error(f"Parallel scan failed for {source_name}: {e}")

        return result

    def _find_files(self, source_path: Path, source_mask: str) -> List[str]:
        """Find all files matching the mask in the source directory.

        Args:
            source_path: Path to the source directory
            source_mask: File pattern to match

        Returns:
            List of absolute file paths
        """
        files = []

        if self.config.max_depth > 0:
            # Limited depth traversal
            for root, dirs, filenames in os.walk(source_path):
                # Check depth
                rel_path = Path(root).relative_to(source_path)
                depth = len(rel_path.parts)
                if depth > self.config.max_depth:
                    dirs.clear()  # Don't descend further
                    continue

                # Skip hidden directories
                if any(d.startswith('.') for d in dirs):
                    dirs[:] = [d for d in dirs if not d.startswith('.')]

                for filename in filenames:
                    if fnmatch.fnmatch(filename, source_mask):
                        files.append(str(Path(root) / filename))

        else:
            # Full recursive traversal using os.walk
            for root, dirs, filenames in os.walk(source_path):
                # Skip hidden directories
                if any(d.startswith('.') for d in dirs):
                    dirs[:] = [d for d in dirs if not d.startswith('.')]

                for filename in filenames:
                    if fnmatch.fnmatch(filename, source_mask):
                        files.append(str(Path(root) / filename))

        return sorted(files)

    def _filter_excluded(self, files: List[str]) -> List[str]:
        """Filter out files matching exclude patterns.

        Args:
            files: List of file paths to filter

        Returns:
            Filtered list of file paths
        """
        if not self._exclude_patterns:
            return files

        filtered = []
        for file_path in files:
            filename = os.path.basename(file_path)

            # Check against exclude patterns
            excluded = False
            for pattern in self._exclude_patterns:
                if fnmatch.fnmatch(filename, pattern):
                    excluded = True
                    break

            if not excluded:
                filtered.append(file_path)

        return filtered

    def add_exclude_pattern(self, pattern: str) -> None:
        """Add an exclude pattern.

        Args:
            pattern: Glob pattern to exclude
        """
        self._exclude_patterns.add(pattern)

    def remove_exclude_pattern(self, pattern: str) -> None:
        """Remove an exclude pattern.

        Args:
            pattern: Glob pattern to remove
        """
        self._exclude_patterns.discard(pattern)


__all__ = ["Scanner", "ScanResult"]
