"""Hash generator module for MyLibraryScanner.

This module handles file hashing operations including MD5 checksums
and SHA256 of file headers for quick comparison.
"""

import hashlib
from typing import Optional
from pathlib import Path

from mylibraryscanner.initialization import get_logger_instance


def compute_md5(file_path: str) -> Optional[str]:
    """Compute the MD5 hash of an entire file.

    Args:
        file_path: Path to the file

    Returns:
        MD5 hex digest, or None if file cannot be read
    """
    logger = get_logger_instance()

    try:
        hash_md5 = hashlib.md5()

        with open(file_path, "rb") as f:
            # Read in chunks to handle large files efficiently
            for chunk in iter(lambda: f.read(8192), b""):
                hash_md5.update(chunk)

        return hash_md5.hexdigest()

    except Exception as e:
        logger.debug(f"Error computing MD5 for {file_path}: {e}")
        return None


def compute_sha256(file_path: str) -> Optional[str]:
    """Compute the SHA256 hash of an entire file.

    Args:
        file_path: Path to the file

    Returns:
        SHA256 hex digest, or None if file cannot be read
    """
    logger = get_logger_instance()

    try:
        hash_sha256 = hashlib.sha256()

        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_sha256.update(chunk)

        return hash_sha256.hexdigest()

    except Exception as e:
        logger.debug(f"Error computing SHA256 for {file_path}: {e}")
        return None


def compute_sha256_first_256(file_path: str, num_bytes: int = 256) -> Optional[str]:
    """Compute SHA256 hash of the first N bytes of a file.

    This is useful for quick file comparison without reading entire files.
    Files with identical headers likely have the same content.

    Args:
        file_path: Path to the file
        num_bytes: Number of bytes to read from the beginning (default: 256)

    Returns:
        SHA256 hex digest of first bytes, or None if file cannot be read
    """
    logger = get_logger_instance()

    try:
        hash_sha256 = hashlib.sha256()

        with open(file_path, "rb") as f:
            header = f.read(num_bytes)
            hash_sha256.update(header)

        return hash_sha256.hexdigest()

    except Exception as e:
        logger.debug(f"Error computing header SHA256 for {file_path}: {e}")
        return None


def compute_multiple_hashes(file_path: str) -> dict:
    """Compute multiple hash types for a file.

    Args:
        file_path: Path to the file

    Returns:
        Dictionary containing all computed hashes
    """
    logger = get_logger_instance()

    result = {
        "md5": None,
        "sha256": None,
        "sha256_header": None,
    }

    try:
        result["md5"] = compute_md5(file_path)
        result["sha256"] = compute_sha256(file_path)
        result["sha256_header"] = compute_sha256_first_256(file_path)

    except Exception as e:
        logger.debug(f"Error computing hashes for {file_path}: {e}")

    return result


def verify_md5(file_path: str, expected_md5: str) -> bool:
    """Verify that a file's MD5 matches the expected value.

    Args:
        file_path: Path to the file
        expected_md5: Expected MD5 hex digest

    Returns:
        True if MD5 matches, False otherwise
    """
    actual_md5 = compute_md5(file_path)

    if actual_md5 is None:
        return False

    return actual_md5.lower() == expected_md5.lower()


def verify_sha256(file_path: str, expected_sha256: str) -> bool:
    """Verify that a file's SHA256 matches the expected value.

    Args:
        file_path: Path to the file
        expected_sha256: Expected SHA256 hex digest

    Returns:
        True if SHA256 matches, False otherwise
    """
    actual_sha256 = compute_sha256(file_path)

    if actual_sha256 is None:
        return False

    return actual_sha256.lower() == expected_sha256.lower()


def get_file_hash_type(file_size: int) -> str:
    """Determine the appropriate hash type based on file size.

    Args:
        file_size: Size of the file in bytes

    Returns:
        Recommended hash type: "md5", "sha256", or "sha256_header"
    """
    if file_size < 1024 * 1024:  # < 1MB
        return "md5"  # Fast enough for small files
    elif file_size < 100 * 1024 * 1024:  # < 100MB
        return "sha256_header"  # Use header for medium files
    else:
        return "sha256_header"  # Always use header for large files


class HashGenerator:
    """Class-based interface for hash operations."""

    def __init__(self, algorithm: str = "md5"):
        """Initialize hash generator.

        Args:
            algorithm: Hash algorithm to use ("md5", "sha256", or "header")
        """
        self.algorithm = algorithm.lower()
        self.logger = get_logger_instance()

    def hash_file(self, file_path: str) -> Optional[str]:
        """Hash a file using the configured algorithm.

        Args:
            file_path: Path to the file

        Returns:
            Hash hex digest, or None on error
        """
        if self.algorithm == "md5":
            return compute_md5(file_path)
        elif self.algorithm == "sha256":
            return compute_sha256(file_path)
        elif self.algorithm == "header":
            return compute_sha256_first_256(file_path)
        else:
            self.logger.warning(f"Unknown algorithm: {self.algorithm}")
            return None


__all__ = [
    "compute_md5",
    "compute_sha256",
    "compute_sha256_first_256",
    "compute_multiple_hashes",
    "verify_md5",
    "verify_sha256",
    "get_file_hash_type",
    "HashGenerator",
]
