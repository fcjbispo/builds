"""MIME type detection module for MyLibraryScanner.

This module handles MIME type detection using the 'file' command on Unix systems
and provides fallback mechanisms for other platforms.
"""

import os
import subprocess
from typing import Tuple, Optional

from mylibraryscanner.initialization import get_logger_instance

# Fallback MIME types for common extensions
EXTENSION_FALLBACK = {
    ".txt": ("text/plain", "Plain Text"),
    ".log": ("text/plain", "Log File"),
    ".csv": ("text/csv", "Comma-Separated Values"),
    ".json": ("application/json", "JavaScript Object Notation"),
    ".xml": ("application/xml", "XML Document"),
    ".html": ("text/html", "HTML Document"),
    ".htm": ("text/html", "HTML Document"),
    ".css": ("text/css", "Cascading Style Sheet"),
    ".js": ("application/javascript", "JavaScript"),
    ".py": ("text/x-python", "Python Source"),
    ".sh": ("application/x-sh", "Shell Script"),
    ".bat": ("application/x-batch", "Batch File"),
    ".ps1": ("application/x-powershell", "PowerShell Script"),
    ".md": ("text/markdown", "Markdown Document"),
    ".rst": ("text/x-rst", "reStructuredText"),
    ".yml": ("application/x-yaml", "YAML Document"),
    ".yaml": ("application/x-yaml", "YAML Document"),
    ".toml": ("application/toml", "TOML Configuration"),
    ".ini": ("text/plain", "INI Configuration"),
    ".conf": ("text/plain", "Configuration File"),
    ".cfg": ("text/plain", "Configuration File"),
    ".pdf": ("application/pdf", "PDF Document"),
    ".doc": ("application/msword", "Microsoft Word Document"),
    ".docx": (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "Microsoft Word Document",
    ),
    ".xls": ("application/vnd.ms-excel", "Microsoft Excel Spreadsheet"),
    ".xlsx": (
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Microsoft Excel Spreadsheet",
    ),
    ".ppt": ("application/vnd.ms-powerpoint", "Microsoft PowerPoint"),
    ".pptx": (
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "Microsoft PowerPoint",
    ),
    ".zip": ("application/zip", "ZIP Archive"),
    ".tar": ("application/x-tar", "TAR Archive"),
    ".gz": ("application/gzip", "GZIP Compressed"),
    ".bz2": ("application/x-bzip2", "BZIP2 Compressed"),
    ".7z": ("application/x-7z-compressed", "7-Zip Archive"),
    ".rar": ("application/x-rar-compressed", "RAR Archive"),
    ".jpg": ("image/jpeg", "JPEG Image"),
    ".jpeg": ("image/jpeg", "JPEG Image"),
    ".png": ("image/png", "PNG Image"),
    ".gif": ("image/gif", "GIF Image"),
    ".bmp": ("image/bmp", "Bitmap Image"),
    ".svg": ("image/svg+xml", "SVG Image"),
    ".ico": ("image/x-icon", "Icon Image"),
    ".webp": ("image/webp", "WebP Image"),
    ".mp3": ("audio/mpeg", "MP3 Audio"),
    ".wav": ("audio/wav", "WAV Audio"),
    ".flac": ("audio/flac", "FLAC Audio"),
    ".ogg": ("audio/ogg", "OGG Audio"),
    ".mp4": ("video/mp4", "MP4 Video"),
    ".avi": ("video/x-msvideo", "AVI Video"),
    ".mkv": ("video/x-matroska", "Matroska Video"),
    ".mov": ("video/quicktime", "QuickTime Video"),
    ".wmv": ("video/x-ms-wmv", "Windows Media Video"),
    ".sql": ("application/x-sql", "SQL Script"),
    ".db": ("application/x-sqlite3", "SQLite Database"),
    ".sqlite": ("application/x-sqlite3", "SQLite Database"),
    ".sqlite3": ("application/x-sqlite3", "SQLite Database"),
    ".mdb": ("application/x-msaccess", "Microsoft Access Database"),
}


def get_file_mime_type(file_path: str) -> Tuple[str, str]:
    """Get the MIME type of a file using the 'file' command.

    Args:
        file_path: Path to the file

    Returns:
        Tuple of (mime_type_code, mime_type_description)

    Note:
        On Unix systems, uses the 'file' command for MIME detection.
        Falls back to extension-based detection if 'file' is unavailable.
        Falls back to generic binary for unknown types.
    """
    logger = get_logger_instance()

    # Try using 'file' command on Unix
    if os.name == "posix":
        try:
            result = subprocess.run(
                ["file", "-b", "--mime-type", file_path],
                capture_output=True,
                text=True,
                check=True,
                timeout=10,
            )
            output = result.stdout.strip()
            if output:
                # file command returns just the MIME type
                return (output, _describe_mime_type(output))
        except subprocess.CalledProcessError:
            logger.debug(f"'file' command failed for {file_path}")
        except FileNotFoundError:
            logger.debug("'file' command not found, using fallback")
        except subprocess.TimeoutExpired:
            logger.warning(f"'file' command timed out for {file_path}")

    # Fallback: try python-magic if available
    try:
        import magic

        mime = magic.Magic(mime=True)
        mime_type = mime.from_file(file_path)
        if mime_type:
            return (mime_type, _describe_mime_type(mime_type))
    except ImportError:
        logger.debug("python-magic not available")
    except Exception as e:
        logger.debug(f"python-magic failed: {e}")

    # Final fallback: extension-based detection
    return get_mime_from_extension(file_path)


def get_mime_from_extension(file_path: str) -> Tuple[str, str]:
    """Get MIME type based on file extension.

    Args:
        file_path: Path to the file

    Returns:
        Tuple of (mime_type_code, mime_type_description)
    """
    from pathlib import Path

    ext = Path(file_path).suffix.lower()

    if ext in EXTENSION_FALLBACK:
        return EXTENSION_FALLBACK[ext]

    # Default fallback for unknown extensions
    return ("application/octet-stream", "Binary File")


def _describe_mime_type(mime_type: str) -> str:
    """Get a human-readable description for a MIME type.

    Args:
        mime_type: MIME type code

    Returns:
        Human-readable description
    """
    # Common MIME type descriptions
    descriptions = {
        "text/plain": "Plain Text",
        "text/csv": "Comma-Separated Values",
        "application/json": "JavaScript Object Notation",
        "application/xml": "XML Document",
        "text/html": "HTML Document",
        "text/css": "Cascading Style Sheet",
        "application/javascript": "JavaScript",
        "text/x-python": "Python Source",
        "application/x-sh": "Shell Script",
        "text/markdown": "Markdown Document",
        "application/pdf": "PDF Document",
        "application/zip": "ZIP Archive",
        "image/jpeg": "JPEG Image",
        "image/png": "PNG Image",
        "image/gif": "GIF Image",
        "image/svg+xml": "SVG Image",
        "audio/mpeg": "MP3 Audio",
        "video/mp4": "MP4 Video",
        "application/octet-stream": "Binary File",
    }

    return descriptions.get(mime_type, mime_type.split("/")[-1].replace("-", " ").title())


def is_text_file(file_path: str) -> bool:
    """Check if a file is a text file based on MIME type.

    Args:
        file_path: Path to the file

    Returns:
        True if the file appears to be text
    """
    mime_type, _ = get_file_mime_type(file_path)
    return mime_type.startswith("text/")


def is_image_file(file_path: str) -> bool:
    """Check if a file is an image based on MIME type.

    Args:
        file_path: Path to the file

    Returns:
        True if the file appears to be an image
    """
    mime_type, _ = get_file_mime_type(file_path)
    return mime_type.startswith("image/")


def is_audio_file(file_path: str) -> bool:
    """Check if a file is an audio file based on MIME type.

    Args:
        file_path: Path to the file

    Returns:
        True if the file appears to be audio
    """
    mime_type, _ = get_file_mime_type(file_path)
    return mime_type.startswith("audio/")


def is_video_file(file_path: str) -> bool:
    """Check if a file is a video file based on MIME type.

    Args:
        file_path: Path to the file

    Returns:
        True if the file appears to be video
    """
    mime_type, _ = get_file_mime_type(file_path)
    return mime_type.startswith("video/")


def is_archive_file(file_path: str) -> bool:
    """Check if a file is an archive based on MIME type.

    Args:
        file_path: Path to the file

    Returns:
        True if the file appears to be an archive
    """
    mime_type, _ = get_file_mime_type(file_path)
    archive_mimes = {
        "application/zip",
        "application/x-tar",
        "application/gzip",
        "application/x-bzip2",
        "application/x-7z-compressed",
        "application/x-rar-compressed",
    }
    return mime_type in archive_mimes


__all__ = [
    "get_file_mime_type",
    "get_mime_from_extension",
    "is_text_file",
    "is_image_file",
    "is_audio_file",
    "is_video_file",
    "is_archive_file",
]
