"""Command-line interface package for MyLibraryScanner."""

from mylibraryscanner.cli.interface import build_parser, main
from mylibraryscanner.cli.commands import (
    cmd_init,
    cmd_library_infer_source,
    cmd_library_list_sources,
    cmd_library_remove_source,
    cmd_scan_target,
    cmd_scan_path,
    execute_command,
)

__all__ = [
    "main",
    "build_parser",
    "cmd_init",
    "cmd_scan_target",
    "cmd_scan_path",
    "cmd_library_list_sources",
    "cmd_library_remove_source",
    "cmd_library_infer_source",
    "execute_command",
]
