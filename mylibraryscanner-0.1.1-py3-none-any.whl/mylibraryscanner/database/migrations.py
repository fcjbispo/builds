"""Database migration support for MyLibraryScanner.

This module provides database migration capabilities to handle schema evolution
and version control for the MyLibraryScanner database.
"""

from pathlib import Path
from typing import List, Optional
import json
from datetime import datetime

from alembic import op
from alembic.runtime.migration import MigrationContext
from alembic.config import Config
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from .models import Base


class MigrationManager:
    """Manages database migrations for MyLibraryScanner."""
    
    def __init__(self, database_url: str):
        """Initialize migration manager.
        
        Args:
            database_url: PostgreSQL database connection URL
        """
        self.database_url = database_url
        self.alembic_cfg = self._create_alembic_config()
    
    def _create_alembic_config(self) -> Config:
        """Create Alembic configuration."""
        alembic_cfg = Config()
        
        # Set basic configuration
        alembic_cfg.set_main_option("sqlalchemy.url", self.database_url)
        alembic_cfg.set_main_option("script_location", str(Path(__file__).parent / "alembic"))
        
        # Configure script generation
        alembic_cfg.set_main_option("file_template", "%%(year)d%%(month).2d%%(day).2d_%%(hour).2d%%(minute).2d_%%(rev)s_%%(slug)s")
        alembic_cfg.set_main_option("truncate_slug_length", "40")
        
        # Configure database settings
        alembic_cfg.set_main_option("timezone", "UTC")
        
        return alembic_cfg
    
    def generate_migration(self, message: str, autogenerate: bool = True) -> str:
        """Generate a new migration.
        
        Args:
            message: Migration description message
            autogenerate: Whether to autogenerate migration based on model changes
            
        Returns:
            Generated migration revision
        """
        from alembic.command import revision
        
        revision_result = revision(
            self.alembic_cfg,
            message=message,
            autogenerate=autogenerate,
            head="head"
        )
        
        return revision_result.revision
    
    def upgrade_database(self, revision: str = "head") -> None:
        """Apply migrations to upgrade database."""
        from alembic.command import upgrade
        
        upgrade(self.alembic_cfg, revision)
    
    def downgrade_database(self, revision: str) -> None:
        """Downgrade database to specific revision."""
        from alembic.command import downgrade
        
        downgrade(self.alembic_cfg, revision)
    
    def show_history(self) -> List[dict]:
        """Show migration history."""
        from alembic.command import history
        
        return history(self.alembic_cfg) or []
    
    def show_current_revision(self) -> Optional[str]:
        """Get current database revision."""
        from alembic.command import current
        
        try:
            current(self.alembic_cfg)
            # Parse output to get revision
            return "current"
        except:
            return None
    
    def stamp_database(self, revision: str) -> None:
        """Set database to specific revision without applying migrations."""
        from alembic.command import stamp
        
        stamp(self.alembic_cfg, revision)
    
    def check_model_consistency(self) -> List[str]:
        """Check if database schema matches current models.
        
        Returns:
            List of differences between models and database
        """
        from alembic.autogenerate import compare_metadata
        from alembic.runtime.migration import MigrationContext
        
        engine = create_engine(self.database_url)
        
        with engine.begin() as connection:
            migration_context = MigrationContext.configure(connection)
            
            # Compare current models with database
            differences = list(compare_metadata(migration_context, Base.metadata))
            
            engine.dispose()
            return differences


def create_initial_migration(database_url: str) -> str:
    """Create initial migration for MyLibraryScanner.
    
    Args:
        database_url: PostgreSQL database URL
        
    Returns:
        Migration revision string
    """
    migration_manager = MigrationManager(database_url)
    
    # Generate initial migration
    revision = migration_manager.generate_migration(
        "Initial schema with sources and source_files tables",
        autogenerate=True
    )
    
    return revision


def setup_migrations(database_url: str) -> None:
    """Set up migration system for MyLibraryScanner.
    
    Args:
        database_url: PostgreSQL database URL
    """
    migration_manager = MigrationManager(database_url)
    
    # Create Alembic directory structure if it doesn't exist
    alembic_dir = Path(__file__).parent / "alembic"
    versions_dir = alembic_dir / "versions"
    
    alembic_dir.mkdir(exist_ok=True)
    versions_dir.mkdir(exist_ok=True)
    
    # Create alembic.ini if it doesn't exist
    alembic_ini_path = Path(__file__).parent / "alembic.ini"
    if not alembic_ini_path.exists():
        _create_alembic_ini(alembic_ini_path)
    
    # Create env.py if it doesn't exist
    env_py_path = alembic_dir / "env.py"
    if not env_py_path.exists():
        _create_env_py(env_py_path)
    
    # Create script.py.mako if it doesn't exist
    script_mako_path = alembic_dir / "script.py.mako"
    if not script_mako_path.exists():
        _create_script_mako(script_mako_path)


def _create_alembic_ini(path: Path) -> None:
    """Create alembic.ini configuration file."""
    content = """# Alembic configuration for MyLibraryScanner

[alembic]
# path to migration scripts
script_location = %(__file__)s/../../migrations/alembic

# template used to generate migration files
file_template = %%(year)d%%(month).2d%%(day).2d_%%(hour).2d%%(minute).2d_%%(rev)s_%%(slug)s

# timezone to use when rendering the date within the migration file
# as well as the filename
timezone = UTC

# max length of characters to apply to the "slug" field
truncate_slug_length = 40

# set to 'true' to run the environment during
# the 'revision' command, regardless of autogenerate
# revision_environment = false

# set to 'true' to allow .pyc and .pyo files without
# a source .py file to be detected as revisions in the
# versions/ directory
# sourceless = false

# version to use for the migration database table
version_table = alembic_version_mylibraryscanner

# version table schema name
# version_table_schema = None

# the encoding format to use when writing version
# files
output_encoding = utf-8

[post_write_hooks]
# post_write_hooks defines scripts or Python functions that are run
# on newly generated revision scripts.  See the documentation for further
# detail and examples

# format using "black" - use the console_scripts runner, against the "black" entrypoint
# hooks = black
# black.type = console_scripts
# black.entrypoint = black
# black.options = -l 79 REVISION_SCRIPT_FILENAME

# Logging configuration
[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
"""
    
    path.write_text(content)


def _create_env_py(path: Path) -> None:
    """Create env.py for Alembic."""
    content = '''"""Alembic environment configuration for MyLibraryScanner migrations."""

from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

# Import your models here
from mylibraryscanner.database.models import Base
from mylibraryscanner.database import DatabaseManager, DatabaseConfig

# Alembic Config object
config = context.config

# Interpret the config file for Python logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Model metadata
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations in offline mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in online mode."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection, target_metadata=target_metadata
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
'''
    
    path.write_text(content)


def _create_script_mako(path: Path) -> None:
    """Create script.py.mako for migration template."""
    content = '"""${message}\n\nRevision ID: ${up_revision}\nRevises: ${down_revision | comma,n}\nCreate Date: ${create_date}\n\n"""\nfrom alembic import op\nimport sqlalchemy as sa\n${imports if imports else ""}\n\n# revision identifiers, used by Alembic.\nrevision = ${repr(up_revision)}\ndown_revision = ${repr(down_revision)}\nbranch_labels = ${repr(branch_labels)}\ndepends_on = ${repr(depends_on)}\n\n\ndef upgrade() -> None:\n    ${upgrades if upgrades else "pass"}\n\n\ndef downgrade() -> None:\n    ${downgrades if downgrades else "pass"}\n'''
    
    path.write_text(content)


__all__ = [
    "MigrationManager",
    "create_initial_migration", 
    "setup_migrations",
]