"""Database models for MyLibraryScanner using FBNet standard configuration.

This module contains SQLAlchemy models for the database schema defined in MODEL.md.
It uses the FBNet configuration system for database settings and logging.
"""

import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

from sqlalchemy import (
    Column,
    String,
    Integer,
    DateTime,
    Text,
    ForeignKey,
    CheckConstraint,
    Index,
    func,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship, declarative_base, Mapped, mapped_column
from sqlalchemy.ext.declarative import DeclarativeMeta

# Create the declarative base
Base = declarative_base()


class Source(Base):
    """Master table representing a scan operation on a specific directory source, supporting LOCAL, REMOVABLE, and REMOTE sources.

        This table stores high-level information about scan operations, including
    the directory scanned, timing information, source type, and overall status.
    """

    __tablename__ = "sources"

    # Constants for source kinds
    SOURCE_KIND_LOCAL = "LOCAL"
    SOURCE_KIND_REMOVABLE = "REMOVABLE"
    SOURCE_KIND_REMOTE = "REMOTE"

    # Primary key
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Unique identifier for the scan",
    )

    # Source identification
    source_name: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        nullable=False,
        index=True,
        comment="Human-readable name for the source",
    )

    source_kind: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=SOURCE_KIND_LOCAL,
        comment="Type of source: LOCAL, REMOVABLE, or REMOTE",
    )

    source_dir: Mapped[str] = mapped_column(
        String(500), nullable=False, comment="Directory path that was scanned"
    )

    source_mask: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="File pattern used for scanning (e.g., '*')",
    )

    # Timing information
    start_extraction: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, comment="When the scan operation started"
    )

    end_extraction: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True, comment="When the scan operation completed"
    )

    # Status and statistics
    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="OK",
        comment="Overall scan status (OK, FAIL, PENDING)",
    )

    files_total: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, comment="Total number of files found"
    )

    # Audit fields
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=func.now(),
        comment="Record creation timestamp",
    )

    updated_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime,
        nullable=True,
        onupdate=func.now(),
        comment="Record last update timestamp",
    )

    # Relationships
    source_files: Mapped[List["SourceFile"]] = relationship(
        "SourceFile",
        back_populates="source",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    # Table constraints
    __table_args__ = (
        CheckConstraint(
            "status IN ('OK', 'FAIL', 'PENDING')", name="check_source_status"
        ),
        CheckConstraint(
            "source_kind IN ('LOCAL', 'REMOVABLE', 'REMOTE')", name="check_source_kind"
        ),
        Index("idx_sources_source_name", "source_name"),
        Index("idx_sources_status", "status"),
        Index("idx_sources_source_kind", "source_kind"),
    )

    def __repr__(self) -> str:
        return f"<Source(id={self.id}, source_name='{self.source_name}', status='{self.status}')>"

    def __str__(self) -> str:
        return f"{self.source_name} ({self.source_dir})"

    @property
    def file_count(self) -> int:
        """Return the count of associated source files."""
        return len(self.source_files)

    def get_successful_files(self) -> List["SourceFile"]:
        """Return only successfully processed files."""
        return [file for file in self.source_files if file.status == "OK"]

    def get_error_files(self) -> List["SourceFile"]:
        """Return files with errors."""
        return [file for file in self.source_files if file.status == "ERROR"]

    def is_local_source(self) -> bool:
        """Check if this is a local source."""
        return self.source_kind == self.SOURCE_KIND_LOCAL

    def is_removable_source(self) -> bool:
        """Check if this is a removable source."""
        return self.source_kind == self.SOURCE_KIND_REMOVABLE

    def is_remote_source(self) -> bool:
        """Check if this is a remote source."""
        return self.source_kind == self.SOURCE_KIND_REMOTE

    def get_source_behavior_description(self) -> str:
        """Get description of source behavior based on kind."""
        descriptions = {
            self.SOURCE_KIND_LOCAL: "Local filesystem source with normal access and permissions",
            self.SOURCE_KIND_REMOVABLE: "Removable device source that may be disconnected or have changing availability",
            self.SOURCE_KIND_REMOTE: "Remote network source with potential connectivity issues and authentication requirements",
        }
        return descriptions.get(
            self.source_kind, f"Unknown source kind: {self.source_kind}"
        )

    def validate_source_access(self) -> bool:
        """Validate if this source can be accessed based on its kind.

        Returns:
            True if source can be accessed, False otherwise
        """
        try:
            if self.source_kind == self.SOURCE_KIND_LOCAL:
                from pathlib import Path

                path = Path(self.source_dir)
                return path.exists() and path.is_dir()
            elif self.source_kind == self.SOURCE_KIND_REMOVABLE:
                # For removable - check if path exists (will be enhanced later)
                from pathlib import Path

                path = Path(self.source_dir)
                return path.exists() and path.is_dir()
            elif self.source_kind == self.SOURCE_KIND_REMOTE:
                # For remote - perform connection test (will be implemented later)
                return True  # Placeholder - will implement connection validation
            else:
                return False
        except Exception as e:
            return False


class SourceFile(Base):
    """Detail table containing individual files found during a scan operation.

        This table stores file-specific information with JSONB storage for flexible
    metadata while maintaining compatibility with existing database views from
    the original project.
    """

    __tablename__ = "source_files"

    # Primary key
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Unique identifier for the file record",
    )

    # Foreign key to sources - using UUID type
    source_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("sources.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        comment="Reference to the parent scan",
    )

    # File identification
    file_path: Mapped[str] = mapped_column(
        Text, nullable=False, comment="Full absolute path to the file"
    )

    # Processing status
    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="OK",
        comment="File processing status (OK, ERROR)",
    )

    status_message: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True, comment="Error message if status is ERROR"
    )

    inference: Mapped[Optional[str]] = mapped_column(
        String(5120),
        nullable=True,
        comment="Concise content inference (max 5KB)",
    )

    # Extracted attributes for efficient querying
    md5sum: Mapped[Optional[str]] = mapped_column(
        String(32),
        nullable=True,
        index=True,
        comment="MD5 hash of entire file (from details JSON) - Critical for duplicate detection",
    )

    # Flexible JSON storage for metadata
    details: Mapped[Dict[str, Any]] = mapped_column(
        JSONB,
        nullable=False,
        default=dict,
        comment="PostgreSQL JSONB containing complete file metadata",
    )

    # Processing timestamp
    processed_at: Mapped[datetime] = mapped_column(
        DateTime,
        nullable=False,
        default=func.now(),
        comment="When this file record was processed",
    )

    # Relationships
    source: Mapped["Source"] = relationship(
        "Source", back_populates="source_files", lazy="joined"
    )

    # Table constraints and indexes
    __table_args__ = (
        CheckConstraint("status IN ('OK', 'ERROR')", name="check_source_file_status"),
        CheckConstraint(
            "char_length(md5sum) = 32 OR md5sum IS NULL", name="check_md5sum_length"
        ),
        CheckConstraint(
            "char_length(inference) <= 5120 OR inference IS NULL",
            name="check_inference_length",
        ),
        Index("idx_source_files_source_id", "source_id"),
        Index("idx_source_files_md5sum", "md5sum"),
        Index("idx_source_files_status", "status"),
    )

    def __repr__(self) -> str:
        return f"<SourceFile(id={self.id}, file_path='{self.file_path}', status='{self.status}')>"

    def __str__(self) -> str:
        return f"{self.file_path} [{self.status}]"

    def extract_md5sum_from_details(self) -> Optional[str]:
        """Extract MD5 hash from the details JSONB column.

        Returns:
            MD5 hash string if found in details, None otherwise
        """
        if self.details and isinstance(self.details, dict):
            return self.details.get("md5sum")
        return None

    def update_md5sum_from_details(self) -> None:
        """Update the normalized md5sum column from the details JSONB.

        This method should be called before saving to ensure consistency
        between the normalized column and the JSONB details.
        """
        self.md5sum = self.extract_md5sum_from_details()

    def get_file_size(self) -> Optional[int]:
        """Get file size from details JSONB.

        Returns:
            File size in bytes if available, None otherwise
        """
        if self.details and isinstance(self.details, dict):
            return self.details.get("size_bytes")
        return None

    def get_mime_type(self) -> Optional[str]:
        """Get MIME type from details JSONB.

        Returns:
            MIME type code if available, None otherwise
        """
        if self.details and isinstance(self.details, dict):
            return self.details.get("mime_type_code")
        return None

    def get_file_extension(self) -> Optional[str]:
        """Get file extension from details JSONB.

        Returns:
            File extension if available, None otherwise
        """
        if self.details and isinstance(self.details, dict):
            return self.details.get("extension")
        return None

    def is_duplicate_by_md5(self) -> bool:
        """Check if this file is a duplicate based on MD5 hash.

        This is used for integration with existing duplicate detection logic.

        Returns:
            True if file has MD5 hash and should be considered for duplicate detection
        """
        return self.md5sum is not None and self.status == "OK"

    def get_details_property(self, key: str, default: Any = None) -> Any:
        """Get a specific property from the details JSONB.

        Args:
            key: Property name to retrieve
            default: Default value if key not found

        Returns:
            Property value or default
        """
        if self.details and isinstance(self.details, dict):
            return self.details.get(key, default)
        return default

    def set_details_property(self, key: str, value: Any) -> None:
        """Set a specific property in the details JSONB.

        Args:
            key: Property name to set
            value: Property value to set
        """
        if not self.details:
            self.details = {}
        self.details[key] = value

    def to_dict_for_ai_analysis(self) -> Dict[str, Any]:
        """Convert to dictionary format suitable for AI analysis.

        Returns:
            Dictionary with all relevant file information for AI processing
        """
        return {
            "file_path": self.file_path,
            "complete_filename": self.get_details_property("complete_filename", ""),
            "filename_no_ext": self.get_details_property("filename_no_ext", ""),
            "extension": self.get_details_property("extension", ""),
            "size_bytes": self.get_details_property("size_bytes", 0),
            "creation_date": self.get_details_property("creation_date", ""),
            "mime_type_code": self.get_mime_type(),
            "mime_type_description": self.get_details_property(
                "mime_type_description", ""
            ),
            "md5sum": self.md5sum,
            "first_256_bytes_sha256_hex": self.get_details_property(
                "first_256_bytes_sha256_hex", ""
            ),
            "status": self.status,
            "status_message": self.status_message,
            "inference": self.inference,
        }
