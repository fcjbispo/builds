"""Database connection management for MyLibraryScanner using FBNet configuration.

This module handles database connections, session management, and configuration
using the FBNet standard system from fbpyutils.
"""

import os
from typing import Optional, Generator, Any, Dict
from contextlib import contextmanager
from urllib.parse import urlparse

from sqlalchemy import create_engine, event, text, inspect
from sqlalchemy.engine import Engine, URL
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import NullPool, StaticPool

from .models import Base
from mylibraryscanner.initialization import get_env_instance, get_logger_instance, get_app_config
from fbpyutils import Logger


class DatabaseManager:
    """Database connection and session manager for MyLibraryScanner.
    
    Uses FBNet environment variables for configuration:
    - FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL: PostgreSQL connection URL
    - FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA: Database schema name
    """
    
    def __init__(self, schema: Optional[str] = None, database_url: Optional[str] = None):
        """Initialize database manager with FBNet configuration.
        
        Args:
            schema: Optional database schema name (defaults to FBNet config)
            database_url: Optional database URL override
        """
        self.env = get_env_instance()
        self.logger = get_logger_instance()
        self.database_url = database_url
        self.schema = schema or self._get_schema_from_config()
        self._engine: Optional[Engine] = None
        self._session_factory: Optional[sessionmaker] = None
        
        # Initialize connection
        self._initialize()
    
    def _get_schema_from_config(self) -> str:
        """Get database schema from FBNet environment variables."""
        env = self.env
        if hasattr(env, 'get'):
            schema = (
                env.get("MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA", "")
                or env.get("FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA", "")
            )
        else:
            # Fallback to dictionary-style access if Env is dict-like
            try:
                schema = env["MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA"]
            except (KeyError, TypeError):
                try:
                    schema = env["FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA"]
                except (KeyError, TypeError):
                    schema = ""

        if not schema:
            # Direct env fallback prioritizing FBNET convention.
            schema = (
                os.getenv("FBNET_MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA", "")
                or os.getenv("MYLIBRARYSCANNER_SYSTEM_DB_SCHEMA", "")
                or os.getenv("DB_SCHEMA", "")
                or os.getenv("SYSTEM_DB_SCHEMA", "")
            )
        
        if not schema:
            # Fallback to default configuration from app.json
            config = get_app_config()
            default_schema = config.get('config', {}).get('system_db_schema', 'mylibrary')
            self.logger.info(f"Using default schema from app.json: {default_schema}")
            return default_schema
        return schema
    
    def _get_database_url(self) -> str:
        """Get database URL from FBNet environment variables."""
        if self.database_url:
            return self.database_url

        env = self.env
        if hasattr(env, 'get'):
            url = (
                env.get("MYLIBRARYSCANNER_SYSTEM_DB_URL", "")
                or env.get("FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL", "")
            )
        else:
            # Fallback to dictionary-style access if Env is dict-like
            try:
                url = env["MYLIBRARYSCANNER_SYSTEM_DB_URL"]
            except (KeyError, TypeError):
                try:
                    url = env["FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL"]
                except (KeyError, TypeError):
                    url = ""

        if not url:
            # Direct env fallback prioritizing FBNET convention.
            url = (
                os.getenv("FBNET_MYLIBRARYSCANNER_SYSTEM_DB_URL", "")
                or os.getenv("MYLIBRARYSCANNER_SYSTEM_DB_URL", "")
                or os.getenv("SYSTEM_DB_URL", "")
            )
        
        if not url:
            # Fallback to app.json default configuration
            config = get_app_config()
            default_url = config.get('config', {}).get('system_db_url', 'postgresql://user:password@host:port/database')
            return default_url
        return url
    
    def _initialize(self) -> None:
        """Initialize database engine and session factory using FBNet config (silent)."""
        try:
            database_url = self._get_database_url()
            
            # Create engine with connection pooling
            self._engine = create_engine(
                database_url,
                pool_size=10,
                max_overflow=20,
                pool_timeout=30,
                echo=False,
                pool_pre_ping=True,  # Verify connections before use
                pool_recycle=3600,   # Recycle connections after 1 hour
            )
            
            # Configure PostgreSQL-specific settings
            self._configure_postgres_engine()
            
            # Create session factory
            self._session_factory = sessionmaker(
                bind=self._engine,
                expire_on_commit=False,
                autoflush=False,
                autocommit=False,
            )

            # Runtime compatibility for additive schema changes.
            self._ensure_runtime_schema_compatibility()
            
            # Log via fbpyutils system (goes to log file)
            self.logger.info("Database connection initialized successfully")
            
        except Exception as e:
            # CRITICAL error only to console
            self.logger.error(f"Failed to initialize database connection: {e}")
            raise

    def _ensure_runtime_schema_compatibility(self) -> None:
        """Apply additive schema compatibility changes if needed."""
        if not self._engine:
            return
        try:
            with self._engine.begin() as conn:
                conn.execute(
                    text(
                        "ALTER TABLE IF EXISTS source_files "
                        "ADD COLUMN IF NOT EXISTS inference VARCHAR(5120)"
                    )
                )
        except Exception as e:
            # Non-fatal: keep startup resilient for environments with restricted DDL.
            self.logger.warning(f"Could not ensure runtime schema compatibility: {e}")
    
    def _configure_postgres_engine(self) -> None:
        """Configure PostgreSQL-specific engine settings."""
        if not self._engine:
            return

        # Configure PostgreSQL connection for better performance
        @event.listens_for(self._engine, "connect")
        def set_postgres_settings(dbapi_connection, connection_record):
            cursor = dbapi_connection.cursor()

            # Set search path to use configured schema
            cursor.execute(f"SET search_path TO {self.schema}, public")

            # Set timezone to UTC
            cursor.execute("SET TIMEZONE = 'UTC'")

            # Set statement timeout (30 minutes for long operations)
            cursor.execute("SET statement_timeout = '30min'")

            cursor.close()

    @property
    def engine(self) -> Engine:
        """Get the SQLAlchemy engine."""
        if not self._engine:
            raise RuntimeError("Database engine not initialized")
        return self._engine
    
    @property
    def session_factory(self) -> sessionmaker:
        """Get the session factory."""
        if not self._session_factory:
            raise RuntimeError("Session factory not initialized")
        return self._session_factory
    
    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """Get a database session with automatic cleanup.
        
        Yields:
            SQLAlchemy Session object
            
        Example:
            with database_manager.get_session() as session:
                sources = session.query(Source).all()
        """
        session = self.session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    def create_tables(self, drop_existing: bool = False) -> None:
        """Create all database tables.
        
        Args:
            drop_existing: Whether to drop existing tables before creating
        """
        try:
            if drop_existing:
                Base.metadata.drop_all(bind=self.engine)
            
            # Create tables with the correct schema
            Base.metadata.create_all(bind=self.engine)
            
            # Verify schema was created
            self._verify_schema_created()
            
            self.logger.info("Database tables created successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to create database tables: {e}")
            raise
    
    def _verify_schema_created(self) -> None:
        """Verify that all required tables were created successfully."""
        from .models import Source, SourceFile
        
        # Check if critical tables exist
        inspector = inspect(self.engine)
        
        # Get table names
        table_names = inspector.get_table_names()
        
        required_tables = ["sources", "source_files"]
        missing_tables = [table for table in required_tables if table not in table_names]
        
        if missing_tables:
            raise RuntimeError(f"Required tables not created: {missing_tables}")
        
        self.logger.info("Database schema verified successfully")
    
    def get_connection_info(self) -> Dict[str, Any]:
        """Get database connection information for debugging."""
        try:
            with self.get_session() as session:
                # Test connection and get PostgreSQL version
                result = session.execute(text("SELECT version()")).scalar_one()
                
                # Get current schema
                schema = session.execute(text("SELECT current_schema()")).scalar_one()
                
                # Get current database
                database = session.execute(text("SELECT current_database()")).scalar_one()
                
                return {
                    "postgresql_version": str(result),
                    "current_schema": str(schema),
                    "current_database": str(database),
                    "schema": self.schema,
                    "engine_url": str(self.engine.url),
                }
        except Exception as e:
            return {"error": str(e)}
    
    def health_check(self) -> Dict[str, Any]:
        """Perform a health check on the database connection.
        
        Returns:
            Health status dictionary
        """
        try:
            # Test connection
            with self.get_session() as session:
                # Simple query to test connectivity
                result = session.execute(text("SELECT 1")).scalar_one()
                
                # Get number of sources
                from .models import Source, SourceFile
                source_count = session.query(Source).count()
                
                # Get number of source files
                file_count = session.query(SourceFile).count()
                
                return {
                    "status": "healthy",
                    "connection_test": result == 1,
                    "total_sources": source_count,
                    "total_files": file_count,
                    "engine_connected": self.engine is not None,
                    "session_factory_ready": self.session_factory is not None,
                    "schema": self.schema,
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "connection_info": self.get_connection_info(),
            }
    
    def close(self) -> None:
        """Close database connections and cleanup resources."""
        if self._engine:
            self._engine.dispose()
            self._engine = None
        self._session_factory = None
        self.logger.info("Database connection closed")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.close()


# Import models for convenience
from .models import Source, SourceFile

__all__ = [
    "Base",
    "Source", 
    "SourceFile",
    "DatabaseManager",
]
