"""Database operations module for MyLibraryScanner.

This module provides repository classes for database CRUD operations
on sources and source_files tables.
"""

import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any, Generator
from dataclasses import asdict

from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_

from mylibraryscanner.database.connection import DatabaseManager
from mylibraryscanner.database.models import Source, SourceFile
from mylibraryscanner.initialization import get_logger_instance


class SourceRepository:
    """Repository for Source model CRUD operations."""

    def __init__(self, db_manager: DatabaseManager):
        """Initialize source repository.

        Args:
            db_manager: Database manager instance
        """
        self.db_manager = db_manager
        self.logger = get_logger_instance()

    def create(
        self,
        source_name: str,
        source_dir: str,
        source_mask: str = "*",
        source_kind: str = "LOCAL",
    ) -> Source:
        """Create a new source record.

        Args:
            source_name: Human-readable name for the source
            source_dir: Directory path that was scanned
            source_mask: File pattern used for scanning
            source_kind: Type of source (LOCAL, REMOVABLE, REMOTE)

        Returns:
            Created Source instance
        """
        with self.db_manager.get_session() as session:
            source = Source(
                source_name=source_name,
                source_dir=source_dir,
                source_mask=source_mask,
                source_kind=source_kind,
                start_extraction=datetime.now(),
                status="PENDING",
            )
            session.add(source)
            session.flush()

            self.logger.info(f"Created source: {source_name}")
            return source

    def get_by_id(self, source_id: uuid.UUID) -> Optional[Source]:
        """Get source by ID.

        Args:
            source_id: Source UUID

        Returns:
            Source instance or None
        """
        with self.db_manager.get_session() as session:
            return session.query(Source).filter(Source.id == source_id).first()

    def get_by_name(self, source_name: str) -> Optional[Source]:
        """Get source by name.

        Args:
            source_name: Source name

        Returns:
            Source instance or None
        """
        with self.db_manager.get_session() as session:
            return session.query(Source).filter(Source.source_name == source_name).first()

    def get_all(self) -> List[Source]:
        """Get all sources.

        Returns:
            List of Source instances
        """
        with self.db_manager.get_session() as session:
            return session.query(Source).order_by(Source.created_at.desc()).all()

    def get_by_status(self, status: str) -> List[Source]:
        """Get sources by status.

        Args:
            status: Status to filter by

        Returns:
            List of Source instances
        """
        with self.db_manager.get_session() as session:
            return session.query(Source).filter(Source.status == status).all()

    def update(
        self,
        source_id: uuid.UUID,
        source_name: Optional[str] = None,
        source_dir: Optional[str] = None,
        source_mask: Optional[str] = None,
        source_kind: Optional[str] = None,
        start_extraction: Optional[datetime] = None,
        end_extraction: Optional[datetime] = None,
        status: Optional[str] = None,
        files_total: Optional[int] = None,
    ) -> Optional[Source]:
        """Update source record.

        Args:
            source_id: Source UUID
            end_extraction: End extraction timestamp
            status: Status to set
            files_total: Total files count

        Returns:
            Updated Source instance or None
        """
        with self.db_manager.get_session() as session:
            source = session.query(Source).filter(Source.id == source_id).first()
            if not source:
                return None

            if source_name:
                source.source_name = source_name
            if source_dir:
                source.source_dir = source_dir
            if source_mask:
                source.source_mask = source_mask
            if source_kind:
                source.source_kind = source_kind
            if start_extraction:
                source.start_extraction = start_extraction
            if end_extraction:
                source.end_extraction = end_extraction
            if status:
                source.status = status
            if files_total is not None:
                source.files_total = files_total

            source.updated_at = datetime.now()
            session.flush()

            self.logger.info(f"Updated source: {source.source_name}")
            return source

    def delete(self, source_id: uuid.UUID) -> bool:
        """Delete a source and all its files.

        Args:
            source_id: Source UUID

        Returns:
            True if deleted, False if not found
        """
        with self.db_manager.get_session() as session:
            source = session.query(Source).filter(Source.id == source_id).first()
            if not source:
                return False

            session.delete(source)
            session.flush()

            self.logger.info(f"Deleted source: {source.source_name}")
            return True

    def count(self) -> int:
        """Count total sources.

        Returns:
            Number of sources
        """
        with self.db_manager.get_session() as session:
            return session.query(Source).count()


class SourceFileRepository:
    """Repository for SourceFile model CRUD operations."""

    def __init__(self, db_manager: DatabaseManager):
        """Initialize source file repository.

        Args:
            db_manager: Database manager instance
        """
        self.db_manager = db_manager
        self.logger = get_logger_instance()

    def create(
        self,
        source_id: uuid.UUID,
        file_path: str,
        status: str = "OK",
        status_message: Optional[str] = None,
        inference: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> SourceFile:
        """Create a new source file record.

        Args:
            source_id: Parent source UUID
            file_path: Full path to the file
            status: Processing status
            status_message: Error message if status is ERROR
            details: JSONB details dictionary

        Returns:
            Created SourceFile instance
        """
        # Extract md5sum from details if present
        md5sum = None
        if details and isinstance(details, dict):
            md5sum = details.get("md5sum")

        with self.db_manager.get_session() as session:
            source_file = SourceFile(
                source_id=source_id,
                file_path=file_path,
                status=status,
                status_message=status_message,
                inference=inference,
                details=details or {},
                md5sum=md5sum,
                processed_at=datetime.now(),
            )
            session.add(source_file)
            session.flush()

            return source_file

    def create_batch(
        self,
        source_id: uuid.UUID,
        files_data: List[Dict[str, Any]],
    ) -> int:
        """Create multiple source file records in batch.

        Args:
            source_id: Parent source UUID
            files_data: List of file data dictionaries

        Returns:
            Number of records created
        """
        now = datetime.now()

        source_files = []
        for file_data in files_data:
            details = file_data.get("details", {})
            md5sum = details.get("md5sum") if isinstance(details, dict) else None

            source_files.append(
                SourceFile(
                    source_id=source_id,
                    file_path=file_data["file_path"],
                    status=file_data.get("status", "OK"),
                    status_message=file_data.get("status_message"),
                    inference=file_data.get("inference"),
                    details=details,
                    md5sum=md5sum,
                    processed_at=now,
                )
            )

        with self.db_manager.get_session() as session:
            session.add_all(source_files)
            session.flush()

            self.logger.info(f"Created {len(source_files)} file records for source {source_id}")
            return len(source_files)

    def get_by_id(self, file_id: uuid.UUID) -> Optional[SourceFile]:
        """Get source file by ID.

        Args:
            file_id: SourceFile UUID

        Returns:
            SourceFile instance or None
        """
        with self.db_manager.get_session() as session:
            return session.query(SourceFile).filter(SourceFile.id == file_id).first()

    def get_by_source(self, source_id: uuid.UUID) -> List[SourceFile]:
        """Get all files for a source.

        Args:
            source_id: Source UUID

        Returns:
            List of SourceFile instances
        """
        with self.db_manager.get_session() as session:
            return (
                session.query(SourceFile)
                .filter(SourceFile.source_id == source_id)
                .order_by(SourceFile.file_path)
                .all()
            )

    def get_by_md5(self, md5sum: str) -> List[SourceFile]:
        """Get all files with the same MD5 (duplicates).

        Args:
            md5sum: MD5 hash to search for

        Returns:
            List of SourceFile instances
        """
        with self.db_manager.get_session() as session:
            return (
                session.query(SourceFile)
                .filter(SourceFile.md5sum == md5sum)
                .all()
            )

    def get_errors(self, source_id: uuid.UUID) -> List[SourceFile]:
        """Get all error files for a source.

        Args:
            source_id: Source UUID

        Returns:
            List of error SourceFile instances
        """
        with self.db_manager.get_session() as session:
            return (
                session.query(SourceFile)
                .filter(
                    and_(
                        SourceFile.source_id == source_id,
                        SourceFile.status == "ERROR",
                    )
                )
                .all()
            )

    def count_by_source(self, source_id: uuid.UUID) -> int:
        """Count files for a source.

        Args:
            source_id: Source UUID

        Returns:
            Number of files
        """
        with self.db_manager.get_session() as session:
            return (
                session.query(SourceFile)
                .filter(SourceFile.source_id == source_id)
                .count()
            )

    def count_errors_by_source(self, source_id: uuid.UUID) -> int:
        """Count error files for a source.

        Args:
            source_id: Source UUID

        Returns:
            Number of error files
        """
        with self.db_manager.get_session() as session:
            return (
                session.query(SourceFile)
                .filter(
                    and_(
                        SourceFile.source_id == source_id,
                        SourceFile.status == "ERROR",
                    )
                )
                .count()
            )

    def delete_by_source(self, source_id: uuid.UUID) -> int:
        """Delete all files for a source.

        Args:
            source_id: Source UUID

        Returns:
            Number of records deleted
        """
        with self.db_manager.get_session() as session:
            count = (
                session.query(SourceFile)
                .filter(SourceFile.source_id == source_id)
                .delete()
            )
            session.flush()

            self.logger.info(f"Deleted {count} files for source {source_id}")
            return count

    def find_duplicates(self) -> Dict[str, List[SourceFile]]:
        """Find all duplicate files by MD5.

        Returns:
            Dictionary mapping MD5 to list of SourceFile instances
        """
        with self.db_manager.get_session() as session:
            # Find MD5 values that appear more than once
            md5_counts = (
                session.query(SourceFile.md5sum, func.count(SourceFile.id).label("count"))
                .filter(SourceFile.md5sum.isnot(None))
                .group_by(SourceFile.md5sum)
                .having(func.count(SourceFile.id) > 1)
                .all()
            )

            duplicates = {}
            for md5sum, _ in md5_counts:
                files = (
                    session.query(SourceFile)
                    .filter(SourceFile.md5sum == md5sum)
                    .all()
                )
                duplicates[md5sum] = files

            return duplicates


class ScanRepository:
    """Combined repository for scan operations (scan + store workflow)."""

    def __init__(self, db_manager: DatabaseManager):
        """Initialize scan repository.

        Args:
            db_manager: Database manager instance
        """
        self.db_manager = db_manager
        self.source_repo = SourceRepository(db_manager)
        self.file_repo = SourceFileRepository(db_manager)
        self.logger = get_logger_instance()

    def store_scan_result(
        self,
        scan_result: Dict[str, Any],
        overwrite: bool = False,
    ) -> Optional[Source]:
        """Store a complete scan result to the database.

        This method handles the full workflow:
        1. Create or update source record
        2. Store all file records in batch

        Args:
            scan_result: Scan result dictionary from Scanner

        Returns:
            Created/updated Source instance
        """
        source_name = scan_result.get("source_name")
        source_dir = scan_result.get("source_dir")
        source_mask = scan_result.get("source_mask", "*")
        source_kind = scan_result.get("source_kind", "LOCAL")
        status = scan_result.get("status", "OK")
        files = scan_result.get("files", [])
        errors = scan_result.get("errors", [])
        start_extraction = scan_result.get("start_extraction")

        try:
            # Check if source already exists
            source = self.source_repo.get_by_name(source_name)

            if source:
                if not overwrite:
                    raise ValueError(
                        f"Source '{source_name}' already exists. "
                        "Operation would partially overwrite data. "
                        "Use --overwrite to replace all source data."
                    )
                # Delete existing files and update
                self.file_repo.delete_by_source(source.id)
                if start_extraction and isinstance(start_extraction, str):
                    start_extraction = datetime.fromisoformat(start_extraction)
                self.source_repo.update(
                    source.id,
                    source_name=source_name,
                    source_dir=source_dir,
                    source_mask=source_mask,
                    source_kind=source_kind,
                    start_extraction=start_extraction or datetime.now(),
                    status="PENDING",
                    files_total=0,
                )
                self.logger.info(f"Updating existing source: {source_name}")
            else:
                # Create new source
                source = self.source_repo.create(
                    source_name=source_name,
                    source_dir=source_dir,
                    source_mask=source_mask,
                    source_kind=source_kind,
                )
                self.logger.info(f"Created new source: {source_name}")

            # Prepare file data
            files_data = []
            for file_info in files:
                files_data.append({
                    "file_path": file_info.get("file_path", ""),
                    "status": file_info.get("status", "OK"),
                    "status_message": file_info.get("status_message"),
                    "inference": file_info.get("inference"),
                    "details": file_info.get("details", {}),
                })

            # Add error files
            for error in errors:
                files_data.append({
                    "file_path": error.get("file", ""),
                    "status": "ERROR",
                    "status_message": error.get("message", "Unknown error"),
                    "details": {},
                })

            # Batch insert files
            if files_data:
                self.file_repo.create_batch(source.id, files_data)

            # Update source with final status
            end_extraction = scan_result.get("end_extraction")
            if end_extraction and isinstance(end_extraction, str):
                end_extraction = datetime.fromisoformat(end_extraction)

            updated_source = self.source_repo.update(
                source.id,
                source_name=source_name,
                source_dir=source_dir,
                source_mask=source_mask,
                source_kind=source_kind,
                end_extraction=end_extraction or datetime.now(),
                status=status,
                files_total=len(files_data),
            )

            self.logger.info(
                f"Stored scan result for {source_name}: {len(files_data)} files"
            )
            return updated_source or source

        except Exception as e:
            self.logger.error(f"Failed to store scan result: {e}")
            raise

    def get_scan_summary(self) -> Dict[str, Any]:
        """Get summary of all scans.

        Returns:
            Dictionary with scan statistics
        """
        with self.db_manager.get_session() as session:
            total_sources = session.query(Source).count()
            total_files = session.query(SourceFile).count()

            # Get status breakdown
            source_status = (
                session.query(Source.status, func.count(Source.id))
                .group_by(Source.status)
                .all()
            )

            # Get file status breakdown
            file_status = (
                session.query(SourceFile.status, func.count(SourceFile.id))
                .group_by(SourceFile.status)
                .all()
            )

            return {
                "total_sources": total_sources,
                "total_files": total_files,
                "sources_by_status": dict(source_status),
                "files_by_status": dict(file_status),
            }


__all__ = [
    "SourceRepository",
    "SourceFileRepository",
    "ScanRepository",
    "get_database_statistics",
]


def get_database_statistics(db_manager: DatabaseManager) -> Dict[str, Any]:
    """Get database statistics.

    Args:
        db_manager: Database manager instance

    Returns:
        Dictionary with database statistics
    """
    scan_repo = ScanRepository(db_manager)
    return scan_repo.get_scan_summary()
