"""Database operations for MyLibraryScanner using FBNet standard configuration.

This package handles database connections, models, and operations
for PostgreSQL databases supporting the MyLibraryScanner schema.

Modules:
    models: SQLAlchemy models for sources and source_files tables
    connection: Database connection management and session handling
    operations: High-level database operations and repository patterns
    migrations: Database migration support for schema evolution
"""

from .models import Base, Source, SourceFile
from .connection import DatabaseManager
from .operations import SourceRepository, SourceFileRepository, ScanRepository

__all__ = [
    # Models
    "Base",
    "Source",
    "SourceFile",

    # Connection management
    "DatabaseManager",

    # Operations
    "SourceRepository",
    "SourceFileRepository",
    "ScanRepository",
]
