"""MyLibraryScanner initialization using FBNet standard configuration and logging."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from fbpyutils import Env, Logger, get_env, get_logger, setup as fb_setup


_env: Optional[Env] = None
_logger: Optional[Logger] = None
_config: Optional[Dict[str, Any]] = None


def _default_config_path() -> Path:
    """Return project source-of-truth configuration path."""
    return Path(__file__).resolve().parent / "app.json"


def load_app_config(config_file: Optional[str] = None) -> Dict[str, Any]:
    """Load application configuration from JSON file."""
    config_path = Path(config_file) if config_file else _default_config_path()
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _default_dotenv_paths() -> list[Path]:
    """Return dotenv file locations to probe."""
    project_root = Path(__file__).resolve().parent.parent
    cwd_root = Path.cwd()
    candidates = [cwd_root / ".env", project_root / ".env"]

    unique: list[Path] = []
    for candidate in candidates:
        if candidate not in unique:
            unique.append(candidate)
    return unique


def _parse_dotenv_line(line: str) -> tuple[Optional[str], Optional[str]]:
    """Parse a KEY=VALUE dotenv line."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None, None

    if stripped.startswith("export "):
        stripped = stripped[len("export ") :].strip()

    if "=" not in stripped:
        return None, None

    key, value = stripped.split("=", 1)
    key = key.strip()
    value = value.strip()

    if value and len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        value = value[1:-1]

    if not key:
        return None, None

    return key, value


def _load_dotenv_file(path: Path, overwrite: bool = False) -> None:
    """Load environment variables from a dotenv file if it exists."""
    if not path.exists() or not path.is_file():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        key, value = _parse_dotenv_line(raw_line)
        if key is None:
            continue
        if overwrite or key not in os.environ:
            os.environ[key] = value if value is not None else ""


def _load_dotenv_defaults() -> None:
    """Load default dotenv files without overriding already exported vars."""
    for path in _default_dotenv_paths():
        _load_dotenv_file(path, overwrite=False)


def _coerce_env_value(raw_value: str, default_value: Any) -> Any:
    """Coerce environment value to the same type as default config value."""
    if default_value is None:
        return raw_value
    if isinstance(default_value, bool):
        return raw_value.strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(default_value, int):
        return int(raw_value)
    if isinstance(default_value, float):
        return float(raw_value)
    return raw_value


def _apply_env_overrides(config: Dict[str, Any]) -> Dict[str, Any]:
    app_code = config.get("app", {}).get("appcode", "MYLIBRARYSCANNER")
    env_prefix = f"FBNET_{app_code}_"
    cfg = config.setdefault("config", {})

    # Map all known config keys from app.json by naming convention.
    for config_key, default_value in list(cfg.items()):
        env_var = f"{env_prefix}{config_key.upper()}"
        env_value = os.getenv(env_var)
        if env_value is not None:
            cfg[config_key] = _coerce_env_value(env_value, default_value)

    # Compatibility aliases from historical naming.
    aliases = {
        "system_db_url": "SYSTEM_DB_URL",
        "system_db_schema": "DB_SCHEMA",
        "llm_embedding_vectordb_url": f"{env_prefix}LLM_VECTORDB_URL",
        "llm_embedding_vectordb_collection": f"{env_prefix}LLM_VECTORDB_COLLECTION",
    }
    for config_key, env_var in aliases.items():
        env_value = os.getenv(env_var)
        if env_value is not None and config_key in cfg:
            cfg[config_key] = _coerce_env_value(env_value, cfg[config_key])

    # Fallback: embedding base URL uses chat base URL if not set.
    if not cfg.get("llm_embedding_base_url") and cfg.get("llm_chat_base_url"):
        cfg["llm_embedding_base_url"] = cfg["llm_chat_base_url"]

    # Fallback: vision base URL uses chat base URL if not set.
    if not cfg.get("llm_vision_base_url") and cfg.get("llm_chat_base_url"):
        cfg["llm_vision_base_url"] = cfg["llm_chat_base_url"]

    # Fallback: vision model uses chat model if not set.
    if not cfg.get("llm_vision_model") and cfg.get("llm_chat_model"):
        cfg["llm_vision_model"] = cfg["llm_chat_model"]

    return config


def setup_system(config_file: Optional[str] = None) -> None:
    """Setup MyLibraryScanner system with FBNet standard configuration."""
    global _env, _logger, _config
    try:
        _load_dotenv_defaults()
        config = load_app_config(config_file)
        config = _apply_env_overrides(config)
        fb_setup(config)

        _env = get_env()
        _logger = get_logger()
        _config = config

        _logger.info("MyLibraryScanner system initialized successfully")
        _logger.info(f"App Code: {config.get('app', {}).get('appcode', 'MYLIBRARYSCANNER')}")
        _logger.info(f"Database Schema: {config.get('config', {}).get('system_db_schema')}")
    except Exception as e:
        print(f"CRITICAL: Failed to setup MyLibraryScanner: {e}")
        raise RuntimeError(f"System setup failed: {e}") from e


def load_dotenv_defaults() -> None:
    """Load default .env files without overriding exported environment variables."""
    _load_dotenv_defaults()


def get_env_instance() -> Env:
    if _env is None:
        raise RuntimeError("System not initialized. Call setup_system() first.")
    return _env


def get_logger_instance() -> Logger:
    if _logger is None:
        raise RuntimeError("System not initialized. Call setup_system() first.")
    return _logger


def get_app_config() -> Dict[str, Any]:
    if _config is None:
        raise RuntimeError("System not initialized. Call setup_system() first.")
    return _config
