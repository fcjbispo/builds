"""MyLibraryScanner CLI entry point.

This module provides the command-line interface for MyLibraryScanner.
It can be executed directly or via `python -m mylibraryscanner`.
"""

import sys
from .cli import interface

def main():
    """Main entry point for the CLI."""
    return interface.main()

if __name__ == "__main__":
    sys.exit(main())