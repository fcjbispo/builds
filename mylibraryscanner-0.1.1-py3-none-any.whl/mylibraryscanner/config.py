"""Configuration management for MyLibraryScanner.

This module handles application configuration including database settings,
scanning parameters, and runtime configuration.
"""

import os
import json
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class DatabaseConfig:
    """Database configuration settings."""

    url: str = "postgresql://postgres:postgres@localhost:5432/mylibraryscanner"
    schema: str = "library"
    pool_size: int = 10
    max_overflow: int = 20
    echo: bool = False
    ssl_mode: str = "prefer"


@dataclass
class ScanningConfig:
    """Scanning operation configuration."""

    parallel_processing: bool = False
    chunk_size: int = 1000
    timeout_seconds: int = 300
    exclude_patterns: List[str] = None
    include_patterns: List[str] = None
    follow_symlinks: bool = False
    max_depth: int = 0  # 0 means unlimited

    def __post_init__(self):
        if self.exclude_patterns is None:
            self.exclude_patterns = [
                "*.tmp",
                "*.temp",
                "__pycache__",
                ".git",
                ".svn",
                "node_modules",
                ".DS_Store",
                "Thumbs.db",
            ]
        if self.include_patterns is None:
            self.include_patterns = ["*"]


@dataclass
class LoggingConfig:
    """Logging configuration settings."""

    level: str = "INFO"
    format: str = "%(asctime)s:%(name)s:%(levelname)s:%(message)s"
    file_path: str = "logs/mylibraryscanner.log"
    max_bytes: int = 10485760  # 10MB
    backup_count: int = 5
    console_output: bool = True


@dataclass
class AppConfig:
    """Main application configuration."""

    name: str = "MyLibraryScanner"
    version: str = "0.1.0"
    debug: bool = False

    database: DatabaseConfig = None
    scanning: ScanningConfig = None
    logging: LoggingConfig = None

    def __post_init__(self):
        if self.database is None:
            self.database = DatabaseConfig()
        if self.scanning is None:
            self.scanning = ScanningConfig()
        if self.logging is None:
            self.logging = LoggingConfig()


class ConfigurationManager:
    """Manager for application configuration with loading and saving capabilities."""

    DEFAULT_CONFIG_FILE = "config/mylibraryscanner.yaml"
    ENV_VAR_PREFIX = "MYLIBRARYSCANNER_"

    def __init__(self, config_file: Optional[str] = None):
        """Initialize configuration manager.

        Args:
            config_file: Path to configuration file (optional)
        """
        self.config_file = config_file or self._get_config_file_from_env()
        self.config = AppConfig()
        self._loaded_from_file = False

        # Try to load from file
        if self.config_file and Path(self.config_file).exists():
            self.load_from_file(self.config_file)
            self._loaded_from_file = True

        # Apply environment variable overrides
        self._apply_env_overrides()

    def _get_config_file_from_env(self) -> str:
        """Get configuration file path from environment variable."""
        return os.getenv(f"{self.ENV_VAR_PREFIX}CONFIG_FILE", self.DEFAULT_CONFIG_FILE)

    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides to configuration."""
        # Database settings
        db_url = os.getenv(f"{self.ENV_VAR_PREFIX}DB_URL")
        if db_url:
            self.config.database.url = db_url

        db_schema = os.getenv(f"{self.ENV_VAR_PREFIX}DB_SCHEMA")
        if db_schema:
            self.config.database.schema = db_schema

        db_echo = os.getenv(f"{self.ENV_VAR_PREFIX}DB_ECHO")
        if db_echo:
            self.config.database.echo = db_echo.lower() == "true"

        # Scanning settings
        parallel_processing = os.getenv(f"{self.ENV_VAR_PREFIX}PARALLEL_PROCESSING")
        if parallel_processing:
            self.config.scanning.parallel_processing = (
                parallel_processing.lower() == "true"
            )

        # Logging settings
        log_level = os.getenv(f"{self.ENV_VAR_PREFIX}LOG_LEVEL")
        if log_level:
            self.config.logging.level = log_level

        debug = os.getenv(f"{self.ENV_VAR_PREFIX}DEBUG")
        if debug:
            self.config.debug = debug.lower() == "true"

    def load_from_file(self, config_file: str) -> None:
        """Load configuration from file.

        Args:
            config_file: Path to configuration file (YAML or JSON)
        """
        config_path = Path(config_file)

        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_file}")

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                if config_path.suffix.lower() in [".yaml", ".yml"]:
                    data = yaml.safe_load(f)
                elif config_path.suffix.lower() == ".json":
                    data = json.load(f)
                else:
                    raise ValueError(
                        f"Unsupported configuration file format: {config_path.suffix}"
                    )

            self._update_from_dict(data)
            print(f"✓ Loaded configuration from {config_file}")

        except Exception as e:
            raise RuntimeError(f"Failed to load configuration from {config_file}: {e}")

    def save_to_file(self, config_file: Optional[str] = None) -> None:
        """Save configuration to file.

        Args:
            config_file: Target configuration file path (optional, uses current)
        """
        target_file = config_file or self.config_file
        if not target_file:
            raise ValueError("No configuration file specified")

        target_path = Path(target_file)
        target_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            data = self.to_dict()

            with open(target_path, "w", encoding="utf-8") as f:
                if target_path.suffix.lower() in [".yaml", ".yml"]:
                    yaml.dump(
                        data, f, default_flow_style=False, sort_keys=False, indent=2
                    )
                elif target_path.suffix.lower() == ".json":
                    json.dump(data, f, indent=2, sort_keys=False)
                else:
                    # Default to YAML
                    yaml.dump(
                        data, f, default_flow_style=False, sort_keys=False, indent=2
                    )

            print(f"✓ Saved configuration to {target_file}")

        except Exception as e:
            raise RuntimeError(f"Failed to save configuration to {target_file}: {e}")

    def _update_from_dict(self, data: Dict[str, Any]) -> None:
        """Update configuration from dictionary.

        Args:
            data: Configuration data dictionary
        """
        # Update database config
        if "database" in data:
            db_data = data["database"]
            for key, value in db_data.items():
                if hasattr(self.config.database, key):
                    setattr(self.config.database, key, value)

        # Update scanning config
        if "scanning" in data:
            scan_data = data["scanning"]
            for key, value in scan_data.items():
                if hasattr(self.config.scanning, key):
                    setattr(self.config.scanning, key, value)

        # Update logging config
        if "logging" in data:
            log_data = data["logging"]
            for key, value in log_data.items():
                if hasattr(self.config.logging, key):
                    setattr(self.config.logging, key, value)

        # Update main config
        if "name" in data:
            self.config.name = data["name"]
        if "version" in data:
            self.config.version = data["version"]
        if "debug" in data:
            self.config.debug = data["debug"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Configuration as dictionary
        """
        return asdict(self.config)

    def generate_default_config(self, config_file: str) -> None:
        """Generate a default configuration file.

        Args:
            config_file: Path to save default configuration
        """
        self.save_to_file(config_file)
        print(f"Generated default configuration at {config_file}")

    def validate(self) -> List[str]:
        """Validate configuration and return any issues.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        # Validate database URL
        if not self.config.database.url:
            errors.append("Database URL is required")

        # Validate scan patterns
        if not self.config.scanning.include_patterns:
            errors.append("Include patterns cannot be empty")

        # Validate logging level
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if self.config.logging.level not in valid_levels:
            errors.append(f"Invalid logging level: {self.config.logging.level}")

        return errors

    @property
    def is_loaded_from_file(self) -> bool:
        """Check if configuration was loaded from file."""
        return self._loaded_from_file

    def __str__(self) -> str:
        """String representation of configuration."""
        return f"ConfigurationManager(config_file='{self.config_file}', loaded_from_file={self.is_loaded_from_file})"


# Default configuration manager instance
default_config = ConfigurationManager()

__all__ = [
    "AppConfig",
    "DatabaseConfig",
    "ScanningConfig",
    "LoggingConfig",
    "ConfigurationManager",
    "default_config",
]
