'''
Brazil's Comissão de Valores Mobiliários
Provides current info for investment funds.
'''

from datetime import datetime

from infobr.api import services
from infobr.providers import cvm

def get_position(id: str, request_time: datetime=None):
    '''
        This function responds to a request for /api/cvm/investmentfund/{id}/position
        Return financial position info for a specific investment fund on CVM.

        id
            The investment fund id

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    request_time = request_time or datetime.utcnow()

    response = services.stamp_response(cvm.investment_fund_position(id), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500

def get_details(id: str, request_time: datetime=None):
    '''
        This function responds to a request for /api/cvm/investmentfund/{id}/details
        Return detailed info for a specific investment fund on CVM.

        id
            The investment fund id

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    request_time = request_time or datetime.utcnow()

    response = services.stamp_response(cvm.investment_fund_details(id), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500

def get_all(manager: str = None, request_time: datetime=None):
    '''
        This function responds to a request for /api/cvm/investmentfunds
        Return info for all available investment funds on CVM.

        manager
            The pattern used to search investment funds. Use pieces of the desired 
            fund manager name. Defaults to None

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    return get(None, manager, request_time)

def get_matcheds(name: str, manager: str = None, request_time: datetime=None):
    '''
        This function responds to a request for /api/cvm/investmentfunds/{fund}
        Return info for matched investment funds using given pattern.

        name
            The pattern used to search investment funds. Use pieces of the desired fund name

        manager
            The pattern used to search investment funds. Use pieces of the desired fund 
            manager name. Defaults to None

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    return get(name, manager, request_time)

def get(name: str = None, manager: str = None, request_time: datetime=None):
    request_time = request_time or datetime.utcnow()

    response = services.stamp_response(cvm.investment_funds(name, manager), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500
