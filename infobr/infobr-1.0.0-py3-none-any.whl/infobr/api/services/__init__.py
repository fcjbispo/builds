'''
Services Package
Provides all services available and its dependencies.
'''
from datetime import datetime
from typing import Dict

from infobr.model.security import AuthorizationKey

DEFAULT_MARKET = 'BVMF'

def stamp_response(
    x: Dict, request_time: datetime=None, response_time: datetime=None) -> Dict:
    '''
        Stamps the response object with the request and responses times.

        x
            The response object to fill in

        request_time
            The datetime object representing the request time

        response_time
            The datetime object representing the response time. Defaults to current timestamp

        Return the response object filled with request and response times
    '''
    if not isinstance(x, dict):
        raise ValueError('Invalid response object')

    x['request_time']= request_time or datetime.now()
    x['response_time']= response_time or datetime.now()

    return x

def authorize_api_key(apikey: str, required_scopes=None) -> Dict:
    '''
        Performs api key authorization
    '''
    authorization_key = AuthorizationKey.query.filter_by(api_key=apikey).all()

    authorized = len(authorization_key) > 0
    if authorized:
        return {'sub': authorization_key[0].api_key}

    # optional: raise exception for custom error response
    return None

