'''
Server Module
REST API server module.
'''
import os

from infobr import core

from flask import Flask, redirect, render_template

basedir = os.path.abspath(os.path.dirname(__file__))

app = core.connex_app

app.add_api(os.path.sep.join([basedir, 'specs', 'swagger.yml']), arguments={'title': 'InfoBR API'})

@app.route('/')
@app.route('/infobr')
def home():
    '''
    Respond for the urls: /, /infobr

        Return the rendered template 'home.html'
    '''

    return redirect('/infobr/v1/ui')

@app.route('/support')
@app.route('/infobr/support')
def support():
    '''
    Respond for the urls: /support, /infobr/support

        Return the rendered template 'unimplemented.html'
    '''

    return render_template('unimplemented.html')

@app.route('/terms')
@app.route('/infobr/terms')
def terms():
    '''
    Respond for the urls: /terms, /infobr/terms

        Return the rendered template 'unimplemented.html'
    '''

    return render_template('unimplemented.html')

# If we're running in stand alone mode, run the application
if __name__ == '__main__':
    _host = core.settings['host_listen_address']
    _port = core.settings['host_listen_port']
    if core.settings['environment'] == 'production':
        from waitress import serve

        serve(app, host=_host, port=_port)
    else:
        app.run(host=_host, port=_port, debug=core.settings['debug_info'])