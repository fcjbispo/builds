'''
Security Model Package
Provides all persistence models for security and authorizations.
'''
from infobr.core import db, ma

from datetime import datetime

from fbpyutils import string as sutl

class AuthorizationKey(db.Model):
    __tablename__ = 'AUTHORIZATION_KEY'
    __table_args__ = (db.UniqueConstraint('api_key'), )
    id = db.Column(
        db.String(32), primary_key=True, default=sutl.random_string)
    api_key = db.Column(
        db.String(36), nullable=False, default=sutl.uuid)
    is_privileged = db.Column(
        db.Boolean(), nullable=False, default=False)
    creation_date = db.Column(
        db.DateTime, nullable=False, default=datetime.utcnow)
    update_date = db.Column(
        db.DateTime, nullable=True, onupdate=datetime.utcnow)

    def __repr__(self) -> str:
        return f'API Key: {self.api_key}'

class AuthorizationKeySchema(ma.Schema):
    class Meta:
        model = AuthorizationKey
        sqla_session = db.session
