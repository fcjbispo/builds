'''
Services Package
Provides all services available and its dependencies.
'''
from datetime import date, datetime
from typing import Dict

from connexion.decorators.security import validate_scope
from connexion.exceptions import OAuthScopeProblem, AuthenticationProblem

from infobr.model.security import AuthorizationKey

from infobr.core import db

DEFAULT_MARKET = 'BVMF'

def stamp_response(
    x: Dict, request_time: datetime=None, response_time: datetime=None) -> Dict:
    '''
        Stamps the response object with the request and responses times.

        x
            The response object to fill in

        request_time
            The datetime object representing the request time

        response_time
            The datetime object representing the response time. Defaults to current timestamp

        Return the response object filled with request and response times
    '''
    if not isinstance(x, dict):
        raise ValueError('Invalid response object')

    x['request_time']= request_time or datetime.now()
    x['response_time']= response_time or datetime.now()

    return x

def authorize_api_key(apikey: str, required_scopes=None) -> Dict:
    '''
        Performs api key authorization
    '''
    try:
        authenticated = AuthorizationKey.query.filter_by(api_key=apikey).first()

        if authenticated:
            if authenticated.is_expired:
                return None

            if authenticated.is_privileged:
                info = {'sub': authenticated.api_key, 'scope': 'PRIVILEGED_ADMIN_ACCESS'}
            else:
                info = {'sub': authenticated.api_key, 'scope': ''}

            if required_scopes is not None and not validate_scope(required_scopes, info['scope']):
                raise OAuthScopeProblem(
                    description='Provided user doesn\'t have the required access rights.',
                    required_scopes=required_scopes,
                    token_scopes=info['scope']
                )

            authenticated.last_access = datetime.utcnow()
            db.session.commit()

            return info

        return None
    except Exception as e:
        raise Exception('Authorization failed: {}'.format(e))
