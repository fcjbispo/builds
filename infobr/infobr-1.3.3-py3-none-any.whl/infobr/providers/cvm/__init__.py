'''
CVM Package
Provides modules, functions and classes for CVM (Comissão de Valores Imobiliários) provider.
'''
from typing import Dict

from infobr import core
from infobr.model.cvm import IFDailyPosition

from sqlalchemy import and_

_format_search = lambda x: '%' if x is None else '%{}%'.format('%'.join(x.split())).upper()


def investment_fund_position(x: str) -> Dict:
    '''
    List the last available position for a CVM investment fund.

        x
            The investment fund id.

        Return the last available position for a CVM investment fund
    '''
    result = {
        'info': 'INVESTMENT FUND POSITION',
        'source': 'CVM',
        'status': 'SUCCESS',
        'details': {}
    }
    try:
        if not x:
            raise ValueError("Fund ID required.")

        df = IFDailyPosition.query.filter(IFDailyPosition.fund_id == x).all()

        if len(df) == 0:
            result['status'] = 'NOT FOUND'
            result['details'] = {
                'id': x
            }
            return result

        if_list = [
            {
                'net_worth': f.net_worth_value,
                'total_value': f.total_value,
                'quota_value': f.quota_value,
                'daily_capture_value': f.daily_capture_value,
                'daily_redemption_value': f.daily_redemption_value,
                'shareholders': f.shareholders,
                'net_worth_date': f.net_worth_date,
                'position_date': f.position_date,
            } 
            for f in df
        ]

        result['details'] = {
            'id': x,
            'matches': len(if_list),
            'funds': if_list,
            'update_date': max([f.creation_date for f in df]),
        }
    except Exception as e:
        m =  core.debug_info(e)
        result['status'] = 'ERROR'
        result['details'] = {
            'error_message': m
        }

    return result

def investment_fund_details(x: str) -> Dict:
    '''
    List the details for a CVM investment fund.

        x
            The investment fund id.

        Return the details for the investment fund given
    '''
    result = {
        'info': 'INVESTMENT FUND DETAILS',
        'source': 'CVM',
        'status': 'SUCCESS',
        'details': {}
    }
    try:
        if not x:
            raise ValueError("Fund ID required.")

        df = IFDailyPosition.query.filter(IFDailyPosition.fund_id == x).all()

        if len(df) == 0:
            result['status'] = 'NOT FOUND'
            result['details'] = {
                'id': x
            }
            return result

        if_list = [
            {
                'type': f.fund_type,
                'name': f.fund_name,
                'register_date': f.register_date,
                'constitution_date': f.constitution_date,
                'cvm_code': f.cvm_code,
                'cancel_date': f.cancel_date,
                'situation_code': f.situation_code,
                'situation_start_date': f.situation_start_date,
                'situation_end_date': f.situation_end_date,
                'excercise_start_date': f.excercise_start_date,
                'excercise_end_date': f.excercise_end_date,
                'class': f.fund_class,
                'class_start_date': f.class_start_date,
                'profitability_type': f.profitability_type,
                'tenancy_type': f.tenancy_type,
                'is_quote_fund': f.is_quote_fund,
                'is_exclusive_fund': f.is_exclusive_fund,
                'is_long_term_tax': f.is_long_term_tax,
                'is_qualified_investment': f.is_qualified_investment,
                'is_investment_entity': f.is_investment_entity,
                'perf_rate': f.perf_rate,
                'perf_rate_info': f.perf_rate_info,
                'admin_rate': f.admin_rate,
                'admin_rate_info': f.admin_rate_info,
                'director_name': f.director_name,
                'admin_id': f.admin_id,
                'admin_name': f.admin_name,
                'manager_type': f.manager_type,
                'manager_id': f.manager_id,
                'manager_name': f.manager_name,
                'controller_id': f.controller_id,
                'controller_name': f.controller_name,
                'custodian_id': f.custodian_id,
                'custodian_name': f.custodian_name,
                'supervisor_id': f.supervisor_id,
                'supervisor_name': f.supervisor_name,
                'position_date': f.position_date,
            } 
            for f in df
        ]

        result['details'] = {
            'id': x,
            'matches': len(if_list),
            'funds': if_list,
            'update_date': max([f.creation_date for f in df]),
        }
    except Exception as e:
        m =  core.debug_info(e)
        result['status'] = 'ERROR'
        result['details'] = {
            'error_message': m
        }

    return result

def investment_funds(x: str = None, y: str = None) -> Dict:
    '''
    List current active investment funds from CVM (Comissão de Valores Mobiliários.

        x
            The name of the investment fund as search pattern. May be used words from the fund name. Defaults to None.

        y
            The name of the investment fund manager as search pattern. May be used words from the manager name. Defaults to None.

        Return all current investment funds from CVM matched with the supplied patters or all if none was given.
    '''
    result = {
        'info': 'INVESTMENT FUNDS',
        'source': 'CVM',
        'status': 'SUCCESS',
        'details': {}
    }

    try:
        df = IFDailyPosition.query.filter(
            and_(
                IFDailyPosition.fund_name.like(_format_search(_format_search(x))),
                IFDailyPosition.manager_name.like(_format_search(_format_search(y))))
        ).all()

        if len(df) == 0:
            result['status'] = 'NOT FOUND'
            result['details'] = {
                'name': x or 'ALL',
                'manager': y or 'ALL'
            }
            return result

        if_list = [
            {
                'id': f.fund_id, 
                'type': f.fund_type, 
                'name': f.fund_name,
                'manager': f.manager_name
            } 
            for f in df
        ]

        result['details'] = {
            'name': x or 'ALL',
            'manager': y or 'ALL',
            'matches': len(if_list),
            'funds': if_list,
            'update_date': max([f.creation_date for f in df]),
        }
    except Exception as e:
        m =  core.debug_info(e)
        result['status'] = 'ERROR'
        result['details'] = {
            'error_message': m
        }

    return result

def investment_fund_managers(x: str =None) -> Dict:
    '''
    List investment funds managers.

        x
            The name of the investment fund manager as search pattern. May be used words from the manager name. Defaults to None.

        Return all current investment fund managers from CVM matched with the supplied patters or all if none was given.
    '''
    result = {
        'info': 'INVESTMENT FUND MANAGERS',
        'source': 'CVM',
        'status': 'SUCCESS',
        'details': {}
    }

    try:
        df = IFDailyPosition.query.filter(
            IFDailyPosition.manager_name.like(_format_search(x))
        ).with_entities(
            IFDailyPosition.manager_id, IFDailyPosition.manager_name, IFDailyPosition.manager_type,
        ).distinct().all()

        if len(df) == 0:
            result['status'] = 'NOT FOUND'
            result['details'] = {
                'manager': x or 'ALL'
            }
            return result

        if_list = [
            {
                'id': f.manager_id,
                'name': f.manager_name,
                'type': f.manager_type
            } for f in df
        ]

        result['details'] = {
            'manager': x or 'ALL',
            'matches': len(if_list),
            'managers': if_list,
        }
    except Exception as e:
        m =  core.debug_info(e)
        result['status'] = 'ERROR'
        result['details'] = {
            'error_message': m
        }

    return result

