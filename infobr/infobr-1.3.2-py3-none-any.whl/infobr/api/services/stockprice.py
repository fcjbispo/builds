'''
Stock Price Service
Provides current price for a stock.
'''
from infobr.api import services

from datetime import datetime
from infobr.providers import google

def get(ticker: str, market: str=services.DEFAULT_MARKET, request_time: datetime=None):
    '''
        This function responds to a request for /api/stockprice/TICKER
        Return the current stock price from Google Finance.

        ticker
            The stock ticker code

        market
            The market code. Defaults to BVMF

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    request_time = request_time or datetime.now()

    market = market or services.DEFAULT_MARKET

    response = services.stamp_response(google.stock_price(ticker, market=market), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500
