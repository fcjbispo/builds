'''
Brazilian Treasury Bonds Service
Provides current info for treasury bonds.
'''
from infobr.api import services

from datetime import datetime
from infobr.providers import tesourodireto

def get(bond_name: str = None, request_time: datetime=None):
    '''
        This function responds to a request for /api/treasurybonds
        Return info for specific treasury bond or all listed and current market.

        bond
            The bond name. Defaults to None

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    request_time = request_time or datetime.now()

    response = services.stamp_response(tesourodireto.treasury_bonds(bond_name), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500
