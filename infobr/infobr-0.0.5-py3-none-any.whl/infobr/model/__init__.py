'''
Model Package
Provides all persistence models, helper functions and classes for entire system.
'''
from sqlalchemy_utils import force_instant_defaults

force_instant_defaults()