'''
Utility for update CVM investment funds.
'''
import sys

import pandas as pd
from pandas.core.frame import DataFrame

from pandasql import PandaSQL
from datetime import datetime
from dateutil.relativedelta import relativedelta

from urllib import request

import sqlalchemy as sql
from sqlalchemy import create_engine

from infobr import core
from infobr.core import db
from infobr.utils import string as sutl
from infobr.model.cvm import IFDailyPosition

pysqldf = PandaSQL()

def _apply_converters(data, converters):
  return [{k: converters[k](v) for k, v in r.items()} for r in data]

def _read_csv_from_url(url, encoding='iso-8859-1', delimiter=',', eol='\n', skip=0, ignore_header_line=False, headers=[], converters=None) -> list:
  response = request.urlopen(url)
  response_data =  response.read().decode('iso-8859-1')

  rows = response_data.split(eol)

  if len(rows) == 0:
    return []

  if len(rows) <= skip:
    raise Exception('Skip too much')

  rows = rows[skip: -1]

  if len(headers) > 0:
    if len(headers) != len(rows[0].split(delimiter)):
      raise Exception('Header length mismatch')
    header = headers
  else:
    header = list(range(0, len(headers))) if ignore_header_line else rows[0].split(delimiter)

  data = rows[1: -1] if ignore_header_line else rows[0: -1]

  csv_data = [{header[i]: row[i] for i in range(0,len(header))} for row in [d.split(delimiter) for d in data]]

  if converters and type(converters) == dict:
    csv_data = _apply_converters(csv_data, converters)
  return csv_data

def _is_nan_or_empty(x):
  return x != x or x is None or not x
  
def _as_boolean(x):
  if _is_nan_or_empty(x):
    return None
  else:
    return x in ('S','Y','1')

def _as_date(x):
  if _is_nan_or_empty(x):
    return None
  else:
    return datetime.strptime(x, '%Y-%m-%d').date()

def _as_float(x):
  o = x
  if _is_nan_or_empty(x):
    return None
  else:
    try:
      x = float(x)
      return x
    except ValueError:
      return None

def _as_integer(x):
  if _is_nan_or_empty(x):
    return None
  else:
    try:
      x = int(float(x))
      return x
    except ValueError:
      return None

def _as_string(x):
  if _is_nan_or_empty(x):
    return None
  else:
    return str(x)

_register_headers = [
    'fund_type',
    'fund_id',
    'fund_name',
    'register_date',
    'constitution_date',
    'cvm_code',
    'cancel_date',
    'situation_code',
    'situation_start_date',
    'situation_end_date',
    'excercise_start_date',
    'excercise_end_date',
    'fund_class',
    'class_start_date',
    'profitability_type',
    'tenancy_type',
    'is_quote_fund',
    'is_exclusive_fund',
    'is_long_term_tax',
    'is_qualified_investment',
    'is_investment_entity',
    'perf_rate',
    'perf_rate_info',
    'admin_rate',
    'admin_rate_info',
    'net_worth',
    'net_worth_date',
    'director_name',
    'admin_id',
    'admin_name',
    'manager_type',
    'manager_id',
    'manager_name',
    'controller_id',
    'controller_name',
    'custodian_id',
    'custodian_name',
    'supervisor_id',
    'supervisor_name',                
]

_position_headers = [
    'fund_type',
    'fund_id',
    'position_date',
    'total_value',
    'quota_value',
    'net_worth_value',
    'daily_capture_value',
    'daily_redemption_value',
    'shareholders',        
]

_converters = {
    'fund_type': lambda x: _as_string(x),
    'fund_id': lambda x: _as_string(x),
    'fund_name': lambda x: _as_string(x),
    'register_date': lambda x: _as_date(x),
    'constitution_date': lambda x: _as_date(x),
    'cvm_code': lambda x: _as_string(x),
    'cancel_date': lambda x: _as_date(x),
    'situation_code': lambda x: _as_string(x),
    'situation_start_date': lambda x: _as_date(x),
    'situation_end_date': lambda x: _as_date(x),
    'excercise_start_date': lambda x: _as_date(x),
    'excercise_end_date': lambda x: _as_date(x),
    'fund_class': lambda x: _as_string(x),
    'class_start_date': lambda x: _as_date(x),
    'profitability_type': lambda x: _as_string(x),
    'tenancy_type': lambda x: _as_string(x),
    'is_quote_fund': lambda x: _as_boolean(x),
    'is_exclusive_fund': lambda x: _as_boolean(x),
    'is_long_term_tax': lambda x: _as_boolean(x),
    'is_qualified_investment': lambda x: _as_boolean(x),
    'is_investment_entity': lambda x: _as_boolean(x),
    'perf_rate': lambda x: _as_float(x),
    'perf_rate_info': lambda x: _as_string(x),
    'admin_rate': lambda x: _as_float(x),
    'admin_rate_info': lambda x: _as_string(x),
    'net_worth': lambda x: _as_float(x),
    'net_worth_date': lambda x: _as_date(x),
    'director_name': lambda x: _as_string(x),
    'admin_id': lambda x: _as_string(x),
    'admin_name': lambda x: _as_string(x),
    'manager_type': lambda x: _as_string(x),
    'manager_id': lambda x: _as_string(x),
    'manager_name': lambda x: _as_string(x),
    'controller_id': lambda x: _as_string(x),
    'controller_name': lambda x: _as_string(x),
    'custodian_id': lambda x: _as_string(x),
    'custodian_name': lambda x: _as_string(x),
    'supervisor_id': lambda x: _as_string(x),
    'supervisor_name': lambda x: _as_string(x),
    'total_value': lambda x: _as_float(x),
    'quota_value': lambda x: _as_float(x),
    'net_worth_value': lambda x: _as_float(x),
    'daily_capture_value': lambda x: _as_float(x),
    'daily_redemption_value': lambda x: _as_float(x),
    'shareholders': lambda x: _as_integer(x),
    'position_date': lambda x: _as_date(x),
}

def get_cvm_if_data() -> DataFrame:
    _url_fi_daily_position = "http://dados.cvm.gov.br/dados/FI/DOC/INF_DIARIO/DADOS/inf_diario_fi_%T%.csv"
    _url_fi_register = "http://dados.cvm.gov.br/dados/FI/CAD/DADOS/cad_fi.csv"

    now = datetime.now()
    month_unit = relativedelta(months=1)

    cvm_if_register = None

    try:
        cvm_if_register = pd.DataFrame.from_dict(
            _read_csv_from_url(
                _url_fi_register, delimiter=';', eol='\r\n', 
                ignore_header_line=True, headers=_register_headers, converters=_converters))
    except Exception as e:
        pass

    cvm_if_daily = None
    tries = 3

    while tries > 0:
        try:
            cvm_if_daily = pd.DataFrame.from_dict(
                _read_csv_from_url(
                    _url_fi_daily_position.replace('%T%', now.strftime('%Y%m')), delimiter=';', 
                    eol='\r\n', ignore_header_line=True, headers=_position_headers, 
                    converters=_converters))

            if len(cvm_if_daily) < len(cvm_if_register):
                raise Exception('Daily position to small..')

            break
        except Exception as e:
            core.debug_print('{}.. Trying past month...'.format(e))
            tries -= 1
            now = (now - month_unit)

    if cvm_if_register is None or cvm_if_daily is None:
        raise Exception('Fail to download CVM daily data')

    step = None
    try:
        step = 'CREATING SQLITE ENGINE'
        engine = create_engine('sqlite:///memory', echo=False)
        conn = engine.connect()

        step = 'REGISTERING TABLES'
        cvm_if_register.to_sql('cvm_if_register', conn, if_exists='replace')
        cvm_if_daily.to_sql('cvm_if_daily', conn, if_exists='replace')

        step = 'CREATING INDEXES'
        r = engine.execute("CREATE INDEX cvm_if_daily_i001 ON cvm_if_daily (fund_type, fund_id)")
        r = engine.execute("CREATE INDEX cvm_if_register_i001 ON cvm_if_register (fund_type, fund_id)")
        r = engine.execute("CREATE INDEX cvm_if_register_i002 ON cvm_if_register (excercise_start_date, excercise_end_date, situation_code)")

        step = 'CONSOLIDATING DATA'
        cvm_daily_position = pd.read_sql("""
            WITH Q AS (
                SELECT fund_type, fund_id, MAX(position_date) position_date
                FROM cvm_if_daily
                GROUP BY fund_type, fund_id
                ORDER BY fund_type, fund_id
            ), G AS (
                select fund_type, fund_id, min(manager_id) as manager_id
                from cvm_if_register
                group by fund_type, fund_id
                ORDER BY fund_type, fund_id
            )
            SELECT A.fund_type,
                    A.fund_id,
                    A.fund_name,
                    A.register_date,
                    A.constitution_date,
                    A.cvm_code,
                    A.cancel_date,
                    A.situation_code,
                    A.situation_start_date,
                    A.situation_end_date,
                    A.excercise_start_date,
                    A.excercise_end_date,
                    A.fund_class,
                    A.class_start_date,
                    A.profitability_type,
                    A.tenancy_type,
                    A.is_quote_fund,
                    A.is_exclusive_fund,
                    A.is_long_term_tax,
                    A.is_qualified_investment,
                    A.is_investment_entity,
                    A.perf_rate,
                    A.perf_rate_info,
                    A.admin_rate,
                    A.admin_rate_info,
                    A.net_worth,
                    A.net_worth_date,
                    A.director_name,
                    A.admin_id,
                    A.admin_name,
                    A.manager_type,
                    A.manager_id,
                    A.manager_name,
                    A.controller_id,
                    A.controller_name,
                    A.custodian_id,
                    A.custodian_name,
                    A.supervisor_id,
                    A.supervisor_name,
                    B.total_value,
                    B.quota_value,
                    B.net_worth_value,
                    B.daily_capture_value,
                    B.daily_redemption_value,
                    B.shareholders,
                    B.position_date
                FROM cvm_if_register A
                JOIN cvm_if_daily B
                ON (A.fund_type = B.fund_type AND
                    A.fund_id = B.fund_id)
                JOIN Q
                ON (B.fund_type = Q.fund_type AND
                    B.fund_id = Q.fund_id AND
                    B.position_date = Q.position_date)
                JOIN G
                ON (G.fund_type = A.fund_type AND
                    G.fund_id = A.fund_id AND
                    G.manager_id = A.manager_id)
            WHERE B.position_date between A.excercise_start_date and A.excercise_end_date
                AND A.situation_code <> 'CANCELADA'
            ORDER BY A.fund_type, A.fund_id, B.position_date
            """, engine)

        step = 'DISPOSING SQLITE ENGINE'
        conn.close()
        engine.dispose()

        return cvm_daily_position
    except Exception as e:
        raise Exception('Fail to consolidade CVM IF Data on step {}: {}'.format(step, e))

def update_cvm_if_data(data: DataFrame, commit_at=2500) -> None:
    p = None
    rows = 0
    uncommited = 0
    step = None
    position_key = sutl.random_string(6)
    try:
        records = _apply_converters(data.to_dict('records'), _converters)
        for p in records:
            p['position_key'] = position_key

            step = 'INSERT DATA'
            x = IFDailyPosition(**p)
            db.session.add(x)
            rows += 1
            uncommited += 1
            
            step = 'INTERMEDIATE COMMIT: DATA'
            if uncommited >= commit_at:
                r = db.session.commit()
                uncommited = 0

        step = 'FINAL COMMIT: DATA'
        r = db.session.commit()

        step = 'REMOVE OLD DATA'
        stmt = sql.delete(IFDailyPosition).where(IFDailyPosition.position_key != position_key)
        db.session.execute(stmt)
        step = 'FINAL COMMIT: OLD DATA REMOVAL'
        db.session.commit()

        return rows
    except Exception as e:
        db.session.rollback()
        raise(Exception('Failed update on step {} at line {} with error {}; Data: {}.'.format(step, rows, e, p)))

# run the CVM data update
if __name__ == '__main__':
    try:
        data = get_cvm_if_data()
        affected_rows = update_cvm_if_data(data)
        print('Update of CVM IF Daily Position: {} rows_affected.'.format(affected_rows))
        sys.exit(0)
    except Exception as e:
        print('Update of CVM IF Daily Position failed: {}'.format(e))
        sys.exit(1)

