'''
CVM Package
Provides modules, functions and classes for CVM (Comissão de Valores Imobiliários) provider.
'''