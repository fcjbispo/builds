'''
Admin Module
Provides cli with administration operations.
'''
import sys, subprocess
from datetime import datetime
from enum import auto

import re
import click

from infobr import core
from infobr.core import db
from infobr.api import server
from infobr.model.security import AuthorizationKey
from infobr.providers.cvm.update import if_daily_position as idp

from fbpyutils import datetime as dutl


_et = lambda x: '{}d, {}hs {}mins {}secs'.format(*x)

_validate_email = lambda x: re.search('^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$', x)

# cli (main) group
@click.group()
def cli():
    pass

# security group
@click.group(help='Performs security operations as api key creation/expiration.')
def security():
    pass

# create infobr apy key
@click.command(help='Creates a new api key.')
@click.option('-e', '--email', required=True, help='Registered email for this api key.')
@click.option('--privileged', default=False, is_flag=True, help='Creates a api key with admin privileges.')
def create_api_key(email: str, privileged: bool = False):
    start_date = datetime.now()
    ak = AuthorizationKey()
    try:
        if not _validate_email(email):
            raise Exception('Invalid email: {}'.format(email))

        ak.is_privileged = bool(privileged)
        ak.registered_email = email

        db.session.add(ak)
        db.session.commit()

        click.echo('New{}api key {} created for {}.'.format((' privileged ' if privileged else ' '), ak.api_key, email))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        db.session.rollback()
        click.echo('Failed on api key creation: {}.'.format(e))
        sys.exit(1)

# expire api keys due to last access greater than specifict number of days or all
@click.command(help='Expires api keys unused for {} days.'.format(core.settings['api_key_expiration_days']))
@click.option('-a', '--all', is_flag=True, help='Expires all api keys regardless last usage.')
def expire_keys(all: bool = False):
    start_date = datetime.now()
    try:
        expireds = 0
        for ak in AuthorizationKey.query.filter(AuthorizationKey.is_expired == False).all():
            if dutl.elapsed_time(ak.last_access or datetime.now(), ak.creation_date)[0] >= \
                core.settings['api_key_expiration_days'] or all:
                ak.is_expired = True
                expireds += 1
        db.session.commit()
        click.echo('{} expired API Key(s).'.format(expireds))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
    except Exception as e:
        click.echo('API Keys expiration failed: {}'.format(e))
        sys.exit(1)

security.add_command(create_api_key)
security.add_command(expire_keys)
cli.add_command(security)

# update group
@click.group(help='Performs update operations for financial data.')
def update():
    pass

# run the CVM data update
@click.command(help='Updates CVM Investment Funds daily position.')
def cvm_if_daily_position():
    start_date = datetime.now()
    try:
        affected_rows = idp.update_if_daily_position(idp.get_if_daily_data())
        click.echo('Update of CVM IF Daily Position: {} rows_affected.'.format(affected_rows))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        click.echo('Update of CVM IF Daily Position failed: {}'.format(e))
        sys.exit(1)

update.add_command(cvm_if_daily_position)
cli.add_command(update)

@click.group(help='Run operations and servers.')
def run():
    pass

@click.command(help='Runs API Server')
@click.option('-s', '--secure', is_flag=True, help='Runs API Server in secure mode. Requires SSL certificates.')
def api_server(secure: bool=False):
    start_date = datetime.now()
    try:
        if secure:
            if not all([core.settings['api_server_ssl_certificate'], core.settings['api_server_ssl_keyfile']]):
                raise Exception('No SSL certificates/keyfile provided.')
            
            _run = '''gunicorn 
                      --certfile={certfile} 
                      --keyfile={keyfile} 
                      --workers={workers} 
                      --bind={host}:{port} infobr.api.server:app'''.format(
                          certfile=core.settings['api_server_ssl_certificate'],
                          keyfile=core.settings['api_server_ssl_keyfile'],
                          workers=core.settings['api_server_workers'],
                          host=core.settings['host_listen_address'],
                          port=core.settings['host_listen_port']
                      ).split()

            subprocess.call(_run)
        else:
            server.run_api_server()
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        click.echo('API Server run failed: {}'.format(e))
        sys.exit(1)

run.add_command(api_server)
cli.add_command(run)

# initialize the cli interface
if __name__ == '__main__':
    cli()
