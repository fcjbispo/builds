'''
CVM Model Module
Provides all persistence models for CVM objects.
'''
from infobr.core import db, ma

from datetime import datetime

from fbpyutils import string as sutl

class IFDailyPosition(db.Model):
    __tablename__ = 'cvm_if_daily_position'
    __table_args__ = (db.UniqueConstraint('fund_id', 'fund_type', 'position_key'),)
    id = db.Column(db.String(32), primary_key=True, default=sutl.random_string)        
    fund_type = db.Column(db.String(32), nullable=False, )
    fund_id = db.Column(db.String(18), nullable=False, )
    fund_name = db.Column(db.String(256), nullable=False, index=True)
    register_date = db.Column(db.Date(),  )
    constitution_date = db.Column(db.Date(),  )
    cvm_code = db.Column(db.String(12),  )
    cancel_date = db.Column(db.Date(),  )
    situation_code = db.Column(db.String(32),  )
    situation_start_date = db.Column(db.Date(),  )
    situation_end_date = db.Column(db.Date(),  )
    excercise_start_date = db.Column(db.Date(),  )
    excercise_end_date = db.Column(db.Date(),  )
    fund_class = db.Column(db.String(32),  )
    class_start_date = db.Column(db.Date(),  )
    profitability_type = db.Column(db.String(100),  )
    tenancy_type = db.Column(db.String(12),  )
    is_quote_fund = db.Column(db.Boolean(),  )
    is_exclusive_fund = db.Column(db.Boolean(),  )
    is_long_term_tax = db.Column(db.Boolean(),  )
    is_qualified_investment = db.Column(db.Boolean(),  )
    is_investment_entity = db.Column(db.Boolean(),  )
    perf_rate = db.Column(db.Numeric(scale=8, precision=32, asdecimal=False), )
    perf_rate_info = db.Column(db.String(512),  )
    admin_rate = db.Column(db.Numeric(scale=8, precision=32, asdecimal=False), )
    admin_rate_info = db.Column(db.String(512),  )
    net_worth = db.Column(db.Numeric(scale=2, precision=32, asdecimal=False), )
    net_worth_date = db.Column(db.Date(),  )
    director_name = db.Column(db.String(256),  )
    admin_id = db.Column(db.String(18),  )
    admin_name = db.Column(db.String(256),  )
    manager_type = db.Column(db.String(12),  )
    manager_id = db.Column(db.String(18),  )
    manager_name = db.Column(db.String(256), index=True,  )
    controller_id = db.Column(db.String(18),  )
    controller_name = db.Column(db.String(256),  )
    custodian_id = db.Column(db.String(18),  )
    custodian_name = db.Column(db.String(256),  )
    supervisor_id = db.Column(db.String(18),  )
    supervisor_name = db.Column(db.String(256),  )
    total_value = db.Column(db.Numeric(scale=2, precision=32, asdecimal=False), )
    quota_value = db.Column(db.Numeric(scale=8, precision=32, asdecimal=False), )
    net_worth_value = db.Column(db.Numeric(scale=2, precision=32, asdecimal=False), )
    daily_capture_value = db.Column(db.Numeric(scale=2, precision=32, asdecimal=False), )
    daily_redemption_value = db.Column(db.Numeric(scale=2, precision=32, asdecimal=False), )
    shareholders = db.Column(db.Integer(),  )
    position_date = db.Column(db.DateTime(), nullable=False, )
    position_key = db.Column(db.String(6), nullable=False, )
    creation_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    update_date = db.Column(db.DateTime, nullable=True, onupdate=datetime.utcnow)

    def __repr__(self) -> str:
        return f'CVM INVESTMENT FUND: {self.fund_id}: {self.fund_name} ({self.fund_type})'

class IFDailyPositionSchema(ma.Schema):
    class Meta:
        model = IFDailyPosition
        sqla_session = db.session

db.create_all()