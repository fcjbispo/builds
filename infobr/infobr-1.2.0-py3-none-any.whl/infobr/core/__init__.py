'''
Core Package
Provides core modules, functions and classes for entire system.
'''
import os, sys
import traceback

from dotenv import load_dotenv

import connexion
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

# loading config parameters
load_dotenv()

# debug resources
def debug_info(x: Exception):
    '''
    Return extra exception/execution info for debug.
    '''
    try:
        info = traceback.format_exc()
    except Exception as e:
        info = "Unable to get debug info: {}".format(e)

    return info if settings['debug_info'] else x.__str__()

def debug(x):
    '''
    Decorator function to be used to debug execution of system functions.
    Prints all arguments used and the result value of the debugged functions.

    Use:

    @debug
    def myFunc(x, y, z)?
        pass

        x
            The function to be decorated

        Return function decorator
    '''

    def _debug(*args, **kwargs):
        result = x(*args, **kwargs)
        print(
            f"{x.__name__}(args: {args}, kwargs: {kwargs}) -> {result}"
        )
        return result

    return _debug

def debug_print(x):
    '''
    Prints x on standard out if DEBUG is turned ON.

    Use:
    '''
    if settings['debug_info']:
        print(x, file=sys.stdout)


# define global core settings
settings = {}

settings['environment'] = os.environ.get('FLASK_ENV', 'development') #or production
settings['debug_info'] = os.environ.get('INFOBR_DEBUG', 'FALSE') == 'TRUE'
settings['host_listen_address'] = os.environ.get('INFOBR_HOST_LISTEN_ADDRESS', '0.0.0.0')
settings['host_listen_port'] = os.environ.get('INFOBR_HOST_LISTEN_PORT', 5000)

settings['db_url'] = os.environ.get('INFOBR_DB_URL', 'sqlite:///infobr.db')
settings['db_user_name'] = os.environ.get('INFOBR_DB_USER_NAME', None)
settings['db_user_password'] = os.environ.get('INFOBR_DB_USER_PASSWORD', None)

settings['api_key_expiration_days'] = os.environ.get('INFOBR_API_KEY_EXPIRATION', 90)

settings['api_key_expiration_days'] = os.environ.get('INFOBR_API_KEY_EXPIRATION', 90)

settings['api_server_ssl_certificate'] = os.environ.get('INFOBR_SSL_CERTIFICATE', None)
settings['api_server_ssl_keyfile'] = os.environ.get('INFOBR_SSL_KEYFILE', None)
settings['api_server_workers'] = os.environ.get('INFOBR_SERVER_WORKERS', 2)

# build global core objects
application = {
    "application": {
        "name": "InfoBR - Informações Financeiras do Mercado Brasileiro",
        "initials": "INFOBR",
        "version": "1.2.0",
        "copyright": {
            "year": 2021,
            "owner": "Ackertime Serviços em Informática"
        }
    }
}

# build core app object

connex_app = connexion.App(__name__)

app = connex_app.app

# Configure the SqlAlchemy part of the app instance
app.config["SQLALCHEMY_ECHO"] = settings['debug_info'] or False
app.config["SQLALCHEMY_DATABASE_URI"] = settings['db_url'].format(
        user=settings['db_user_name'],
        password=settings['db_user_password'])
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    'max_identifier_length': 30
}

# Create the SqlAlchemy db instance
db = SQLAlchemy(app)

# Initialize Marshmallow
ma = Marshmallow(app)
