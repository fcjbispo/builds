'''
Exchange Rate Service
Provide exchange rate among currencies.
'''
from infobr.api import services

from datetime import datetime
from infobr.providers import google

def get(currency_from: str, currency_to: str, request_time: datetime=None):
    '''
        This function responds to a request for /api/exchange_rate/FROM/TO
        Return the exchange rate for from the first currency to the second from Google Finance.
        The currency codes used are the ISO 4217

        currency_from
            The currency code to be exchanged

        currency_to
            The currency code to be used to exchange

        request_time
            The datetime object representing the request time

        Return the response object filled with request and response times
    '''
    request_time = request_time or datetime.now()

    response = services.stamp_response(google.exchange_rate(currency_from, currency_to), request_time=request_time)

    if response['status'] == 'SUCCESS':
        return response, 200
    elif response['status'] == 'NOT FOUND':
        return response, 404
    else:
        return response, 500
