# %%
"""
Custom Process wrapper for InfoBR with progress callback support.

This module provides a Process class that extends fbpyutils.process.Process
to add callback support for real-time progress updates in Rich TUI.

This is a temporary local solution until fbpyutils includes callback support natively.
"""

import time
from time import perf_counter
from typing import Any, Callable, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from tqdm import tqdm

from fbpyutils.process import Process as BaseProcess
from infobr import logger


class ProcessWithCallback(BaseProcess):
    """
    Extended Process class with progress callback support.
    
    This class wraps the fbpyutils Process and adds a progress_callback parameter
    that allows external code (like Rich TUI) to receive real-time progress updates.
    
    Attributes:
        progress_callback: Optional callback function(current, total, status)
    """
    
    def __init__(
        self,
        process: Callable,
        parallelize: bool = True,
        workers: Optional[int] = None,
        sleeptime: float = 0,
        parallel_type: str = "threads",
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ):
        """
        Initialize Process with optional progress callback.
        
        Args:
            process: The processing function to execute
            parallelize: Enable parallel execution
            workers: Number of worker threads/processes
            sleeptime: Sleep time between items in serial mode
            parallel_type: 'threads' or 'processes'
            progress_callback: Optional callback(current, total, status)
                              - current: items processed so far
                              - total: total items to process
                              - status: 'running', 'completed', 'error'
        """
        super().__init__(
            process=process,
            parallelize=parallelize,
            workers=workers,
            sleeptime=sleeptime,
            parallel_type=parallel_type
        )
        self.progress_callback = progress_callback
    
    def run(
        self,
        params: List[Tuple[Any, ...]],
        progress: bool = False
    ) -> List[Tuple[bool, Optional[str], Any]]:
        """
        Execute processing with optional progress bar and callback.
        
        Args:
            params: List of parameter tuples to process
            progress: Show progress bar (uses tqdm)
            
        Returns:
            List of processing results
        """
        total = len(params)
        
        # Notify start via callback
        if self.progress_callback:
            self.progress_callback(0, total, "running")
        
        # Prioriza callback sobre tqdm para evitar conflitos com Rich
        if self.progress_callback:
            return self._run_with_callback(params)
        elif progress:
            return self._run_with_tqdm(params)
        else:
            # No progress tracking at all
            return super().run(params)
    
    def _run_with_callback(
        self,
        params: List[Tuple[Any, ...]]
    ) -> List[Tuple[bool, Optional[str], Any]]:
        """Run processing with callback updates only (no tqdm)."""
        start_time = perf_counter()
        responses = []
        total = len(params)
        
        if not self._parallelize:
            # Serial execution with callback
            logger.info(f"Running in serial mode with callback. Total: {total}")
            
            for i, param in enumerate(params):
                try:
                    result = self._process(*param)
                    responses.append(result)
                except Exception as e:
                    logger.error(f"Error processing item {i + 1}/{total}: {e}")
                    responses.append((False, str(e), None))
                
                # Update callback
                if self.progress_callback:
                    self.progress_callback(i + 1, total, "running")
                
                if self.sleeptime > 0:
                    time.sleep(self.sleeptime)
        else:
            # Parallel execution - callback called at chunks
            logger.info(f"Running in parallel mode with callback. Total: {total}")
            
            max_workers = self._workers or self.get_available_cpu_count()
            executor_class = (
                ProcessPoolExecutor if self._parallel_type == "processes"
                else ThreadPoolExecutor
            )
            
            try:
                with executor_class(max_workers=max_workers) as executor:
                    if self._parallel_type == "processes":
                        # Use wrapper for processes (picklable)
                        wrapped_inputs = [(self._process, p) for p in params]
                        futures = [
                            executor.submit(self._process_wrapper, wi)
                            for wi in wrapped_inputs
                        ]
                    else:
                        futures = [
                            executor.submit(self._process, *p)
                            for p in params
                        ]
                    
                    # Collect results with callback updates
                    for i, future in enumerate(futures):
                        try:
                            result = future.result()
                            responses.append(result)
                        except Exception as e:
                            logger.error(f"Error in future {i + 1}/{total}: {e}")
                            responses.append((False, str(e), None))
                        
                        # Update callback every item or less frequently if needed
                        if self.progress_callback:
                            self.progress_callback(i + 1, total, "running")
                            
            except Exception as e:
                logger.error(f"Error during parallel execution: {e}")
                if self.progress_callback:
                    self.progress_callback(len(responses), total, "error")
                raise
        
        # Final callback
        if self.progress_callback:
            self.progress_callback(total, total, "completed")
        
        duration = perf_counter() - start_time
        logger.info(f"Execution completed: {total} items in {duration:.2f}s")
        
        return responses
    
    def _run_with_tqdm(
        self,
        params: List[Tuple[Any, ...]]
    ) -> List[Tuple[bool, Optional[str], Any]]:
        """Run processing with tqdm progress bar (only when no callback)."""
        start_time = perf_counter()
        responses = []
        total = len(params)
        
        # Não usa tqdm se houver callback para evitar conflitos com Rich
        if self.progress_callback:
            return self._run_with_callback(params)
        
        with tqdm(total=total, desc="Processando", unit="item") as pbar:
            if not self._parallelize:
                # Serial execution
                for i, param in enumerate(params):
                    try:
                        result = self._process(*param)
                        responses.append(result)
                    except Exception as e:
                        logger.error(f"Error: {e}")
                        responses.append((False, str(e), None))
                    
                    pbar.update(1)
                    
                    if self.sleeptime > 0:
                        time.sleep(self.sleeptime)
            else:
                # Parallel execution with thread/process map
                max_workers = self._workers or self.get_available_cpu_count()
                
                from tqdm.contrib.concurrent import thread_map, process_map
                
                wrapped_inputs = [(self._process, p) for p in params]
                
                if self._parallel_type == "processes":
                    responses = process_map(
                        self._process_wrapper,
                        wrapped_inputs,
                        max_workers=max_workers,
                        desc="Processando",
                        unit="item"
                    )
                else:
                    responses = thread_map(
                        self._process_wrapper,
                        wrapped_inputs,
                        max_workers=max_workers,
                        desc="Processando",
                        unit="item"
                    )
        
        duration = perf_counter() - start_time
        logger.info(f"Execution completed: {total} items in {duration:.2f}s")
        
        return responses


# Compatibility alias - use this to maintain same interface
Process = ProcessWithCallback
# %%
