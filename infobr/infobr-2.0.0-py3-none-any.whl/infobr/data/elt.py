#!/usr/bin/env python3
"""
InfoBR ELT Pipeline TUI CLI

Interface de linha de comando interativa para gerenciar e executar pipelines ELT.

Usage:
    python -m infobr.data.elt                    # Modo interativo TUI
    python -m infobr.data.elt -p series.extract  # Executar pipeline diretamente
    python -m infobr.data.elt -l                 # Listar pipelines disponíveis
"""

import os
import sys
import time
import argparse
from typing import List, Tuple, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.prompt import Prompt, Confirm
from rich import box

# Import from parent package
from infobr import logger, env
from infobr.services import (
    estimate_pipeline_items,
    get_pipeline_config,
    list_operation_files,
    list_pipelines,
    read_operation_file,
    run_pipeline,
    summarize_pipeline_execution,
    validate_pipeline_exists,
)

console = Console()


class ELT_TUI:
    """
    Terminal User Interface for InfoBR ELT Pipelines.
    """
    
    PIPELINES_FOLDER = os.path.sep.join([env.USER_APP_FOLDER, "pipelines"])
    OPERATIONS_FOLDER = os.path.sep.join([env.USER_APP_FOLDER, "operations"])
    PIPELINE_MASK = "*.json"
    
    def __init__(self):
        self.pipelines: List[Tuple[str, str]] = []
        self.selected_pipeline: Optional[str] = None
        
    def clear_screen(self):
        """Clear terminal screen."""
        console.clear()
        
    def get_pipelines(self) -> List[Tuple[str, str]]:
        """List all available pipelines."""
        pipelines = list_pipelines(self.PIPELINES_FOLDER)
        return [(p.name, p.path) for p in pipelines]
    
    def display_header(self):
        """Display application header."""
        header = Panel(
            Text("📊 InfoBR ELT Pipeline Manager", style="bold cyan", justify="center"),
            subtitle=f"v2.0.0 | User: {env.USER}",
            box=box.SQUARE,
            border_style="blue"
        )
        console.print(header)
        console.print()
        
    def display_pipelines_table(self) -> Optional[str]:
        """Display pipelines in an interactive table and return selection."""
        self.pipelines = self.get_pipelines()
        
        if not self.pipelines:
            console.print("[yellow]⚠️  Nenhuma pipeline encontrada![/yellow]")
            console.print(f"[dim]Crie pipelines em: {self.PIPELINES_FOLDER}[/dim]")
            return None
        
        table = Table(
            title="📁 Pipelines Disponíveis",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta",
            row_styles=["", "dim"]
        )
        
        table.add_column("#", style="bold cyan", width=4, justify="center")
        table.add_column("Nome", style="green", min_width=25)
        table.add_column("Arquivo", style="dim", min_width=40)
        table.add_column("Status", style="blue", width=10, justify="center")
        
        for idx, (name, path) in enumerate(self.pipelines, 1):
            display_name = name.replace(".", " ").replace("_", " ").title()
            table.add_row(
                str(idx),
                display_name,
                os.path.basename(path),
                "[green]✓[/green]"
            )
        
        console.print(table)
        console.print()
        
        # Interactive selection
        choices = [str(i) for i in range(1, len(self.pipelines) + 1)]
        choices.append("q")
                    
        choice = Prompt.ask(
            "[cyan]Selecione uma pipeline (número) ou q para sair[/cyan]",
            choices=choices,
            show_choices=False
        )
        
        if choice == "q":
            return None
            
        selected_idx = int(choice) - 1
        return self.pipelines[selected_idx][0]
    
    def display_pipeline_info(self, pipeline_name: str):
        """Display detailed information about a pipeline."""
        try:
            config = get_pipeline_config(pipeline_name, self.PIPELINES_FOLDER)
        except FileNotFoundError:
            console.print(f"[red]❌ Pipeline não encontrada: {pipeline_name}[/red]")
            return False
        except Exception as e:
            console.print(f"[red]❌ Erro ao carregar pipeline: {str(e)}[/red]")
            return False

        file_path = os.path.sep.join([self.PIPELINES_FOLDER, f"{pipeline_name}.json"])
        
        # Create info panel
        info_text = []
        info_text.append(f"[bold cyan]Nome:[/bold cyan] {pipeline_name}")
        
        if "processor" in config:
            info_text.append(f"[bold cyan]Processor:[/bold cyan] {config['processor']}")
        
        if "scopes" in config:
            scopes = config["scopes"]
            info_text.append(f"[bold cyan]Scopes:[/bold cyan] {len(scopes)} item(s)")
            for scope in scopes:
                info_text.append(f"  • {scope}")
        
        if "llm" in config:
            llm = config["llm"] or "Não definido"
            info_text.append(f"[bold cyan]LLM:[/bold cyan] {llm}")
            
        if "timeout" in config:
            info_text.append(f"[bold cyan]Timeout:[/bold cyan] {config['timeout']}ms")
            
        if "parallelize" in config:
            parallel = "Sim" if config["parallelize"] else "Não"
            info_text.append(f"[bold cyan]Paralelização:[/bold cyan] {parallel}")
        
        info_text.append(f"[dim]Arquivo: {file_path}[/dim]")
        
        panel = Panel(
            "\n".join(info_text),
            title="📋 Configuração da Pipeline",
            box=box.ROUNDED,
            border_style="green"
        )
        console.print(panel)
        console.print()
        return True
    
    def run_pipeline_with_progress(self, pipeline_name: str, parallelize: bool = True, progress: bool = True):
        """Execute pipeline with rich progress display with determinate progress bar."""
        console.print()
        console.print(f"[bold green]🚀 Iniciando pipeline:[/bold green] [cyan]{pipeline_name}[/cyan]")
        console.print("[dim]Pressione Ctrl+C para interromper[/dim]")
        console.print()
        
        # Estimate total items from pipeline config
        total_items = self._estimate_pipeline_items(pipeline_name)
        
        try:
            # Create progress display with determinate total - disable tqdm completely
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(bar_width=40),
                TaskProgressColumn(),
                console=console,
                transient=False
            ) as progress_display:
                
                task = progress_display.add_task(
                    f"[cyan]Executando {pipeline_name}...[/cyan]",
                    total=total_items or None  # Determinate if we know total
                )
                
                # Progress callback that updates the Rich progress bar
                def progress_callback(current: int, total: int, status: str):
                    if status == "running":
                        # Update total if we got a more accurate count
                        if progress_display._tasks[task].total != total:
                            progress_display.update(task, total=total)
                        progress_display.update(task, completed=current)
                    elif status == "completed":
                        progress_display.update(task, completed=total)
                        progress_display.update(task, description="[green]✓ Pipeline concluída![/green]")
                    elif status == "error":
                        progress_display.update(task, description="[red]Erro durante execução[/red]")
                
                # Validate pipeline before execution
                try:
                    validate_pipeline_exists(pipeline_name, self.PIPELINES_FOLDER)
                except FileNotFoundError:
                    console.print(f"[red]❌ Pipeline não encontrada: {pipeline_name}[/red]")
                    return False
                
                progress_display.update(task, description="[cyan]Processando dados...[/cyan]")
                
                # Run via shared service - disable tqdm to avoid conflicts with Rich.
                run_pipeline(
                    pipeline_name,
                    parallelize=parallelize,
                    progress=False,  # Disable tqdm completely
                    progress_callback=progress_callback
                )
            
            # Show results summary
            self.show_execution_summary(pipeline_name)
            return True
            
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠️  Pipeline interrompida pelo usuário[/yellow]")
            return False
        except Exception as e:
            console.print(f"\n[red]❌ Erro na execução: {str(e)}[/red]")
            logger.error(f"Pipeline execution failed: {e}")
            return False
    
    def _estimate_pipeline_items(self, pipeline_name: str) -> int:
        """Estimate total items to process for a pipeline."""
        try:
            return estimate_pipeline_items(pipeline_name, self.PIPELINES_FOLDER)
        except Exception as e:
            logger.warning(f"Could not estimate pipeline items: {e}")
            return 0  # Return 0 to use indeterminate mode
    
    def display_results_menu(self):
        """Display results menu with option to view detailed results."""
        while True:
            try:
                result_files_info = list_operation_files(limit=10, operations_dir=self.OPERATIONS_FOLDER)
                result_files = [i.path for i in result_files_info]
                
                if not result_files:
                    console.print("[yellow]⚠️  Nenhuma execução encontrada[/yellow]")
                    console.print()
                    Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
                    return
                
                table = Table(
                    title="📁 Últimas Execuções",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                table.add_column("#", width=3)
                table.add_column("Pipeline", style="green")
                table.add_column("Timestamp", style="cyan")
                table.add_column("Tamanho", justify="right")
                
                for idx, info in enumerate(result_files_info, 1):
                    name = info.pipeline_name or "unknown"
                    timestamp = info.run_timestamp
                    size = info.file_size
                    size_str = f"{size/1024:.1f} KB" if size > 1024 else f"{size} B"
                    
                    table.add_row(str(idx), name, timestamp, size_str)
                
                console.print(table)
                console.print()
                
                # Menu options
                choices = [str(i) for i in range(1, len(result_files) + 1)]
                choices.append("q")
                
                choice = Prompt.ask(
                    "[cyan]Selecione um resultado para ver detalhes ou q para sair[/cyan]",
                    choices=choices,
                    show_choices=False
                )
                
                if choice == "q":
                    return
                else:
                    # View detailed results
                    selected_idx = int(choice) - 1
                    if 0 <= selected_idx < len(result_files):
                        selected_file = result_files[selected_idx]
                        self.display_result_details(selected_file)
                    else:
                        console.print("[red]❌ Seleção inválida[/red]")
                    
            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Menu interrompido[/yellow]")
                return
    
    def display_result_details(self, result_file: str):
        """Display detailed results from a JSON file with pagination support."""
        try:
            results = read_operation_file(result_file, max_size_mb=50)
            
            if not results:
                console.print("[yellow]⚠️  Arquivo de resultado vazio[/yellow]")
                return
            
            total_records = len(results)
            RECORDS_PER_PAGE = 50  # Maximum records per page for performance
            
            # Determine navigation mode based on total records
            use_pagination = total_records > RECORDS_PER_PAGE
            
            if use_pagination:
                self._display_paginated_results(results, result_file, RECORDS_PER_PAGE)
            else:
                self._display_individual_results(results, result_file)
        except ValueError as e:
            console.print(f"[red]❌ Erro de validação ao ler arquivo: {str(e)}[/red]")
            console.print(f"[dim]Arquivo: {result_file}[/dim]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
        except FileNotFoundError as e:
            console.print(f"[red]❌ Arquivo não encontrado: {str(e)}[/red]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
        except PermissionError as e:
            console.print(f"[red]❌ Sem permissão para ler o arquivo: {str(e)}[/red]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
        except OSError as e:
            console.print(f"[red]❌ Erro ao acessar arquivo: {str(e)}[/red]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
        except KeyboardInterrupt:
            console.print("\n[yellow]⚠️  Visualização interrompida[/yellow]")
            return
        except Exception as e:
            console.print(f"[red]❌ Erro inesperado: {str(e)}[/red]")
            console.print(f"[dim]Tipo: {type(e).__name__}[/dim]")
            console.print()
            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
            
    def _display_paginated_results(self, results: list, result_file: str, records_per_page: int):
        """Display results with pagination navigation (for large datasets)."""
        total_records = len(results)
        total_pages = (total_records + records_per_page - 1) // records_per_page
        current_page = 0
        
        while True:
            try:
                self.clear_screen()
                self.display_header()
                
                # Calculate page boundaries
                start_idx = current_page * records_per_page
                end_idx = min(start_idx + records_per_page, total_records)
                page_records = results[start_idx:end_idx]
                
                # Display file info with pagination details
                basename = os.path.basename(result_file)
                console.print(Panel(
                    f"[bold cyan]Arquivo:[/bold cyan] {basename}\n"
                    f"[bold cyan]Página:[/bold cyan] {current_page + 1} de {total_pages} "
                    f"({start_idx + 1}-{end_idx} de {total_records} registros)",
                    title="📊 Detalhes do Resultado (Modo Paginação)",
                    box=box.ROUNDED,
                    border_style="green"
                ))
                console.print()
                
                # Create summary table for the page
                summary_table = Table(
                    title=f"📋 Resumo da Página {current_page + 1}",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                summary_table.add_column("Scope", style="green", min_width=25)
                summary_table.add_column("Status", style="bold", width=10, justify="center")
                summary_table.add_column("Erro", style="red", max_width=40)
                
                success_count = 0
                error_count = 0
                
                for record in page_records:
                    success = record.get("success", False)
                    if success:
                        success_count += 1
                        status = "[green]✓[/green]"
                    else:
                        error_count += 1
                        status = "[red]✗[/red]"
                    
                    error_msg = ""
                    if record.get("error_message"):
                        error_msg = str(record["error_message"])[:60]  # Truncate long errors
                        if len(error_msg) == 60:
                            error_msg += "..."
                    
                    summary_table.add_row(
                        str(record.get("scope", "N/A")),
                        status,
                        error_msg
                    )
                
                console.print(summary_table)
                console.print()
                
                # Page statistics
                stats_table = Table(box=box.ROUNDED, show_header=False)
                stats_table.add_column("Métrica", style="bold")
                stats_table.add_column("Valor", justify="right")
                
                stats_table.add_row("Registros nesta página", str(len(page_records)))
                stats_table.add_row("[green]Sucessos na página[/green]", f"[green]{success_count}[/green]")
                if error_count > 0:
                    stats_table.add_row("[red]Erros na página[/red]", f"[red]{error_count}[/red]")
                stats_table.add_row("", "")
                stats_table.add_row("Total de registros", str(total_records))
                
                # Calculate overall statistics
                total_success = sum(1 for r in results if r.get("success", False))
                total_errors = total_records - total_success
                stats_table.add_row("[green]Total de sucessos[/green]", f"[green]{total_success}[/green]")
                if total_errors > 0:
                    stats_table.add_row("[red]Total de erros[/red]", f"[red]{total_errors}[/red]")
                stats_table.add_row("Taxa de sucesso geral", f"{(total_success/total_records*100):.1f}%")
                
                console.print(stats_table)
                console.print()
                
                # Navigation menu
                nav_options = []
                if current_page > 0:
                    nav_options.append("p Página anterior")
                if current_page < total_pages - 1:
                    nav_options.append("n Próxima página")
                nav_options.extend(["i Ir para página", "q Sair"])
                
                nav_text = " | ".join(nav_options)
                console.print(f"[cyan]{nav_text}[/cyan]")
                console.print()
                
                # Get navigation choice
                available_choices = []
                if current_page > 0:
                    available_choices.append("p")
                if current_page < total_pages - 1:
                    available_choices.append("n")
                available_choices.extend(["i", "q"])
                
                choice = Prompt.ask(
                    "[cyan]Escolha uma opção[/cyan]",
                    choices=available_choices,
                    show_choices=False
                )
                
                if choice == "p" and current_page > 0:
                    current_page -= 1
                elif choice == "n" and current_page < total_pages - 1:
                    current_page += 1
                elif choice == "i":
                    # Go to specific page
                    page_num = Prompt.ask(
                        f"[cyan]Ir para página (1-{total_pages})[/cyan]",
                        default=str(current_page + 1)
                    )
                    try:
                        new_page = int(page_num) - 1
                        if 0 <= new_page < total_pages:
                            current_page = new_page
                        else:
                            console.print(f"[red]❌ Página inválida. Deve estar entre 1 e {total_pages}[/red]")
                            time.sleep(1)
                    except ValueError:
                        console.print("[red]❌ Número de página inválido[/red]")
                        time.sleep(1)
                elif choice == "q":
                    return
                    
            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Navegação interrompida[/yellow]")
                return
            
    def _display_individual_results(self, results: list, result_file: str):
        """Display results with individual record navigation (for small datasets)."""
        current_index = 0
        total_records = len(results)
        
        while True:
            try:
                self.clear_screen()
                self.display_header()
                
                # Display file info
                basename = os.path.basename(result_file)
                console.print(Panel(
                    f"[bold cyan]Arquivo:[/bold cyan] {basename}\n"
                    f"[bold cyan]Registro:[/bold cyan] {current_index + 1} de {total_records}",
                    title="📊 Detalhes do Resultado",
                    box=box.ROUNDED,
                    border_style="green"
                ))
                console.print()
                
                # Get current record
                record = results[current_index]
                
                # Display record details in table format
                details_table = Table(
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold cyan"
                )
                details_table.add_column("Campo", style="bold", width=20)
                details_table.add_column("Valor", min_width=40)
                
                # Basic info
                details_table.add_row("Scope", str(record.get("scope", "N/A")))
                details_table.add_row("Success", "[green]✓ Sim[/green]" if record.get("success") else "[red]✗ Não[/red]")
                
                if record.get("error_message"):
                    details_table.add_row("Error", f"[red]{record['error_message']}[/red]")
                
                # Parameters section
                if "data" in record and "params" in record["data"]:
                    details_table.add_row("", "")  # Empty row as separator
                    details_table.add_row("[bold magenta]Parâmetros[/bold magenta]", "")
                    params = record["data"]["params"]
                    
                    for key, value in params.items():
                        if isinstance(value, (str, int, float, bool)):
                            details_table.add_row(f"  {key}", str(value))
                        elif isinstance(value, list) and len(value) <= 3:
                            details_table.add_row(f"  {key}", ", ".join(map(str, value)))
                        elif isinstance(value, list):
                            details_table.add_row(f"  {key}", f"Lista com {len(value)} itens")
                        else:
                            details_table.add_row(f"  {key}", str(type(value).__name__))
                
                # Output file
                if "data" in record and "output_file_path" in record["data"]:
                    details_table.add_row("", "")
                    details_table.add_row("[bold magenta]Arquivo de Saída[/bold magenta]", record["data"]["output_file_path"])
                
                console.print(details_table)
                console.print()
                
                # Navigation menu
                nav_options = []
                if current_index > 0:
                    nav_options.append("p Anterior")
                if current_index < total_records - 1:
                    nav_options.append("n Próximo")
                nav_options.extend(["q Sair"])
                
                nav_text = " | ".join(nav_options)
                console.print(f"[cyan]{nav_text}[/cyan]")
                console.print()
                
                # Get navigation choice
                available_choices = []
                if current_index > 0:
                    available_choices.append("p")
                if current_index < total_records - 1:
                    available_choices.append("n")
                available_choices.append("q")
                
                choice = Prompt.ask(
                    "[cyan]Escolha uma opção[/cyan]",
                    choices=available_choices,
                    show_choices=False
                )
                
                if choice == "p" and current_index > 0:
                    current_index -= 1
                elif choice == "n" and current_index < total_records - 1:
                    current_index += 1
                elif choice == "q":
                    return
                    
            except KeyboardInterrupt:
                console.print("\n[yellow]⚠️  Navegação interrompida[/yellow]")
                return
    
    def show_execution_summary(self, pipeline_name: str):
        """Display summary of last execution."""
        summary = summarize_pipeline_execution(
            pipeline_name,
            operations_dir=self.OPERATIONS_FOLDER,
        )

        if not summary:
            console.print("[yellow]⚠️  Nenhum arquivo de resultado encontrado[/yellow]")
            return

        try:
            # Create summary table
            summary_table = Table(
                title=f"📊 Resumo da Execução ({os.path.basename(summary.file_path)})",
                box=box.ROUNDED,
                show_header=True,
                header_style="bold cyan"
            )
            
            summary_table.add_column("Métrica", style="bold")
            summary_table.add_column("Valor", justify="right")
            
            summary_table.add_row("Total de operações", str(summary.total_operations))
            summary_table.add_row("[green]Sucessos[/green]", f"[green]{summary.successful_operations}[/green]")
            if summary.failed_operations > 0:
                summary_table.add_row("[red]Falhas[/red]", f"[red]{summary.failed_operations}[/red]")
            summary_table.add_row("Taxa de sucesso", f"{summary.success_rate:.1f}%")
            
            console.print(summary_table)
            console.print()
            
            # Show errors if any
            if summary.failed_operations > 0:
                error_table = Table(
                    title="❌ Operações com Erro",
                    box=box.ROUNDED,
                    show_header=True,
                    header_style="bold red"
                )
                error_table.add_column("Scope", style="cyan")
                error_table.add_column("Erro", style="red", max_width=60)
                
                for err in summary.errors:
                    error_table.add_row(
                        str(err.scope or "N/A"),
                        err.error_message
                    )
                
                console.print(error_table)
                console.print()
            
            console.print(f"[dim]📁 Resultado completo em: {summary.file_path}[/dim]")
        except Exception as e:
            console.print(f"[yellow]⚠️  Erro inesperado ao ler resultado: {str(e)}[/yellow]")
            console.print(f"[dim]Tipo: {type(e).__name__}[/dim]")
    
    def run_interactive(self):
        """Run interactive TUI mode."""
        while True:
            self.clear_screen()
            self.display_header()
            
            # Show menu
            menu_options = [
                "[1] Listar e executar pipeline",
                "[2] Ver últimos resultados",
                "q Sair"
            ]
            
            menu_panel = Panel(
                "\n".join(menu_options),
                title="⚡ Menu Principal",
                box=box.ROUNDED,
                border_style="cyan"
            )
            console.print(menu_panel)
            console.print()
            
            choice = Prompt.ask(
                "[cyan]Escolha uma opção (1, 2 ou q para sair)[/cyan]",
                choices=["1", "2", "q"],
                show_choices=False
            )
            
            if choice == "q":
                console.print("\n[bold cyan]👋 Até logo![/bold cyan]")
                break
                
            elif choice == "1":
                self.clear_screen()
                self.display_header()
                
                pipeline_name = self.display_pipelines_table()
                
                if pipeline_name:
                    self.clear_screen()
                    self.display_header()
                    
                    if self.display_pipeline_info(pipeline_name):
                        console.print()
                        confirm = Confirm.ask(
                            f"[green]Executar pipeline '{pipeline_name}'? (Enter=Sim, Ctrl+C=Não)[/green]",
                            default=True
                        )
                        
                        if confirm:
                            # Ask for execution options
                            console.print()
                            parallel = Confirm.ask(
                                "[cyan]Usar paralelização? (Enter=Sim, Ctrl+C=Não)[/cyan]",
                                default=True
                            )
                            show_progress = Confirm.ask(
                                "[cyan]Mostrar progresso detalhado? (Enter=Sim, Ctrl+C=Não)[/cyan]",
                                default=True
                            )
                            
                            self.run_pipeline_with_progress(
                                pipeline_name, 
                                parallelize=parallel, 
                                progress=show_progress
                            )
                            
                            console.print()
                            Prompt.ask("[dim]Pressione Enter para continuar...[/dim]")
                            
            elif choice == "2":
                self.clear_screen()
                self.display_header()
                self.display_results_menu()
    
    def run_pipeline_direct(self, pipeline_name: str, parallelize: bool = True, progress: bool = True):
        """Run pipeline directly (non-interactive mode)."""
        self.clear_screen()
        self.display_header()
        
        # Validate pipeline exists
        pipelines = self.get_pipelines()
        available_names = [p[0] for p in pipelines]

        try:
            validate_pipeline_exists(pipeline_name, self.PIPELINES_FOLDER)
        except FileNotFoundError:
            console.print(f"[red]❌ Pipeline não encontrada: {pipeline_name}[/red]")
            console.print(f"[dim]Disponíveis: {', '.join(available_names) or 'Nenhuma'}[/dim]")
            sys.exit(1)
        
        self.display_pipeline_info(pipeline_name)
        console.print()
        
        success = self.run_pipeline_with_progress(pipeline_name, parallelize, progress)
        sys.exit(0 if success else 1)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog="python -m infobr.data.elt",
        description="InfoBR ELT Pipeline CLI - Gerencie pipelines de extração de dados financeiros",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos:
  python -m infobr.data.elt                           # Modo interativo TUI
  python -m infobr.data.elt -p series.extract.full    # Executar pipeline diretamente
  python -m infobr.data.elt -l                        # Listar pipelines disponíveis
  python -m infobr.data.elt -p teste --no-parallel    # Executar sem paralelização
        """
    )
    
    parser.add_argument(
        "-p", "--pipeline",
        metavar="NAME",
        help="Nome da pipeline para executar (modo direto)"
    )
    
    parser.add_argument(
        "-l", "--list",
        action="store_true",
        help="Listar todas as pipelines disponíveis"
    )
    
    parser.add_argument(
        "--no-parallel",
        action="store_true",
        help="Desativar paralelização na execução"
    )
    
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Desativar exibição de progresso"
    )
    
    parser.add_argument(
        "-v", "--version",
        action="version",
        version="%(prog)s 2.0.0"
    )
    
    args = parser.parse_args()
    
    tui = ELT_TUI()
    
    if args.list:
        # List mode
        tui.clear_screen()
        tui.display_header()
        pipelines = tui.get_pipelines()
        
        if pipelines:
            table = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
            table.add_column("#", width=4, justify="center")
            table.add_column("Nome", style="green")
            table.add_column("Caminho", style="dim")
            
            for idx, (name, path) in enumerate(pipelines, 1):
                table.add_row(str(idx), name, path)
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(pipelines)} pipeline(s)[/dim]")
        else:
            console.print("[yellow]Nenhuma pipeline encontrada.[/yellow]")
        
    elif args.pipeline:
        # Direct execution mode
        tui.run_pipeline_direct(
            args.pipeline,
            parallelize=not args.no_parallel,
            progress=not args.no_progress
        )
    else:
        # Interactive TUI mode
        tui.run_interactive()


if __name__ == "__main__":
    main()
