import os
import pandas as pd
import duckdb as ddb
import yfinance as yf

from typing import List, Tuple, Optional
from datetime import datetime, timedelta

from infobr import logger


def get_prices(ticker: str, start_date: str, end_date: str) -> Optional[pd.DataFrame]:
    """
    Retrieve historical price data for a given ticker symbol within a date range.

    Args:
        ticker: The ticker symbol to retrieve prices for
        start_date: Start date in 'YYYY-MM-DD' format
        end_date: End date in 'YYYY-MM-DD' format

    Returns:
        DataFrame with date, close and adjusted close prices, or None if retrieval fails
    """
    logger.info(f"Getting prices for {ticker} from {start_date} to {end_date}")

    def add_one_day(input_date: str) -> str:
        """Add one day to the provided date string."""
        date_obj = datetime.strptime(input_date, "%Y-%m-%d") + timedelta(days=1)
        return date_obj.strftime("%Y-%m-%d")

    try:
        xend_date = add_one_day(end_date)
        logger.debug(f"Using end date +1 day: {xend_date}")

        data = yf.download(ticker, start=start_date, end=xend_date)

        data["Date"] = data.index
        data = data[["Date", "Close", "Adj Close"]].copy()
        data.reset_index(inplace=True, drop=True)

        logger.info(f"Retrieved {len(data)} price records for {ticker}")
        return data
    except Exception as e:
        logger.error(f"Failed to get prices for {ticker}: {str(e)}")
        return None


def get_price(
    price_date: str, prices: List[Tuple[str, Tuple[float, float]]]
) -> Tuple[Optional[str], Optional[float], Optional[float]]:
    """
    Get the most recent price data for a given date from a list of price tuples.

    Args:
        price_date: Date string to find the price for
        prices: List of tuples containing (date_string, (price, adj_price))

    Returns:
        Tuple containing (date_string, price, adjusted_price) or (None, None, None) if not found
    """
    logger.debug("Getting price for date: {price_date}")
    p = sorted([z for z in prices if z[0] <= price_date], reverse=True)
    if p:
        logger.debug("Found price: {p[0]}")
        return p[0][0], p[0][1][0], p[0][1][1]
    else:
        logger.warning(f"No price found for date: {price_date}")
        return None, None, None


def write_stock_data(st_data: pd.DataFrame, fx_data_path: str) -> str:
    """
    Writes the Stock data to CSV files organized by ticker.

    Args:
        st_data: DataFrame containing stock data
        fx_data_path: Directory path where CSV files will be stored

    Returns:
        storage_path or None if no data written
    """
    logger.info(f"Writing stock data with {len(st_data)} rows to {fx_data_path}")

    if not os.path.exists(fx_data_path):
        logger.info(f"Creating directory: {fx_data_path}")
        os.makedirs(fx_data_path, exist_ok=True)

    _ = ddb.register("st_data", st_data)

    summary_query = """
    select "Ticker", 
            min("Date") as "MinDate", 
            max("Date") as "MaxDate",
            max("Reference_Date") as "Reference_Date",
            sum(1) as "Records"
    from st_data
    group by "Ticker"
    """

    summary_results = ddb.sql(summary_query).to_df()
    logger.debug("Found {len(summary_results)} unique tickers")

    storage_path = None
    for r in summary_results.to_dict(orient="records"):
        _ticker = r["Ticker"].upper()
        _min_date = str(r["MinDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _max_date = str(r["MaxDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _ref_date = (
            str(r["Reference_Date"]).replace("T", " ").split(" ")[0].replace("-", "")
        )
        _records = r["Records"]

        storage_file = f"STOCK_DAILY_{_ticker}_{_min_date}_{_max_date}_V{_ref_date}.csv"
        storage_path = os.path.sep.join([fx_data_path, storage_file])

        # selects all data from st_data for the given ticker and dates
        query = f"""
        select *
        from st_data
        where "Ticker" = '{_ticker}'
        and ("Date" >= '{r["MinDate"]}' and "Date" <= '{r["MaxDate"]}')
        order by "Date" desc
        """

        logger.debug("Executing query for {_ticker}")
        ddb.sql(query).to_df().to_csv(storage_path, index=False, sep=";")
        logger.info(f"Wrote {_records} records to {storage_path}")

    return storage_path


def write_fx_data(fx_data: pd.DataFrame, fx_data_path: str) -> str:
    """
    Writes the Foreign Exchange (FX) data to CSV files organized by currency pairs.

    Args:
        fx_data: DataFrame containing FX data
        fx_data_path: Directory path where CSV files will be stored

    Returns:
        storage_path or None if no data written
    """
    logger.info(f"Writing FX data with {len(fx_data)} rows to {fx_data_path}")

    if not os.path.exists(fx_data_path):
        logger.info(f"Creating directory: {fx_data_path}")
        os.makedirs(fx_data_path, exist_ok=True)

    _ = ddb.register("fx_data", fx_data)

    summary_query = """
    select "From", 
            "To", 
            min("Date") as "MinDate", 
            max("Date") as "MaxDate",
            max("Reference_Date") as "Reference_Date",
            sum(1) as "Records"
    from fx_data
    group by "From", "To"
    """

    summary_results = ddb.sql(summary_query).to_df()
    logger.debug("Found {len(summary_results)} unique currency pairs")

    storage_path = None
    for r in summary_results.to_dict(orient="records"):
        _from = r["From"].upper()
        _to = r["To"].upper()
        _min_date = str(r["MinDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _max_date = str(r["MaxDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _ref_date = (
            str(r["Reference_Date"]).replace("T", " ").split(" ")[0].replace("-", "")
        )
        _records = r["Records"]

        storage_file = (
            f"FX_DAILY_{_from}_{_to}_{_min_date}_{_max_date}_V{_ref_date}.csv"
        )
        storage_path = os.path.sep.join([fx_data_path, storage_file])

        # selects all data from fx_data for the given currency pair and dates
        query = f"""
        select *
        from fx_data
        where "From" = '{_from}'
        and "To" = '{_to}'
        and ("Date" >= '{r["MinDate"]}' and "Date" <= '{r["MaxDate"]}')
        order by "Date" desc
        """

        logger.debug("Executing query for {_from}/{_to}")
        ddb.sql(query).to_df().to_csv(storage_path, index=False, sep=";")
        logger.info(f"Wrote {_records} records to {storage_path}")

    return storage_path


def write_dividend_data(div_data: pd.DataFrame, dividend_data_path: str) -> str:
    """
    Writes the Dividend data to CSV files organized by ticker.

    Args:
        div_data: DataFrame containing dividend data
        dividend_data_path: Directory path where CSV files will be stored

    Returns:
        storage_path or None if no data written
    """
    logger.info(
        f"Writing dividend data with {len(div_data)} rows to {dividend_data_path}"
    )

    if not os.path.exists(dividend_data_path):
        logger.info(f"Creating directory: {dividend_data_path}")
        os.makedirs(dividend_data_path, exist_ok=True)

    _ = ddb.register("div_data", div_data)

    summary_query = """
    with t as (
    select * from div_data where CAST("Pay_Date" AS STRING) <> '' 
    )
    select "Ticker", 
            "Payout_Frequency",
            min("Pay_Date") as "MinDate", 
            max("Pay_Date") as "MaxDate",
            max("Reference_Date") as "Reference_Date",
            sum(1) as "Records"
    from t
    group by "Ticker",
            "Payout_Frequency"
    """

    summary_results = ddb.sql(summary_query).to_df()
    logger.debug("Found {len(summary_results)} unique tickers with dividends")

    storage_path = None
    for r in summary_results.to_dict(orient="records"):
        _ticker = r["Ticker"].upper()
        _frequency = r["Payout_Frequency"].upper()
        _min_date = str(r["MinDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _max_date = str(r["MaxDate"]).replace("T", " ").split(" ")[0].replace("-", "")
        _ref_date = (
            str(r["Reference_Date"]).replace("T", " ").split(" ")[0].replace("-", "")
        )
        _records = r["Records"]

        storage_file = (
            f"DIVIDEND_{_ticker}_{_frequency}_{_min_date}_{_max_date}_V{_ref_date}.csv"
        )
        storage_path = os.path.sep.join([dividend_data_path, storage_file])

        # selects all data from div_data for the given ticker and dates
        query = f"""
        select *
        from div_data
        where upper("Ticker") = '{_ticker}'
        and "Payout_Frequency" = '{r["Payout_Frequency"]}'
        and ("Pay_Date" >= '{r["MinDate"]}' and "Pay_Date" <= '{r["MaxDate"]}')
        order by "Pay_Date" desc
        """

        logger.debug("Executing dividend query for {_ticker}")
        ddb.sql(query).to_df().to_csv(storage_path, index=False, sep=";")
        logger.info(f"Wrote {_records} dividend records to {storage_path}")

    return storage_path
