import os
import pandas as pd
from datetime import datetime
from typing import List, Dict, Any, Tuple
from fbpyutils import file as fu

from infobr import env, logger
from infobr.data import DataProvider
from infobr.data.tools import DataTools
from infobr.data.providers import write_stock_data
from fbpyutils_ai.llm import OpenAILLMService


_CURRENCY_BASE_URL = (
    "https://investing.com/currencies/{currency_from}-{currency_to}-historical-data"
)


def _currency_fast_extract(
    currency_from: str, currency_to: str, context: str
) -> pd.DataFrame:
    """
    Retrieve currency exchange rate data from markdown content between the table header and 'Highest:'.

    Args:
        currency_from (str): The base currency code (e.g., 'USD').
        currency_to (str): The target currency code (e.g., 'BRL').
        context (str): Raw markdown content containing the historical data table.

    Returns:
        pd.DataFrame: DataFrame with columns:
            - "From": Source currency (string)
            - "To": Target currency (string)
            - "Date": Trading date (datetime)
            - "Open": Opening price (float)
            - "High": Highest price (float)
            - "Low": Lowest price (float)
            - "Close": Closing price (float)
            - "Reference_Date": Date of data extraction (datetime)
    """
    # Define the table header to look for
    expected_header = "| Date | Price | Open | High | Low | Vol. | Change % |"

    # Split the markdown content into lines
    lines = context.split("\n")

    # Find the start of the table (header line)
    try:
        header_index = lines.index(expected_header)
    except ValueError:
        # If header isn’t found, return an empty DataFrame
        return pd.DataFrame(
            columns=[
                "From",
                "To",
                "Date",
                "Open",
                "High",
                "Low",
                "Close",
                "Reference_Date",
            ]
        )

    # Find the end of the table (line with "Highest:")
    try:
        end_index = next(
            i
            for i, line in enumerate(lines[header_index:], start=header_index)
            if "Highest:" in line
        )
    except StopIteration:
        # If "Highest:" isn’t found, use the end of the content
        end_index = len(lines)

    # Extract lines between the header and "Highest:", skipping the header itself
    table_lines = lines[header_index + 1 : end_index]

    # Filter out the separator line (e.g., "| --- | --- | ...") and empty lines
    data_lines = [
        line
        for line in table_lines
        if not line.strip().startswith("|---") and line.strip()
    ]

    # If there are no data lines, return an empty DataFrame
    if not data_lines:
        return pd.DataFrame(
            columns=[
                "From",
                "To",
                "Date",
                "Open",
                "High",
                "Low",
                "Close",
                "Reference_Date",
            ]
        )

    # Define the column names from the header
    columns = [col.strip() for col in expected_header.split("|") if col.strip()]

    # Parse each data row into a list of values
    data = []
    for line in data_lines[1:]:
        row = [col.strip() for col in line.split("|")][1:-1]
        if len(row) == len(columns):  # Ensure the row matches the header’s column count
            data.append(row)

    # Create a DataFrame from the parsed data
    df = pd.DataFrame(data, columns=columns)

    # Select and rename the relevant columns
    df = df[["Date", "Price", "Open", "High", "Low"]].rename(columns={"Price": "Close"})

    # Convert 'Date' to datetime format
    df["Date"] = pd.to_datetime(df["Date"], format="mixed", errors="coerce")

    # Convert numerical columns to floats
    for col in ["Open", "High", "Low", "Close"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Add the currency and reference date columns
    df["From"] = currency_from
    df["To"] = currency_to
    df["Reference_Date"] = datetime.now()

    # Reorder columns to match the desired output
    return df[["From", "To", "Date", "Open", "High", "Low", "Close", "Reference_Date"]]


def write_stock_data_from_source_history(
    history_folder: str, storage_folder: str
) -> None:
    """
    Process stock history CSV files and write structured data to storage folder.

    This function reads all CSV files in the history folder, parses them to extract
    stock data including ticker symbol, date, price information, and volume.
    The processed data is then written to the storage folder.

    Args:
        history_folder: Directory containing the source CSV history files
        storage_folder: Directory where processed stock data will be saved

    Returns:
        None
    """
    logger.info(f"Processing stock history files from {history_folder}")
    stock_history_files = fu.find(history_folder, "*.csv")
    logger.debug(f"Found {len(stock_history_files)} CSV files")

    stock_data: List[Tuple] = []
    for stock_history_file in stock_history_files:
        logger.debug(f"Processing file: {stock_history_file}")

        symbol = stock_history_file.split(os.path.sep)[-1].split(" ")[0].strip().upper()
        logger.info(f"Extracting data for symbol: {symbol}")

        stock_columns = [
            "Ticker",
            "Date",
            "Open",
            "High",
            "Low",
            "Close",
            "Volume",
            "Reference_Date",
        ]
        reference_date = fu.creation_date(stock_history_file)

        try:
            df = pd.read_csv(stock_history_file, sep=",", header=0, encoding="utf-8")
            logger.debug(f"Loaded {len(df)} records from file")

            for line in df.to_dict(orient="records"):
                vol = str(line["Vol."])
                if vol == "nan":
                    volume = 0
                else:
                    vol_unit = vol[-1]
                    if vol_unit == "K":
                        volume = float(vol[:-1]) * 1000
                    elif vol_unit == "M":
                        volume = float(vol[:-1]) * 1000000
                    elif vol_unit == "B":
                        volume = float(vol[:-1]) * 1000000000
                    else:
                        volume = float(vol[:-1])

                try:
                    data = (
                        symbol,
                        datetime.strptime(line["Date"], "%m/%d/%Y").date(),
                        line["Open"],
                        line["High"],
                        line["Low"],
                        line["Price"],
                        int(volume),
                        reference_date.date(),
                    )
                    stock_data.append(data)
                except (ValueError, KeyError) as e:
                    logger.warning(f"Error processing record for {symbol}: {str(e)}")
                    continue

        except Exception as e:
            logger.error(f"Failed to process {stock_history_file}: {str(e)}")
            continue

    logger.info(f"Processed {len(stock_data)} stock data records in total")
    df = pd.DataFrame(stock_data, columns=stock_columns)
    write_stock_data(df, storage_folder)


class InvestingCurrencyDataProvider(DataProvider):
    """
    Data provider for currency exchange rates from Investing.com.

    This provider uses LLM-based extraction to retrieve historical currency
    exchange rate data from Investing.com website.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - currency_from: Source currency code (e.g., 'USD', 'BRL', 'EUR')
            - currency_to: Target currency code
            - llm: (optional) LLM model name to use for extraction. If not provided, the fast scrape method will be used.
            - timeout (optional): Request timeout in milliseconds
            - tries (optional): Number of extraction attempts before failing (default: 3)
            - verbose_mode (optional): Enable verbose logging (default: False)
    """

    EXPECTED_PARAMS = {
        "llm": (str, False, None),
        "currency_from": (str, True, None),
        "currency_to": (str, True, None),
        "timeout": (int, False, 6000),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve currency exchange rate data from Investing.com.

        Uses an LLM to extract structured data from the Investing.com website
        for the specified currency pair.

        Returns:
            pd.DataFrame: DataFrame containing currency exchange rate data:
            {
                "From": { "type": "string" },
                "To": { "type": "string" },
                "Date": { "type": "string", "format": "date-time" },
                "Open": { "type": "number" },
                "High": { "type": "number" },
                "Low": { "type": "number" },
                "Close": { "type": "number" },
                "Reference_Date": { "type": "string", "format": "date-time" }
            }

        Raises:
            ValueError: If data extraction fails
        """
        # Get parameters with defaults
        timeout = self.params.get("timeout", 30000)
        if timeout < 0:
            logger.warning(f"Invalid timeout value: {timeout}, using default 30000")
            timeout = 30000

        # Get number of extraction attempts
        tries = self.params.get("tries", 3)
        if tries < 1:
            logger.warning(f"Invalid tries value: {tries}, using default 3")
            tries = 3

        currency_from = self.params["currency_from"]
        currency_to = self.params["currency_to"]
        verbose_mode = self.params.get("verbose_mode", False)

        logger.info(f"Fetching exchange rate data for {currency_from}/{currency_to}")

        url = _CURRENCY_BASE_URL.format(
            currency_from=currency_from.lower(), currency_to=currency_to.lower()
        )
        logger.debug(f"Using URL: {url}")

        llm_name = self.params.get("llm")

        data = pd.DataFrame()
        try:
            scrape_result = DataTools.scrape_url(url, timeout=timeout)
            context = scrape_result["data"]["markdown"]
            kind = "FX"
            info = f"the currency exchange rate data ({currency_from}->{currency_to})"

            if not llm_name:
                logger.info("Using fast context extraction.")
                data = _currency_fast_extract(currency_from, currency_to, context)
                return data
            else:
                logger.info("Using LLM-Extraction.")
                # Set up LLM service

                # Get number of extraction attempts
                tries = self.params.get("tries", 3)
                if tries < 1:
                    logger.warning(f"Invalid tries value: {tries}, using default 3")
                    tries = 3

                logger.debug(f"Using model: {llm_name}")

                _, model, api_base, api_key, _, _ = env.resolve_model(llm_name)

                llm = OpenAILLMService(
                    model=model, api_key=api_key, api_base=api_base, timeout=timeout
                )

                logger.info(
                    f"Extracting data using LLM from {url} with {tries} max attempts"
                )
                json_data = DataTools.llm_data_extract(
                    llm,
                    info,
                    context,
                    timeout=timeout,
                    kind="FX",
                    tries=tries,
                    verbose_mode=verbose_mode,
                    stream=True,
                )

                data = pd.DataFrame.from_dict(json_data)

            data = DataTools.apply_schema(data, DataTools.DATA_SCHEMAS[kind])
            logger.info(f"Successfully extracted {len(data)} records")

            return data

        except Exception as e:
            logger.error(f"Failed to extract currency data: {str(e)}")
            raise
