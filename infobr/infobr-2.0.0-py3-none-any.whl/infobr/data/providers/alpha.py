import requests
import pandas as pd
from datetime import datetime
from typing import Dict, Any, List, Optional

from infobr import logger
from infobr.data import DataProvider


class RateLimitException(Exception):
    """
    Exception raised when Alpha Vantage API rate limit is exceeded.

    Attributes:
        message: Explanation of the error
    """

    def __init__(self, message: Optional[str] = None) -> None:
        """
        Initialize the RateLimitException with a custom message.

        Args:
            message: Custom error message. If None, a default message is used.
        """
        self.message = message or "Rate limit exceeded. Please try again later."
        logger.warning(f"Alpha Vantage rate limit exceeded: {self.message}")
        super().__init__(self.message)


class AlphaVantageStockDataProvider(DataProvider):
    """
    Data provider for stock data from Alpha Vantage API.

    This provider retrieves historical daily stock price data including
    open, high, low, close prices and volume for a specified stock symbol.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - api_key: Alpha Vantage API key
            - symbol: Stock ticker symbol
            - outputsize (optional): 'compact' (last 100 data points) or 'full' (up to 20 years)
    """

    def _check_params(self, params: Dict[str, Any]) -> bool:
        """
        Validate the provided parameters for the stock data provider.

        Args:
            params: Dictionary of configuration parameters

        Returns:
            bool: True if parameters are valid, False otherwise
        """
        valid_outputsizes = ("compact", "full")
        required_params = ("api_key", "symbol")

        is_valid = (
            all([p in params for p in required_params])
            and params.get("outputsize", "full") in valid_outputsizes
        )

        if not is_valid:
            missing_params = [p for p in required_params if p not in params]
            if missing_params:
                logger.error(
                    f"Missing required parameters: {', '.join(missing_params)}",
                )

            invalid_outputsize = (
                params.get("outputsize") not in valid_outputsizes
                if "outputsize" in params
                else False
            )
            if invalid_outputsize:
                logger.error(
                    f"Invalid outputsize: {params.get('outputsize')}. Must be one of {valid_outputsizes}",
                )

        return is_valid

    def __init__(self, params: Dict[str, Any]) -> None:
        """
        Initialize the Alpha Vantage stock data provider.

        Args:
            params: Dictionary of configuration parameters

        Raises:
            ValueError: If parameters are invalid
        """
        logger.debug(
            f"Initializing AlphaVantageStockDataProvider with symbol: {params.get('symbol', 'unknown')}",
        )
        super().__init__(params)

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve historical daily stock price data from Alpha Vantage.

        Returns:
            pd.DataFrame: DataFrame containing stock price data with columns:
                Ticker, Date, Open, High, Low, Close, Volume, Reference_Date

        Raises:
            RateLimitException: If Alpha Vantage API rate limit is exceeded
            Exception: If any error occurs during data retrieval or processing
        """
        alpha_function = "TIME_SERIES_DAILY"
        outputsize = self.params.get("outputsize", "compact")
        if outputsize not in ("compact", "full"):
            logger.warning(
                f"Invalid outputsize value: {outputsize}, using 'compact'",
            )
            outputsize = "compact"

        symbol = self.params["symbol"]
        api_key = self.params["api_key"]

        url = f"https://www.alphavantage.co/query?function={alpha_function}&symbol={symbol}&outputsize={outputsize}&apikey={api_key}"
        logger.info(
            f"Fetching stock data for symbol: {symbol} with outputsize: {outputsize}",
        )

        try:
            # Hide API key from logs
            safe_url = url.replace(api_key, "***REDACTED***")
            logger.debug(f"Making API request to: {safe_url}")
            r = requests.get(url)
            data = r.json()
            logger.debug(f"Received response with status code: {r.status_code}")

            if "Information" in data.keys():
                error_msg = f"{data['Information']}"
                logger.warning(
                    f"Rate limit information from Alpha Vantage: {error_msg}",
                )
                raise RateLimitException(error_msg)

            if "Error Message" in data.keys():
                error_msg = f"{data['Error Message']}"
                logger.error(f"Error message from Alpha Vantage: {error_msg}")
                raise Exception(f"Alpha Vantage API error: {error_msg}")

            # Extracting metadata and time series data
            metadata_key, data_key = data.keys()
            metadata, time_series_data = data[metadata_key], data[data_key]
            logger.debug(
                f"Retrieved metadata for {symbol}, last refreshed: {metadata.get('3. Last Refreshed', 'unknown')}",
            )
            logger.info(
                f"Retrieved {len(time_series_data)} data points for {symbol}",
            )

            # Process each data point in the time series
            series: List[Dict[str, Any]] = []
            for date_str in time_series_data.keys():
                try:
                    serie = time_series_data[date_str].copy()
                    # Convert string values to float
                    for key in serie.keys():
                        serie[key] = float(serie[key])

                    # Add date and symbol information
                    serie["date"] = datetime.strptime(date_str, "%Y-%m-%d")
                    serie["symbol"] = metadata["2. Symbol"]
                    series.append(serie)
                except (ValueError, KeyError) as e:
                    logger.warning(
                        f"Error processing data point for date {date_str}: {str(e)}",
                    )
                    continue

            logger.info(
                f"Successfully processed {len(series)} data points for {symbol}",
            )

            # Convert to DataFrame and format columns
            df = pd.DataFrame(series)
            df["reference_date"] = pd.to_datetime(metadata["3. Last Refreshed"]).date()

            # Rename columns to standard format
            df.columns = [
                "Open",
                "High",
                "Low",
                "Close",
                "Volume",
                "Date",
                "Ticker",
                "Reference_Date",
            ]

            # Reorder columns to have Ticker and Date first
            result_df = (
                df[
                    ["Ticker", "Date"]
                    + [col for col in df if col not in ["Ticker", "Date"]]
                ]
                .copy()
                .reset_index(drop=True)
            )

            logger.info(
                f"Returning DataFrame with {len(result_df)} rows for {symbol}",
            )
            return result_df

        except RateLimitException:
            # Re-raise rate limit exceptions
            raise
        except Exception as e:
            error_msg = f"Error retrieving data from Alpha Vantage: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)


class AlphaVantageCurrencyDataProvider(DataProvider):
    """
    Data provider for currency exchange rates from Alpha Vantage API.

    This provider retrieves historical daily foreign exchange (FX) data including
    open, high, low, close rates for a specified currency pair.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - api_key: Alpha Vantage API key
            - currency_from: Source currency code (e.g., 'USD')
            - currency_to: Target currency code (e.g., 'EUR')
            - outputsize (optional): 'compact' (last 100 data points) or 'full' (up to 20 years)
    """

    EXPECTED_PARAMS = {
        "api_key": (str, True, None),
        "currency_from": (str, True, None),
        "currency_to": (str, True, None),
        "outputsize": (str, False, "compact"),
        "timeout": (int, False, 6000),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve historical daily foreign exchange data from Alpha Vantage.

        Returns:
            pd.DataFrame: DataFrame containing currency exchange data with columns:
                From, To, Date, Open, High, Low, Close, Reference_Date

        Raises:
            RateLimitException: If Alpha Vantage API rate limit is exceeded
            Exception: If any error occurs during data retrieval or processing
        """
        alpha_function = "FX_DAILY"

        currency_from = self.params["currency_from"]
        currency_to = self.params["currency_to"]
        outputsize = self.params.get("outputsize", "compact")

        if outputsize not in ("compact", "full"):
            logger.warning(
                f"Invalid outputsize value: {outputsize}, using 'compact'",
            )
            outputsize = "compact"

        api_key = self.params["api_key"]

        url = f"https://www.alphavantage.co/query?function={alpha_function}&from_symbol={currency_from}&to_symbol={currency_to}&apikey={api_key}&outputsize={outputsize}"
        logger.info(
            f"Fetching currency data for pair: {currency_from}/{currency_to} with outputsize: {outputsize}",
        )

        try:
            # Hide API key from logs
            safe_url = url.replace(api_key, "***REDACTED***")
            logger.debug(f"Making API request to: {safe_url}")
            r = requests.get(url)
            data = r.json()
            logger.debug(f"Received response with status code: {r.status_code}")

            if "Information" in data.keys():
                error_msg = f"{data['Information']}"
                logger.warning(
                    f"Rate limit information from Alpha Vantage: {error_msg}",
                )
                raise RateLimitException(error_msg)

            if "Error Message" in data.keys():
                error_msg = f"{data['Error Message']}"
                logger.error(f"Error message from Alpha Vantage: {error_msg}")
                raise Exception(f"Alpha Vantage API error: {error_msg}")

            # Extracting metadata and time series data
            metadata_key, data_key = data.keys()
            metadata, time_series_data = data[metadata_key], data[data_key]
            logger.debug(
                f"Retrieved metadata for {currency_from}/{currency_to}, last refreshed: {metadata.get('5. Last Refreshed', 'unknown')}",
            )
            logger.info(
                f"Retrieved {len(time_series_data)} data points for {currency_from}/{currency_to}",
            )

            # Process each data point in the time series
            series: List[Dict[str, Any]] = []
            for date_str in time_series_data.keys():
                try:
                    serie = time_series_data[date_str].copy()
                    # Convert string values to float
                    for key in serie.keys():
                        serie[key] = float(serie[key])

                    # Add date and currency pair information
                    serie["date"] = datetime.strptime(date_str, "%Y-%m-%d")
                    serie["from"] = metadata["2. From Symbol"]
                    serie["to"] = metadata["3. To Symbol"]
                    serie["reference"] = metadata["5. Last Refreshed"]
                    series.append(serie)
                except (ValueError, KeyError) as e:
                    logger.warning(
                        f"Error processing data point for date {date_str}: {str(e)}",
                    )
                    continue

            logger.info(
                f"Successfully processed {len(series)} data points for {currency_from}/{currency_to}",
            )

            # Convert to DataFrame and format columns
            df = pd.DataFrame(series)

            # Rename columns to standard format
            df.columns = [
                "Open",
                "High",
                "Low",
                "Close",
                "Date",
                "From",
                "To",
                "Reference_Date",
            ]

            # Reorder columns to have From, To, and Date first
            result_df = (
                df[
                    ["From", "To", "Date"]
                    + [col for col in df if col not in ["From", "To", "Date"]]
                ]
                .copy()
                .reset_index(drop=True)
            )

            logger.info(
                f"Returning DataFrame with {len(result_df)} rows for {currency_from}/{currency_to}",
            )
            return result_df

        except RateLimitException:
            # Re-raise rate limit exceptions
            raise
        except Exception as e:
            error_msg = f"Error retrieving data from Alpha Vantage: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)
