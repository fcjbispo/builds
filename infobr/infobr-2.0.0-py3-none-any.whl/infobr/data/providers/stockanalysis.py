import pandas as pd
from datetime import datetime
from typing import Dict, Any

from fbpyutils import file as fu
import duckdb as ddb
import os

from infobr import env, logger
from infobr.data import DataProvider
from infobr.data.tools import DataTools
from fbpyutils_ai.llm import OpenAILLMService


# URL templates for different data types
_SITE_BASE_URL = "https://stockanalysis.com/{kind}/{ticker}"
_HISTORY_BASE_URL = f"{_SITE_BASE_URL}/history/"
_DIVIDEND_BASE_URL = f"{_SITE_BASE_URL}/dividend/"


def _stock_fast_extract(ticker: str, context: str) -> pd.DataFrame:
    """
    Extract stock price history data from raw markdown content and return it as a Pandas DataFrame.

    Args:
        ticker: The stock ticker symbol
        context: Raw markdown content containing stock price history

    Returns:
        pd.DataFrame: DataFrame containing stock price history with columns:
        {
            "Ticker": { "type": "string" },
            "Date": { "type": "string", "format": "date-time" },
            "Open": { "type": "number" },
            "High": { "type": "number" },
            "Low": { "type": "number" },
            "Close": { "type": "number" },
            "Volume": { "type": "number" },
            "Reference_Date": { "type": "string", "format": "date-time" }
        }
    """
    logger.info(f"Extracting stock price data for {ticker}")

    # Extract and filter content lines containing stock data
    content = [d for d in context.split("\n") if d.startswith("|") if "---" not in d]
    logger.debug(f"Found {len(content)} stock data rows")

    if not content:
        logger.warning(f"No stock data found for {ticker}")
        return pd.DataFrame()

    # Parse header and data rows
    header = [c.strip() for c in content[0].split("|") if c]
    data = [[d.strip() for d in d.split("|") if d] for d in content[1:]]

    # Define transformation functions for each column
    transforms = {
        "Date": DataTools.us_string_to_date,
        "Open": DataTools.as_float,
        "High": DataTools.as_float,
        "Low": DataTools.as_float,
        "Close": DataTools.as_float,
        "Volume": lambda x: DataTools.as_float(x.replace(",", "")),
        "Adj. Close": str,  # We'll skip this column in final output
        "Change": str,  # We'll skip this column in final output
    }

    # Apply transformations to the data
    xdata = [
        {k: transforms.get(k, str)(v) for k, v in d.items()}
        for d in pd.DataFrame(data, columns=header).to_dict(orient="records")
    ]

    if not xdata:
        logger.warning(f"No valid stock data found for {ticker}")
        return pd.DataFrame()

    now = datetime.now()

    # Enrich each record with ticker and reference date
    for x in xdata:
        x["Ticker"] = ticker
        x["Reference_Date"] = now

    # Create DataFrame
    transformed_data = pd.DataFrame.from_dict(data=xdata)

    # Select and order columns for the final result
    result = transformed_data[
        ["Ticker", "Date", "Open", "High", "Low", "Close", "Volume", "Reference_Date"]
    ].copy()

    logger.info(f"Extracted {len(result)} stock price records for {ticker}")
    return result


def _dividend_fast_extract(
    ticker: str, context: str, compute_frequency: bool = False
) -> pd.DataFrame:
    """
    Extract dividend data from the raw markdown context and enrich it with price information.

    This function processes the raw markdown data extracted from a website, parses the dividend
    information and return as Pandas DataFrame.

    Args:
        ticker: The stock ticker symbol
        context: Raw markdown content containing dividend information
        compute_frequency: Whether to compute the payout frequency of the dividends (default: False)

    Returns:
        DataFrame containing structured dividend data
        {
            "Ticker": { "type": "string" },
            "Payout_Frequency": { "type": "string" },
            "Ex_Dividend_Date": { "type": "string", "format": "date-time" },
            "Cash_Amount": { "type": "number" },
            "Record_Date": { "type": "string", "format": "date-time" },
            "Pay_Date": { "type": "string", "format": "date-time" },
            "Reference_Date": { "type": "string", "format": "date-time" }
        }
    """
    logger.info(f"Extracting dividend data for {ticker}")

    # Extract and filter content lines containing dividend data
    content = [
        d
        for d in context.split("\n")
        if d.startswith("|")
        if "---" not in d and "n/a" not in d
    ]
    logger.debug(f"Found {len(content)} dividend data rows")

    # Parse header and data rows
    header = [c.strip() for c in content[0].split("|") if c]
    data = [[d.strip() for d in d.split("|") if d] for d in content[1:]]

    # Define transformation functions for each column
    transforms = {
        k: DataTools.us_string_to_date
        if "Date" in k
        else DataTools.as_float
        if k == "Cash Amount"
        else str
        for k in header
    }

    # Apply transformations to the data
    xdata = [
        {k: transforms[k](v) for k, v in d.items()}
        for d in pd.DataFrame(data, columns=header).to_dict(orient="records")
    ]
    xdates = [d["Pay Date"] for d in xdata if d["Pay Date"]]

    if not xdates:
        logger.warning(f"No valid pay dates found for {ticker}")
        return pd.DataFrame()

    now = datetime.now()

    # Enrich each dividend record with price and yield information
    for x in xdata:
        # Add ticker and reference date
        x["Ticker"] = ticker
        x["Reference Date"] = now

    # Create DataFrame
    transformed_data = pd.DataFrame.from_dict(data=xdata)
    renamed_columns = [
        c.replace(" ", "_").replace("-", "_") for c in transformed_data.columns
    ]
    transformed_data.columns = renamed_columns

    # Compute Frequency
    if "Payout_Frequency" not in transformed_data.columns or compute_frequency:
        frequency = DataTools.date_frequency(
            [d for d in transformed_data["Pay_Date"].to_list() if d]
        )
        transformed_data["Payout_Frequency"] = frequency

    # Select and order columns for the final result
    result = transformed_data[
        [
            "Ticker",
            "Payout_Frequency",
            "Ex_Dividend_Date",
            "Cash_Amount",
            "Record_Date",
            "Pay_Date",
            "Reference_Date",
        ]
    ].copy()

    logger.info(f"Extracted {len(result)} dividend records for {ticker}")
    return result


class StockAnalysisDividendDataProvider(DataProvider):
    """
    Data provider for dividend information from Nasdaq/StockAnalysis.com.

    This provider retrieves and processes dividend data for a specified stock ticker
    using markdown scrape (fast) or LLM-based extraction from StockAnalysis.com.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - ticker: Stock ticker symbol
            - asset_type: Asset type ('stocks' or 'etf')
            - llm: (optional) LLM model name to use for extraction. If not provided, the fast scrape method will be used.
            - timeout (optional): Request timeout in milliseconds
            - tries (optional): Number of extraction attempts before failing (default: 3)
            - verbose_mode (optional): Enable verbose logging (default: False)
            - compute_frequency (optional): Whether to compute the payout frequency of the dividends (default: True)
    """

    EXPECTED_PARAMS = {
        "llm": (str, False, None),
        "ticker": (str, True, None),
        "asset_type": (str, True, None),
        "verbose_mode": (bool, False, False),
        "tries": (int, False, 3),
        "timeout": (int, False, 6000),
        "compute_frequency": (bool, False, True),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve dividend data from StockAnalysis.com.

        Uses an LLM to extract structured dividend data from the website
        for the specified ticker, and enriches it with yield calculations.

        Returns:
            pd.DataFrame: DataFrame containing dividend data with columns:
            {
                "Ticker": { "type": "string" },
                "Payout_Frequency": { "type": "string" },
                "Ex_Dividend_Date": { "type": "string", "format": "date-time" },
                "Cash_Amount": { "type": "number" },
                "Record_Date": { "type": "string", "format": "date-time" },
                "Pay_Date": { "type": "string", "format": "date-time" },
                "Reference_Date": { "type": "string", "format": "date-time" }
            }

        Raises:
            ValueError: If data extraction fails
        """
        # Get parameters with defaults
        timeout = self.params.get("timeout", 30000)
        if timeout < 0:
            logger.warning(f"Invalid timeout value: {timeout}, using default 30000")
            timeout = 30000

        llm_name = self.params.get("llm")
        ticker = self.params["ticker"]
        asset_type = self.params["asset_type"]
        verbose_mode = self.params.get("verbose_mode", False)
        compute_frequency = self.params.get("compute_frequency", True)

        logger.info(f"Fetching dividend data for {asset_type}/{ticker}")

        url = _DIVIDEND_BASE_URL.format(ticker=ticker, kind=asset_type)
        logger.debug(f"Grabbing context using URL: {url}")

        data = pd.DataFrame()
        try:
            scrape_result = DataTools.scrape_url(url, timeout=timeout)
            context = scrape_result["data"]["markdown"]
            kind = "DIVIDEND"

            info = f"the dividend payments data for {ticker}"

            if not llm_name:
                logger.info("Using fast context extraction.")
                data = _dividend_fast_extract(
                    ticker, context, compute_frequency=compute_frequency
                )
            else:
                logger.info("Using LLM-Extraction.")
                # Set up LLM service

                # Get number of extraction attempts
                tries = self.params.get("tries", 3)
                if tries < 1:
                    logger.warning(f"Invalid tries value: {tries}, using default 3")
                    tries = 3

                logger.debug(f"Using model: {llm_name}")

                _, model, api_base, api_key, _, _ = env.resolve_model(llm_name)

                llm = OpenAILLMService(
                    model=model, api_key=api_key, api_base=api_base, timeout=timeout
                )

                logger.info(
                    f"Extracting dividend data using LLM from {url} with {tries} max attempts"
                )
                # The 'kind' parameter for DataTools.llm_data_extract is fixed to 'DIVIDEND' for this provider
                json_data = DataTools.llm_data_extract(
                    llm,
                    info,
                    context,
                    timeout=timeout,
                    kind=kind,
                    tries=tries,
                    verbose_mode=verbose_mode,
                    stream=True,
                )

                data = pd.DataFrame.from_dict(json_data)

            data = DataTools.apply_schema(data, DataTools.DATA_SCHEMAS[kind])
            logger.info(f"Successfully extracted {len(data)} dividend records")

            if compute_frequency:
                # frequency = DataTools.date_frequency([datetime.strptime(d, '%Y-%m-%d') for d in data['Pay_Date'].to_list() if d])
                frequency = DataTools.date_frequency(
                    [d for d in data["Pay_Date"].to_list() if d]
                )
                data["Payout_Frequency"] = frequency

            return data
        except Exception as e:
            logger.error(f"Failed to extract dividend data: {str(e)}")
            raise


class StockAnalysisStockDataProvider(DataProvider):
    """
    Data provider for stock price history from Nasdaq/StockAnalysis.com.

    This provider retrieves historical stock price data for a specified stock ticker
    using LLM-based extraction from StockAnalysis.com.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - ticker: Stock ticker symbol
            - asset_type: Asset type ('stocks' or 'etf')
            - llm: (optional) LLM model name to use for extraction. If not provided, the fast scrape method will be used.
            - timeout (optional): Request timeout in milliseconds
            - tries (optional): Number of extraction attempts before failing (default: 3)
            - verbose_mode (optional): Enable verbose logging (default: False)
    """

    EXPECTED_PARAMS = {
        "llm": (str, False, None),
        "ticker": (str, True, None),
        "asset_type": (str, True, None),
        "verbose_mode": (bool, False, False),
        "tries": (int, False, 3),
        "timeout": (int, False, 6000),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve historical stock price data from StockAnalysis.com.

        Uses an LLM to extract structured price history data from the website
        for the specified ticker.

        Returns:
            pd.DataFrame: DataFrame containing stock price history with columns:
            {
                "Ticker": { "type": "string" },
                "Date": { "type": "string", "format": "date-time" },
                "Open": { "type": "number" },
                "High": { "type": "number" },
                "Low": { "type": "number" },
                "Close": { "type": "number" },
                "Volume": { "type": "number" },
                "Reference_Date": { "type": "string", "format": "date-time" }
            }

        Raises:
            ValueError: If data extraction fails
        """
        # Get parameters with defaults
        timeout = self.params.get("timeout", 30000)
        if timeout < 0:
            logger.warning(f"Invalid timeout value: {timeout}, using default 30000")
            timeout = 30000

        llm_name = self.params.get("llm")
        ticker = self.params["ticker"]
        asset_type = self.params["asset_type"]
        verbose_mode = self.params.get("verbose_mode", False)
        kind = "STOCK"

        logger.info(f"Fetching stock history for {asset_type}/{ticker}")

        url = _HISTORY_BASE_URL.format(ticker=ticker, kind=asset_type)
        logger.debug(f"Grabbing context using URL: {url}")

        data = pd.DataFrame()
        try:
            scrape_result = DataTools.scrape_url(url, timeout=timeout)
            context = scrape_result["data"]["markdown"]

            info = f"the historical price data for {ticker}"
            if not llm_name:
                logger.info("Using fast context extraction.")
                data = _stock_fast_extract(ticker, context)
            else:
                # Get number of extraction attempts
                tries = self.params.get("tries", 3)
                if tries < 1:
                    logger.warning(f"Invalid tries value: {tries}, using default 3")
                    tries = 3

                # Set up LLM service
                logger.debug(f"Using model: {llm_name}")

                _, model, api_base, api_key, _, _ = env.resolve_model(llm_name)

                llm = OpenAILLMService(
                    model=model, api_key=api_key, api_base=api_base, timeout=timeout
                )

                logger.info(
                    f"Extracting stock history using LLM from {url} with {tries} max attempts"
                )
                # The 'kind' parameter for DataTools.llm_data_extract is fixed to 'STOCK' for this provider
                json_data = DataTools.llm_data_extract(
                    llm,
                    url,
                    info,
                    timeout=timeout,
                    kind=kind,
                    tries=tries,
                    verbose_mode=verbose_mode,
                    stream=True,
                )

                data = pd.DataFrame.from_dict(json_data)

            data = DataTools.apply_schema(data, DataTools.DATA_SCHEMAS[kind])
            logger.info(f"Successfully extracted {len(data)} price records")

            return data

        except Exception as e:
            logger.error(f"Failed to extract stock history data: {str(e)}")
            raise
