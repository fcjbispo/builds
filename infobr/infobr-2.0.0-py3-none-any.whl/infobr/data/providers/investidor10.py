import time

import pandas as pd
from datetime import datetime
from typing import Dict, Any

from infobr import env, logger
from infobr.data import DataProvider
from infobr.data.tools import DataTools
from fbpyutils_ai.llm import OpenAILLMService


import os
from fbpyutils import file as fu
import duckdb as ddb


_STOCK_SITE_BASE_URL = "https://investidor10.com.br/fiis/{ticker}/"


def _transform(data: pd.DataFrame, compute_frequency: bool = True) -> pd.DataFrame:
    result = data[["FUNDO", "DATA COM", "PAGAMENTO", "VALOR", "DATA REFERENCIA"]]

    map = {
        "Ticker": {"type": "string", "map": "FUNDO"},
        "Payout_Frequency": {"type": "string", "map": None},
        "Ex_Dividend_Date": {
            "type": "string",
            "format": "date-time",
            "map": "DATA COM",
        },
        "Cash_Amount": {"type": "number", "map": "VALOR"},
        "Record_Date": {"type": "string", "format": "date-time", "map": None},
        "Pay_Date": {"type": "string", "format": "date-time", "map": "PAGAMENTO"},
        "Reference_Date": {
            "type": "string",
            "format": "date-time",
            "map": "DATA REFERENCIA",
        },
    }

    data = result.rename(
        columns={v["map"]: k for k, v in map.items() if v["map"] is not None}
    ).copy()

    if compute_frequency:
        dates = [d for d in data["Pay_Date"]]
        freq = DataTools.date_frequency(dates)
        data["Payout_Frequency"] = freq
    data["Record_Date"] = data["Ex_Dividend_Date"]

    return data[[k for k in map.keys() if k in data.columns]].copy()


def _dividend_fast_extract(
    ticker: str, context: str, compute_frequency: bool = True
) -> pd.DataFrame:
    """
    Extract dividend data from the raw markdown context and enrich it with price information.

    This function processes the raw markdown data extracted from the Investidor10 website, parses
    the dividend information, calculates yields based on historical prices.

    Args:
        ticker: The real estate fund ticker symbol
        context: Raw markdown content containing dividend information

    Returns:
        DataFrame containing structured dividend data
        {
            "Ticker": { "type": "string" },
            "Payout_Frequency": { "type": "string" },
            "Ex_Dividend_Date": { "type": "string", "format": "date-time" },
            "Cash_Amount": { "type": "number" },
            "Record_Date": { "type": "string", "format": "date-time" },
            "Pay_Date": { "type": "string", "format": "date-time" },
            "Reference_Date": { "type": "string", "format": "date-time" }
        }
    """
    header = ["INFO", "DATA COM", "PAGAMENTO", "VALOR"]
    try:
        data = [
            d
            for d in [
                d.split("|")[1:-1]
                for d in [
                    c.replace(" ", "") for c in context.split("\n") if "Dividendos" in c
                ]
            ]
            if len(d) == 4
        ]
        logger.debug(f"Found {len(data)} dividend data rows for {ticker}")

        transformers = {
            k: DataTools.br_string_to_date
            if k in ("DATA COM", "PAGAMENTO")
            else DataTools.br_string_to_float
            if k == "VALOR"
            else str
            for k in header
        }

        xdata = [
            {k: transformers[k](v) for k, v in d.items()}
            for d in pd.DataFrame(data, columns=header).to_dict(orient="records")
        ]

        now = datetime.now()

        for x in xdata:
            # Add ticker and reference date
            x["FUNDO"] = ticker
            x["DATA REFERENCIA"] = now

        data = pd.DataFrame.from_dict(data=xdata)

        logger.info(f"Extracted {len(data)} dividend records for {ticker}")
        return _transform(data, compute_frequency=compute_frequency)
    except Exception as e:
        logger.error(f"Error extracting dividend data for {ticker}: {e}")
        raise


class Inv10DividendDataProvider(DataProvider):
    """
    Data provider for dividend information from Investidor10 for Brazilian real estate funds.

    This provider retrieves and processes dividend data for specified real estate funds (FIIs)
    using LLM-based extraction from Investidor10 website.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - ticker: Fund ticker symbol
            - llm: (optional) LLM model name to use for extraction. If not provided, the fast scrape method will be used.
            - timeout (optional): Request timeout in milliseconds
            - tries (optional): Number of extraction attempts before failing (default: 3)
            - verbose_mode (optional): Enable verbose logging (default: False)
            - compute_frequency (optional): Whether to compute the payout frequency of the dividends (default: True)
    """

    EXPECTED_PARAMS = {
        "llm": (str, False, None),
        "ticker": (str, True, None),
        "timeout": (int, False, 30000),
        "tries": (int, False, 5),
        "verbose": (bool, False, False),
        "compute_frequency": (bool, False, True),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve dividend data for Brazilian real estate funds from Investidor10.

        Uses an LLM to extract structured dividend data from the website
        for the specified ticker, and enriches it with yield calculations.

        Returns:
            DataFrame containing structured dividend data
            {
                "Ticker": { "type": "string" },
                "Payout_Frequency": { "type": "string" },
                "Ex_Dividend_Date": { "type": "string", "format": "date-time" },
                "Cash_Amount": { "type": "number" },
                "Record_Date": { "type": "string", "format": "date-time" },
                "Pay_Date": { "type": "string", "format": "date-time" },
                "Reference_Date": { "type": "string", "format": "date-time" }
            }

        Raises:
            ValueError: If data extraction fails
        """
        # Get parameters with defaults
        timeout = self.params.get("timeout", 30000)
        if timeout < 0:
            logger.warning(f"Invalid timeout value: {timeout}, using default 30000")
            timeout = 30000

        # Get number of extraction attempts
        tries = self.params.get("tries", 3)
        if tries < 1:
            logger.warning(f"Invalid tries value: {tries}, using default 3")
            tries = 3

        llm_name = self.params["llm"]
        ticker = self.params["ticker"]
        verbose_mode = self.params.get("verbose", False)
        compute_frequency = self.params.get("compute_frequency", True)

        logger.info(f"Fetching dividend data for FII {ticker}")

        url = _STOCK_SITE_BASE_URL.format(ticker=ticker)
        logger.debug(f"Using URL: {url}")

        data = pd.DataFrame()
        scrape_result = None
        last_exception = None
        
        # Retry com backoff exponencial para rate limiting
        for attempt in range(1, tries + 1):
            try:
                logger.debug(f"Scrape attempt {attempt}/{tries} for {ticker}")
                scrape_result = DataTools.scrape_url(url, timeout=timeout)
                break  # Sucesso, sai do loop
            except ValueError as e:
                error_msg = str(e)
                last_exception = e
                # Verificar se é erro de rate limit (HTTP 429)
                if "429" in error_msg or "rate limit" in error_msg.lower():
                    if attempt < tries:
                        # Backoff exponencial com jitter: 4s, 8s, 16s, 32s...
                        wait_time = min(2 ** (attempt + 1), 60)  # Max 60s
                        logger.warning(
                            f"Rate limit (HTTP 429) on attempt {attempt}/{tries} for {ticker}. "
                            f"Waiting {wait_time}s before retry..."
                        )
                        time.sleep(wait_time)
                    else:
                        logger.error(f"Rate limit persists after {tries} attempts for {ticker}")
                        raise
                else:
                    # Outros erros ValueError (como 404, 500, etc)
                    if attempt < tries:
                        wait_time = 2 ** attempt  # 2s, 4s, 8s...
                        logger.warning(
                            f"Error on attempt {attempt}/{tries} for {ticker}: {error_msg}. "
                            f"Waiting {wait_time}s before retry..."
                        )
                        time.sleep(wait_time)
                    else:
                        raise
            except Exception as e:
                last_exception = e
                if attempt < tries:
                    wait_time = 2 ** attempt  # 2s, 4s, 8s...
                    logger.warning(
                        f"Unexpected error on attempt {attempt}/{tries} for {ticker}: {str(e)}. "
                        f"Waiting {wait_time}s before retry..."
                    )
                    time.sleep(wait_time)
                else:
                    raise
        
        if scrape_result is None:
            raise ValueError(f"Failed to scrape {ticker} after {tries} attempts: {str(last_exception)}")
        
        try:
            context = scrape_result["data"]["markdown"]
            kind = "DIVIDEND"

            info = (
                f"the dividend payment data for the Brazilian real estate fund {ticker}"
            )

            if not llm_name:
                logger.info("Using fast context extraction.")
                data = _dividend_fast_extract(
                    ticker, context, compute_frequency=compute_frequency
                )
            else:
                # Set up LLM service
                logger.debug(f"Using model: {llm_name}")

                _, model, api_base, api_key, _, _ = env.resolve_model(llm_name)

                llm = OpenAILLMService(
                    model=model, api_key=api_key, api_base=api_base, timeout=timeout
                )

                # Define schema mapping instructions
                schema_instructions = """
                Map the extracted data to the following fields:
                - Ticker: The fund ticker symbol (same as input)
                - Payout_Frequency: Fixed value "MONTHLY" as Brazilian FIIs typically pay monthly
                - Ex_Dividend_Date: The field "DATA COM" (ex-dividend date)
                - Cash_Amount: The field "VALOR" (dividend amount)
                - Record_Date: Same as Ex_Dividend_Date
                - Pay_Date: The field "PAGAMENTO" (payment date)
                - Reference_Date: Current date
                """

                info_with_schema = f"{info}. {schema_instructions}"

                logger.info(
                    f"Extracting dividend data using LLM from {url} with {tries} max attempts"
                )
                # The 'kind' parameter for DataTools.llm_data_extract is fixed to 'DIVIDEND' for this provider
                data = DataTools.llm_data_extract(
                    llm,
                    url,
                    info_with_schema,
                    timeout=timeout,
                    kind=kind,
                    tries=tries,
                    verbose_mode=verbose_mode,
                )
                logger.info(f"Successfully extracted {len(data)} dividend records")

            return data
        except Exception as e:
            logger.error(f"Failed to extract dividend data: {str(e)}")
            raise
