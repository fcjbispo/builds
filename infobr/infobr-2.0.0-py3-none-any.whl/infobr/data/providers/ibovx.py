import pandas as pd
from io import StringIO
from datetime import datetime
import re
import locale
from typing import Dict, Any

from infobr import env, logger
from infobr.data import DataProvider
from infobr.data.tools import DataTools
from fbpyutils_ai.llm import OpenAILLMService


# URL template for B3 stock data
_STOCK_SITE_BASE_URL = (
    "https://ibovx.com.br/historico-papeis-bovespa.aspx?papel={ticker_lower}"
)


def _stock_fast_extract(ticker: str, context: str) -> pd.DataFrame:
    """
    Extrai dados de cotações históricas de um papel a partir de um conteúdo markdown
    e retorna um DataFrame do Pandas com a estrutura especificada.

    Args:
        ticker (str): O ticker do papel (ex.: 'FESA4').
        context (str): O conteúdo markdown contendo as tabelas de cotações.

    Returns:
        pd.DataFrame: DataFrame com as colunas Ticker, Date, Open, High, Low, Close,
                      Volume e Reference_Date. Retorna um DataFrame vazio em caso de erro.
    """
    try:
        # Procurar a tabela no contexto usando regex
        pattern = r"Date,Open,High,Low,Close,Volume\n(.*?)(?:\n\n|$)"
        match = re.search(pattern, context, re.DOTALL)

        if not match:
            logger.warning(
                "Tabela CSV não encontrada no contexto. Verificando se o markdown contém 'Date,Open,High,Low,Close,Volume'."
            )
            return pd.DataFrame()

        # Extrair o texto da tabela, incluindo o cabeçalho
        table_text = "Date,Open,High,Low,Close,Volume\n" + match.group(1).strip()

        # Tentar ler o CSV
        try:
            df = pd.read_csv(StringIO(table_text), sep=",")
        except Exception as e:
            logger.error(
                f"Erro ao ler a tabela CSV: {str(e)}. Verificar o formato dos dados extraídos."
            )
            return pd.DataFrame()

        # Verificar se a coluna 'Date' está presente
        if "Date" not in df.columns:
            logger.warning(
                "A coluna 'Date' não foi encontrada no DataFrame. Verificar o cabeçalho da tabela."
            )
            return pd.DataFrame()

        # Limpar espaços extras nas strings de data
        df["Date"] = df["Date"].str.strip()

        # Definir o locale para inglês para garantir que as abreviações dos meses sejam reconhecidas
        current_locale = locale.getlocale()
        try:
            locale.setlocale(locale.LC_TIME, "en_US.UTF-8")
        except locale.Error:
            try:
                locale.setlocale(locale.LC_TIME, "C")
            except Exception:
                logger.warning(
                    "Não foi possível configurar o locale para leitura de datas"
                )

        try:
            # Converter a coluna 'Date' para datetime com errors='coerce'
            df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y", errors="coerce")

            # Adicionar a coluna 'Ticker'
            df["Ticker"] = ticker

            # Adicionar a coluna 'Reference_Date' com a data atual
            reference_date = datetime.now().strftime("%Y-%m-%d")
            df["Reference_Date"] = reference_date

            # Reordenar as colunas
            df = df[
                [
                    "Ticker",
                    "Date",
                    "Open",
                    "High",
                    "Low",
                    "Close",
                    "Volume",
                    "Reference_Date",
                ]
            ]

            logger.info(
                f"Extração rápida bem-sucedida: {len(df)} registros para {ticker}"
            )
            return df
        finally:
            # Restaurar o locale original
            try:
                locale.setlocale(locale.LC_ALL, current_locale)
            except Exception:
                pass
    except Exception as e:
        logger.error(f"Erro durante a extração rápida para {ticker}: {str(e)}")
        return pd.DataFrame()


class IBovxStockDataProvider(DataProvider):
    """
    Data provider for stock price history from IBovx.com.br.

    This provider retrieves historical stock price data for a specified B3 stock ticker
    using fast scrape or LLM-based extraction from IBovx.com.br.

    Attributes:
        params (Dict[str, Any]): Configuration parameters including:
            - ticker: Stock ticker symbol (B3 format, e.g., 'FESA4')
            - llm: (optional) LLM model name to use for extraction. If not provided, the fast scrape method will be used.
            - timeout (optional): Request timeout in milliseconds
            - tries (optional): Number of extraction attempts before failing (default: 3)
            - verbose_mode (optional): Enable verbose logging (default: False)
    """

    EXPECTED_PARAMS = {
        "llm": (str, False, None),
        "ticker": (str, False, None),
        "timeout": (int, False, 6000),
    }

    def get_data(self) -> pd.DataFrame:
        """
        Retrieve historical stock price data from IBovx.com.br.

        Uses fast scrape or LLM-based extraction to get structured price history data
        from the website for the specified B3 ticker.

        Returns:
            pd.DataFrame: DataFrame containing stock price history with columns, or an empty
            DataFrame if extraction fails:
            {
                "Ticker": { "type": "string" },
                "Date": { "type": "string", "format": "date-time" },
                "Open": { "type": "number" },
                "High": { "type": "number" },
                "Low": { "type": "number" },
                "Close": { "type": "number" },
                "Volume": { "type": "number" },
                "Reference_Date": { "type": "string", "format": "date-time" }
            }
        """
        # Get parameters with defaults
        timeout = self.params.get("timeout", 30000)
        if timeout < 0:
            logger.warning(f"Invalid timeout value: {timeout}, using default 30000")
            timeout = 30000

        llm_name = self.params.get("llm")
        ticker = self.params["ticker"]
        verbose_mode = self.params.get("verbose_mode", False)
        kind = "STOCK"

        logger.info(f"Fetching stock history for B3/{ticker}")

        # Prepare URL with lowercase ticker as required by IBovx
        ticker_lower = ticker.lower()
        url = _STOCK_SITE_BASE_URL.format(ticker_lower=ticker_lower)
        logger.debug(f"Grabbing context using URL: {url}")

        data = pd.DataFrame()
        try:
            scrape_result = DataTools.scrape_url(url, timeout=timeout)
            context = scrape_result["data"]["markdown"]

            info = f"the historical price data for {ticker} from B3 (Brazil)"
            if not llm_name:
                logger.info("Using fast context extraction.")
                data = _stock_fast_extract(ticker, context)
            else:
                # Get number of extraction attempts
                tries = self.params.get("tries", 3)
                if tries < 1:
                    logger.warning(f"Invalid tries value: {tries}, using default 3")
                    tries = 3

                # Set up LLM service
                logger.debug(f"Using model: {llm_name}")

                _, model, api_base, api_key, _, provider = env.resolve_model(llm_name)

                llm = OpenAILLMService(
                    model=model, api_key=api_key, api_base=api_base, timeout=timeout
                )

                logger.info(
                    f"Extracting stock history using LLM from {url} with {tries} max attempts"
                )
                # The 'kind' parameter for DataTools.llm_data_extract is fixed to 'STOCK' for this provider
                json_data = DataTools.llm_data_extract(
                    llm=llm,
                    provider=provider,
                    info=info,
                    context=context,
                    tries=tries,
                    kind=kind,
                    verbose_mode=verbose_mode,
                    stream=True,
                )

                data = pd.DataFrame.from_dict(json_data)

            data = DataTools.apply_schema(data, DataTools.DATA_SCHEMAS[kind])
            logger.info(f"Successfully extracted {len(data)} price records")

            return data

        except Exception as e:
            error_message = (
                f"Failed to extract stock history data for {ticker}: {str(e)}"
            )
            logger.error(error_message)

            # Return an empty DataFrame with the correct schema
            empty_df = pd.DataFrame(
                columns=[
                    "Ticker",
                    "Date",
                    "Open",
                    "High",
                    "Low",
                    "Close",
                    "Volume",
                    "Reference_Date",
                ]
            )

            # Apply schema to ensure proper column types
            try:
                empty_df = DataTools.apply_schema(
                    empty_df, DataTools.DATA_SCHEMAS[kind]
                )
            except Exception as schema_error:
                logger.warning(
                    f"Could not apply schema to empty DataFrame: {str(schema_error)}"
                )

                logger.info("Returning empty DataFrame due to extraction error")
            return empty_df
