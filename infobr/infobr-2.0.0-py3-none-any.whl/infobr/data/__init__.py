from typing import List, Any, Tuple, Union, Dict
import pandas as pd


from infobr import logger

from abc import ABC, abstractmethod


class BaseData(ABC):
    """
    Abstract base class for data handling.
    Attributes:
        params (dict): A dictionary of parameters used to configure the data provider.
        EXPECTED_PARAMS (dict): A dictionary of expected parameters where keys are parameter names
                                 and values are tuples of (type, is_required).
    """

    EXPECTED_PARAMS: Dict[str, Tuple[Any, bool, Any]] = {}

    def __init__(self, params: dict) -> None:
        self.params = params
        if not self._check_params(params):
            raise ValueError(f"Invalid params: {params}")
        super().__init__()

    def _check_params(self, params: dict) -> bool:
        logger.debug(f"Checking parameters: {params}")

        # Verificar parâmetros obrigatórios
        required_params = {
            name for name, (_, required, _) in self.EXPECTED_PARAMS.items() if required
        }
        missing_params = required_params - set(params.keys())

        if missing_params:
            logger.error(
                f"Missing required parameters: {', '.join(missing_params)}. "
                f"Required: {', '.join(required_params)}, Got: {list(params.keys())}"
            )
            return False

        # Verificar tipos de dados
        for param_name, param_value in params.items():
            expected_type, required, _ = self.EXPECTED_PARAMS[param_name]

            valid = (
                expected_type is type(param_value)
                if required
                else True
                if type(param_value) == type(None)
                else expected_type is type(param_value)
            )

            if not valid:
                logger.error(
                    f"Invalid type for parameter '{param_name}'. "
                    f"Expected {expected_type.__name__}, got {type(param_value).__name__}"
                )
                logger.debug(
                    f"who: {self}, expected: {self.EXPECTED_PARAMS}, valid: {valid}, "
                    f"param: {param_name}, param_value {param_value}, param_type: {type(param_value).__name__}, "
                    f"expected_type:{expected_type.__name__}"
                )
                return False
        return True


class DataProvider(BaseData):
    """
    Abstract base class for data providers.

    This class defines the basic structure and behavior of a data provider,
    including initialization with a set of parameters and methods for checking
    parameter validity and retrieving data.

    """

    @abstractmethod
    def get_data(self) -> pd.DataFrame:
        """
        Retrieves data from the provider.
        """
        pass


class DataProcessor(BaseData):
    """
    Abstract base class for data processors.

    This class defines the basic structure and behavior of a data processor, for use in data extraction/transformation/loading (ETL) pipelines.
    """

    @abstractmethod
    def run(self) -> Tuple[str, bool, Union[str, None], Union[pd.DataFrame, None]]:
        """
        Executes the processing for a given parameter.
        Return scope, success, error_message, data
        """
        pass


class DataProviderProcessor(DataProvider, DataProcessor):
    """
    A combined interface for data providers and processors.
    """

    @abstractmethod
    def get_data(self) -> pd.DataFrame:
        """
        Retrieves data from the provider.
        """
        pass

    @abstractmethod
    def run() -> Tuple[str, bool, Union[str, None], Union[pd.DataFrame, None]]:
        """
        Executes the processing for a given parameter.
        """
        pass
