# %%
from abc import ABC
import os
import random
import pandas as pd
import polars as pl

from infobr import logger, env
from infobr.data import DataProcessor
from infobr.data.providers import write_stock_data, write_dividend_data, write_fx_data
from infobr.data.providers.stockanalysis import (
    StockAnalysisStockDataProvider,
    StockAnalysisDividendDataProvider,
)
from infobr.data.providers.investidor10 import Inv10DividendDataProvider
from infobr.data.providers.ibovx import IBovxStockDataProvider
from infobr.data.providers.investing import InvestingCurrencyDataProvider
from infobr.data.providers.alpha import AlphaVantageCurrencyDataProvider
from infobr.data.process import ProcessWithCallback

from typing import Tuple, Union, Optional, Callable, List
from fbpyutils import file as F
from jsonschema import validate, ValidationError
from fbpyutils_db.hashing.hash_index import add_hash_index
from fbpyutils_db.database.operations import table_operation
from infobr.data.tools import DataTools


# %%
class Series(ABC):
    FII_DIVIDENDS = "FIIs Dividends"
    FII_PRICES = "FIIs Prices"
    ETF_DIVIDENDS = "ETFs Dividends"
    ETF_PRICES = "ETFs Prices"
    FX_HISTORY = "FX History"


class SeriesExtractDataProcessor(DataProcessor):
    EXPECTED_PARAMS = {
        "storage_folder": (str, True, None),
        "scopes": (list, False, []),
        "llm": (str, False, None),
        "timeout": (int, False, 30000),
        "wait": (int, False, 10),
        "verbose_mode": (bool, False, False),
        "tries": (int, False, 5),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
    }

    @staticmethod
    def _sanitize_params(params: dict) -> dict:
        """
        Sanitize sensitive parameters before logging or saving to results.
        Masks api_key and other sensitive fields.
        """
        if not isinstance(params, dict):
            return params
        
        sanitized = params.copy()
        # Mask sensitive fields
        sensitive_keys = ['api_key', 'apikey', 'key', 'token', 'password', 'secret']
        for key in sanitized.keys():
            if any(sensitive in key.lower() for sensitive in sensitive_keys):
                if sanitized[key]:
                    sanitized[key] = "***REDACTED***"
        return sanitized

    @staticmethod
    def process_provider_runner(
        scope, provider, storage_folder, storage_sub_folders, writer, provider_param
    ):
        records = 0
        success = False
        error_message = None
        output_file_path = None
        try:
            provider_instance = provider(provider_param)

            data = provider_instance.get_data()

            if isinstance(data, pd.DataFrame):
                records = len(data)
                storage_path = os.path.sep.join([storage_folder] + storage_sub_folders)
                if not os.path.exists(storage_path):
                    os.makedirs(storage_path, exist_ok=True)
                output_file_path = writer(data, storage_path)
                success = True
            else:
                logger.warning(
                    f"{scope}: Could not get data for this scope: {type(data)}"
                )
        except Exception as e:
            error_message = str(e)
            logger.debug(f"f:process_provider_runner")
            # Log sanitized params to avoid exposing sensitive data
            safe_params = SeriesExtractDataProcessor._sanitize_params(provider_param)
            logger.error(f"Error {e} on processing {scope}: {safe_params}")

        # Use sanitized params in return data to avoid exposing sensitive info
        safe_return_params = SeriesExtractDataProcessor._sanitize_params(provider_param)
        return_data = pd.DataFrame(
            [
                {
                    "params": safe_return_params,
                    "output_file_path": output_file_path,
                    "records": records,
                }
            ]
        )
        return [scope, success, error_message, return_data]

    @staticmethod
    def process_extractor_runner(scope, scope_params):
        try:
            params = scope_params["params"]
            series = scope_params["series"]

            process_provider_params = []
            for param in params:
                provider = param["provider"]
                storage_folder = param["storage_folder"]
                sub_folders = param["sub_folders"]
                writer = param["writer"]
                parallelize = param["parallelize"]
                progress = param["progress"]
                wait = param["wait"]

                for serie in series:
                    # Start with default values from EXPECTED_PARAMS
                    process_provider_param = {
                        k: v[2] for k, v in provider.EXPECTED_PARAMS.items()
                    }
                    # Override with values from param dict (pipeline-level params)
                    for key in provider.EXPECTED_PARAMS:
                        if key in param and param[key] is not None:
                            process_provider_param[key] = param[key]
                    # Finally override with serie-specific values (e.g., ticker)
                    process_provider_param |= serie

                    process_provider_params.append(
                        (
                            scope,
                            provider,
                            storage_folder,
                            sub_folders,
                            writer,
                            process_provider_param,
                        )
                    )
                break

            if process_provider_params:
                process_provider = ProcessWithCallback(
                    process=SeriesExtractDataProcessor.process_provider_runner,
                    parallelize=parallelize,
                    workers=ProcessWithCallback.get_available_cpu_count() if parallelize else 1,
                    sleeptime=wait,
                    progress_callback=scope_params.get("progress_callback"),
                )

                return process_provider.run(process_provider_params, progress=progress)
            else:
                raise ValueError("No params found for {scope}.")
        except Exception as e:
            logger.debug(f"f:process_extractor_runner")
            logger.error(f"Error {e} on processing {scope}: {scope_params}.")
            return [scope, False, str(e), None]

    def _build_extraction_params(self):
        storage_folder = self.params["storage_folder"]
        scopes = self.params.get("scopes", [])

        fii_list = [
            {"ticker": t["ticker"]}
            for t in pl.read_database(
                """
                select ticker
                from infobr.ativos 
                where tipo = 'fii' and ativo = 1
                order by ticker
                """,
                env.DB,
            ).to_dicts()
        ]
        random.shuffle(fii_list)  # Aleatorizar ordem para evitar padrão previsível

        etf_list = [
            {"ticker": e["ticker"], "asset_type": e["tipo"]}
            for e in pl.read_database(
                """
                select ticker, tipo
                from infobr.ativos 
                where tipo = 'etf' and ativo = 1
                order by ticker
                """,
                env.DB,
            ).to_dicts()
        ]
        random.shuffle(etf_list)  # Aleatorizar ordem para evitar padrão previsível

        fx_list = [
            {
                "api_key": os.getenv(
                    "ALPHA_VANTAGE_API_KEY",
                    env.USER_CONFIG.get("ALPHA_VANTAGE_API_KEY"),
                ),
                "currency_from": currency_from,
                "currency_to": currency_to,
            }
            for currency_from, currency_to in [
                fx["ticker"].split(":")
                for fx in pl.read_database(
                    """
                    select ticker
                    from infobr.ativos 
                    where tipo = 'fx' and ativo = 1
                    order by ticker
                    """,
                    env.DB,
                ).to_dicts()
            ]
        ]
        random.shuffle(fx_list)  # Aleatorizar ordem para evitar padrão previsível

        params = {
            Series.FII_DIVIDENDS: {
                "params": (
                    {
                        "provider": Inv10DividendDataProvider,
                        "sub_folders": ["DIVIDEND", "BR"],
                        "parallelize": False,
                        "progress": True,
                        "writer": write_dividend_data,
                        "llm": self.params.get("llm"),
                        "timeout": self.params.get("timeout"),
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                ),
                "series": fii_list,
            },
            Series.FII_PRICES: {
                "params": (
                    {
                        "provider": IBovxStockDataProvider,
                        "sub_folders": ["STOCK", "BR"],
                        "parallelize": False,
                        "progress": True,
                        "writer": write_stock_data,
                        "llm": self.params.get("llm"),
                        "timeout": self.params.get("timeout"),
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                ),
                "series": fii_list,
            },
            Series.ETF_DIVIDENDS: {
                "params": (
                    {
                        "provider": StockAnalysisDividendDataProvider,
                        "sub_folders": ["DIVIDEND", "US"],
                        "llm": self.params.get("llm"),
                        "timeout": self.params.get("timeout"),
                        "tries": self.params.get("tries"),
                        "verbose_mode": self.params.get("verbose_mode"),
                        "parallelize": False,
                        "progress": True,
                        "writer": write_dividend_data,
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                ),
                "series": etf_list,
            },
            Series.ETF_PRICES: {
                "params": (
                    {
                        "provider": StockAnalysisStockDataProvider,
                        "sub_folders": ["STOCK", "US"],
                        "llm": self.params.get("llm"),
                        "timeout": self.params.get("timeout"),
                        "tries": self.params.get("tries"),
                        "verbose_mode": self.params.get("verbose_mode"),
                        "parallelize": False,
                        "progress": True,
                        "writer": write_stock_data,
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                ),
                "series": etf_list,
            },
            Series.FX_HISTORY: {
                "params": (
                    {
                        "timeout": self.params.get("timeout"),
                        "provider": AlphaVantageCurrencyDataProvider,
                        "sub_folders": ["FX"],
                        "parallelize": False,
                        "progress": True,
                        "writer": write_fx_data,
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                    {
                        "provider": InvestingCurrencyDataProvider,
                        "sub_folders": ["FX"],
                        "llm": self.params.get("llm"),
                        "timeout": self.params.get("timeout"),
                        "parallelize": False,
                        "progress": True,
                        "writer": write_fx_data,
                        "storage_folder": self.params["storage_folder"],
                        "wait": 15,
                    },
                ),
                "series": fx_list,
            },
        }

        return [(k, v) for k, v in params.items() if k in scopes or not scopes]

    def run(
        self,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Tuple[str, bool, Union[str, None], Union[pd.DataFrame, None]]:
        """
        Executes the processing for a given parameter.
        
        Args:
            progress_callback: Optional callback(current, total, status) for progress updates
        """
        extractor_process = ProcessWithCallback(
            process=SeriesExtractDataProcessor.process_extractor_runner,
            parallelize=self.params["parallelize"],
            workers=ProcessWithCallback.get_available_cpu_count()
            if self.params["parallelize"]
            else 1,
            sleeptime=self.params.get("sleeptime", 0),
        )

        progress = self.params.get("progress", False)
        params_list = self._build_extraction_params()
        
        # Enrich params with progress_callback
        if progress_callback:
            for _, scope_params in params_list:
                scope_params["progress_callback"] = progress_callback

        return extractor_process.run(params=params_list, progress=progress)


class SeriesLoadDataProcessor(DataProcessor):
    VALID_OPERATIONS = ("upsert", "append", "replace")
    DOMAIN_MAP = {
        ("STOCK", "USD"): "ACAO_US",
        ("STOCK", "BRL"): "ACAO_BR",
        ("DIVIDEND", "USD"): "DIVIDENDO_US",
        ("DIVIDEND", "BRL"): "DIVIDENDO_BR",
        ("FX", None): "CAMBIO",
    }
    EXPECTED_PARAMS = {
        "storage_folder": (str, True, None),
        "scopes": (list, False, []),
        "parallelize": (bool, False, False),
        "progress": (bool, False, False),
        "batch_size": (int, False, 10000),
        "truncate_before_load": (bool, False, False),
        "schema": (str, False, "infobr"),
        "dry_run": (bool, False, False),
        "operation": (str, False, "upsert"),
    }

    def _check_params(self, params: dict) -> bool:
        if not super()._check_params(params):
            return False
        operation = params.get("operation")
        if operation is not None and operation not in self.VALID_OPERATIONS:
            logger.error(
                f"Invalid operation '{operation}'. "
                f"Expected one of {list(self.VALID_OPERATIONS)}"
            )
            return False
        return True

    @staticmethod
    def _discover_files(
        storage_folder: str, sub_folders: list, mask: str = "*.csv"
    ) -> list:
        storage_path = os.path.sep.join([storage_folder] + sub_folders)
        if not os.path.exists(storage_path):
            logger.warning(f"Storage path not found: {storage_path}")
            return []
        return F.find(storage_path, mask, recurse=False, parallel=False)

    @staticmethod
    def _read_csv(file_path: str) -> pd.DataFrame:
        return pd.read_csv(file_path, sep=";")

    @staticmethod
    def _load_dataframe_to_db(df: pd.DataFrame, loader_param: dict) -> bool:
        """
        Placeholder for fbpyutils-db integration.

        loader_param schema:
            {
                "schema": str,                # DB schema name (e.g., "infobr")
                "target_table": str,          # Target table name (e.g., "series")
                "truncate_before_load": bool, # Whether to truncate before upsert
                "batch_size": int,            # Batch size for upsert
                "dry_run": bool,              # Skip DB writes when True
                "kind": str,                  # Source kind: "DIVIDEND" | "STOCK" | "FX"
                "operation": str              # "upsert" | "append" | "replace"
            }
        """
        schema = loader_param.get("schema", "infobr")
        table_name = loader_param.get("target_table", "series")
        operation = loader_param.get("operation", "upsert")

        schema_fields = SeriesLoadDataProcessor._get_db_schema_fields(
            schema_name=schema, table_name=table_name
        )
        key_columns = [
            field["field_name"] for field in schema_fields if field["is_key"]
        ]
        operation_keys = ["id"] if "id" in df.columns else key_columns

        return table_operation(
            operation=operation,
            dataframe=df,
            engine=env.DB,
            table_name=table_name,
            schema=schema,
            keys=operation_keys,
        )

    @staticmethod
    def _build_table_json_schema(schema_name: str, table_name: str) -> dict:
        schema_fields = SeriesLoadDataProcessor._get_db_schema_fields(
            schema_name=schema_name, table_name=table_name
        )
        properties = {}
        for field in schema_fields:
            field_name = field["field_name"]
            field_type = field["field_type"]
            if field_type in ("float", "int", "integer", "number"):
                properties[field_name] = {"type": "number"}
            elif field_type == "datetime":
                properties[field_name] = {"type": "string", "format": "date-time"}
            else:
                properties[field_name] = {"type": "string"}
        return {"type": "array", "items": {"type": "object", "properties": properties}}

    @staticmethod
    def _coerce_datetime(df: pd.DataFrame, columns: List[str], to_date: bool = True):
        for column in columns:
            if column in df.columns:
                values = pd.to_datetime(df[column], errors="coerce")
                df[column] = values.dt.date if to_date else values

    @staticmethod
    def _transform_dividend(
        df: pd.DataFrame, scope: str, currency: Optional[str] = None
    ) -> pd.DataFrame:
        result = pd.DataFrame()
        result["dominio_nome"] = SeriesLoadDataProcessor.DOMAIN_MAP.get(
            ("DIVIDEND", currency)
        )
        result["ticker"] = df.get("Ticker")
        result["frequencia_pagamento"] = df.get("Payout_Frequency")
        result["data_ex_dividendo"] = df.get("Ex_Dividend_Date")
        result["data_registro"] = df.get("Record_Date")
        result["data_pagamento"] = df.get("Pay_Date")
        result["valor_efetivo"] = pd.to_numeric(
            df.get("Cash_Amount"), errors="coerce"
        )
        result["data_referencia"] = df.get("Reference_Date")
        result["data_evento"] = df.get("Pay_Date")
        SeriesLoadDataProcessor._coerce_datetime(
            result,
            [
                "data_ex_dividendo",
                "data_registro",
                "data_pagamento",
                "data_evento",
            ],
            to_date=True,
        )
        SeriesLoadDataProcessor._coerce_datetime(
            result, ["data_referencia"], to_date=False
        )
        return result

    @staticmethod
    def _transform_stock(
        df: pd.DataFrame, scope: str, currency: Optional[str] = None
    ) -> pd.DataFrame:
        result = pd.DataFrame()
        result["dominio_nome"] = SeriesLoadDataProcessor.DOMAIN_MAP.get(
            ("STOCK", currency)
        )
        result["ticker"] = df.get("Ticker")
        result["data_acao"] = df.get("Date")
        result["abertura"] = pd.to_numeric(df.get("Open"), errors="coerce")
        result["alta"] = pd.to_numeric(df.get("High"), errors="coerce")
        result["baixa"] = pd.to_numeric(df.get("Low"), errors="coerce")
        result["fechamento"] = pd.to_numeric(df.get("Close"), errors="coerce")
        result["volume"] = pd.to_numeric(df.get("Volume"), errors="coerce")
        result["data_referencia"] = df.get("Reference_Date")
        result["data_evento"] = df.get("Date")
        SeriesLoadDataProcessor._coerce_datetime(
            result, ["data_acao", "data_evento"], to_date=True
        )
        SeriesLoadDataProcessor._coerce_datetime(
            result, ["data_referencia"], to_date=False
        )
        return result

    @staticmethod
    def _transform_fx(df: pd.DataFrame, scope: str) -> pd.DataFrame:
        result = pd.DataFrame()
        result["dominio_nome"] = SeriesLoadDataProcessor.DOMAIN_MAP.get(("FX", None))
        result["moeda_origem"] = df.get("From")
        result["moeda_destino"] = df.get("To")
        result["ticker"] = (
            df.get("From", "").astype(str).fillna("")
            + df.get("To", "").astype(str).fillna("")
        )
        result["data_cambio"] = df.get("Date")
        result["abertura"] = pd.to_numeric(df.get("Open"), errors="coerce")
        result["alta"] = pd.to_numeric(df.get("High"), errors="coerce")
        result["baixa"] = pd.to_numeric(df.get("Low"), errors="coerce")
        result["fechamento"] = pd.to_numeric(df.get("Close"), errors="coerce")
        result["data_referencia"] = df.get("Reference_Date")
        result["data_evento"] = df.get("Date")
        SeriesLoadDataProcessor._coerce_datetime(
            result, ["data_cambio", "data_evento"], to_date=True
        )
        SeriesLoadDataProcessor._coerce_datetime(
            result, ["data_referencia"], to_date=False
        )
        return result

    @staticmethod
    def _transform_df(
        kind: str, df: pd.DataFrame, scope: str, currency: Optional[str] = None
    ) -> pd.DataFrame:
        if kind == "DIVIDEND":
            return SeriesLoadDataProcessor._transform_dividend(df, scope, currency)
        if kind == "STOCK":
            return SeriesLoadDataProcessor._transform_stock(df, scope, currency)
        if kind == "FX":
            return SeriesLoadDataProcessor._transform_fx(df, scope)
        raise ValueError(f"Unknown kind: {kind}")

    @staticmethod
    def _validate_against_schema(kind: str, df: pd.DataFrame) -> List[str]:
        schema = DataTools.DATA_SCHEMAS.get(kind)
        if not schema:
            raise ValueError(f"No schema found for kind: {kind}")

        required = set(schema.get("items", {}).get("required", []))
        missing = required - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        item_schema = schema.get("items", {})
        errors: List[str] = []
        for idx, record in enumerate(df.to_dict(orient="records")):
            try:
                validate(instance=record, schema=item_schema)
            except ValidationError as e:
                errors.append(f"row {idx}: {e.message}")

        if errors:
            raise ValueError(
                f"Schema validation failed with {len(errors)} error(s). "
                f"First: {errors[0]}"
            )
        return errors

    @staticmethod
    def _normalize_df(
        df: pd.DataFrame, schema_name: str, table_name: str
    ) -> pd.DataFrame:
        schema_fields = SeriesLoadDataProcessor._get_db_schema_fields(
            schema_name=schema_name, table_name=table_name
        )
        ordered_columns = [f["field_name"] for f in schema_fields]
        for column in ordered_columns:
            if column not in df.columns:
                df[column] = None
        return df[ordered_columns].copy()

    @staticmethod
    def _add_id_column(
        df: pd.DataFrame, schema_name: str, table_name: str
    ) -> pd.DataFrame:
        schema_fields = SeriesLoadDataProcessor._get_db_schema_fields(
            schema_name=schema_name, table_name=table_name
        )
        key_columns = [
            field["field_name"]
            for field in schema_fields
            if field["is_key"] and field["field_name"] != "id"
        ]
        if not key_columns:
            raise ValueError("No key columns found to generate id index.")
        hashed = add_hash_index(df, index_name="id", length=32, columns=key_columns)
        return hashed.reset_index()

    @staticmethod
    def _apply_db_schema(
        df: pd.DataFrame, schema_name: str, table_name: str
    ) -> pd.DataFrame:
        schema = SeriesLoadDataProcessor._build_table_json_schema(
            schema_name=schema_name, table_name=table_name
        )
        return DataTools.apply_schema(df, schema)

    @staticmethod
    def _get_db_schema_fields(schema_name: str, table_name: str) -> List[dict]:
        fields = []
        for row in env.SCHEMAS:
            schema, table, field_name, field_type, is_key = row
            if schema == schema_name and table == table_name:
                fields.append(
                    {
                        "field_name": field_name,
                        "field_type": field_type,
                        "is_key": is_key,
                    }
                )
        return fields

    @staticmethod
    def _process_file_runner(scope, file_path: str, loader_param: dict):
        records = 0
        success = False
        error_message = None
        errors: List[str] = []
        db_result = None
        try:
            df = SeriesLoadDataProcessor._read_csv(file_path)
            kind = loader_param["kind"]
            errors = SeriesLoadDataProcessor._validate_against_schema(kind, df)
            transformed = SeriesLoadDataProcessor._transform_df(
                kind, df, scope, loader_param.get("currency")
            )
            normalized = SeriesLoadDataProcessor._normalize_df(
                transformed,
                schema_name=loader_param.get("schema", "infobr"),
                table_name=loader_param.get("target_table", "series"),
            )
            normalized = SeriesLoadDataProcessor._apply_db_schema(
                normalized,
                schema_name=loader_param.get("schema", "infobr"),
                table_name=loader_param.get("target_table", "series"),
            )
            normalized = SeriesLoadDataProcessor._add_id_column(
                normalized,
                schema_name=loader_param.get("schema", "infobr"),
                table_name=loader_param.get("target_table", "series"),
            )
            records = len(normalized)

            if not loader_param.get("dry_run", False):
                db_result = SeriesLoadDataProcessor._load_dataframe_to_db(
                    normalized, loader_param
                )

            if not loader_param.get("dry_run", False):
                os.rename(file_path, f"{file_path}.done")
            else:
                logger.info(
                    f"Dry-run enabled. File preserved without rename: {file_path}"
                )

            success = True
        except Exception as e:
            error_message = str(e)
            logger.debug(f"f:_process_file_runner")
            logger.error(f"Error {e} on loading {scope} from {file_path}")

        return_data = pd.DataFrame(
            [
                {
                    "file_path": file_path,
                    "records": records,
                    "target_table": loader_param.get("target_table"),
                    "schema": loader_param.get("schema"),
                    "dry_run": loader_param.get("dry_run", False),
                    "operation": loader_param.get("operation"),
                    "db_operation": db_result.get("operation") if db_result else None,
                    "insertions": db_result.get("insertions") if db_result else 0,
                    "updates": db_result.get("updates") if db_result else 0,
                    "skips": db_result.get("skips") if db_result else 0,
                    "failures": db_result.get("failures") if db_result else [],
                    "errors": errors,
                }
            ]
        )
        return [scope, success, error_message, return_data]

    @staticmethod
    def process_scope_runner(scope, scope_params):
        try:
            params = scope_params["params"]

            for param in params:
                storage_folder = param["storage_folder"]
                sub_folders = param["sub_folders"]
                parallelize = param["parallelize"]
                progress = param["progress"]
                wait = param["wait"]
                kind = param["kind"]

                files = SeriesLoadDataProcessor._discover_files(
                    storage_folder, sub_folders
                )

                loader_param = {
                    "schema": param.get("schema"),
                    "target_table": param.get("target_table"),
                    "truncate_before_load": param.get("truncate_before_load", False),
                    "batch_size": param.get("batch_size", 10000),
                    "dry_run": param.get("dry_run", False),
                    "currency": param.get("currency"),
                    "operation": param.get("operation", "upsert"),
                    "kind": kind,
                }

                if not files:
                    return [
                        scope,
                        True,
                        None,
                        pd.DataFrame(
                            [
                                {
                                    "storage_path": os.path.sep.join(
                                        [storage_folder] + sub_folders
                                    ),
                                    "files_processed": 0,
                                    "records": 0,
                                    "target_table": loader_param.get("target_table"),
                                    "schema": loader_param.get("schema"),
                                    "dry_run": loader_param.get("dry_run", False),
                                    "operation": loader_param.get("operation"),
                                }
                            ]
                        ),
                    ]

                process_loader_params = [
                    (scope, file_path, loader_param) for file_path in files
                ]

                process_loader = ProcessWithCallback(
                    process=SeriesLoadDataProcessor._process_file_runner,
                    parallelize=parallelize,
                    workers=ProcessWithCallback.get_available_cpu_count()
                    if parallelize
                    else 1,
                    sleeptime=wait,
                    progress_callback=scope_params.get("progress_callback"),
                )

                return process_loader.run(process_loader_params, progress=progress)
            raise ValueError("No params found for {scope}.")
        except Exception as e:
            logger.debug(f"f:process_scope_runner")
            logger.error(f"Error {e} on loading {scope}: {scope_params}.")
            return [scope, False, str(e), None]

    def _build_load_params(self):
        storage_folder = self.params["storage_folder"]
        scopes = self.params.get("scopes", [])

        params = {
            Series.FII_DIVIDENDS: {
                "params": (
                    {
                        "sub_folders": ["DIVIDEND", "BR"],
                        "kind": "DIVIDEND",
                        "parallelize": self.params.get("parallelize", False),
                        "progress": self.params.get("progress", False),
                        "storage_folder": storage_folder,
                        "wait": 1,
                        "target_table": "series",
                        "schema": self.params.get("schema", "infobr"),
                        "truncate_before_load": self.params.get(
                            "truncate_before_load", False
                        ),
                        "batch_size": self.params.get("batch_size", 10000),
                        "dry_run": self.params.get("dry_run", False),
                        "operation": self.params.get("operation", "upsert"),
                    },
                ),
            },
            Series.FII_PRICES: {
                "params": (
                    {
                        "sub_folders": ["STOCK", "BR"],
                        "kind": "STOCK",
                        "parallelize": self.params.get("parallelize", False),
                        "progress": self.params.get("progress", False),
                        "storage_folder": storage_folder,
                        "wait": 1,
                        "target_table": "series",
                        "schema": self.params.get("schema", "infobr"),
                        "truncate_before_load": self.params.get(
                            "truncate_before_load", False
                        ),
                        "batch_size": self.params.get("batch_size", 10000),
                        "dry_run": self.params.get("dry_run", False),
                        "operation": self.params.get("operation", "upsert"),
                    },
                ),
            },
            Series.ETF_DIVIDENDS: {
                "params": (
                    {
                        "sub_folders": ["DIVIDEND", "US"],
                        "kind": "DIVIDEND",
                        "parallelize": self.params.get("parallelize", False),
                        "progress": self.params.get("progress", False),
                        "storage_folder": storage_folder,
                        "wait": 1,
                        "target_table": "series",
                        "schema": self.params.get("schema", "infobr"),
                        "truncate_before_load": self.params.get(
                            "truncate_before_load", False
                        ),
                        "batch_size": self.params.get("batch_size", 10000),
                        "dry_run": self.params.get("dry_run", False),
                        "operation": self.params.get("operation", "upsert"),
                    },
                ),
            },
            Series.ETF_PRICES: {
                "params": (
                    {
                        "sub_folders": ["STOCK", "US"],
                        "kind": "STOCK",
                        "parallelize": self.params.get("parallelize", False),
                        "progress": self.params.get("progress", False),
                        "storage_folder": storage_folder,
                        "wait": 1,
                        "target_table": "series",
                        "schema": self.params.get("schema", "infobr"),
                        "truncate_before_load": self.params.get(
                            "truncate_before_load", False
                        ),
                        "batch_size": self.params.get("batch_size", 10000),
                        "dry_run": self.params.get("dry_run", False),
                        "operation": self.params.get("operation", "upsert"),
                    },
                ),
            },
            Series.FX_HISTORY: {
                "params": (
                    {
                        "sub_folders": ["FX"],
                        "kind": "FX",
                        "parallelize": self.params.get("parallelize", False),
                        "progress": self.params.get("progress", False),
                        "storage_folder": storage_folder,
                        "wait": 1,
                        "target_table": "series",
                        "schema": self.params.get("schema", "infobr"),
                        "truncate_before_load": self.params.get(
                            "truncate_before_load", False
                        ),
                        "batch_size": self.params.get("batch_size", 10000),
                        "dry_run": self.params.get("dry_run", False),
                        "operation": self.params.get("operation", "upsert"),
                    },
                ),
            },
        }

        return [(k, v) for k, v in params.items() if k in scopes or not scopes]

    def run(
        self,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Tuple[str, bool, Union[str, None], Union[pd.DataFrame, None]]:
        """
        Executes loading for a given set of scopes.

        Args:
            progress_callback: Optional callback(current, total, status) for progress updates
        """
        scope_process = ProcessWithCallback(
            process=SeriesLoadDataProcessor.process_scope_runner,
            parallelize=self.params["parallelize"],
            workers=ProcessWithCallback.get_available_cpu_count()
            if self.params["parallelize"]
            else 1,
            sleeptime=self.params.get("sleeptime", 0),
        )

        progress = self.params.get("progress", False)
        params_list = self._build_load_params()

        if progress_callback:
            for _, scope_params in params_list:
                scope_params["progress_callback"] = progress_callback

        return scope_process.run(params=params_list, progress=progress)
