# %%
import os
import json
from datetime import datetime

from infobr import logger, env
from infobr.data.series import SeriesExtractDataProcessor, SeriesLoadDataProcessor
from infobr.operations import register_operations


# %%
class Pipeline:
    PROCESSORS = {
        "SeriesExtractDataProcessor": SeriesExtractDataProcessor,
        "SeriesLoadDataProcessor": SeriesLoadDataProcessor,
    }

    def __init__(self, pipeline_name: str):
        if not pipeline_name:
            raise ValueError("Pipeline name must be provided.")

        self.pipeline_name = pipeline_name

    def load(self):
        file_path = os.path.sep.join(
            [env.USER_APP_FOLDER, "pipelines", f"{self.pipeline_name}.json"]
        )
        if not os.path.exists(file_path):
            logger.error(f"Pipeline file not found: {file_path}")
            return None
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_results(self, results):
        results_data = []
        for r in results:
            for row in r:
                scope, success, error_message, data = row
                results_data.append(
                    {
                        "scope": scope,
                        "success": success,
                        "error_message": error_message,
                        "data": data.to_dict(orient="records"),
                    }
                )
        if env.CONFIG.get("WRITE_OPERATIONS_TO_DB", False):
            register_operations(operations=results_data, operation="append")

        file_path = os.path.sep.join(
            [
                env.USER_APP_FOLDER,
                "operations",
                f"{self.pipeline_name}.out.{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.json",
            ]
        )
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(results_data, f, ensure_ascii=False, indent=4)

    def run(
        self,
        parallelize: bool = True,
        progress: bool = False,
        progress_callback=None,
    ):
        storage_folder = env.USER_CONFIG.get("SERIES_HISTORY_FOLDER")

        pipeline = self.load()
        if not pipeline:
            raise ValueError(f"Pipeline '{self.pipeline_name}' could not be loaded.")

        pipeline["storage_folder"] = storage_folder
        pipeline["parallelize"] = parallelize
        pipeline["progress"] = progress

        if "processor" not in pipeline:
            raise ValueError("Pipeline must specify a 'processor'.")

        processor = self.PROCESSORS[pipeline.pop("processor")](pipeline)

        # Pass progress_callback if the processor supports it
        if progress_callback:
            self.save_results(processor.run(progress_callback=progress_callback))
        else:
            self.save_results(processor.run())


# %%
