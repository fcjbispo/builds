import os
import re
import json
from typing import Any, Dict, List, Optional
from fbpyutils_ai.base import LLMService
from fbpyutils_ai.scrape import FireCrawlTool
from infobr import env, logger
from datetime import datetime, date
import locale
import calendar
import pandas as pd
import numpy as np
from jsonschema import validate

import yaml
import configparser
from collections import namedtuple
from fbpyutils import string as su


class DataTools:
    """
    Utility class providing tools for data manipulation, conversion, and extraction.
    Contains static methods for common data operations used across the application.
    """

    with open(
        os.path.sep.join([env.ROOT_FOLDER, "data", "tools", "schemas.json"]),
        "r",
        encoding="utf-8",
    ) as f:
        DATA_SCHEMAS = json.loads(f.read())

    @staticmethod
    def scrape_url(url: str, timeout: int = 30000) -> Dict[str, Any]:
        """
        Scrape content from a URL using FireCrawl service.

        Args:
            url: The URL to scrape
            timeout: Request timeout in milliseconds (default: 30000)

        Returns:
            Dict containing the scraped content and metadata

        Raises:
            ValueError: If the URL cannot be accessed or returns an error
        """

        # Initialize FireCrawl client with environment credentials
        base_url = os.getenv("FBPY_FIRECRAWL_BASE_URL")
        api_token = os.getenv("FBPY_FIRECRAWL_API_KEY")

        logger.log(logger.DEBUG, f"Using FireCrawl with base URL: {base_url}")
        fc = FireCrawlTool(base_url=base_url, token=api_token, verify_ssl=False)

        result = fc.scrape(
            url=url,
            formats=["markdown"],
            onlyMainContent=True,
            removeBase64Images=True,
            timeout=timeout,
        )

        # Check for errors
        status_code = result.get("data", {}).get("metadata", {}).get("statusCode")
        if status_code != 200 or result.get("error") is not None:
            # Detectar rate limiting específico (HTTP 429)
            if status_code == 429:
                error_msg = f"{url}: HTTP 429 (Rate Limit) - Too many requests. Please reduce request rate."
            elif status_code is None and result.get("error"):
                error_msg = f"{url}: Scraping error: {result.get('error')}"
            else:
                error_msg = (
                    f"{url}: HTTP Error ({status_code}) or Error: {result.get('error')}"
                )
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        return result

    @staticmethod
    def remove_non_numeric_chars(input_string: str) -> str:
        """
        Remove all non-numeric characters from a string, keeping only digits, dots, plus signs,
        spaces, commas, and minus signs.

        Args:
            input_string: The string to process

        Returns:
            A string containing only numeric characters and basic math symbols
        """
        logger.log(logger.DEBUG, f"Removing non-numeric chars from: {input_string}")
        return re.sub(r"[^\d.\+\s,-]", "", input_string)

    @staticmethod
    def as_float(x: str, currency: str = "USD") -> float:
        """
        Convert a string representation of a monetary value to float based on currency format.

        Args:
            x: The string value to convert
            currency: Currency code determining the format ('USD' or 'BRL')

        Returns:
            Float value of the converted string

        Raises:
            ValueError: If an invalid currency is provided
        """
        currency = currency or "USD"
        if currency not in ("USD", "BRL"):
            error_msg = f"Invalid currency: {currency}"
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        try:
            if currency == "BRL":
                x = x.replace(".", "").replace(",", ".")

            result = float(DataTools.remove_non_numeric_chars(x))
            logger.log(logger.DEBUG, f"Converted '{x}' ({currency}) to {result}")
            return result
        except ValueError as e:
            logger.log(logger.WARNING, f"Could not convert '{x}' to float: {str(e)}")
            return 0

    @staticmethod
    def br_string_to_float(x: str) -> float:
        """
        Convert a Brazilian formatted number string to float.

        Args:
            x: The string value in Brazilian number format

        Returns:
            Float value of the converted string
        """
        return DataTools.as_float(x, "BRL")

    @staticmethod
    def us_string_to_float(x: str) -> float:
        """
        Convert a US formatted number string to float.

        Args:
            x: The string value in US number format

        Returns:
            Float value of the converted string
        """
        return DataTools.as_float(x, "USD")

    @staticmethod
    def br_string_to_date(date_string: str) -> Optional[date]:
        """
        Convert a Brazilian formatted date string (DD/MM/YYYY) to a date object.
        Handles edge cases where the given date may be invalid.

        Args:
            date_string: The date string in Brazilian format (DD/MM/YYYY)

        Returns:
            Date object or None if conversion fails
        """
        date_pattern = "%d/%m/%Y"
        logger.log(logger.DEBUG, f"Converting BR date string: {date_string}")

        current_locale, current_encoding = locale.getlocale()

        locale.setlocale(locale.LC_TIME, "pt_BR.UTF-8")

        try:
            result = datetime.strptime(date_string, date_pattern).date()
            logger.log(
                logger.DEBUG, f"Successfully converted '{date_string}' to {result}"
            )
            return result
        except ValueError as e:
            logger.log(
                logger.WARNING,
                f"Primary date conversion failed for '{date_string}': {str(e)}",
            )
            # Split the date string into day, month, and year
            try:
                day_str, month_str, year_str = date_string.split("/")

                # Parse year and month to validate them separately
                year = int(year_str)
                month = int(month_str)
                day = int(calendar.monthrange(year, month)[1])
                result = datetime(year, month, day).date()
                logger.log(logger.INFO, f"Fallback date conversion succeeded: {result}")
                return result
            except ValueError as e2:
                logger.log(
                    logger.ERROR,
                    f"Fallback date conversion failed for '{date_string}': {str(e2)}",
                )
                return None
        finally:
            locale.setlocale(locale.LC_TIME, f"{current_locale}.{current_encoding}")

    @staticmethod
    def us_string_to_date(date_string: str) -> Optional[date]:
        """
        Convert a US formatted date string (e.g., 'Jan 15, 2023') to a date object.

        Args:
            date_string: The date string in US format

        Returns:
            Date object or None if conversion fails
        """
        search = "  "
        logger.log(logger.DEBUG, f"Converting US date string: {date_string}")

        current_locale, current_encoding = locale.getlocale()
        try:
            locale.setlocale(locale.LC_TIME, "en_US.UTF-8")
            while search in date_string:
                date_string = date_string.replace(search, " ")

            str_parts = date_string.replace(",", "").replace(" ", "|").split("|")
            str_parts[0] = str_parts[0][0:3]
            str_parts = "|".join(str_parts)
            if "Feb|29" in str_parts:
                str_parts = str_parts.replace("Feb|29", "Feb|28")
                logger.log(
                    logger.INFO, f"Fixed February 29 date to February 28: {str_parts}"
                )

            result = datetime.strptime(str_parts, "%b|%d|%Y").date()
            logger.log(
                logger.DEBUG, f"Successfully converted '{date_string}' to {result}"
            )
            return result
        except Exception:
            try:
                logger.log(
                    logger.WARNING,
                    "Primary US date conversion failed, trying alternate format",
                )
                result = datetime.strptime(str_parts, "%B|%d|%Y").date()
                logger.log(
                    logger.INFO, f"Alternate US date conversion succeeded: {result}"
                )
                return result
            except Exception as e:
                logger.log(
                    logger.ERROR,
                    f"US date conversion failed for '{date_string}': {str(e)}",
                )
                return None
        finally:
            locale.setlocale(locale.LC_TIME, f"{current_locale}.{current_encoding}")

    @staticmethod
    def as_date(x: str, locale: Optional[str] = None) -> date:
        """
        Convert a string representation of a date to a date object based on locale format.

        Args:
            x: The date string to convert
            locale: Locale code determining the format ('TMZ', 'ISO', 'USD', or 'BRL'). Defaults to 'ISO' if not provided.

        Returns:
            Date object of the converted string

        Raises:
            ValueError: If conversion fails or an invalid locale is provided
        """
        locale = locale or "ISO"
        logger.log(logger.DEBUG, f"Converting date string '{x}' with locale '{locale}'")

        try:
            # formats TMZ date as YYYY-MM-DDTHH:MM:SSZ
            if locale == "TMZ":
                return datetime.strptime(x, "%Y-%m-%dT%H:%M:%SZ").date()
            if locale == "ISO":
                return datetime.strptime(x, "%Y-%m-%d").date()
            elif locale == "USD":
                result = DataTools.us_string_to_date(x)
                if result is None:
                    raise ValueError(f"Failed to parse US date: {x}")
                return result
            elif locale == "BRL":
                result = DataTools.br_string_to_date(x)
                if result is None:
                    raise ValueError(f"Failed to parse BR date: {x}")
                return result
            else:
                error_msg = f"Invalid locale {locale}"
                logger.log(logger.ERROR, error_msg)
                raise ValueError(error_msg)
        except Exception as e:
            error_msg = f"Invalid value: {x}: {e}"
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

    @staticmethod
    def apply_schema(df: pd.DataFrame, schema: dict) -> pd.DataFrame:
        """
        Adjusts the data types of the columns in a DataFrame according to the provided JSON schema.
        Adds empty columns for fields defined in the schema that are not present in the DataFrame.
        Returns only the columns listed in 'properties' in the specified order.

        Parameters:
        -----------
        df : pandas.DataFrame
            The DataFrame to be adjusted.
        schema : dict
            Dictionary representing the JSON schema with the expected structure.

        Returns:
        --------
        pandas.DataFrame
            DataFrame with adjusted columns and in the order specified in the schema.

        Raises:
        -------
        ValueError
            If a data type in the schema is not supported ('string' or 'number').
        """
        # Extract properties from the schema
        properties = schema["items"]["properties"]
        ordered_columns = list(properties.keys())

        # Map schema types to pandas data types
        column_types = {}
        for col, prop in properties.items():
            if prop["type"] == "string":
                if prop.get("format") == "date-time":
                    column_types[col] = "datetime64[ns]"
                else:
                    column_types[col] = "object"
            elif prop["type"] == "number":
                column_types[col] = "float64"
            else:
                raise ValueError(f"Unsupported type: {prop['type']}")

        # Define conversion functions for the types
        converters = {
            "datetime64[ns]": lambda s: pd.to_datetime(s, errors="coerce"),
            "float64": lambda s: pd.to_numeric(s, errors="coerce"),
            "object": lambda s: s.astype("object"),
        }

        # Adjust or add columns according to the schema
        for col in ordered_columns:
            if col in df:
                # Convert the type of the existing column
                df[col] = converters[column_types[col]](df[col])
            else:
                # Add an empty column with the correct type
                df[col] = pd.Series(index=df.index, dtype=column_types[col])

        # Return the DataFrame with only the specified columns, in the defined order
        return df[ordered_columns]

    @staticmethod
    def date_frequency(dates: List[date]) -> str:
        """
        Determine the frequency of a series of dates.

        Args:
            dates: List of date objects to analyze

        Returns:
            String indicating frequency: 'monthly', 'quarterly', 'semiannual', or 'annual'
        """
        logger.log(logger.INFO, f"Calculating date frequency for {len(dates)} dates")

        # Sort the dates
        dates.sort()

        # Calculate the difference between each date and the previous date
        freqs = [(dates[i] - dates[i - 1]).days for i in range(1, len(dates))]

        # Calculate the average frequency
        avg_freq = int(np.mean(freqs)) if freqs else 0
        logger.log(logger.DEBUG, f"Average frequency: {avg_freq} days")

        if avg_freq <= 31:
            logger.log(logger.INFO, "Detected monthly frequency")
            return "Monthly"
        elif avg_freq <= 92:
            logger.log(logger.INFO, "Detected quarterly frequency")
            return "Quarterly"
        elif avg_freq <= 183:
            logger.log(logger.INFO, "Detected semiannual frequency")
            return "Semiannual"
        else:
            logger.log(logger.INFO, "Detected annual frequency")
            return "Annual"

    @staticmethod
    def convert_to_openai_schema(
        input_schema: dict, name: str = "Converted OpenAI Schema"
    ) -> dict:
        """
        Convert a generic JSON schema into an OpenAI-compatible JSON structured format response schema.

        Args:
            input_schema (dict): The input JSON schema to convert.
            title (str, optional): The title for the schema. Defaults to "Converted OpenAI Schema".

        Returns:
            dict: A new JSON schema compatible with OpenAI conventions.

        Example:
            >>> schema = {
            ...     "type": "array",
            ...     "items": {
            ...         "type": "object",
            ...         "properties": {"Ticker": {"type": "string"}},
            ...         "required": ["Ticker"]
            ...     }
            ... }
            >>> converted = convert_to_openai_schema(schema)
            >>> print(converted["$schema"])
            "http://json-schema.org/draft-07/schema#"
        """
        # Base structure for OpenAI-compatible schema
        openai_schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "name": name,
            "strict": True,
        }

        # Helper function to process properties and add descriptions
        def process_properties(props: dict) -> dict:
            """
            Process a properties dictionary, adding descriptions based on field names if absent.

            Args:
                props (dict): The properties dictionary from the schema.

            Returns:
                dict: Processed properties with descriptions.
            """
            processed = {}
            for field_name, field_schema in props.items():
                processed[field_name] = field_schema.copy()  # Avoid mutating original
                # Use field name as description if not provided
                if "description" not in processed[field_name]:
                    processed[field_name]["description"] = field_name.replace(
                        "_", " "
                    ).title()
            return processed

        # Handle the input schema based on its type
        if input_schema.get("type") == "array" and "items" in input_schema:
            # Array type schema: process the items
            openai_schema["type"] = "array"
            items = input_schema["items"]
            openai_schema["items"] = {
                "type": items["type"],
                "properties": process_properties(items["properties"]),
                "additionalProperties": items.get("additionalProperties", False),
                "required": items.get("required", []),
            }
        else:
            # Default to object type if not an array (fallback)
            openai_schema["type"] = "object"
            openai_schema["properties"] = process_properties(
                input_schema.get("properties", {})
            )
            openai_schema["additionalProperties"] = input_schema.get(
                "additionalProperties", False
            )
            openai_schema["required"] = input_schema.get("required", [])

        return openai_schema

    @staticmethod
    def llm_data_extract(
        llm: LLMService,
        provider: str,
        info: str,
        context: str,
        tries: int = 3,
        kind: str = "FX",
        verbose_mode: bool = False,
        stream: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Extract structured data from a webpage using LLM processing.

        Args:
            llm: LLM service instance to use for extraction
            provider: The ...
            info: Information description to guide the LLM extraction
            context: The context to extract data from (markdown)
            tries: Number of attempts to extract valid data
            kind: Type of data to extract ('FX', 'STOCK', or 'DIVIDEND')
            verbose_mode: Enable verbose logging for debugging
            stream: Enable streaming mode for LLM completions (default: False)

        Returns:
            The extracted data as a dictionary, list of dictionaries, or text, depending on the kind or None if the extraction fails.

        Raises:
            ValueError: If the kind is invalid or the URL cannot be accessed
        """
        if not llm or not isinstance(llm, LLMService):
            error_msg = "Invalid or not provided LLM Service"
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        if provider is None:
            error_msg = "LLM Provider cannot be None"
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        kind = kind or "FX"
        if context is None:
            error_msg = "Context cannot be None"
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        kind = kind or "FX"
        if kind not in ("FX", "STOCK", "DIVIDEND"):
            error_msg = (
                f"Invalid kind: {kind}. Valid values are 'FX', 'STOCK', and 'DIVIDEND'."
            )
            logger.log(logger.ERROR, error_msg)
            raise ValueError(error_msg)

        def validate_json(json_data: Any, schema: Dict[str, Any]) -> bool:
            """Validate JSON data against a schema."""
            try:
                validate(instance=json_data, schema=schema)
                return True
            except Exception as e:
                logger.log(logger.WARNING, f"JSON validation failed: {str(e)}")
                return False

        logger.log(logger.DEBUG, f"Retrieved content: {len(context)} characters")
        if verbose_mode:
            logger.log(logger.DEBUG, f"Provided context: ```markdown\n{context}```")

        schemas = DataTools.DATA_SCHEMAS

        schema = schemas[kind]

        # Create different system prompts based on the kind of data we're extracting (in English)
        system_prompts = {
            "FX": "You are an assistant specialized in extracting currency exchange rate data from markdown content. Your task is to analyze the provided text, identify relevant information about exchange rates, and return them in a structured format as specified. RETURN ONLY THE REQUESTED JSON, DO NOT ADD ANY EXPLANATIONS OR ADDITIONAL TEXT. REDUCE YOU REASONING OUTPUTS TO A MAXIMUM OF 3 SENTENCES, IF POSSIBLE.",
            "STOCK": "You are an assistant specialized in extracting historical stock and fund data from markdown content. Your task is to analyze the provided text, identify information about prices (open, close, high, low) and volumes, and return them in a structured format as specified. RETURN ONLY THE REQUESTED JSON, DO NOT ADD ANY EXPLANATIONS OR ADDITIONAL TEXT.. REDUCE YOU REASONING OUTPUTS TO A MAXIMUM OF 3 SENTENCES, IF POSSIBLE.",
            "DIVIDEND": "You are an assistant specialized in extracting stock dividend data from markdown content. Your task is to analyze the provided text, identify information about dividend payments, ex-dividend dates, amounts, and frequencies, and return them in a structured format as specified. RETURN ONLY THE REQUESTED JSON, DO NOT ADD ANY EXPLANATIONS OR ADDITIONAL TEXT.. REDUCE YOU REASONING OUTPUTS TO A MAXIMUM OF 3 SENTENCES, IF POSSIBLE.",
        }

        system_prompt = system_prompts.get(kind, system_prompts["STOCK"])

        # Add clear instructions about the expected format (in English)
        user_prompt = (
            f"Please extract {info} from the following content:\n\n"
            f"{context}\n\n"
            f"The data should be extracted and returned in a JSON format that EXACTLY follows this schema:\n\n"
            f"```json\n{json.dumps(schema, default=str, indent=2)}\n```\n\n"
            f"IMPORTANT: Return ONLY the valid JSON object, without any explanatory text before or after. "
            f"The expected format is an array of objects, even if there is only one item. "
            f"MAKE SURE TO RETURN ALL DATA AVAILABLE ON THE SOURCE. "
            f"ALL LINES OF THE JSON OBJECT MUST BE RETURNED, EVEN IF THEY ARE EMPTY."
        )

        # Convert the schema
        response_format_schema = DataTools.convert_to_openai_schema(
            schema, name=f"Data Extraction for {kind} Data Schema"
        )

        # Para lmstudio, não usamos o formato response_format completo
        if provider == "lmstudio":
            response_format = {"type": "json_object"}
        else:
            response_format = {
                "type": "json_schema",
                "json_schema": {
                    "name": f"{kind} Data Extraction Schema",
                    "schema": response_format_schema,
                    "strict": True,  # Recommended to ensure the output matches the schema exactly
                },
            }

        # response_format = { "type": "json_object" }

        request = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": response_format,
        }

        data: List[Dict[str, Any]] = []
        try_n = 1
        logger.log(
            logger.INFO,
            f"Starting LLM extraction for {kind} data with {tries} max attempts",
        )

        while try_n <= tries:
            try:
                logger.log(logger.DEBUG, f"Attempt {try_n}/{tries}")

                if stream:
                    logger.log(logger.DEBUG, "Using streaming mode for LLM completions")
                    # When streaming is enabled, collect chunks and process when complete
                    chunks = []
                    for chunk in llm.generate_completions(
                        messages=request["messages"], temperature=0.0, stream=True
                    ):
                        chunks.append(chunk)
                    result = "".join(chunks)
                else:
                    result = llm.generate_completions(
                        messages=request["messages"], temperature=0.0
                    )

                # Better JSON extraction from the text response
                cleaned_result = result

                # Remove markdown code blocks if present
                if "```json" in cleaned_result or "```" in cleaned_result:
                    cleaned_result = re.sub(r"```json\s*|\s*```", "", cleaned_result)

                # Limpar e fixar problemas comuns em JSON
                try:
                    # Correção para problemas específicos
                    # 1. Corrigir strings simples que deveriam ser duplas
                    if "'" in cleaned_result:
                        cleaned_result = cleaned_result.replace("'", '"')

                    # 2. Corrigir propriedades sem aspas (como {key: "value"} para {"key": "value"})
                    cleaned_result = re.sub(
                        r"([{,])\s*([a-zA-Z0-9_]+)\s*:", r'\1"\2":', cleaned_result
                    )

                    # 3. Corrigir erros nas propriedades do tipo TAB/REASONING em tags
                    if provider == "lmstudio":
                        cleaned_result = cleaned_result.replace('TAB"', "TAB")
                        cleaned_result = cleaned_result.replace(
                            'REASONING"', "REASONING"
                        )
                        cleaned_result = cleaned_result.replace(
                            '"REASONING', "REASONING"
                        )
                        cleaned_result = cleaned_result.replace(
                            "REASONING:", '"REASONING":'
                        )

                    # 4. Tentar corrigir vírgulas inválidas no final de objetos
                    cleaned_result = re.sub(r",\s*}", "}", cleaned_result)
                    cleaned_result = re.sub(r",\s*\]", "]", cleaned_result)

                    logger.log(logger.DEBUG, f"Cleaned JSON: {cleaned_result[:300]}...")

                    data = json.loads(cleaned_result)

                    if not validate_json(data, schema):
                        logger.log(
                            logger.WARNING,
                            f"Attempt {try_n}/{tries}: JSON validation failed",
                        )
                        if verbose_mode:
                            logger.log(
                                logger.ERROR, f"Returned JSON: {str(cleaned_result)}"
                            )
                        fail_message = (
                            f"Attempt {try_n}/{tries} failed: The returned JSON does not match the expected format. "
                            f"Please return a valid JSON according to the provided schema. "
                            f"Schema: {json.dumps(schema, default=str, indent=2)}"
                        )
                        request["messages"].append(
                            {"role": "user", "content": fail_message}
                        )
                        logger.log(
                            logger.DEBUG,
                            "Retrying with new message about schema validation",
                        )
                        try_n += 1  # Increment the try counter
                    else:
                        logger.log(
                            logger.INFO,
                            f"JSON validation successful on attempt {try_n}",
                        )
                        break
                except json.JSONDecodeError as je:
                    logger.log(logger.ERROR, f"JSON decode error: {str(je)}")
                    if verbose_mode:
                        logger.log(
                            logger.ERROR, f"Returned JSON: {str(cleaned_result)}"
                        )

                    # Salvar o erro para diagnóstico
                    error_log = os.path.sep.join(
                        [
                            env.USER_APP_FOLDER,
                            f"llm_extract_data_json_error_{provider}_{try_n}.json",
                        ]
                    )
                    try:
                        with open(error_log, "w") as f:
                            f.write(cleaned_result)
                        logger.log(logger.INFO, f"Saved error JSON to {error_log}")
                    except Exception as e:
                        logger.log(
                            logger.WARNING, f"Could not save error log: {str(e)}"
                        )

                    fail_message = (
                        f"Attempt {try_n}/{tries} failed with JSON format error: {str(je)}. "
                        f"Please return only a valid JSON object without any additional text before or after. "
                        f"Use the provided JSON schema to format the output. "
                        f"The JSON must exactly follow the provided schema: {json.dumps(schema, default=str)}"
                    )
                    if "JSON decode error: Unterminated string starting at" in str(je):
                        fail_message += (
                            " The error seems to be caused by an unterminated string OR MISSING DATA. "
                            " Please ensure that all strings are properly terminated with double quotes and ALL DATA IS PRESENT."
                        )
                    elif "Expecting property name enclosed in double quotes" in str(je):
                        fail_message += (
                            " The error is caused by property names not enclosed in double quotes. "
                            " Please ensure all property names are enclosed in double quotes."
                        )
                    request["messages"].append(
                        {"role": "user", "content": fail_message}
                    )
                    try_n += 1  # Increment the try counter
            except Exception as e:
                logger.log(
                    logger.ERROR, f"Attempt {try_n}/{tries} failed with error: {str(e)}"
                )
                # Add a better error message to help the LLM
                fail_message = f"Attempt {try_n}/{tries} failed with error: {str(e)}. Please return a valid JSON that follows the provided schema."
                request["messages"].append({"role": "user", "content": fail_message})
                try_n += 1  # Increment the try counter

        if try_n > tries:
            logger.log(
                logger.ERROR, f"All {tries} attempts failed. Returning empty data."
            )
            data = []  # Ensure we return an empty list if all attempts failed

        return data

    @staticmethod
    def resolve_model(
        model: str, force: bool = False
    ) -> tuple[str, str, str, str, int, list[str]]:
        """
        Extrai detalhes do modelo, provider, URL base da API, chave da API, tamanho do contexto e tags com base nas configurações do ambiente.

        Args:
            model: String de definição do modelo no formato "provider:modelo".
            force: Força a resolução do modelo, ignorando o cache.

        Returns:
            Uma tupla contendo provider, name, api_base_url, api_key, context_length e tags.

        Raises:
            ValueError: Se o modelo não estiver no formato esperado ou se informações essenciais estiverem faltando.
        """
        parts = model.split(":", 1)
        if len(parts) != 2:
            raise ValueError("Formato de modelo inválido. Use 'provider:modelo'.")
        provider, name = parts

        if force:
            model_info = {"context_lenght": 4096, "tags": []}
        else:
            model_info = None
            for p in env.SUPPORTED_LLMS:
                if p["preffix"] == provider:
                    for m in p["models"]:
                        if m["name"] == name:
                            model_info = m
                            break
                    if model_info:
                        break

            if not model_info:
                raise ValueError(
                    f"Modelo '{model}' não encontrado nas configurações suportadas."
                )

        api_key = ""
        if provider == "litellm":
            api_base_url = os.getenv("MM_LMSTUDIO_API_BASE")
            api_key = env.LITELLM_API_KEY
            if not api_key:
                raise ValueError("Chave da API do LiteLLM não configurada.")
        elif provider == "ollama":
            api_base_url = os.getenv("MM_OLLAMA_API_BASE")
            api_key = "LocalLLMNeedsNoKey"
        elif provider == "lmstudio":
            api_base_url = os.getenv("MM_LMSTUDIO_API_BASE")
            api_key = "LocalLLMNeedsNoKey"
        else:
            raise ValueError(f"Provider '{provider}' não suportado.")

        return (
            provider,
            name,
            api_base_url,
            api_key,
            model_info["context_lenght"],
            model_info["tags"],
        )

    @staticmethod
    def extract_db_response_values(response):
        # Extract 'mensagem' and 'status'
        mensagem = response["mensagem"]
        status = response["status"] == "OK"

        # Parse the 'mensagem' string
        parts = mensagem.split(", ")
        data = {}
        for part in parts:
            key, value = part.split("=")
            if key in ["insertions", "updates", "skips"]:
                data[key] = int(value)
            elif key == "failures":
                data[key] = eval(
                    value
                )  # Note: Using eval here for simplicity, but be cautious with this in production
            else:
                data[key] = value

        # Return as a tuple with status
        return (
            status,
            data["operation"],
            data["table_name"],
            data["insertions"],
            data["updates"],
            data["skips"],
            data["failures"],
        )

    @staticmethod
    def dict_to_namedtuple(dictionary, name=f"GenericNamedTuple_{su.random_string(8)}"):
        """
        Converte um dicionário em uma named tuple.

        Args:
            dictionary (dict): Dicionário a ser convertido
            name (str, opcional): Nome da named tuple. Padrão é 'GenericNamedTuple_<hash>'

        Returns:
            namedtuple: Uma named tuple com os campos do dicionário
        """
        return namedtuple(name, dictionary.keys())(**dictionary)

    @staticmethod
    def remove_code_descriptors(text):
        # Use a regular expression to find and remove code descriptors and backticks
        pattern1 = r"```(.*?)\n"
        result1 = re.sub(pattern1, "", text)
        pattern2 = r"\n```"
        result2 = re.sub(pattern2, "", result1)
        return result2

    @staticmethod
    def read_yaml(file_path):
        """
        Reads a YAML file and returns its content as a dictionary.

        Args:
            file_path (str): The path to the YAML file.

        Returns:
            dict: The content of the YAML file as a dictionary.
        """
        Logger.log(Logger.DEBUG, f"Reading YAML file from {file_path}")
        if not os.path.exists(file_path):
            Logger.log(Logger.ERROR, f"File at path {file_path} does not exist")
            raise FileNotFoundError(f"The file at {file_path} does not exist.")

        with open(file_path, "r", encoding="utf-8") as file:
            try:
                content = yaml.safe_load(file)
                Logger.log(
                    Logger.DEBUG, f"Successfully read YAML file from {file_path}"
                )
                return content
            except yaml.YAMLError as exc:
                Logger.log(
                    Logger.ERROR, f"Error reading YAML file from {file_path}: {exc}"
                )
                raise ValueError(
                    f"There was an error parsing the YAML file at {file_path}: {exc}"
                )

    @staticmethod
    def save_to_yaml(file_path, data):
        """
        Saves a dictionary to a YAML file.

        Args:
            file_path (str): The path where the YAML file will be saved.
            data (dict): The dictionary to be saved as a YAML file.
        """
        with open(file_path, "w", encoding="utf-8") as file:
            try:
                yaml.dump(data, file, default_flow_style=False)
            except yaml.YAMLError as exc:
                raise ValueError(
                    f"There was an error writing the YAML file at {file_path}: {exc}"
                )

    @staticmethod
    def read_ini(file_path):
        """
        Reads an INI file and returns its contents as a dictionary.

        Args:
            file_path (str): The path to the INI file.

        Returns:
            dict: A dictionary containing the settings from the INI file.
        """
        if not os.path.exists(file_path):
            return {}

        config = configparser.ConfigParser()
        # Specify the encoding while reading the file
        with open(file_path, "r", encoding="utf-8") as file:
            config.read_file(file)
        ini_dict = dict(config._sections)

        return ini_dict

    @staticmethod
    def save_to_ini(file_path, data):
        """
        Saves a dictionary to an INI file.

        Args:
            file_path (str): The path where the INI file will be saved.
            data (dict): A dictionary containing the settings to be written to the INI file.
        """
        config = configparser.ConfigParser()
        for section, values in data.items():
            config[section] = values

        with open(file_path, "w", encoding="utf-8") as ini_file:
            config.write(ini_file)
