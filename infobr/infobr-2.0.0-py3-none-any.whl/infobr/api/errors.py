"""Global exception handlers and helpers."""

from __future__ import annotations

from http import HTTPStatus
from typing import Any

from fastapi.encoders import jsonable_encoder
from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from infobr.api.schemas.errors import ErrorResponse


def _reason_phrase(status_code: int) -> str:
    try:
        return HTTPStatus(status_code).phrase
    except ValueError:
        return "Unexpected Error"


def build_error_response(
    status_code: int,
    message: str | None = None,
    details: Any | None = None,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    """Build a JSONResponse with the standard API error schema."""
    safe_details = jsonable_encoder(details) if details is not None else None
    payload = ErrorResponse(
        code=status_code,
        message=message or _reason_phrase(status_code),
        details=safe_details,
    ).model_dump(exclude_none=True)
    return JSONResponse(status_code=status_code, content=payload, headers=headers)


async def http_exception_handler(
    request: Request, exc: StarletteHTTPException
) -> JSONResponse:
    """Handle HTTP errors (e.g. 401, 403, 404)."""
    _ = request
    details = exc.detail if exc.detail is not None else None
    return build_error_response(
        status_code=exc.status_code,
        details=details,
        headers=exc.headers,
    )


async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """Handle FastAPI request validation errors (422)."""
    _ = request
    return build_error_response(
        status_code=422,
        message="Validation Error",
        details=exc.errors(),
    )


async def unhandled_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    """Handle unexpected internal errors (500)."""
    _ = request, exc
    return build_error_response(status_code=500)
