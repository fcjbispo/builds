"""Asynchronous pipeline execution service with run tracking."""

from __future__ import annotations

import json
import os
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from infobr import logger
from infobr.api.db import session_scope
from infobr.api.models import PipelineRun
from infobr.api.repositories import PipelineRunRepository
from infobr.services import get_pipeline_config
from infobr.services import run_pipeline as execute_pipeline

_MAX_WORKERS = int(os.getenv("INFOBR_PIPELINE_RUNNERS", "2"))
_EXECUTOR = ThreadPoolExecutor(max_workers=max(1, _MAX_WORKERS), thread_name_prefix="infobr-runner")


@dataclass(frozen=True)
class RunDispatchResult:
    """Result returned immediately when a run is queued."""

    run_id: str
    status: str


@dataclass
class ScopeConflictError(Exception):
    """Raised when a requested run conflicts with scopes already in execution."""

    requested_scopes: tuple[str, ...]
    conflicting_scopes: tuple[str, ...]
    conflicting_run_ids: tuple[str, ...]

    def __str__(self) -> str:
        scopes = ", ".join(self.conflicting_scopes)
        runs = ", ".join(self.conflicting_run_ids)
        return f"Scope already running: {scopes} (active runs: {runs})"


class PipelineRunnerService:
    """Submit and track asynchronous pipeline executions."""

    @staticmethod
    def _extract_scopes_from_pipeline_config(pipeline_name: str) -> set[str]:
        try:
            config = get_pipeline_config(pipeline_name)
        except Exception:
            return set()
        raw_scopes = config.get("scopes")
        if not isinstance(raw_scopes, list):
            return set()
        return {str(s).strip() for s in raw_scopes if str(s).strip()}

    @staticmethod
    def _resolve_requested_scopes(pipeline_name: str, params: dict[str, Any]) -> set[str]:
        explicit_scope = str(params.get("scope") or "").strip()
        if explicit_scope and explicit_scope.upper() != "ALL":
            return {explicit_scope}
        return PipelineRunnerService._extract_scopes_from_pipeline_config(pipeline_name)

    @staticmethod
    def _safe_params(params_json: str | None) -> dict[str, Any]:
        if not params_json:
            return {}
        try:
            payload = json.loads(params_json)
        except Exception:
            return {}
        return payload if isinstance(payload, dict) else {}

    @staticmethod
    def _ensure_scope_is_available(
        *,
        repo: PipelineRunRepository,
        pipeline_name: str,
        params: dict[str, Any],
    ) -> None:
        requested_scopes = PipelineRunnerService._resolve_requested_scopes(pipeline_name, params)
        if not requested_scopes:
            return

        conflicting_scopes: set[str] = set()
        conflicting_runs: set[str] = set()
        for active in repo.list_active():
            active_params = PipelineRunnerService._safe_params(active.params_json)
            active_scopes = PipelineRunnerService._resolve_requested_scopes(active.pipeline_name, active_params)
            overlap = requested_scopes.intersection(active_scopes)
            if overlap:
                conflicting_scopes.update(overlap)
                conflicting_runs.add(active.id)

        if conflicting_scopes:
            raise ScopeConflictError(
                requested_scopes=tuple(sorted(requested_scopes)),
                conflicting_scopes=tuple(sorted(conflicting_scopes)),
                conflicting_run_ids=tuple(sorted(conflicting_runs)),
            )

    @staticmethod
    def dispatch_run(
        *,
        pipeline_name: str,
        requested_by: str | None = None,
        params: dict | None = None,
    ) -> RunDispatchResult:
        params = params or {}
        params_json = json.dumps(params, ensure_ascii=False, sort_keys=True)

        with session_scope() as session:
            repo = PipelineRunRepository(session)
            PipelineRunnerService._ensure_scope_is_available(
                repo=repo,
                pipeline_name=pipeline_name,
                params=params,
            )
            run = repo.create(
                pipeline_name=pipeline_name,
                status="queued",
                requested_by=requested_by,
                params_json=params_json,
            )
            run_id = run.id

        _EXECUTOR.submit(PipelineRunnerService._execute_run, run_id, pipeline_name, params)
        return RunDispatchResult(run_id=run_id, status="queued")

    @staticmethod
    def _execute_run(run_id: str, pipeline_name: str, params: dict) -> None:
        with session_scope() as session:
            repo = PipelineRunRepository(session)
            repo.update_status(run_id, status="running", started_at=datetime.utcnow())

        try:
            result = execute_pipeline(
                pipeline_name,
                parallelize=bool(params.get("parallelize", True)),
                progress=bool(params.get("progress", False)),
            )

            with session_scope() as session:
                repo = PipelineRunRepository(session)
                repo.update_status(
                    run_id,
                    status="success",
                    finished_at=datetime.utcnow(),
                    operation_output_path=result.operation_file,
                    error_message=None,
                )
        except Exception as exc:
            logger.error(f"Pipeline run failed for run_id={run_id}: {exc}")
            with session_scope() as session:
                repo = PipelineRunRepository(session)
                repo.update_status(
                    run_id,
                    status="failed",
                    finished_at=datetime.utcnow(),
                    error_message=str(exc),
                )

    @staticmethod
    def get_run(run_id: str) -> PipelineRun | None:
        with session_scope() as session:
            repo = PipelineRunRepository(session)
            run = repo.get_by_id(run_id)
            if run:
                session.expunge(run)
            return run

    @staticmethod
    def list_runs(
        *,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> list[PipelineRun]:
        with session_scope() as session:
            repo = PipelineRunRepository(session)
            runs = repo.list(
                offset=offset,
                limit=limit,
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )
            for run in runs:
                session.expunge(run)
            return runs

    @staticmethod
    def count_runs(
        *,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> int:
        with session_scope() as session:
            repo = PipelineRunRepository(session)
            return repo.count(
                pipeline_name=pipeline_name,
                status=status,
                requested_by=requested_by,
            )
