"""Basic in-memory rate limiting helpers."""

from __future__ import annotations

import os
from collections import defaultdict, deque
from datetime import datetime, timezone
from threading import Lock


def _utc_now_ts() -> float:
    return datetime.now(timezone.utc).timestamp()


class InMemoryRateLimiter:
    """Per-key fixed-window limiter using UTC timestamps."""

    def __init__(self, *, max_requests: int, window_seconds: int):
        if max_requests < 1:
            raise ValueError("max_requests must be >= 1")
        if window_seconds < 1:
            raise ValueError("window_seconds must be >= 1")
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._entries: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def allow(self, key: str, *, now_ts: float | None = None) -> tuple[bool, int]:
        """
        Return (allowed, retry_after_seconds).

        retry_after_seconds is 0 when allowed.
        """
        if not key:
            return True, 0

        now = now_ts if now_ts is not None else _utc_now_ts()
        window_start = now - self.window_seconds

        with self._lock:
            bucket = self._entries[key]
            while bucket and bucket[0] <= window_start:
                bucket.popleft()

            if len(bucket) >= self.max_requests:
                retry_after = max(1, int(bucket[0] + self.window_seconds - now))
                return False, retry_after

            bucket.append(now)
            return True, 0

    def reset(self) -> None:
        """Reset all in-memory counters (test helper)."""
        with self._lock:
            self._entries.clear()


def _env_int(name: str, default: int) -> int:
    raw = (os.getenv(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value >= 1 else default


def build_default_rate_limiter() -> InMemoryRateLimiter:
    """Build rate limiter from environment config."""
    max_requests = _env_int("INFOBR_API_RATE_LIMIT_MAX_REQUESTS", 120)
    window_seconds = _env_int("INFOBR_API_RATE_LIMIT_WINDOW_SECONDS", 60)
    return InMemoryRateLimiter(max_requests=max_requests, window_seconds=window_seconds)

