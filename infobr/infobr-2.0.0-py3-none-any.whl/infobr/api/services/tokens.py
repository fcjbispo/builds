"""Token domain service: generation, hashing, and validation rules."""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timezone

from infobr.api.models import Token
from infobr.api.repositories import TokenRepository


class TokenService:
    """Application service for authentication token operations."""

    VALID_PROFILES = {"USER", "ADMIN"}

    @staticmethod
    def normalize_profile(profile: str) -> str:
        """Normalize and validate profile name."""
        value = (profile or "").strip().upper()
        if value not in TokenService.VALID_PROFILES:
            raise ValueError(
                f"Invalid profile '{profile}'. Expected one of {sorted(TokenService.VALID_PROFILES)}"
            )
        return value

    @staticmethod
    def generate_raw_token(bytes_length: int = 32) -> str:
        """Generate a new random bearer token."""
        if bytes_length < 16:
            raise ValueError("bytes_length must be >= 16")
        return secrets.token_urlsafe(bytes_length)

    @staticmethod
    def token_prefix(raw_token: str, length: int = 8) -> str:
        """Compute a short non-sensitive identifier for logs/UI."""
        if length < 1:
            raise ValueError("length must be >= 1")
        return (raw_token or "")[:length]

    @staticmethod
    def hash_token(raw_token: str, pepper: str | None = None) -> str:
        """
        Hash token with optional pepper from env.

        Uses SHA-256 for deterministic lookup. Pepper can be configured via:
        - INFOBR_TOKEN_PEPPER
        """
        if not raw_token:
            raise ValueError("raw_token must be provided")
        secret = pepper if pepper is not None else os.getenv("INFOBR_TOKEN_PEPPER", "")
        material = f"{secret}:{raw_token}".encode("utf-8")
        return hashlib.sha256(material).hexdigest()

    @staticmethod
    def is_expired(expires_at: datetime | None, now: datetime | None = None) -> bool:
        """Check expiration against UTC now."""
        if expires_at is None:
            return False
        now_utc = now or datetime.now(timezone.utc)
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        return expires_at <= now_utc

    @staticmethod
    def is_token_usable(token: Token, now: datetime | None = None) -> bool:
        """Apply active + expiration rules to a stored token row."""
        return bool(token and token.is_active and not TokenService.is_expired(token.expires_at, now))

    @staticmethod
    def issue_token(
        repo: TokenRepository,
        *,
        email: str,
        profile: str,
        expires_at: datetime | None = None,
        created_by: str | None = None,
    ) -> tuple[Token, str]:
        """Create and persist a new token, returning (token_row, raw_token)."""
        if not email or "@" not in email:
            raise ValueError("Valid email must be provided")
        normalized_profile = TokenService.normalize_profile(profile)
        raw_token = TokenService.generate_raw_token()
        token_hash = TokenService.hash_token(raw_token)
        token = repo.create(
            email=email.strip().lower(),
            profile=normalized_profile,
            token_hash=token_hash,
            token_prefix=TokenService.token_prefix(raw_token),
            expires_at=expires_at,
            created_by=created_by,
        )
        return token, raw_token

    @staticmethod
    def rotate_token(
        repo: TokenRepository,
        *,
        token_id: str,
        expires_at: datetime | None = None,
    ) -> tuple[Token | None, str | None]:
        """Rotate an existing token and return (token_row, raw_token)."""
        raw_token = TokenService.generate_raw_token()
        token_hash = TokenService.hash_token(raw_token)
        token = repo.rotate(
            token_id,
            token_hash=token_hash,
            token_prefix=TokenService.token_prefix(raw_token),
            expires_at=expires_at,
        )
        if not token:
            return None, None
        return token, raw_token

    @staticmethod
    def validate_bearer_token(
        repo: TokenRepository,
        *,
        raw_token: str,
        touch_last_used: bool = True,
        now: datetime | None = None,
    ) -> Token | None:
        """Validate token value against persistence and policy rules."""
        if not raw_token:
            return None
        token_hash = TokenService.hash_token(raw_token)
        token = repo.get_by_token_hash(token_hash)
        if not token:
            return None

        # Constant-time comparison to avoid leaking hash mismatch timing.
        if not hmac.compare_digest(token.token_hash, token_hash):
            return None
        if not TokenService.is_token_usable(token, now=now):
            return None

        if touch_last_used:
            token = repo.touch_last_used(token.id) or token
        return token

