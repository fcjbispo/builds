"""Password authentication service for web app login."""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone

from infobr.api.models import AppCredential, Token
from infobr.api.repositories import AppCredentialRepository, TokenRepository
from infobr.api.services.tokens import TokenService


class PasswordService:
    """Business rules for app password management and login."""

    HASH_SCHEME = "pbkdf2_sha256"

    @staticmethod
    def _env_int(name: str, default: int) -> int:
        raw = (os.getenv(name) or "").strip()
        if not raw:
            return default
        try:
            value = int(raw)
        except ValueError:
            return default
        return value if value >= 1 else default

    @staticmethod
    def normalize_email(email: str) -> str:
        value = (email or "").strip().lower()
        if "@" not in value:
            raise ValueError("Valid email must be provided")
        return value

    @staticmethod
    def validate_password_policy(password: str) -> None:
        value = password or ""
        min_length = PasswordService._env_int("INFOBR_PASSWORD_MIN_LENGTH", 8)
        if len(value) < min_length:
            raise ValueError(f"Password must have at least {min_length} characters")
        if any(ch.isspace() for ch in value):
            raise ValueError("Password must not contain whitespace")
        if value.lower() == value or value.upper() == value:
            raise ValueError("Password must include upper and lower case letters")
        if not any(ch.isdigit() for ch in value):
            raise ValueError("Password must include at least one digit")

    @staticmethod
    def hash_password(password: str, *, iterations: int | None = None) -> str:
        PasswordService.validate_password_policy(password)
        rounds = iterations or int((os.getenv("INFOBR_PASSWORD_ITERATIONS") or "310000").strip())
        salt = secrets.token_hex(16)
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            rounds,
        ).hex()
        return f"{PasswordService.HASH_SCHEME}${rounds}${salt}${digest}"

    @staticmethod
    def verify_password(password: str, password_hash: str) -> bool:
        if not password or not password_hash:
            return False
        try:
            scheme, rounds_raw, salt, expected = password_hash.split("$", 3)
            rounds = int(rounds_raw)
        except ValueError:
            return False
        if scheme != PasswordService.HASH_SCHEME:
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            rounds,
        ).hex()
        return hmac.compare_digest(expected, digest)

    @staticmethod
    def _is_locked(row: AppCredential) -> bool:
        if not row.locked_until:
            return False
        now = datetime.now(timezone.utc)
        locked_until = row.locked_until
        if locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=timezone.utc)
        return locked_until > now

    @staticmethod
    def _login_lock_settings() -> tuple[int, int]:
        max_attempts = int((os.getenv("INFOBR_LOGIN_MAX_ATTEMPTS") or "5").strip())
        lock_minutes = int((os.getenv("INFOBR_LOGIN_LOCK_MINUTES") or "15").strip())
        return max(1, max_attempts), max(1, lock_minutes)

    @staticmethod
    def _token_ttl() -> timedelta:
        ttl_hours = int((os.getenv("INFOBR_LOGIN_TOKEN_TTL_HOURS") or "12").strip())
        return timedelta(hours=max(1, ttl_hours))

    @staticmethod
    def set_password(
        repo: AppCredentialRepository,
        *,
        email: str,
        profile: str,
        password: str,
        created_by: str | None,
    ) -> AppCredential:
        normalized_email = PasswordService.normalize_email(email)
        normalized_profile = TokenService.normalize_profile(profile)
        password_hash = PasswordService.hash_password(password)
        return repo.upsert_password(
            email=normalized_email,
            profile=normalized_profile,
            password_hash=password_hash,
            created_by=created_by,
        )

    @staticmethod
    def change_password(
        repo: AppCredentialRepository,
        *,
        email: str,
        current_password: str,
        new_password: str,
    ) -> AppCredential:
        normalized_email = PasswordService.normalize_email(email)
        row = repo.get_by_email(normalized_email)
        if not row:
            raise ValueError("Credential not found")
        if not row.is_active:
            raise ValueError("Credential is inactive")
        if not PasswordService.verify_password(current_password, row.password_hash):
            raise ValueError("Current password is invalid")
        new_hash = PasswordService.hash_password(new_password)
        updated = repo.update_password(row.id, new_hash)
        if not updated:
            raise ValueError("Credential not found")
        return updated

    @staticmethod
    def reset_password(
        repo: AppCredentialRepository,
        *,
        email: str,
        new_password: str,
        profile: str | None = None,
    ) -> AppCredential:
        normalized_email = PasswordService.normalize_email(email)
        row = repo.get_by_email(normalized_email)
        if not row:
            raise ValueError("Credential not found")
        effective_profile = TokenService.normalize_profile(profile) if profile else row.profile
        row.profile = effective_profile
        new_hash = PasswordService.hash_password(new_password)
        updated = repo.update_password(row.id, new_hash)
        if not updated:
            raise ValueError("Credential not found")
        updated.profile = effective_profile
        return updated

    @staticmethod
    def login(
        cred_repo: AppCredentialRepository,
        token_repo: TokenRepository,
        *,
        email: str,
        password: str,
    ) -> tuple[Token, str]:
        normalized_email = PasswordService.normalize_email(email)
        row = cred_repo.get_by_email(normalized_email)
        if not row or not row.is_active:
            raise ValueError("Invalid credentials")

        if PasswordService._is_locked(row):
            raise PermissionError("Credential temporarily locked due to failed attempts")

        if not PasswordService.verify_password(password, row.password_hash):
            max_attempts, lock_minutes = PasswordService._login_lock_settings()
            base_attempts = int(row.failed_attempts or 0)
            # Expired lock should not keep escalating attempts forever.
            if row.locked_until and not PasswordService._is_locked(row):
                base_attempts = 0
            next_attempts = base_attempts + 1
            lock_until = None
            if next_attempts >= max_attempts:
                lock_until = datetime.utcnow() + timedelta(minutes=lock_minutes)
            cred_repo.register_login_failure(
                row.id,
                failed_attempts=next_attempts,
                lock_until=lock_until,
            )
            raise ValueError("Invalid credentials")

        cred_repo.register_login_success(row.id)
        expires_at = datetime.now(timezone.utc) + PasswordService._token_ttl()
        return TokenService.issue_token(
            token_repo,
            email=row.email,
            profile=row.profile,
            expires_at=expires_at,
            created_by=row.email,
        )
