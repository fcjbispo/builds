"""Security audit logging helpers."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from fastapi import Request

from infobr import logger


def request_correlation_id(request: Request | None) -> str:
    """Resolve correlation ID from request headers or generate one."""
    if request is not None:
        value = (request.headers.get("x-request-id") or "").strip()
        if value:
            return value[:128]
    return uuid4().hex


def request_context(request: Request | None) -> dict[str, Any]:
    """Extract minimal request context for audit events."""
    if request is None:
        return {}

    context: dict[str, Any] = {
        "path": str(request.url.path),
        "method": request.method,
    }
    if request.client and request.client.host:
        context["client_ip"] = request.client.host
    return context


def audit_security_event(
    *,
    event: str,
    outcome: str,
    actor_email: str | None = None,
    target_token_id: str | None = None,
    target_email: str | None = None,
    target_profile: str | None = None,
    token_prefix: str | None = None,
    reason: str | None = None,
    correlation_id: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    """Emit structured security audit event to application logs."""
    payload: dict[str, Any] = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "outcome": outcome,
        "correlation_id": correlation_id or uuid4().hex,
    }
    if actor_email:
        payload["actor_email"] = actor_email
    if target_token_id:
        payload["target_token_id"] = target_token_id
    if target_email:
        payload["target_email"] = target_email
    if target_profile:
        payload["target_profile"] = target_profile
    if token_prefix:
        payload["token_prefix"] = token_prefix
    if reason:
        payload["reason"] = reason
    if extra:
        payload["extra"] = extra

    message = f"[SECURITY_AUDIT] {json.dumps(payload, default=str, sort_keys=True)}"
    if outcome.lower() == "success":
        logger.info(message)
    else:
        logger.warning(message)
