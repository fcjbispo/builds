"""FastAPI application factory for InfoBR REST API."""

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from infobr.api.errors import (
    http_exception_handler,
    unhandled_exception_handler,
    validation_exception_handler,
)
from infobr.api.routers.auth import router as auth_router
from infobr.api.routers.health import router as health_router
from infobr.api.routers.operations import router as operations_router
from infobr.api.routers.pipelines import router as pipelines_router
from infobr.api.routers.runs import router as runs_router


def create_app() -> FastAPI:
    """Create and configure the InfoBR API application."""
    app = FastAPI(
        title="InfoBR API",
        version="1.0.0",
        description="Modernized InfoBR REST API.",
    )

    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)

    app.include_router(health_router, prefix="/api/v1", tags=["health"])
    app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
    app.include_router(pipelines_router, prefix="/api/v1", tags=["pipelines"])
    app.include_router(runs_router, prefix="/api/v1", tags=["runs"])
    app.include_router(operations_router, prefix="/api/v1", tags=["operations"])

    return app


app = create_app()
