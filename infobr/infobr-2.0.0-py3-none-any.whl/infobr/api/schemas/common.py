"""Common API response schemas."""

from pydantic import BaseModel


class HealthResponse(BaseModel):
    """Health endpoint response payload."""

    status: str
    service: str


class AuthMeResponse(BaseModel):
    """Temporary auth introspection payload for API-002."""

    authenticated: bool
    scheme: str
    token_prefix: str
    email: str | None = None
    profile: str | None = None
