"""Operation endpoint schemas."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class OperationListResponse(BaseModel):
    """Paginated operation records response."""

    items: list[dict[str, Any]]
    total: int
    offset: int
    limit: int


class OperationDetailResponse(BaseModel):
    """Single operation record response."""

    item: dict[str, Any]
