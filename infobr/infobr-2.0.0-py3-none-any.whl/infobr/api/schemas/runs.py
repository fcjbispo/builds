"""Run endpoint schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class RunView(BaseModel):
    """Run tracking row exposed by API."""

    id: str
    pipeline_name: str
    status: str
    requested_by: str | None
    params_json: str | None
    started_at: datetime | None
    finished_at: datetime | None
    error_message: str | None
    operation_output_path: str | None
    created_at: datetime
    updated_at: datetime | None


class RunListResponse(BaseModel):
    """Paginated run list response."""

    items: list[RunView]
    total: int
    offset: int
    limit: int


class RunResultsResponse(BaseModel):
    """Paginated operation results bound to one run."""

    run_id: str
    status: str
    file_path: str
    page: int
    page_size: int
    total_records: int
    total_pages: int
    items: list[dict[str, Any]]
    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float
