"""Error response schemas."""

from typing import Any

from pydantic import BaseModel


class ErrorResponse(BaseModel):
    """Standard API error payload."""

    code: int
    message: str
    details: Any | None = None

