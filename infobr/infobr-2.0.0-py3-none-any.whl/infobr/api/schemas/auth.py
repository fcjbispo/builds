"""Authentication and token-management API schemas."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class TokenView(BaseModel):
    """Safe token representation for API responses."""

    id: str
    email: str
    profile: str
    token_prefix: str | None
    expires_at: datetime | None
    is_active: bool
    last_used_at: datetime | None
    created_at: datetime
    updated_at: datetime | None
    created_by: str | None


class TokenCreateRequest(BaseModel):
    """Payload to issue a new token."""

    email: str = Field(min_length=3, max_length=256)
    profile: str = Field(min_length=4, max_length=16)
    expires_at: datetime | None = None

    @field_validator("email")
    @classmethod
    def _validate_email(cls, value: str) -> str:
        email = value.strip().lower()
        if "@" not in email:
            raise ValueError("email must contain '@'")
        return email


class TokenCreateResponse(BaseModel):
    """Response when creating or rotating a token."""

    token: TokenView
    raw_token: str


class TokenListResponse(BaseModel):
    """Paginated token list response."""

    items: list[TokenView]
    total: int
    offset: int
    limit: int


class TokenRevokeResponse(BaseModel):
    """Response when revoking a token."""

    token: TokenView


class TokenRotateRequest(BaseModel):
    """Payload to rotate a token."""

    expires_at: datetime | None = None


class LoginRequest(BaseModel):
    """Email/password login payload."""

    email: str = Field(min_length=3, max_length=256)
    password: str = Field(min_length=1, max_length=256)

    @field_validator("email")
    @classmethod
    def _validate_login_email(cls, value: str) -> str:
        email = value.strip().lower()
        if "@" not in email:
            raise ValueError("email must contain '@'")
        return email


class LoginResponse(BaseModel):
    """Login response with bearer token."""

    access_token: str
    token_type: str = "Bearer"
    email: str
    profile: str
    expires_at: datetime | None = None


class LogoutResponse(BaseModel):
    """Logout response."""

    success: bool = True


class PasswordSetRequest(BaseModel):
    """Payload to create or overwrite a credential password."""

    email: str = Field(min_length=3, max_length=256)
    profile: str = Field(min_length=4, max_length=16)
    password: str = Field(min_length=8, max_length=256)


class PasswordChangeRequest(BaseModel):
    """Payload to change own password."""

    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=8, max_length=256)


class PasswordResetRequest(BaseModel):
    """Payload to reset password for an existing credential."""

    email: str = Field(min_length=3, max_length=256)
    new_password: str = Field(min_length=8, max_length=256)
    profile: str | None = Field(default=None, min_length=4, max_length=16)


class PasswordActionResponse(BaseModel):
    """Password management response."""

    email: str
    profile: str
    is_active: bool
