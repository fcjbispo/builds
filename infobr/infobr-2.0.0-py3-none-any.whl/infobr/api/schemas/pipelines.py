"""Pipeline endpoint schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class PipelineListItem(BaseModel):
    """Pipeline metadata exposed by API."""

    name: str
    path: str
    exists: bool
    updated_at: datetime | None


class PipelineListResponse(BaseModel):
    """Response payload for pipeline listing."""

    items: list[PipelineListItem]
    total: int


class PipelineDetailResponse(BaseModel):
    """Response payload for pipeline detail/config."""

    name: str
    config: dict[str, Any]


class PipelineRunRequest(BaseModel):
    """Payload to enqueue one pipeline run."""

    parallelize: bool = True
    progress: bool = False
    params: dict[str, Any] = Field(default_factory=dict)


class PipelineRunDispatchResponse(BaseModel):
    """Immediate async dispatch response."""

    run_id: str
    status: str
    pipeline_name: str
