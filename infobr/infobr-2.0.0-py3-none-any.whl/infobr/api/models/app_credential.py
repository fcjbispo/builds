"""App credential ORM model (email + app password)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from infobr import env
from infobr.api.db import Base

_SCHEMA = "infobr" if env.DB.dialect.name == "postgresql" else None


class AppCredential(Base):
    """Credential storage model for web/password authentication."""

    __tablename__ = "app_credentials"
    __table_args__ = {"schema": _SCHEMA} if _SCHEMA else {}

    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    email: Mapped[str] = mapped_column(String(256), nullable=False, unique=True, index=True)
    profile: Mapped[str] = mapped_column(String(16), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(512), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean(), nullable=False, default=True)
    failed_attempts: Mapped[int] = mapped_column(Integer(), nullable=False, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(), nullable=False, default=datetime.utcnow)
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
    created_by: Mapped[str | None] = mapped_column(String(256), nullable=True)

