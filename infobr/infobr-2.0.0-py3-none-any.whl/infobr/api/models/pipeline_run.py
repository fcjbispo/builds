"""Pipeline run ORM model."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from infobr import env
from infobr.api.db import Base

_SCHEMA = "infobr" if env.DB.dialect.name == "postgresql" else None


class PipelineRun(Base):
    """Execution tracking row for pipeline runs."""

    __tablename__ = "pipeline_runs"
    __table_args__ = {"schema": _SCHEMA} if _SCHEMA else {}

    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    pipeline_name: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    requested_by: Mapped[str | None] = mapped_column(String(256), nullable=True, index=True)
    params_json: Mapped[str | None] = mapped_column(Text(), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text(), nullable=True)
    operation_output_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(), nullable=False, default=datetime.utcnow
    )
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(), nullable=True)
