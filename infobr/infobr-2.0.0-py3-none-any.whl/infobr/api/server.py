"""CLI entrypoint for InfoBR API server."""

from __future__ import annotations

import os

import uvicorn


def main() -> None:
    host = os.getenv("INFOBR_API_HOST", "0.0.0.0")
    port = int((os.getenv("INFOBR_API_PORT") or "8000").strip())
    reload_enabled = (os.getenv("INFOBR_API_RELOAD", "false").strip().lower() in {"1", "true", "yes", "on"})
    workers = int((os.getenv("INFOBR_API_WORKERS") or "1").strip())
    if reload_enabled:
        workers = 1
    uvicorn.run(
        "infobr.api.main:app",
        host=host,
        port=port,
        reload=reload_enabled,
        workers=max(1, workers),
    )


if __name__ == "__main__":
    main()
