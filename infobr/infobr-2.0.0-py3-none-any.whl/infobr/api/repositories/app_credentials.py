"""Credential repository for app password authentication."""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from infobr.api.models import AppCredential


class AppCredentialRepository:
    """Persistence operations for app credentials."""

    def __init__(self, session: Session):
        self.session = session

    @staticmethod
    def _new_id() -> str:
        return uuid4().hex[:32]

    def get_by_email(self, email: str) -> AppCredential | None:
        stmt = select(AppCredential).where(AppCredential.email == email.strip().lower())
        return self.session.execute(stmt).scalar_one_or_none()

    def create(
        self,
        *,
        email: str,
        profile: str,
        password_hash: str,
        created_by: str | None = None,
    ) -> AppCredential:
        row = AppCredential(
            id=self._new_id(),
            email=email.strip().lower(),
            profile=profile,
            password_hash=password_hash,
            is_active=True,
            failed_attempts=0,
            locked_until=None,
            last_login_at=None,
            created_at=datetime.utcnow(),
            updated_at=None,
            created_by=created_by,
        )
        self.session.add(row)
        self.session.flush()
        return row

    def upsert_password(
        self,
        *,
        email: str,
        profile: str,
        password_hash: str,
        created_by: str | None = None,
    ) -> AppCredential:
        row = self.get_by_email(email)
        if not row:
            return self.create(
                email=email,
                profile=profile,
                password_hash=password_hash,
                created_by=created_by,
            )
        row.profile = profile
        row.password_hash = password_hash
        row.is_active = True
        row.failed_attempts = 0
        row.locked_until = None
        row.updated_at = datetime.utcnow()
        self.session.flush()
        return row

    def update_password(self, row_id: str, password_hash: str) -> AppCredential | None:
        row = self.get_by_id(row_id)
        if not row:
            return None
        row.password_hash = password_hash
        row.failed_attempts = 0
        row.locked_until = None
        row.updated_at = datetime.utcnow()
        self.session.flush()
        return row

    def get_by_id(self, row_id: str) -> AppCredential | None:
        stmt = select(AppCredential).where(AppCredential.id == row_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def register_login_success(self, row_id: str) -> AppCredential | None:
        row = self.get_by_id(row_id)
        if not row:
            return None
        row.failed_attempts = 0
        row.locked_until = None
        row.last_login_at = datetime.utcnow()
        row.updated_at = datetime.utcnow()
        self.session.flush()
        return row

    def register_login_failure(
        self,
        row_id: str,
        *,
        failed_attempts: int | None = None,
        lock_until: datetime | None,
    ) -> AppCredential | None:
        row = self.get_by_id(row_id)
        if not row:
            return None
        if failed_attempts is None:
            row.failed_attempts = int(row.failed_attempts or 0) + 1
        else:
            row.failed_attempts = max(0, int(failed_attempts))
        row.locked_until = lock_until
        row.updated_at = datetime.utcnow()
        self.session.flush()
        return row
