"""Token repository (CRUD + revoke + rotate)."""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from infobr.api.models import Token


class TokenRepository:
    """Persistence operations for auth tokens."""

    def __init__(self, session: Session):
        self.session = session

    @staticmethod
    def _new_id() -> str:
        return uuid4().hex[:32]

    def create(
        self,
        *,
        email: str,
        profile: str,
        token_hash: str,
        token_prefix: str | None = None,
        expires_at: datetime | None = None,
        created_by: str | None = None,
    ) -> Token:
        token = Token(
            id=self._new_id(),
            email=email,
            profile=profile,
            token_hash=token_hash,
            token_prefix=token_prefix,
            expires_at=expires_at,
            is_active=True,
            created_by=created_by,
            created_at=datetime.utcnow(),
        )
        self.session.add(token)
        self.session.flush()
        return token

    def get_by_id(self, token_id: str) -> Token | None:
        stmt = select(Token).where(Token.id == token_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def get_by_token_hash(self, token_hash: str) -> Token | None:
        stmt = select(Token).where(Token.token_hash == token_hash)
        return self.session.execute(stmt).scalar_one_or_none()

    def list(
        self,
        *,
        offset: int = 0,
        limit: int = 100,
        email: str | None = None,
        profile: str | None = None,
        is_active: bool | None = None,
    ) -> list[Token]:
        stmt = select(Token).order_by(Token.created_at.desc()).offset(offset).limit(limit)
        if email:
            stmt = stmt.where(Token.email == email)
        if profile:
            stmt = stmt.where(Token.profile == profile)
        if is_active is not None:
            stmt = stmt.where(Token.is_active == is_active)
        return list(self.session.execute(stmt).scalars().all())

    def count(
        self,
        *,
        email: str | None = None,
        profile: str | None = None,
        is_active: bool | None = None,
    ) -> int:
        stmt = select(func.count(Token.id))
        if email:
            stmt = stmt.where(Token.email == email)
        if profile:
            stmt = stmt.where(Token.profile == profile)
        if is_active is not None:
            stmt = stmt.where(Token.is_active == is_active)
        return int(self.session.execute(stmt).scalar_one())

    def revoke(self, token_id: str) -> Token | None:
        token = self.get_by_id(token_id)
        if not token:
            return None
        token.is_active = False
        token.updated_at = datetime.utcnow()
        self.session.flush()
        return token

    def rotate(
        self,
        token_id: str,
        *,
        token_hash: str,
        token_prefix: str | None = None,
        expires_at: datetime | None = None,
    ) -> Token | None:
        token = self.get_by_id(token_id)
        if not token:
            return None
        token.token_hash = token_hash
        token.token_prefix = token_prefix
        token.expires_at = expires_at
        token.is_active = True
        token.updated_at = datetime.utcnow()
        self.session.flush()
        return token

    def touch_last_used(self, token_id: str) -> Token | None:
        token = self.get_by_id(token_id)
        if not token:
            return None
        token.last_used_at = datetime.utcnow()
        token.updated_at = datetime.utcnow()
        self.session.flush()
        return token
