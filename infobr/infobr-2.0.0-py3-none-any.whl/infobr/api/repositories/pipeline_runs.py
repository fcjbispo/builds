"""Repository for pipeline run tracking rows."""

from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from infobr.api.models import PipelineRun


class PipelineRunRepository:
    """Persistence operations for pipeline execution tracking."""

    VALID_STATUSES = {"queued", "running", "success", "failed", "canceled"}

    def __init__(self, session: Session):
        self.session = session

    @staticmethod
    def _new_id() -> str:
        return uuid4().hex[:32]

    @staticmethod
    def _normalize_status(status: str) -> str:
        value = (status or "").strip().lower()
        if value not in PipelineRunRepository.VALID_STATUSES:
            raise ValueError(
                f"Invalid status '{status}'. Expected one of {sorted(PipelineRunRepository.VALID_STATUSES)}"
            )
        return value

    def create(
        self,
        *,
        pipeline_name: str,
        status: str = "queued",
        requested_by: str | None = None,
        params_json: str | None = None,
    ) -> PipelineRun:
        run = PipelineRun(
            id=self._new_id(),
            pipeline_name=pipeline_name,
            status=self._normalize_status(status),
            requested_by=requested_by,
            params_json=params_json,
            created_at=datetime.utcnow(),
        )
        self.session.add(run)
        self.session.flush()
        return run

    def get_by_id(self, run_id: str) -> PipelineRun | None:
        stmt = select(PipelineRun).where(PipelineRun.id == run_id)
        return self.session.execute(stmt).scalar_one_or_none()

    def list(
        self,
        *,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> list[PipelineRun]:
        stmt = (
            select(PipelineRun)
            .order_by(PipelineRun.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        if pipeline_name:
            stmt = stmt.where(PipelineRun.pipeline_name == pipeline_name)
        if status:
            stmt = stmt.where(PipelineRun.status == self._normalize_status(status))
        if requested_by:
            stmt = stmt.where(PipelineRun.requested_by == requested_by)
        return list(self.session.execute(stmt).scalars().all())

    def count(
        self,
        *,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> int:
        stmt = select(func.count(PipelineRun.id))
        if pipeline_name:
            stmt = stmt.where(PipelineRun.pipeline_name == pipeline_name)
        if status:
            stmt = stmt.where(PipelineRun.status == self._normalize_status(status))
        if requested_by:
            stmt = stmt.where(PipelineRun.requested_by == requested_by)
        return int(self.session.execute(stmt).scalar_one())

    def list_active(self) -> list[PipelineRun]:
        stmt = (
            select(PipelineRun)
            .where(PipelineRun.status.in_(("queued", "running")))
            .order_by(PipelineRun.created_at.desc())
        )
        return list(self.session.execute(stmt).scalars().all())

    def update_status(
        self,
        run_id: str,
        *,
        status: str,
        started_at: datetime | None = None,
        finished_at: datetime | None = None,
        error_message: str | None = None,
        operation_output_path: str | None = None,
    ) -> PipelineRun | None:
        run = self.get_by_id(run_id)
        if not run:
            return None

        run.status = self._normalize_status(status)
        if started_at is not None:
            run.started_at = started_at
        if finished_at is not None:
            run.finished_at = finished_at
        if error_message is not None:
            run.error_message = error_message
        if operation_output_path is not None:
            run.operation_output_path = operation_output_path
        run.updated_at = datetime.utcnow()
        self.session.flush()
        return run
