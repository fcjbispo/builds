"""Database primitives for API modules."""

from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy.orm import DeclarativeBase, sessionmaker

from infobr import env


class Base(DeclarativeBase):
    """Declarative base for API ORM models."""


SessionLocal = sessionmaker(bind=env.DB, autoflush=False, autocommit=False)


@contextmanager
def session_scope():
    """Provide a transactional scope around a series of operations."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

