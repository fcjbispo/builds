"""Auth routes."""

from __future__ import annotations

import os

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from infobr.api.db import session_scope
from infobr.api.dependencies.security import require_admin, require_user
from infobr.api.models import AppCredential, Token
from infobr.api.repositories import AppCredentialRepository, TokenRepository
from infobr.api.schemas.auth import (
    LoginRequest,
    LoginResponse,
    LogoutResponse,
    PasswordActionResponse,
    PasswordChangeRequest,
    PasswordResetRequest,
    PasswordSetRequest,
    TokenCreateRequest,
    TokenCreateResponse,
    TokenListResponse,
    TokenRevokeResponse,
    TokenRotateRequest,
    TokenView,
)
from infobr.api.schemas.common import AuthMeResponse
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.services import (
    PasswordService,
    TokenService,
    audit_security_event,
    request_context,
    request_correlation_id,
)
from infobr.api.services.rate_limit import InMemoryRateLimiter

router = APIRouter()


def _env_int(name: str, default: int) -> int:
    raw = (os.getenv(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value >= 1 else default


def _build_login_rate_limiter() -> InMemoryRateLimiter:
    max_requests = _env_int("INFOBR_AUTH_LOGIN_RATE_LIMIT_MAX_REQUESTS", 20)
    window_seconds = _env_int("INFOBR_AUTH_LOGIN_RATE_LIMIT_WINDOW_SECONDS", 60)
    return InMemoryRateLimiter(max_requests=max_requests, window_seconds=window_seconds)


def _login_rate_key(request: Request, email: str) -> str:
    ip = (request.client.host if request.client else "unknown").strip()
    normalized_email = (email or "").strip().lower()
    return f"{ip}:{normalized_email}"


login_rate_limiter = _build_login_rate_limiter()


def _token_to_view(token: Token) -> TokenView:
    return TokenView(
        id=token.id,
        email=token.email,
        profile=token.profile,
        token_prefix=token.token_prefix,
        expires_at=token.expires_at,
        is_active=token.is_active,
        last_used_at=token.last_used_at,
        created_at=token.created_at,
        updated_at=token.updated_at,
        created_by=token.created_by,
    )


def _credential_to_view(row: AppCredential) -> PasswordActionResponse:
    return PasswordActionResponse(
        email=row.email,
        profile=row.profile,
        is_active=row.is_active,
    )


@router.post(
    "/login",
    response_model=LoginResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def auth_login(
    payload: LoginRequest,
    request: Request,
) -> LoginResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    allowed, retry_after = login_rate_limiter.allow(_login_rate_key(request, payload.email))
    if not allowed:
        audit_security_event(
            event="auth.login",
            outcome="denied",
            target_email=payload.email,
            reason="rate_limited",
            correlation_id=correlation_id,
            extra={**req_ctx, "retry_after_seconds": retry_after},
        )
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded for login",
            headers={"Retry-After": str(retry_after)},
        )

    with session_scope() as session:
        cred_repo = AppCredentialRepository(session)
        token_repo = TokenRepository(session)
        try:
            token, raw_token = PasswordService.login(
                cred_repo,
                token_repo,
                email=payload.email,
                password=payload.password,
            )
        except PermissionError as exc:
            audit_security_event(
                event="auth.login",
                outcome="denied",
                target_email=payload.email,
                reason="locked",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(exc),
            ) from exc
        except ValueError:
            audit_security_event(
                event="auth.login",
                outcome="denied",
                target_email=payload.email,
                reason="invalid_credentials",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
            ) from None
        session.expunge(token)

    audit_security_event(
        event="auth.login",
        outcome="success",
        actor_email=token.email,
        target_token_id=token.id,
        token_prefix=token.token_prefix,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return LoginResponse(
        access_token=raw_token,
        email=token.email,
        profile=token.profile,
        expires_at=token.expires_at,
    )


@router.post(
    "/logout",
    response_model=LogoutResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def auth_logout(
    request: Request,
    current_token: Token = Depends(require_user),
) -> LogoutResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = TokenRepository(session)
        repo.revoke(current_token.id)

    audit_security_event(
        event="auth.logout",
        outcome="success",
        actor_email=current_token.email,
        target_token_id=current_token.id,
        token_prefix=current_token.token_prefix,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return LogoutResponse(success=True)


@router.get(
    "/me",
    response_model=AuthMeResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def auth_me(
    token: Token = Depends(require_user),
) -> AuthMeResponse:
    """Return basic information from the authenticated token context."""
    return AuthMeResponse(
        authenticated=True,
        scheme="Bearer",
        token_prefix=token.token_prefix or "",
        email=token.email,
        profile=token.profile,
    )


@router.post(
    "/password/set",
    response_model=PasswordActionResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def set_password(
    payload: PasswordSetRequest,
    request: Request,
    current_token: Token = Depends(require_admin),
) -> PasswordActionResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = AppCredentialRepository(session)
        try:
            row = PasswordService.set_password(
                repo,
                email=payload.email,
                profile=payload.profile,
                password=payload.password,
                created_by=current_token.email,
            )
        except ValueError as exc:
            audit_security_event(
                event="auth.password.set",
                outcome="denied",
                actor_email=current_token.email,
                target_email=payload.email,
                reason="validation_error",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc
        session.expunge(row)

    audit_security_event(
        event="auth.password.set",
        outcome="success",
        actor_email=current_token.email,
        target_email=row.email,
        target_profile=row.profile,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return _credential_to_view(row)


@router.post(
    "/password/change",
    response_model=PasswordActionResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def change_password(
    payload: PasswordChangeRequest,
    request: Request,
    current_token: Token = Depends(require_user),
) -> PasswordActionResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = AppCredentialRepository(session)
        try:
            row = PasswordService.change_password(
                repo,
                email=current_token.email,
                current_password=payload.current_password,
                new_password=payload.new_password,
            )
        except ValueError as exc:
            audit_security_event(
                event="auth.password.change",
                outcome="denied",
                actor_email=current_token.email,
                reason="validation_error",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc
        session.expunge(row)

    audit_security_event(
        event="auth.password.change",
        outcome="success",
        actor_email=current_token.email,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return _credential_to_view(row)


@router.post(
    "/password/reset",
    response_model=PasswordActionResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def reset_password(
    payload: PasswordResetRequest,
    request: Request,
    current_token: Token = Depends(require_admin),
) -> PasswordActionResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = AppCredentialRepository(session)
        try:
            row = PasswordService.reset_password(
                repo,
                email=payload.email,
                new_password=payload.new_password,
                profile=payload.profile,
            )
        except ValueError as exc:
            audit_security_event(
                event="auth.password.reset",
                outcome="denied",
                actor_email=current_token.email,
                target_email=payload.email,
                reason="validation_error",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc
        session.expunge(row)

    audit_security_event(
        event="auth.password.reset",
        outcome="success",
        actor_email=current_token.email,
        target_email=row.email,
        target_profile=row.profile,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return _credential_to_view(row)


@router.post(
    "/tokens",
    response_model=TokenCreateResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def create_token(
    payload: TokenCreateRequest,
    request: Request,
    current_token: Token = Depends(require_admin),
) -> TokenCreateResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    if TokenService.is_expired(payload.expires_at):
        audit_security_event(
            event="token.create",
            outcome="denied",
            actor_email=current_token.email,
            target_email=payload.email,
            target_profile=payload.profile,
            reason="invalid_expires_at",
            correlation_id=correlation_id,
            extra=req_ctx,
        )
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="expires_at must be in the future",
        )

    with session_scope() as session:
        repo = TokenRepository(session)
        try:
            token, raw_token = TokenService.issue_token(
                repo,
                email=payload.email,
                profile=payload.profile,
                expires_at=payload.expires_at,
                created_by=current_token.email,
            )
        except ValueError as exc:
            audit_security_event(
                event="token.create",
                outcome="denied",
                actor_email=current_token.email,
                target_email=payload.email,
                target_profile=payload.profile,
                reason="validation_error",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc
        session.expunge(token)

    audit_security_event(
        event="token.create",
        outcome="success",
        actor_email=current_token.email,
        target_token_id=token.id,
        target_email=token.email,
        target_profile=token.profile,
        token_prefix=token.token_prefix,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return TokenCreateResponse(token=_token_to_view(token), raw_token=raw_token)


@router.get(
    "/tokens",
    response_model=TokenListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def list_tokens(
    _current_token: Token = Depends(require_admin),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    email: str | None = Query(default=None),
    profile: str | None = Query(default=None),
    is_active: bool | None = Query(default=None),
) -> TokenListResponse:
    normalized_profile: str | None = None
    if profile is not None:
        try:
            normalized_profile = TokenService.normalize_profile(profile)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc

    normalized_email = email.strip().lower() if email else None

    with session_scope() as session:
        repo = TokenRepository(session)
        items = repo.list(
            offset=offset,
            limit=limit,
            email=normalized_email,
            profile=normalized_profile,
            is_active=is_active,
        )
        total = repo.count(
            email=normalized_email,
            profile=normalized_profile,
            is_active=is_active,
        )
        for token in items:
            session.expunge(token)

    return TokenListResponse(
        items=[_token_to_view(token) for token in items],
        total=total,
        offset=offset,
        limit=limit,
    )


@router.get(
    "/tokens/{token_id}",
    response_model=TokenView,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def get_token(
    token_id: str,
    _current_token: Token = Depends(require_admin),
) -> TokenView:
    with session_scope() as session:
        repo = TokenRepository(session)
        token = repo.get_by_id(token_id)
        if not token:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token not found",
            )
        session.expunge(token)

    return _token_to_view(token)


@router.post(
    "/tokens/{token_id}/revoke",
    response_model=TokenRevokeResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def revoke_token(
    token_id: str,
    request: Request,
    current_token: Token = Depends(require_admin),
) -> TokenRevokeResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = TokenRepository(session)
        token = repo.revoke(token_id)
        if not token:
            audit_security_event(
                event="token.revoke",
                outcome="denied",
                actor_email=current_token.email,
                target_token_id=token_id,
                reason="not_found",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token not found",
            )
        session.expunge(token)

    audit_security_event(
        event="token.revoke",
        outcome="success",
        actor_email=current_token.email,
        target_token_id=token.id,
        target_email=token.email,
        target_profile=token.profile,
        token_prefix=token.token_prefix,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return TokenRevokeResponse(token=_token_to_view(token))


@router.post(
    "/tokens/{token_id}/rotate",
    response_model=TokenCreateResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def rotate_token(
    token_id: str,
    request: Request,
    payload: TokenRotateRequest | None = None,
    current_token: Token = Depends(require_admin),
) -> TokenCreateResponse:
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    with session_scope() as session:
        repo = TokenRepository(session)
        existing = repo.get_by_id(token_id)
        if not existing:
            audit_security_event(
                event="token.rotate",
                outcome="denied",
                actor_email=current_token.email,
                target_token_id=token_id,
                reason="not_found",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token not found",
            )

        # Keep current expiration by default if request body is omitted.
        expires_at = existing.expires_at
        if payload is not None and "expires_at" in payload.model_fields_set:
            expires_at = payload.expires_at
            if TokenService.is_expired(expires_at):
                audit_security_event(
                    event="token.rotate",
                    outcome="denied",
                    actor_email=current_token.email,
                    target_token_id=token_id,
                    reason="invalid_expires_at",
                    correlation_id=correlation_id,
                    extra=req_ctx,
                )
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="expires_at must be in the future",
                )

        token, raw_token = TokenService.rotate_token(
            repo,
            token_id=token_id,
            expires_at=expires_at,
        )
        if not token or not raw_token:
            audit_security_event(
                event="token.rotate",
                outcome="denied",
                actor_email=current_token.email,
                target_token_id=token_id,
                reason="not_found",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token not found",
            )
        session.expunge(token)

    audit_security_event(
        event="token.rotate",
        outcome="success",
        actor_email=current_token.email,
        target_token_id=token.id,
        target_email=token.email,
        target_profile=token.profile,
        token_prefix=token.token_prefix,
        correlation_id=correlation_id,
        extra=req_ctx,
    )
    return TokenCreateResponse(token=_token_to_view(token), raw_token=raw_token)
