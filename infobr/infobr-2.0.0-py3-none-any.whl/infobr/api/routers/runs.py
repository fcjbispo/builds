"""Run tracking routes (ADMIN)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status

from infobr.api.dependencies.security import require_admin
from infobr.api.models import PipelineRun, Token
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.runs import RunListResponse, RunResultsResponse, RunView
from infobr.api.services import PipelineRunnerService
from infobr.services import get_operation_page, summarize_operation_file

router = APIRouter()


def _run_to_view(run: PipelineRun) -> RunView:
    return RunView(
        id=run.id,
        pipeline_name=run.pipeline_name,
        status=run.status,
        requested_by=run.requested_by,
        params_json=run.params_json,
        started_at=run.started_at,
        finished_at=run.finished_at,
        error_message=run.error_message,
        operation_output_path=run.operation_output_path,
        created_at=run.created_at,
        updated_at=run.updated_at,
    )


@router.get(
    "/runs",
    response_model=RunListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def runs_list(
    _current_token: Token = Depends(require_admin),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    pipeline_name: str | None = Query(default=None),
    status_filter: str | None = Query(default=None, alias="status"),
    requested_by: str | None = Query(default=None),
) -> RunListResponse:
    try:
        items = PipelineRunnerService.list_runs(
            offset=offset,
            limit=limit,
            pipeline_name=pipeline_name,
            status=status_filter,
            requested_by=requested_by,
        )
        total = PipelineRunnerService.count_runs(
            pipeline_name=pipeline_name,
            status=status_filter,
            requested_by=requested_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    return RunListResponse(
        items=[_run_to_view(run) for run in items],
        total=total,
        offset=offset,
        limit=limit,
    )


@router.get(
    "/runs/{run_id}",
    response_model=RunView,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def run_detail(
    run_id: str,
    _current_token: Token = Depends(require_admin),
) -> RunView:
    run = PipelineRunnerService.get_run(run_id)
    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Run not found",
        )
    return _run_to_view(run)


@router.get(
    "/runs/{run_id}/results",
    response_model=RunResultsResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        409: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def run_results(
    run_id: str,
    _current_token: Token = Depends(require_admin),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=50, ge=1, le=500),
) -> RunResultsResponse:
    run = PipelineRunnerService.get_run(run_id)
    if not run:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Run not found",
        )

    if not run.operation_output_path:
        if run.status in {"queued", "running"}:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Run is still in progress; results are not available yet",
            )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Run has no result output file",
        )

    try:
        page_data = get_operation_page(
            run.operation_output_path,
            page=page,
            page_size=page_size,
        )
        summary = summarize_operation_file(run.operation_output_path)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Run output file not found",
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    return RunResultsResponse(
        run_id=run.id,
        status=run.status,
        file_path=page_data.file_path,
        page=page_data.page,
        page_size=page_data.page_size,
        total_records=page_data.total_records,
        total_pages=page_data.total_pages,
        items=page_data.items,
        total_operations=summary.total_operations,
        successful_operations=summary.successful_operations,
        failed_operations=summary.failed_operations,
        success_rate=summary.success_rate,
    )
