"""Health routes."""

from fastapi import APIRouter

from infobr.api.schemas.common import HealthResponse
from infobr.api.schemas.errors import ErrorResponse

router = APIRouter()


@router.get(
    "/health",
    response_model=HealthResponse,
    responses={500: {"model": ErrorResponse}},
)
def healthcheck() -> HealthResponse:
    """Liveness endpoint for API base checks."""
    return HealthResponse(status="ok", service="infobr-api")
