"""Pipeline management routes (ADMIN)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from infobr.api.dependencies.security import require_admin
from infobr.api.models import Token
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.pipelines import (
    PipelineDetailResponse,
    PipelineListItem,
    PipelineListResponse,
    PipelineRunDispatchResponse,
    PipelineRunRequest,
)
from infobr.api.services import PipelineRunnerService, ScopeConflictError
from infobr.services import get_pipeline_config, list_pipelines, validate_pipeline_exists

router = APIRouter()


@router.get(
    "/pipelines",
    response_model=PipelineListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipelines_list(
    _current_token: Token = Depends(require_admin),
) -> PipelineListResponse:
    items = list_pipelines()
    return PipelineListResponse(
        items=[
            PipelineListItem(
                name=i.name,
                path=i.path,
                exists=i.exists,
                updated_at=i.updated_at,
            )
            for i in items
        ],
        total=len(items),
    )


@router.get(
    "/pipelines/{pipeline_name}",
    response_model=PipelineDetailResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        409: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_detail(
    pipeline_name: str,
    _current_token: Token = Depends(require_admin),
) -> PipelineDetailResponse:
    try:
        config = get_pipeline_config(pipeline_name)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Pipeline not found",
        ) from exc

    return PipelineDetailResponse(name=pipeline_name, config=config)


@router.post(
    "/pipelines/{pipeline_name}/runs",
    response_model=PipelineRunDispatchResponse,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def pipeline_run_dispatch(
    pipeline_name: str,
    payload: PipelineRunRequest | None = None,
    current_token: Token = Depends(require_admin),
) -> PipelineRunDispatchResponse:
    try:
        validate_pipeline_exists(pipeline_name)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Pipeline not found",
        ) from exc

    request = payload or PipelineRunRequest()
    params = dict(request.params)
    params["parallelize"] = request.parallelize
    params["progress"] = request.progress

    try:
        dispatch = PipelineRunnerService.dispatch_run(
            pipeline_name=pipeline_name,
            requested_by=current_token.email,
            params=params,
        )
    except ScopeConflictError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "message": str(exc),
                "requested_scopes": list(exc.requested_scopes),
                "conflicting_scopes": list(exc.conflicting_scopes),
                "conflicting_run_ids": list(exc.conflicting_run_ids),
            },
        ) from exc
    return PipelineRunDispatchResponse(
        run_id=dispatch.run_id,
        status=dispatch.status,
        pipeline_name=pipeline_name,
    )
