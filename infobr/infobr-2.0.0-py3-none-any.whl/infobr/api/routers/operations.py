"""Operation/result routes (ADMIN)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.encoders import jsonable_encoder

from infobr.api.dependencies.security import require_admin
from infobr.api.models import Token
from infobr.api.schemas.errors import ErrorResponse
from infobr.api.schemas.operations import OperationDetailResponse, OperationListResponse
from infobr.services import parse_operation_directory

router = APIRouter()


def _to_records_safe(df) -> list[dict]:
    """Convert parser dataframe to JSON-safe records."""
    if df.empty:
        return []
    normalized = df.where(df.notna(), None)
    records = normalized.to_dict(orient="records")
    return [jsonable_encoder(row) for row in records]


@router.get(
    "/operations",
    response_model=OperationListResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        422: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def operations_list(
    _current_token: Token = Depends(require_admin),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
    pipeline: str | None = Query(default=None),
    operation_type: str | None = Query(default=None),
    success: bool | None = Query(default=None),
    scope: str | None = Query(default=None),
) -> OperationListResponse:
    try:
        df = parse_operation_directory(pattern="*.out.*.json")
    except FileNotFoundError:
        df = None

    if df is None or df.empty:
        return OperationListResponse(items=[], total=0, offset=offset, limit=limit)

    filtered = df
    if pipeline:
        filtered = filtered[filtered["pipeline"] == pipeline]
    if operation_type:
        filtered = filtered[filtered["operation_type"] == operation_type]
    if success is not None:
        filtered = filtered[filtered["success"] == success]
    if scope:
        filtered = filtered[filtered["scope"] == scope]

    total = int(len(filtered))
    page = filtered.iloc[offset : offset + limit]

    return OperationListResponse(
        items=_to_records_safe(page),
        total=total,
        offset=offset,
        limit=limit,
    )


@router.get(
    "/operations/{operation_id}",
    response_model=OperationDetailResponse,
    responses={
        401: {"model": ErrorResponse},
        403: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
def operation_detail(
    operation_id: str,
    _current_token: Token = Depends(require_admin),
) -> OperationDetailResponse:
    try:
        df = parse_operation_directory(pattern="*.out.*.json")
    except FileNotFoundError:
        df = None

    if df is None or df.empty:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Operation not found",
        )

    result = df[df["id"] == operation_id]
    if result.empty:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Operation not found",
        )

    return OperationDetailResponse(item=_to_records_safe(result.iloc[:1])[0])
