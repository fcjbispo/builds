"""Security dependencies for API routes."""

from fastapi import Request
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from infobr.api.db import session_scope
from infobr.api.models import Token
from infobr.api.repositories import TokenRepository
from infobr.api.services import (
    TokenService,
    audit_security_event,
    build_default_rate_limiter,
    request_context,
    request_correlation_id,
)


bearer_scheme = HTTPBearer(auto_error=True)
rate_limiter = build_default_rate_limiter()


def get_bearer_credentials(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> HTTPAuthorizationCredentials:
    """Return bearer credentials from Authorization header."""
    return credentials


def get_current_token(
    credentials: HTTPAuthorizationCredentials = Depends(get_bearer_credentials),
    request: Request = None,
) -> Token:
    """
    Resolve and validate current bearer token against persistence rules.

    Raises:
        HTTPException(401): missing/invalid/inactive/expired token
    """
    raw_token = (credentials.credentials or "").strip()
    correlation_id = request_correlation_id(request)
    req_ctx = request_context(request)
    if not raw_token:
        audit_security_event(
            event="token.use",
            outcome="denied",
            reason="empty_bearer",
            correlation_id=correlation_id,
            extra=req_ctx,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid bearer token",
        )

    with session_scope() as session:
        repo = TokenRepository(session)
        token = TokenService.validate_bearer_token(
            repo,
            raw_token=raw_token,
            touch_last_used=True,
        )
        if not token:
            audit_security_event(
                event="token.use",
                outcome="denied",
                reason="invalid_or_expired",
                correlation_id=correlation_id,
                extra=req_ctx,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
            )

        allowed, retry_after = rate_limiter.allow(token.id)
        if not allowed:
            audit_security_event(
                event="token.use",
                outcome="denied",
                actor_email=token.email,
                target_token_id=token.id,
                target_email=token.email,
                target_profile=token.profile,
                token_prefix=token.token_prefix,
                reason="rate_limited",
                correlation_id=correlation_id,
                extra={**req_ctx, "retry_after_seconds": retry_after},
            )
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Rate limit exceeded for token",
                headers={"Retry-After": str(retry_after)},
            )

        audit_security_event(
            event="token.use",
            outcome="success",
            actor_email=token.email,
            target_token_id=token.id,
            target_email=token.email,
            target_profile=token.profile,
            token_prefix=token.token_prefix,
            correlation_id=correlation_id,
            extra=req_ctx,
        )
        session.expunge(token)
        return token


def require_user(token: Token = Depends(get_current_token)) -> Token:
    """Require any authenticated profile (USER or ADMIN)."""
    profile = (token.profile or "").strip().upper()
    if profile not in {"USER", "ADMIN"}:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient privileges",
        )
    return token


def require_admin(token: Token = Depends(get_current_token)) -> Token:
    """Require ADMIN profile."""
    profile = (token.profile or "").strip().upper()
    if profile != "ADMIN":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin profile required",
        )
    return token
