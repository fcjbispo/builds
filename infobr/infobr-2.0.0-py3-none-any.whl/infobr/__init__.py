"""
InfoBR - Brazilian Financial Information System.
"""

import os
import json
import getpass

from sqlalchemy import create_engine
from dotenv import load_dotenv
from fbpyutils import setup, get_env, get_logger
from fbpyutils_db.database.schema import get_schemas


_ = load_dotenv()

_ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
_USER_HOME_DIR = os.path.expanduser("~")
_USER_NAME = getpass.getuser()
_USER_APP_FOLDER = os.getenv(
    "INFOBR_HOME",
    os.path.sep.join([_USER_HOME_DIR, ".infobr"]),
).strip()

setup(os.path.sep.join([_ROOT_DIR, "app.json"]))

env = get_env()
logger = get_logger()

# Normalize DB URL from env/.env to avoid hidden trailing chars (e.g. CRLF).
env.DB_URL = os.getenv(
    "INFOBR_DB_URL", f"sqlite:///{_USER_APP_FOLDER}/infbr.db"
).strip()
env.ROOT_FOLDER = _ROOT_DIR
env.USER = _USER_NAME.upper()
env.USER_APP_FOLDER = _USER_APP_FOLDER
env.USER_CONFIG = {}
env.SCHEMAS = get_schemas(os.path.sep.join([_ROOT_DIR, "data", "schemas"]))

os.makedirs(_USER_APP_FOLDER, exist_ok=True)
os.makedirs(os.path.sep.join([_USER_APP_FOLDER, "pipelines"]), exist_ok=True)
os.makedirs(os.path.sep.join([_USER_APP_FOLDER, "operations"]), exist_ok=True)
os.makedirs(os.path.sep.join([_USER_APP_FOLDER, "logs"]), exist_ok=True)

_config_file = os.path.sep.join([env.USER_APP_FOLDER, "config.json"])
if not os.path.exists(_config_file):
    with open(_config_file, "w", encoding="utf-8") as f:
        f.write(json.dumps(env.USER_CONFIG, indent=4, ensure_ascii=False))
else:
    with open(_config_file, "r", encoding="utf-8") as f:
        file_config = json.load(f)
        for key, value in file_config.items():
            env.USER_CONFIG[key] = value

def _env_int(name: str, default: int, *, minimum: int = 1) -> int:
    raw = (os.getenv(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value >= minimum else default


try:
    db_engine_options: dict[str, object] = {
        "pool_pre_ping": True,
        "pool_use_lifo": True,
    }
    if not env.DB_URL.startswith("sqlite"):
        db_engine_options.update(
            {
                "pool_size": _env_int("INFOBR_DB_POOL_SIZE", 25),
                "max_overflow": _env_int("INFOBR_DB_MAX_OVERFLOW", 35, minimum=0),
                "pool_timeout": _env_int("INFOBR_DB_POOL_TIMEOUT", 60),
                "pool_recycle": _env_int("INFOBR_DB_POOL_RECYCLE", 1800),
            }
        )
    env.DB = create_engine(env.DB_URL, **db_engine_options)
except Exception as e:
    logger.critical(f"Unable to connect/create system database: {e}")
    raise SystemError(f"Unable to connect/create system database: {e}.")
