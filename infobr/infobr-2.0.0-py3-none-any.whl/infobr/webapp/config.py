"""Configuration helpers for Streamlit web app."""

from __future__ import annotations

import os


def api_base_url() -> str:
    """Return API base URL used by the Streamlit client."""
    return (os.getenv("INFOBR_API_BASE_URL") or "http://127.0.0.1:8000/api/v1").strip().rstrip("/")

