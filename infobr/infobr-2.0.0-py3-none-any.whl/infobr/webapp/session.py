"""Session state primitives for Streamlit app."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import streamlit as st


@dataclass
class WebSession:
    """Authenticated user session data stored in Streamlit state."""

    access_token: str | None = None
    email: str | None = None
    profile: str | None = None

    @property
    def authenticated(self) -> bool:
        return bool(self.access_token)


def get_session() -> WebSession:
    """Read session state into typed object."""
    return WebSession(
        access_token=st.session_state.get("access_token"),
        email=st.session_state.get("user_email"),
        profile=st.session_state.get("user_profile"),
    )


def set_session(*, access_token: str, email: str, profile: str) -> None:
    """Persist auth session in Streamlit state."""
    st.session_state["access_token"] = access_token
    st.session_state["user_email"] = email
    st.session_state["user_profile"] = profile


def clear_session() -> None:
    """Clear auth session values from Streamlit state."""
    for key in ("access_token", "user_email", "user_profile"):
        st.session_state.pop(key, None)


def set_last_error(payload: Any) -> None:
    """Persist last API error for display/debug."""
    st.session_state["last_api_error"] = payload


def get_last_error() -> Any:
    """Return last API error payload, if any."""
    return st.session_state.get("last_api_error")

