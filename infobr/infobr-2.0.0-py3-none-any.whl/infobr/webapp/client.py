"""REST API client for Streamlit app."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import httpx
import logging

try:
    from .config import api_base_url
except ImportError:  # pragma: no cover - fallback when executed as script module
    from config import api_base_url


logger = logging.getLogger("infobr.webapp.client")


@dataclass
class ApiResult:
    """Simple response envelope for UI consumption."""

    ok: bool
    status_code: int
    data: Any | None = None
    error: Any | None = None


class ApiClient:
    """HTTP client wrapper for InfoBR API."""

    def __init__(self, base_url: str | None = None, timeout_seconds: float = 20.0):
        self.base_url = (base_url or api_base_url()).rstrip("/")
        self.timeout_seconds = timeout_seconds

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _headers(self, token: str | None = None) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        token: str | None = None,
        json_payload: dict[str, Any] | None = None,
        query_params: dict[str, Any] | None = None,
    ) -> ApiResult:
        url = self._url(path)
        logger.info("request method=%s url=%s", method.upper(), url)
        try:
            response = httpx.request(
                method=method.upper(),
                url=url,
                headers=self._headers(token),
                json=json_payload,
                params=query_params,
                timeout=self.timeout_seconds,
            )
        except httpx.HTTPError as exc:
            logger.exception("request_error method=%s url=%s err=%s", method.upper(), url, exc)
            return ApiResult(
                ok=False,
                status_code=0,
                error={"message": "Unable to connect to API", "details": str(exc)},
            )

        try:
            payload = response.json()
        except ValueError:
            payload = {"raw": response.text}
        logger.info("response method=%s url=%s status=%s", method.upper(), url, response.status_code)

        if response.status_code >= 400:
            logger.warning(
                "response_error method=%s url=%s status=%s payload=%s",
                method.upper(),
                url,
                response.status_code,
                payload,
            )
            return ApiResult(
                ok=False,
                status_code=response.status_code,
                error=payload,
            )

        return ApiResult(
            ok=True,
            status_code=response.status_code,
            data=payload,
        )

    def health(self) -> ApiResult:
        return self._request("GET", "/health")

    def auth_me(self, token: str) -> ApiResult:
        return self._request("GET", "/auth/me", token=token)

    def login(self, *, email: str, password: str) -> ApiResult:
        return self._request(
            "POST",
            "/auth/login",
            json_payload={"email": email.strip().lower(), "password": password},
        )

    def logout(self, *, token: str) -> ApiResult:
        return self._request("POST", "/auth/logout", token=token)

    def list_pipelines(self, *, token: str) -> ApiResult:
        return self._request("GET", "/pipelines", token=token)

    def get_pipeline(self, *, token: str, pipeline_name: str) -> ApiResult:
        return self._request("GET", f"/pipelines/{pipeline_name}", token=token)

    def dispatch_pipeline_run(
        self,
        *,
        token: str,
        pipeline_name: str,
        parallelize: bool,
        progress: bool,
        params: dict[str, Any] | None = None,
    ) -> ApiResult:
        payload = {
            "parallelize": parallelize,
            "progress": progress,
            "params": params or {},
        }
        return self._request(
            "POST",
            f"/pipelines/{pipeline_name}/runs",
            token=token,
            json_payload=payload,
        )

    def list_runs(
        self,
        *,
        token: str,
        offset: int = 0,
        limit: int = 100,
        pipeline_name: str | None = None,
        status: str | None = None,
        requested_by: str | None = None,
    ) -> ApiResult:
        params: dict[str, Any] = {"offset": offset, "limit": limit}
        if pipeline_name:
            params["pipeline_name"] = pipeline_name
        if status:
            params["status"] = status
        if requested_by:
            params["requested_by"] = requested_by
        return self._request("GET", "/runs", token=token, query_params=params)

    def get_run(self, *, token: str, run_id: str) -> ApiResult:
        return self._request("GET", f"/runs/{run_id}", token=token)

    def get_run_results(
        self,
        *,
        token: str,
        run_id: str,
        page: int = 1,
        page_size: int = 50,
    ) -> ApiResult:
        return self._request(
            "GET",
            f"/runs/{run_id}/results",
            token=token,
            query_params={"page": page, "page_size": page_size},
        )

    def list_operations(
        self,
        *,
        token: str,
        offset: int = 0,
        limit: int = 100,
        pipeline: str | None = None,
        operation_type: str | None = None,
        success: bool | None = None,
        scope: str | None = None,
    ) -> ApiResult:
        params: dict[str, Any] = {"offset": offset, "limit": limit}
        if pipeline:
            params["pipeline"] = pipeline
        if operation_type:
            params["operation_type"] = operation_type
        if success is not None:
            params["success"] = success
        if scope:
            params["scope"] = scope
        return self._request("GET", "/operations", token=token, query_params=params)

    def get_operation(self, *, token: str, operation_id: str) -> ApiResult:
        return self._request("GET", f"/operations/{operation_id}", token=token)

    def create_token(
        self,
        *,
        token: str,
        email: str,
        profile: str,
        expires_at: datetime | None = None,
    ) -> ApiResult:
        payload: dict[str, Any] = {
            "email": email.strip().lower(),
            "profile": profile.strip().upper(),
        }
        if expires_at is not None:
            payload["expires_at"] = expires_at.isoformat()
        return self._request("POST", "/auth/tokens", token=token, json_payload=payload)

    def list_tokens(
        self,
        *,
        token: str,
        offset: int = 0,
        limit: int = 100,
        email: str | None = None,
        profile: str | None = None,
        is_active: bool | None = None,
    ) -> ApiResult:
        params: dict[str, Any] = {"offset": offset, "limit": limit}
        if email:
            params["email"] = email.strip().lower()
        if profile:
            params["profile"] = profile.strip().upper()
        if is_active is not None:
            params["is_active"] = is_active
        return self._request("GET", "/auth/tokens", token=token, query_params=params)

    def get_token_detail(self, *, token: str, token_id: str) -> ApiResult:
        return self._request("GET", f"/auth/tokens/{token_id}", token=token)

    def revoke_token(self, *, token: str, token_id: str) -> ApiResult:
        return self._request("POST", f"/auth/tokens/{token_id}/revoke", token=token)

    def rotate_token(
        self,
        *,
        token: str,
        token_id: str,
        expires_at: datetime | None = None,
    ) -> ApiResult:
        payload: dict[str, Any] = {}
        if expires_at is not None:
            payload["expires_at"] = expires_at.isoformat()
        return self._request("POST", f"/auth/tokens/{token_id}/rotate", token=token, json_payload=payload)

    def password_set(self, *, token: str, email: str, profile: str, password: str) -> ApiResult:
        payload = {
            "email": email.strip().lower(),
            "profile": profile.strip().upper(),
            "password": password,
        }
        return self._request("POST", "/auth/password/set", token=token, json_payload=payload)

    def password_change(self, *, token: str, current_password: str, new_password: str) -> ApiResult:
        payload = {"current_password": current_password, "new_password": new_password}
        return self._request("POST", "/auth/password/change", token=token, json_payload=payload)

    def password_reset(
        self,
        *,
        token: str,
        email: str,
        new_password: str,
        profile: str | None = None,
    ) -> ApiResult:
        payload: dict[str, Any] = {
            "email": email.strip().lower(),
            "new_password": new_password,
        }
        if profile:
            payload["profile"] = profile.strip().upper()
        return self._request("POST", "/auth/password/reset", token=token, json_payload=payload)
