"""Streamlit web application package for InfoBR."""

