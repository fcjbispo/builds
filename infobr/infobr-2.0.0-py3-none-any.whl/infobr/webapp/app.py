"""InfoBR Streamlit web app shell (WEB-001/WEB-002)."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Callable

import streamlit as st
from streamlit.web import cli as stcli

try:
    from .client import ApiClient
    from .session import clear_session, get_last_error, get_session, set_last_error, set_session
except ImportError:  # pragma: no cover - fallback when executed as script path
    from client import ApiClient
    from session import clear_session, get_last_error, get_session, set_last_error, set_session


MENU_ITEMS: list[tuple[str, str]] = [
    ("dashboard", "🏠 Dashboard"),
    ("pipelines", "🧩 Pipelines"),
    ("runs", "⏱️ Runs"),
    ("operations", "📊 Operations"),
    ("auth_admin", "🔐 Auth/Admin"),
    ("settings", "⚙️ Settings"),
]

MENU_ACCESS: dict[str, set[str]] = {
    "dashboard": {"USER", "ADMIN"},
    "pipelines": {"ADMIN"},
    "runs": {"ADMIN"},
    "operations": {"ADMIN"},
    "auth_admin": {"ADMIN"},
    "settings": {"USER", "ADMIN"},
}


MENU_TITLES = {
    "dashboard": "Dashboard",
    "pipelines": "Pipelines",
    "runs": "Runs",
    "operations": "Operations",
    "auth_admin": "Auth/Admin",
    "settings": "Settings",
}

THEMES = {
    "corporate_clean": {
        "bg": "#f8fafc",
        "surface": "#ffffff",
        "border": "rgba(49, 51, 63, 0.18)",
        "text": "#0f172a",
        "muted": "#64748b",
        "badge_bg": "#e2e8f0",
        "badge_border": "#334155",
        "badge_text": "#1e293b",
    },
    "corporate_dark": {
        "bg": "#0b1220",
        "surface": "#111827",
        "border": "rgba(148, 163, 184, 0.35)",
        "text": "#e5e7eb",
        "muted": "#94a3b8",
        "badge_bg": "#1f2937",
        "badge_border": "#64748b",
        "badge_text": "#e2e8f0",
    },
    "high_contrast": {
        "bg": "#000000",
        "surface": "#111111",
        "border": "rgba(255, 255, 255, 0.7)",
        "text": "#ffffff",
        "muted": "#f1f5f9",
        "badge_bg": "#ffffff",
        "badge_border": "#ffffff",
        "badge_text": "#000000",
    },
}


def _get_theme() -> str:
    theme = st.session_state.get("ui_theme", "corporate_clean")
    if theme not in THEMES:
        return "corporate_clean"
    return theme


def _set_theme(theme: str) -> None:
    st.session_state["ui_theme"] = theme if theme in THEMES else "corporate_clean"


def _style(theme_key: str) -> None:
    theme = THEMES.get(theme_key, THEMES["corporate_clean"])
    st.markdown(
        f"""
        <style>
        :root {{
            --ib-bg: {theme["bg"]};
            --ib-surface: {theme["surface"]};
            --ib-border: {theme["border"]};
            --ib-text: {theme["text"]};
            --ib-muted: {theme["muted"]};
            --ib-badge-bg: {theme["badge_bg"]};
            --ib-badge-border: {theme["badge_border"]};
            --ib-badge-text: {theme["badge_text"]};
        }}
        .stApp {{ background: var(--ib-bg); color: var(--ib-text); }}
        .block-container {{padding-top: 3.8rem; padding-bottom: 1.5rem;}}
        [data-testid="stSidebar"] {{
            border-right: 1px solid var(--ib-border);
            background: var(--ib-surface);
        }}
        .ib-topline {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid var(--ib-border);
            border-radius: 12px;
            padding: 10px 14px;
            margin-top: 0.2rem;
            margin-bottom: 12px;
            background: var(--ib-surface);
        }}
        .ib-breadcrumb {{font-size: 0.9rem; color: var(--ib-muted);}}
        .ib-badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 999px;
            border: 1px solid var(--ib-badge-border);
            font-size: 0.78rem;
            font-weight: 600;
            color: var(--ib-badge-text);
            background: var(--ib-badge-bg);
        }}
        .ib-card {{
            border: 1px solid var(--ib-border);
            border-radius: 12px;
            padding: 14px 16px;
            background: var(--ib-surface);
        }}
        .ib-muted {{color: var(--ib-muted); font-size: 0.92rem;}}
        .ib-topline .ib-muted {{margin-left: 8px;}}
        div[data-testid="stBaseButton-secondary"] > button {{
            border: 1px solid var(--ib-border);
            background: var(--ib-surface);
            color: var(--ib-text);
            min-height: 42px;
            border-radius: 12px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def _sidebar(allowed_keys: list[str]) -> str:
    st.sidebar.title("InfoBR Web")
    st.sidebar.caption("Corporate Clean v1")
    visible_items = [item for item in MENU_ITEMS if item[0] in allowed_keys]
    labels = [label for _, label in visible_items]
    default = int(st.session_state.get("menu_index", 0))
    selected = st.sidebar.radio("Main menu", labels, index=min(default, max(0, len(labels) - 1)))
    selected_index = labels.index(selected)
    st.session_state["menu_index"] = selected_index
    return visible_items[selected_index][0]


def _topline(menu_key: str, client: ApiClient) -> None:
    session = get_session()
    title = MENU_TITLES.get(menu_key, "Dashboard")
    c1, c2, c3 = st.columns([0.70, 0.24, 0.06], vertical_alignment="center")
    with c1:
        st.markdown(
            (
                '<div class="ib-topline">'
                f'<div class="ib-breadcrumb">InfoBR / {title}</div>'
                "</div>"
            ),
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            (
                '<div class="ib-topline" style="justify-content:flex-end;">'
                f'<span class="ib-badge">{(session.profile or "USER").upper()}</span> '
                f'<span class="ib-muted">{session.email or "anonymous"}</span>'
                "</div>"
            ),
            unsafe_allow_html=True,
        )
    with c3:
        if st.button("⏻", key="topline_logout_btn", type="secondary", help="Logout", use_container_width=True):
            if session.access_token:
                client.logout(token=session.access_token)
            clear_session()
            st.rerun()


def _allowed_menu_keys(profile: str | None) -> list[str]:
    normalized = (profile or "USER").strip().upper()
    return [key for key, allowed in MENU_ACCESS.items() if normalized in allowed]


def _is_admin(profile: str | None) -> bool:
    return (profile or "").strip().upper() == "ADMIN"


def _admin_guard(profile: str | None) -> bool:
    if _is_admin(profile):
        return True
    st.error("Admin profile required for this area.")
    return False


def _parse_optional_datetime(raw: str) -> datetime | None:
    value = (raw or "").strip()
    if not value:
        return None
    normalized = value.replace("Z", "+00:00")
    return datetime.fromisoformat(normalized)


def _kpi_row(metrics: list[tuple[str, str]]) -> None:
    if not metrics:
        return
    cols = st.columns(len(metrics))
    for idx, (label, value) in enumerate(metrics):
        cols[idx].metric(label=label, value=value)


def _json_for_copy(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, default=str)


def _show_json(data: object, *, key: str, title: str | None = None) -> None:
    if title:
        st.caption(title)
    text = _json_for_copy(data)
    st.code(text, language="json")
    st.download_button(
        "Download JSON",
        data=text,
        file_name=f"{key}.json",
        mime="application/json",
        key=f"{key}_download",
    )


def _render_table_with_id_copy(
    records: list[dict],
    *,
    key_prefix: str,
    id_fields: tuple[str, ...] = ("id", "run_id", "operation_id", "token_id"),
) -> None:
    _ = key_prefix, id_fields
    st.dataframe(records, use_container_width=True, hide_index=True)


def _status_breakdown(items: list[dict], key: str = "status") -> dict[str, int]:
    result: dict[str, int] = {}
    for item in items:
        name = str(item.get(key) or "unknown").lower()
        result[name] = result.get(name, 0) + 1
    return result


def _infobr_home_path(*parts: str) -> Path:
    base = os.path.expanduser(os.getenv("INFOBR_HOME", "~/.infobr").strip() or "~/.infobr")
    return Path(base, *parts)


def _read_user_config() -> dict:
    config_path = _infobr_home_path("config.json")
    if not config_path.exists():
        return {}
    try:
        with config_path.open("r", encoding="utf-8") as fh:
            loaded = json.load(fh)
    except Exception:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _is_bearer_login_enabled() -> bool:
    user_config = _read_user_config()
    value = user_config.get("WEBAPP_ENABLE_BEARER_LOGIN", False)
    return bool(value)


def _show_login(client: ApiClient) -> None:
    st.subheader("Sign in")
    st.caption("Authenticate with email and app password.")
    with st.expander("API diagnostics", expanded=True):
        st.write("Current API base URL:")
        st.code(client.base_url)
        if st.button("Ping /health", key="ping_health_btn"):
            health = client.health()
            if health.ok:
                st.success(f"/health OK ({health.status_code})")
                _show_json(health.data, key="login_health")
            else:
                st.error(f"/health failed ({health.status_code})")
                _show_json(health.error, key="login_health_error")

    with st.form("login_form", clear_on_submit=False):
        email = st.text_input("Email")
        password = st.text_input("App password", type="password")
        submitted = st.form_submit_button("Login")
    if submitted:
        result = client.login(email=email, password=password)
        if result.ok:
            data = result.data or {}
            set_session(
                access_token=str(data.get("access_token") or ""),
                email=str(data.get("email") or email),
                profile=str(data.get("profile") or "USER"),
            )
            st.success("Authenticated.")
            st.rerun()
        else:
            set_last_error(result.error)
            st.error(f"Login failed ({result.status_code}).")
            _show_json(result.error, key="login_error")

    if _is_bearer_login_enabled():
        with st.expander("Use existing bearer token (temporary bootstrap)"):
            st.caption("Use this only until password login endpoints are implemented.")
            token = st.text_input("Bearer token", type="password", key="bootstrap_token")
            if st.button("Use token", type="secondary"):
                if not token.strip():
                    st.warning("Provide a token first.")
                    return
                me = client.auth_me(token.strip())
                if not me.ok:
                    set_last_error(me.error)
                    st.error(f"Token validation failed ({me.status_code}).")
                    _show_json(me.error, key="bootstrap_token_error")
                    return
                data = me.data or {}
                set_session(
                    access_token=token.strip(),
                    email=str(data.get("email") or "unknown@example.com"),
                    profile=str(data.get("profile") or "USER").upper(),
                )
                st.success("Authenticated with bearer token.")
                st.rerun()


def _dashboard_page(client: ApiClient) -> None:
    st.subheader("Dashboard")
    tabs = st.tabs(["Overview", "Health", "Session"])
    with tabs[0]:
        token = get_session().access_token or ""
        pipelines = client.list_pipelines(token=token)
        runs_total = client.list_runs(token=token, offset=0, limit=1)
        runs_success = client.list_runs(token=token, offset=0, limit=1, status="success")
        runs_failed = client.list_runs(token=token, offset=0, limit=1, status="failed")
        runs_running = client.list_runs(token=token, offset=0, limit=1, status="running")

        if all(
            (
                pipelines.ok,
                runs_total.ok,
                runs_success.ok,
                runs_failed.ok,
                runs_running.ok,
            )
        ):
            _kpi_row(
                [
                    ("Total Pipelines", str((pipelines.data or {}).get("total", 0))),
                    ("Total Runs", str((runs_total.data or {}).get("total", 0))),
                    ("Total Successful Runs", str((runs_success.data or {}).get("total", 0))),
                    ("Total Failed Runs", str((runs_failed.data or {}).get("total", 0))),
                    ("Current Running Pipelines", str((runs_running.data or {}).get("total", 0))),
                ]
            )
        else:
            st.warning("Some KPI sources are unavailable right now.")

        st.markdown('<div class="ib-card">', unsafe_allow_html=True)
        st.write("Use the left menu to navigate modules.")
        st.caption("Core modules are available in the sidebar with role-based visibility.")
        st.markdown("</div>", unsafe_allow_html=True)
    with tabs[1]:
        health = client.health()
        if health.ok:
            st.success("API online")
            _show_json(health.data, key="dashboard_health")
        else:
            st.error(f"Health check failed ({health.status_code}).")
            _show_json(health.error, key="dashboard_health_error")
    with tabs[2]:
        session = get_session()
        _kpi_row(
            [
                ("Authenticated", "yes" if session.authenticated else "no"),
                ("Profile", (session.profile or "USER").upper()),
                ("Theme", _get_theme()),
            ]
        )
        _show_json(
            {
                "authenticated": session.authenticated,
                "email": session.email,
                "profile": session.profile,
            },
            key="dashboard_session",
        )


def _pipelines_page(client: ApiClient) -> None:
    if not _admin_guard(get_session().profile):
        return
    st.subheader("Pipelines")
    tabs = st.tabs(["List", "Detail", "Run"])

    session = get_session()
    token = session.access_token or ""
    list_result = client.list_pipelines(token=token)
    items = (list_result.data or {}).get("items", []) if list_result.ok else []
    names = [item.get("name") for item in items if item.get("name")]

    with tabs[0]:
        if not list_result.ok:
            st.error(f"Unable to load pipelines ({list_result.status_code}).")
            _show_json(list_result.error, key="pipelines_list_error")
        elif not items:
            st.info("No pipelines found.")
        else:
            existing = sum(1 for i in items if i.get("exists"))
            _kpi_row(
                [
                    ("Total", str((list_result.data or {}).get("total", len(items)))),
                    ("Existing files", str(existing)),
                    ("Missing files", str(max(0, len(items) - existing))),
                ]
            )
            _render_table_with_id_copy(items, key_prefix="pipelines_list")

    with tabs[1]:
        if not list_result.ok:
            st.info("Load pipelines first to view details.")
        elif not names:
            st.info("No pipeline available for detail.")
        else:
            selected = st.selectbox("Pipeline", options=names, key="pipeline_detail_name")
            if st.button("Load detail", key="pipeline_detail_btn"):
                detail = client.get_pipeline(token=token, pipeline_name=selected)
                if not detail.ok:
                    st.error(f"Unable to load detail ({detail.status_code}).")
                    _show_json(detail.error, key="pipeline_detail_error")
                else:
                    st.success(f"Loaded pipeline: {selected}")
                    _show_json(detail.data, key="pipeline_detail")

    with tabs[2]:
        if not list_result.ok or not names:
            st.info("No pipeline available for run dispatch.")
        else:
            selected = st.selectbox("Pipeline to run", options=names, key="pipeline_run_name")
            parallelize = st.checkbox("Parallelize", value=True, key="pipeline_run_parallelize")
            progress = st.checkbox("Progress", value=False, key="pipeline_run_progress")
            params_text = st.text_area(
                "Params JSON",
                value='{"scope":"ALL"}',
                key="pipeline_run_params_json",
                help="JSON object merged into pipeline params.",
            )
            if st.button("Dispatch run", key="pipeline_run_dispatch_btn", type="primary"):
                try:
                    parsed_params = json.loads(params_text.strip() or "{}")
                    if not isinstance(parsed_params, dict):
                        raise ValueError("Params JSON must be an object")
                except Exception as exc:
                    st.error(f"Invalid params JSON: {exc}")
                    return

                dispatched = client.dispatch_pipeline_run(
                    token=token,
                    pipeline_name=selected,
                    parallelize=parallelize,
                    progress=progress,
                    params=parsed_params,
                )
                if not dispatched.ok:
                    st.error(f"Run dispatch failed ({dispatched.status_code}).")
                    _show_json(dispatched.error, key="pipeline_dispatch_error")
                else:
                    st.success("Run dispatched.")
                    _show_json(dispatched.data, key="pipeline_dispatch")


def _runs_page(client: ApiClient) -> None:
    if not _admin_guard(get_session().profile):
        return
    st.subheader("Runs")
    tabs = st.tabs(["List", "Detail", "Results"])

    session = get_session()
    token = session.access_token or ""

    with tabs[0]:
        col1, col2, col3, col4, col5 = st.columns(5)
        offset = col1.number_input("Offset", min_value=0, value=0, step=1, key="runs_offset")
        limit = col2.number_input("Limit", min_value=1, max_value=500, value=100, step=1, key="runs_limit")
        pipeline_name = col3.text_input("Pipeline", key="runs_pipeline_name").strip() or None
        status_filter = col4.text_input("Status", key="runs_status").strip() or None
        requested_by = col5.text_input("Requested by", key="runs_requested_by").strip() or None

        if st.button("Load runs", key="runs_load_btn"):
            list_result = client.list_runs(
                token=token,
                offset=int(offset),
                limit=int(limit),
                pipeline_name=pipeline_name,
                status=status_filter,
                requested_by=requested_by,
            )
            st.session_state["runs_last_list"] = list_result.data if list_result.ok else None
            st.session_state["runs_last_error"] = None if list_result.ok else list_result.error
            st.session_state["runs_ids"] = [item.get("id") for item in (list_result.data or {}).get("items", []) if item.get("id")] if list_result.ok else []

        if st.session_state.get("runs_last_error") is not None:
            st.error("Unable to load runs.")
            _show_json(st.session_state["runs_last_error"], key="runs_list_error")
        elif st.session_state.get("runs_last_list"):
            payload = st.session_state["runs_last_list"]
            run_items = payload.get("items", [])
            statuses = _status_breakdown(run_items, key="status")
            _kpi_row(
                [
                    ("Returned", str(payload.get("total", 0))),
                    ("Running", str(statuses.get("running", 0) + statuses.get("queued", 0))),
                    ("Success", str(statuses.get("success", 0))),
                    ("Failed", str(statuses.get("failed", 0))),
                ]
            )
            _render_table_with_id_copy(run_items, key_prefix="runs_list")
        else:
            st.info("Click 'Load runs' to fetch data.")

    with tabs[1]:
        run_ids = st.session_state.get("runs_ids") or []
        selected = st.selectbox("Run ID", options=run_ids if run_ids else [""], key="run_detail_id")
        if st.button("Load run detail", key="run_detail_btn"):
            if not selected:
                st.warning("Load runs first and select a run id.")
            else:
                detail = client.get_run(token=token, run_id=selected)
                if not detail.ok:
                    st.error(f"Unable to load run detail ({detail.status_code}).")
                    _show_json(detail.error, key="run_detail_error")
                else:
                    st.success(f"Loaded run: {selected}")
                    _show_json(detail.data, key="run_detail")

    with tabs[2]:
        run_ids = st.session_state.get("runs_ids") or []
        selected = st.selectbox("Run ID for results", options=run_ids if run_ids else [""], key="run_results_id")
        col1, col2 = st.columns(2)
        page = col1.number_input("Page", min_value=1, value=1, step=1, key="run_results_page")
        page_size = col2.number_input("Page size", min_value=1, max_value=500, value=50, step=1, key="run_results_page_size")
        if st.button("Load run results", key="run_results_btn"):
            if not selected:
                st.warning("Load runs first and select a run id.")
            else:
                results = client.get_run_results(
                    token=token,
                    run_id=selected,
                    page=int(page),
                    page_size=int(page_size),
                )
                if not results.ok:
                    st.error(f"Unable to load run results ({results.status_code}).")
                    _show_json(results.error, key="run_results_error")
                else:
                    payload = results.data or {}
                    st.success(f"Results loaded for run: {selected}")
                    _kpi_row(
                        [
                            ("Total ops", str(payload.get("total_operations", 0))),
                            ("Success", str(payload.get("successful_operations", 0))),
                            ("Failed", str(payload.get("failed_operations", 0))),
                            ("Rate", f"{payload.get('success_rate', 0)}%"),
                        ]
                    )
                    st.caption(
                        f"Operations: {payload.get('successful_operations', 0)} success / "
                        f"{payload.get('failed_operations', 0)} failed "
                        f"(rate={payload.get('success_rate', 0)}%)"
                    )
                    raw_items = payload.get("items", [])
                    normalized_items: list[dict] = []
                    for item in raw_items:
                        if isinstance(item, dict):
                            row = dict(item)
                            if "data" in row:
                                row["data"] = _json_for_copy(row.get("data"))
                            normalized_items.append(row)
                        else:
                            normalized_items.append({"value": str(item)})
                    _render_table_with_id_copy(normalized_items, key_prefix="run_results")
                    _show_json(payload, key="run_results_payload")


def _operations_page(client: ApiClient) -> None:
    if not _admin_guard(get_session().profile):
        return
    st.subheader("Operations")
    tabs = st.tabs(["List", "Detail"])

    session = get_session()
    token = session.access_token or ""

    with tabs[0]:
        col1, col2, col3, col4 = st.columns(4)
        offset = col1.number_input("Offset", min_value=0, value=0, step=1, key="ops_offset")
        limit = col2.number_input("Limit", min_value=1, max_value=500, value=100, step=1, key="ops_limit")
        pipeline = col3.text_input("Pipeline", key="ops_pipeline").strip() or None
        operation_type = col4.text_input("Operation type", key="ops_operation_type").strip() or None
        col5, col6 = st.columns(2)
        scope = col5.text_input("Scope", key="ops_scope").strip() or None
        success_filter = col6.selectbox("Success", options=["any", "true", "false"], key="ops_success")

        if st.button("Load operations", key="ops_load_btn"):
            success: bool | None = None
            if success_filter == "true":
                success = True
            elif success_filter == "false":
                success = False

            result = client.list_operations(
                token=token,
                offset=int(offset),
                limit=int(limit),
                pipeline=pipeline,
                operation_type=operation_type,
                success=success,
                scope=scope,
            )
            st.session_state["ops_last_list"] = result.data if result.ok else None
            st.session_state["ops_last_error"] = None if result.ok else result.error
            st.session_state["ops_ids"] = [item.get("id") for item in (result.data or {}).get("items", []) if item.get("id")] if result.ok else []

        if st.session_state.get("ops_last_error") is not None:
            st.error("Unable to load operations.")
            _show_json(st.session_state["ops_last_error"], key="operations_list_error")
        elif st.session_state.get("ops_last_list"):
            payload = st.session_state["ops_last_list"]
            items = payload.get("items", [])
            success_total = client.list_operations(
                token=token,
                offset=0,
                limit=1,
                pipeline=pipeline,
                operation_type=operation_type,
                success=True,
                scope=scope,
            )
            fail_total = client.list_operations(
                token=token,
                offset=0,
                limit=1,
                pipeline=pipeline,
                operation_type=operation_type,
                success=False,
                scope=scope,
            )
            success_count = int((success_total.data or {}).get("total", 0)) if success_total.ok else 0
            fail_count = int((fail_total.data or {}).get("total", 0)) if fail_total.ok else 0
            _kpi_row(
                [
                    ("Returned", str(payload.get("total", 0))),
                    ("Success", str(success_count)),
                    ("Failed", str(fail_count)),
                ]
            )
            _render_table_with_id_copy(items, key_prefix="operations_list")
        else:
            st.info("Click 'Load operations' to fetch data.")

    with tabs[1]:
        op_ids = st.session_state.get("ops_ids") or []
        selected = st.selectbox("Operation ID", options=op_ids if op_ids else [""], key="ops_detail_id")
        if st.button("Load operation detail", key="ops_detail_btn"):
            if not selected:
                st.warning("Load operations first and select an operation id.")
            else:
                detail = client.get_operation(token=token, operation_id=selected)
                if not detail.ok:
                    st.error(f"Unable to load operation detail ({detail.status_code}).")
                    _show_json(detail.error, key="operation_detail_error")
                else:
                    st.success(f"Loaded operation: {selected}")
                    _show_json(detail.data, key="operation_detail")


def _auth_admin_page(client: ApiClient) -> None:
    if not _admin_guard(get_session().profile):
        return
    st.subheader("Auth/Admin")
    tabs = st.tabs(["Tokens", "Password", "Audit"])
    token = get_session().access_token or ""

    with tabs[0]:
        st.markdown("**Create token**")
        col1, col2, col3 = st.columns(3)
        c_email = col1.text_input("Email", key="adm_create_email")
        c_profile = col2.selectbox("Profile", options=["USER", "ADMIN"], key="adm_create_profile")
        c_expires = col3.text_input("Expires at (ISO optional)", key="adm_create_expires")
        if st.button("Create token", key="adm_create_token_btn"):
            try:
                expires_at = _parse_optional_datetime(c_expires)
            except Exception as exc:
                st.error(f"Invalid expires_at: {exc}")
                return
            created = client.create_token(
                token=token,
                email=c_email,
                profile=c_profile,
                expires_at=expires_at,
            )
            if not created.ok:
                st.error(f"Create token failed ({created.status_code}).")
                _show_json(created.error, key="token_create_error")
            else:
                st.success("Token created.")
                _show_json(created.data, key="token_create")

        st.markdown("---")
        st.markdown("**List / detail / revoke / rotate**")
        f1, f2, f3, f4, f5 = st.columns(5)
        offset = f1.number_input("Offset", min_value=0, value=0, step=1, key="adm_tokens_offset")
        limit = f2.number_input("Limit", min_value=1, max_value=500, value=100, step=1, key="adm_tokens_limit")
        email = f3.text_input("Filter email", key="adm_tokens_email").strip() or None
        profile = f4.text_input("Filter profile", key="adm_tokens_profile").strip() or None
        active = f5.selectbox("Active", options=["any", "true", "false"], key="adm_tokens_active")
        if st.button("Load tokens", key="adm_tokens_load_btn"):
            is_active = None
            if active == "true":
                is_active = True
            elif active == "false":
                is_active = False
            listed = client.list_tokens(
                token=token,
                offset=int(offset),
                limit=int(limit),
                email=email,
                profile=profile,
                is_active=is_active,
            )
            st.session_state["adm_tokens_list"] = listed.data if listed.ok else None
            st.session_state["adm_tokens_error"] = None if listed.ok else listed.error
            st.session_state["adm_token_ids"] = [item.get("id") for item in (listed.data or {}).get("items", []) if item.get("id")] if listed.ok else []

        if st.session_state.get("adm_tokens_error") is not None:
            st.error("Unable to load tokens.")
            _show_json(st.session_state["adm_tokens_error"], key="tokens_list_error")
        elif st.session_state.get("adm_tokens_list"):
            data = st.session_state["adm_tokens_list"]
            token_items = data.get("items", [])
            active_count = sum(1 for item in token_items if item.get("is_active"))
            _kpi_row(
                [
                    ("Returned", str(data.get("total", 0))),
                    ("Active", str(active_count)),
                    ("Inactive", str(max(0, len(token_items) - active_count))),
                ]
            )
            _render_table_with_id_copy(token_items, key_prefix="tokens_list")

        ids = st.session_state.get("adm_token_ids") or []
        selected = st.selectbox("Token ID", options=ids if ids else [""], key="adm_token_selected")
        a1, a2, a3 = st.columns(3)
        if a1.button("Get detail", key="adm_token_detail_btn"):
            if not selected:
                st.warning("Load tokens first and select a token id.")
            else:
                detail = client.get_token_detail(token=token, token_id=selected)
                if not detail.ok:
                    st.error(f"Detail failed ({detail.status_code}).")
                    _show_json(detail.error, key="token_detail_error")
                else:
                    _show_json(detail.data, key="token_detail")
        if a2.button("Revoke", key="adm_token_revoke_btn"):
            if not selected:
                st.warning("Select a token id.")
            else:
                revoked = client.revoke_token(token=token, token_id=selected)
                if not revoked.ok:
                    st.error(f"Revoke failed ({revoked.status_code}).")
                    _show_json(revoked.error, key="token_revoke_error")
                else:
                    st.success("Token revoked.")
                    _show_json(revoked.data, key="token_revoke")
        rotate_expires_raw = st.text_input("Rotate expires_at (ISO optional)", key="adm_token_rotate_expires")
        if a3.button("Rotate", key="adm_token_rotate_btn"):
            if not selected:
                st.warning("Select a token id.")
            else:
                try:
                    rotate_expires = _parse_optional_datetime(rotate_expires_raw)
                except Exception as exc:
                    st.error(f"Invalid rotate expires_at: {exc}")
                    return
                rotated = client.rotate_token(token=token, token_id=selected, expires_at=rotate_expires)
                if not rotated.ok:
                    st.error(f"Rotate failed ({rotated.status_code}).")
                    _show_json(rotated.error, key="token_rotate_error")
                else:
                    st.success("Token rotated.")
                    _show_json(rotated.data, key="token_rotate")

    with tabs[1]:
        st.markdown("**Set password (admin)**")
        p1, p2, p3 = st.columns(3)
        set_email = p1.text_input("Email", key="pwd_set_email")
        set_profile = p2.selectbox("Profile", options=["USER", "ADMIN"], key="pwd_set_profile")
        set_password = p3.text_input("Password", type="password", key="pwd_set_password")
        if st.button("Set password", key="pwd_set_btn"):
            result = client.password_set(
                token=token,
                email=set_email,
                profile=set_profile,
                password=set_password,
            )
            if not result.ok:
                st.error(f"Set password failed ({result.status_code}).")
                _show_json(result.error, key="password_set_error")
            else:
                st.success("Password set.")
                _show_json(result.data, key="password_set")

        st.markdown("---")
        st.markdown("**Change own password**")
        c1, c2 = st.columns(2)
        current_pwd = c1.text_input("Current password", type="password", key="pwd_change_current")
        new_pwd = c2.text_input("New password", type="password", key="pwd_change_new")
        if st.button("Change own password", key="pwd_change_btn"):
            result = client.password_change(token=token, current_password=current_pwd, new_password=new_pwd)
            if not result.ok:
                st.error(f"Change password failed ({result.status_code}).")
                _show_json(result.error, key="password_change_error")
            else:
                st.success("Password changed.")
                _show_json(result.data, key="password_change")

        st.markdown("---")
        st.markdown("**Reset password (admin)**")
        r1, r2, r3 = st.columns(3)
        reset_email = r1.text_input("Email", key="pwd_reset_email")
        reset_pwd = r2.text_input("New password", type="password", key="pwd_reset_new")
        reset_profile = r3.text_input("Profile optional", key="pwd_reset_profile").strip() or None
        if st.button("Reset password", key="pwd_reset_btn"):
            result = client.password_reset(
                token=token,
                email=reset_email,
                new_password=reset_pwd,
                profile=reset_profile,
            )
            if not result.ok:
                st.error(f"Reset password failed ({result.status_code}).")
                _show_json(result.error, key="password_reset_error")
            else:
                st.success("Password reset.")
                _show_json(result.data, key="password_reset")

    with tabs[2]:
        st.info("Audit event viewer planned for WEB-042. Current events are logged server-side.")


def _settings_page(client: ApiClient) -> None:
    st.subheader("Settings")
    tabs = st.tabs(["Theme", "Config"])
    with tabs[0]:
        options = list(THEMES.keys())
        current_theme = _get_theme()
        selected = st.selectbox("Theme", options=options, index=options.index(current_theme))
        if selected != current_theme:
            _set_theme(selected)
            st.success(f"Theme changed to: {selected}")
            st.rerun()
        st.caption(f"Selected theme: {selected}")
    with tabs[1]:
        config_path = _infobr_home_path("config.json")
        if not config_path.exists():
            st.warning(f"Config file not found: {config_path}")
        else:
            try:
                with config_path.open("r", encoding="utf-8") as fh:
                    config_data = json.load(fh)
            except Exception as exc:
                st.error(f"Unable to read config file: {exc}")
            else:
                _show_json(config_data, key="settings_config", title=str(config_path))
    if get_last_error() is not None:
        st.caption("Last API error")
        _show_json(get_last_error(), key="last_api_error")


def render_app() -> None:
    st.set_page_config(
        page_title="InfoBR Web",
        page_icon="📈",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    _style(_get_theme())

    client = ApiClient()
    session = get_session()
    if not session.authenticated:
        _show_login(client)
        return

    me = client.auth_me(session.access_token or "")
    if not me.ok:
        set_last_error(me.error)
        clear_session()
        st.warning("Session expired or invalid. Please sign in again.")
        _show_login(client)
        return
    me_data = me.data or {}
    if me_data.get("email"):
        st.session_state["user_email"] = me_data.get("email")
    if me_data.get("profile"):
        st.session_state["user_profile"] = str(me_data.get("profile")).upper()
    session = get_session()

    allowed_keys = _allowed_menu_keys(session.profile)
    menu_key = _sidebar(allowed_keys)
    if menu_key not in allowed_keys:
        menu_key = "dashboard"
    _topline(menu_key, client)
    page_map: dict[str, Callable[[], None]] = {
        "dashboard": lambda: _dashboard_page(client),
        "pipelines": lambda: _pipelines_page(client),
        "runs": lambda: _runs_page(client),
        "operations": lambda: _operations_page(client),
        "auth_admin": lambda: _auth_admin_page(client),
        "settings": lambda: _settings_page(client),
    }
    handler = page_map.get(menu_key, lambda: _dashboard_page(client))
    handler()


def main() -> None:
    """Console entrypoint for `infobr-webapp`."""
    os.environ.setdefault("STREAMLIT_SERVER_HEADLESS", "true")
    sys.argv = ["streamlit", "run", __file__]
    raise SystemExit(stcli.main())


if __name__ == "__main__":
    render_app()
