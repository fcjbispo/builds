"""InfoBR operations normalization library."""

import os
from typing import Any, Optional
from infobr import env, logger
from fbpyutils_db.database.operations import table_operation

from .parser import (
    OPERATION_COLUMNS,
    OperationParser,
    parse_operation_directory,
    parse_operation_file,
    parse_operations,
)

__all__ = [
    "OPERATION_COLUMNS",
    "OperationParser",
    "parse_operations",
    "parse_operation_file",
    "parse_operation_directory",
]


def register_operations(
        operations: list[dict[str, Any]] = None, source_path: str = None, operation: str = 'append'
):
    try:
        if operations is not None:
            records = parse_operations(operations=operations, metadata={}, path=None)
        elif source_path and os.path.isfile(source_path) and os.path.exists(source_path):
            records = parse_operation_file(source_path)
        else:
            records = parse_operation_directory(os.path.sep.join([env.USER_APP_FOLDER, 'operations']), pattern="*.json")

        table_schema = 'infobr'
        table_name = 'operations'
        commit_at = 1000
        operation = operation.lower() or 'append'

        result = table_operation(
            operation=operation,
            dataframe=records,
            engine=env.DB,
            table_name=table_name,
            schema=table_schema,
            keys=['id'],
            index='primary',
            commit_at=commit_at,
        )

        return result
    except Exception as e:
        logger.warning(f"Failed to register operations: {e}")