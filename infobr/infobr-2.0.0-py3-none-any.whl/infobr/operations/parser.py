"""Operation result JSON normalization into a common pandas DataFrame schema."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd

# Canonical schema used for both extract and load operation outputs.
OPERATION_COLUMNS: tuple[str, ...] = (
    "id",
    "source_file",
    "source_path",
    "operation_index",
    "data_index",
    "pipeline",
    "operation_type",
    "flow",
    "run_datetime",
    "parsed_at",
    "scope",
    "success",
    "error_message",
    "records",
    "files_processed",
    "input_file_path",
    "output_file_path",
    "target_table",
    "target_schema",
    "dry_run",
    "operation",
    "db_operation",
    "insertions",
    "updates",
    "skips",
    "source_ticker",
    "source_asset_type",
    "source_currency_from",
    "source_currency_to",
    "params_json",
    "errors_json",
    "failures_json",
    "data_payload_json",
    "operation_extra_json",
    "data_extra_json",
)

_OP_KEYS = {"scope", "success", "error_message", "error_msg", "data"}
_DATA_KEYS = {
    "params",
    "records",
    "files_processed",
    "file_path",
    "input_file_path",
    "output_file_path",
    "target_table",
    "schema",
    "dry_run",
    "operation",
    "db_operation",
    "insertions",
    "updates",
    "skips",
    "errors",
    "failures",
}


def _to_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _json_or_none(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)


def _parse_filename_metadata(path: Path) -> dict[str, Any]:
    parts = path.name.removesuffix(".json").split(".")
    result: dict[str, Any] = {
        "pipeline": None,
        "operation_type": None,
        "flow": None,
        "run_datetime": None,
    }

    if len(parts) < 5 or parts[-2] != "out":
        return result

    result["pipeline"] = parts[0]
    result["operation_type"] = parts[1]
    result["flow"] = ".".join(parts[2:-2])
    try:
        result["run_datetime"] = datetime.strptime(parts[-1], "%Y-%m-%d_%H-%M-%S")
    except ValueError:
        result["run_datetime"] = None
    return result


class OperationParser:
    """Parse InfoBR operation JSON files into a normalized pandas DataFrame."""

    columns = OPERATION_COLUMNS

    def parse_file_operations(self, operations: dict[str, Any], metadata: dict[str, Any], path: Optional[str]) -> list[dict[str, Any]]:
        parsed_at = datetime.now()
        rows: list[dict[str, Any]] = []

        for operation_index, operation in enumerate(operations):
            if not isinstance(operation, dict):
                operation = {"scope": None, "success": False, "error_message": "Invalid operation payload", "data": [operation]}

            data_entries = operation.get("data")
            if not isinstance(data_entries, list) or not data_entries:
                data_entries = [None]

            op_extra = {k: v for k, v in operation.items() if k not in _OP_KEYS}

            for data_index, data_entry in enumerate(data_entries):
                row = self._normalize_row(
                    path=path or None,
                    metadata=metadata,
                    operation=operation,
                    operation_index=operation_index,
                    data_entry=data_entry,
                    data_index=data_index,
                    parsed_at=parsed_at,
                    op_extra=op_extra,
                )
                rows.append(row)

        df = pd.DataFrame(rows)
        for column in self.columns:
            if column not in df.columns:
                df[column] = None

        return self._apply_types(df[list(self.columns)])

    def parse_file(self, filepath: str | Path) -> pd.DataFrame:
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"Operation file not found: {path}")

        with path.open("r", encoding="utf-8") as f:
            loaded = json.load(f)

        operations = loaded if isinstance(loaded, list) else [loaded]
        metadata = _parse_filename_metadata(path)

        return self.parse_file_operations(operations=operations, metadata=metadata, path=path) 

    def parse_directory(self, directory: str | Path, pattern: str = "*.json") -> pd.DataFrame:
        base = Path(directory)
        if not base.exists():
            raise FileNotFoundError(f"Directory not found: {base}")

        frames = [self.parse_file(path) for path in sorted(base.glob(pattern))]
        if not frames:
            return pd.DataFrame(columns=self.columns)
        return pd.concat(frames, ignore_index=True)

    def parse_files(self, paths: list[str | Path]) -> pd.DataFrame:
        frames = [self.parse_file(path) for path in paths]
        if not frames:
            return pd.DataFrame(columns=self.columns)
        return pd.concat(frames, ignore_index=True)

    def _normalize_row(
        self,
        path: Path,
        metadata: dict[str, Any],
        operation: dict[str, Any],
        operation_index: int,
        data_entry: Any,
        data_index: int,
        parsed_at: datetime,
        op_extra: dict[str, Any],
    ) -> dict[str, Any]:
        data = data_entry if isinstance(data_entry, dict) else {}
        params = data.get("params") if isinstance(data.get("params"), dict) else {}
        data_extra = {k: v for k, v in data.items() if k not in _DATA_KEYS}

        record_content = "|".join(
            [
                str(path),
                str(operation_index),
                str(data_index),
                str(metadata.get("pipeline")),
                str(metadata.get("operation_type")),
                str(metadata.get("flow")),
                str(operation.get("scope")),
            ]
        )
        id = hashlib.sha256(record_content.encode("utf-8")).hexdigest()[:32]

        return {
            "id": id,
            "source_file": path.name,
            "source_path": str(path),
            "operation_index": operation_index,
            "data_index": data_index,
            "pipeline": metadata.get("pipeline"),
            "operation_type": metadata.get("operation_type"),
            "flow": metadata.get("flow"),
            "run_datetime": metadata.get("run_datetime"),
            "parsed_at": parsed_at,
            "scope": operation.get("scope"),
            "success": operation.get("success"),
            "error_message": operation.get("error_message") or operation.get("error_msg"),
            "records": _to_int(data.get("records")),
            "files_processed": _to_int(data.get("files_processed")),
            "input_file_path": data.get("input_file_path") or data.get("file_path"),
            "output_file_path": data.get("output_file_path"),
            "target_table": data.get("target_table"),
            "target_schema": data.get("schema"),
            "dry_run": data.get("dry_run"),
            "operation": data.get("operation"),
            "db_operation": data.get("db_operation"),
            "insertions": _to_int(data.get("insertions")),
            "updates": _to_int(data.get("updates")),
            "skips": _to_int(data.get("skips")),
            "source_ticker": params.get("ticker"),
            "source_asset_type": params.get("asset_type"),
            "source_currency_from": params.get("currency_from"),
            "source_currency_to": params.get("currency_to"),
            "params_json": _json_or_none(params if params else None),
            "errors_json": _json_or_none(data.get("errors")),
            "failures_json": _json_or_none(data.get("failures")),
            "data_payload_json": _json_or_none(data_entry),
            "operation_extra_json": _json_or_none(op_extra if op_extra else None),
            "data_extra_json": _json_or_none(data_extra if data_extra else None),
        }

    @staticmethod
    def _apply_types(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["run_datetime"] = pd.to_datetime(df["run_datetime"], errors="coerce")
        df["parsed_at"] = pd.to_datetime(df["parsed_at"], errors="coerce")
        df["operation_index"] = pd.to_numeric(df["operation_index"], errors="coerce").astype("Int64")
        df["data_index"] = pd.to_numeric(df["data_index"], errors="coerce").astype("Int64")
        df["records"] = pd.to_numeric(df["records"], errors="coerce").astype("Int64")
        df["files_processed"] = pd.to_numeric(df["files_processed"], errors="coerce").astype("Int64")
        df["insertions"] = pd.to_numeric(df["insertions"], errors="coerce").astype("Int64")
        df["updates"] = pd.to_numeric(df["updates"], errors="coerce").astype("Int64")
        df["skips"] = pd.to_numeric(df["skips"], errors="coerce").astype("Int64")

        if "success" in df.columns:
            df["success"] = df["success"].astype("boolean")
        if "dry_run" in df.columns:
            df["dry_run"] = df["dry_run"].astype("boolean")
        return df


def parse_operations(operations: dict[str, Any], metadata: dict[str, Any], path: Optional[str]) -> list[dict[str, Any]]:
    """Parse a list of operation dicts into the canonical schema."""
    return OperationParser().parse_file_operations(operations=operations, metadata=metadata, path=path)

def parse_operation_file(filepath: str | Path) -> pd.DataFrame:
    """Parse one operation result file into the canonical DataFrame schema."""
    return OperationParser().parse_file(filepath)


def parse_operation_directory(directory: str | Path, pattern: str = "*.json") -> pd.DataFrame:
    """Parse operation result files in a directory into the canonical schema."""
    return OperationParser().parse_directory(directory, pattern=pattern)
