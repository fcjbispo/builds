"""Reusable pipeline domain services for TUI and API."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from glob import glob
from typing import Any

from infobr import env, logger
from infobr.data.pipeline import Pipeline
from fbpyutils import file as F


PIPELINE_MASK = "*.json"


@dataclass(frozen=True)
class PipelineInfo:
    """Pipeline file metadata."""

    name: str
    path: str
    exists: bool
    updated_at: datetime | None


@dataclass(frozen=True)
class PipelineRunStats:
    """Execution aggregate stats from operation output."""

    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float


@dataclass(frozen=True)
class PipelineRunResult:
    """Pipeline execution service result."""

    pipeline_name: str
    success: bool
    operation_file: str | None
    stats: PipelineRunStats | None


def _pipelines_dir(pipelines_dir: str | None = None) -> str:
    return pipelines_dir or os.path.sep.join([env.USER_APP_FOLDER, "pipelines"])


def _operations_dir(operations_dir: str | None = None) -> str:
    return operations_dir or os.path.sep.join([env.USER_APP_FOLDER, "operations"])


def _pipeline_path(pipeline_name: str, pipelines_dir: str | None = None) -> str:
    return os.path.sep.join([_pipelines_dir(pipelines_dir), f"{pipeline_name}.json"])


def list_pipelines(pipelines_dir: str | None = None) -> list[PipelineInfo]:
    """List available pipeline definitions sorted by name."""
    folder = _pipelines_dir(pipelines_dir)
    if not os.path.exists(folder):
        return []

    pipelines: list[PipelineInfo] = []
    for path in F.find(folder, PIPELINE_MASK):
        name = os.path.basename(path).replace(".json", "")
        exists = os.path.exists(path)
        updated_at = None
        if exists:
            updated_at = datetime.fromtimestamp(os.path.getmtime(path))
        pipelines.append(
            PipelineInfo(
                name=name,
                path=path,
                exists=exists,
                updated_at=updated_at,
            )
        )

    return sorted(pipelines, key=lambda item: item.name)


def validate_pipeline_exists(pipeline_name: str, pipelines_dir: str | None = None) -> None:
    """Validate pipeline file existence."""
    if not pipeline_name:
        raise ValueError("pipeline_name must be provided")

    if not os.path.exists(_pipeline_path(pipeline_name, pipelines_dir)):
        raise FileNotFoundError(f"Pipeline not found: {pipeline_name}")


def get_pipeline_config(pipeline_name: str, pipelines_dir: str | None = None) -> dict[str, Any]:
    """Read and return pipeline JSON configuration."""
    validate_pipeline_exists(pipeline_name, pipelines_dir)
    path = _pipeline_path(pipeline_name, pipelines_dir)
    with open(path, "r", encoding="utf-8") as f:
        config = json.load(f)
    if not isinstance(config, dict):
        raise ValueError(f"Invalid pipeline config format for '{pipeline_name}'")
    return config


def estimate_pipeline_items(pipeline_name: str, pipelines_dir: str | None = None) -> int:
    """
    Best-effort estimate of items to process.

    Mirrors current TUI behavior and falls back to 0 when estimate is unavailable.
    """
    try:
        config = get_pipeline_config(pipeline_name, pipelines_dir)
        scopes = config.get("scopes", [])
        total = 0

        import polars as pl

        for scope in scopes:
            scope_value = str(scope).lower()
            if "fii" in scope_value:
                total += pl.read_database(
                    "select count(*) as n from infobr.ativos where tipo = 'fii' and ativo = 1",
                    env.DB,
                )[0, 0]
            elif "etf" in scope_value:
                total += pl.read_database(
                    "select count(*) as n from infobr.ativos where tipo = 'etf' and ativo = 1",
                    env.DB,
                )[0, 0]
            elif "fx" in scope_value:
                total += (
                    pl.read_database(
                        "select count(*) as n from infobr.ativos where tipo = 'fx' and ativo = 1",
                        env.DB,
                    )[0, 0]
                    * 2
                )
        return int(total)
    except Exception as exc:
        logger.warning(f"Could not estimate pipeline items for '{pipeline_name}': {exc}")
        return 0


def _latest_operation_file(pipeline_name: str, operations_dir: str | None = None) -> str | None:
    pattern = os.path.sep.join([_operations_dir(operations_dir), f"{pipeline_name}.out.*.json"])
    matches = glob(pattern)
    if not matches:
        return None
    return max(matches, key=os.path.getmtime)


def _summarize_operation_file(path: str | None) -> PipelineRunStats | None:
    if not path or not os.path.exists(path):
        return None
    if os.path.getsize(path) == 0:
        return None

    with open(path, "r", encoding="utf-8") as f:
        loaded = json.load(f)
    if not isinstance(loaded, list):
        return None

    total = len(loaded)
    if total == 0:
        return PipelineRunStats(
            total_operations=0,
            successful_operations=0,
            failed_operations=0,
            success_rate=0.0,
        )

    successful = sum(1 for row in loaded if isinstance(row, dict) and row.get("success", False))
    failed = total - successful
    return PipelineRunStats(
        total_operations=total,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=(successful / total) * 100,
    )


def run_pipeline(
    pipeline_name: str,
    *,
    parallelize: bool = True,
    progress: bool = False,
    progress_callback=None,
) -> PipelineRunResult:
    """Execute one pipeline and return a normalized run result."""
    validate_pipeline_exists(pipeline_name)

    pipeline = Pipeline(pipeline_name)
    if not pipeline.load():
        raise ValueError(f"Pipeline '{pipeline_name}' could not be loaded.")

    pipeline.run(
        parallelize=parallelize,
        progress=progress,
        progress_callback=progress_callback,
    )

    operation_file = _latest_operation_file(pipeline_name)
    stats = _summarize_operation_file(operation_file)

    return PipelineRunResult(
        pipeline_name=pipeline_name,
        success=True,
        operation_file=operation_file,
        stats=stats,
    )
