"""Reusable operation/result services for TUI and API."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from glob import glob
from pathlib import Path
from typing import Any

from infobr import env
from infobr.operations import OperationParser


@dataclass(frozen=True)
class OperationFileInfo:
    """Operation output file metadata."""

    path: str
    name: str
    pipeline_name: str
    run_timestamp: str
    file_size: int
    modified_at: datetime


@dataclass(frozen=True)
class OperationSummaryError:
    """Error entry from operation output."""

    scope: str | None
    error_message: str


@dataclass(frozen=True)
class OperationSummary:
    """Aggregate summary for an operation output file."""

    file_path: str
    total_operations: int
    successful_operations: int
    failed_operations: int
    success_rate: float
    errors: list[OperationSummaryError]


@dataclass(frozen=True)
class OperationPage:
    """Paginated operation entries."""

    file_path: str
    page: int
    page_size: int
    total_records: int
    total_pages: int
    items: list[dict[str, Any]]


def _operations_dir(operations_dir: str | None = None) -> str:
    return operations_dir or os.path.sep.join([env.USER_APP_FOLDER, "operations"])


def _decode_operation_filename(path: str) -> tuple[str, str]:
    basename = os.path.basename(path)
    parts = basename.split(".out.")
    pipeline_name = parts[0] if parts else ""
    run_timestamp = parts[1].replace(".json", "") if len(parts) > 1 else ""
    return pipeline_name, run_timestamp


def list_operation_files(
    *,
    limit: int = 10,
    pipeline_name: str | None = None,
    operations_dir: str | None = None,
) -> list[OperationFileInfo]:
    """List recent valid operation output files."""
    if limit < 1:
        raise ValueError("limit must be >= 1")

    folder = _operations_dir(operations_dir)
    pattern = "*.out.*.json"
    if pipeline_name:
        pattern = f"{pipeline_name}.out.*.json"

    files = sorted(
        glob(os.path.sep.join([folder, pattern])),
        key=os.path.getmtime,
        reverse=True,
    )

    result: list[OperationFileInfo] = []
    for path in files:
        try:
            file_size = os.path.getsize(path)
            if file_size <= 0:
                continue
            modified_at = datetime.fromtimestamp(os.path.getmtime(path))
            parsed_pipeline, run_timestamp = _decode_operation_filename(path)
            result.append(
                OperationFileInfo(
                    path=path,
                    name=os.path.basename(path),
                    pipeline_name=parsed_pipeline,
                    run_timestamp=run_timestamp,
                    file_size=file_size,
                    modified_at=modified_at,
                )
            )
            if len(result) >= limit:
                break
        except (OSError, PermissionError):
            continue
    return result


def read_operation_file(path: str, *, max_size_mb: int = 50) -> list[dict[str, Any]]:
    """Read operation result file with safety checks."""
    if not path:
        raise ValueError("path must be provided")
    if max_size_mb < 1:
        raise ValueError("max_size_mb must be >= 1")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Operation file not found: {path}")

    max_size = max_size_mb * 1024 * 1024
    file_size = os.path.getsize(path)
    if file_size > max_size:
        raise ValueError(
            f"Operation file is too large ({file_size / 1024 / 1024:.1f} MB). "
            f"Maximum allowed: {max_size_mb} MB"
        )

    with open(path, "r", encoding="utf-8") as f:
        loaded = json.load(f)

    if not isinstance(loaded, list):
        raise ValueError("Invalid operation file format. Expected JSON array.")

    return [row if isinstance(row, dict) else {"data": row} for row in loaded]


def get_operation_record(path: str, *, index: int) -> dict[str, Any]:
    """Return one operation record by index."""
    if index < 0:
        raise ValueError("index must be >= 0")
    records = read_operation_file(path)
    if index >= len(records):
        raise IndexError("operation record index out of range")
    return records[index]


def get_operation_page(
    path: str,
    *,
    page: int,
    page_size: int = 50,
) -> OperationPage:
    """Return paginated operation records (1-based page index)."""
    if page < 1:
        raise ValueError("page must be >= 1")
    if page_size < 1:
        raise ValueError("page_size must be >= 1")

    records = read_operation_file(path)
    total_records = len(records)
    total_pages = (total_records + page_size - 1) // page_size if total_records else 0

    if total_pages == 0:
        items: list[dict[str, Any]] = []
    else:
        if page > total_pages:
            raise ValueError(f"page must be between 1 and {total_pages}")
        start = (page - 1) * page_size
        end = start + page_size
        items = records[start:end]

    return OperationPage(
        file_path=path,
        page=page,
        page_size=page_size,
        total_records=total_records,
        total_pages=total_pages,
        items=items,
    )


def summarize_operation_file(path: str) -> OperationSummary:
    """Aggregate operation output summary from one file."""
    records = read_operation_file(path)
    total = len(records)
    successful = sum(1 for row in records if row.get("success", False))
    failed = total - successful
    success_rate = (successful / total * 100) if total else 0.0

    errors: list[OperationSummaryError] = []
    for row in records:
        if row.get("success", False):
            continue
        message = row.get("error_message")
        if message:
            errors.append(
                OperationSummaryError(
                    scope=row.get("scope"),
                    error_message=str(message),
                )
            )

    return OperationSummary(
        file_path=path,
        total_operations=total,
        successful_operations=successful,
        failed_operations=failed,
        success_rate=success_rate,
        errors=errors,
    )


def summarize_pipeline_execution(
    pipeline_name: str,
    *,
    operations_dir: str | None = None,
) -> OperationSummary | None:
    """Summarize latest operation output for one pipeline."""
    matches = list_operation_files(
        limit=1,
        pipeline_name=pipeline_name,
        operations_dir=operations_dir,
    )
    if not matches:
        return None
    return summarize_operation_file(matches[0].path)


def parse_operation_file(path: str):
    """Parse one operation output file into canonical dataframe schema."""
    return OperationParser().parse_file(Path(path))


def parse_operation_files(paths: list[str]):
    """Parse many operation output files into canonical dataframe schema."""
    return OperationParser().parse_files([Path(p) for p in paths])


def parse_operation_directory(
    operations_dir: str | None = None,
    *,
    pattern: str = "*.json",
):
    """Parse operation output files from a directory into canonical dataframe schema."""
    return OperationParser().parse_directory(_operations_dir(operations_dir), pattern=pattern)
