"""API-041: integration tests for critical endpoint flow."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin
from infobr.api.main import app
from infobr.api.services.pipeline_runner import RunDispatchResult
from infobr.services.operations import OperationPage, OperationSummary, OperationSummaryError


def _admin_token():
    return SimpleNamespace(email="admin@example.com", profile="ADMIN", token_prefix="admintok")


def test_critical_flow_create_token_dispatch_run_and_fetch_results(monkeypatch):
    app.dependency_overrides[require_admin] = _admin_token

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace()
        session.expunge = lambda _obj: None
        yield session

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

    def fake_issue_token(_repo, **_kwargs):
        token = SimpleNamespace(
            id="tok-admin-1",
            email="client@example.com",
            profile="ADMIN",
            token_prefix="rawtoken",
            expires_at=None,
            is_active=True,
            last_used_at=None,
            created_at=datetime.now(timezone.utc),
            updated_at=None,
            created_by="admin@example.com",
        )
        return token, "raw-token-value"

    monkeypatch.setattr("infobr.api.routers.auth.session_scope", fake_session_scope)
    monkeypatch.setattr("infobr.api.routers.auth.TokenRepository", FakeTokenRepo)
    monkeypatch.setattr("infobr.api.routers.auth.TokenService.issue_token", fake_issue_token)

    monkeypatch.setattr("infobr.api.routers.pipelines.validate_pipeline_exists", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        "infobr.api.routers.pipelines.PipelineRunnerService.dispatch_run",
        lambda **_kwargs: RunDispatchResult(run_id="run-001", status="queued"),
    )

    run_obj = SimpleNamespace(
        id="run-001",
        pipeline_name="series.extract.full",
        status="success",
        requested_by="admin@example.com",
        params_json='{"parallelize": true}',
        started_at=datetime.now(timezone.utc),
        finished_at=datetime.now(timezone.utc),
        error_message=None,
        operation_output_path="/tmp/series.extract.full.out.2026-02-20_10-00-00.json",
        created_at=datetime.now(timezone.utc),
        updated_at=None,
    )
    monkeypatch.setattr(
        "infobr.api.routers.runs.PipelineRunnerService.get_run",
        lambda _run_id: run_obj,
    )
    monkeypatch.setattr(
        "infobr.api.routers.runs.get_operation_page",
        lambda *_args, **_kwargs: OperationPage(
            file_path=run_obj.operation_output_path,
            page=1,
            page_size=50,
            total_records=2,
            total_pages=1,
            items=[{"id": "op1", "success": True}, {"id": "op2", "success": False}],
        ),
    )
    monkeypatch.setattr(
        "infobr.api.routers.runs.summarize_operation_file",
        lambda *_args, **_kwargs: OperationSummary(
            file_path=run_obj.operation_output_path,
            total_operations=2,
            successful_operations=1,
            failed_operations=1,
            success_rate=50.0,
            errors=[OperationSummaryError(scope="BBB", error_message="db error")],
        ),
    )

    client = TestClient(app)

    create_token_resp = client.post(
        "/api/v1/auth/tokens",
        json={"email": "client@example.com", "profile": "ADMIN"},
    )
    assert create_token_resp.status_code == 201
    assert create_token_resp.json()["token"]["email"] == "client@example.com"
    assert create_token_resp.json()["raw_token"] == "raw-token-value"

    dispatch_resp = client.post(
        "/api/v1/pipelines/series.extract.full/runs",
        json={"parallelize": True, "progress": False, "params": {"scope": "ALL"}},
    )
    assert dispatch_resp.status_code == 202
    assert dispatch_resp.json()["run_id"] == "run-001"

    run_detail_resp = client.get("/api/v1/runs/run-001")
    assert run_detail_resp.status_code == 200
    assert run_detail_resp.json()["status"] == "success"

    run_results_resp = client.get("/api/v1/runs/run-001/results?page=1&page_size=50")
    assert run_results_resp.status_code == 200
    payload = run_results_resp.json()
    assert payload["run_id"] == "run-001"
    assert payload["total_operations"] == 2
    assert payload["failed_operations"] == 1
    assert len(payload["items"]) == 2

    app.dependency_overrides.clear()


def test_run_results_returns_409_while_running(monkeypatch):
    app.dependency_overrides[require_admin] = _admin_token
    running_run = SimpleNamespace(
        id="run-002",
        pipeline_name="series.load.full",
        status="running",
        requested_by="admin@example.com",
        params_json="{}",
        started_at=datetime.now(timezone.utc),
        finished_at=None,
        error_message=None,
        operation_output_path=None,
        created_at=datetime.now(timezone.utc),
        updated_at=None,
    )
    monkeypatch.setattr(
        "infobr.api.routers.runs.PipelineRunnerService.get_run",
        lambda _run_id: running_run,
    )

    client = TestClient(app)
    resp = client.get("/api/v1/runs/run-002/results")
    assert resp.status_code == 409
    assert "in progress" in resp.json()["details"]

    app.dependency_overrides.clear()
