"""API-045: scope-level concurrency lock for pipeline dispatch."""

from __future__ import annotations

from contextlib import contextmanager
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin
from infobr.api.main import app
from infobr.api.routers import pipelines as pipelines_router
from infobr.api.services.pipeline_runner import PipelineRunnerService, ScopeConflictError


def test_dispatch_run_blocks_when_scope_conflicts(monkeypatch):
    active_run = SimpleNamespace(
        id="run-active-1",
        pipeline_name="series.extract.full",
        params_json='{"scope":"FII_PRICES"}',
        status="running",
    )

    class FakeRepo:
        def __init__(self, _session):
            self.create_called = False

        def list_active(self):
            return [active_run]

        def create(self, **_kwargs):
            self.create_called = True
            raise AssertionError("create must not be called on scope conflict")

    @contextmanager
    def fake_session_scope():
        yield SimpleNamespace()

    monkeypatch.setattr("infobr.api.services.pipeline_runner.session_scope", fake_session_scope)
    monkeypatch.setattr("infobr.api.services.pipeline_runner.PipelineRunRepository", FakeRepo)
    monkeypatch.setattr(
        "infobr.api.services.pipeline_runner.get_pipeline_config",
        lambda _name: {"scopes": ["FII_PRICES", "FII_DY"]},
    )

    with pytest.raises(ScopeConflictError) as exc:
        PipelineRunnerService.dispatch_run(
            pipeline_name="series.extract.full",
            requested_by="admin@example.com",
            params={"scope": "FII_PRICES"},
        )
    assert "FII_PRICES" in str(exc.value)
    assert "run-active-1" in str(exc.value)


def test_pipeline_dispatch_route_returns_409_on_scope_conflict(monkeypatch):
    app.dependency_overrides[require_admin] = lambda: SimpleNamespace(
        email="admin@example.com", profile="ADMIN"
    )
    monkeypatch.setattr(pipelines_router, "validate_pipeline_exists", lambda *_a, **_k: None)
    monkeypatch.setattr(
        pipelines_router.PipelineRunnerService,
        "dispatch_run",
        lambda **_kwargs: (_ for _ in ()).throw(
            ScopeConflictError(
                requested_scopes=("FII_PRICES",),
                conflicting_scopes=("FII_PRICES",),
                conflicting_run_ids=("run-active-1",),
            )
        ),
    )

    client = TestClient(app)
    resp = client.post(
        "/api/v1/pipelines/series.extract.full/runs",
        json={"parallelize": True, "progress": False, "params": {"scope": "FII_PRICES"}},
    )
    assert resp.status_code == 409
    payload = resp.json()
    assert "details" in payload
    assert payload["details"]["conflicting_scopes"] == ["FII_PRICES"]
    assert payload["details"]["conflicting_run_ids"] == ["run-active-1"]

    app.dependency_overrides.clear()
