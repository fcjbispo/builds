"""WEB-042: unit tests for auth/password hardening rules."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from infobr.api.main import app
from infobr.api.routers import auth
from infobr.api.services.passwords import PasswordService


def test_password_policy_rejects_whitespace_and_respects_min_length(monkeypatch):
    monkeypatch.setenv("INFOBR_PASSWORD_MIN_LENGTH", "10")

    with pytest.raises(ValueError):
        PasswordService.hash_password("Admin123")

    with pytest.raises(ValueError):
        PasswordService.hash_password("Admin 1234")


def test_login_route_returns_429_when_rate_limited(monkeypatch):
    emitted: list[dict] = []

    class DenyingLimiter:
        @staticmethod
        def allow(_key: str):
            return False, 5

    monkeypatch.setattr(auth, "login_rate_limiter", DenyingLimiter())
    monkeypatch.setattr(auth, "audit_security_event", lambda **kwargs: emitted.append(kwargs))

    client = TestClient(app)
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@example.com", "password": "Admin123"},
    )

    assert resp.status_code == 429
    assert resp.headers.get("Retry-After") == "5"
    assert emitted[-1]["event"] == "auth.login"
    assert emitted[-1]["reason"] == "rate_limited"


def test_login_failure_after_expired_lock_resets_attempt_counter(monkeypatch):
    row = SimpleNamespace(
        id="cred-1",
        email="admin@example.com",
        profile="ADMIN",
        is_active=True,
        failed_attempts=7,
        locked_until=(datetime.now(timezone.utc) - timedelta(minutes=1)).replace(tzinfo=None),
        password_hash=PasswordService.hash_password("Admin123"),
    )
    captured: dict[str, object] = {}

    class FakeCredRepo:
        def get_by_email(self, _email: str):
            return row

        def register_login_failure(self, _row_id: str, *, failed_attempts: int | None, lock_until):
            captured["failed_attempts"] = failed_attempts
            captured["lock_until"] = lock_until
            return row

        def register_login_success(self, _row_id: str):
            return row

    with pytest.raises(ValueError):
        PasswordService.login(
            FakeCredRepo(),
            token_repo=SimpleNamespace(),
            email="admin@example.com",
            password="Wrong123",
        )

    assert captured["failed_attempts"] == 1
    assert captured["lock_until"] is None
