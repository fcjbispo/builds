"""API-040: unit tests for auth/tokens/rbac."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from infobr.api.dependencies import security
from infobr.api.services.tokens import TokenService


def _token(**kwargs):
    base = {
        "id": "tok1",
        "email": "user@example.com",
        "token_hash": "x",
        "token_prefix": "tok1pref",
        "is_active": True,
        "expires_at": None,
        "profile": "USER",
    }
    base.update(kwargs)
    return SimpleNamespace(**base)


def test_normalize_profile_accepts_user_admin():
    assert TokenService.normalize_profile("user") == "USER"
    assert TokenService.normalize_profile(" ADMIN ") == "ADMIN"


def test_normalize_profile_rejects_invalid():
    with pytest.raises(ValueError):
        TokenService.normalize_profile("guest")


def test_hash_token_is_deterministic_and_uses_pepper():
    t1 = TokenService.hash_token("raw-token", pepper="pep1")
    t2 = TokenService.hash_token("raw-token", pepper="pep1")
    t3 = TokenService.hash_token("raw-token", pepper="pep2")
    assert t1 == t2
    assert t1 != t3


def test_is_expired_handles_none_and_future_and_past():
    now = datetime.now(timezone.utc)
    assert TokenService.is_expired(None, now=now) is False
    assert TokenService.is_expired(now + timedelta(minutes=1), now=now) is False
    assert TokenService.is_expired(now - timedelta(minutes=1), now=now) is True


def test_validate_bearer_token_success_and_touch():
    raw = "abc123"
    token_hash = TokenService.hash_token(raw)
    tok = _token(id="tok-ok", token_hash=token_hash, is_active=True, expires_at=None)

    class Repo:
        def __init__(self):
            self.touched = False

        def get_by_token_hash(self, value):
            return tok if value == token_hash else None

        def touch_last_used(self, token_id):
            assert token_id == "tok-ok"
            self.touched = True
            return tok

    repo = Repo()
    result = TokenService.validate_bearer_token(repo, raw_token=raw, touch_last_used=True)
    assert result is tok
    assert repo.touched is True


def test_validate_bearer_token_fails_for_missing_inactive_or_expired():
    raw = "abc123"
    token_hash = TokenService.hash_token(raw)
    expired = datetime.now(timezone.utc) - timedelta(seconds=1)

    class RepoMissing:
        def get_by_token_hash(self, _):
            return None

    class RepoInactive:
        def get_by_token_hash(self, _):
            return _token(token_hash=token_hash, is_active=False)

    class RepoExpired:
        def get_by_token_hash(self, _):
            return _token(token_hash=token_hash, is_active=True, expires_at=expired)

    assert TokenService.validate_bearer_token(RepoMissing(), raw_token=raw) is None
    assert TokenService.validate_bearer_token(RepoInactive(), raw_token=raw) is None
    assert TokenService.validate_bearer_token(RepoExpired(), raw_token=raw) is None


def test_require_user_and_require_admin_rules():
    user = _token(profile="USER")
    admin = _token(profile="ADMIN")
    guest = _token(profile="GUEST")

    assert security.require_user(user) is user
    assert security.require_user(admin) is admin
    with pytest.raises(HTTPException) as exc:
        security.require_user(guest)
    assert exc.value.status_code == 403

    assert security.require_admin(admin) is admin
    with pytest.raises(HTTPException) as exc2:
        security.require_admin(user)
    assert exc2.value.status_code == 403


def test_get_current_token_rejects_empty_credentials():
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="   ")
    with pytest.raises(HTTPException) as exc:
        security.get_current_token(creds)
    assert exc.value.status_code == 401


def test_get_current_token_success_and_invalid(monkeypatch):
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="token-ok")
    token_ok = _token(profile="ADMIN")

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunged=False)
        session.expunge = lambda _obj: setattr(session, "expunged", True)
        yield session

    class Repo:
        def __init__(self, _session):
            pass

    monkeypatch.setattr(security, "session_scope", fake_session_scope)
    monkeypatch.setattr(security, "TokenRepository", Repo)

    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: token_ok,
    )
    assert security.get_current_token(creds) is token_ok

    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: None,
    )
    with pytest.raises(HTTPException) as exc:
        security.get_current_token(creds)
    assert exc.value.status_code == 401
