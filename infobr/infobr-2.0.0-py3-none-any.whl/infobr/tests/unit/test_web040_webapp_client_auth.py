"""WEB-040: unit tests for webapp ApiClient auth/admin methods."""

from __future__ import annotations

from datetime import datetime, timezone

from infobr.webapp.client import ApiClient, ApiResult


def test_client_login_logout_delegate_to_request(monkeypatch):
    calls: list[dict] = []

    def fake_request(self, method, path, **kwargs):
        calls.append({"method": method, "path": path, **kwargs})
        return ApiResult(ok=True, status_code=200, data={"ok": True})

    monkeypatch.setattr(ApiClient, "_request", fake_request)
    client = ApiClient(base_url="http://localhost:8000/api/v1")

    client.login(email="USER@EXAMPLE.COM", password="Secret123")
    client.logout(token="abc")

    assert calls[0]["method"] == "POST"
    assert calls[0]["path"] == "/auth/login"
    assert calls[0]["json_payload"]["email"] == "user@example.com"
    assert calls[1]["path"] == "/auth/logout"
    assert calls[1]["token"] == "abc"


def test_client_password_and_token_management_payloads(monkeypatch):
    calls: list[dict] = []

    def fake_request(self, method, path, **kwargs):
        calls.append({"method": method, "path": path, **kwargs})
        return ApiResult(ok=True, status_code=200, data={"ok": True})

    monkeypatch.setattr(ApiClient, "_request", fake_request)
    client = ApiClient(base_url="http://localhost:8000/api/v1")

    expires_at = datetime(2026, 2, 20, 12, 0, tzinfo=timezone.utc)
    client.create_token(token="admin", email="X@Y.COM", profile="admin", expires_at=expires_at)
    client.list_tokens(token="admin", offset=10, limit=20, email="A@B.COM", profile="user", is_active=True)
    client.revoke_token(token="admin", token_id="tok1")
    client.rotate_token(token="admin", token_id="tok1", expires_at=expires_at)
    client.password_set(token="admin", email="A@B.COM", profile="USER", password="Abcd1234")
    client.password_change(token="tok-user", current_password="Old12345", new_password="New12345")
    client.password_reset(
        token="admin",
        email="A@B.COM",
        new_password="Reset1234",
        profile="ADMIN",
    )

    assert calls[0]["path"] == "/auth/tokens"
    assert calls[0]["json_payload"]["email"] == "x@y.com"
    assert calls[0]["json_payload"]["profile"] == "ADMIN"
    assert calls[0]["json_payload"]["expires_at"].startswith("2026-02-20T12:00:00")

    assert calls[1]["path"] == "/auth/tokens"
    assert calls[1]["query_params"]["offset"] == 10
    assert calls[1]["query_params"]["profile"] == "USER"

    assert calls[2]["path"] == "/auth/tokens/tok1/revoke"
    assert calls[3]["path"] == "/auth/tokens/tok1/rotate"
    assert calls[4]["path"] == "/auth/password/set"
    assert calls[5]["path"] == "/auth/password/change"
    assert calls[6]["path"] == "/auth/password/reset"
    assert calls[6]["json_payload"]["profile"] == "ADMIN"

