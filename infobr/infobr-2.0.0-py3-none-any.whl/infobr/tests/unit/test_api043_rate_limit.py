"""API-043: unit tests for per-token rate limit."""

from __future__ import annotations

from contextlib import contextmanager
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from infobr.api.dependencies import security
from infobr.api.services.rate_limit import InMemoryRateLimiter


def test_inmemory_rate_limiter_blocks_after_limit_and_recovers_after_window():
    limiter = InMemoryRateLimiter(max_requests=2, window_seconds=10)
    assert limiter.allow("tok1", now_ts=100.0) == (True, 0)
    assert limiter.allow("tok1", now_ts=101.0) == (True, 0)

    allowed, retry_after = limiter.allow("tok1", now_ts=102.0)
    assert allowed is False
    assert retry_after > 0

    assert limiter.allow("tok1", now_ts=111.1) == (True, 0)


def test_get_current_token_returns_429_when_rate_limited(monkeypatch):
    token_ok = SimpleNamespace(
        id="tok-limited",
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="tklim",
    )
    emitted: list[dict] = []

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class Repo:
        def __init__(self, _session):
            pass

    class DenyingLimiter:
        @staticmethod
        def allow(_key):
            return False, 7

    monkeypatch.setattr(security, "session_scope", fake_session_scope)
    monkeypatch.setattr(security, "TokenRepository", Repo)
    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: token_ok,
    )
    monkeypatch.setattr(security, "rate_limiter", DenyingLimiter())
    monkeypatch.setattr(
        security,
        "audit_security_event",
        lambda **kwargs: emitted.append(kwargs),
    )

    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="token-ok")
    with pytest.raises(HTTPException) as exc:
        security.get_current_token(creds)

    assert exc.value.status_code == 429
    assert exc.value.headers["Retry-After"] == "7"
    assert emitted[-1]["event"] == "token.use"
    assert emitted[-1]["outcome"] == "denied"
    assert emitted[-1]["reason"] == "rate_limited"

