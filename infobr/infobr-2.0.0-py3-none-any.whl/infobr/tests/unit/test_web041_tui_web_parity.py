"""WEB-041: regression checks for TUI-to-Web functional parity surface."""

from __future__ import annotations

from infobr.webapp import app
from infobr.webapp.client import ApiClient


def test_menu_visibility_matches_expected_rbac():
    user_keys = app._allowed_menu_keys("USER")
    admin_keys = app._allowed_menu_keys("ADMIN")

    assert user_keys == ["dashboard", "settings"]
    assert admin_keys == [key for key, _label in app.MENU_ITEMS]


def test_web_menu_covers_tui_core_modules():
    keys = [key for key, _label in app.MENU_ITEMS]

    assert "pipelines" in keys
    assert "runs" in keys
    assert "operations" in keys


def test_api_client_exposes_tui_equivalent_operations():
    client = ApiClient(base_url="http://localhost:8000/api/v1")

    assert callable(client.list_pipelines)
    assert callable(client.get_pipeline)
    assert callable(client.dispatch_pipeline_run)
    assert callable(client.list_runs)
    assert callable(client.get_run)
    assert callable(client.get_run_results)
    assert callable(client.list_operations)
    assert callable(client.get_operation)
