"""WEB-011/WEB-012: tests for password auth endpoints and service rules."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from types import SimpleNamespace

from fastapi.testclient import TestClient

from infobr.api.dependencies.security import require_admin, require_user
from infobr.api.main import app
from infobr.api.routers import auth
from infobr.api.services.passwords import PasswordService


def test_password_hash_and_verify_roundtrip():
    password_hash = PasswordService.hash_password("Admin123")
    assert PasswordService.verify_password("Admin123", password_hash) is True
    assert PasswordService.verify_password("wrong123", password_hash) is False


def test_login_endpoint_success(monkeypatch):
    token = SimpleNamespace(
        id="tok-login-1",
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="tokpref",
        expires_at=datetime.now(timezone.utc),
    )

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class FakeCredRepo:
        def __init__(self, _session):
            pass

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

    monkeypatch.setattr(auth, "session_scope", fake_session_scope)
    monkeypatch.setattr(auth, "AppCredentialRepository", FakeCredRepo)
    monkeypatch.setattr(auth, "TokenRepository", FakeTokenRepo)
    monkeypatch.setattr(
        auth.PasswordService,
        "login",
        lambda *_args, **_kwargs: (token, "raw-login-token"),
    )

    client = TestClient(app)
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@example.com", "password": "Admin123"},
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["access_token"] == "raw-login-token"
    assert payload["email"] == "admin@example.com"
    assert payload["profile"] == "ADMIN"


def test_password_management_endpoints(monkeypatch):
    app.dependency_overrides[require_admin] = lambda: SimpleNamespace(
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="admintok",
        id="admin-token-id",
    )
    app.dependency_overrides[require_user] = lambda: SimpleNamespace(
        email="user@example.com",
        profile="USER",
        token_prefix="usertok",
        id="user-token-id",
    )

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class FakeCredRepo:
        def __init__(self, _session):
            pass

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

        def revoke(self, _token_id):
            return True

    cred = SimpleNamespace(
        id="cred1",
        email="user@example.com",
        profile="USER",
        is_active=True,
    )

    monkeypatch.setattr(auth, "session_scope", fake_session_scope)
    monkeypatch.setattr(auth, "AppCredentialRepository", FakeCredRepo)
    monkeypatch.setattr(auth, "TokenRepository", FakeTokenRepo)
    monkeypatch.setattr(auth.PasswordService, "set_password", lambda *_args, **_kwargs: cred)
    monkeypatch.setattr(auth.PasswordService, "change_password", lambda *_args, **_kwargs: cred)
    monkeypatch.setattr(auth.PasswordService, "reset_password", lambda *_args, **_kwargs: cred)

    client = TestClient(app)

    set_resp = client.post(
        "/api/v1/auth/password/set",
        json={"email": "user@example.com", "profile": "USER", "password": "User1234"},
    )
    assert set_resp.status_code == 200
    assert set_resp.json()["email"] == "user@example.com"

    change_resp = client.post(
        "/api/v1/auth/password/change",
        json={"current_password": "Old12345", "new_password": "New12345"},
    )
    assert change_resp.status_code == 200

    reset_resp = client.post(
        "/api/v1/auth/password/reset",
        json={"email": "user@example.com", "new_password": "Reset1234", "profile": "USER"},
    )
    assert reset_resp.status_code == 200

    logout_resp = client.post("/api/v1/auth/logout")
    assert logout_resp.status_code == 200
    assert logout_resp.json()["success"] is True

    app.dependency_overrides.clear()

