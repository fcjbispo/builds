"""API-042: unit tests for security audit trail events."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest
from fastapi.security import HTTPAuthorizationCredentials
from fastapi.testclient import TestClient

from infobr.api.dependencies import security
from infobr.api.dependencies.security import require_admin
from infobr.api.main import app
from infobr.api.routers import auth
from infobr.api.services.security_audit import audit_security_event


def _request(path: str, method: str = "GET") -> SimpleNamespace:
    return SimpleNamespace(
        headers={"x-request-id": "req-123"},
        url=SimpleNamespace(path=path),
        method=method,
        client=SimpleNamespace(host="127.0.0.1"),
    )


def test_audit_security_event_uses_info_for_success_and_warning_for_denied(monkeypatch):
    emitted: list[tuple[str, str]] = []
    fake_logger = SimpleNamespace(
        info=lambda msg: emitted.append(("info", msg)),
        warning=lambda msg: emitted.append(("warning", msg)),
    )
    monkeypatch.setattr("infobr.api.services.security_audit.logger", fake_logger)

    audit_security_event(event="token.use", outcome="success", actor_email="admin@example.com")
    audit_security_event(event="token.use", outcome="denied", reason="invalid_or_expired")

    assert emitted[0][0] == "info"
    assert '"event": "token.use"' in emitted[0][1]
    assert '"outcome": "success"' in emitted[0][1]
    assert emitted[1][0] == "warning"
    assert '"outcome": "denied"' in emitted[1][1]


def test_get_current_token_emits_use_audit_event(monkeypatch):
    token_ok = SimpleNamespace(
        id="tok-ok",
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="prefix",
    )
    emitted: list[dict] = []

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class Repo:
        def __init__(self, _session):
            pass

    monkeypatch.setattr(security, "session_scope", fake_session_scope)
    monkeypatch.setattr(security, "TokenRepository", Repo)
    monkeypatch.setattr(
        security.TokenService,
        "validate_bearer_token",
        lambda *_args, **_kwargs: token_ok,
    )
    monkeypatch.setattr(
        security,
        "audit_security_event",
        lambda **kwargs: emitted.append(kwargs),
    )

    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="token-ok")
    result = security.get_current_token(creds, request=_request("/api/v1/auth/me"))
    assert result is token_ok
    assert emitted[-1]["event"] == "token.use"
    assert emitted[-1]["outcome"] == "success"
    assert emitted[-1]["target_token_id"] == "tok-ok"


def test_auth_routes_emit_create_revoke_rotate_audit_events(monkeypatch):
    app.dependency_overrides[require_admin] = lambda: SimpleNamespace(
        email="admin@example.com",
        profile="ADMIN",
        token_prefix="admintok",
    )
    emitted: list[dict] = []
    now = datetime.now(timezone.utc)
    token_obj = SimpleNamespace(
        id="tok-001",
        email="client@example.com",
        profile="ADMIN",
        token_prefix="tokpref",
        expires_at=None,
        is_active=True,
        last_used_at=None,
        created_at=now,
        updated_at=None,
        created_by="admin@example.com",
    )

    @contextmanager
    def fake_session_scope():
        session = SimpleNamespace(expunge=lambda _obj: None)
        yield session

    class FakeTokenRepo:
        def __init__(self, _session):
            pass

        def revoke(self, _token_id):
            return token_obj

        def get_by_id(self, _token_id):
            return token_obj

    monkeypatch.setattr(auth, "session_scope", fake_session_scope)
    monkeypatch.setattr(auth, "TokenRepository", FakeTokenRepo)
    monkeypatch.setattr(
        auth.TokenService,
        "issue_token",
        lambda *_args, **_kwargs: (token_obj, "raw-created"),
    )
    monkeypatch.setattr(
        auth.TokenService,
        "rotate_token",
        lambda *_args, **_kwargs: (token_obj, "raw-rotated"),
    )
    monkeypatch.setattr(
        auth,
        "audit_security_event",
        lambda **kwargs: emitted.append(kwargs),
    )

    client = TestClient(app)

    create_resp = client.post(
        "/api/v1/auth/tokens",
        json={"email": "client@example.com", "profile": "ADMIN"},
        headers={"x-request-id": "req-1"},
    )
    assert create_resp.status_code == 201

    revoke_resp = client.post(
        "/api/v1/auth/tokens/tok-001/revoke",
        headers={"x-request-id": "req-2"},
    )
    assert revoke_resp.status_code == 200

    rotate_resp = client.post(
        "/api/v1/auth/tokens/tok-001/rotate",
        json={},
        headers={"x-request-id": "req-3"},
    )
    assert rotate_resp.status_code == 200

    events = {(item["event"], item["outcome"]) for item in emitted}
    assert ("token.create", "success") in events
    assert ("token.revoke", "success") in events
    assert ("token.rotate", "success") in events

    app.dependency_overrides.clear()

