"""API-024: TUI post-refactor regression tests (API-023)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from infobr.data.elt import ELT_TUI
from infobr.services.operations import (
    get_operation_page,
    list_operation_files,
    read_operation_file,
    summarize_operation_file,
)
from infobr.services.pipelines import get_pipeline_config, list_pipelines


def test_list_pipelines_and_get_config(tmp_path: Path):
    pipelines_dir = tmp_path / "pipelines"
    pipelines_dir.mkdir(parents=True, exist_ok=True)

    (pipelines_dir / "zeta.json").write_text(
        json.dumps({"processor": "SeriesLoadDataProcessor", "scopes": ["FII"]}),
        encoding="utf-8",
    )
    (pipelines_dir / "alpha.json").write_text(
        json.dumps({"processor": "SeriesExtractDataProcessor", "scopes": ["ETF"]}),
        encoding="utf-8",
    )

    items = list_pipelines(str(pipelines_dir))
    assert [p.name for p in items] == ["alpha", "zeta"]

    config = get_pipeline_config("alpha", str(pipelines_dir))
    assert config["processor"] == "SeriesExtractDataProcessor"
    assert config["scopes"] == ["ETF"]


def test_operations_list_read_page_summary(tmp_path: Path):
    operations_dir = tmp_path / "operations"
    operations_dir.mkdir(parents=True, exist_ok=True)
    output_file = operations_dir / "series.load.full.out.2026-02-20_10-30-00.json"
    output_file.write_text(
        json.dumps(
            [
                {"scope": "AAA", "success": True, "error_message": None, "data": {}},
                {"scope": "BBB", "success": False, "error_message": "db error", "data": {}},
                {"scope": "CCC", "success": True, "error_message": None, "data": {}},
            ]
        ),
        encoding="utf-8",
    )

    files = list_operation_files(limit=10, operations_dir=str(operations_dir))
    assert len(files) == 1
    assert files[0].pipeline_name == "series.load.full"

    records = read_operation_file(str(output_file))
    assert len(records) == 3

    page = get_operation_page(str(output_file), page=1, page_size=2)
    assert page.total_records == 3
    assert page.total_pages == 2
    assert len(page.items) == 2

    summary = summarize_operation_file(str(output_file))
    assert summary.total_operations == 3
    assert summary.successful_operations == 2
    assert summary.failed_operations == 1
    assert len(summary.errors) == 1
    assert summary.errors[0].scope == "BBB"


def test_tui_get_pipelines_uses_service_output(monkeypatch):
    class _Item:
        def __init__(self, name: str, path: str):
            self.name = name
            self.path = path

    monkeypatch.setattr(
        "infobr.data.elt.list_pipelines",
        lambda _folder: [_Item("p1", "/tmp/p1.json"), _Item("p2", "/tmp/p2.json")],
    )

    tui = ELT_TUI()
    assert tui.get_pipelines() == [("p1", "/tmp/p1.json"), ("p2", "/tmp/p2.json")]


def test_tui_direct_mode_exits_when_pipeline_missing(monkeypatch):
    monkeypatch.setattr("infobr.data.elt.validate_pipeline_exists", lambda *_args, **_kwargs: (_ for _ in ()).throw(FileNotFoundError()))
    monkeypatch.setattr("infobr.data.elt.ELT_TUI.display_header", lambda _self: None)
    monkeypatch.setattr("infobr.data.elt.ELT_TUI.clear_screen", lambda _self: None)
    monkeypatch.setattr("infobr.data.elt.ELT_TUI.get_pipelines", lambda _self: [])

    tui = ELT_TUI()
    with pytest.raises(SystemExit) as exc:
        tui.run_pipeline_direct("missing.pipeline")
    assert exc.value.code == 1
