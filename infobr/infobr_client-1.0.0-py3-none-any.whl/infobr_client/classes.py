'''
InfoBR Client Classes
'''

import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class InfoBRClient:
    ''' 
        Client for InfoBR API RESET Service

        Attributes
        ----------
        _endpoint : str
            Current endpoint for the REST service. Default = Internal service url.
        _verifyssl : bool
            Configure SSL certificate verification on service request commands. Default = False.
    '''
    _endpoint = 'https://150.136.160.68:5101/infobr/v1'
    _verifyssl = False

    def __init__(self, api_key: str, endpoint: str=None, verifyssl: bool=None):
        '''
            Creates a new instance of InfoBRClient.

            api_key
                The API key registered for the service.
            endpoint
                Overrides default endpoint definition.
            verifyssl
                Set verification for the SSL certificate used for the service. Defaults to False.
        '''
        self._endpoint = endpoint or self._endpoint
        self._verifyssl = verifyssl or self._verifyssl
        self._api_key = api_key

        self._headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0',
            'Accept': 'application/json',
            'Accept-Language': 'pt-BR,pt',
            'X-API-KEY': self._api_key
        }

    def _get(self, url: str, params: dict=None):
        '''
            Global GET method execution.

            url
                Full url for the REST service.
            params
                Query parameters for the service url.
        '''
        params = params or {}
        response = requests.get(url, params=params, headers=self._headers, verify=self._verifyssl)

        if response.status_code == 200:
            return json.loads(response.content)
        else:
            raise Exception('Fail executing operation. Error code: {}'.format(response.status_code))

    def get_stockprice(self, ticker: str, market: str=None):
        '''
            GET /stockprice/{ticker}
            Return the current stock price from Google Finance.

            ticker
                The stock ticker code

            market
                The market code. Defaults to BVMF

            Return the response object filled with request and response times
        '''
        market = 'BVMF' or market
        _url = '/'.join([self._endpoint, 'stockprice', ticker])
        _params = {} if market else {
            'market': market
        }
        return self._get(_url, params=_params)

    def get_exchangerate(self, currency_from: str, currency_to: str):
        '''
            GET /exchangerate/{currency_from}/{currency_to}
            Return the exchange rate for from the first currency to the second from Google Finance.
            The currency codes used are the ISO 4217

            currency_from
                The currency code to be exchanged

            currency_to
                The currency code to be used to exchange

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'exchangerate', currency_from, currency_to])
        return self._get(_url)

    def get_investmentfund_details(self, fund_id: str):
        '''
            GET /investmentfund/{id}/details
            Return detailed info for a specific investment fund on CVM.

            id
                The investment fund id

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'investmentfund', fund_id, 'details'])
        return self._get(_url)

    def get_investmentfund_position(self, fund_id: str):
        '''
            GET /investmentfund/{id}/position
            Return financial position info for a specific investment fund on CVM.

            id
                The investment fund id

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'investmentfund', fund_id, 'position'])
        return self._get(_url)

    def get_investmentfunds_managers(self, manager: str=None):
        '''
            GET /investmentfunds/managers
            Return a list for matched investment funds managers using given pattern.

            manager
                The pattern used to search investment funds. Use pieces of the desired fund 
                manager name. Defaults to None

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'investmentfunds', 'managers'])
        _params = {} if manager is None else {
            'manager': manager
        }
        return self._get(_url, params=_params)

    def get_investmentfunds(self, manager: str, fund_name: str=None):
        '''
            GET /investmentfunds/{manager}
            Return info for matched investment funds using given pattern.

            manager
                The pattern used to search investment funds. Use pieces of the desired fund 
                manager name. Required

            name
                The pattern used to search investment funds. Use pieces of the desired fund name.
                Defaults to None

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'investmentfunds', manager])
        _params = {} if fund_name is None else {
            'name': fund_name
        }
        return self._get(_url, params=_params)

    def get_treasurybond(self, bond_name: str):
        '''
            GET /treasurybond/{bond_name}
            Return info for specific treasury bond listed and current market.

            bond
                The bond name. Required

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'treasurybond', bond_name])
        return self._get(_url)

    def get_treasurybonds(self):
        '''
            GET /treasurybonds
            Return info for all listed and current market.

            Return the response object filled with request and response times
        '''
        _url = '/'.join([self._endpoint, 'treasurybonds'])
        return self._get(_url)