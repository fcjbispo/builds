'''
InfoBR Client CLI
'''

import sys
import json
import click
from pprint import pprint

from infobr_client.classes import InfoBRClient

@click.group()
def cli():
    pass

@click.command(help="Get current stock price")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-t', '--ticker', required=True, help='Ticker code which information is requested.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_stock_price(api_key, ticker, market=None, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_stockprice(ticker, market)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_stock_price)

@click.command(help="Get currency exchange rate")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-f', '--from', required=True, help='From Currency code.')
@click.option('-t', '--to', required=True, help='To Currency code.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_exchangerate(api_key, currency_from, currency_to, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_exchangerate(currency_from, currency_from)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_exchangerate)

@click.command(help="Get investment funds from a specific manager")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-m', '--manager', required=True, help='Manager name or part name to search for investment funds.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_investmentfunds(api_key, manager, fund_name=None, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_investmentfunds(manager, fund_name)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_investmentfunds)

@click.command(help="Get investment fund details")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-f', '--fund_id', required=True, help='Investment fund Id.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_investmentfund_details(api_key, fund_id, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_investmentfund_details(fund_id)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_investmentfund_details)

@click.command(help="Get investment fund position")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-f', '--fund_id', required=True, help='Investment fund Id.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_investmentfund_position(api_key, fund_id, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_investmentfund_position(fund_id)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_investmentfund_position)

@click.command(help="Get investment funds managers")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-m', '--manager', required=False, help='Pattern to match with manager name or ALL if None.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_investmentfunds_managers(api_key, manager, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
          cli.get_investmentfunds_managers(manager)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_investmentfunds_managers)

@click.command(help="Get all treasury bonds listed")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_treasurybonds(api_key, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_treasurybonds()
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_treasurybonds)

@click.command(help="Get treasury bonds detailed information")
@click.option('-k', '--api-key', required=True, help='API Key registered for the service.')
@click.option('-b', '--bond_name', required=True, help='Treasury Bond name.')
@click.option('--endpoint', required=False, help='API Service endpoint.')
@click.option('--verifyssl', default=False, is_flag=True, help='Validate/verify SSL connection.')
def get_treasurybond(api_key, bond_name, endpoint=None, verifyssl=None):
    try:
        endpoint = endpoint or InfoBRClient._endpoint
        verifyssl = verifyssl or False
        cli = InfoBRClient(api_key=api_key, endpoint=endpoint, verifyssl=verifyssl)
        pprint(
           cli.get_treasurybond(bond_name)
        )
        sys.exit(0)
    except Exception as e:
        click.echo('Operation failed: {}.'.format(e))
        sys.exit(1)

cli.add_command(get_treasurybond)

# initialize the cli interface
if __name__ == '__main__':
    cli()