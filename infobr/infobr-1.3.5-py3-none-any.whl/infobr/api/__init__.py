'''
API Package
Provides modules, functions and classes for the system REST API.
'''