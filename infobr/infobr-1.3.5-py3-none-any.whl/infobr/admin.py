'''
Admin Module
Provides cli with administration operations.
'''
import sys, subprocess
from datetime import datetime
from enum import auto

import re
import click

from infobr import core
from infobr.core import db
from infobr.api import server
from infobr.model.security import AuthorizationKey
from infobr.providers.cvm.update import if_daily_position as idp
from infobr.providers.cvm.update import if_history_files as ihf
from infobr.providers.cvm.update import if_manage_headers as imh

from fbpyutils import datetime as dutl

from sqlalchemy import and_, or_


_et = lambda x: '{}d, {}hs {}mins {}secs'.format(*x)

_validate_email = lambda x: re.search('^(\w|\.|\_|\-)+[@](\w|\_|\-|\.)+[.]\w{2,3}$', x)

# cli (main) group
@click.group()
def cli():
    pass

# security group
@click.group(help='Performs security operations as api key creation/expiration.')
def security():
    pass

# list keys for an email
@click.command(help='List all api keys registered for an specific email or all.')
@click.option('-e', '--email', required=True, help='Registered email for the api key or ALL for all emails.')
@click.option('--with-expireds', default=False, is_flag=True, help='Include expired api keys.')
def list_api_keys(email: str, with_expireds: bool = False):
    start_date = datetime.now()
    try:
        aks = list(
            AuthorizationKey.query.filter(
                and_(
                    or_(AuthorizationKey.registered_email == email, email.upper() == 'ALL'),
                    or_(AuthorizationKey.is_expired == False, with_expireds)
                )
            ).order_by(
                    AuthorizationKey.registered_email,
                    AuthorizationKey.creation_date.desc()
            ).all()
        )
        
        emails = set([a.registered_email for a in aks])
        for e in emails:
            click.echo('API keys for {}:'.format(e))
            ak = [a for a in aks if a.registered_email == e]
            for i in range(0, len(ak)):
                tags = []
                if ak[i].is_privileged:
                    tags.append('privileged')
                if ak[i].is_expired:
                    tags.append('expired')
                tag = '' if len(tags) == 0 else ' ({})'.format(','.join(tags))

                click.echo('\tKey #{}: {}{}'.format(
                    i, 
                    ak[i].api_key,
                    tag
                ))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        db.session.rollback()
        click.echo('Failed on api keys listing: {}.'.format(e))
        sys.exit(1)

# create infobr apy key
@click.command(help='Creates a new api key.')
@click.option('-e', '--email', required=True, help='Registered email for this api key.')
@click.option('--privileged', default=False, is_flag=True, help='Creates a api key with admin privileges.')
def create_api_key(email: str, privileged: bool = False):
    start_date = datetime.now()
    ak = AuthorizationKey()
    try:
        if not _validate_email(email):
            raise Exception('Invalid email: {}'.format(email))

        ak.is_privileged = bool(privileged)
        ak.registered_email = email

        db.session.add(ak)
        db.session.commit()

        click.echo('New{}api key {} created for {}.'.format((' privileged ' if privileged else ' '), ak.api_key, email))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        db.session.rollback()
        click.echo('Failed on api key creation: {}.'.format(e))
        sys.exit(1)

# expire api keys due to last access greater than specifict number of days or all
@click.command(help='Expires api keys unused for {} days.'.format(core.settings['api_key_expiration_days']))
@click.option('-a', '--all', is_flag=True, help='Expires all api keys regardless last usage.')
def expire_keys(all: bool = False):
    start_date = datetime.now()
    try:
        expireds = 0
        for ak in AuthorizationKey.query.filter(AuthorizationKey.is_expired == False).all():
            if dutl.elapsed_time(ak.last_access or datetime.now(), ak.creation_date)[0] >= \
                core.settings['api_key_expiration_days'] or all:
                ak.is_expired = True
                expireds += 1
        db.session.commit()
        click.echo('{} expired API Key(s).'.format(expireds))
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
    except Exception as e:
        click.echo('API Keys expiration failed: {}'.format(e))
        sys.exit(1)

security.add_command(create_api_key)
security.add_command(list_api_keys)
security.add_command(expire_keys)
cli.add_command(security)

# update group
@click.group(help='Performs update operations for financial data.')
def update():
    pass

# run the CVM data update
@click.command(help='Updates CVM Investment Funds daily position.')
@click.option('-f', '--force', is_flag=True, help='Forces update even no new history files where gathered.')
def cvm_if_daily_position(force: bool=False):
    start_date = datetime.now()
    try:
        new_history_files = len(ihf.update_history_files())
        if new_history_files > 0 or force:
            headers_changed = imh.update_if_headers()
            if not headers_changed:
                affected_rows = idp.update_if_daily_position(idp.get_if_daily_data())
                click.echo('Update of CVM IF Daily Position: {} new history files. {} rows_affected.'.format(new_history_files, affected_rows))
            else:
                raise RuntimeError('Update of CVM IF Daily Position Failed: headers changed.')
        else:
            click.echo('No new history files where gathered. Try with --force option.')
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        click.echo('Update of CVM IF Daily Position failed: {}'.format(e))
        sys.exit(1)

@click.command(help='Detects headers changes in CVM Investment Funds history files.')
def cvm_if_detect_headers_changes():
    start_date = datetime.now()
    try:
        header_changed = imh.update_if_headers()
        if header_changed:
            click.echo('CVM IF headers changed.')
        else:
            click.echo('CVM IF headers not changed.')
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        click.echo('CVM IF headers change detection failed: {}'.format(e))
        sys.exit(1)

update.add_command(cvm_if_daily_position)
update.add_command(cvm_if_detect_headers_changes)
cli.add_command(update)

@click.group(help='Run operations and servers.')
def run():
    pass

@click.command(help='Runs API Server')
@click.option('-s', '--secure', is_flag=True, help='Runs API Server in secure mode. Requires SSL certificates.')
def api_server(secure: bool=False):
    start_date = datetime.now()
    try:
        if secure:
            if not all([core.settings['api_server_ssl_certificate'], core.settings['api_server_ssl_keyfile']]):
                raise Exception('No SSL certificates/keyfile provided.')
            
            _run = '''gunicorn 
                      --certfile={certfile} 
                      --keyfile={keyfile} 
                      --workers={workers} 
                      --bind={host}:{port} infobr.api.server:app'''.format(
                          certfile=core.settings['api_server_ssl_certificate'],
                          keyfile=core.settings['api_server_ssl_keyfile'],
                          workers=core.settings['api_server_workers'],
                          host=core.settings['host_listen_address'],
                          port=core.settings['host_listen_port']
                      ).split()

            subprocess.call(_run)
        else:
            server.run_api_server()
        click.echo('Operation full completed in {}.'.format(_et(dutl.elapsed_time(datetime.now(), start_date))))
        sys.exit(0)
    except Exception as e:
        click.echo('API Server run failed: {}'.format(e))
        sys.exit(1)

run.add_command(api_server)
cli.add_command(run)

# initialize the cli interface
if __name__ == '__main__':
    cli()
