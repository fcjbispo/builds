'''
Utility for update CVM investment funds.
'''

import os
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from fbpyutils import string as sutl, file as futl

import infobr
from infobr.model.cvm import IFDailyPosition
from infobr.providers.cvm import update as cvm_update
from infobr.providers.cvm.update.converters import *

import sqlalchemy as sql

core = cvm_update.core
db = core.db

source_encoding, target_encoding = 'iso-8859-1', 'utf-8'

def _apply_converters(data, converters):
    for k, v in converters.items():
        if k in data.columns:
            data[k] = data[k].apply(v)
    return data.where(pd.notnull(data), None)


def _get_expression_and_converters(mappings):
    expressions, converters = [], {}
    for m in mappings:
        expression = 'NULL'
        if not is_nan_or_empty(m['Source_Field']):
            
            expression = m['Source_Field']

            if not is_nan_or_empty(m['Transformation1']):
                expression = m['Transformation1'].replace('$X', expression)

                if not is_nan_or_empty(m['Transformation2']):
                    expression = m['Transformation2'].replace('$X', expression)

                    if not is_nan_or_empty(m['Transformation3']):
                        expression = m['Transformation3'].replace('$X', expression)

        converters[m['Target_Field']] = eval(m['Converter'].replace('_as_', 'as_'))
        expressions.append(f"{expression} AS {m['Target_Field']}")
    return expressions, converters


def get_if_daily_data() -> DataFrame:
    step, engine, conn = None, None, None

    try:
        step = 'CREATING SQLITE ENGINE'
        engine = sql.create_engine(core.settings['stage_db_url'], echo=core.settings['debug_info'])
        conn = engine.connect()

        step = 'SETTING UP HISTORY FOLDER'
        history_folder = cvm_update.CVM_HISTORY_FOLDER

        step = 'SETTING UP MAPPING DATA'
        header_mappings_file = os.path.sep.join([infobr.APP_FOLDER, 'providers', 'cvm', 'data', 'if_headers.xlsx'])

        if_header_mappings = pd.read_excel(header_mappings_file)

        step = 'SETTING UP FI REGISTER DATA'
        if_register_mask = 'if_register.cad_fi.csv'
        if_register_files = futl.find(history_folder, if_register_mask)

        if len(if_register_files) < 1:
            raise ValueError('No FI REGISTER files found.')

        if_register_file = if_register_files[0]

        with open(if_register_file, 'r') as f:
            line = f.readline()
            f.close()
        file_name_parts = if_register_file.split(os.path.sep)[-1].split('.')
        kind = file_name_parts[0].upper()
        file = file_name_parts[-2]
         
        if 'cad_fi' == file.lower() or file.lower().startswith('inf_cadastral_fi'):
            sub_kind = 'CAD_FI'
        elif file.lower().startswith('inf_diario_fi'):
            sub_kind = 'DIARIO_FI'
        else: 
            sub_kind = file.upper()

        line = line.split('\n')[0]
        header_hash = sutl.hash_string(';'.join([kind, sub_kind, line]))

        mappings = if_header_mappings[if_header_mappings.Hash == header_hash].to_dict('records')

        expressions, converters1 = _get_expression_and_converters(mappings)

        if_register_table = 'cvm_if_register'
        _ = pd.read_csv(if_register_file, sep=';', encoding=target_encoding, dtype=str).to_sql(if_register_table, conn, if_exists='replace', index=False)

        expression = f"SELECT {', '.join(expressions)} FROM {if_register_table}"

        _ = pd.read_sql(expression, con=conn).to_sql(if_register_table, conn, if_exists='replace', index=False)

        step = 'SETTING UP DAILY POSITION DATA'
        if_position_mask = f'if_position.inf_diario_fi_{datetime.now().year}*.csv'
        if_position_mask

        if_position_files = futl.find(history_folder, if_position_mask)
        if_position_file = max(if_position_files)

        with open(if_position_file, 'r') as f:
            line = f.readline()
            f.close()
        file_name_parts = if_position_file.split(os.path.sep)[-1].split('.')
        kind = file_name_parts[0].upper()
        file = file_name_parts[-2]
        
        if 'cad_fi' == file.lower() or file.lower().startswith('inf_cadastral_fi'):
            sub_kind = 'CAD_FI'
        elif file.lower().startswith('inf_diario_fi'):
            sub_kind = 'DIARIO_FI'  
        else:
            sub_kind = file.upper()

        line = line.split('\n')[0]
        header_hash = sutl.hash_string(';'.join([kind, sub_kind, line]))

        mappings = if_header_mappings[if_header_mappings.Hash == header_hash].to_dict('records')

        expressions, converters2 = _get_expression_and_converters(mappings)

        if_position_table = 'cvm_if_daily'
        _ = pd.read_csv(if_position_file, sep=';', encoding=target_encoding, dtype=str).to_sql(if_position_table, conn, if_exists='replace', index=False)

        expression = f"SELECT {', '.join(expressions)} FROM {if_position_table}"

        _ = pd.read_sql(expression, con=conn).to_sql(if_position_table, conn, if_exists='replace', index=False)

        step = 'CREATING INDEXES'
        _ = engine.execute(f"CREATE INDEX IF NOT EXISTS {if_register_table}_i001 ON {if_register_table} (fund_type, fund_id)")
        _ = engine.execute(f"CREATE INDEX IF NOT EXISTS {if_register_table}_i002 ON {if_register_table} (excercise_start_date, excercise_end_date, situation_code)")
        _ = engine.execute(f"CREATE INDEX IF NOT EXISTS {if_position_table}_i001 ON {if_position_table} (fund_type, fund_id)")

        step = 'CONSOLIDATING DATA'
        cvm_daily_position = pd.read_sql("""
            WITH Q AS (
                SELECT fund_type, fund_id, MAX(position_date) position_date
                FROM cvm_if_daily
                GROUP BY fund_type, fund_id
                ORDER BY fund_type, fund_id
            ), G AS (
                select fund_type, fund_id, max(rowid) as rowid
                from cvm_if_register
                group by fund_type, fund_id
                ORDER BY fund_type, fund_id
            )
            SELECT DISTINCT
                A.fund_type,
                A.fund_id,
                A.fund_name,
                A.register_date,
                A.constitution_date,
                A.cvm_code,
                A.cancel_date,
                A.situation_code,
                A.situation_start_date,
                A.situation_end_date,
                A.excercise_start_date,
                A.excercise_end_date,
                A.fund_class,
                A.class_start_date,
                A.profitability_type,
                A.tenancy_type,
                A.is_quote_fund,
                A.is_exclusive_fund,
                A.is_long_term_tax,
                A.is_qualified_investment,
                A.is_investment_entity,
                A.perf_rate,
                A.perf_rate_info,
                A.admin_rate,
                A.admin_rate_info,
                A.net_worth,
                A.net_worth_date,
                A.director_name,
                A.admin_id,
                A.admin_name,
                A.manager_type,
                A.manager_id,
                A.manager_name,
                A.controller_id,
                A.controller_name,
                A.custodian_id,
                A.custodian_name,
                A.supervisor_id,
                A.supervisor_name,
                B.total_value,
                B.quota_value,
                B.net_worth_value,
                B.daily_capture_value,
                B.daily_redemption_value,
                B.shareholders,
                B.position_date
            FROM cvm_if_register A
            JOIN cvm_if_daily B
                ON (A.fund_type = B.fund_type AND
                    A.fund_id = B.fund_id)
            JOIN Q
                ON (B.fund_type = Q.fund_type AND
                    B.fund_id = Q.fund_id AND
                    B.position_date = Q.position_date)
            JOIN G
                ON (G.fund_type = A.fund_type AND
                    G.fund_id = A.fund_id AND
                    G.rowid = A.rowid)
            WHERE B.position_date between A.excercise_start_date and A.excercise_end_date
            AND A.situation_code NOT IN ('CANCELADA', 'FASE PRÉ-OPERACIONAL')
            ORDER BY A.fund_type, A.fund_id, B.position_date
        """, engine)

        step="APPLYING CONVERSIONS"
        converters = {**converters1, **converters2}

        cvm_daily_position = _apply_converters(cvm_daily_position, converters)

        return cvm_daily_position
    except Exception as e:
        raise ValueError('Fail to get CVM IF DAILY Data on step {}: {}'.format(step, e))
    finally:
        if conn: conn.close()
        if engine: engine.dispose()


def update_if_daily_position(data: DataFrame, commit_at=0) -> None:
    p = None
    rows = 0
    uncommited = 0
    step = None
    position_key = sutl.random_string(6)
    try:
        records = data.to_dict('records')
        for p in records:
            p['position_key'] = position_key

            step = 'INSERT DATA'
            x = IFDailyPosition(**p)
            db.session.add(x)
            rows += 1
            uncommited += 1
            
            step = 'INTERMEDIATE COMMIT: DATA'
            if commit_at > 0 and uncommited >= commit_at:
                _ = db.session.commit()
                uncommited = 0

        step = 'FINAL COMMIT: DATA'
        _ = db.session.commit()

        step = 'REMOVE OLD DATA'
        stmt = sql.delete(IFDailyPosition).where(IFDailyPosition.position_key != position_key)
        db.session.execute(stmt)
        step = 'FINAL COMMIT: OLD DATA REMOVAL'
        db.session.commit()

        return rows
    except Exception as e:
        db.session.rollback()
        step = 'REMOVE REMAINNING NEW DATA'
        stmt = sql.delete(IFDailyPosition).where(IFDailyPosition.position_key == position_key)
        db.session.execute(stmt)
        step = 'FINAL COMMIT: REMAINNING NEW DATA REMOVAL'
        db.session.commit()
        raise(ValueError('Failed update on step {} at line {} with error {}; Data: {}.'.format(step, rows, e, p)))