import sys, os

import pandas as pd

from fbpyutils import string as sutl, file as futl

import infobr 
from infobr.providers.cvm import update as cvm_update

import sqlalchemy as sql

core = cvm_update.core

def update_if_headers() -> bool:
    step, engine, conn = None, None, None

    try:
        step = 'CREATING SQLITE ENGINE'
        engine = sql.create_engine(core.settings['stage_db_url'], echo=core.settings['debug_info'])
        conn = engine.connect()

        history_folder = cvm_update.CVM_HISTORY_FOLDER

        step = 'READING HEADERS MAPPINGS INFO'
        header_mappings_file = os.path.sep.join([infobr.APP_FOLDER, 'providers', 'cvm', 'data', 'if_header_mappings.xlsx'])
        if not os.path.exists(header_mappings_file):
            raise FileNotFoundError(f"Header Mappings not found.")

        _ = pd.read_excel(
            header_mappings_file, sheet_name='IF_HEADERS'
        ).to_sql('if_headers', conn, index=False, if_exists='replace')

        header_mappings = {}

        for header in pd.read_sql("""
            select distinct Header
            from if_headers
        """, con=conn).to_dict('records'):
            mappings = pd.read_sql("""
            select "Order", Target_Field, Source_Field, Transformation1, Transformation2, Transformation3, Converter
                from if_headers 
                where Header=?
                order by "Order"
            """, con=conn, params=[header['Header']]).to_dict('records')
            header_mappings[header['Header']] = mappings

        step = 'READING IF HISTORY FILES'
        file_mask = 'if_*.csv'
        if_source_files = futl.find(history_folder, mask=file_mask)

        if_source_headers = set()

        for if_register_file in if_source_files:
            with open(if_register_file, 'r') as f:
                line = f.readline()
                f.close()
            file_name_parts = if_register_file.split(os.path.sep)[-1].split('.')
            kind = file_name_parts[0].upper()
            file = file_name_parts[-2]
            sub_kind = 'CAD_FI' if 'cad_fi' == file.lower() or file.lower().startswith('inf_cadastral_fi') \
                else 'DIARIO_FI' if file.lower().startswith('inf_diario_fi') else file.upper()
            line = line.split('\n')[0]
            if_source_headers.add((kind, sub_kind, line, sutl.hash_string(';'.join([kind, sub_kind, line]))))

        _ = pd.DataFrame(
            if_source_headers, columns=['Kind', 'Sub_Kind', 'Header', 'Hash']
        ).to_sql('if_source_headers', conn, index=False, if_exists='replace')


        step = 'READING CURRENT HEADERS INFO'
        header_mappings_file = os.path.sep.join([infobr.APP_FOLDER, 'providers', 'cvm', 'data', 'if_headers.xlsx'])
        if os.path.exists(header_mappings_file):
            mappings = pd.read_excel(header_mappings_file, sheet_name='IF_HEADERS').to_dict('records')
        else:
            mappings = []

        existing_mappings = set([m.get('Hash') for m in mappings])

        if len(if_source_files) == 0 and len(existing_mappings) == 0:
            raise ValueError("Mappend Heanders and/or History Files Not Found.")

        step = 'COMPUTING NEW HEADERS INFO'
        for header_group in pd.read_sql("""
            select distinct Kind, Sub_Kind
            from if_source_headers
        """, con=conn).to_dict('records'):
            kind, sub_kind = header_group['Kind'], header_group['Sub_Kind']
            header_mapping = header_mappings[kind]

            for source_header in pd.read_sql("""
                select * 
                from if_source_headers
                where Kind=? and Sub_Kind=?
            """, con=conn, params=[kind, sub_kind]).to_dict('records'):
                header = source_header['Header']
                hash = source_header['Hash']

                if hash not in existing_mappings:
                    fields = header.split(';')
                    for m in header_mapping[:]:
                        found = m['Source_Field'] in fields
                        mappings.append({
                            'Kind': kind,
                            'Sub_Kind': sub_kind,
                            'Header': header,
                            'Hash': hash,
                            'Order': int(m['Order']),
                            'Target_Field': m['Target_Field'],
                            'Source_Field': m['Source_Field'] if found else None,
                            'Transformation1': m['Transformation1'] if found else None,
                            'Transformation2': m['Transformation2'] if found else None,
                            'Transformation3': m['Transformation3'] if found else None,
                            'Converter': m['Converter'] if found else None,
                            'Is_New': True
                        })

                        if sub_kind in ['CAD_FI', 'DIARIO_FI']:
                            max_order = max([
                                h['Order'] for h in header_mapping if h['Source_Field'] is not None])
                            source_fields = [
                                h['Source_Field'] for h in header_mapping if h['Source_Field'] is not None]
                            mapped_fields = [
                                m['Source_Field'] for m in mappings if m['Target_Field'] is not None] + [
                                    m['Source_Field'] for m in mappings if m['Transformation1'] is not None] + [
                                        m['Source_Field'] for m in mappings if m['Transformation2'] is not None] + [
                                            m['Source_Field'] for m in mappings if m['Transformation3'] is not None] 
                            for f in fields:
                                if not f in source_fields and not f in mapped_fields:
                                    max_order += 1
                                    mappings.append({
                                        'Kind': kind,
                                        'Sub_Kind': sub_kind,
                                        'Header': header,
                                        'Hash': hash,
                                        'Order': max_order,
                                        'Target_Field': None,
                                        'Source_Field': f,
                                        'Transformation1': None,
                                        'Transformation2': None,
                                        'Transformation3': None,
                                        'Converter': None,
                                        'Is_New': True
                                    })

        step = 'WRITING NEW HEADERS MAPPINGS INFO'
        new_mappings = set(m['Hash'] for m in mappings) - existing_mappings
        if new_mappings:
            _ = pd.DataFrame.from_dict(mappings).to_sql('if_headers_final', conn, index=False, if_exists='replace')

            if_headers_final = pd.read_sql("""
                select distinct 
                    Hash,
                    Kind,
                    Sub_Kind,
                    "Order",
                    Target_Field,
                    Source_Field,
                    Transformation1,
                    Transformation2,
                    Transformation3,
                    Converter,
                    Is_New
                from if_headers_final
                order by Hash,
                        "Order"
            """, con=conn)

            source_encoding, target_encoding = 'iso-8859-1', 'utf-8'
            
            if_headers_final.to_excel(header_mappings_file, sheet_name='IF_HEADERS', index=False,  encoding=target_encoding, freeze_panes=(1, 0), header=True)

            return True
        else:
            return False
    except Exception as e:
        raise ValueError('Fail to UPDATE IF HEANDERS INFO on step {}: {}'.format(step, e))
    finally:
        if conn: conn.close()
        if engine: engine.dispose()