
import os
import io
from zipfile import ZipFile
import pandas as pd
from pandas import DataFrame
from datetime import datetime
from urllib import request

from fbpyutils import file as futl

import infobr
import infobr.providers.cvm.update as cvm_update

import sqlalchemy as sql

import re, requests, bs4
from bs4 import BeautifulSoup

URL_IF_REGISTER = "http://dados.cvm.gov.br/dados/FI/CAD/DADOS"

URL_IF_REGISTER_HIST = "http://dados.cvm.gov.br/dados/FI/CAD/DADOS/HIST"

URL_IF_DAILY = "http://dados.cvm.gov.br/dados/FI/DOC/INF_DIARIO/DADOS"

URL_IF_DAILY_HIST = "http://dados.cvm.gov.br/dados/FI/DOC/INF_DIARIO/DADOS/HIST"

_get_value_by_index_if_exists = lambda x, y, z=None: x[y] if len(x) > y else z or None


_make_number_type = lambda x, y=int: None if x is None or x == '-' else int(re.sub(r'[a-zA-Z]', '', x))

core = cvm_update.core


def _replace_all(x, old, new):
    while old in x:
        x = x.replace(old, new)
    return x


def _make_datetime(x, y):
    sep = ' '
    if not all([x, y]):
        return None
    else:
        dt = sep.join([x, y])
        return datetime.strptime(dt, "%d-%b-%Y %H:%M")


def _get_url_paths(url, params={}):
    response = requests.get(url, params=params)
    if response.ok:
        response_text = response.text
    else:
        return response.raise_for_status()
    soup = BeautifulSoup(response_text, 'html.parser')
    pre = soup.find_all('pre')

    pre = pre[0] if len(pre) > 0 else None

    sep = pre.text[3:5]

    hrefs = [a.get('href') for a in [p for p in pre] if type(a) if type(a) == bs4.element.Tag]

    contents = [_replace_all(p, '  ', ' ').split(' ') for p in pre.text.split(sep)]

    directory = set()

    for i, href in enumerate(hrefs):
        directory.add((
            i,
            href,
            _get_value_by_index_if_exists(contents[i], 0),
            _make_datetime(
                _get_value_by_index_if_exists(contents[i], 1), 
                _get_value_by_index_if_exists(contents[i], 2)
            ),
            _make_number_type(_get_value_by_index_if_exists(contents[i], 3))
        ))

    headers = ['Sequence', 'HRef', 'Name', 'Last_Modified', 'Size']
    directory = pd.DataFrame(directory, columns=headers).sort_values(by='Sequence', ascending=True)

    return directory


def _get_remote_files_list(conn, kind, current_url, history_url):
    current_dir = _get_url_paths(current_url)
    current_dir['History'] = False
    current_dir['Url'] = current_url

    history_dir = _get_url_paths(history_url)
    history_dir['History'] = True
    history_dir['Url'] = history_url

    current_dir.to_sql('current_dir', conn, if_exists='replace', index=False)
    history_dir.to_sql('history_dir', conn, if_exists='replace', index=False)

    files_dir = pd.read_sql("""
        select HRef as Name, Last_Modified, Size, History, Url
        from current_dir
        Where Size is not null
        union
        select HRef as Name, Last_Modified, Size, History, Url
        from history_dir
        Where Size is not null
    """, con=conn)

    files_dir['Kind'] = kind

    return files_dir


def _write_target_file(data, metadata, target_folder, index=None, file=None, encoding='utf-8'):
    preffix = metadata['Name'].split('.')[0]
    if file:
        index = str(int('0' if index is None else index)).zfill(4)
        target_file_name = '.'.join([preffix, index, file])
    else:
        target_file_name = metadata['Name']
    target_file_name = '.'.join([metadata['Kind'].lower(), target_file_name])

    target_file = os.path.sep.join([target_folder, target_file_name])

    with open(target_file, 'wb') as f:
        f.write(data.encode(encoding))
        f.close()
    
    return target_file


source_encoding, target_encoding = 'iso-8859-1', 'utf-8'

def update_history_files() -> DataFrame:
    step, conn, engine = None, None, None
    
    try:
        step = 'CREATING SQLITE ENGINE'
        engine = sql.create_engine(core.settings['stage_db_url'], echo=core.settings['debug_info'])
        conn = engine.connect()

        step = 'SETTING UP HISTORY FOLDER'
        history_folder = cvm_update.CVM_HISTORY_FOLDER

        step = 'SETTING UP HEADERS MAPPINGS INFO'
        header_mappings_file = os.path.sep.join([infobr.APP_FOLDER, 'providers', 'cvm', 'data', 'if_header_mappings.xlsx'])
        
        all_header_mappings = pd.read_excel(header_mappings_file, sheet_name='IF_HEADERS')

        register_header_mappings = all_header_mappings[
            all_header_mappings.Header == 'IF_REGISTER'][[c for c in all_header_mappings.columns if c != 'Header']]
        position_header_mappings = all_header_mappings[
            all_header_mappings.Header == 'IF_POSITION'][[c for c in all_header_mappings.columns if c != 'Header']]

        register_header_mappings.to_sql(
            'if_register_header_mappings', conn, if_exists='replace', index=False)
        position_header_mappings.to_sql(
            'if_position_header_mappings', conn, if_exists='replace', index=False)


        step = "SETTING UP CATALOG JOURNAL"

        if_register_files = _get_remote_files_list(
            conn, 'IF_REGISTER', URL_IF_REGISTER, URL_IF_REGISTER_HIST
        )
        if_register_files.to_sql('if_register_files', conn, if_exists='replace', index=False)

        if_position_files = _get_remote_files_list(
            conn, 'IF_POSITION', URL_IF_DAILY, URL_IF_DAILY_HIST
        )
        if_position_files.to_sql('if_position_files', conn, if_exists='replace', index=False)

        if_remote_files = pd.read_sql("""
            select * 
            from if_register_files union all
            select * 
            from if_position_files
        """, conn)

        catalog_journal_file = os.path.sep.join([core.USER_FOLDER, 'if_catalog_journal.xlsx'])

        if os.path.exists(catalog_journal_file):
            catalog_journal = pd.read_excel(catalog_journal_file, sheet_name='CATALOG_JOURNAL').to_dict('records')
        else:
            catalog_journal = []

        for if_metadata in [f for f in if_remote_files.to_dict('records')]:
            if_metadata['Url'] = '/'.join([if_metadata['Url'], if_metadata['Name']])

            metadata = [m for m in catalog_journal if m['Url'] == if_metadata['Url']]
            metadata = None if len(metadata) == 0 else metadata[0]
            
            if metadata is None:
                metadata = if_metadata
                metadata['Process'] = True
                catalog_journal.append(metadata)
            else:
                if if_metadata['Last_Modified'] > metadata['Last_Modified']:
                    metadata['Process'] = True
                    metadata['Last_Modified'] = if_metadata['Last_Modified']
                else:
                    metadata['Process'] = False

        result = []
        for if_metadata in [m for m in catalog_journal if m['Process']]:
            response = request.urlopen(if_metadata['Url'])

            data = response.read()

            mime_type = futl.magic.from_buffer(data)
            mime_type = mime_type.split(';')[0]


            if mime_type == 'Zip archive data, at least v2.0 to extract':
                zip_file = ZipFile(io.BytesIO(data))
                for k, v in enumerate(zip_file.namelist()):
                    response_data = zip_file.open(v).read().decode(source_encoding)
                    r = _write_target_file(response_data, if_metadata, history_folder, index=k, file=v, encoding=target_encoding)
                    
                    result.append(f'{r} written from {if_metadata["Url"]}')
            elif mime_type == 'Non-ISO extended-ASCII text, with very long lines, with CRLF line terminators':
                response_data = data.decode(source_encoding)

                r = _write_target_file(response_data, if_metadata, history_folder, encoding=target_encoding)

                result.append(f'{r} written from {if_metadata["Url"]}')

            else:
                raise ValueError('Unknown mime type:{} for url:{}'.format(mime_type, if_metadata['Url']))


        metadata_to_process = pd.DataFrame.from_dict([j for j in catalog_journal if j.get('Process')])

        for m in catalog_journal:
            _ = m.pop('Process', None)

        catalog_journal_df = pd.DataFrame.from_dict(catalog_journal, orient='columns')
        catalog_journal_df.to_sql('if_catalog_journal', conn, if_exists='replace', index=False)

        catalog_journal_df.to_excel(
            catalog_journal_file, index=False, sheet_name='CATALOG_JOURNAL', encoding=target_encoding, freeze_panes=(1, 0))

        return metadata_to_process.to_dict('records')
    except Exception as e:
        raise ValueError('Fail to UPDATE history files on step {}: {}'.format(step, e))
    finally:
        if conn: conn.close()
        if engine: engine.dispose()



