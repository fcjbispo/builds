'''
CVM Update Package
Provides updating data modules, functions and classes for CVM (Comissão de Valores Imobiliários) provider.
'''

import os
from infobr import core

CVM_HISTORY_FOLDER = os.path.sep.join([core.settings['history_folder'], 'cvm'])

if not os.path.exists(CVM_HISTORY_FOLDER):
    os.makedirs(CVM_HISTORY_FOLDER)