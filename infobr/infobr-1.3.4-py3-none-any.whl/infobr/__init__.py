'''
InfoBR Package.
'''
import os

APP_FOLDER = os.path.dirname(os.path.realpath(__file__))
